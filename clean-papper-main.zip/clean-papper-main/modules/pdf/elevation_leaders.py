"""Conservative vector-PDF linkage: elevation text -> level glyph -> colored geometry.

A match is a graphic CONTACT CANDIDATE, not proof of a duct, centerline
endpoint, riser length, vertical quantity, or material surface.
"""
from __future__ import annotations
import argparse
import json
import math
import re
from pathlib import Path
import fitz
from schematic_evidence import parse_evidence

_SCHEME_TITLE_RX = re.compile(r'Схема\s+((?:ДП|ДВ|П|В)\s*\d+(?:[.,]\d+)?\s*-\s*\d+)', re.I)


def normalize_system(code):
    if not code:
        return None
    return re.sub(r'\s+', '', str(code)).replace(',', '.').replace('−', '-').upper()


def _pos(p):
    return (float(p.x), float(p.y))


def _dist(a, b):
    return math.dist(a, b)


def _segdist(p, a, b):
    dx, dy = b[0]-a[0], b[1]-a[1]
    scale = dx*dx+dy*dy
    t = max(0.0, min(1.0, ((p[0]-a[0])*dx+(p[1]-a[1])*dy)/scale)) if scale > 1e-9 else 0.0
    return _dist(p, (a[0]+t*dx, a[1]+t*dy))


def _extract(page, roi):
    black, colored, seen = [], [], set()
    area = fitz.Rect(*roi)
    for i, drawing in enumerate(page.get_drawings()):
        color = drawing.get('color')
        if not color:
            continue
        neutral = max(color)-min(color) < .13 and max(color) < .5
        highlighted = max(color) > .55 and max(color)-min(color) > .35
        for j, item in enumerate(drawing['items']):
            if item[0] != 'l':
                continue
            a, b = _pos(item[1]), _pos(item[2])
            line_rect = fitz.Rect(min(a[0],b[0])-.1, min(a[1],b[1])-.1,
                                  max(a[0],b[0])+.1, max(a[1],b[1])+.1)
            if _dist(a,b) < .45 or not area.intersects(line_rect):
                continue
            lo, hi = min(a,b), max(a,b)
            key = (round(lo[0],2),round(lo[1],2),round(hi[0],2),round(hi[1],2),
                   'b' if neutral else 'c')
            if key in seen:
                continue
            seen.add(key)
            edge = {'a':a, 'b':b, 'path_index':i, 'item_index':j, 'length_pt':_dist(a,b)}
            if neutral:
                black.append(edge)
            elif highlighted:
                colored.append(edge)
    return black, colored


def _glyph_stems(mark, lines):
    x0,y0,x1,y1 = mark['bbox_pt']
    width=x1-x0
    bases=[]
    for edge in lines:
        a,b=edge['a'],edge['b']
        if not 14 <= edge['length_pt'] <= 32 or abs(a[1]-b[1]) > .35:
            continue
        if min(abs(a[1]-y1),abs(b[1]-y1)) > 3.2:
            continue
        overlap=max(0, min(max(a[0],b[0]),x1)-max(min(a[0],b[0]),x0))
        if overlap < max(5,width*.55):
            continue
        bases.append(edge)
    stems=[]
    for base in bases:
        for endpoint in (base['a'],base['b']):
            for e in lines:
                if e is base:
                    continue
                a,b=e['a'],e['b']
                if abs(a[0]-b[0]) > .3 or not 6 <= e['length_pt'] <= 11:
                    continue
                if _dist(a,endpoint) < .35:
                    free=b
                elif _dist(b,endpoint) < .35:
                    free=a
                else:
                    continue
                stems.append((base,e,free))
    unique={}
    for base,stem,free in stems:
        unique[(stem['path_index'],stem['item_index'])] = (base,stem,free)
    return list(unique.values())


def _anchor_paths(free, base, stem, black, colored, max_steps=4):
    excluded={(base['path_index'],base['item_index']),
              (stem['path_index'],stem['item_index'])}
    graph=[e for e in black if min(_dist(e['a'],free),_dist(e['b'],free)) < 65
           and (e['path_index'],e['item_index']) not in excluded]
    results=[]
    frontier=[(free, [], 0., set())]
    while frontier:
        tip, path, length, used = frontier.pop()
        if path and _dist(tip,free) > 5:
            matches=[]
            for line in colored:
                distance=_segdist(tip,line['a'],line['b'])
                if distance <= 1.5:
                    matches.append((distance,line))
            if matches:
                distance,line=min(matches,key=lambda v:v[0])
                results.append({'anchor_pt':tip,'leader_parts':path,
                                'leader_length_pt':length,
                                'colored_gap_pt':round(distance,3),
                                'graphic_path_index':line['path_index'],
                                'graphic_item_index':line['item_index']})
        if len(path) >= max_steps or length > 90:
            continue
        for edge in graph:
            key=(edge['path_index'],edge['item_index'])
            if key in used:
                continue
            a,b=edge['a'],edge['b']
            if _dist(a,tip) <= .38:
                far=b
            elif _dist(b,tip) <= .38:
                far=a
            else:
                continue
            if _dist(far,free) < 2:
                continue
            frontier.append((far,path+[key],length+edge['length_pt'],used|{key}))
    return results


def link_elevation_leaders(pdf_path, page_number, bounds_pt, system=None):
    evidence=parse_evidence(pdf_path,page_number,bounds_pt,system)
    with fitz.open(str(pdf_path)) as doc:
        page=doc[page_number-1]
        # The caller-supplied system code is NOT authoritative.
        titles=[normalize_system(x) for x in _SCHEME_TITLE_RX.findall(
            page.get_text('text',clip=fitz.Rect(*bounds_pt)))]
        unique_titles=sorted(set(titles))
        recognized=unique_titles[0] if len(unique_titles)==1 else None
        verified=bool(recognized and recognized==normalize_system(system))
        evidence['scheme_title_evidence']={
            'system_read_from_pdf':recognized,
            'title_occurrences':titles,
            'verified':verified,
            'reason':'unique_matching_printed_scheme_title' if verified
                     else 'missing_ambiguous_or_mismatched_printed_title'}
        black,colored=_extract(page,bounds_pt)
        result=[]
        for mark in evidence['elevation_marks']:
            item={**mark,'status':'unresolved','leader_vector_ids':[],
                  'candidate_anchor_pt':None,'graphic_path_index':None,
                  'graphic_gap_pt':None,'verified_duct_centerline_endpoint':False}
            stems=_glyph_stems(mark,black)
            if len(stems)!=1:
                item.update(status='no_unique_level_glyph',stem_candidates=len(stems))
            else:
                base,stem,free=stems[0]
                item['level_baseline_path_index']=base['path_index']
                item['glyph_stem_path_index']=stem['path_index']
                paths=_anchor_paths(free,base,stem,black,colored)
                if not paths:
                    item['status']='glyph_detected_no_graphic_contact'
                else:
                    unique={tuple(round(z,1) for z in p['anchor_pt']):p for p in paths}
                    if len(unique)>1:
                        item['status']='multiple_graphic_contact_candidates'
                        item['candidate_anchor_points']=[list(k) for k in sorted(unique)]
                    else:
                        candidate=next(iter(unique.values()))
                        item['status']='leader_to_colored_geometry_candidate'
                        item['candidate_anchor_pt']=[round(v,2) for v in candidate['anchor_pt']]
                        item['leader_vector_ids']=[f'{p}:{j}' for p,j in candidate['leader_parts']]
                        item['graphic_path_index']=candidate['graphic_path_index']
                        item['graphic_vector_id']=f"{candidate['graphic_path_index']}:{candidate['graphic_item_index']}"
                        item['graphic_gap_pt']=candidate['colored_gap_pt']
            result.append(item)
    evidence['level_anchor_evidence']=result
    evidence['summary'].update({
        'level_anchor_candidates':sum(x['status']=='leader_to_colored_geometry_candidate' for x in result),
        'unresolved_or_ambiguous_anchors':sum(x['status']!='leader_to_colored_geometry_candidate' for x in result),
        'verified_straight_vertical_length_m':None})
    evidence['limitations'].extend([
        'Colored graphic contact is not verified ventilation duct or centerline',
        'Leader anchor does not establish riser endpoints or material quantity',
        'PDF-point positions need visual confirmation and CAD/BIM verification'])
    return evidence


def main():
    p=argparse.ArgumentParser(description='Trace elevation marks to vector graphic candidates')
    p.add_argument('pdf')
    p.add_argument('--page',type=int,required=True)
    p.add_argument('--box',nargs=4,type=float,required=True)
    p.add_argument('--system')
    p.add_argument('--output')
    args=p.parse_args()
    output=json.dumps(link_elevation_leaders(args.pdf,args.page,args.box,args.system),
                      ensure_ascii=False,indent=2)
    if args.output:
        Path(args.output).write_text(output,encoding='utf-8')
    else:
        print(output)

if __name__=='__main__':
    main()
