"""Read-only PDF ventilation-plan preflight: labels and colored vector strokes.

This module measures graphic paths, not real-world duct length. Hatching,
repeated outlines, symbols and architecture can dominate line counts.
"""
from __future__ import annotations
import argparse
import json
import re
from collections import Counter
from pathlib import Path

SECTION_RX = re.compile(r"(?<!\d)(?:[Ø⌀Фф]\s*\d{2,4}|\d{2,4}\s*[xх×]\s*\d{2,4})(?!\d)", re.I)

def color_family(color):
    if not color or len(color) != 3:
        return None
    r, g, b = color
    if b > .7 and b > r * 1.45 and b > g * 1.35:
        return "blue"
    if g > .7 and g > r * 1.45 and g > b * 1.25:
        return "green"
    if r > .7 and r > g * 1.45 and r > b * 1.45:
        return "red"
    return None

def analyze_page(page, page_number):
    strokes = Counter()
    paths = 0
    for drawing in page.get_drawings():
        paths += 1
        family = color_family(drawing.get("color"))
        if family:
            strokes[family] += 1
    labels = []
    seen = set()
    for word in page.get_text("words"):
        x0, y0, x1, y1, value = word[:5]
        for m in SECTION_RX.finditer(value):
            token = m.group(0)
            key = (token, round(x0, 2), round(y0, 2))
            if key in seen:
                continue
            seen.add(key)
            labels.append({
                "text": token,
                "rect_pt": [round(x0, 2), round(y0, 2), round(x1, 2), round(y1, 2)]
            })
    return {
        "pdf_page": page_number,
        "page_size_pt": [round(page.rect.width, 2), round(page.rect.height, 2)],
        "vector_paths_total": paths,
        "colored_path_counts": dict(strokes),
        "size_label_candidates": labels,
        "size_label_count": len(labels),
        "warning": "Colored vector paths and size labels are graphics observations; not verified ventilation elements or measured lengths.",
    }

def probe_pdf(path, pages):
    import fitz
    with fitz.open(str(path)) as pdf:
        out = []
        for page in pages:
            if page < 1 or page > len(pdf):
                raise ValueError(f"Page {page} outside 1..{len(pdf)}")
            out.append(analyze_page(pdf[page - 1], page))
        return {"total_pdf_pages": len(pdf), "pages": out}

def main():
    parser = argparse.ArgumentParser(description="PDF ventilation plan graphics preflight (not duct takeoff)")
    parser.add_argument("pdf")
    parser.add_argument("--pages", required=True, help="Comma-separated 1-based PDF page numbers")
    parser.add_argument("--output")
    args = parser.parse_args()
    pages = [int(x.strip()) for x in args.pages.split(",") if x.strip()]
    payload = json.dumps(probe_pdf(args.pdf, pages), ensure_ascii=False, indent=2)
    if args.output:
        Path(args.output).write_text(payload, encoding="utf-8")
    else:
        print(payload)

if __name__ == "__main__":
    main()
