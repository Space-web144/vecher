# PDF plan inspection

Run:
  python modules/pdf/plan_probe.py album.pdf --pages 8,9,14 --output probe.json

Emits colored vector stroke counts and section label candidates, but **not** duct quantities. Colored hatches can contain thousands of paths. Always link observations to the original page and visually verify before quantity takeoff.
