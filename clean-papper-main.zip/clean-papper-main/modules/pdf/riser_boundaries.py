"""Trace evidence for putative upper/lower junction seams of vector PDF riser contours.

A seam connecting the projected outer rails is a *drafting boundary candidate*;
it is NOT a certified duct-to-fitting connection, material length or riser port.
This read-only adapter consumes stage-7 candidate data and original PDF vectors.
"""
from __future__ import annotations
import argparse
import json
import math
from pathlib import Path
from typing import Any

import fitz

JOIN_TOL_PT = 0.65
MAX_DY_OVER_DX = 1.3
MIN_DIAGONAL_DX_PT = 3.0
ADJACENCY_TOL_PT = 0.75
OUTSIDE_EXTENSION_MIN_PT = 0.25


def _p(p):
    return float(p.x), float(p.y)


def _distance(a, b):
    return math.dist(a, b)


def _colored(c):
    if not c or len(c) != 3:
        return False
    r, g, b = c
    return (g > 0.65 and g >= r*1.35 and g > b*1.25) or (b > .65 and b > r*1.35 and b >= g*1.15)


def colored_edges(page, roi):
    region = fitz.Rect(*roi)
    if region.is_empty or not page.rect.contains(region):
        raise ValueError('Invalid PDF page region')
    result = []
    seen = set()
    for i, drawing in enumerate(page.get_drawings()):
        if not _colored(drawing.get('color')):
            continue
        for j, item in enumerate(drawing.get('items', [])):
            if item[0] != 'l':
                continue
            a, b = _p(item[1]), _p(item[2])
            if _distance(a,b) < 0.15:
                continue
            if not region.intersects(fitz.Rect(min(a[0],b[0])-.05, min(a[1],b[1])-.05,
                                                 max(a[0],b[0])+.05, max(a[1],b[1])+.05)):
                continue
            canonical=tuple(sorted(((round(a[0], 2),round(a[1],2)),
                                    (round(b[0], 2),round(b[1],2)))))
            if canonical in seen:
                continue
            seen.add(canonical)
            result.append({'a':a, 'b':b, 'vector_id':f'{i}:{j}'})
    return result


def _diag_matches(origin, edges, *, rising_x=True):
    matched=[]
    for e in edges:
        a,b=e['a'], e['b']
        if _distance(a,origin)<=JOIN_TOL_PT:
            out=b
        elif _distance(b,origin)<=JOIN_TOL_PT:
            out=a
        else:
            continue
        dx=out[0]-origin[0]
        dy=out[1]-origin[1]
        if (dx if rising_x else -dx) < MIN_DIAGONAL_DX_PT:
            continue
        if abs(dy/dx) > MAX_DY_OVER_DX:
            continue
        matched.append((e,out))
    return matched


def _seam_path(left, right, edges, intermediate):
    """Find direct / two-segment diagonals from outside rail ends.

    When an interior rail is present, a two-edge join must meet its endpoint.
    An entirely interior single horizontal line cannot masquerade as an end.
    """
    options=[]
    for first, midpoint in _diag_matches(left,edges):
        if _distance(midpoint,right) <= JOIN_TOL_PT:
            options.append({'vector_ids':[first['vector_id']],
                            'midpoint_pt':None,
                            'length_pt':_distance(left,midpoint)})
            continue
        if not intermediate or not any(_distance(midpoint,p)<=JOIN_TOL_PT for p in intermediate):
            continue
        for second,end in _diag_matches(midpoint,edges):
            if second['vector_id']==first['vector_id']:
                continue
            if _distance(end,right) > JOIN_TOL_PT:
                continue
            options.append({'vector_ids':[first['vector_id'],second['vector_id']],
                            'midpoint_pt':[round(v,3) for v in midpoint],
                            'length_pt':_distance(left,midpoint)+_distance(midpoint,end)})
    # De-duplicate paths with coinciding geometry but different vector IDs.
    unique={tuple(round(v,2) for v in (o['midpoint_pt'] or [])):o for o in options}
    return sorted(unique.values(), key=lambda r:(r['length_pt'],r['vector_ids']))


def _outside_continuations(terminal, edges, used_ids, y_limit, side):
    links=[]
    for edge in edges:
        if edge['vector_id'] in used_ids:
            continue
        if _distance(edge['a'],terminal)<=ADJACENCY_TOL_PT:
            other=edge['b']
        elif _distance(edge['b'],terminal)<=ADJACENCY_TOL_PT:
            other=edge['a']
        else:
            continue
        if side=='top' and other[1] < y_limit-OUTSIDE_EXTENSION_MIN_PT:
            links.append(edge['vector_id'])
        elif side=='bottom' and other[1] > y_limit+OUTSIDE_EXTENSION_MIN_PT:
            links.append(edge['vector_id'])
    return sorted(set(links))


def inspect_riser(candidate, edges):
    rails=sorted(candidate.get('rails',[]),key=lambda z:z['x_pt'])
    if len(rails)<2:
        return {'candidate_id':candidate.get('candidate_id'),'status':'insufficient_rails'}
    left, right=rails[0],rails[-1]
    evidence={}
    for name,field in [('top','y0_pt'),('bottom','y1_pt')]:
        p_left=(left['x_pt'],left[field])
        p_right=(right['x_pt'],right[field])
        inside=[(r['x_pt'],r[field]) for r in rails[1:-1]]
        options=_seam_path(p_left,p_right,edges,inside)
        chosen=options[0] if len(options)==1 else None
        if chosen:
            chosen={**chosen,
                    'left_endpoint_pt':[round(v,3) for v in p_left],
                    'right_endpoint_pt':[round(v,3) for v in p_right],
                    'seam_length_pt':round(chosen['length_pt'],4),
                    'outside_left_vector_ids':_outside_continuations(p_left,edges,set(chosen['vector_ids']),p_left[1],name),
                    'outside_right_vector_ids':_outside_continuations(p_right,edges,set(chosen['vector_ids']),p_right[1],name),
                    'physical_fitting_type_confirmed':False,
                    'physical_port_confirmed':False}
        if chosen:
            chosen.pop('length_pt',None)
        evidence[name]={
            'status':'unique_seam_candidate' if chosen else ('ambiguous_seam_paths' if len(options)>1 else 'seam_not_found'),
            'candidate_path_count':len(options),
            'seam':chosen,
        }
    both=all(evidence[k]['status']=='unique_seam_candidate' for k in ('top','bottom'))
    return {'candidate_id':candidate['candidate_id'],
            'original_status':candidate['status'],
            'top':evidence['top'],'bottom':evidence['bottom'],
            'top_and_bottom_drafting_seams':both,
            'status':'two_drafting_interface_candidates' if both else 'partial_or_unresolved_interface',
            'confirmed_physical_endpoints':False,
            'confirmed_section_mm':None,
            'confirmed_vertical_length_m':None,
            'approved_surface_m2':None,
            'requires_engineer_review':True}


def analyze_riser_interfaces(pdf_file,risers,leaders=None):
    if risers.get('source_pdf_filename') != Path(pdf_file).name:
        raise ValueError('Riser candidate PDF filename does not match source')
    with fitz.open(str(pdf_file)) as pdf:
        page=int(risers['pdf_page'])
        if page<1 or page>len(pdf):
            raise ValueError('PDF page out of range')
        roi=risers['region_pt']
        edges=colored_edges(pdf[page-1],roi)
    results=[inspect_riser(c,edges) for c in risers['riser_candidates']]
    if leaders is not None:
        if (leaders.get('pdf_page')!=risers.get('pdf_page') or
            [float(v) for v in leaders.get('region_pt',[])] != [float(v) for v in risers.get('region_pt',[])]):
            raise ValueError('Leader source page/ROI mismatch')
        if (not (leaders.get('scheme_title_evidence') or {}).get('verified') or
            (leaders.get('scheme')!=risers.get('system'))):
            raise ValueError('Leader system identity not independently verified')
    return {'source_pdf_filename':Path(pdf_file).name,'pdf_page':risers['pdf_page'],
            'region_pt':risers['region_pt'],'system':risers.get('system'),
            'summary':{'projected_riser_candidates':len(results),
                       'two_seam_candidates':sum(x['top_and_bottom_drafting_seams'] for x in results),
                       'approved_vertical_length_m':None,'approved_surface_m2':None},
            'riser_interface_candidates':results,
            'limitations':['A vector seam between rails is not a verified mechanical fitting connection',
                           'Curved elbow contours can be represented as many small line fragments',
                           'Top/bottom projected seam positions are not elevation endpoints',
                           'No conversion of PDF point lengths into physical meters or surface quantities']}


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('pdf');ap.add_argument('--risers',required=True)
    ap.add_argument('--leaders');ap.add_argument('--output')
    a=ap.parse_args()
    r=json.loads(Path(a.risers).read_text(encoding='utf-8'))
    l=json.loads(Path(a.leaders).read_text(encoding='utf-8')) if a.leaders else None
    output=json.dumps(analyze_riser_interfaces(a.pdf,r,l),ensure_ascii=False,indent=2)
    if a.output:Path(a.output).write_text(output,encoding='utf-8')
    else:print(output)

if __name__=='__main__':main()
