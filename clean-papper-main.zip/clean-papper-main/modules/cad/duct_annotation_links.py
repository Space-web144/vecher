"""Trace independent duct-size labels along CAD leader lines to duct walls/fittings.

A geometric association is a candidate, not approval of a W×H section or
automatic identification of all ducts in the same network.
"""
from __future__ import annotations

import argparse
from collections import defaultdict
import json
import math
from pathlib import Path

import ezdxf
from ezdxf import bbox

from duct_topology import build_topology
from duct_takeoff import METERS_PER_DXF_UNIT

LEADER_LAYER = "M-HVAC-DUCT-IDEN"
TEXT_ATTACH_TOL_MM = 170.0
JUNCTION_TOL_MM = 3.0
WALL_ATTACH_TOL_MM = 85.0
BLOCK_BOUNDARY_TOL_MM = 3.0
MAX_LEADER_LINES = 5


def _xy(v):
    return float(v.x), float(v.y)


def _ends(e):
    return _xy(e.dxf.start), _xy(e.dxf.end)


def _distance_to_text_rect(point, rect):
    x, y = point
    a, b = rect.extmin, rect.extmax
    return math.hypot(max(float(a.x) - x, 0, x - float(b.x)),
                      max(float(a.y) - y, 0, y - float(b.y)))


def _trace_leader(text, leaders, mm_per_unit):
    rect = bbox.extents([text], fast=True)
    if not rect.has_data:
        return {"status": "text_bbox_missing"}
    choices = sorted(
        (_distance_to_text_rect(point, rect) * mm_per_unit, e.dxf.handle, j)
        for e in leaders for j, point in enumerate(_ends(e))
    )
    if not choices or choices[0][0] > TEXT_ATTACH_TOL_MM:
        return {"status": "no_text_attached_leader"}
    within = [v for v in choices if v[0] <= TEXT_ATTACH_TOL_MM]
    if len({v[1] for v in within}) > 1:
        return {"status": "multiple_text_attached_leaders",
                "candidate_handles": sorted({v[1] for v in within})}
    _, handle, point_idx = choices[0]
    lookup = {e.dxf.handle: e for e in leaders}
    trail = [handle]
    tip = _ends(lookup[handle])[1 - point_idx]
    for _ in range(MAX_LEADER_LINES - 1):
        neighbors = sorted(
            (math.dist(tip, pt) * mm_per_unit, e.dxf.handle, j)
            for e in leaders if e.dxf.handle not in trail
            for j, pt in enumerate(_ends(e))
            if math.dist(tip, pt) * mm_per_unit <= JUNCTION_TOL_MM
        )
        nearby = {v[1] for v in neighbors}
        if not nearby:
            break
        if len(nearby) != 1:
            return {"status": "leader_branch_ambiguous", "leader_handles": trail}
        _, handle, j = neighbors[0]
        trail.append(handle)
        tip = _ends(lookup[handle])[1 - j]
    return {"status": "traced_leader", "leader_handles": trail,
            "leader_tip_xy_units": [round(x, 3) for x in tip]}


def _wall_candidates(tip, segments, mm_per_unit):
    result = []
    for s in segments:
        a, b = s["start_xy_units"], s["end_xy_units"]
        dx, dy = b[0] - a[0], b[1] - a[1]
        length = math.hypot(dx, dy)
        if length <= 0:
            continue
        px, py = tip[0] - a[0], tip[1] - a[1]
        t = (px * dx + py * dy) / length ** 2
        if not 0 <= t <= 1:
            continue
        center_mm = abs(px * dy - py * dx) / length * mm_per_unit
        error = abs(center_mm - float(s["plan_width_mm"]) / 2)
        if error <= WALL_ATTACH_TOL_MM:
            result.append({"segment_handle": s["handle"],
                           "wall_error_mm": round(error, 3),
                           "plan_width_mm": s["plan_width_mm"]})
    return result


def _single_port_fitting_candidates(tip, doc, topology, mm_per_unit):
    ports = defaultdict(list)
    for e in topology["endpoint_contacts"]:
        if (e["status"] == "single_face_match" and
                e["block_kind"] in ("elbow", "transition")):
            ports[e["block_handle"]].append(e)
    index = {e.dxf.handle: e for e in doc.modelspace()
             if e.dxftype() == "INSERT"}
    candidates = []
    tol = BLOCK_BOUNDARY_TOL_MM / mm_per_unit
    for handle, ends in ports.items():
        if len(ends) != 1 or handle not in index:
            continue
        rect = bbox.extents([index[handle]], fast=True)
        if not rect.has_data:
            continue
        x0, y0, x1, y1 = rect.extmin.x, rect.extmin.y, rect.extmax.x, rect.extmax.y
        if not (x0 - tol <= tip[0] <= x1 + tol and
                y0 - tol <= tip[1] <= y1 + tol):
            continue
        boundary_mm = min(abs(tip[0] - x0), abs(tip[0] - x1),
                          abs(tip[1] - y0), abs(tip[1] - y1)) * mm_per_unit
        if boundary_mm > BLOCK_BOUNDARY_TOL_MM:
            continue
        candidates.append({
            "segment_handle": ends[0]["segment_handle"],
            "block_handle": handle,
            "block_kind": ends[0]["block_kind"],
            "plan_width_mm": ends[0]["plan_width_mm"],
        })
    return candidates


def link_annotations(path, topology=None):
    topology = topology or build_topology(path)
    doc = ezdxf.readfile(str(path))
    mm_per_unit = METERS_PER_DXF_UNIT[int(doc.header["$INSUNITS"])] * 1000
    model = doc.modelspace()
    leaders = [e for e in model if e.dxftype() == "LINE"
               and e.dxf.layer == LEADER_LAYER]
    texts = {e.dxf.handle: e for e in model
             if e.dxftype() in ("TEXT", "MTEXT")}
    group_by_segment = {
        handle: group["component_id"]
        for group in topology["components"]
        for handle in group["segment_handles"]
    }
    labels = []
    for source in topology["size_annotations"]:
        label = dict(source)
        label.update({
            "link_status": "not_duct_section" if
                source["context"] == "fire_damper_product_label" else "unlinked",
            "candidate_component_id": None, "candidate_system": None,
            "evidence_method": None,
        })
        if source["context"] == "fire_damper_product_label":
            labels.append(label)
            continue
        leader = _trace_leader(texts[source["handle"]], leaders, mm_per_unit)
        label.update(leader)
        if leader["status"] != "traced_leader":
            label["link_status"] = leader["status"]
            labels.append(label)
            continue
        tip = leader["leader_tip_xy_units"]
        acceptable_widths = source["dimensions_mm"]
        wall = [
            c for c in _wall_candidates(tip, topology["segments"], mm_per_unit)
            if any(abs(c["plan_width_mm"] - w) <= 1 for w in acceptable_widths)
        ]
        fittings = [
            c for c in _single_port_fitting_candidates(tip, doc, topology,
                                                       mm_per_unit)
            if any(abs(c["plan_width_mm"] - w) <= 1 for w in acceptable_widths)
        ]
        matches = {
            c["segment_handle"]: ("single_port_fitting", c) for c in fittings
        }
        matches.update({
            c["segment_handle"]: ("duct_wall", c) for c in wall
        })
        label["segment_candidate_handles"] = sorted(matches)
        if len(matches) == 1:
            segment, (evidence, details) = next(iter(matches.items()))
            label.update({
                "linked_segment_handle": segment,
                "candidate_component_id": group_by_segment.get(segment),
                "link_status": "leader_to_candidate_segment",
                "evidence_method": evidence,
                "candidate_plan_width_mm": details["plan_width_mm"],
            })
        elif len(matches) > 1:
            label["link_status"] = "multiple_duct_candidates"
        else:
            label["link_status"] = "leader_tip_not_at_unique_duct"
        labels.append(label)

    # Only pair a system label with a size callout when they share a layer,
    # lie in the same local annotation region, and the size has a unique
    # leader. It is still only a candidate system for that component.
    systems = []
    for source in topology["system_annotations"]:
        item = dict(source)
        item["candidate_component_id"] = None
        item["context_status"] = "unassigned"
        if item["layer"] == "M-HVAC-DUCT-IDEN":
            nearby = [
                label for label in labels
                if label["context"] == "independent_size_label"
                and label.get("candidate_component_id")
                and label["layer"] == item["layer"]
                and 0 <= label["xy_units"][1] - item["baseline_y_units"]
                <= 450 / mm_per_unit
                and abs(label["xy_units"][0] -
                        item["first_fragment_x_units"]) <= 500 / mm_per_unit
            ]
            if len(nearby) == 1:
                target = nearby[0]
                item["candidate_component_id"] = target["candidate_component_id"]
                item["context_status"] = "same_annotation_context_candidate"
                item["section_label_handle"] = target["handle"]
                target["candidate_system"] = item["code"]
        systems.append(item)

    by_group = defaultdict(list)
    for label in labels:
        if label.get("candidate_component_id"):
            by_group[label["candidate_component_id"]].append(label)
    components = []
    for source in topology["components"]:
        cid = source["component_id"]
        matched = by_group[cid]
        sizes = sorted({tuple(z["dimensions_mm"]) for z in matched})
        status = ("unassigned" if not sizes else
                  "candidate_section_from_leader" if len(sizes) == 1
                  else "conflicting_size_callouts")
        components.append({
            **source,
            "candidate_section_mm": list(sizes[0]) if len(sizes) == 1 else None,
            "candidate_section_status": status,
            "section_callout_handles": [z["handle"] for z in matched],
            "candidate_systems": sorted({
                z["code"] for z in systems
                if z["candidate_component_id"] == cid
            }),
        })
    return {
        "source_file": Path(path).name,
        "summary": {
            **topology["summary"],
            "independent_labels_traced_to_one_segment": sum(
                z["link_status"] == "leader_to_candidate_segment" for z in labels),
            "independent_labels_unassigned": sum(
                z["context"] == "independent_size_label"
                and z["link_status"] != "leader_to_candidate_segment"
                for z in labels),
            "groups_with_consistent_section_candidates": sum(
                z["candidate_section_status"] == "candidate_section_from_leader"
                for z in components),
            "groups_without_confirmed_size_callout": sum(
                z["candidate_section_status"] == "unassigned"
                for z in components),
            "system_annotations_with_group_candidate": sum(
                z["context_status"] == "same_annotation_context_candidate"
                for z in systems),
        },
        "segments": topology["segments"],
        "components": components,
        "size_annotations": labels,
        "system_annotations": systems,
        "endpoint_contacts": topology["endpoint_contacts"],
        "connections": topology["connections"],
        "review": topology["review"] + [
            {"category": "size_label_review", "handle": z["handle"],
             "status": z["link_status"]}
            for z in labels if z["context"] == "independent_size_label"
            and z["link_status"] != "leader_to_candidate_segment"
        ],
        "limitations": topology["limitations"] + [
            "Leader links are section candidates, not approved dimensions.",
            "Candidate sizes are never auto-propagated to other segments.",
            "Nearby system labels are context evidence, not verified MEP membership.",
        ],
    }


def main():
    parser = argparse.ArgumentParser(
        description="Leader-line links to candidate duct geometry"
    )
    parser.add_argument("dxf")
    parser.add_argument("--output")
    args = parser.parse_args()
    payload = json.dumps(link_annotations(args.dxf), ensure_ascii=False, indent=2)
    if args.output:
        Path(args.output).write_text(payload, encoding="utf-8")
    else:
        print(payload)


if __name__ == "__main__":
    main()
