# CAD adapter

Current:
- preflight.py — read-only DWG/DXF header and inventory; supports AC1032 identification, but **not** DWG entity decoding.
- dxf_segments.py — preliminary raw geometry lengths for explicit DXF layers. A sum of line lengths is not a verified duct centerline measurement.

Examples:
  python modules/cad/preflight.py path/to/unpacked/dwg/folder
  python modules/cad/dxf_segments.py drawing.dxf --layer SELECTED_VENT_LAYER --output observations.json

DXF input requires ezdxf, and should preserve original drawing units. Closed outlines, hatches and unconfirmed curves must not be treated as duct length. For DWG use an approved AutoCAD/ODA conversion before processing.
