"""Conservative DXF duct connections from centerline ends to block boundaries.

Contacts and connected groups are geometric hypotheses, not proof of complete
MEP networks. Product-code dimensions for fire dampers are kept separate.
"""
from __future__ import annotations

from collections import defaultdict
import argparse
import json
import math
from pathlib import Path
import re

import ezdxf
from ezdxf import bbox

from duct_takeoff import (DEFAULT_CENTER_LAYER, DEFAULT_OUTLINE_LAYER,
                          _endpoints, classify_block, examine_dxf)

BOUNDS_TOL_MM = 1.5
CROSS_AXIS_TOL_MM = 2.0
SAME_WIDTH_TOL_MM = 1.0
CONNECTED_KINDS = {"elbow", "transition", "fire_damper"}
SIZE_RX = re.compile(r"(?<!\d)(\d{2,4})\s*[xх×]\s*(\d{2,4})(?!\d)", re.I)
ESCAPED_UNICODE_RX = re.compile(r"\\U\+([0-9A-Fa-f]{4})")
SYSTEM_RX = re.compile(r"\b(?:ДВ|ДП|В|П)\s*\d+(?:\.\d+)?-\d+\b", re.I)


def plain_text(s):
    """Decode Revit-style escaped Unicode in DXF MTEXT."""
    return ESCAPED_UNICODE_RX.sub(lambda m: chr(int(m.group(1), 16)), str(s))


def _rectangles(model, include_layers):
    """Use expanded block geometry rather than unreliable INSERT coordinates."""
    result = {}
    for e in model:
        if e.dxftype() != "INSERT" or e.dxf.layer not in include_layers:
            continue
        kind = classify_block(e.dxf.name, e.dxf.layer)
        if kind is None:
            continue
        box = bbox.extents([e], fast=True)
        if not box.has_data:
            continue
        a, b = box.extmin, box.extmax
        if not all(math.isfinite(v) for v in (a.x, a.y, b.x, b.y)):
            continue
        result[e.dxf.handle] = {
            "handle": e.dxf.handle, "kind": kind,
            "bbox_units": [float(a.x), float(a.y), float(b.x), float(b.y)],
        }
    return result


def _face_contact(point, axis, block, mm_per_unit):
    x, y = point
    x0, y0, x1, y1 = block["bbox_units"]
    tol = BOUNDS_TOL_MM / mm_per_unit
    cross_tol = CROSS_AXIS_TOL_MM / mm_per_unit
    if axis == "horizontal":
        if not y0 - cross_tol <= y <= y1 + cross_tol:
            return None
        choices = [(abs(x - x0), "min_x"), (abs(x - x1), "max_x")]
    else:
        if not x0 - cross_tol <= x <= x1 + cross_tol:
            return None
        choices = [(abs(y - y0), "min_y"), (abs(y - y1), "max_y")]
    error, face = min(choices)
    return (round(error * mm_per_unit, 3), face) if error <= tol else None


def _axis(a, b, mm_per_unit):
    dx, dy = abs(b[0] - a[0]) * mm_per_unit, abs(b[1] - a[1]) * mm_per_unit
    if dy <= BOUNDS_TOL_MM and dx > BOUNDS_TOL_MM:
        return "horizontal"
    if dx <= BOUNDS_TOL_MM and dy > BOUNDS_TOL_MM:
        return "vertical"
    return None


def _invalid_pair(kind, p, q):
    if p["segment_handle"] == q["segment_handle"]:
        return "same_centerline"
    a, b = p["face"], q["face"]
    wa, wb = p["plan_width_mm"], q["plan_width_mm"]
    if kind == "elbow":
        if a[-1] == b[-1]:
            return "elbow_faces_not_perpendicular"
        if abs(wa - wb) > SAME_WIDTH_TOL_MM:
            return "elbow_width_conflict"
        return None
    if kind in {"fire_damper", "transition"}:
        if {a, b} not in ({"min_x", "max_x"}, {"min_y", "max_y"}):
            return "through_faces_not_opposite"
        if kind == "fire_damper" and abs(wa - wb) > SAME_WIDTH_TOL_MM:
            return "damper_width_conflict"
        return None
    return "unsupported_block_kind"


def _classify_labels(model):
    """Group fragmented MTEXT by layer and baseline.

    Fire damper product-code sizes must not be silently assigned to ducts.
    Other labels remain independent size observations, not confirmed sections.
    """
    rows = defaultdict(list)
    layers = {"M-HVAC-DUCT-IDEN", "M-EQPM-IDEN", "M-HVAC-CDFF-IDEN"}
    for e in model:
        if e.dxftype() not in ("TEXT", "MTEXT") or e.dxf.layer not in layers:
            continue
        s = plain_text(e.plain_text() if e.dxftype() == "MTEXT" else e.dxf.text)
        p = e.dxf.insert
        rows[(e.dxf.layer, round(float(p.y)))].append(
            (float(p.x), e.dxf.handle, s, (float(p.x), float(p.y)))
        )
    labels, systems = [], []
    for (layer, _), chunks in rows.items():
        chunks.sort()
        joined = "".join(z[2] for z in chunks)
        product_code = "КПВ" in joined.upper()
        for _, handle, value, xy in chunks:
            for m in SIZE_RX.finditer(value):
                labels.append({
                    "handle": handle, "layer": layer, "text": m.group(0),
                    "dimensions_mm": [int(m.group(1)), int(m.group(2))],
                    "xy_units": [round(xy[0], 3), round(xy[1], 3)],
                    "context": "fire_damper_product_label" if product_code
                               else "independent_size_label",
                    "linked_segment_handle": None,
                })
        for m in SYSTEM_RX.finditer(joined):
            systems.append({
                "code": re.sub(r"\s+", "", m.group(0)).upper(),
                "layer": layer,
                "baseline_y_units": round(chunks[0][3][1], 3),
                "first_fragment_x_units": round(chunks[0][3][0], 3),
                "first_fragment_handle": chunks[0][1],
                "linked_component_id": None,
            })
    return labels, systems


def build_topology(path, center_layer=DEFAULT_CENTER_LAYER,
                   duct_layer=DEFAULT_OUTLINE_LAYER):
    base = examine_dxf(path, center_layer, duct_layer)
    doc = ezdxf.readfile(str(path))
    mm_per_unit = base["meters_per_unit"] * 1000
    model = doc.modelspace()
    blocks = _rectangles(model, {duct_layer, "M-EQPM", "M-HVAC-CDFF"})
    lines = {e.dxf.handle: e for e in model
             if e.dxftype() == "LINE" and e.dxf.layer == center_layer}
    by_block = defaultdict(list)
    endpoints = []
    for seg in base["segments"]:
        a, b = _endpoints(lines[seg["handle"]])
        axis = _axis(a, b, mm_per_unit)
        for j, pt in enumerate((a, b)):
            choices = []
            if axis:
                for block in blocks.values():
                    match = _face_contact(pt, axis, block, mm_per_unit)
                    if match:
                        choices.append((match[0], block["handle"], match[1], block["kind"]))
            choices.sort()
            item = {
                "segment_handle": seg["handle"],
                "endpoint": "start" if j == 0 else "end",
                "xy_units": [round(pt[0], 3), round(pt[1], 3)],
                "plan_width_mm": seg["plan_width_mm"],
                "block_handle": None, "block_kind": None, "face": None,
                "status": "unmatched",
                "candidate_block_handles": [v[1] for v in choices],
            }
            if axis is None:
                item["status"] = "non_axial_centerline_not_supported"
            elif len(choices) == 1:
                error, handle, face, kind = choices[0]
                item.update({
                    "block_handle": handle, "block_kind": kind,
                    "face": face, "face_error_mm": error,
                    "status": "single_face_match",
                })
                by_block[handle].append(item)
            elif len(choices) > 1:
                item["status"] = "ambiguous_multiple_blocks"
            endpoints.append(item)

    connections, rejected = [], []
    for handle, ports in sorted(by_block.items()):
        kind = blocks[handle]["kind"]
        if len(ports) != 2 or kind not in CONNECTED_KINDS:
            continue
        reason = _invalid_pair(kind, ports[0], ports[1])
        item = {
            "block_handle": handle, "kind": kind,
            "segment_handles": sorted((ports[0]["segment_handle"],
                                        ports[1]["segment_handle"])),
            "port_faces": [ports[0]["face"], ports[1]["face"]],
        }
        if reason:
            rejected.append({**item, "reason": reason})
        else:
            connections.append({**item, "status": "two_verified_boundary_contacts"})

    parents = {s["handle"]: s["handle"] for s in base["segments"]}
    def root(k):
        while parents[k] != k:
            parents[k] = parents[parents[k]]
            k = parents[k]
        return k
    for conn in connections:
        a, b = conn["segment_handles"]
        ra, rb = root(a), root(b)
        if ra != rb:
            parents[max(ra, rb)] = min(ra, rb)
    groups = defaultdict(list)
    for seg in base["segments"]:
        groups[root(seg["handle"])].append(seg)
    components = []
    for i, group in enumerate(sorted(groups.values(),
                                      key=lambda v: min(s["handle"] for s in v)), 1):
        components.append({
            "component_id": f"G{i:02d}",
            "segment_handles": sorted(s["handle"] for s in group),
            "straight_length_m": round(sum(s["length_m"] for s in group), 6),
            "plan_widths_mm": sorted(set(s["plan_width_mm"] for s in group)),
            "system": None, "full_section": None,
            "status": "geometric_partial_component_only",
        })
    labels, systems = _classify_labels(model)
    review = [
        {
            "category": "unmatched_endpoint",
            "handle": p["segment_handle"],
            "endpoint": p["endpoint"], "details": p["xy_units"],
        }
        for p in endpoints if p["status"] != "single_face_match"
    ]
    review.extend({"category": "fitting_port_conflict", **v} for v in rejected)
    return {
        "source_file": Path(path).name,
        "summary": {
            "straight_segment_count": len(base["segments"]),
            "verified_partial_straight_length_m": base["summary"]["partial_straight_length_m"],
            "centerline_endpoints": len(endpoints),
            "single_block_face_contacts": sum(x["status"] == "single_face_match"
                                               for x in endpoints),
            "unmatched_or_ambiguous_endpoints": sum(x["status"] != "single_face_match"
                                                    for x in endpoints),
            "through_fitting_connections": len(connections),
            "rejected_possible_connections": len(rejected),
            "disconnected_straight_groups": len(components),
            "fire_damper_size_annotations": sum(x["context"] ==
                        "fire_damper_product_label" for x in labels),
            "independent_size_annotations": sum(x["context"] ==
                        "independent_size_label" for x in labels),
            "unassigned_system_annotations": len(systems),
        },
        "segments": base["segments"],
        "block_candidates": base["block_candidates"],
        "endpoint_contacts": endpoints,
        "connections": connections,
        "rejected_connections": rejected,
        "components": components,
        "size_annotations": labels,
        "system_annotations": systems,
        "review": review,
        "limitations": [
            "Connections are based on block bounding faces, not MEP ports.",
            "Partial groups are not verified systems or complete duct networks.",
            "Grilles and equipment never join segments automatically.",
            "No fitting length is added to the straight duct total.",
            "Fire damper product label dimensions do not establish duct sections.",
        ],
    }


def main():
    p = argparse.ArgumentParser(description="Conservative DXF duct topology")
    p.add_argument("dxf")
    p.add_argument("--output")
    args = p.parse_args()
    content = json.dumps(build_topology(args.dxf), ensure_ascii=False, indent=2)
    if args.output:
        Path(args.output).write_text(content, encoding="utf-8")
    else:
        print(content)


if __name__ == "__main__":
    main()
