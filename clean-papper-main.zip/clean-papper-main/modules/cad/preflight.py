"""Read-only inventory of DWG/DXF drawing files.

Not a DWG geometry decoder. DWG geometry requires an appropriate CAD converter
or Autodesk SDK. Never claim lengths from the DWG file header.
"""
from __future__ import annotations
import argparse
import json
import re
from pathlib import Path
from typing import Any

DWG_RELEASES = {
    "AC1015": "AutoCAD 2000", "AC1018": "AutoCAD 2004",
    "AC1021": "AutoCAD 2007", "AC1024": "AutoCAD 2010",
    "AC1027": "AutoCAD 2013", "AC1032": "AutoCAD 2018",
}

def probe_file(path: str | Path) -> dict[str, Any]:
    path = Path(path)
    with path.open("rb") as handle:
        signature = handle.read(8)
    fmt = "DWG" if signature[:2] == b"AC" else "DXF" if path.suffix.lower() == ".dxf" else "unknown"
    version = signature[:6].decode("ascii", errors="replace") if fmt == "DWG" else None
    match = re.search(r"Лист\s*[-–]\s*(\d+)\s*[-–]", path.name)
    return {
        "file": path.name,
        "format": fmt,
        "dwg_signature": version,
        "format_family": DWG_RELEASES.get(version, "unknown") if version else None,
        "sheet": int(match.group(1)) if match else None,
        "size_bytes": path.stat().st_size,
        "geometry_readable": fmt == "DXF",
        "status": "requires_dwg_to_dxf_conversion" if fmt == "DWG" else "geometry_adapter_available" if fmt == "DXF" else "unsupported",
    }

def inventory(directory: str | Path) -> dict[str, Any]:
    directory = Path(directory)
    items = [probe_file(p) for p in sorted(directory.rglob("*")) if p.is_file() and p.suffix.lower() in (".dwg", ".dxf")]
    sheets = {x["sheet"] for x in items if x["sheet"] is not None}
    return {"files": items, "summary": {
        "count": len(items),
        "dwg": sum(x["format"] == "DWG" for x in items),
        "dxf": sum(x["format"] == "DXF" for x in items),
        "named_sheets": sorted(sheets),
        "note": "This is file preflight, not ventilation quantity takeoff.",
    }}

def main():
    parser = argparse.ArgumentParser(description="Inspect DWG/DXF version and file inventory (not quantities)")
    parser.add_argument("path", help="Directory or DWG/DXF file")
    parser.add_argument("--output", help="Optional JSON output file")
    args = parser.parse_args()
    p = Path(args.path)
    result = inventory(p) if p.is_dir() else probe_file(p)
    payload = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        Path(args.output).write_text(payload, encoding="utf-8")
    else:
        print(payload)

if __name__ == "__main__":
    main()
