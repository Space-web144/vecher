"""Trace provisional straight-duct continuity through explicit CAD fan/transition contacts.

Only measurable block-face contacts + existing centerline-to-transition contacts
are accepted. This is a geometric hypothesis, NOT HVAC connectivity approval.
No fitting/fan length is included in quantities.
"""
from __future__ import annotations
import argparse
import json
import math
import re
from collections import defaultdict
from pathlib import Path
from typing import Any
import ezdxf
from ezdxf import bbox

DUCT = 'M-HVAC-DUCT'
EQUIPMENT = 'M-EQPM'
EQUIPMENT_LABELS = 'M-EQPM-IDEN'
_FACE_TOL_MM = 1.5
_FACE_OVERLAP_RATIO = 0.94
_TEXT_SHIFT_MIN_MM = 120
_TEXT_SHIFT_MAX_MM = 700
_SYSTEM_RX = re.compile(r'\b(?:ДП|ДВ|П|В)\s*\d+(?:[.,]\d+)?\s*-\s*\d+\b', re.I)
_UNIT_MM = {1:25.4,2:304.8,4:1.,5:10.,6:1000.}
_UNICODE_RX = re.compile(r'\\U\+([0-9a-fA-F]{4})')

def _text(s):
    return _UNICODE_RX.sub(lambda m:chr(int(m.group(1),16)),s).replace('\\P',' ')

def _rectangle(e, cache):
    box = bbox.extents([e], fast=True, cache=cache)
    if not box.has_data: return None
    x0,y0,x1,y1 = box.extmin.x,box.extmin.y,box.extmax.x,box.extmax.y
    if not all(math.isfinite(v) for v in (x0,y0,x1,y1)):return None
    return (x0,y0,x1,y1)

def _face_candidates(transition, fan, mm_per_unit):
    a0,b0,a1,b1 = transition
    c0,d0,c1,d1 = fan
    tol=_FACE_TOL_MM/mm_per_unit
    cases=[('min_x','max_x',a0-c1,b0,b1,d0,d1),
           ('max_x','min_x',a1-c0,b0,b1,d0,d1),
           ('min_y','max_y',b0-d1,a0,a1,c0,c1),
           ('max_y','min_y',b1-d0,a0,a1,c0,c1)]
    out=[]
    for face_t,face_f,dist,p0,p1,q0,q1 in cases:
        overlap = min(p1,q1)-max(p0,q0)
        span=min(p1-p0,q1-q0)
        center_delta=abs((p0+p1-q0-q1)/2)*mm_per_unit
        if span<=0:continue
        if abs(dist)<=tol and overlap/span >=_FACE_OVERLAP_RATIO and center_delta<=100:
            # Concentric fan/transition bounding-face spans may differ; this is only a geometry candidate.
            out.append({'transition_face':face_t,'fan_face':face_f,
                        'face_gap_mm':round(dist*mm_per_unit,4),
                        'overlap_fraction':round(overlap/span,4)})
    return out

def _other_face(face):
    return {'min_x':'max_x','max_x':'min_x','min_y':'max_y','max_y':'min_y'}[face]

def _on_rectangle_boundary(point, rect, tol):
    x,y=point; x0,y0,x1,y1=rect
    if x0-tol<=x<=x1+tol and (abs(y-y0)<=tol or abs(y-y1)<=tol):return True
    if y0-tol<=y<=y1+tol and (abs(x-x0)<=tol or abs(x-x1)<=tol):return True
    return False

def _system_shelves(model, rects, scale):
    """Match system-name shelf INSERTs to their MTEXT and LINE fan leaders."""
    out=[]
    text_entities=[e for e in model if e.dxftype() in ('TEXT','MTEXT') and e.dxf.layer==EQUIPMENT_LABELS]
    lines=[e for e in model.query('LINE') if e.dxf.layer==EQUIPMENT_LABELS]
    for shelf in model.query('INSERT'):
        if shelf.dxf.layer!=EQUIPMENT_LABELS or 'имя системы' not in _text(shelf.dxf.name).lower():continue
        rect=rects.get(shelf.dxf.handle)
        if rect is None:continue
        x0,y0,x1,y1=rect
        matches=[]
        for t in text_entities:
            p=t.dxf.insert
            if x0-2/scale<=p.x<=x1+2/scale and _TEXT_SHIFT_MIN_MM/scale < p.y-y0 < _TEXT_SHIFT_MAX_MM/scale:
                matches.append(t)
        if not matches:continue
        matches.sort(key=lambda t:t.dxf.insert.x)
        joined=''.join(_text(t.plain_text() if t.dxftype()=='MTEXT' else t.dxf.text) for t in matches)
        codes={re.sub(r'\s+','',m.group(0)).replace(',','.').upper() for m in _SYSTEM_RX.finditer(joined)}
        if len(codes)!=1:continue
        links=[]
        tol=2/scale
        def near(p,q):return math.dist(p,q)<=tol
        segments=[(e.dxf.handle, (e.dxf.start.x,e.dxf.start.y),
                   (e.dxf.end.x,e.dxf.end.y)) for e in lines]
        beginnings=[]
        for handle,a,b in segments:
            for shelf_end,other in ((a,b),(b,a)):
                if abs(shelf_end[1]-y0)<=tol and min(abs(shelf_end[0]-x0),abs(shelf_end[0]-x1))<=tol:
                    beginnings.append((handle,other,(handle,)))
        for handle,point,path in beginnings:
            frontier=[(point,path)]
            while frontier:
                remote,used=frontier.pop()
                fanmatches=[fid for fid,fr in rects.items()
                            if fid.startswith('FAN:') and _on_rectangle_boundary(remote,fr,tol)]
                if len(fanmatches)==1:links.append((fanmatches[0][4:],used[0]))
                if len(used)>=3:continue
                for nxt,a,b in segments:
                    if nxt in used:continue
                    if near(remote,a):frontier.append((b,used+(nxt,)))
                    elif near(remote,b):frontier.append((a,used+(nxt,)))
        unique={(h,l) for h,l in links}
        if len(unique)==1:
            fan,leader=next(iter(unique))
            out.append({'system':next(iter(codes)), 'fan_handle':fan,
                        'system_shelf_handle':shelf.dxf.handle,
                        'system_text_handles':[t.dxf.handle for t in matches],
                        'leader_handle':leader,
                        'evidence':'unique_shelf_text_and_leader_to_fan_bbox'})
    return sorted(out,key=lambda x:x['fan_handle'])

def analyze_equipment_bridges(dxf_path: str|Path, topology:dict[str,Any]):
    doc=ezdxf.readfile(str(dxf_path))
    unit_code=int(doc.header.get('$INSUNITS',0))
    if unit_code not in _UNIT_MM:
        raise ValueError(f'Unknown DXF drawing units: $INSUNITS={unit_code}')
    scale=_UNIT_MM[unit_code]
    m=doc.modelspace()
    cache=bbox.Cache()
    transitions={};fans={};shelfrects={}
    for e in m.query('INSERT'):
        name=_text(e.dxf.name).casefold()
        if (e.dxf.layer==DUCT and 'переход' in name) or (e.dxf.layer==EQUIPMENT and 'вентилятор' in name):
            r=_rectangle(e,cache)
            if r is None:continue
            (transitions if e.dxf.layer==DUCT else fans)[e.dxf.handle]=r
            if e.dxf.layer==EQUIPMENT:shelfrects['FAN:'+e.dxf.handle]=r
        elif e.dxf.layer==EQUIPMENT_LABELS and 'имя системы' in name:
            r=_rectangle(e,cache)
            if r is not None:shelfrects[e.dxf.handle]=r
    contacts=defaultdict(list)
    for e in topology['endpoint_contacts']:
        if e.get('status')=='single_face_match' and e.get('block_handle'):
            contacts[e['block_handle']].append(e)
    member={h:c['component_id'] for c in topology['components'] for h in c['segment_handles']}
    face_touch=[];rejected=[]
    by_fan=defaultdict(list)
    for trans_handle,trans_rect in transitions.items():
        for fan_handle,fan_rect in fans.items():
            faces=_face_candidates(trans_rect,fan_rect,scale)
            for f in faces:
                record={'fan_handle':fan_handle,'transition_handle':trans_handle,**f}
                ports=contacts.get(trans_handle,[])
                if len(ports)!=1:
                    rejected.append({**record,'reason':'transition_centerline_port_count_not_one','ports':len(ports)})
                    continue
                port=ports[0]
                if port.get('face')!=_other_face(f['transition_face']):
                    rejected.append({**record,'reason':'segment_not_on_opposite_transition_face',
                                     'segment_face':port.get('face')})
                    continue
                seg=port['segment_handle']
                if seg not in member:
                    rejected.append({**record,'reason':'segment_missing_from_components'})
                    continue
                record.update({'segment_handle':seg,'component_id':member[seg],
                               'segment_port_face':port['face'],
                               'status':'transition_fan_face_geometry_candidate'})
                face_touch.append(record)
    fans_per_transition=defaultdict(set)
    for record in face_touch:
        fans_per_transition[record['transition_handle']].add(record['fan_handle'])
    valid_touches=[]
    for record in face_touch:
        if len(fans_per_transition[record['transition_handle']])>1:
            rejected.append({**record,'reason':'transition_touches_multiple_fans'})
            continue
        valid_touches.append(record)
        by_fan[record['fan_handle']].append(record)
    face_touch=valid_touches
    bridges=[]
    for fan, ports in by_fan.items():
        if len(ports)!=2:
            rejected.append({'fan_handle':fan,'reason':'fan_not_exactly_two_unique_transition_contacts',
                             'touches':len(ports)})
            continue
        left,right=sorted(ports,key=lambda p:p['fan_face'])
        if right['fan_face'] !=_other_face(left['fan_face']):
            rejected.append({'fan_handle':fan,'reason':'fan_faces_not_opposite',
                             'faces':[left['fan_face'],right['fan_face']]})
            continue
        if left['component_id']==right['component_id']:
            rejected.append({'fan_handle':fan,'reason':'already_same_straight_group'})
            continue
        bridges.append({'fan_handle':fan,
                        'transition_handles':[left['transition_handle'],right['transition_handle']],
                        'segment_handles':[left['segment_handle'],right['segment_handle']],
                        'component_ids':sorted([left['component_id'],right['component_id']]),
                        'fan_faces':[left['fan_face'],right['fan_face']],
                        'status':'candidate_via_two_transition_faces',
                        'approval_required':True})
    bridges.sort(key=lambda p:p['fan_handle'])
    systems=_system_shelves(m,shelfrects,scale)
    sysbyfan=defaultdict(set)
    for s in systems:sysbyfan[s['fan_handle']].add(s['system'])
    for b in bridges:
        codes=sysbyfan.get(b['fan_handle'],set())
        if len(codes)==1:
            b['candidate_system']=next(iter(codes))
            b['system_evidence']='equipment_system_label_leader'
        else:
            b['candidate_system']=None
            b['system_evidence']='not_identified_or_ambiguous'
    parent={c['component_id']:c['component_id'] for c in topology['components']}
    def root(x):
        while parent[x]!=x:
            parent[x]=parent[parent[x]];x=parent[x]
        return x
    for b in bridges:
        a,c=b['component_ids'];a=root(a);c=root(c)
        if a!=c:parent[max(a,c)]=min(a,c)
    groups=defaultdict(list)
    for cid in parent:groups[root(cid)].append(cid)
    networks=[]
    for idx,members in enumerate(sorted(groups.values(),key=lambda m:min(m)),1):
        attached=[b for b in bridges if any(v in members for v in b['component_ids'])]
        codes={b['candidate_system'] for b in attached if b['candidate_system']}
        networks.append({'network_candidate_id':f'N{idx:02}',
                         'component_ids':sorted(members),
                         'fan_handles':sorted({b['fan_handle'] for b in attached}),
                         'candidate_system':next(iter(codes)) if len(codes)==1 else None,
                         'system_status':'unique_label_candidate' if len(codes)==1 else
                                         'multiple_conflicting_labels' if len(codes)>1 else 'unassigned',
                         'status':'geometric_network_candidate_only',
                         'approval_required':True})
    return {'source_file':Path(dxf_path).name,
            'summary':{'fan_blocks':len(fans),
                       'transition_blocks':len(transitions),
                       'transition_fan_face_contacts':len(face_touch),
                       'fan_bridges':len(bridges),
                       'initial_straight_groups':len(topology['components']),
                       'provisional_groups_after_fan_bridges':len(networks),
                       'systems_with_direct_label_evidence':len(systems),
                       'verified_additional_duct_length_m':0},
            'face_contacts':face_touch,
            'bridge_candidates':bridges,
            'system_label_evidence':systems,
            'provisional_networks':networks,
            'rejected_contacts':rejected,
            'limitations':[
                'Bounding-box face adjacency is NOT verified mechanical connection or port geometry.',
                'Only fan-between-two-transition bridges are considered; fittings-to-fittings are not inferred.',
                'System codes from explicit equipment label leader lines are candidates only.',
                'No fan, transition, bend, or vertical length has been added to quantities.',
                'Competing contacts or non-opposite faces are rejected, not forced.',
            ]}

def main():
    p=argparse.ArgumentParser(description='Read-only fan/transition network hypotheses from DXF and topology JSON')
    p.add_argument('dxf')
    p.add_argument('--topology',required=True)
    p.add_argument('--output')
    args=p.parse_args()
    topology=json.loads(Path(args.topology).read_text(encoding='utf-8'))
    output=json.dumps(analyze_equipment_bridges(args.dxf,topology),ensure_ascii=False,indent=2)
    if args.output:Path(args.output).write_text(output,encoding='utf-8')
    else:print(output)
if __name__=='__main__':main()
