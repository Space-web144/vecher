"""Classify non-connected straight duct endpoints using direct CAD evidence.

This module does not manufacture connections or include fitting lengths.
Termination evidence differs from completed ventilation quantities.
"""
from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
from typing import Any

import ezdxf
from ezdxf import bbox

DUCT_LAYER = "M-HVAC-DUCT"
WALL_VALVE_WORDS = ("клапан", "стеновой")
MAX_WALL_FACE_DEPTH_MM = 60.0
BOUNDARY_TOL_MM = 1.0
WIDTH_TOL_MM = 2.0


def _point_rect_inside(x: float, y: float, box) -> bool:
    return box.extmin.x <= x <= box.extmax.x and box.extmin.y <= y <= box.extmax.y


def _xy(vec):
    return float(vec.x), float(vec.y)


def _near_wall_valves(point, model, factor_mm_per_unit):
    x, y = point
    candidates = []
    for insert in model.query("INSERT"):
        if insert.dxf.layer != DUCT_LAYER:
            continue
        name = insert.dxf.name.casefold()
        if not all(word in name for word in WALL_VALVE_WORDS):
            continue
        rect = bbox.extents([insert], fast=True)
        if not rect.has_data or not _point_rect_inside(x, y, rect):
            continue
        depth_mm = min(x - rect.extmin.x, rect.extmax.x - x,
                       y - rect.extmin.y, rect.extmax.y - y) * factor_mm_per_unit
        if depth_mm <= MAX_WALL_FACE_DEPTH_MM:
            candidates.append({
                "handle": insert.dxf.handle,
                "depth_from_outer_bbox_mm": round(depth_mm, 3),
                "block_type": "wall_mounted_fire_damper",
            })
    return sorted(candidates, key=lambda c: (c["depth_from_outer_bbox_mm"], c["handle"]))


def _transverse_endlines(point, start, end, width_mm, model, scale):
    x, y = point
    sx, sy = start
    ex, ey = end
    axis_x, axis_y = ex - sx, ey - sy
    norm = math.hypot(axis_x, axis_y)
    if norm <= 1e-9:
        return []
    axis_x /= norm
    axis_y /= norm
    candidates = []
    for ln in model.query("LINE"):
        if ln.dxf.layer != DUCT_LAYER:
            continue
        a, b = _xy(ln.dxf.start), _xy(ln.dxf.end)
        dx, dy = b[0] - a[0], b[1] - a[1]
        length = math.hypot(dx, dy)
        if length < 1e-9 or abs(length * scale - width_mm) > WIDTH_TOL_MM:
            continue
        # A transverse line runs orthogonally through the centerline endpoint.
        if abs((dx * axis_x + dy * axis_y) / length) > .005:
            continue
        mx, my = (a[0] + b[0]) / 2, (a[1] + b[1]) / 2
        deviation = math.hypot(mx - x, my - y) * scale
        if deviation <= BOUNDARY_TOL_MM:
            candidates.append({"handle": ln.dxf.handle,
                               "midpoint_error_mm": round(deviation, 3),
                               "line_width_mm": round(length * scale, 3)})
    return sorted(candidates, key=lambda v: (v["midpoint_error_mm"], v["handle"]))


def classify_endpoint(point, other, width_mm, model, scale):
    """Return explicit type and evidence; never claim a physical endcap exists."""
    valves = _near_wall_valves(point, model, scale)
    boundaries = _transverse_endlines(point, other, point, width_mm, model, scale)
    evidence = {"point_xy_units": [round(z, 3) for z in point],
                "wall_valve_candidates": valves,
                "transverse_boundary_candidates": boundaries}
    if len(valves) == 1:
        evidence.update({"interpretation": "within_wall_damper_bbox",
                         "reference_handle": valves[0]["handle"],
                         "review_required": True})
    elif len(valves) > 1:
        evidence.update({"interpretation": "ambiguous_wall_damper_overlap",
                         "reference_handle": None,
                         "review_required": True})
    elif len(boundaries) == 1:
        evidence.update({"interpretation": "transverse_duct_end_boundary",
                         "reference_handle": boundaries[0]["handle"],
                         "review_required": True})
    elif len(boundaries) > 1:
        evidence.update({"interpretation": "multiple_transverse_boundaries",
                         "reference_handle": None,
                         "review_required": True})
    else:
        evidence.update({"interpretation": "no_explanation",
                         "reference_handle": None,
                         "review_required": True})
    return evidence


def explain_unmatched(dxf_file, topology: dict[str, Any]):
    drawing = ezdxf.readfile(str(dxf_file))
    units = int(drawing.header.get("$INSUNITS", 0))
    scales = {1:25.4, 2:304.8, 4:1.0, 5:10.0, 6:1000.0}
    if units not in scales:
        raise ValueError(f"Cannot measure endpoint evidence with $INSUNITS={units}")
    model = drawing.modelspace()
    scale = scales[units]
    line_index = {ln.dxf.handle: ln for ln in model.query("LINE")}
    result = []
    for contact in topology["endpoint_contacts"]:
        if contact.get("status") == "single_face_match":
            continue
        line = line_index.get(contact["segment_handle"])
        if line is None:
            result.append({"segment_handle": contact["segment_handle"],
                           "endpoint": contact["endpoint"],
                           "interpretation": "missing_line", "review_required": True})
            continue
        ends = [_xy(line.dxf.start), _xy(line.dxf.end)]
        which = 0 if contact["endpoint"] == "start" else 1
        evidence = classify_endpoint(ends[which], ends[1 - which],
                                     float(contact["plan_width_mm"]), model, scale)
        evidence.update({"segment_handle": contact["segment_handle"],
                         "endpoint": contact["endpoint"],
                         "initial_contact_status": contact["status"]})
        result.append(evidence)
    return {"file": Path(dxf_file).name,
            "summary": {"unmatched_endpoints_examined": len(result),
                        "explained_with_cad_evidence": sum(v["interpretation"]
                           in {"within_wall_damper_bbox", "transverse_duct_end_boundary"}
                           for v in result),
                        "all_require_review": True},
            "endpoint_evidence": result}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("dxf")
    p.add_argument("--topology", required=True, help="Topology JSON created by duct_topology.py")
    p.add_argument("--output")
    args = p.parse_args()
    top = json.loads(Path(args.topology).read_text(encoding="utf-8"))
    payload = json.dumps(explain_unmatched(args.dxf, top), ensure_ascii=False, indent=2)
    if args.output:
        Path(args.output).write_text(payload, encoding="utf-8")
    else:
        print(payload)


if __name__ == "__main__":
    main()
