"""Conservative, traceable partial duct takeoff from a DXF drawing.

Measure only explicit duct centerlines which have a symmetric pair of
matching, parallel duct outlines. Block instances and annotation labels are
reported separately. This does not replace a complete ventilation estimate:
heights, systems, elbows, verticals and fitting dimensions require review.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import json
import math
import re
from pathlib import Path

METERS_PER_DXF_UNIT = {1: .0254, 2: .3048, 4: .001, 5: .01, 6: 1.0, 7: 1000.0}
DEFAULT_CENTER_LAYER = "M-HVAC-DUCT-CNTR"
DEFAULT_OUTLINE_LAYER = "M-HVAC-DUCT"


def _xy(vec):
    return float(vec.x), float(vec.y)


def _endpoints(line):
    return _xy(line.dxf.start), _xy(line.dxf.end)


def _parallel_edges(center, body_lines, tolerance=0.05,
                    min_half_width=40.0, max_half_width=2500.0):
    """Match edges with identical projected endpoints on opposite sides.

    Choose the narrowest *symmetric* pair, avoiding extra insulation lines.
    Mere parallelism or an endpoint touching the duct is not sufficient.
    """
    start, end = _endpoints(center)
    length = math.dist(start, end)
    if length < tolerance:
        return None
    ux, uy = (end[0] - start[0]) / length, (end[1] - start[1]) / length
    nx, ny = -uy, ux
    positive, negative = [], []
    for edge in body_lines:
        p, q = _endpoints(edge)
        dx, dy = q[0] - p[0], q[1] - p[1]
        if abs(math.hypot(dx, dy) - length) > tolerance:
            continue
        if abs(dx * nx + dy * ny) > tolerance:
            continue
        projections = [(pt[0] - start[0]) * ux + (pt[1] - start[1]) * uy
                       for pt in (p, q)]
        if max(abs(min(projections)), abs(max(projections) - length)) > tolerance:
            continue
        offsets = [(pt[0] - start[0]) * nx + (pt[1] - start[1]) * ny
                   for pt in (p, q)]
        if abs(offsets[0] - offsets[1]) > tolerance:
            continue
        offset = sum(offsets) / 2
        if not min_half_width <= abs(offset) <= max_half_width:
            continue
        (positive if offset > 0 else negative).append((abs(offset), edge.dxf.handle))
    if not positive or not negative:
        return None
    candidates = [(a + b, abs(a - b), ah, bh)
                  for a, ah in positive for b, bh in negative
                  if abs(a - b) <= tolerance]
    if not candidates:
        return None
    width, _, h1, h2 = min(candidates)
    return {"width_units": width, "outline_handles": sorted((h1, h2))}


def classify_block(block_name, layer, duct_layer=DEFAULT_OUTLINE_LAYER):
    """Classify descriptive CAD family blocks; exclude hatch-fill FP_*."""
    name = block_name.casefold()
    if layer == duct_layer:
        if name.startswith("fp_"):
            return None
        if "клапан" in name:
            return "fire_damper"
        for needle, kind in (("отвод", "elbow"), ("переход", "transition"),
                             ("врезка", "takeoff"), ("тройник", "tee"),
                             ("крестовина", "cross")):
            if needle in name:
                return kind
        return "unclassified_duct_block"
    if layer == "M-EQPM":
        return "equipment"
    if layer == "M-HVAC-CDFF":
        if "клапан" in name:
            return "pressure_relief_valve"
        if "решетка" in name or "решётка" in name:
            return "grille"
        return "air_terminal_other"
    return None


def examine_dxf(path, center_layer=DEFAULT_CENTER_LAYER,
                duct_layer=DEFAULT_OUTLINE_LAYER):
    import ezdxf
    path = Path(path)
    doc = ezdxf.readfile(path)
    unit_code = int(doc.header.get("$INSUNITS", 0))
    factor = METERS_PER_DXF_UNIT.get(unit_code)
    if factor is None:
        raise ValueError(f"Unknown DXF $INSUNITS={unit_code}; cannot convert distances to meters")
    model = doc.modelspace()
    centerlines = [e for e in model if e.dxftype() == "LINE"
                   and e.dxf.layer == center_layer]
    edges = [e for e in model if e.dxftype() == "LINE"
             and e.dxf.layer == duct_layer]
    non_line_centers = sum(1 for e in model if e.dxf.layer == center_layer
                           and e.dxftype() != "LINE")
    segments, review = [], []
    unit_per_mm = 0.001 / factor
    for center in centerlines:
        start, end = _endpoints(center)
        pair = _parallel_edges(center, edges,
                               tolerance=.05 * unit_per_mm,
                               min_half_width=40 * unit_per_mm,
                               max_half_width=2500 * unit_per_mm)
        if pair is None:
            review.append({"handle": center.dxf.handle,
                           "reason": "symmetric outline pair not found"})
            continue
        segments.append({
            "handle": center.dxf.handle,
            "start_xy_units": [round(n, 3) for n in start],
            "end_xy_units": [round(n, 3) for n in end],
            "length_m": round(math.dist(start, end) * factor, 6),
            "plan_width_mm": round(pair["width_units"] * factor * 1000, 3),
            "outline_handles": pair["outline_handles"],
            "height_mm": None,
            "system": None,
            "status": "measured_straight_segment_only",
        })

    # Reading a label does NOT mean we know which duct it belongs to.
    size_re = re.compile(r"(?<!\d)(\d{2,4})\s*[xх×]\s*(\d{2,4})(?!\d)", re.I)
    labels = []
    for e in model:
        if e.dxf.layer != "M-HVAC-DUCT-IDEN" or e.dxftype() != "MTEXT":
            continue
        for match in size_re.finditer(e.plain_text()):
            labels.append({
                "handle": e.dxf.handle, "label": match.group(0),
                "first_mm": int(match.group(1)),
                "second_mm": int(match.group(2)),
                "position_xy_units": [round(n, 3) for n in _xy(e.dxf.insert)],
                "linked_segment_handle": None,
                "status": "unlinked_annotation",
            })

    blocks, excluded_fill = [], 0
    for e in model:
        if e.dxftype() != "INSERT":
            continue
        name, layer = e.dxf.name, e.dxf.layer
        kind = classify_block(name, layer, duct_layer)
        if layer == duct_layer and name.casefold().startswith("fp_"):
            excluded_fill += 1
        if kind is None:
            continue
        blocks.append({
            "handle": e.dxf.handle, "kind": kind,
            "layer": layer, "block_name": name,
            "insert_xy_units": [round(n, 3) for n in _xy(e.dxf.insert)],
            "status": "block_family_classification_only",
        })

    by_width = defaultdict(lambda: {"count": 0, "length_m": 0.0})
    for seg in segments:
        row = by_width[str(seg["plan_width_mm"])]
        row["count"] += 1
        row["length_m"] += seg["length_m"]
    for item in by_width.values():
        item["length_m"] = round(item["length_m"], 6)

    return {
        "file": path.name,
        "version": doc.dxfversion,
        "insunits": unit_code,
        "meters_per_unit": factor,
        "center_layer": center_layer,
        "duct_layer": duct_layer,
        "summary": {
            "centerline_count": len(centerlines),
            "measured_centerline_count": len(segments),
            "unmatched_centerline_count": len(review),
            "additional_non_line_center_entities": non_line_centers,
            "partial_straight_length_m": round(sum(x["length_m"] for x in segments), 6),
            "straight_by_plan_width_mm": dict(sorted(by_width.items(),
                                                      key=lambda v: float(v[0]))),
            "block_candidate_counts": dict(sorted(Counter(b["kind"] for b in blocks).items())),
            "unlinked_section_label_candidates": len(labels),
            "excluded_hatch_fill_insert_count": excluded_fill,
        },
        "segments": segments,
        "block_candidates": blocks,
        "section_label_candidates": labels,
        "review": review,
        "limitations": [
            "Partial: explicit straight centerlines only; not total duct lengths",
            "Plan width is not the W×H duct section; heights and systems are unassigned",
            "Section labels have not been geometrically linked to individual segments",
            "Elbows, transitions, vertical runs and blocks are excluded from line lengths",
            "Block family counts are not final procurement quantities",
            "Other linework and nested block geometry are not counted as duct lengths",
        ],
    }


def main():
    parser = argparse.ArgumentParser(description="Traceable partial straight-duct DXF takeoff")
    parser.add_argument("dxf")
    parser.add_argument("--center-layer", default=DEFAULT_CENTER_LAYER)
    parser.add_argument("--duct-layer", default=DEFAULT_OUTLINE_LAYER)
    parser.add_argument("--output")
    args = parser.parse_args()
    result = examine_dxf(args.dxf, args.center_layer, args.duct_layer)
    payload = json.dumps(result, ensure_ascii=False, indent=2)
    if args.output:
        Path(args.output).write_text(payload, encoding="utf-8")
    else:
        print(payload)


if __name__ == "__main__":
    main()
