"""Read-only DXF linear-geometry probe.

Counts geometric paths only on explicitly selected layers. These paths are
NOT verified duct centerlines. No quantity takeoff without engineer review.
"""
from __future__ import annotations
import argparse
import json
import math
from collections import defaultdict
from pathlib import Path

METERS_PER_UNIT = {1: 0.0254, 2: 0.3048, 4: 0.001, 5: 0.01, 6: 1.0, 7: 1000.0}

def _distance(a, b):
    return math.dist(tuple(a)[:2], tuple(b)[:2])

def entity_length(entity):
    kind = entity.dxftype()
    if kind == "LINE":
        return _distance(entity.dxf.start, entity.dxf.end)
    if kind == "LWPOLYLINE":
        if entity.has_arc:
            return None
        pts = [(x, y) for x, y, *_ in entity.get_points()]
        length = sum(_distance(a, b) for a, b in zip(pts, pts[1:]))
        return length + (_distance(pts[-1], pts[0]) if entity.closed and len(pts) > 2 else 0)
    if kind == "POLYLINE":
        if entity.is_3d_polyline or entity.is_polygon_mesh or entity.is_poly_face_mesh:
            return None
        verts = list(entity.vertices)
        if any(abs(v.dxf.get("bulge", 0.0)) > 1e-12 for v in verts):
            return None
        pts = [v.dxf.location for v in verts]
        length = sum(_distance(a, b) for a, b in zip(pts, pts[1:]))
        return length + (_distance(pts[-1], pts[0]) if entity.is_closed and len(pts) > 2 else 0)
    if kind == "ARC":
        return float(entity.dxf.radius) * math.radians((float(entity.dxf.end_angle) - float(entity.dxf.start_angle)) % 360)
    return None

def probe_dxf(path, selected_layers):
    import ezdxf
    selected_layers = set(selected_layers)
    if not selected_layers:
        raise ValueError("Specify explicit candidate layers; measuring all drawing lines is unsafe")
    doc = ezdxf.readfile(str(path))
    units = int(doc.header.get("$INSUNITS", 0))
    scale = METERS_PER_UNIT.get(units)
    count_by_layer = defaultdict(int)
    length_by_layer = defaultdict(float)
    skipped_by_type = defaultdict(int)
    for e in doc.modelspace():
        if e.dxf.layer not in selected_layers:
            continue
        length = entity_length(e)
        if length is None:
            skipped_by_type[e.dxftype()] += 1
            continue
        if e.dxftype() in {"LWPOLYLINE", "POLYLINE"} and (getattr(e, "closed", False) or getattr(e, "is_closed", False)):
            skipped_by_type["closed_polyline"] += 1
            continue
        count_by_layer[e.dxf.layer] += 1
        length_by_layer[e.dxf.layer] += length
    return {
        "file": Path(path).name,
        "insunits": units,
        "meters_per_unit": scale,
        "candidate_layers": sorted(selected_layers),
        "raw_geometry_lengths_m": {k: round(v * scale, 4) for k, v in length_by_layer.items()} if scale else None,
        "raw_geometry_lengths_units": {k: round(v, 3) for k, v in length_by_layer.items()},
        "object_counts": dict(count_by_layer),
        "skipped_objects": dict(skipped_by_type),
        "warning": "Raw layer line lengths are NOT duct lengths. No engineering interpretation, centerline verification, or fittings yet.",
    }

def main():
    p = argparse.ArgumentParser(description="Probe DXF linear geometry on explicit layers")
    p.add_argument("dxf")
    p.add_argument("--layer", action="append", required=True, help="Exact layer name; repeat for multiple")
    p.add_argument("--output")
    args = p.parse_args()
    result = json.dumps(probe_dxf(args.dxf, args.layer), ensure_ascii=False, indent=2)
    if args.output:
        Path(args.output).write_text(result, encoding="utf-8")
    else:
        print(result)

if __name__ == "__main__":
    main()
