"""Prevent false engineering quantity comparisons across incompatible scopes.

Reading DXF and seeing partial lines must never be reported as a project
material deficit. Confirm quantities, boundaries, systems and dimensions
before any quantitative verdict.
"""
from __future__ import annotations


def evaluate_quantity_comparison(measured: dict, reference: dict) -> dict:
    """Report an exact delta only if both quantities describe the same scope.

    Required measured/reference keys: unit, system, scope, quantity.
    Required measured keys: complete (bool), system_confirmed (bool),
    section_confirmed (bool). No inference or rounding is performed.
    """
    failures = []
    for key in ("system", "scope", "unit"):
        if not measured.get(key) or not reference.get(key):
            failures.append(f"{key}_missing")
        elif str(measured[key]).strip().casefold() != str(reference[key]).strip().casefold():
            failures.append(f"{key}_mismatch")
    if not measured.get("complete"):
        failures.append("partial_geometric_measurement")
    if not measured.get("system_confirmed"):
        failures.append("system_unconfirmed")
    if not measured.get("section_confirmed"):
        failures.append("section_unconfirmed")
    try:
        actual, expected = float(measured["quantity"]), float(reference["quantity"])
    except (TypeError, ValueError, KeyError):
        failures.append("quantity_invalid")
        actual, expected = None, None
    return {
        "comparable": not failures,
        "status": "comparable" if not failures else "requires_scope_validation",
        "reasons": failures,
        "measured_quantity": actual,
        "reference_quantity": expected,
        "difference": (actual - expected) if not failures else None,
        "message": "A numerical gap is not a materials deficit until measurement scopes agree."
                   if failures else "Both quantities passed the scope checks.",
    }
