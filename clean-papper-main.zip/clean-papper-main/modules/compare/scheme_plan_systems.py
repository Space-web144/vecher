"""Associate independently identified PDF/DXF system names, never geometric ducts.

A shared system code proves only a DOCUMENT-LEVEL candidate association;
it cannot prove the same segment, approved vertical length or material area.
"""
from __future__ import annotations
import argparse
import json
import re
from collections import defaultdict
from pathlib import Path


def _norm(value):
    return re.sub(r'\s+','',str(value)).replace(',','.').replace('−','-').upper() if value else None


def associate_sources(equipment, scheme_reports):
    if not isinstance(scheme_reports,list):
        raise ValueError('scheme_reports must be a list')
    fan_codes=defaultdict(set)
    for row in equipment.get('system_label_evidence',[]):
        if row.get('fan_handle') and row.get('system'):
            fan_codes[row['fan_handle']].add(_norm(row['system']))
    networks=defaultdict(list)
    for net in equipment.get('provisional_networks',[]):
        code=_norm(net.get('candidate_system'))
        fans=net.get('fan_handles') or []
        if (code and net.get('system_status')=='unique_label_candidate' and
            len(fans)==1 and fan_codes.get(fans[0])=={code}):
            networks[code].append(net)
    pdfs=defaultdict(list)
    review=[]
    for report in scheme_reports:
        evidence=report.get('scheme_title_evidence') or {}
        code=_norm(evidence.get('system_read_from_pdf'))
        declared=_norm(report.get('scheme'))
        if not (evidence.get('verified') is True and code and code==declared):
            review.append({'pdf_page':report.get('pdf_page'),'declared_system':declared,
                           'reason':'printed_scheme_title_not_independently_verified'})
            continue
        pdfs[code].append(report)
    associations=[]
    for code in sorted(set(networks)|set(pdfs)):
        nets=networks.get(code,[])
        schemes=pdfs.get(code,[])
        if len(nets)!=1 or len(schemes)!=1:
            review.append({'system':code,'reason':'nonunique_or_missing_system_evidence',
                           'cad_candidates':len(nets),'pdf_candidates':len(schemes)})
            continue
        net,scheme=nets[0],schemes[0]
        associations.append({
            'system':code,
            'cad_network_id':net['network_candidate_id'],
            'cad_component_ids':net['component_ids'],
            'cad_fan_handles':net['fan_handles'],
            'pdf_page':scheme['pdf_page'],
            'scheme_region_pt':scheme['region_pt'],
            'pdf_printed_title_system':scheme['scheme_title_evidence']['system_read_from_pdf'],
            'graphic_mark_candidates':sum(
                item['status']=='leader_to_colored_geometry_candidate'
                for item in scheme.get('level_anchor_evidence',[])),
            'status':'system_name_correspondence_only',
            'verified_segment_correspondence':False,
            'verified_vertical_length_m':None,
            'verified_material_surface_m2':None,
        })
    return {
        'summary':{
            'system_name_correspondences':len(associations),
            'unmatched_or_ambiguous':len(review),
            'approved_duct_geometry_correspondences':0,
        },
        'associations':associations,
        'review':review,
        'limitations':[
            'Shared system code establishes document-level association only',
            'No plan line is proven to be the same physical duct as the PDF graphic',
            'No elevation span or material quantity is derived from a system name',
        ],
    }


def main():
    p=argparse.ArgumentParser(description='Join verified system names without guessing duct geometry')
    p.add_argument('--equipment',required=True,help='equipment_bridges JSON')
    p.add_argument('--schemes',nargs='+',required=True,help='elevation_leaders PDF JSON files')
    p.add_argument('--output')
    args=p.parse_args()
    equipment=json.loads(Path(args.equipment).read_text(encoding='utf-8'))
    schemes=[json.loads(Path(file).read_text(encoding='utf-8')) for file in args.schemes]
    output=json.dumps(associate_sources(equipment,schemes),ensure_ascii=False,indent=2)
    if args.output:
        Path(args.output).write_text(output,encoding='utf-8')
    else:
        print(output)

if __name__=='__main__':
    main()
