"""Quantity calculations with explicit engineering verification gates.

No guessed missing values, inferred segment heights, default material or
fitting-length additions. Report withheld quantity as null, not zero.
"""
from __future__ import annotations
import math

_REQUIRED_CHECKS = ('length_approved','width_approved','height_approved',
                    'system_approved','scope_approved')


def vertical_length_from_levels(start_level_m,end_level_m,*,same_datum=False,
                                same_straight_axis=False,
                                marks_define_centerline_ends=False,
                                source_mark_ids=None):
    vals=(start_level_m,end_level_m)
    valid=all(isinstance(v,(int,float)) and not isinstance(v,bool) and math.isfinite(v)
              for v in vals)
    missing=[]
    if not valid: missing.append('invalid_elevation_marks')
    if not same_datum: missing.append('datum_not_confirmed')
    if not same_straight_axis:missing.append('same_straight_riser_not_confirmed')
    if not marks_define_centerline_ends:missing.append('centerline_end_marks_not_confirmed')
    if not source_mark_ids or len(source_mark_ids)!=2 or not all(source_mark_ids):
        missing.append('missing_source_mark_ids')
    length=abs(end_level_m-start_level_m) if valid else None
    if valid and length<=0: missing.append('nonpositive_vertical_extent')
    return {'elevation_span_m':round(length,6) if length is not None else None,
            'verified_straight_vertical_length_m':round(length,6) if not missing else None,
            'status':'approved' if not missing else 'review_required',
            'reasons':missing}


def straight_duct_surface(row):
    """Validated rectangular duct lateral surface, excluding ends, flanges and fittings.

    Each row must include numeric length_m, width_mm, height_mm; exact source
    identifier; system and five explicit engineer approvals. Returns area_m2
    ONLY for eligible input, plus equation and provenance.
    """
    blockers=[name for name in _REQUIRED_CHECKS if row.get(name) is not True]
    if not row.get('source_id'):blockers.append('source_id_missing')
    if not row.get('system'):blockers.append('system_missing')
    dims={}
    for name in ('length_m','width_mm','height_mm'):
        value=row.get(name)
        if not isinstance(value,(int,float)) or isinstance(value,bool) or not math.isfinite(value) or value<=0:
            blockers.append(f'{name}_invalid')
        else:dims[name]=float(value)
    if blockers:
        return {'element_id':row.get('element_id'),'system':row.get('system'),
                'surface_m2':None,'status':'review_required','reasons':blockers,
                'equation':'2*(W_mm+H_mm)/1000 * L_m'}
    area=2*(dims['width_mm']+dims['height_mm'])/1000*dims['length_m']
    return {'element_id':row.get('element_id'),'system':row['system'],
            'surface_m2':round(area,6),'status':'approved','reasons':[],
            'source_id':row['source_id'],
            'equation':'2*(W_mm+H_mm)/1000 * L_m',
            'exclusions':['fittings','flanges','ends','insulation','waste','manufacturing_allowances']}
