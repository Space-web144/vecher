# Vision adapter — planned

Goal: detect duct symbols, section labels, line endpoints and branch junctions on vector/raster PDF plans. Interpret observations using LLM only as assistance; independent geometry determines measurements. Nothing is implemented yet.
