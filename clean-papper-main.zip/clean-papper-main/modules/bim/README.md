# BIM adapter — planned

Goal: extract IFC ventilation objects, geometry, quantities and system membership; report missing or contradictory properties. Nothing is implemented yet.
