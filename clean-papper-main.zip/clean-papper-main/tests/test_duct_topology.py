"""Synthetic DXF tests: no client documents are embedded in repository."""
import sys
import tempfile
import unittest
from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(BASE / "modules" / "cad"))

import ezdxf
from duct_topology import build_topology, _classify_labels
from duct_annotation_links import link_annotations


def duct(model, a, b, half):
    model.add_line(a, b, dxfattribs={"layer": "M-HVAC-DUCT-CNTR"})
    if a[1] == b[1]:
        for shift in (-half, half):
            model.add_line((a[0], a[1] + shift), (b[0], b[1] + shift),
                           dxfattribs={"layer": "M-HVAC-DUCT"})
    else:
        for shift in (-half, half):
            model.add_line((a[0] + shift, a[1]), (b[0] + shift, b[1]),
                           dxfattribs={"layer": "M-HVAC-DUCT"})


class TopologyTests(unittest.TestCase):
    def test_zero_origin_insert_with_absolute_block_geometry(self):
        with tempfile.TemporaryDirectory() as folder:
            doc = ezdxf.new("R2013")
            doc.header["$INSUNITS"] = 4
            model = doc.modelspace()
            duct(model, (0, 400), (500, 400), 100)
            duct(model, (600, 500), (600, 900), 100)
            block = doc.blocks.new("DFT_Отвод_test")
            block.add_line((500, 200), (700, 200))
            block.add_line((700, 200), (700, 500))
            block.add_line((700, 500), (500, 500))
            block.add_line((500, 500), (500, 200))
            model.add_blockref(block.name, (0, 0),
                               dxfattribs={"layer": "M-HVAC-DUCT"})
            file = Path(folder) / "synthetic_elbow.dxf"
            doc.saveas(file)
            got = build_topology(file)
            self.assertEqual(got["summary"]["straight_segment_count"], 2)
            self.assertEqual(got["summary"]["through_fitting_connections"], 1)
            self.assertEqual(got["summary"]["disconnected_straight_groups"], 1)
            self.assertEqual(got["summary"]["single_block_face_contacts"], 2)
            self.assertAlmostEqual(got["summary"]["verified_partial_straight_length_m"], .9)

    def test_overlapping_valves_do_not_merge_adjacent_widths(self):
        with tempfile.TemporaryDirectory() as folder:
            doc = ezdxf.new("R2013")
            doc.header["$INSUNITS"] = 4
            model = doc.modelspace()
            duct(model, (1000, 900), (1000, 1000), 100)
            duct(model, (1020, 880), (1020, 1020), 100)
            for name, y0, y1 in (
                ("DA_Клапан_A", 1000, 1150),
                ("DA_Клапан_B", 1020, 1170),
            ):
                block = doc.blocks.new(name)
                block.add_line((900, y0), (1100, y0))
                block.add_line((900, y1), (1100, y1))
                model.add_blockref(name, (0, 0),
                                   dxfattribs={"layer": "M-HVAC-DUCT"})
            file = Path(folder) / "overlap.dxf"
            doc.saveas(file)
            got = build_topology(file)
            end_ports = [x for x in got["endpoint_contacts"]
                         if x["endpoint"] == "end"]
            self.assertEqual(len(end_ports), 2)
            self.assertTrue(all(x["status"] == "single_face_match" for x in end_ports))
            self.assertEqual(len({x["block_handle"] for x in end_ports}), 2)
            self.assertEqual(got["summary"]["through_fitting_connections"], 0)

    def test_damper_product_size_not_used_as_duct_section(self):
        doc = ezdxf.new("R2013")
        model = doc.modelspace()
        model.add_mtext("КПВ", dxfattribs={
            "layer": "M-HVAC-DUCT-IDEN", "insert": (0, 500)})
        model.add_mtext("-700x400-", dxfattribs={
            "layer": "M-HVAC-DUCT-IDEN", "insert": (300, 500)})
        model.add_mtext("800x600", dxfattribs={
            "layer": "M-HVAC-DUCT-IDEN", "insert": (0, 1000)})
        labels, systems = _classify_labels(model)
        self.assertEqual([x["context"] for x in labels], [
            "fire_damper_product_label", "independent_size_label",
        ])
        self.assertEqual(systems, [])

    def test_size_without_leader_is_unassigned(self):
        with tempfile.TemporaryDirectory() as folder:
            doc = ezdxf.new("R2013")
            doc.header["$INSUNITS"] = 4
            model = doc.modelspace()
            duct(model, (0, 0), (1000, 0), 100)
            model.add_mtext("200x150", dxfattribs={
                "layer": "M-HVAC-DUCT-IDEN", "insert": (200, 600)})
            file = Path(folder) / "no_leader.dxf"
            doc.saveas(file)
            got = link_annotations(file)
            self.assertEqual(got["size_annotations"][0]["link_status"],
                             "no_text_attached_leader")
            self.assertIsNone(got["size_annotations"][0]["linked_segment_handle"])
            self.assertEqual(got["summary"]["groups_with_consistent_section_candidates"], 0)

    def test_leader_traces_to_duct_wall(self):
        with tempfile.TemporaryDirectory() as folder:
            doc = ezdxf.new("R2013")
            doc.header["$INSUNITS"] = 4
            model = doc.modelspace()
            duct(model, (0, 0), (1000, 0), 100)
            model.add_mtext("200x150", dxfattribs={
                "layer": "M-HVAC-DUCT-IDEN",
                "insert": (100, 650), "char_height": 90})
            model.add_line((200, 560), (500, 105),
                           dxfattribs={"layer": "M-HVAC-DUCT-IDEN"})
            file = Path(folder) / "leader.dxf"
            doc.saveas(file)
            got = link_annotations(file)
            self.assertEqual(got["size_annotations"][0]["link_status"],
                             "leader_to_candidate_segment")
            self.assertEqual(got["size_annotations"][0]["evidence_method"],
                             "duct_wall")
            self.assertEqual(got["summary"]["groups_with_consistent_section_candidates"], 1)


if __name__ == "__main__":
    unittest.main()
