"""Synthetic PDF vector leader checks; no client drawings are committed."""
import sys
import tempfile
import unittest
from pathlib import Path
import fitz

BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'modules'/'pdf'))
from elevation_leaders import link_elevation_leaders


def synthetic(page, colored=True, branch=False, print_title=True):
    if print_title:
        page.insert_text((25,30),'Scheme DP 9-1',fontsize=10)
    page.insert_text((100,102),'+4.510',fontsize=9,fontname='helv')
    box=page.search_for('+4.510')[0]
    y=box.y1+1
    start=(box.x1-22.68,y)
    end=(box.x1,y)
    top=(box.x1,y-8.52)
    tip=(box.x1+12,y-15)
    page.draw_line(start,end,color=(0,0,0),width=.2)
    page.draw_line(top,end,color=(0,0,0),width=.2)
    page.draw_line(top,tip,color=(0,0,0),width=.2)
    if colored:
        page.draw_line(tip,(tip[0]+20,tip[1]-10),color=(0,1,0),width=.2)
    if branch:
        second=(box.x1+12,y-2)
        page.draw_line(top,second,color=(0,0,0),width=.2)
        page.draw_line(second,(second[0]+30,second[1]),color=(0,1,0),width=.2)


class VectorLeaderTests(unittest.TestCase):
    def _result(self,colored=True,branch=False):
        with tempfile.TemporaryDirectory() as folder:
            path=Path(folder)/'sample.pdf'
            doc=fitz.open()
            page=doc.new_page(width=500,height=350)
            synthetic(page,colored=colored,branch=branch)
            doc.save(path);doc.close()
            return link_elevation_leaders(path,1,[0,0,500,300],'ДП9-1')

    def test_single_vector_contact_remains_candidate_only(self):
        data=self._result()
        self.assertEqual(data['summary']['level_anchor_candidates'],1)
        v=data['level_anchor_evidence'][0]
        self.assertEqual(v['status'],'leader_to_colored_geometry_candidate')
        self.assertTrue(v['leader_vector_ids'])
        self.assertFalse(v['verified_duct_centerline_endpoint'])
        self.assertIsNone(data['summary']['verified_straight_vertical_length_m'])

    def test_no_colored_contact(self):
        self.assertEqual(self._result(colored=False)['level_anchor_evidence'][0]['status'],
                         'glyph_detected_no_graphic_contact')

    def test_multiple_vector_contacts_refused(self):
        v=self._result(branch=True)['level_anchor_evidence'][0]
        self.assertEqual(v['status'],'multiple_graphic_contact_candidates')
        self.assertIsNone(v['candidate_anchor_pt'])

    def test_keeps_original_mark(self):
        data=self._result()
        self.assertEqual(data['pdf_page'],1)
        self.assertEqual(data['level_anchor_evidence'][0]['raw'],'+4.510')

    def test_scheme_title_not_guessed_from_command_line(self):
        self.assertFalse(self._result()['scheme_title_evidence']['verified'])

if __name__=='__main__':
    unittest.main()
