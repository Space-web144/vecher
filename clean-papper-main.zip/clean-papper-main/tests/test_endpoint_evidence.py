"""Synthetic CAD-only tests. No client files."""
import importlib.util
import tempfile
import unittest
from pathlib import Path
import ezdxf

p=Path(__file__).resolve().parents[1] / "modules" / "cad" / "endpoint_evidence.py"
spec=importlib.util.spec_from_file_location("endpoints",p)
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

class EvidenceTests(unittest.TestCase):
    def test_perpendicular_line_is_only_boundary_not_an_endcap(self):
        d=ezdxf.new("R2013");m=d.modelspace()
        edge=m.add_line((1000,-200),(1000,200),dxfattribs={"layer":"M-HVAC-DUCT"})
        e=module.classify_endpoint((1000,0),(0,0),400,m,1)
        self.assertEqual(e["interpretation"],"transverse_duct_end_boundary")
        self.assertEqual(e["reference_handle"],edge.dxf.handle)

    def test_wall_damper_supersedes_transverse_line(self):
        d=ezdxf.new("R2013");m=d.modelspace()
        damper=d.blocks.new("DA_Клапан_стеновой")
        for a,b in [((-100,-100),(100,-100)),((100,100),(-100,100)),
                    ((-100,100),(-100,-100)),((100,-100),(100,100))]:
            damper.add_line(a,b)
        inst=m.add_blockref(damper.name,(1000,0),dxfattribs={"layer":"M-HVAC-DUCT"})
        m.add_line((1050,-200),(1050,200),dxfattribs={"layer":"M-HVAC-DUCT"})
        e=module.classify_endpoint((1050,0),(0,0),400,m,1)
        self.assertEqual(e["interpretation"],"within_wall_damper_bbox")
        self.assertEqual(e["reference_handle"],inst.dxf.handle)

    def test_ambiguous_dampers_require_review(self):
        d=ezdxf.new("R2013");m=d.modelspace()
        blk=d.blocks.new("Клапан_стеновой")
        for a,b in [((-100,-100),(100,-100)),((100,100),(-100,100)),
                    ((-100,100),(-100,-100)),((100,-100),(100,100))]:
            blk.add_line(a,b)
        for _ in range(2):
            m.add_blockref(blk.name,(1000,0),dxfattribs={"layer":"M-HVAC-DUCT"})
        e=module.classify_endpoint((1050,0),(0,0),400,m,1)
        self.assertEqual(e["interpretation"],"ambiguous_wall_damper_overlap")
        self.assertIsNone(e["reference_handle"])

    def test_missing_evidence_stays_unresolved(self):
        d=ezdxf.new("R2013")
        e=module.classify_endpoint((1000,0),(0,0),400,d.modelspace(),1)
        self.assertEqual(e["interpretation"],"no_explanation")

    def test_topology_unmatched_only(self):
        d=ezdxf.new("R2013");d.header["$INSUNITS"]=4
        ln=d.modelspace().add_line((0,0),(1000,0),
              dxfattribs={"layer":"M-HVAC-DUCT-CNTR"})
        with tempfile.TemporaryDirectory() as folder:
            file=Path(folder)/"test.dxf";d.saveas(file)
            result=module.explain_unmatched(file,{"endpoint_contacts":[
                {"segment_handle":ln.dxf.handle,"endpoint":"start","plan_width_mm":400,"status":"single_face_match"},
                {"segment_handle":ln.dxf.handle,"endpoint":"end","plan_width_mm":400,"status":"unmatched"}]})
            self.assertEqual(result["summary"]["unmatched_endpoints_examined"],1)
            self.assertEqual(result["endpoint_evidence"][0]["interpretation"],"no_explanation")

if __name__ == "__main__":
    unittest.main()
