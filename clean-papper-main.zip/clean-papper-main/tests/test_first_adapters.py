"""Synthetic tests for first CAD/PDF adapter preflight; no project files included."""
import importlib.util
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

def module(relative):
    spec = importlib.util.spec_from_file_location(relative.replace("/", "_"), ROOT / relative)
    result = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(result)
    return result

class AdapterTests(unittest.TestCase):
    def test_dwg_header_only(self):
        m = module("modules/cad/preflight.py")
        with tempfile.TemporaryDirectory() as p:
            dwg = Path(p) / "Лист - 7 - Plan.dwg"
            dwg.write_bytes(b"AC1032" + b"\0" * 20)
            info = m.probe_file(dwg)
            self.assertEqual(info["dwg_signature"], "AC1032")
            self.assertEqual(info["sheet"], 7)
            self.assertFalse(info["geometry_readable"])

    def test_dxf_linear_segments_are_only_candidates(self):
        import ezdxf
        m = module("modules/cad/dxf_segments.py")
        with tempfile.TemporaryDirectory() as p:
            f = Path(p) / "synthetic.dxf"
            doc = ezdxf.new("R2013", setup=True)
            doc.header["$INSUNITS"] = 4  # millimeters
            doc.layers.new("DUCT_CANDIDATES")
            ms = doc.modelspace()
            ms.add_line((0, 0), (1000, 0), dxfattribs={"layer": "DUCT_CANDIDATES"})
            ms.add_lwpolyline([(0, 0), (3000, 0), (3000, 4000)], dxfattribs={"layer": "DUCT_CANDIDATES"})
            ms.add_line((0, 0), (100000, 0), dxfattribs={"layer": "0"})
            doc.saveas(str(f))
            result = m.probe_dxf(f, ["DUCT_CANDIDATES"])
            self.assertEqual(result["object_counts"]["DUCT_CANDIDATES"], 2)
            self.assertEqual(result["raw_geometry_lengths_m"]["DUCT_CANDIDATES"], 8)
            with self.assertRaises(ValueError):
                m.probe_dxf(f, [])

    def test_pdf_vector_and_size_preflight(self):
        import fitz
        m = module("modules/pdf/plan_probe.py")
        with tempfile.TemporaryDirectory() as p:
            f = Path(p) / "synthetic.pdf"
            doc = fitz.open()
            page = doc.new_page()
            page.draw_line((40, 40), (200, 40), color=(0, 0, 1))
            page.insert_text((50, 65), "250x150")
            doc.save(f)
            doc.close()
            result = m.probe_pdf(f, [1])
            entry = result["pages"][0]
            self.assertGreaterEqual(entry["colored_path_counts"].get("blue", 0), 1)
            self.assertTrue(any(x["text"] == "250x150" for x in entry["size_label_candidates"]))

if __name__ == "__main__":
    unittest.main()
