"""Synthetic PDF elevations and engineering quantity-gate tests."""
import importlib.util
import tempfile
from pathlib import Path
import unittest
import fitz

BASE=Path(__file__).resolve().parents[1]
def module(path):
    spec=importlib.util.spec_from_file_location(path.replace('/','_'),BASE / path)
    obj=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj

pdfmod=module('modules/pdf/schematic_evidence.py')
calc=module('modules/calc/confirmed_quantities.py')

class Stage5Tests(unittest.TestCase):
    def test_pdf_levels_not_assumed_to_be_length(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'case.pdf'
            d=fitz.open();q=d.new_page(width=700,height=400)
            q.insert_text((45,65),'+4.510',fontsize=12)
            q.insert_text((45,165),'-0.590',fontsize=12)
            q.insert_text((190,65),'700x400',fontsize=12)
            q.insert_text((300,140),'KPV-700x400',fontsize=12)
            d.save(p);d.close()
            out=pdfmod.parse_evidence(p,1,[20,20,660,220],'TestSystem')
            self.assertEqual(out['summary']['elevation_mark_count'],2)
            self.assertAlmostEqual(out['summary']['range_of_elevation_marks_m'],5.1)
            self.assertIsNone(out['summary']['verified_vertical_duct_length_m'])
            self.assertEqual(out['summary']['isolated_section_candidates'],1)

    def test_pdf_clip_no_silent_pickup_from_other_scheme(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'case.pdf';d=fitz.open();q=d.new_page(width=700,height=400)
            q.insert_text((45,65),'+4.510');q.insert_text((450,65),'-0.590')
            d.save(p);d.close()
            out=pdfmod.parse_evidence(p,1,[20,20,300,200],'TestSystem')
            self.assertEqual(out['summary']['elevation_mark_count'],1)
            self.assertIsNone(out['summary']['range_of_elevation_marks_m'])

    def test_bad_region_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'case.pdf';d=fitz.open();d.new_page();d.save(p);d.close()
            with self.assertRaises(ValueError):
                pdfmod.parse_evidence(p,1,[0,0,9000,9000])

    def test_levels_require_riser_proof(self):
        r=calc.vertical_length_from_levels(-.59,4.51)
        self.assertAlmostEqual(r['elevation_span_m'],5.1)
        self.assertIsNone(r['verified_straight_vertical_length_m'])

    def test_level_approvals_with_mark_ids(self):
        r=calc.vertical_length_from_levels(-.59,4.51,same_datum=True,
            same_straight_axis=True,marks_define_centerline_ends=True,
            source_mark_ids=['p40:mark1','p40:mark2'])
        self.assertAlmostEqual(r['verified_straight_vertical_length_m'],5.1)

    def test_duct_requires_complete_approved_section(self):
        r=calc.straight_duct_surface({'element_id':'C1','length_m':2.5,
                                      'width_mm':500,'height_mm':300,
                                      'system':'S1','source_id':'CAD:37'})
        self.assertIsNone(r['surface_m2'])

    def test_duct_area_with_full_evidence(self):
        r=calc.straight_duct_surface({'element_id':'C1','length_m':2.5,
                                      'width_mm':500,'height_mm':300,
                                      'system':'S1','source_id':'CAD:37',
                                      'length_approved':True,'width_approved':True,
                                      'height_approved':True,'system_approved':True,
                                      'scope_approved':True})
        self.assertAlmostEqual(r['surface_m2'],4.0)

    def test_no_faked_zero_for_missing_height(self):
        r=calc.straight_duct_surface({'length_m':5,'width_mm':800,'height_mm':None})
        self.assertIsNone(r['surface_m2'])

if __name__=='__main__':
    unittest.main()
