"""Source associations require unique CAD and printed PDF scheme labels."""
import sys
import unittest
from pathlib import Path

sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'modules'/'compare'))
from scheme_plan_systems import associate_sources


def equip(duplicate=False):
    nets=[{'network_candidate_id':'N1','component_ids':['G1','G2'],
           'fan_handles':['AB12'],'candidate_system':'ДП 7-1',
           'system_status':'unique_label_candidate'}]
    if duplicate:
        nets.append({'network_candidate_id':'N2','component_ids':['G3'],
                     'fan_handles':['AB12'],'candidate_system':'ДП7-1',
                     'system_status':'unique_label_candidate'})
    return {'system_label_evidence':[{'fan_handle':'AB12','system':'ДП7-1'}],
            'provisional_networks':nets}


def report(verified=True,code='ДП7-1'):
    return {'scheme':'ДП 7-1','pdf_page':40,'region_pt':[0,0,100,100],
            'scheme_title_evidence':{'verified':verified,'system_read_from_pdf':code},
            'level_anchor_evidence':[{'status':'leader_to_colored_geometry_candidate'}]}


class SourceAssociationTests(unittest.TestCase):
    def test_independent_system_codes_link_only_document_scope(self):
        a=associate_sources(equip(),[report()])['associations'][0]
        self.assertEqual(a['system'],'ДП7-1')
        self.assertEqual(a['graphic_mark_candidates'],1)
        self.assertFalse(a['verified_segment_correspondence'])
        self.assertIsNone(a['verified_material_surface_m2'])

    def test_unverified_pdf_title_refused(self):
        self.assertFalse(associate_sources(equip(),[report(verified=False)])['associations'])

    def test_pdf_title_mismatch_refused(self):
        self.assertFalse(associate_sources(equip(),[report(code='ДП8-1')])['associations'])

    def test_ambiguous_duplicate_dxfs_refused(self):
        self.assertFalse(associate_sources(equip(duplicate=True),[report()])['associations'])

    def test_ambiguous_fan_labels_refused(self):
        e=equip()
        e['system_label_evidence'].append({'fan_handle':'AB12','system':'ДП8-1'})
        self.assertFalse(associate_sources(e,[report()])['associations'])

    def test_duplicate_pdf_reports_refused(self):
        self.assertFalse(associate_sources(equip(),[report(),report()])['associations'])

if __name__=='__main__':
    unittest.main()
