"""Engineering quantity comparisons must respect their scopes."""
import importlib.util
from pathlib import Path
import unittest
p=Path(__file__).resolve().parents[1] / "modules" / "compare" / "quantity_scope.py"
spec=importlib.util.spec_from_file_location("quantity_scope",p)
m=importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

class ScopeTests(unittest.TestCase):
    def fields(self):
        return {"system":"ДП7-1","scope":"same","unit":"м",
                "quantity":3.5,"complete":True,
                "system_confirmed":True,"section_confirmed":True}

    def test_partial_against_full_project(self):
        x=self.fields();x.update(scope="basement-only",complete=False,system_confirmed=False,quantity=1.539775)
        y={"system":"ДП7-1","scope":"whole-project","unit":"м","quantity":89.05}
        result=m.evaluate_quantity_comparison(x,y)
        self.assertFalse(result["comparable"])
        self.assertIsNone(result["difference"])
        self.assertIn("scope_mismatch",result["reasons"])

    def test_section_unconfirmed(self):
        x=self.fields();x["section_confirmed"]=False
        y={"system":"ДП7-1","scope":"same","unit":"м","quantity":3.5}
        self.assertIsNone(m.evaluate_quantity_comparison(x,y)["difference"])

    def test_confirmed_exact_difference(self):
        x=self.fields()
        y={"system":"ДП7-1","scope":"same","unit":"м","quantity":3.57}
        result=m.evaluate_quantity_comparison(x,y)
        self.assertTrue(result["comparable"])
        self.assertAlmostEqual(result["difference"],-.07)

    def test_unit_mismatch(self):
        x=self.fields();x["unit"]="шт"
        y={"system":"ДП7-1","scope":"same","unit":"м","quantity":3.57}
        self.assertIn("unit_mismatch",m.evaluate_quantity_comparison(x,y)["reasons"])

if __name__ == "__main__":
    unittest.main()
