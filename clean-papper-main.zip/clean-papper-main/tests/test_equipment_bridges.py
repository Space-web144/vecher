"""Synthetic tests for fan/transition face bridging; no real project geometry."""
import importlib.util
import tempfile
import unittest
from pathlib import Path
import ezdxf

SOURCE = Path(__file__).resolve().parents[1] / 'modules' / 'cad' / 'equipment_bridges.py'
S = importlib.util.spec_from_file_location('equipment_bridges', SOURCE)
M = importlib.util.module_from_spec(S)
S.loader.exec_module(M)


def rect(block,x0,y0,x1,y1):
    for a,b in [((x0,y0),(x1,y0)),((x1,y0),(x1,y1)),
                ((x1,y1),(x0,y1)),((x0,y1),(x0,y0))]:
        block.add_line(a,b)


def synthetic(*,face='opposite',port_count=1,with_label=True,shift=0):
    doc=ezdxf.new('R2013');doc.header['$INSUNITS']=4
    model=doc.modelspace()
    f=doc.blocks.new('ME_Вентилятор_учебный');rect(f,0,-250,500,250)
    fan=model.add_blockref(f.name,(0,0),dxfattribs={'layer':'M-EQPM'})
    lt=doc.blocks.new('DFT_Переход_left');rect(lt,-300,-200,0,200)
    left=model.add_blockref(lt.name,(0,0),dxfattribs={'layer':'M-HVAC-DUCT'})
    rt=doc.blocks.new('DFT_Переход_right')
    if face=='opposite':rect(rt,500,-200+shift,800,200+shift)
    else:rect(rt,-300,500,-0,900)
    right=model.add_blockref(rt.name,(0,0),dxfattribs={'layer':'M-HVAC-DUCT'})
    contacts=[{'segment_handle':'A','block_handle':left.dxf.handle,
               'face':'min_x','status':'single_face_match'}]
    if port_count:
        contacts.append({'segment_handle':'B','block_handle':right.dxf.handle,
                         'face':'max_x','status':'single_face_match'})
    groups=[{'component_id':'G01','segment_handles':['A']},
            {'component_id':'G02','segment_handles':['B']}]
    if with_label:
        shelf=doc.blocks.new('Имя системы_учебная_полка')
        shelf.add_line((900,800),(2900,800))
        model.add_blockref(shelf.name,(0,0),dxfattribs={'layer':'M-EQPM-IDEN'})
        model.add_mtext('\\U+0414\\U+041F',dxfattribs={'layer':'M-EQPM-IDEN','insert':(1000,1200)})
        model.add_mtext(' 9-1',dxfattribs={'layer':'M-EQPM-IDEN','insert':(1400,1200)})
        model.add_line((250,250),(900,800),dxfattribs={'layer':'M-EQPM-IDEN'})
    return doc,fan.dxf.handle,{'endpoint_contacts':contacts,'components':groups}


class BridgeTests(unittest.TestCase):
    def run_analyze(self,doc,top):
        with tempfile.TemporaryDirectory() as t:
            p=Path(t)/'test.dxf';doc.saveas(p)
            return M.analyze_equipment_bridges(p,top)

    def test_two_opposite_transitions_merge_two_groups_provisionally(self):
        doc,fan,top=synthetic()
        r=self.run_analyze(doc,top)
        self.assertEqual(r['summary']['fan_bridges'],1)
        self.assertEqual(r['summary']['transition_fan_face_contacts'],2)
        self.assertEqual(r['summary']['provisional_groups_after_fan_bridges'],1)
        self.assertEqual(r['bridge_candidates'][0]['component_ids'],['G01','G02'])
        self.assertEqual(r['summary']['verified_additional_duct_length_m'],0)
        self.assertTrue(r['bridge_candidates'][0]['approval_required'])

    def test_explicit_equipment_shelf_label_is_only_candidate(self):
        doc,fan,top=synthetic()
        r=self.run_analyze(doc,top)
        self.assertEqual(r['system_label_evidence'][0]['system'],'ДП9-1')
        self.assertEqual(r['bridge_candidates'][0]['candidate_system'],'ДП9-1')
        self.assertEqual(r['provisional_networks'][0]['system_status'],'unique_label_candidate')

    def test_missing_port_blocks_bridge(self):
        doc,fan,top=synthetic(port_count=0)
        r=self.run_analyze(doc,top)
        self.assertEqual(r['summary']['fan_bridges'],0)
        self.assertEqual(r['summary']['provisional_groups_after_fan_bridges'],2)

    def test_same_fan_face_does_not_bridge(self):
        doc,fan,top=synthetic(face='same')
        r=self.run_analyze(doc,top)
        self.assertEqual(r['summary']['fan_bridges'],0)

    def test_large_offset_does_not_match_transition_port(self):
        doc,fan,top=synthetic(shift=170,with_label=False)
        r=self.run_analyze(doc,top)
        self.assertEqual(r['summary']['fan_bridges'],0)

    def test_unlabelled_fan_does_not_inherit_system(self):
        doc,fan,top=synthetic(with_label=False)
        r=self.run_analyze(doc,top)
        self.assertEqual(r['summary']['fan_bridges'],1)
        self.assertEqual(r['summary']['systems_with_direct_label_evidence'],0)
        self.assertIsNone(r['bridge_candidates'][0]['candidate_system'])

    def test_unknown_units_rejected(self):
        doc,fan,top=synthetic();doc.header['$INSUNITS']=0
        with self.assertRaisesRegex(ValueError,'Unknown DXF'):
            self.run_analyze(doc,top)

if __name__=='__main__':unittest.main()
