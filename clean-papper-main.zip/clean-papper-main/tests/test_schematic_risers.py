"""Synthetic PDF vector tests only; no customer drawing committed."""
import sys
import tempfile
import unittest
from pathlib import Path
import fitz

BASE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(BASE/'modules'/'pdf'))
from schematic_risers import detect_schematic_risers

ROI=[0.,0.,500.,420.]


def rail(page,x,y0=100,y1=230,dashed=True):
    if dashed:
        for k in range(6):
            p=y0+k*20
            page.draw_line((x,p),(x,p+12),color=(0,1,0),width=.3)
    else:
        page.draw_line((x,y0),(x,y1),color=(0,1,0),width=.3)


def fixture(xs=(100,120),dashed=True,missing_second=False,slopes=False,y2=(100,230)):
    tmp=tempfile.TemporaryDirectory()
    path=Path(tmp.name)/'synthetic.pdf'
    doc=fitz.open()
    pg=doc.new_page(width=500,height=420)
    rail(pg,xs[0],dashed=dashed)
    if not missing_second:
        rail(pg,xs[1],y0=y2[0],y1=y2[1],dashed=dashed)
    if slopes:
        for i in range(12):
            pg.draw_line((170,100+i*10),(205,140+i*10),color=(0,1,0),width=.3)
    doc.save(path)
    doc.close()
    return tmp,path


class RiserEvidenceTests(unittest.TestCase):
    def test_two_broken_color_walls_one_projected_candidate(self):
        tmp,p=fixture()
        try:
            r=detect_schematic_risers(p,1,ROI,system='SYNTHETIC')
            self.assertEqual(r['summary']['projected_riser_envelope_candidates'],1)
            c=r['riser_candidates'][0]
            self.assertEqual(c['status'],'two_rail_contour_candidate')
            self.assertEqual(c['rail_count'],2)
            self.assertAlmostEqual(c['projected_axis_candidate']['x_pt'],110)
            self.assertAlmostEqual(c['projected_axis_candidate']['projected_axis_span_pt'],112)
            self.assertIsNone(c['confirmed_vertical_length_m'])
            self.assertTrue(c['rails'][0]['vector_ids'])
        finally:tmp.cleanup()

    def test_three_parallel_walls_require_review(self):
        tmp,p=fixture(xs=(100,110))
        try:
            doc=fitz.open(p)
            pg=doc[0]
            rail(pg,120)
            out=Path(tmp.name)/'three.pdf'
            doc.save(out)
            doc.close()
            c=detect_schematic_risers(out,1,ROI)['riser_candidates'][0]
            self.assertEqual(c['rail_count'],3)
            self.assertEqual(c['status'],'ambiguous_parallel_rails')
            self.assertFalse(c['verified_elevation_endpoints'])
        finally:tmp.cleanup()

    def test_single_wall_does_not_imply_duct(self):
        tmp,p=fixture(missing_second=True)
        try:self.assertFalse(detect_schematic_risers(p,1,ROI)['riser_candidates'])
        finally:tmp.cleanup()

    def test_long_single_stroke_is_admissible_as_rail(self):
        tmp,p=fixture(dashed=False)
        try:self.assertEqual(detect_schematic_risers(p,1,ROI)['summary']['projected_riser_envelope_candidates'],1)
        finally:tmp.cleanup()

    def test_short_single_strokes_do_not_create_rails(self):
        tmp=tempfile.TemporaryDirectory()
        try:
            p=Path(tmp.name)/'short.pdf'
            d=fitz.open()
            pg=d.new_page(width=500,height=420)
            for x in (100,120):
                pg.draw_line((x,100),(x,145),color=(0,1,0))
            d.save(p);d.close()
            self.assertFalse(detect_schematic_risers(p,1,ROI)['riser_candidates'])
        finally:tmp.cleanup()

    def test_diagonal_hatch_not_counted_as_vertical_rails(self):
        tmp,p=fixture(missing_second=True,slopes=True)
        try:self.assertEqual(detect_schematic_risers(p,1,ROI)['summary']['projected_riser_envelope_candidates'],0)
        finally:tmp.cleanup()

    def test_too_distant_walls_not_treated_as_one_duct(self):
        tmp,p=fixture(xs=(100,230))
        try:self.assertFalse(detect_schematic_risers(p,1,ROI)['riser_candidates'])
        finally:tmp.cleanup()

    def test_nonoverlapping_vertical_strokes_not_paired(self):
        tmp,p=fixture(xs=(100,120),dashed=False,y2=(280,390))
        try:self.assertFalse(detect_schematic_risers(p,1,ROI)['riser_candidates'])
        finally:tmp.cleanup()

    def test_anchor_near_end_not_confirmation(self):
        tmp,p=fixture()
        try:
            report={'pdf_page':1,'region_pt':ROI,'scheme':'SYN',
                    'scheme_title_evidence':{'verified':True},
                    'level_anchor_evidence':[{'raw':'+1.000','status':'leader_to_colored_geometry_candidate',
                                               'candidate_anchor_pt':[110,100]}]}
            c=detect_schematic_risers(p,1,ROI,leader_report=report,system='SYN')['riser_candidates'][0]
            self.assertTrue(c['mark_anchor_checks'][0]['anchor_at_candidate_riser_end'])
            self.assertFalse(c['verified_elevation_endpoints'])
            self.assertIsNone(c['confirmed_vertical_length_m'])
        finally:tmp.cleanup()

    def test_anchor_far_from_end_flagged(self):
        tmp,p=fixture()
        try:
            report={'pdf_page':1,'region_pt':ROI,'scheme':'SYN',
                    'scheme_title_evidence':{'verified':True},
                    'level_anchor_evidence':[{'raw':'+1.000','status':'leader_to_colored_geometry_candidate',
                                               'candidate_anchor_pt':[250,400]}]}
            c=detect_schematic_risers(p,1,ROI,leader_report=report,system='SYN')['riser_candidates'][0]
            self.assertFalse(c['mark_anchor_checks'][0]['anchor_at_candidate_riser_end'])
        finally:tmp.cleanup()

    def test_missing_or_wrong_roi_source_rejected(self):
        tmp,p=fixture()
        try:
            report={'pdf_page':5,'region_pt':ROI,'scheme_title_evidence':{'verified':True}}
            with self.assertRaises(ValueError):
                detect_schematic_risers(p,1,ROI,leader_report=report)
            report['pdf_page']=1
            report['scheme_title_evidence']['verified']=False
            with self.assertRaises(ValueError):
                detect_schematic_risers(p,1,ROI,leader_report=report)
        finally:tmp.cleanup()

    def test_invalid_roi_rejected(self):
        tmp,p=fixture()
        try:
            with self.assertRaises(ValueError):
                detect_schematic_risers(p,1,[0,0,900,420])
        finally:tmp.cleanup()


if __name__=='__main__':
    unittest.main()
