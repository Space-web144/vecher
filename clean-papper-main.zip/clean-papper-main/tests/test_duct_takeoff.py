"""Synthetic tests for partial duct DXF takeoff; no client files or drawings."""
import importlib.util
from pathlib import Path
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
s = importlib.util.spec_from_file_location("duct_takeoff", ROOT / "modules/cad/duct_takeoff.py")
duct = importlib.util.module_from_spec(s)
s.loader.exec_module(duct)


class DuctTakeoffTests(unittest.TestCase):
    def test_centerline_width_ignores_extra_insulation_and_nonphysical_blocks(self):
        import ezdxf
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "synthetic.dxf"
            doc = ezdxf.new("R2013")
            doc.header["$INSUNITS"] = 4
            m = doc.modelspace()
            m.add_line((0, 0), (2500, 0), dxfattribs={"layer": "M-HVAC-DUCT-CNTR"})
            for y in (-200, 200, -205, 205):
                m.add_line((0, y), (2500, y), dxfattribs={"layer": "M-HVAC-DUCT"})
            m.add_mtext("400x250", dxfattribs={"layer": "M-HVAC-DUCT-IDEN", "insert": (0, 350)})
            for name, layer in (("DFT_Отвод", "M-HVAC-DUCT"),
                                ("FP_7", "M-HVAC-DUCT"),
                                ("DA_Клапан противопожарный", "M-HVAC-DUCT"),
                                ("AT_Решетка", "M-HVAC-CDFF")):
                doc.blocks.new(name)
                m.add_blockref(name, (0, 0), dxfattribs={"layer": layer})
            doc.saveas(path)
            data = duct.examine_dxf(path)
            summary = data["summary"]
            self.assertEqual(summary["measured_centerline_count"], 1)
            self.assertEqual(summary["partial_straight_length_m"], 2.5)
            self.assertEqual(data["segments"][0]["plan_width_mm"], 400)
            self.assertEqual(summary["excluded_hatch_fill_insert_count"], 1)
            self.assertEqual(summary["block_candidate_counts"],
                             {"elbow": 1, "fire_damper": 1, "grille": 1})
            self.assertEqual(summary["unlinked_section_label_candidates"], 1)
            self.assertIsNone(data["segments"][0]["height_mm"])
            self.assertIsNone(data["section_label_candidates"][0]["linked_segment_handle"])

    def test_one_sided_outline_does_not_produce_quantity(self):
        import ezdxf
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "missing.dxf"
            doc = ezdxf.new("R2013")
            doc.header["$INSUNITS"] = 4
            model = doc.modelspace()
            model.add_line((0, 0), (1000, 0), dxfattribs={"layer": "M-HVAC-DUCT-CNTR"})
            model.add_line((0, 200), (1000, 200), dxfattribs={"layer": "M-HVAC-DUCT"})
            doc.saveas(path)
            result = duct.examine_dxf(path)
            self.assertEqual(result["summary"]["partial_straight_length_m"], 0)
            self.assertEqual(result["summary"]["unmatched_centerline_count"], 1)

    def test_unset_units_is_rejected(self):
        import ezdxf
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / "unset.dxf"
            doc = ezdxf.new("R2013")
            doc.header["$INSUNITS"] = 0
            doc.saveas(path)
            with self.assertRaisesRegex(ValueError, "Unknown DXF"):
                duct.examine_dxf(path)


if __name__ == "__main__":
    unittest.main()
