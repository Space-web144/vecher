"""Synthetic vector PDFs for stage-8 seam recognition: no customer files in tests."""
from __future__ import annotations
import tempfile
import unittest
from pathlib import Path
import sys
import fitz
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/"modules"/"pdf"))
from riser_boundaries import analyze_riser_interfaces, inspect_riser


def generate_file(folder, top=True, bottom=True, only_one_rail=False,
                  false_seam=False, extra_seam=False):
    path=Path(folder)/'synthetic.pdf'
    doc=fitz.open()
    page=doc.new_page(width=400,height=300)
    left=(100, 100, 200)
    middle=(110,105,205)
    right=(120,100,200)
    rails=[left,middle,right] if not only_one_rail else [left]
    for x,y0,y1 in rails:
        page.draw_line((x,y0),(x,y1),color=(0,1,0))
    if top:
        page.draw_line((100,100),(110,105 if not false_seam else 114),color=(0,1,0))
        page.draw_line((110,105 if not false_seam else 114),(120,100),color=(0,1,0))
    if bottom:
        page.draw_line((100,200),(110,205),color=(0,1,0))
        page.draw_line((110,205),(120,200),color=(0,1,0))
    for a,b in [((100,100),(96,96)),((120,100),(124,96)),
                ((100,200),(96,204)),((120,200),(124,204))]:
        page.draw_line(a,b,color=(0,1,0))
    if extra_seam:
        page.draw_line((100,100),(110,105.3),color=(0,1,0))
        page.draw_line((110,105.3),(120,100),color=(0,1,0))
    doc.save(path)
    doc.close()
    return path


def stage7(path, rail_count=3):
    a=[{'x_pt':100,'y0_pt':100,'y1_pt':200}]
    if rail_count>=3:
        a.append({'x_pt':110,'y0_pt':105,'y1_pt':205})
    if rail_count>=2:
        a.append({'x_pt':120,'y0_pt':100,'y1_pt':200})
    return {'source_pdf_filename':path.name,'pdf_page':1,
            'region_pt':[0.,0.,400.,300.], 'system':'SYN',
            'riser_candidates':[{'candidate_id':'V01','status':'ambiguous_parallel_rails',
                                 'rails':a}]}


class BoundaryTests(unittest.TestCase):
    def test_two_seams_with_provenance_are_only_drafting_candidates(self):
        with tempfile.TemporaryDirectory() as f:
            path=generate_file(f)
            o=analyze_riser_interfaces(path,stage7(path))
            v=o['riser_interface_candidates'][0]
            self.assertTrue(v['top_and_bottom_drafting_seams'])
            self.assertEqual(v['top']['status'],'unique_seam_candidate')
            self.assertEqual(v['bottom']['status'],'unique_seam_candidate')
            self.assertEqual(len(v['top']['seam']['vector_ids']),2)
            self.assertEqual(len(v['bottom']['seam']['vector_ids']),2)
            self.assertTrue(v['top']['seam']['outside_left_vector_ids'])
            self.assertTrue(v['bottom']['seam']['outside_right_vector_ids'])
            self.assertFalse(v['confirmed_physical_endpoints'])
            self.assertIsNone(v['confirmed_vertical_length_m'])
            self.assertIsNone(v['approved_surface_m2'])
            self.assertNotIn('length_pt',v['top']['seam'])

    def test_missing_lower_seam(self):
        with tempfile.TemporaryDirectory() as f:
            path=generate_file(f,bottom=False)
            v=analyze_riser_interfaces(path,stage7(path))['riser_interface_candidates'][0]
            self.assertEqual(v['bottom']['status'],'seam_not_found')
            self.assertFalse(v['top_and_bottom_drafting_seams'])

    def test_false_middle_not_same_rail_end(self):
        with tempfile.TemporaryDirectory() as f:
            path=generate_file(f,false_seam=True)
            v=analyze_riser_interfaces(path,stage7(path))['riser_interface_candidates'][0]
            self.assertEqual(v['top']['status'],'seam_not_found')

    def test_near_duplicate_seam_requires_review(self):
        with tempfile.TemporaryDirectory() as f:
            path=generate_file(f,extra_seam=True)
            v=analyze_riser_interfaces(path,stage7(path))['riser_interface_candidates'][0]
            self.assertEqual(v['top']['status'],'ambiguous_seam_paths')
            self.assertIsNone(v['top']['seam'])

    def test_no_second_rail_does_not_form_seam(self):
        self.assertEqual(inspect_riser({'candidate_id':'V01','rails':[{'x_pt':100}]},[]),
                         {'candidate_id':'V01','status':'insufficient_rails'})

    def test_different_source_filename_refused(self):
        with tempfile.TemporaryDirectory() as f:
            path=generate_file(f)
            source=stage7(path);source['source_pdf_filename']='another.pdf'
            with self.assertRaisesRegex(ValueError,'filename'):
                analyze_riser_interfaces(path,source)

    def test_leader_roi_mismatch_refused(self):
        with tempfile.TemporaryDirectory() as f:
            path=generate_file(f)
            with self.assertRaisesRegex(ValueError,'mismatch'):
                analyze_riser_interfaces(path,stage7(path),{'pdf_page':1,'region_pt':[0,0,100,100]})

    def test_unverified_system_refused(self):
        with tempfile.TemporaryDirectory() as f:
            path=generate_file(f)
            leader={'pdf_page':1,'region_pt':[0,0,400,300],
                    'scheme':'SYN','scheme_title_evidence':{'verified':False}}
            with self.assertRaisesRegex(ValueError,'identity'):
                analyze_riser_interfaces(path,stage7(path),leader)

if __name__=='__main__':unittest.main()
