# Transfer provenance and status

**Source:** veryhardlogin69/baza-znaniy, main commit 6d0c5e60261a4844d064610e78b3453bf48f0bb1
**Target:** veryhardlogin69/clean-papper
**Method:** GitHub connected file reads + Git tree object; preserve existing internal paths and source text.
**Transfer date:** 2026-11-20

## Included
- common/: selected calculation, categorization, normalization, nomenclature matching, Claude client, Excel and related test files, plus parameter configuration.
- program-a/: PDF extraction and specification conversion, equipment matching, Excel/fitting processor and related tests and prompts.
- program-b/: selected graphical PDF extraction, raster/vector difference, sheet matching, specification comparison, verification and related tests/prompts.
- docs/reference/: selected existing technical documentation describing the implementation and validations.

## Deliberately excluded
- Entire production website and server endpoints; deployment jobs, CI secrets and VPS configuration.
- Private nomenclature databases, customer drawings, generated reports, company-specific data and binary attachments.
- Full Verrata PDF report/orchestrator and its font assets; this is an algorithmic seed, not a working full product.
- Native CAD and BIM reader modules: absent in source snapshot and must be developed.

## Evidence and caveats
The source documentation reports previous checks on real PDF specifications and fitting calculations. They are historical reports, not a substitute for new local tests.
The port preserves source text but does not guarantee standalone function: the original project has runtime paths and optional external services.
GitHub compile workflow checks Python syntax only; functional regression, installation and business accuracy still need explicit verification.
No changes were made to source repository.
