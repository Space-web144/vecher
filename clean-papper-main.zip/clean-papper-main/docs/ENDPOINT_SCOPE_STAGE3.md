# Stage 3 — endpoint evidence and scope-safe comparisons

The stage is based on one locally supplied DXF ventilation plan (sheet 5) and one Excel calculation book. The original customer files and extracted customer-specific data are **not committed**.

New modules:
- modules/cad/endpoint_evidence.py: for ends not joined by the earlier graph algorithm, distinguishes a unique transverse boundary LINE from a point inside a unique wall-mounted fire damper INSERT; records handle/geometry. Both remain under engineer review and never add length.
- modules/compare/quantity_scope.py: allows a numerical discrepancy only when the system, source scope, units, completeness, section and system membership are all confirmed. Incomplete comparisons return difference=null.

Example for CAD:
  python modules/cad/duct_topology.py drawing.dxf --output topology.json
  python modules/cad/endpoint_evidence.py drawing.dxf --topology topology.json --output endings.json

Pilot observations (not committed as artifacts): one transverse duct boundary and two wall fire damper overlaps explain three previously unmatched endpoints; the partial straight-centerline total remains 16.144405 m. All three are still engineer-review cases, not confirmed endcaps, fittings or additional meters.

Potential group-to-system candidates for later verification:
- ДП7-1: G01/G02; 700×400; 3.244959 m
- ДП4.2-1: G03/G04; 800×400; 5.399032 m
- ДП2-1: G05/G09/G11; 450×400; 3.228000 m
- ДП8-1: G06/G07; 600×400; 2.732639 m
- ДВ2-1: G08/G10; 800×600; 1.539775 m

Those associations are proposals, not confirmed network connections. The project spreadsheet contains whole-system planned quantities and cannot be used as direct ground truth for this single-page partial measurement. Its row 38 also has computed columns K38=L38*1.25 and N38=O38*1.25, whose meanings must be checked in the source template.

Nine new synthetic tests cover endpoint geometry and comparison safeguards. Next: verify physical connections through equipment and between adjacent fittings, trace plan verticals to system drawings, and independently compare quantities only after scope alignment.
