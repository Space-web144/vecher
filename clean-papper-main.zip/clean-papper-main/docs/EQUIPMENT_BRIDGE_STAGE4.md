# Stage 4 - fan/transition connectivity candidates from DXF

## Engineering goal

Use existing stage-2 duct_topology.py endpoint contacts as evidence to propose additional connectivity through a fan. Keep exact CAD handles, separate system-label observations and never add guessed duct/fitting lengths.

## New adapter

Module modules/cad/equipment_bridges.py operates on original DXF modelspace and stage-2 topology JSON:

    python modules/cad/duct_topology.py drawing.dxf --output topology.json
    python modules/cad/equipment_bridges.py drawing.dxf --topology topology.json --output equipment_networks.json

For each bridge, the algorithm requires:
1. Two duct-transition INSERTs on M-HVAC-DUCT and one fan INSERT on M-EQPM.
2. Each transition bbox touches a fan bbox face within 1.5 mm, with nearly concentric overlapping face spans (at least 94% of narrower face and within 100 mm of centered alignment).
3. Exactly one previously identified straight-duct endpoint touches the opposite face of each transition.
4. Transitions touch opposite faces of same fan; multiple candidate fan connections and ambiguous port counts are rejected.
5. The connected straight segments belong to different existing groups.

This yields a reviewable, provisional graph edge, not a confirmed mechanical port connection. Bounding boxes are CAD object extents, not guaranteed physical flange faces.

## Source-label evidence

System-label shelf INSERTs on M-EQPM-IDEN provide fragmented MTEXT and leader LINEs; one- or two-segment lines can connect a shelf to the fan bbox. A fan without unique label evidence stays unassigned.

## Pilot observations (local project, not committed)

The supplied sheet-5 DXF has four fan blocks and eight touching transition blocks. Eight fan-transition face contacts support four provisional bridges, combining 11 pre-existing straight groups into seven network candidates:

| Fan CAD handle | Provisional group pair | Direct label candidate |
| --- | --- | --- |
| 2517 | G05 + G09 | ДП2-1 |
| 2688 | G03 + G04 | ДП4.2-1 |
| 27F9 | G01 + G02 | ДП7-1 |
| 2BA4 | G06 + G07 | No uniquely linked system |

The remaining G08, G10 and G11 groups have no fan bridge. Their system and connectivity remain unresolved. Earlier tentative attributions without CAD-leader evidence are not promoted.

**Quantity conservation:** the 16.144405 m of measured straight centerline length stays unchanged. The algorithm adds **0 m**; it does not add elbow, transition, fan or vertical duct lengths.

## Tests and limitations

tests/test_equipment_bridges.py has seven synthetic cases for valid opposite ports, explicit label shelves, missing ports, same-face contacts, misalignment, unlabelled fans and unknown units. The current implementation depends on export conventions (named layers/blocks); no claim of universal CAD performance is made.

No customer DWG/DXF/PDF/Excel or confidential nomenclature databases are included in the repository.

## Next tasks

1. Check fan/transition physical ports against native CAD block attributes, not bbox alone.
2. Identify unlabeled fan systems from independent sheets.
3. Inspect adjacent fittings and vertical shafts; do not merge on mere overlapping bounding rectangles.
4. Add takeoff of fitting surfaces only when section sizes, lengths, angles and engineering rules are confirmed.
