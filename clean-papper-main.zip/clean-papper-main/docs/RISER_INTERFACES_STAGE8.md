# Stage 8 — boundaries of projected PDF riser contours

This adapter builds on stage 7. It takes an existing **projected vertical-contour candidate** (at least two outer colored rails) and analyzes the underlying vector PDF to see if the top and bottom rails are joined by short, diagonal **drafting seams**.

## Design

\`modules/pdf/riser_boundaries.py\`:
- reads only original colored vector \`LINE\` primitives in an explicit PDF page region;
- confirms that the candidate comes from the **same filename, PDF page and ROI**;
- tries a direct seam between outer rails, or a two-segment path through the endpoint of an existing *interior* rail;
- requires monotonic horizontal progress, limits slope and matches endpoints within a stated tolerance;
- rejects absent or multiple geometrically distinct paths, reporting reasons instead of guessing;
- records original vector path/item identifiers, projected seam endpoints and local colored strokes that continue outside the presumed straight segment;
- reports **null** verified vertical length, section and area, even when top and bottom boundaries are found.

A two-stroke drafted boundary is evidence of a drawn segmentation, **not** a verified fan/fitting flange, duct-end centerline, physical port or confirmed W×H. Source X/Y coordinates are **PDF points**.

### CLI

Run schematic_risers.py on the same region first to obtain risers.json, then:

    python modules/pdf/riser_boundaries.py album.pdf --risers risers.json --leaders leader.json --output interfaces.json

## Real project pilot (no source files committed)

Four selected scheme regions were inspected. One region had a three-rail projected vertical contour (ambiguous). The algorithm found an upper and lower **two-diagonal** drafted boundary and nearby continuing color strokes. The other regions had no stable stage-7 contour, so no seam was fabricated.

No vertical lengths or metallic surface quantities were accepted. Elevation markers are not attached to certified physical endpoints. The line orientation and the drafting seams do not establish the section or system association in the DXF plan.

## QA

\`tests/test_riser_boundaries.py\` covers eight synthetic cases: both ends present, absent lower seam, false interior point, ambiguous near-duplicate seam, insufficient rails, source filename discrepancy, page/ROI mismatch, unverified system/title. Actual client PDFs, DWG/DXF, workbook and PNG exports are kept outside the repository.

## Next challenge

Verify actual fitting ports/segment endpoints using native CAD/BIM geometry, and prove 1:1 matching of those entities to the scheme contour. Only then release L and W×H into \`modules/calc/confirmed_quantities.py\`.
