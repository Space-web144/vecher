# Stage 7 - projected vertical contours from vector PDF

## Purpose

Recover visually plausible *vertical geometry* from original CAD-exported PDF vector paths while maintaining a strict distinction between projected PDF dimensions and actual duct lengths.

The earlier stage-6 elevation leader analyzer provides text-mark anchors, but those anchors are frequently attached to horizontal branches or equipment. Neither level differences nor PDF point distances may automatically be converted into meters of duct.

## New module

modules/pdf/schematic_risers.py operates on one explicitly selected scheme and optional stage-6 JSON:

    python modules/pdf/schematic_risers.py album.pdf --page 40 \
      --box X0 Y0 X1 Y1 --system "ДП8-1" \
      --leaders dp8_leaders.json --output riser_candidates.json

Process:

1. Extract saturated green/blue vector LINE primitives inside an explicitly bounded PDF region. Ignore grayscale annotation strokes and diagonal hatching.
2. Group nearly collinear vertical strokes by x-coordinate (0.85 PDF pt tolerance), including dashes and broken contours (up to 9.8 pt gap).
3. Require a sufficiently long visual rail (minimum 35 pt and two strokes, or a single 70+ pt continuous stroke) to avoid mistaking short equipment outlines for risers.
4. Form possible paired rails when side separation is 5-35 pt and vertical overlap is at least 30 pt and 65% of the shorter rail.
5. Preserve original path/item vector identifiers and projected endpoints. If three or more overlapping rails occur, mark the contour *ambiguous* instead of choosing an arbitrary pair.
6. Check the distances between existing elevation leader anchors and the candidate top/bottom in PDF points. Proximity is *never* treated as proven physical endpoint identity.
7. Always return confirmed_vertical_length_m=null and approved_material_surface_m2=null until independent engineering confirmation becomes possible.

The geometric thresholds are experimental defaults appropriate only for the pilot drawing. They are **not** validated CAD/BIM conventions or universal sizing rules.

## Pilot, source file not committed

Four separate ventilation scheme regions on one vector PDF page were examined:

| Scheme | Colored vertical strokes | Long rails grouped | Contour candidates |
| --- | ---: | ---: | ---: |
| ДП2-1 | 26 | 0 | 0 |
| ДП4.2-1 | 30 | 0 | 0 |
| ДП7-1 | 27 | 0 | 0 |
| ДП8-1 | 55 | 3 | 1 |

For ДП8-1, candidate V01 includes three approximately parallel graphic rails at PDF x=1501.08 / 1513.32 / 1521.48, with common projected y range 687.116-789.836 and span 102.720 PDF points. It remains ambiguous: contours, hatching and drawing conventions are not automatically distinguishable.

Stage-6 level leader anchors for +4.510 and -0.590 are tens of PDF points away from both V01 projected ends. Neither is verified as a physical endpoint of this vertical run. The 5.100 m difference between marks is **not** added to quantity takeoff.

No additional linear duct meters or surface area were approved in this stage. Previous straight-plan length remains independent of these observations.

## Validation and data safeguards

tests/test_schematic_risers.py has 12 synthetic tests: dashed paired outlines, three-rail ambiguity, single-line false positive, long solid rails, short equipment outlines, hatch diagonals, excessive rail separation, non-overlapping contours, near/far level anchors, input provenance mismatch and ROI validation.

The project drawing, rendered fragments and customer Excel stay outside GitHub. The user receives the annotated pilot PNG and evidence workbook directly in the conversation.

## Next implementation priorities

- Use CAD or native BIM element ports and level data, not PDF vector pixel scaling, for dimensional verification.
- Add explicit 3D riser topology linking plan objects to scheme objects with machine-readable source IDs.
- Validate actual top/bottom reference locations and whether offsets reference ducts, fittings, fan nozzles or floor elevation.
- Once W, H, L and the same system/scope are separately approved, use modules/calc/confirmed_quantities.py to release area.
