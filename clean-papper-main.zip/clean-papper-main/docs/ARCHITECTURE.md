# Architecture — Clean Papper

## Purpose
One reusable engine for ventilation quantity takeoff and materials reconciliation, independent of input files and output Excel templates.

## Input adapters
A. PDF specifications: reuse program-a/pdf_to_spec.py, pdf_layout.py, spec_conversion.py and spec_agent.py.
B. PDF plans: reuse geometric extraction from program-b/geometry.py and raster tools as foundations. No completed duct-network reconstruction exists.
C. DWG/DXF: future CAD adapter. Prefer exact entity coordinates, blocks, layers and dimensions before vision.
D. IFC/BIM: future BIM adapter. Prefer explicit object parameters and relationships before visual inference.

## Intermediate object model (design target)
Project > document > sheet > ventilation system > element.
Element fields: element_id; source reference (file / page or model handle / bounding region); system; floor; type; section dimensions; material; thickness; length; quantity; engineering connections; extraction method; confidence; review status; assumptions.

The normalized object model is not yet implemented.

## Calculation
Reusable arithmetic: common/area.py and existing VentSpec functions. Separate:
- project quantities (measured from source);
- material calculations (area, fitting dimensions, insulation);
- procurement quantities (additional rules and packaging).

No model-generated freehand quantity is accepted without evidence and deterministic validation.

## Nomenclature reconciliation
Normalize project and external catalogue values via common/parameters.py, matcher.py, hybrid_matcher.py; check critical features (geometry, material, mark, execution), then optionally suggest uncertain matches. Do not auto-approve a fuzzy match.

## Excel/output
Existing writers in program-a and program-b are reusable but presently assume specific legacy formats. Future outputs should read the normalized object model, not a fixed Excel column mapping.

## Engineering verification
Every automatically quantified element needs a traceable source. Any unrecognized segment, missing dimensions or uncertain junction must remain in a review queue. Independently verify totals and row extraction where possible (program-b/verify_so.py is a useful precedent).

## Service boundary
Future API endpoints: upload project, inspect extraction result, modify or approve detection, calculate quantities, run external-catalog matching, export XLSX and audit report. The deployment UI / API is not built yet.

## Non-goals of initial port
No direct connection to live 1C, no customer-project content, no migration of production website, and no claim of accurate DWG/PDF plan takeoff.
