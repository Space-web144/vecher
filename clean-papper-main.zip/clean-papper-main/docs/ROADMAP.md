# Roadmap

## Phase 0 — isolated foundation (current)
- Copy a curated set of original source modules, tests and reference documentation.
- Preserve original logic; do not copy user secrets or customer documents.
- Verify the tree, source provenance and compilation; assess what fails due to missing legacy dependencies.

## Phase 1 — stable materials core
- Define a normalized element and specification-row format.
- Build integration adapters for program-a and common algorithms, without rewriting formulas.
- Run tests against permitted synthetic fixtures.
- Acceptance: equivalent input yields equivalent outputs and auditable origin of every row.

## Phase 2 — PDF specification pipeline
- PDF specification → parsed rows → normalized model → configurable XLSX.
- Compare two external nomenclature sources with strict material-parameter validation.
- Acceptance: independent verification of counts and associations; explicit review queue for unreadable pages.

## Phase 3 — DWG/DXF quantity takeoff MVP
- Read CAD entities, layers, blocks, dimensions and system labels.
- Reconstruct simple planar ventilation segments and calculate centerline lengths.
- Acceptance: measurable precision/recall against manually measured approved drawings; ambiguous crossings are flagged.

## Phase 4 — PDF-plan computer vision
- Extend vector-PDF reader with symbolic and graphical detection; add raster path for scans.
- Fuse OCR/vision semantics with deterministic geometric measurement.
- Acceptance: correct reconciliation with CAD ground truth, highlighted source fragments for every element.

## Phase 5 — BIM
- Support IFC object quantities and system properties with explicit missing-property checks.
- Reconcile IFC and 2D schedules without silently mixing revisions.

## Phase 6 — web product
- Task queue, project/version storage, review UI, exports, authentication, cost monitoring.
- Agent becomes an optional orchestration interface; calculations remain ordinary code.

## Immediate next experiment
Take one permission-cleared project with a DWG and PDF of the same ventilation plan, plus manually checked lengths and fittings. Establish a reproducible test corpus, then design the CAD extractor before building an extensive UI.
