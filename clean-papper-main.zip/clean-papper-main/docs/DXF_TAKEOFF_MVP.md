# Partial DXF takeoff — MVP

## Implementation
modules/cad/duct_takeoff.py is a conservative DXF modelspace extractor. It uses ezdxf (see requirements-adapters.txt) to:
1. Read units from $INSUNITS (reject unknown units).
2. Read explicit straight LINE centerlines on M-HVAC-DUCT-CNTR.
3. Independently confirm two symmetric, parallel matching body outlines on M-HVAC-DUCT.
4. Use the nearest **symmetric** pair, so an outer insulation contour does not enlarge the duct width.
5. Preserve centerline and two outline CAD handles plus model coordinates for later verification.
6. Classify INSERT block **candidates** on duct/equipment/air-terminal layers using family names. Exclude FP_ fill/pattern blocks.
7. Discover sectional W×H MTEXT labels on M-HVAC-DUCT-IDEN, but do not invent associations to nearby ducts.

Example: python modules/cad/duct_takeoff.py drawing.dxf --output takeoff.json

## Engineering limits
- The measured length is the sum of explicitly identified **straight centerlines only**. It is not the total system length or final materials quantity.
- Measured plan width is *not* a full W×H duct section. Height and system membership remain unassigned.
- Fitting INSERTs are only family-level candidates. Their dimensions, possible nesting/duplication, and count as procurement items require separate verification.
- Bends, transitions, verticals, fittings, unrecognized geometry, and lines inside blocks do **not** contribute to straight-line totals.
- No project documents, customer drawings, private Excel sheets or credentials are committed.

## Next milestones
A. Trace candidate duct connectivity and tie label leaders to specific centerlines and fittings.
B. Recover whole W×H section and systems; use an independent reference specification to verify.
C. Add three-dimensional and vertical run reconstruction.
D. Implement review UI and compare complete quantities against engineer calculations.

## Tests
tests/test_duct_takeoff.py uses synthetic geometry, including a false wider insulation outline, a missing opposite wall, unrecognized units and FP_ pattern exclusions.
