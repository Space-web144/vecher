# Pilot 01 — ventilation drawing preflight (2026-11-20)

## Source material (not committed)
One user-provided engineering package inspected locally: an RAR with 36 DWG files, a 181-page PDF album, and a five-sheet Excel calculation book. Customer file contents and detailed project data remain outside Git.

The DWG archive contains drawing sheets 1–3 and 5–37. Drawing sheet 4 is missing from the DWG archive but available in the PDF album. DWG signatures read as AC1032 (AutoCAD 2018 family). The archive was successfully inspected and sample DWGs were locally extracted, but DWG CAD geometry was **not** parsed because no supported CAD converter is available in the analysis environment.

## PDF vector reconnaissance
Tests on PDF pages 8, 9, and 14 found vector drawing paths and text labels. In the PDF:
- p. 8: 36,780 graphic paths; 4,481 green stroke paths; 343 blue stroke paths; 26 size-label candidates.
- p. 9: 135,660 graphic paths; 1,371 green stroke paths; 11,169 blue stroke paths; 25 size-label candidates.
- p. 14: 38,013 graphic paths; 17,514 blue stroke paths; 39 size-label candidates.

Examples of textual section tokens: 450x400, Ø100, 250x150. These are **not** verified duct objects. Hatching and repeated contours are numerous, so graphic-path count is not an estimate of running duct meters.

## Excel control sample
The book has five sheets, including supply/exhaust ventilation and smoke-control materials. The first comparison pass identifies rows by simple keywords only. Totals can only be used as acceptance criteria after explicitly identifying project, estimate, actual, and stock/1C columns; such values are not interchangeable.

## Prototype delivered
- modules/cad/preflight.py — drawing signature, index and file inventory (no geometry).
- modules/cad/dxf_segments.py — line/polyline/arc geometry on **manually selected DXF layers** (raw lengths only, not finished duct quantities).
- modules/pdf/plan_probe.py — vector path colors and section-label candidates in PDF.
- tests/test_first_adapters.py — three synthetic tests.

## Blocking requirement for real geometry
Run AutoCAD, ODA File Converter or a comparable permitted DWG decoder to export original drawings to DXF **in original model coordinates and original units**, preserving layers, blocks, labels and XREF where possible. Avoid PDF-to-DXF as the reference for precise quantities. Then inspect entities and identify duct centerlines before any quantity comparison.

## Next milestone
1. Obtain at least one correctly converted DXF of the same plan.
2. Inspect layer names, blocks and model-space units.
3. Separate duct traces from architectural underlays, hatch patterns and fitting boundaries.
4. Reconstruct connected segments and identify section annotations.
5. Calculate *reviewable* candidate duct lengths and compare to Excel, with source references.
