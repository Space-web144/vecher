# Stage 6 — PDF elevation leader contacts and conservative PDF↔DXF system mapping

## Why

A signed level in a PDF scheme is not automatically the elevation of a duct-centerline endpoint. The software must distinguish **text**, its vector annotation glyph, a connected leader, and a candidate contact with a colored schematic stroke.

Matching the scheme and CAD plan at **system-name** level is independent of matching their geometric elements. Never equate the two.

## Modules

- modules/pdf/elevation_leaders.py extends stage 5. Given an explicitly selected PDF page + diagram bounding rectangle:
  1. reads signed three-decimal elevation tokens with PDF-coordinate references;
  2. independently finds a unique printed "Схема ДП ..." title matching the supplied system code;
  3. recognizes an annotation baseline + short vertical level marker and follows connected black vector LINE items;
  4. checks whether a candidate leader endpoint touches a distinct colored vector stroke within 1.5 PDF pt;
  5. retains PDF vector path/item IDs, text and coordinates. Multiple candidate endpoints are refused.
  A graphical contact stays a review candidate, NOT a confirmed duct port, duct length, or physical connection.

- modules/compare/scheme_plan_systems.py matches PDF diagram evidence to stage-4 DXF network evidence ONLY when each independent source has a unique matching, verified system code. Multiple PDFs, multiple DXF networks, uncertain equipment labels, missing printed PDF title, or code discrepancies produce unresolved review items. No measurements result from this join.

## Usage

    python modules/pdf/elevation_leaders.py album.pdf --page 40 --box X0 Y0 X1 Y1 --system "ДП8-1" --output dp8.json

    python modules/compare/scheme_plan_systems.py \
      --equipment equipment_networks.json \
      --schemes dp2.json dp4_2.json dp7.json dp8.json \
      --output cross_source.json

Coordinates are in PDF points, not pixel coordinates or DWG units. A system argument does NOT override the independent title check.

## Pilot (real source files were inspected locally, never committed)

Four manually selected scheme regions on a ventilation PDF page yielded 6 explicit signed elevation marks. The detector traced 5 unique leaders to colored graphic-contact candidates; one remained without a verified colored contact. All four printed scheme titles matched their corresponding supplied system identifiers.

The previously extracted DXF topology had three fan networks with independently traced code labels, allowing **three system-name-only PDF/DXF candidate associations**. The fourth PDF scheme lacked matching, confirmed DXF network identity. No geometric/physical correspondence was approved.

**No additional vertical length or material surface was authorized.** In particular, 5.100 m and 2.260 m are differences between project levels, not automatically straight vertical duct lengths.

## Validation

- tests/test_elevation_leaders.py: synthetic vector level symbol with one contact, missing contact, ambiguous contacts, text/source preservation, and inability to infer scheme name from CLI input.
- tests/test_scheme_plan_systems.py: independent name match, absent/ambiguous evidence, duplicate networks, duplicate PDF title reports, contradictory equipment label.

## Limitations and next steps

- The algorithm relies on vector-PDF drawing conventions (black annotation + colored engineering outlines); scans need separate image understanding.
- PDF vector graphics may show walls, equipment contours or hatching, not necessarily duct centerlines.
- The manual scheme region is trusted only as a region selection, NOT an engineering validation of system membership.
- Next: identify actual duct centerlines and physical ports inside each scheme, then match **explicitly identified** scheme objects to CAD handles or IFC IDs.
- Only after independently verified start/end elevations of one straight vertical run, full W×H, system and scope can existing calculation gates release area.
