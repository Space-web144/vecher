# DXF topology pilot — geometric connections and leader-linked labels

## Stage 2 implementation

Modules:
- modules/cad/duct_takeoff.py — preserved first-stage straight-duct measurements
- modules/cad/duct_topology.py — endpoint-to-block-boundary matching and conservative graph of connected straight segments
- modules/cad/duct_annotation_links.py — classify product-code vs independent size annotations; follow LINE leaders to a duct wall or one-port fitting; propose section dimensions and system context without final approval

Read-only commands, using ezdxf:

    python modules/cad/duct_topology.py drawing.dxf --output topology.json
    python modules/cad/duct_annotation_links.py drawing.dxf --output callout_links.json

## Pilot observations from an engineering DXF (source not committed)

- 24 straight centerlines, partial sum 16.144405 m
- 48 endpoints, 45 matching one block boundary face, 3 unresolved
- 13 two-port fitting/valve connections, yielding 11 disconnected groups of straight centerlines
- 15 W×H textual tokens: 8 explicitly embedded in fire damper product codes, 7 independent size callouts
- All 7 independent callouts trace to a unique straight segment or via a single-port elbow
- 6 groups get consistent section **candidates**, 5 groups have no linked callout
- A system-code annotation adjacent to one callout gives one group a **candidate** system ID

These observations describe **this one DXF** only. They are not measured model accuracy, not complete ventilation quantities, and not a replacement for manual acceptance. Candidate links are inferred from geometric evidence and must be reviewed.

## Essential exclusions

- No attempt to create fictitious duct lengths through fittings, fans, grilles, shafts or vertical runs
- No automatic connection through air terminals or equipment
- No propagation of section labels to all objects as confirmed dimensions
- No dimensions inferred from products identified as fire dampers
- No fabrication of systems for unlabeled groups
- No customer DWG, DXF, PDF, Excel, nomenclature file or credentials committed

## Next

1. Inspect the 3 unmatched endpoints and identify whether they terminate at walls/shafts.
2. Resolve the 5 unsectioned groups from associated system drawings / project documentation.
3. Recover exact geometric fitting sizes and physical lengths, preserving CAD handles and confidence.
4. Compare a complete candidate materials takeoff against a vetted engineer specification only after scope and quantity conventions agree.

CI: tests/test_duct_topology.py provides five synthetic checks. No client drawing is stored in CI.
