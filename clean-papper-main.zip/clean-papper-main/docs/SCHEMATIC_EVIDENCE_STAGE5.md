# Stage 5 - evidence from schematic elevations; approved surface calculation

## Why this module exists

A height callout on an axonometric ventilation scheme is a source observation, **not** proof of the length of one vertical duct. Different marks may refer to horizontal branch elevations, fitting faces, fan nozzles, roof points, or centerlines. Taking max-min blindly overestimates or misclassifies material quantities.

## New modules

- modules/pdf/schematic_evidence.py: a *read-only* PyMuPDF extractor for elevation marks and W x H text in a manually selected rectangular region on a 1-based PDF page. Keeps text, PDF page and bounding box for each observation. Classifies product-code dimensions separately. Reports mark-range only.
- modules/calc/confirmed_quantities.py: explicit engineering check gates for elevation-to-vertical-length and W x H x L to straight rectangular-duct lateral surface. Both return null rather than zero when evidence is missing.

Usage:

    python modules/pdf/schematic_evidence.py path/to/album.pdf --page 40 --box 1360 550 1665 920 --system SAMPLE --output observations.json

The coordinates above are an **example of a selected region** and need not fit another PDF or page. Use a page viewer to obtain them. The source PDF is not stored here.

The section parser intentionally does not infer that a W x H token in a fan, air terminal, fire damper or other product name gives the dimensions of any adjacent duct.

## Calculation policy

A difference of elevations becomes eligible as the straight vertical length only when:
- both marks have documented source IDs;
- both refer to the same elevation datum;
- the geometry is proven to be the same straight riser axis;
- both mark references are confirmed **centerline endpoints** of that straight riser.

The rectangular straight surface calculation then additionally requires:
- positive verified length, W and H;
- nonempty element source reference and known system;
- independent engineer confirmation of length, width, height, system and scope.

Equation: **S = 2 x (W_mm + H_mm) / 1000 x L_m**. Excludes ends, elbows, transitions, flanges, insulation, waste and fabrication allowances. The formula makes no assumptions about material thickness.

## Pilot findings (no client data committed)

On four small smoke-control scheme regions, some regions contained only one elevation mark, while others had two with distinct levels. The new module always returned verified_vertical_duct_length_m=null for such unchecked annotations; all such observations are review inputs only. The associated generated workbook is delivered separately to the user and not uploaded to GitHub.

## Tests and next milestones

tests/test_stage5.py contains 8 synthetic tests including ROI isolation, rejecting invalid region bounds, extraction from PDF text, non-inference from level ranges, signoff checks, and refusal of incomplete area calculation.

Next:
1. Extract scheme-specific riser axes and attach each level mark to a graphical leader/port instead of comparing unassociated elevations.
2. Match scheme systems to selected DXF component groups and require approved connections.
3. Extract actual fitting dimensions and types from CAD INSERT properties; calculate using established fitting rules only with unambiguous inputs.
4. Generate a checked materials specification while preserving per-row source references and an engineer review queue.
