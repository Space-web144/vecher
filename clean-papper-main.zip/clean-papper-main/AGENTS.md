# Instructions for Codex and development agents

Project: Clean Papper — engineering analysis of ventilation drawings, specifications and nomenclature.

## Safeguards

1. The original source is veryhardlogin69/baza-znaniy at commit 6d0c5e60261a4844d064610e78b3453bf48f0bb1. Never write to that repository as part of Clean Papper tasks.
2. Modules under common/, program-a/, program-b/ are imported legacy components. Prefer writing adapters or new modules under modules/ over editing them before baseline regression tests exist.
3. Never replace deterministic engineering calculations with unverified LLM output. Show assumptions and source references; flag uncertainty for human review.
4. Never commit API keys, customer PDF/DWG, internal nomenclature databases, server configurations or generated outputs.
5. Changes to formulas must include explicit test inputs and expected numeric outputs. Preserve original files' behavior until a change is approved.
6. Work in small, reviewable changes; run syntax checks and relevant tests before claiming functionality.
7. Do not treat a vector-PDF parser as a DWG parser or a plan quantity takeoff. Those are future modules.
8. Keep source provenance (page, coordinates, original filename, extraction method) for any new intermediate model.

Current scope and milestones: docs/ARCHITECTURE.md and docs/ROADMAP.md.
