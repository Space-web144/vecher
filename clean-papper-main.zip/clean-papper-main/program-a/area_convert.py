# -*- coding: utf-8 -*-
"""
Конвертер PDF-спецификации в Excel формата инструмента Area (плоский
список позиций: "Наименование" + "Площадь"), см. area_calc.py.

Зачем отдельно от pdf_to_spec.convert(): тот собирает спецификацию в
38-колоночном формате VentSpec, где площадь лежит в столбце "Кол-во м2
по СПЕКЕ" — Area такой файл не примет (run_area_calc ищет в первой
строке столбцы со словами "Наименование" и "Площадь"). Поэтому здесь —
только своя запись столбцов; РАЗБОР PDF общий, из
pdf_to_spec.extract_spec_rows(), чтобы калибровка по трём реальным
шаблонам оставалась в одном месте и два конвертера не разошлись.

Столбец "Площадь" сознательно остаётся пустым: конвертация и расчёт —
два разных шага (как и в VentSpec, где конвертер не делает сравнения с
1С). Полученный файл загружается в форму расчёта на той же странице
Area — там столбец и заполняется.
"""

import os
import sys

from openpyxl import Workbook
from openpyxl.styles import Font, Alignment, Border, Side

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from pdf_to_spec import extract_spec_rows, require_spec_rows  # noqa: E402

# Порядок и названия столбцов. Первые два обязаны читаться
# area_calc._find_column: он ищет по вхождению подстроки "Наименование" и
# "Площадь" (без учёта регистра) в первой строке — отсюда и формулировки.
# Остальное — контекст позиции из той же спецификации, расчёту не мешает.
_HEADERS = [
    "Позиция",
    "Наименование",
    "Тип, марка, обозначение",
    "Единица измерения",
    "Количество",
    "Площадь, м²",
]

_NAME_COLUMN = 2
_COLUMN_WIDTHS = [12.0, 90.0, 30.0, 16.0, 12.0, 14.0]

_HEADER_FONT = Font(bold=True)
_HEADER_ALIGN = Alignment(horizontal="center", vertical="center", wrap_text=True)
_DATA_ALIGN = Alignment(horizontal="center", vertical="center", wrap_text=True)
_NAME_ALIGN = Alignment(horizontal="left", vertical="center", wrap_text=True)

_THIN_SIDE = Side(style="thin", color="000000")
_CELL_BORDER = Border(left=_THIN_SIDE, right=_THIN_SIDE, top=_THIN_SIDE, bottom=_THIN_SIDE)


def _as_number(text):
    """Количество числом, а не текстом — иначе по столбцу не посчитать
    сумму в Excel. Не парсится (диапазон, "по месту") — оставляем как
    есть, данные из PDF не выбрасываем. То же правило, что в
    pdf_to_spec._as_number."""
    if not text:
        return text
    try:
        value = float(str(text).replace(",", ".").replace(" ", ""))
        return int(value) if value.is_integer() else value
    except ValueError:
        return text


def convert_to_area(pdf_path, output_path=None, progress_callback=None, rows_data=None,
                    conversion_info=None):
    """PDF-спецификация -> Excel для инструмента Area.
    Возвращает (путь к сохранённому файлу, число позиций)."""
    if not output_path:
        base, _ext = os.path.splitext(pdf_path)
        output_path = base + "_area_cont.xlsx"

    if rows_data is None:
        rows_data = extract_spec_rows(pdf_path, progress_callback=progress_callback)
    rows, _is_rotated, _is_gost = rows_data

    require_spec_rows(rows)
    wb = Workbook()
    ws = wb.active
    ws.title = "Позиции"

    ws.append(_HEADERS)
    for cell in ws[1]:
        cell.font = _HEADER_FONT
        cell.alignment = _HEADER_ALIGN
        cell.border = _CELL_BORDER
    for i, width in enumerate(_COLUMN_WIDTHS, start=1):
        ws.column_dimensions[ws.cell(row=1, column=i).column_letter].width = width
    ws.freeze_panes = "A2"

    total_rows = 0
    for row in rows:
        ws.append([
            row.get("POS", ""),
            row.get("NAME", ""),
            row.get("TYPE", ""),
            row.get("UNIT", ""),
            _as_number(row.get("QTY", "")),
            "",  # "Площадь" заполняет расчёт (area_calc.run_area_calc), не конвертер
        ])
        r = ws.max_row
        for c in range(1, len(_HEADERS) + 1):
            cell = ws.cell(row=r, column=c)
            if isinstance(cell.value, str):
                cell.data_type = "s"
            cell.alignment = _NAME_ALIGN if c == _NAME_COLUMN else _DATA_ALIGN
            cell.border = _CELL_BORDER
        total_rows += 1

    if conversion_info is not None:
        from spec_conversion import add_report
        add_report(wb, conversion_info)
    wb.save(output_path)
    return output_path, total_rows


def main():
    import argparse

    parser = argparse.ArgumentParser(
        description="PDF-спецификация -> Excel (формат инструмента Area)")
    parser.add_argument("pdf", help="путь к PDF-файлу спецификации")
    parser.add_argument("-o", "--output", default=None, help="путь для сохранения .xlsx")
    args = parser.parse_args()

    output_path, total_rows = convert_to_area(args.pdf, args.output)
    print(f"Готово: {total_rows} позиций -> {output_path}")


if __name__ == "__main__":
    main()
