"""Границы колонок по заголовкам и линиям PDF, без координат проекта."""

_FIELDS = {
    'поз.': 'POS', 'поз': 'POS', 'позиция': 'POS',
    'наименование': 'NAME', 'тип,': 'TYPE', 'тип': 'TYPE',
    'код': 'CODE', 'поставщик': 'VENDOR', 'завод': 'VENDOR',
    'завод-изготовитель': 'VENDOR',
    'ед.': 'UNIT', 'ед': 'UNIT', 'единица': 'UNIT',
    'кол.': 'QTY', 'коли-': 'QTY', 'количество': 'QTY',
    'коли-чество': 'QTY', 'количе-ство': 'QTY', 'кол-во': 'QTY',
    'масса': 'MASS', 'примечание': 'NOTE',
}
_REQUIRED = {'NAME', 'UNIT', 'QTY'}


def vertical_rules(page):
    result = []
    for drawing in page.get_drawings():
        for item in drawing.get('items', ()):
            if item[0] == 'l':
                a, b = item[1:3]
                if abs(a.x - b.x) < 1 and abs(a.y - b.y) > 3:
                    result.append(((a.x + b.x) / 2, min(a.y, b.y), max(a.y, b.y)))
            elif item[0] == 're':
                rect = item[1]
                if rect.width < 3 and rect.height > 3:
                    result.append(((rect.x0 + rect.x1) / 2, rect.y0, rect.y1))
    return result


def detect_columns(page, words):
    """Подтверждённая шапкой и вертикальной сеткой раскладка или None."""
    candidates = [(field, w) for w in words
                  for field in [_FIELDS.get(w[4].strip().lower())]
                  if field and w[1] < page.rect.height * .3]
    for field, anchor in candidates:
        if field != 'NAME':
            continue
        nearby = [(f, w) for f, w in candidates if abs(w[1] - anchor[1]) < max(30, 3 * (anchor[3] - anchor[1]))]
        if not _REQUIRED.issubset(f for f, _ in nearby):
            continue
        rules = vertical_rules(page)
        bounds, missing = {}, {}
        for field, word in nearby:
            center, y = (word[0] + word[2]) / 2, (word[1] + word[3]) / 2
            xs = sorted({round(x, 1) for x, top, low in rules if top <= y + 2 and low >= y - 2})
            left = max((x for x in xs if x < center), default=None)
            right = min((x for x in xs if x > center), default=None)
            if left is None or right is None:
                missing[field] = word
            else:
                bounds[field] = (left, right)
        if not _REQUIRED.issubset(bounds):
            continue
        # На продолжении таблицы внешняя рамка бывает не нарисована.
        # Крайние графы известны по заголовку; внутренние не угадываем.
        if 'POS' in missing:
            bounds['POS'] = (0, bounds['NAME'][0])
        if 'NOTE' in missing and 'MASS' in bounds:
            bounds['NOTE'] = (bounds['MASS'][1], page.rect.width)
        # Непредставленные графы (например, «Код» в 8-колоночной таблице)
        # остаются пустыми, а не заимствуют данные соседнего столбца.
        for field in set(_FIELDS.values()):
            bounds.setdefault(field, (0, 0))
        active = sorted((a, b, f) for f, (a, b) in bounds.items() if b > a)
        if any(b > next_a + 1 for (_a, b, _f), (next_a, _b, _g) in zip(active, active[1:])):
            continue
        return bounds
    return None


def table_extent(page, bounds):
    """Вертикальные границы таблицы по бокам графы наименования."""
    edges = bounds['NAME']
    matching = [(top, low) for x, top, low in vertical_rules(page)
                if any(abs(x - edge) < 3 for edge in edges)]
    if not matching:
        return None
    return min(top for top, _ in matching), max(low for _, low in matching)


def header_bottom(page, words, bounds):
    """Конец шапки по горизонтальной линии под названиями столбцов."""
    anchors = [w for w in words if _FIELDS.get(w[4].strip().lower()) == 'NAME'
               and bounds['NAME'][0] <= (w[0] + w[2]) / 2 < bounds['NAME'][1]
               and w[1] < page.rect.height * .3]
    if not anchors:
        return None
    anchor = min(anchors, key=lambda w: w[1])
    height = anchor[3] - anchor[1]
    labels = [w for w in words if _FIELDS.get(w[4].strip().lower())
              and abs(w[1] - anchor[1]) < max(30, height * 3)]
    end = max(w[3] for w in labels)
    left, right = bounds['NAME']
    lines = []
    for drawing in page.get_drawings():
        for item in drawing.get('items', ()):
            if item[0] == 'l':
                a, b = item[1:3]
                if abs(a.y - b.y) < 1 and min(a.x, b.x) <= left + 5 and max(a.x, b.x) >= right - 5:
                    lines.append((a.y + b.y) / 2)
            elif item[0] == 're':
                rect = item[1]
                if rect.height < 3 and rect.x0 <= left + 5 and rect.x1 >= right - 5:
                    lines.append((rect.y0 + rect.y1) / 2)
    below = sorted(y for y in lines if y >= end - 1)
    if not below:
        return end + 1
    bottom = below[0]
    # Нумерация граф под шапкой — отдельная служебная строка, не позиция.
    digits = [w for w in words if bottom <= w[1] < bottom + height * 3
              and w[4] in {'1','2','3','4','5','6','7','8','9'}]
    rows = []
    for word in sorted(digits, key=lambda w: w[1]):
        if not rows or word[1] - rows[-1][0][1] > height * .3:
            rows.append([])
        rows[-1].append(word)
    for row in rows:
        numbered_columns = {f for f, (lo, hi) in bounds.items()
                            if any(lo <= (w[0] + w[2]) / 2 < hi for w in row)}
        if len(numbered_columns) >= 5:
            last = max(w[3] for w in row)
            bottom = next((y for y in below if y >= last - 1), last + 1)
            break
    return bottom


class _VisiblePage:
    """Координаты текста и линий в ориентации, которую видит пользователь."""
    def __init__(self, page):
        self.page = page
        self.rect = page.rect

    def get_text(self, kind):
        import fitz
        matrix = self.page.rotation_matrix
        return [tuple(fitz.Rect(w[:4]) * matrix) + tuple(w[4:])
                for w in self.page.get_text(kind)]

    def get_drawings(self):
        matrix = self.page.rotation_matrix
        result = []
        for drawing in self.page.get_drawings():
            items = []
            for item in drawing.get('items', ()):
                if item[0] == 'l':
                    items.append(('l', item[1] * matrix, item[2] * matrix))
                elif item[0] == 're':
                    items.append(('re', item[1] * matrix) + tuple(item[2:]))
            result.append({'items': items})
        return result


def visible_page(page):
    return _VisiblePage(page) if page.rotation else page


def service_text_lines(page):
    """Строки накладных штампов отдельно от текста таблицы под ними."""
    import re
    import fitz
    lines = []
    # Одинаковые флаги с get_text("words"): изображения не должны
    # сдвигать номера текстовых блоков между двумя представлениями.
    for block in page.get_text('dict', flags=fitz.TEXTFLAGS_WORDS).get('blocks', ()):
        for number, line in enumerate(block.get('lines', ())):
            text = ''.join(span['text'] for span in line.get('spans', ())).strip()
            lines.append((block['number'], number, line['bbox'], text))
    anchors = [line for line in lines if re.match(
        r'^\s*(?:В\s+производство\s+работ\b|Архивный\s*№)', line[3], re.I)]
    if not anchors:
        return set()
    frames = [d['rect'] for d in page.get_drawings() if d.get('rect') is not None]
    def placeholder(text):
        return bool(text == 'ФИО' or ('___' in text and
                    re.fullmatch(r'[\s_«»".\-<>\dгГ/]+', text)))
    def archive_id(text):
        return bool(re.fullmatch(r'[А-ЯA-Z]{1,8}\d[А-ЯA-Z\d.\-]+', text))
    annotations = [line for line in lines if placeholder(line[3]) or archive_id(line[3])]
    excluded = set()
    zones = []
    for line in anchors:
        x0, y0, x1, y1 = line[2]
        enclosing = [r for r in frames if r.x0 <= x0 and r.y0 <= y0
                     and r.x1 >= x1 and r.y1 >= y1
                     and r.width * r.height < page.rect.width * page.rect.height * .1]
        if enclosing:
            rect = min(enclosing, key=lambda r: r.width * r.height)
            zone = tuple(rect)
        else:
            zone = (x0 - 25, y0 - 5, x1 + 25, y1 + 40)
        # Одноимённое настоящее примечание не удаляется без подписи,
        # шаблона даты или архивного номера рядом с заголовком штампа.
        if not any(zone[0] <= (other[2][0] + other[2][2]) / 2 <= zone[2]
                   and zone[1] <= (other[2][1] + other[2][3]) / 2 <= zone[3]
                   for other in annotations):
            continue
        excluded.add((line[0], line[1]))
        zones.append(zone)
    for block, number, bbox, text in annotations:
        cx, cy = (bbox[0] + bbox[2]) / 2, (bbox[1] + bbox[3]) / 2
        if any(a <= cx <= c and b <= cy <= d for a, b, c, d in zones):
            excluded.add((block, number))
    return excluded
