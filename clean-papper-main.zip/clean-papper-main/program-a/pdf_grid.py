# -*- coding: utf-8 -*-
"""
Чтение табличных листов PDF по линиям сетки.

Отличие от pdf_to_spec.py: там таблица восстанавливается по координатам
слов и подобранным под конкретный шаблон границам столбцов (порогам
переноса строк), потому что тому конвертеру нужны ВСЕ позиции
спецификации до единой, включая переносы длинных наименований. Здесь
задача уже другая — из альбома нужны только строки про вентиляторы, зато
листы бывают самые разные (ХСОВ, спецификация, листы подбора из разных
альбомов), и хардкодить границы столбцов под каждый нельзя.

Поэтому таблица читается от сетки: вертикальные и горизонтальные линии,
которыми нарисована рамка таблицы, дают границы столбцов и строк, а
слова просто раскладываются по получившимся ячейкам. Границы столбцов при
этом не нужно подбирать вручную — они берутся из самого листа.

Линии в PDF бывают нарисованы и как отрезки ("l"), и как тонкие
прямоугольники ("re") — учитываются оба варианта. Разделители строк в
реальных альбомах часто рисуются НЕ одной длинной линией через всю
таблицу, а отдельным отрезком под каждой ячейкой (и прерываются там, где
ячейки объединены по вертикали) — поэтому граница строки определяется не
по длине одного отрезка, а по суммарной длине всех отрезков на одной
высоте (см. _coverage).
"""

import collections

import fitz  # PyMuPDF — только ради Point/Matrix при повороте страницы

# Минимальная суммарная длина линий (в долях от ширины/высоты страницы),
# при которой ряд отрезков на одной координате считается границей строки
# или столбца таблицы. Всё, что короче, — это рамка штампа, подчёркивания
# в подписях, обводка отдельных ячеек и прочая мелочь, не образующая
# сетки.
_MIN_COL_HEIGHT_FRACTION = 0.15
_MIN_ROW_WIDTH_FRACTION = 0.18

# Допуск (pt), внутри которого координаты линий считаются одной и той же
# линией. Граница ячейки почти всегда нарисована дважды — рамками двух
# соседних ячеек, и расходятся эти две линии на толщину рамки: в
# альбомах встречалось до 2pt. Без такого допуска между столбцами
# появлялись бы пустые столбцы-щели шириной в рамку. Настоящих столбцов
# уже такого размера не бывает (самый узкий из виденных — 19pt).
_LINE_TOLERANCE = 3.0

# Толщина, до которой отрезок считается прямым (горизонтальным или
# вертикальным), и минимальная длина отрезка, который вообще учитывается.
_STRAIGHT_TOLERANCE = 0.8
_MIN_SEGMENT = 5.0


def _segments(page, matrix):
    """Прямые отрезки страницы: (vertical, horizontal), где каждый
    элемент — (координата поперёк, начало, конец) вдоль своей оси.

    matrix — поворот страницы (см. read_table): у повёрнутых листов
    (/Rotate 90, обычный случай для альбомной вёрстки) и линии, и слова
    отдаются в неповёрнутых координатах, где столбцы таблицы идут не
    сверху вниз, а слева направо. Приводим всё к тому виду, в котором
    лист показывают читателю, иначе строки и столбцы поменяются местами.
    """
    vertical = []
    horizontal = []

    def add(x0, y0, x1, y1):
        start = fitz.Point(x0, y0) * matrix
        end = fitz.Point(x1, y1) * matrix
        x0, y0, x1, y1 = start.x, start.y, end.x, end.y
        if abs(x0 - x1) <= _STRAIGHT_TOLERANCE and abs(y0 - y1) >= _MIN_SEGMENT:
            vertical.append((x0, min(y0, y1), max(y0, y1)))
        elif abs(y0 - y1) <= _STRAIGHT_TOLERANCE and abs(x0 - x1) >= _MIN_SEGMENT:
            horizontal.append((y0, min(x0, x1), max(x0, x1)))

    for drawing in page.get_drawings():
        for item in drawing["items"]:
            kind = item[0]
            if kind == "l":
                a, b = item[1], item[2]
                add(a.x, a.y, b.x, b.y)
            elif kind == "re":
                rect = item[1]
                # Тонкий прямоугольник — это линия; толстый — рамка,
                # у которой линии все четыре стороны.
                if rect.width <= _STRAIGHT_TOLERANCE or rect.height <= _STRAIGHT_TOLERANCE:
                    add(rect.x0, rect.y0, rect.x1, rect.y1)
                else:
                    add(rect.x0, rect.y0, rect.x0, rect.y1)
                    add(rect.x1, rect.y0, rect.x1, rect.y1)
                    add(rect.x0, rect.y0, rect.x1, rect.y0)
                    add(rect.x0, rect.y1, rect.x1, rect.y1)

    return vertical, horizontal


def _coverage(spans):
    """Суммарная длина объединения отрезков (перекрытия не считаются
    дважды) — именно она, а не длина самого длинного отрезка, говорит,
    что линия тянется через всю таблицу."""
    total = 0.0
    current_start = None
    current_end = None
    for start, end in sorted(spans):
        if current_end is None or start > current_end:
            if current_start is not None:
                total += current_end - current_start
            current_start, current_end = start, end
        elif end > current_end:
            current_end = end
    if current_start is not None:
        total += current_end - current_start
    return total


def _grid_lines(segments, min_coverage):
    """Координаты линий сетки: группируем отрезки по координате поперёк
    оси (с допуском) и оставляем те группы, где суммарная длина отрезков
    набирает min_coverage. Возвращает (отсортированные координаты,
    {координата: [отрезки]}) — отрезки нужны, чтобы потом понять, где
    линия прервана (объединённая ячейка)."""
    buckets = collections.defaultdict(list)
    for across, start, end in segments:
        buckets[round(across, 1)].append((start, end))

    merged = {}
    for across in sorted(buckets):
        placed = None
        for existing in merged:
            if abs(existing - across) <= _LINE_TOLERANCE:
                placed = existing
                break
        if placed is None:
            merged[across] = list(buckets[across])
        else:
            merged[placed].extend(buckets[across])

    lines = sorted(c for c, spans in merged.items() if _coverage(spans) >= min_coverage)
    return lines, merged


class Table(object):
    """Таблица одного листа: границы столбцов/строк и текст ячеек.

    cell(row, col) — текст ячейки; пустая строка, если в ячейке ничего
    нет. is_merged_with_previous(row, col) — правда ли, что между этой
    строкой и предыдущей в этом столбце нет разделителя (ячейка
    объединена по вертикали: так в ХСОВ оформляют пары "рабочий/
    холодный резерв" — марка написана один раз на две строки).
    """

    def __init__(self, x_lines, y_lines, cells, row_separators, column_spans=None):
        self.x_lines = x_lines
        self.y_lines = y_lines
        self._cells = cells
        self._row_separators = row_separators
        self._column_spans = column_spans or {}

    def column_at(self, x):
        """Номер столбца, в который попадает координата, или None."""
        return _band(self.x_lines, x)

    def column_line_covers(self, col, y):
        """Доходит ли вертикальная линия, ограничивающая столбец слева, до
        высоты y.

        Этим отличаются разделители групп шапки от разделителей
        подстолбцов: группа ("Вентилятор", "Электродвигатель") нарисована
        одной ячейкой на несколько столбцов, и линии между этими
        столбцами начинаются ниже — уже под названием группы. Так границу
        группы можно найти по чертежу, не угадывая её по названиям
        столбцов, которые в каждом альбоме свои.
        """
        if col <= 0 or col >= len(self.x_lines):
            return True
        for start, end in self._column_spans.get(col, ()):
            if start - _LINE_TOLERANCE <= y <= end + _LINE_TOLERANCE:
                return True
        return False

    def group_first_column(self, col, y):
        """Первый столбец группы шапки, в которую входит столбец col на
        высоте y названия группы."""
        while col > 0 and not self.column_line_covers(col, y):
            col -= 1
        return col

    @property
    def n_rows(self):
        return max(0, len(self.y_lines) - 1)

    @property
    def n_cols(self):
        return max(0, len(self.x_lines) - 1)

    def cell(self, row, col):
        return self._cells.get((row, col), "")

    def row_text(self, row):
        return " ".join(self.cell(row, c) for c in range(self.n_cols)).strip()

    def is_merged_with_previous(self, row, col):
        if row <= 0 or col >= self.n_cols:
            return False
        return not self._row_separators.get((row, col), True)

    def find_column(self, *needles, **kwargs):
        """Номер столбца, в шапке которого встречается один из фрагментов
        (сравнение без регистра). Ищется по всей высоте листа, но
        возвращается самое верхнее совпадение — шапка всегда выше данных,
        а те же слова ("Тип", "Наименование") ниже встречаются и в
        данных.

        Пробелы и дефисы при сравнении отбрасываются: в узких столбцах
        заголовок переносят по слогам ("Кол. сис-тем", "Обозна-чение
        системы"), и искать по нему как есть бесполезно."""
        max_row = kwargs.get("max_row")
        best = None
        prepared = [_squeeze(needle) for needle in needles]
        for (row, col), text in self._cells.items():
            if max_row is not None and row > max_row:
                continue
            low = _squeeze(text)
            if any(needle in low for needle in prepared):
                if best is None or row < best[0]:
                    best = (row, col)
        return best[1] if best else None


def _squeeze(text):
    """Строка без пробелов, дефисов и регистра — для сравнения заголовков,
    которые в узких столбцах перенесены по слогам."""
    return "".join(ch for ch in (text or "").lower() if ch not in " \t\n-–—")


def _join_cell_lines(lines):
    """Склейка строк внутри одной ячейки. Внутри ячейки текст переносится
    как попало: "ROOF-H / 400 E4 30" — через пробел, а "ВОСК72Б- /
    056-00220 / -04-1-О- / У2" — без пробела, иначе марка развалится.
    Ориентир — дефис на стыке: он и означает перенос внутри слова."""
    out = ""
    for line in lines:
        if not out:
            out = line
        elif out.endswith("-") or line.startswith("-"):
            out += line
        elif (" " not in out and any(ch.isdigit() for ch in out)
                and (line[0].isdigit() or (line[0] in ",." and line[1:2].isdigit()))):
            # Марку переносят где придётся, в том числе посреди числа:
            # "ВР-80-70К-1" + "0,0-0,9Дн-...", "ВР-80-70К-8" +
            # ",0-1,05Дн-...", "...-11,00/" + "6-Лев0-У1". Пробел здесь
            # разорвал бы типоразмер пополам. Условие узкое (в накопленном
            # тексте нет пробелов, есть цифры, и продолжение начинается с
            # цифры), чтобы не склеивать так обычные слова наименования.
            out += line
        else:
            out += " " + line
    return out


def read_table(page, min_col_height_fraction=_MIN_COL_HEIGHT_FRACTION,
               min_row_width_fraction=_MIN_ROW_WIDTH_FRACTION):
    """Таблица листа или None, если сетки на листе нет (чертёж, титул)."""
    matrix = page.rotation_matrix
    vertical, horizontal = _segments(page, matrix)
    page_width = page.rect.width
    page_height = page.rect.height

    x_lines, x_spans = _grid_lines(vertical, page_height * min_col_height_fraction)
    y_lines, y_spans = _grid_lines(horizontal, page_width * min_row_width_fraction)

    # Меньше двух столбцов или двух строк — это не таблица.
    if len(x_lines) < 3 or len(y_lines) < 3:
        return None

    # Слова раскладываем по ячейкам, внутри ячейки — по строкам текста
    # (одна ячейка часто содержит несколько строк переноса).
    lines_in_cell = collections.defaultdict(lambda: collections.defaultdict(list))
    for x0, y0, x1, y1, word, _b, _l, _w in page.get_text("words"):
        rect = fitz.Rect(x0, y0, x1, y1) * matrix
        x0, y0, x1, y1 = rect.x0, rect.y0, rect.x1, rect.y1
        cx = (x0 + x1) / 2.0
        cy = (y0 + y1) / 2.0
        col = _band(x_lines, cx)
        row = _band(y_lines, cy)
        if col is None or row is None:
            continue
        lines_in_cell[(row, col)][round(y0, 0)].append((x0, word))

    cells = {}
    for key, by_line in lines_in_cell.items():
        rendered = []
        for line_y in sorted(by_line):
            words = [w for _x, w in sorted(by_line[line_y])]
            rendered.append(" ".join(words))
        text = _join_cell_lines(rendered).strip()
        if text:
            cells[key] = text

    # Есть ли разделитель между строкой row-1 и row в столбце col: если
    # горизонтальная линия на этой высоте не перекрывает столбец, ячейка
    # объединена по вертикали.
    separators = {}
    for row in range(1, len(y_lines) - 1):
        y = y_lines[row]
        spans = []
        for candidate, candidate_spans in y_spans.items():
            if abs(candidate - y) <= _LINE_TOLERANCE:
                spans.extend(candidate_spans)
        for col in range(len(x_lines) - 1):
            left, right = x_lines[col], x_lines[col + 1]
            inner_left = left + min(2.0, (right - left) / 4.0)
            inner_right = right - min(2.0, (right - left) / 4.0)
            separators[(row, col)] = any(
                start <= inner_left and end >= inner_right for start, end in spans)

    # Вертикальные отрезки каждой границы столбца — по ним видно, до
    # какой высоты она доходит (см. Table.column_line_covers).
    column_spans = {}
    for col, x in enumerate(x_lines):
        spans = []
        for candidate, candidate_spans in x_spans.items():
            if abs(candidate - x) <= _LINE_TOLERANCE:
                spans.extend(candidate_spans)
        column_spans[col] = spans

    return Table(x_lines, y_lines, cells, separators, column_spans)


def _band(lines, value):
    """Номер промежутка между линиями, в который попадает координата."""
    if not lines or value < lines[0] or value >= lines[-1]:
        return None
    low, high = 0, len(lines) - 1
    while low < high - 1:
        mid = (low + high) // 2
        if lines[mid] <= value:
            low = mid
        else:
            high = mid
    return low
