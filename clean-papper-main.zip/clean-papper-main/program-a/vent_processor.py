# -*- coding: utf-8 -*-
"""
ОБРАБОТЧИК СПЕЦИФИКАЦИИ ВЕНТИЛЯЦИИ — ядро (для GUI).

Это рефакторинг исходной «блочной» программы (V1.5-без-крепежа):
вся вычислительная логика сохранена один-в-один, убраны только:
  - код Google Colab (files.upload / files.download);
  - вызов input() при выборе базы 1С (теперь выбор передаётся параметром);
  - запуск обработки на уровне модуля (теперь это функция run_processing).

print(...) заменён на _log(...), чтобы интерфейс мог перехватывать вывод.
Сами формулы, регулярные выражения и расчёты площадей НЕ менялись.
"""

import re
import math
import csv
import os
import sys
import time
import gc
import datetime
from collections import defaultdict, Counter
from functools import lru_cache

from openpyxl import load_workbook, Workbook
from openpyxl.styles import PatternFill, Alignment, Font, Border, Side
from openpyxl.utils import get_column_letter, column_index_from_string

# common/ живёт в корне репозитория, на уровень выше этой папки (program-a/).
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

# ────────────────────────────────────────────────────────────────────
# ОБЩИЙ КОД С matching_system (common/) — V2.0.
#
# Извлечение параметров, категоризация, геометрический/КПВ/fuzzy/wordset
# матч и расчёт площади фасонных изделий перенесены в common/ — единый источник
# истины для обеих программ вместо двух расходящихся копий. Логика НЕ
# ИЗМЕНЕНА: перенос проверен дифференциальными тестами против этой самой
# версии файла (common/tests/, 0 расхождений). Имена импортов совпадают
# со старыми локальными именами, поэтому весь остальной код ниже (парсинг
# строк спецификации, формулы столбцов, форматирование) не тронут.
# ────────────────────────────────────────────────────────────────────
from common.parameters import (
    normalize,
    normalize_diameter_tokens,
    normalize_workshop_shorthand,
    extract_sections as extract_and_normalize_sections,
    extract_angle as _extract_angle,
    extract_geometry as extract_full_geometry,
)
from common.matcher import determine_category, NomenclatureIndex, validate_other_category_dimensions, strip_assembly_membership_note
from common.hybrid_matcher import build_hybrid_matcher_from_items
from common.anthropic_client import AnthropicClient, AnthropicError
from common.claude_matcher import ClaudeMatcher, PROMPT_SPEC, SHORTLIST_SIZE
from common.report import write_report_sheet, write_report_file, default_report_path
from common.header_style import HEADER_FILL_BY_COLUMN, HEADER_COLUMN_GROUPS, DATA_FILL_BY_COLUMN
from common.xlsx_values import save_numeric_cells
from common.area import (
    FasonkaMath,
    calculate_fitting_surface as _common_calculate_fitting_surface,
    get_fitting_type,
    is_fitting_row,
)

# Версия программы (показывается в интерфейсе).
# Схема: МАЖОР.МИНОР.ПАТЧ
#   • МАЖОР (1)  — поколение архитектуры;
#   • МИНОР (8)  — набор возможностей/интерфейс;
#   • ПАТЧ  (.N) — точечные доработки логики сравнения и расчёта внутри 1.8
#                  (без смены архитектуры и интерфейса).
#
# Журнал ПАТЧей линии 1.8:
#   1.8.0  Базовая 1.8: горизонтальный интерфейс, drag-and-drop, форматирование
#          вывода, матчинг по набору слов и нормализация диаметров.
#   1.8.1  Толщина воздуховодов читается через δ («δ=0.8»); угол отвода 90° по
#          умолчанию, если не указан явно.
#   1.8.2  Жёсткая сверка противопожарных клапанов КПВ: модель + предел EI
#          (EI60/EI90) + режим НО/НЗ обязаны совпадать.
#   1.8.3  Запрет переворота сечений: ориентация строго сохраняется для
#          воздуховодов, тройников и крестовин («400х200» ≠ «200х400»).
#   1.8.4  Исправлен разбор угла отвода без «°»: голое «90» больше не попадает
#          в сечения как ложный диаметр.
#   1.8.5  Толщина и длина — строгие критерии для всех типов (ослабление
#          разрушает правильность). Разрешены только два безопасных послабления:
#          у перехода — порядок концов (XxY-ZxK = ZxK-XxY), у заглушки —
#          ориентация пары (XxY = YxX).
#   1.8.6  Колонка «Кол-во м2 по СПЕКЕ» теперь распознаётся по корню «СПЕК»
#          (раньше — только «СПЕКА»/«СПЕЦ»), поэтому площадь больше не уходит
#          в неё, а заполняет «Кол-во кв.м» и «Кол-во кв.м СМЕТА». Запись
#          площади устойчива к отсутствию какого-либо из столбцов площади.
#   1.8.7  Полная сверка клапанов КПВ по коду (11 полей: модель+EI, НО/НЗ,
#          К/С, сечение с ориентацией, привод MBE/MBF/ЭМ, напряжение, СН/ВН,
#          поля 7-9, ЗК). Прямой перебор кандидатов по полям, нормализация
#          кириллических букв-двойников в приводе («МBE»=«MBE»), EI120.
#          КИД пока не обрабатывается.
#   1.8.8  Расширение покрытия сверки при сохранении правильности (проверено на
#          двух эталонных спецификациях, 3108 строк: TP 56.8%→60.8%,
#          неверных матчей 367→274). Изменения:
#          • Защита типоразмера крепежа/изоляции: М8≠М10, №20≠№30,
#            DIN933≠DIN934, Ø8≠Ø10 — кандидат с другим размером отвергается
#            (устранены подмены «Шайба М8→М10», «Гайка М8→М12», «Шина №20→№30»).
#          • Защита типа оборудования: тип спеки обязан совпасть с типом
#            кандидата («Дроссель-клапан» ≠ «Клапан воздушный»; ДРОССЕЛЬ=ДК).
#          • Защита от матча по слишком общей спеке: если нет размера И меньше
#            двух различающих слов — не матчим («Декоративная решетка» без марки
#            и размера больше не цепляет чужую решётку).
#          • Категоризация пополнена по эталонам: крепёж — ПРОВОЛОКА, ШТРИПС,
#            ШТИФТ, ДЮБЕЛЬ, КРОНШТЕЙН, ОПОРА; материалы — ГРУНТОВКА,
#            РАСТВОРИТЕЛЬ, КЛЕЙ, ГВОЗДИ (раньше уходили в «не определено» и не
#            искались вовсе).
#          • Длина обязательна для воздуховода: если в спеке нет L=, сравнения
#            нет (произвольную длину подставлять нельзя). Отвода/заглушки/
#            тройника/перехода не касается.
#   1.8.9  Исправлено сопоставление формы (круг ≠ прямоугольник). Проверка
#          диаметра больше не засчитывает число, стоящее внутри пары AxB: круглая
#          сетка/деталь Ø100 больше не совпадает с прямоугольной 200х100 (там
#          есть «100», но это высота прямоугольника, а не диаметр). Круглое
#          матчится только с настоящим диаметром кандидата.
#   1.8.10 Симметричная жёсткая сверка КПВ. Раньше проверялось только «поля
#          спеки есть у кандидата»; теперь набор различающих полей обязан
#          совпасть в обе стороны. Закрывает два дефекта: (1) кандидат с ЛИШНИМ
#          полем (спека …-ВН-К, база …-ВН-СЛ-К «Виктория») больше не проходит;
#          (2) кандидат с НЕПОЛНОЙ маркировкой (нет привода/напряжения, которые
#          есть в спеке) тоже отвергается. Поле 11 (К/КК) и бренд не различающие.
#   1.9.1  Сверка всей математики площади фасонных изделий с калькулятором-источником
#          wentprom.ru/software (18 контрольных замеров). Подтверждено, что
#          методика источника перенесена верно: заглушка (борт по половине
#          периметра), переход круг↔прямоугольник (коэффициент 2.8) и
#          вычитание отверстия у тройника — НЕ ошибки, правке не подлежат.
#          Исправлены реальные дефекты переноса и разбора:
#          • Врезка прямоугольная: порядок аргументов был (A, L, B) вместо
#            (A, B, L) — сайт называет вторую сторону сечения «Длина, B»,
#            и в этот слот попадала длина патрубка. Завышение до x8.4
#            (медиана x3.2), 226 строк. Припуски +0.02/+0.04 убраны: замеры
#            показали, что у источника припуска нет.
#          • Составной переход «совместно с прямым участком» (73 строки):
#            размеры перехода искались по всей строке, из-за чего сечение
#            прямого участка подменяло второе сечение, а диаметр терялся.
#            Теперь переход и прямой участок считаются раздельно и
#            складываются. Занижение было медианно x2.0.
#          • Тройник «круглое на прямоугольное» (44 строки): формы не было,
#            прямоугольная врезка принималась за ствол. Добавлена
#            tee_round_rect_area; ствол определяется по порядку записи.
#          • Символ «⌀» (U+2300) приравнен к «Ø» — 80 строк давали 0.
#          • Утка прямоугольного сечения: формула восстановлена замерами.
#          • Врезка с воротником, круглая и прямоугольная: формулы
#            восстановлены замерами (в спецификациях этого проекта не
#            встречались, добавлены на будущее).
#          • Угол отвода вне набора 15/30/45/60/90 больше не считается как
#            90 — возвращается 0 (источник таких углов не считает).
#          • Защита от отрицательной площади (крупная врезка в тройнике).
#          Осознанные решения, зафиксированные при сверке: крестовина
#          считается как тройник по первым двум сечениям (формы у источника
#          нет), длина врезного патрубка 50 мм, длина перехода без явного
#          L= — 300 мм, врезка в плоский лист и пластина с врезкой — 0.
#          ВАЖНО: get_strict_type и determine_category НЕ менялись, все
#          правки замкнуты в модуле площади — на матчер влияния нет.
#   2.0.0  Извлечение параметров, матч (determine_category/find_1c_match/
#          КПВ/fuzzy/wordset) и расчёт площади (FasonkaMath) перенесены в
#          общий пакет common/ — тот же код теперь использует и
#          matching_system. Логика не менялась (сверено дифференциальными
#          тестами и полным прогоном run_processing: 0 расхождений на
#          9223 ячейках реальных данных). Архитектурный мажорный скачок —
#          отсюда 2.0.0, а не 1.9.2.
#   2.1.0  «Сравнение с 1С» получило Tier 2: если точный матч (Tier 1) не
#          находит совпадения, автоматически подключается нечёткий поиск
#          (BM25+fuzzy, common/hybrid_matcher.py) и предлагает лучшего
#          похожего кандидата — жёлтая заливка, неподтверждено, требует
#          проверки человеком (не путать с зелёным/без заливки — точным
#          совпадением). Кандидат с явно шумовым score (комментарий,
#          случайно попавший в колонку наименования) не предлагается
#          вовсе — см. TIER2_MIN_SCORE.
#   2.2.0  «Сравнение с 1С» и «Полная обработка» теперь всегда формируют
#          отчёт (common/report.py): точных/неподтверждённых/ненайденных
#          позиций, разбивка по категориям, для полной обработки — сумма
#          площади фасонных изделий. Место — на выбор в GUI: доп. лист «Отчёт» в
#          том же файле (по умолчанию) либо отдельный Excel-файл в папке
#          результатов (report_destination="sheet"/"folder"). Режим
#          «Расчёт площади фасонных изделий» отчёт не строит — базы 1С в нём нет.
VERSION = "2.2.0"


# ────────────────────────────────────────────────────────────────────
# ЛОГИРОВАНИЕ: интерфейс подменяет приёмник через set_logger()
# ────────────────────────────────────────────────────────────────────
_LOG_FN = print


def set_logger(fn):
    """Назначить функцию вывода (GUI передаёт сюда запись в текстовое поле)."""
    global _LOG_FN
    _LOG_FN = fn if callable(fn) else print


def _log(*args):
    _LOG_FN(" ".join(str(a) for a in args))


def _safe_save(wb, output_file, save=None):
    """
    Сохранить книгу. Если целевой файл занят (открыт в Excel → [Errno 13]
    Permission denied), сохранить рядом под именем «… (1).xlsx»,
    «… (2).xlsx» и т.д. Возвращает фактический путь сохранения.
    """
    save = save or wb.save
    try:
        save(output_file)
        return output_file
    except PermissionError:
        base, ext = os.path.splitext(output_file)
        for i in range(1, 100):
            alt = f"{base} ({i}){ext}"
            try:
                save(alt)
                _log(f"  ⚠️  Файл «{os.path.basename(output_file)}» занят "
                     f"(вероятно открыт в Excel). Результат сохранён как "
                     f"«{os.path.basename(alt)}».")
                return alt
            except PermissionError:
                continue
        # Все альтернативы тоже заняты — пробрасываем понятную ошибку
        raise PermissionError(
            f"Не удалось сохранить результат: файл «{os.path.basename(output_file)}» "
            f"и его копии заняты. Закройте файл в Excel и повторите.")


# ────────────────────────────────────────────────────────────────────
# КОНФИГУРАЦИЯ ЗАГОЛОВКОВ И СТИЛЕЙ (бывшая ячейка 4 — только определения)
# ────────────────────────────────────────────────────────────────────
HEADERS = {
    "A": "Позиция",
    "B": "Наименование и техническая характеристика",
    "C": "Тип, марка, обозначение документ, опросного листа",
    "D": "Код оборудования, изделия, материала",
    "E": "Завод изготовитель",
    "F": "Ед. измерения",
    "G": "Количество",
    "H": "Кол-во кв.м. СПЕКА",
    "I": "Наименование в 1С",
    "J": "Ед. измерения",
    "K": "Наименование системы",
    "L": "Примечание",
    "M": "ФАКТ",
    "N": "Кол-во шт.",
    "O": "Кол-во кв.м.",
    "P": "Кол-во м.п. СМЕТА",
    "Q": "Кол-во шт. СМЕТА",
    "R": "Кол-во кв. м.",
    "S": "Вспомогательный",
    "T": "Тех.подполье",
    "U": "1 этаж",
    "V": "2 этаж",
    "W": "3 этаж",
}

HEADER_FILL = PatternFill(start_color="DDEBF7", end_color="DDEBF7", fill_type="solid")
HEADER_FONT = Font(bold=True)
HEADER_BORDER = Border(
    left=Side(style="thin"), right=Side(style="thin"),
    top=Side(style="thin"), bottom=Side(style="thin"),
)
HEADER_ALIGN = Alignment(horizontal="center", vertical="center", wrap_text=True)

GREEN_FILL = PatternFill(start_color="C6E0B4", end_color="C6E0B4", fill_type="solid")
ORANGE_FILL = PatternFill(start_color="FFE699", end_color="FFE699", fill_type="solid")
GRAY_FILL = PatternFill(start_color="D9D9D9", end_color="D9D9D9", fill_type="solid")
YELLOW_FILL = PatternFill(start_color="FFF2CC", end_color="FFF2CC", fill_type="solid")
NO_FILL = PatternFill(fill_type=None)   # «нет заливки» (снимает существующую)

# Заливка ячейки «Наименование в 1С» (столбец I) по качеству совпадения —
# отдельные константы, а не переиспользование YELLOW_FILL/GRAY_FILL и
# т.п. выше: те цвета уже заняты построчной раскраской по категории
# (столбцы B..G), красить ими же столбец I означало бы либо совпадение
# по случайности, либо путаницу при будущей правке одного без другого.
# 100%-е совпадение (Tier 1) цвет ячейки не меняет вовсе — остаётся тот,
# что уже стоит там статично (см. common/header_style.py).
MATCH_TIER2_FILL = PatternFill(start_color="FAF091", end_color="FAF091", fill_type="solid")   # RGB(250,240,145) — подсказка Tier 2, требует проверки
MATCH_TIER3_FILL = PatternFill(start_color="C9D9F0", end_color="C9D9F0", fill_type="solid")   # RGB(201,217,240) — подсказка Tier 3 (Claude), требует проверки
MATCH_NONE_FILL = PatternFill(start_color="FACDBE", end_color="FACDBE", fill_type="solid")    # RGB(250,205,190) — совпадение не найдено

ALIGN_CENTER_WRAP = Alignment(horizontal="center", vertical="center", wrap_text=True)
ALIGN_LEFT_WRAP = Alignment(horizontal="left", vertical="center", wrap_text=True)


# ────────────────────────────────────────────────────────────────────
# ИНДЕКСАЦИЯ БАЗЫ 1С (ячейка 6)
# ────────────────────────────────────────────────────────────────────
ONS_CATALOG_NAME = "Номенклатура"
ONS_NAME_ATTR = "Наименование"
ONS_LOAD_LIMIT = 0
USE_CACHE = True

database_items = []
geo_index = None
text_index = None
_db_source = None
_db_loaded = False
_nomenclature_index = None   # common.matcher.NomenclatureIndex, строится в _build_indexes
_tier2_matcher = None        # common.hybrid_matcher.HybridMatcher (fuzzy fallback), строится там же
_tier3_matcher = None        # common.claude_matcher.ClaudeMatcher, подключается в run_processing (см. _setup_tier3)
_tier3_status = None         # почему Tier 3 не подключён — для отчёта; None, если его и не просили
_tier3_cache = {}            # {(spec_text, марка): db_name} — заполняется _prepare_tier3_matches ПЕРЕД циклом по строкам
_tier3_asked = set()         # ключи, уже отправленные в Claude за этот прогон (на любом листе книги)

# Книга/лист спецификации (устанавливаются в run_processing)
wb = None
ws = None


def _find_1c_bases_in_registry():
    try:
        import winreg
    except ImportError:
        return []
    bases = []
    reg_paths = [
        r"SOFTWARE\1C\1Cv8\InfoBases",
        r"SOFTWARE\WOW6432Node\1C\1Cv8\InfoBases",
        r"SOFTWARE\1C\1Cv82\InfoBases",
        r"SOFTWARE\WOW6432Node\1C\1Cv82\InfoBases",
    ]
    for hive in [winreg.HKEY_LOCAL_MACHINE, winreg.HKEY_CURRENT_USER]:
        for reg_path in reg_paths:
            try:
                key = winreg.OpenKey(hive, reg_path)
                i = 0
                while True:
                    try:
                        base_name = winreg.EnumKey(key, i)
                        base_key = winreg.OpenKey(key, base_name)
                        try:
                            path, _ = winreg.QueryValueEx(base_key, "Connect")
                        except FileNotFoundError:
                            path = ""
                        if not any(b["name"] == base_name for b in bases):
                            bases.append({"name": base_name, "path": path})
                        i += 1
                    except OSError:
                        break
                winreg.CloseKey(key)
            except OSError:
                continue
    return bases


def find_1c_bases():
    """Публичная обёртка для GUI: список найденных баз 1С (может быть пустым)."""
    try:
        return _find_1c_bases_in_registry()
    except Exception:
        return []


def _build_com_connection_string(base_info):
    path = base_info.get("path", "")
    if path.startswith("File=") or path.startswith("Srvr="):
        return path
    if path and os.path.isdir(path):
        return f'File="{path}"'
    return None


def _connect_com_1c(connection_string):
    try:
        import pythoncom  # noqa: F401
        import win32com.client as win32
    except ImportError:
        return None, "Библиотека pywin32 не установлена."
    last_error = ""
    for progid in ["V83.COMConnector", "V82.COMConnector"]:
        try:
            connector = win32.Dispatch(progid)
            connection = connector.Connect(connection_string)
            return connection, None
        except Exception as e:
            last_error = str(e)
            continue
    return None, f"Не удалось подключиться ({last_error})."


def _load_from_com(connection):
    names = []
    try:
        catalog = connection.Catalogs[ONS_CATALOG_NAME]
        selection = catalog.Select()
        count = 0
        while selection.Next():
            try:
                if selection.IsFolder:
                    continue
            except Exception:
                pass
            try:
                name = str(getattr(selection, ONS_NAME_ATTR, "") or "").strip()
            except Exception:
                name = ""
            if name:
                names.append(name)
                count += 1
                if ONS_LOAD_LIMIT > 0 and count >= ONS_LOAD_LIMIT:
                    break
    except Exception as e:
        _log(f"  ⚠️  Ошибка чтения справочника (данные 1С не затронуты): {e}")
    return names


def _load_names_from_file(path):
    names = []
    if path.lower().endswith(".csv"):
        for encoding in ["utf-8-sig", "cp1251", "utf-8"]:
            try:
                with open(path, newline="", encoding=encoding) as f:
                    sample = f.read(2048)
                    f.seek(0)
                    delimiter = ";" if sample.count(";") >= sample.count(",") else ","
                    reader = csv.reader(f, delimiter=delimiter)
                    for row in reader:
                        if len(row) >= 2:
                            name = str(row[1]).strip()
                            if name and name.lower() != "наименование":
                                names.append(name)
                break
            except (UnicodeDecodeError, Exception):
                names = []
                continue
    else:
        db_wb = load_workbook(path, data_only=True, read_only=True)
        db_ws = db_wb.active
        first = True
        for row in db_ws.iter_rows(min_row=1, values_only=True):
            if first:
                first = False
                continue
            if len(row) >= 2 and row[1]:
                name = str(row[1]).strip()
                if name:
                    names.append(name)
        db_wb.close()
    return names


def _build_indexes(names):
    """
    Индексация — теперь common.matcher.NomenclatureIndex (V2.0). Строит тот
    же геометрический/текстовый индекс, что и раньше (совпадает 1-в-1, см.
    common/tests/test_matcher.py), но хранит записи как объекты индекса,
    а не голые строки — geo_index/text_index остаются доступны как атрибуты
    _nomenclature_index для обратной совместимости логов ниже.
    """
    global database_items, geo_index, text_index, _nomenclature_index, _tier2_matcher
    items = [{"original": n} for n in names if n]
    _nomenclature_index = NomenclatureIndex(items, name_key="original")
    database_items = _nomenclature_index.items
    geo_index = _nomenclature_index.geo_index
    text_index = _nomenclature_index.text_index

    # Tier 2 (V2.1) — fuzzy fallback для строк, где точный матч (Tier 1)
    # ничего не находит. Строится из того же списка names, что и Tier 1 —
    # без файла, без сети (keyword+fuzzy).
    # Ошибка здесь не должна ронять загрузку базы — это дополнение, не ядро.
    try:
        tier2_items = [{"code": str(i), "name": n, "search_text": n} for i, n in enumerate(names) if n]
        _tier2_matcher = build_hybrid_matcher_from_items(tier2_items, log=_log)
    except Exception as exc:
        _log(f"  ⚠️  Tier 2 (подсказки при отсутствии точного совпадения) не собран: {exc}")
        _tier2_matcher = None


def _print_category_stats(items):
    cat_names = {0: "Не определено", 1: "Оборудование", 2: "Воздуховоды",
                 3: "Фасонные изделия", 4: "Изоляция/прочее", 5: "Крепёж"}
    counts = Counter(item["category"] for item in items)
    _log("  Распределение по категориям:")
    for cat in sorted(counts.keys()):
        label = cat_names.get(cat, f"Кат.{cat}")
        bar = "█" * min(counts[cat] // 500, 30)
        _log(f"    [{cat}] {label:<18} {counts[cat]:>6} шт.  {bar}")


def load_database(db_file_path=None, force_reload=False, use_com=True, selected_base=None):
    """
    Загрузка и индексация базы 1С.
    selected_base — словарь {'name','path'} (для GUI). Если None и баз
    несколько, берётся первая (без input()).
    Tier 3 (Claude) от базы не зависит и подключается отдельно — см.
    _setup_tier3: кандидатов ему отбирает Tier 2 из этой же базы.
    """
    global _db_source, _db_loaded, _tier3_cache
    if _db_loaded and USE_CACHE and not force_reload:
        _log(f"✅ База уже загружена ({len(database_items)} позиций, источник: {_db_source}).")
        return

    _db_source = None
    _db_loaded = False
    names = []

    if use_com:
        _log("🔍 Поиск баз 1С на компьютере...")
        try:
            bases = _find_1c_bases_in_registry()
        except Exception:
            bases = []
        if not bases:
            _log("  ℹ️  Базы 1С не найдены — переход к файловому режиму.")
        else:
            _log(f"  Найдено баз: {len(bases)}")
            if selected_base is not None:
                sel = selected_base
            else:
                sel = bases[0]
            _log(f"  Выбрана база: {sel['name']}")
            conn_str = _build_com_connection_string(sel)
            if conn_str:
                _log(f"  Подключение к [{sel['name']}] ...")
                connection, error = _connect_com_1c(conn_str)
                if connection:
                    _log(f"  ✅ COM-подключение (чтение). Загрузка «{ONS_CATALOG_NAME}»...")
                    try:
                        names = _load_from_com(connection)
                        _db_source = "com"
                        _log(f"  Получено наименований: {len(names)}")
                    finally:
                        try:
                            del connection
                            gc.collect()
                        except Exception:
                            pass
                else:
                    _log(f"  ⚠️  COM недоступен: {error}")

    if not names:
        if not db_file_path or not os.path.exists(db_file_path):
            _log(f"❌ COM недоступен и файл базы не найден: {db_file_path}")
            return
        _log(f"📂 Загрузка из файла: {os.path.basename(db_file_path)} ...")
        names = _load_names_from_file(db_file_path)
        _db_source = "file"
        _log(f"  Прочитано наименований: {len(names)}")

    if not names:
        _log("❌ База пустая. Проверьте источник данных.")
        return

    _log("⚙️  Индексация с предпарсингом...")
    t0 = time.time()
    _build_indexes(names)

    _tier3_cache = {}
    find_1c_match_with_tier.cache_clear()  # старые результаты относились к прошлой базе
    _tier1_exact.cache_clear()
    dt = time.time() - t0
    _db_loaded = True

    _log("=" * 50)
    _log(f"✅ База проиндексирована: {len(database_items)} позиций за {dt:.1f} сек")
    _log(f"   Источник: {'COM (живая 1С)' if _db_source == 'com' else 'Файл'}")
    _log(f"   Геометрических групп: {len(geo_index)}")
    _print_category_stats(database_items)
    _log("=" * 50)


def get_database_status():
    if not _db_loaded:
        return "База не загружена"
    return f"База загружена: {len(database_items)} позиций | Источник: {'1С (COM)' if _db_source == 'com' else 'Файл'}"


# ────────────────────────────────────────────────────────────────────
# ПОИСК СОВПАДЕНИЙ И ПЛОЩАДЬ ФАСОННЫХ ИЗДЕЛИЙ — common.matcher / common.area (V2.0)
#
# Вся логика (геометрический/КПВ/fuzzy/wordset матч, формулы площади)
# перенесена в common/ — см. импорты в начале файла. Здесь только тонкие
# обёртки, сохраняющие прежние сигнатуры и подключающие GUI-логирование
# (_log), чтобы run_processing/parse_fitting ниже не пришлось менять.
# ────────────────────────────────────────────────────────────────────
def find_1c_match(spec_text, spec_model, spec_category):
    """Точный матч по индексу базы 1С. Возвращает найденное наименование
    (строку) либо None — как и раньше, для обратной совместимости.
    Только Tier 1 — без fuzzy-подсказок; для них см. find_1c_match_with_tier."""
    if not spec_text or _nomenclature_index is None:
        return None
    item = _nomenclature_index.find_exact(spec_text, spec_model, spec_category)
    return item["original"] if item else None


#  Порог отсечки Tier 2 по score. Подобран по распределению реальных
#  запросов: строки-комментарии, случайно попавшие в спецификацию вместо
#  наименования («Схема с отметками до 23 этажа…», «Отсутствует сетка…»),
#  стабильно получают score ≤0.02 — это шум BM25 на случайном пересечении
#  редких слов, не осмысленное совпадение. Осмысленные кандидаты (даже
#  слабые) начинаются от ~1.0. Было 0.1 — на практике оказалось слишком
#  мягко (в т.ч. из-за бага буста по подстроке "воздуховод", см. историю
#  разговора): пропускало явно чужую категорию с завышенным score.
#  Поднято до 0.3 — отсекает больше шума, оставляя только более уверенные
#  кандидаты.
TIER2_MIN_SCORE = 0.3


@lru_cache(maxsize=None)
def _tier1_exact(spec_text, spec_model, spec_category):
    """Точный матч Tier 1 (наименование базы или None) с кэшем: его зовут
    и пред-проход Tier 3 (решить, нужен ли Claude), и основной цикл через
    find_1c_match_with_tier — без кэша одна и та же строка, повторённая
    на десятке этажей, считалась бы заново в каждом из них. Кэш
    сбрасывается вместе с find_1c_match_with_tier в load_database."""
    if _nomenclature_index is None:
        return None
    item = _nomenclature_index.find_exact(spec_text, spec_model, spec_category)
    return item["original"] if item else None


def _tier3_key(spec_text, spec_model):
    """Ключ ответа Tier 3: наименование вместе с «Тип, марка». Claude видит
    обе графы, и одно наименование с разными марками («Вентилятор
    канальный» + «ВКК 200» / «ВКК 315») — разные позиции базы."""
    mark = "" if spec_model is None else str(spec_model).strip()
    return spec_text, mark


@lru_cache(maxsize=None)
def find_1c_match_with_tier(spec_text, spec_model, spec_category, top_k_candidates=3):
    """
    Матч с fallback (V2.1) + Tier 3: сначала точный (Tier 1) — как
    find_1c_match. Если он ничего не нашёл, проверяется Tier 3
    (подсказка Claude, если он подключён и уже ответил по этой строке —
    см. _prepare_tier3_matches, вызывается пачкой на лист ПЕРЕД основным
    циклом по строкам, не отсюда). Если и Tier 3 не дал ответа, берётся
    лучший fuzzy-кандидат Tier 2 — но только если его score выше
    TIER2_MIN_SCORE (иначе это не подсказка, а шум, и лучше честно ничего
    не предлагать).
    Возвращает (наименование_или_None, tier): 1 — точное совпадение,
    3 — подсказка Claude (приоритет выше Tier 2: модель сравнила строку
    с кандидатами по марке и характеристикам, и ответ дополнительно
    проверен против размеров/типа — см. validate_other_category_dimensions
    в _prepare_tier3_matches), 2 — неподтверждённая подсказка Tier 2,
    0 — не найдено вовсе. Вызывающий код (run_processing) красит ячейку
    по tier — синим для 3, жёлтым для 2, красным для 0.

    @lru_cache (V2.4, ускорение) — та же тройка (текст, модель, категория)
    почти всегда даёт тот же результат: база 1С не меняется в рамках одной
    обработки, а в реальных спецификациях одинаковые позиции (типовая
    фасонные изделия/воздуховод) повторяются на разных этажах десятками раз. Кэш
    сбрасывается в load_database() при каждой (пере)загрузке базы —
    результат никогда не переживает смену базы, только процесс всё ещё
    ссылается на её саму. _tier3_cache по тому же ключу всегда
    возвращает один и тот же ответ в рамках одного прогона (заполняется
    до цикла по строкам и только дополняется), так что кэшировать его
    здесь тоже безопасно; _setup_tier3 сбрасывает кэш в начале прогона.
    """
    if not spec_text:
        return None, 0
    tier1_name = _tier1_exact(spec_text, spec_model, spec_category)
    if tier1_name is not None:
        return tier1_name, 1
    # Воздуховоды/фасонные изделия (2/3) — Tier 2 туда не зовём вообще: Tier 3 для
    # них и так исключён (см. _prepare_tier3_matches), а Tier 2
    # категорийно-слепой — находил
    # воздуховод "похожим" на утеплитель или фланец просто по общим
    # словам. Для этих категорий надёжна только геометрия Tier 1; если он
    # не нашёл — честно "не найдено", а не текстовый шум вместо ответа.
    if spec_category in (2, 3):
        return None, 0
    tier3_name = _tier3_cache.get(_tier3_key(spec_text, spec_model))
    if tier3_name is not None:
        return tier3_name, 3
    if _tier2_matcher is None:
        return None, 0
    # strip_assembly_membership_note — см. common/matcher.py: хвост
    # "в составе вентиляционной установки <код>" не идентифицирует
    # позицию, только зашумляет BM25-релевантность коротких точных
    # наименований в базе.
    stripped_spec_text = strip_assembly_membership_note(spec_text)
    results = _tier2_matcher.search(stripped_spec_text, top_k=top_k_candidates)
    # Tier 2 сам никак не проверяет ТИП/РАЗМЕР оборудования — текстово
    # похожий кандидат другого типа или без совпадающего размера мог
    # набрать достаточный score и пройти. validate_other_category_dimensions
    # — та же проверка, что уже страхует Tier 3 (equipment_type_ok +
    # конфликт типоразмера + совпадение прямоугольных сечений/диаметров) —
    # здесь применяем её и к Tier 2: перебираем кандидатов по убыванию
    # score, пропуская тех, чей тип или размер не совпадает, вместо того
    # чтобы слепо брать первого. Раньше здесь была только equipment_type_ok
    # (без проверки размера) — после того как strip_assembly_membership_note
    # стал давать короче/чище запрос, этого перестало хватать: короткая
    # обрезанная спека («Фильтр кассетный ... 300x150») набирала высокий
    # score против кандидата без единого совпадающего числа («Фильтр
    # воздушный для мотора Форд Транзит») — только equipment_type_ok такое
    # пропускал, только полная проверка размеров ловит корректно.
    # Порог TIER2_MIN_SCORE по-прежнему действует — как только у кандидата
    # score ниже него, дальше по списку (отсортированному по убыванию)
    # тоже ничего не наберёт.
    for candidate, score, _scores_dict in results:
        if score < TIER2_MIN_SCORE:
            break
        if not validate_other_category_dimensions(spec_text, candidate["name"]):
            continue
        return candidate["name"], 2
    return None, 0


# Предохранитель числа запросов к Claude за один прогон: 100 пачек по
# ROWS_PER_REQUEST строк — это 2500 строк без точного совпадения, больше,
# чем бывает в реальной спецификации. Сверх него строки остаются без
# Tier 3 (с пометкой в отчёте), а не уходят в модель бесконечно.
TIER3_MAX_REQUESTS = 100


def _setup_tier3(credentials_file):
    """Подключает Tier 3 (Claude) на этот прогон. credentials_file — JSON
    с ключом Anthropic (см. common/anthropic_client.py); None — Tier 3 не
    нужен (десктопный GUI, режим площади фасонных изделий). Файла нет или ключ не
    годится — Tier 3 выключается с записью в лог и в отчёт, обработка
    идёт через Tier 1/Tier 2, как без него."""
    global _tier3_matcher, _tier3_status, _tier3_cache, _tier3_asked
    # Ответы Tier 3 прошлого прогона больше не действуют, а с Tier 3 этого
    # прогона прежние «не найдено» могут смениться подсказкой. Без Tier 3
    # в обоих прогонах кэш не трогаем: GUI переиспользует его между
    # файлами при той же базе (force_reload=False).
    if credentials_file or _tier3_cache:
        find_1c_match_with_tier.cache_clear()
    _tier3_matcher = None
    _tier3_status = None
    _tier3_cache = {}
    _tier3_asked = set()
    if not credentials_file:
        return
    try:
        client = AnthropicClient(credentials_file=credentials_file, log=_log,
                                 max_requests=TIER3_MAX_REQUESTS)
    except AnthropicError as exc:
        _tier3_status = f"не подключён: {exc}"
        _log(f"  ⚠️  Tier 3 (Claude) не подключён: {exc}")
        return
    _tier3_matcher = ClaudeMatcher(client, PROMPT_SPEC, log=_log)
    _log(f"  🧠 Tier 3 (Claude) подключён, модель {_tier3_matcher.model}.")


def _tier3_report_status():
    """Строка «Tier 3 (Claude)» для отчёта; None — Tier 3 не запрашивался."""
    if _tier3_matcher is None:
        return _tier3_status
    status = f"работал, модель {_tier3_matcher.model}; {_tier3_matcher.client.usage_summary()}"
    if _tier3_matcher.failed:
        status = f"сбой связи: {_tier3_matcher.failed}"
    if _tier3_matcher.skipped:
        status += f"; строк без ответа модели: {_tier3_matcher.skipped}"
    return status


def _prepare_tier3_matches(last_row, mode, header_row=1):
    """Пред-проход перед основным циклом по листу (Tier 3): собирает
    строки, которые Tier 1 не закроет — только категории 1/4/5
    (оборудование/изоляция/крепёж), где есть пост-проверка размеров
    validate_other_category_dimensions; воздуховоды и фасонные изделия (2/3)
    закрывает строгая геометрия Tier 1, догадкам там не место. Для каждой
    строки Tier 2 отбирает из базы SHORTLIST_SIZE кандидатов, и Claude
    пачками выбирает среди них то же изделие (см. common/claude_matcher.py).
    Запрос идёт на пачку строк, а не на каждую, — иначе обработка
    растянулась бы на минуты.

    Результат дописывается в module-level _tier3_cache, который читает
    find_1c_match_with_tier; строка, уже отправленная с другого листа той
    же книги, второй раз не отправляется. Tier 3 не подключён, Claude
    недоступен или ответил ерундой — ничего не делает: обработка идёт
    как раньше через Tier 1/Tier 2, без падения всего прогона.
    """
    global _tier3_cache
    if mode not in (MODE_MATCH, MODE_FULL) or _tier3_matcher is None:
        return
    if _tier2_matcher is None:
        _log("  ⚠️  Tier 3 (Claude) пропущен: не собран поиск кандидатов (Tier 2).")
        return

    # Tier 3 — дополнение, а не ядро: никакая его поломка, в том числе
    # непредвиденная, не должна ронять обработку файла.
    try:
        t_start = time.perf_counter()
        queries = []
        for row in range(header_row + 1, last_row + 1):
            cell_b_raw = ws[f"{COLMAP['NAME']}{row}"].value
            cell_b_raw = normalize_workshop_shorthand(cell_b_raw)
            cell_b = normalize(cell_b_raw)
            if not cell_b:
                continue
            cell_c = ws[f"{COLMAP['TYPE']}{row}"].value if "TYPE" in COLMAP else None
            category = determine_category(cell_b, is_spec_row=True)
            if category not in (1, 4, 5):
                continue
            key = _tier3_key(cell_b_raw, cell_c)
            if key in _tier3_asked:
                continue
            if _tier1_exact(cell_b_raw, cell_c, category) is not None:
                continue  # Tier 1 сам справится, Claude не нужен
            _tier3_asked.add(key)
            mark = key[1]
            # Хвост «в составе установки …» позицию не идентифицирует и
            # только сбивает отбор (как и у Tier 2), а марка из графы «Тип»
            # — наоборот, главное, по чему кандидата и ищут.
            query_text = strip_assembly_membership_note(str(cell_b_raw))
            if mark:
                query_text = f"{query_text} {mark}"
            found = _tier2_matcher.search(query_text, top_k=SHORTLIST_SIZE)
            candidates = list(dict.fromkeys(candidate["name"] for candidate, _s, _d in found))
            if candidates:
                queries.append({"key": key, "name": str(cell_b_raw), "mark": mark,
                                "candidates": candidates})

        if not queries:
            return

        # Отбор кандидатов (локальный поиск по базе) и сеть считаем
        # отдельно от общего времени обработки, иначе по логу не понять,
        # что «тормозит»: поиск по базе 1С или запросы к Claude.
        t0 = time.perf_counter()
        shortlist_sec = t0 - t_start
        resolved = _tier3_matcher.choose(queries)
        elapsed = time.perf_counter() - t0

        validated = {key: name for key, name in resolved.items()
                     if validate_other_category_dimensions(key[0], name)}
        _tier3_cache.update(validated)
        _log(f"  🧠 Tier 3: без точного совпадения — {len(queries)} строк, "
             f"Claude выбрал позицию базы для {len(resolved)}, после проверки размеров — "
             f"{len(validated)}; отбор кандидатов — {shortlist_sec:.1f} сек, "
             f"запросы к Claude — {elapsed:.1f} сек "
             f"({_tier3_matcher.client.usage_summary()}).")
    except Exception as exc:
        _log(f"  ⚠️  Tier 3 (Claude) не сработал для этого листа: {exc}")


def calculate_fitting_surface(text):
    """Площадь фасонного изделия, м² (common.area), с логированием в GUI."""
    return _common_calculate_fitting_surface(text, log=_log)


# ────────────────────────────────────────────────────────────────────
# АДАПТИВНАЯ ПРИВЯЗКА СТОЛБЦОВ (V1.7)
# Все расчёты/формулы/чтение теперь обращаются не к жёстким буквам
# (A,B,C…), а к ЛОГИЧЕСКИМ полям, которые сопоставляются с фактическими
# заголовками строки 1. Это позволяет обрабатывать таблицы с разной
# раскладкой столбцов (напр. «Вариант 1» и «Вариант 2 / Расчёт»).
# ────────────────────────────────────────────────────────────────────

# Логическое поле → буква по умолчанию (раскладка «Вариант 1» / HEADERS).
# Откат на эту букву применяется ТОЛЬКО если заголовок не распознан И
# соответствующая ячейка строки 1 пуста (чтобы не «перехватить» чужой
# столбец в нестандартной таблице).
_DEFAULT_LETTERS = {
    "POS": "A", "NAME": "B", "TYPE": "C", "CODE": "D", "VENDOR": "E",
    "UNIT": "F", "QTY": "G", "AREA_SPEC": "H", "NAME_1C": "I", "UNIT_1C": "J",
    "SYSTEM": "K", "NOTE": "L", "FAKT": "M", "QTY_PCS": "N", "AREA_M2": "O",
    "MP_SMETA": "P", "QTY_PCS_SMETA": "Q", "AREA_M2_2": "R", "AUX": "S",
}
_DEFAULT_FLOORS = ["T", "U", "V", "W"]

# Поля, обязательные для каждого режима (если не нашлись — понятная ошибка).
# Ключи — строковые значения MODE_* (которые объявлены ниже по файлу).
_REQUIRED_FIELDS = {
    "fitting": ["NAME", "AUX"],
    "match":   ["NAME", "NAME_1C"],
    "full":    ["NAME", "NAME_1C", "FAKT", "QTY_PCS", "AREA_M2",
                "QTY_PCS_SMETA", "AREA_M2_2", "AUX"],
}

# Заполняются в run_processing через resolve_columns()
COLMAP = {}
FLOOR_LETTERS = list(_DEFAULT_FLOORS)


def _classify_header(raw):
    """Определить логическое поле по тексту заголовка. None — не распознан."""
    norm = normalize(raw)
    if not norm:
        return None
    sq = re.sub(r"[\s.\-]", "", norm)          # «склеенная» форма для устойчивости
    # Сначала — более специфичные правила.
    if "ВСПОМОГАТЕЛЬН" in sq:
        return "AUX"
    if "НАИМЕНОВАН" in sq and "1С" in sq:
        return "NAME_1C"
    if "СИСТЕМ" in sq:                            # «Наименование системы» / «Система»
        return "SYSTEM"
    if "НАИМЕНОВАН" in sq:
        return "NAME"
    if "ЕД" in sq and "ИЗМ" in sq:
        return "UNIT_1C" if "1С" in sq else "UNIT"
    if sq == "ФАКТ":
        return "FAKT"
    if "КОЛВОМП" in sq:                          # «Кол-во м.п. СМЕТА»
        return "MP_SMETA"
    if "КОЛВОШТ" in sq:                          # «Кол-во шт.» / «…СМЕТА»
        return "QTY_PCS_SMETA" if "СМЕТА" in sq else "QTY_PCS"
    if "КВМ" in sq or "М2" in sq:               # «Кол-во кв.м …» / «… м2 …»
        if "СПЕК" in sq or "СПЕЦ" in sq:         # «по спеке/спеке/спец/спецификации»
            return "AREA_SPEC"
        if "СМЕТА" in sq:
            return "AREA_M2_2"
        return "AREA_M2"
    if "КОЛИЧЕСТВО" in sq or sq == "КОЛВО":     # «Количество» / «Кол-во»
        return "QTY"
    if sq in ("ПОЗ", "ПОЗИЦИЯ") or sq.startswith("ПОЗИЦ"):
        return "POS"
    if "ТИП" in sq and "МАРК" in sq:
        return "TYPE"
    if "ПРИМЕЧАН" in sq:
        return "NOTE"
    if "КОД" in sq:
        return "CODE"
    if "ЗАВОД" in sq or "ПОСТАВЩИК" in sq or "ИЗГОТОВ" in sq:
        return "VENDOR"
    if "МАСС" in sq:
        return "MASS"
    return None


def _detect_header_row(ws, max_scan=15):
    """Шапка таблицы не всегда в строке 1 — некоторые файлы ("Лимит на
    материалы" и т.п.) сначала несут несколько строк с названием
    объекта/лимита, и только потом настоящую шапку столбцов (в реальном
    файле — 6 строк заголовка листа, шапка на 7-й). Сканирует первые
    max_scan строк листа и берёт ту, где по _classify_header
    распознаётся больше всего полей — и точно есть "Наименование"
    (иначе распознавание одного случайного столбца могло бы перевесить
    настоящую шапку). Если такой строки нет вовсе (в т.ч. настоящая
    шапка и правда в строке 1) — возвращает 1, старое поведение."""
    maxc = ws.max_column or 1
    best_row, best_score = 1, -1
    limit = min(max_scan, ws.max_row or 1)
    for r in range(1, limit + 1):
        fields = set()
        for ci in range(1, maxc + 1):
            field = _classify_header(ws.cell(row=r, column=ci).value)
            if field:
                fields.add(field)
        if "NAME" not in fields:
            continue
        if len(fields) > best_score:
            best_score, best_row = len(fields), r
    return best_row


def resolve_columns(ws, mode, header_row=1):
    """
    Сопоставить логические поля с буквами столбцов на основе заголовков
    строки header_row (см. _detect_header_row — не всегда строка 1).
    Возвращает (colmap, floor_letters). Кидает RuntimeError, если не
    найдены поля, обязательные для режима.
    """
    maxc = ws.max_column or 1
    headers = []                  # [(col_idx, letter, field, raw)]
    for ci in range(1, maxc + 1):
        raw = ws.cell(row=header_row, column=ci).value
        headers.append((ci, get_column_letter(ci), _classify_header(raw), raw))

    cand = defaultdict(list)      # поле → [буквы в порядке столбцов]
    for ci, letter, field, raw in headers:
        if field:
            cand[field].append(letter)

    colmap = {}
    if cand.get("NAME_1C"):
        colmap["NAME_1C"] = cand["NAME_1C"][0]

    # Разрешение неоднозначности «Ед. измерения»: в «Варианте 1» оба
    # столбца (спека и 1С) подписаны одинаково. Тот, что правее
    # «Наименование в 1С», считаем единицей измерения 1С.
    units = cand.get("UNIT", [])
    units1c = cand.get("UNIT_1C", [])
    if units1c:
        colmap["UNIT_1C"] = units1c[0]
        if units:
            colmap["UNIT"] = units[0]
    elif len(units) >= 2 and colmap.get("NAME_1C"):
        n1c = column_index_from_string(colmap["NAME_1C"])
        after = [u for u in units if column_index_from_string(u) > n1c]
        before = [u for u in units if column_index_from_string(u) <= n1c]
        colmap["UNIT"] = (before or units)[0]
        if after:
            colmap["UNIT_1C"] = after[0]
    elif units:
        colmap["UNIT"] = units[0]

    # Аналогичная неоднозначность для площади «кв.м»: в «Варианте 1»
    # столбцы O («Кол-во кв.м.») и R («Кол-во кв. м.») подписаны почти
    # одинаково. Если сметная площадь не отмечена словом СМЕТА — второй
    # по счёту столбец площади считаем сметным (AREA_M2_2).
    areas = cand.get("AREA_M2", [])
    areas2 = cand.get("AREA_M2_2", [])
    if areas2:
        colmap["AREA_M2_2"] = areas2[0]
        if areas:
            colmap["AREA_M2"] = areas[0]
    elif len(areas) >= 2:
        colmap["AREA_M2"] = areas[0]
        colmap["AREA_M2_2"] = areas[1]
    elif areas:
        colmap["AREA_M2"] = areas[0]

    for field, letters in cand.items():
        if field in ("UNIT", "UNIT_1C", "NAME_1C", "AREA_M2", "AREA_M2_2"):
            continue
        colmap.setdefault(field, letters[0])

    # Проверка обязательных полей — ДО отката на буквы по умолчанию.
    # Обязательное поле считается найденным только если оно распознано
    # по заголовку (иначе откат на пустую дефолтную букву маскировал бы
    # реально отсутствующий столбец — это противоречит привязке по имени).
    missing = [f for f in _REQUIRED_FIELDS.get(mode, []) if f not in colmap]
    if missing:
        raise RuntimeError(
            "В таблице не найдены обязательные столбцы для режима "
            f"«{MODE_TITLE.get(mode, mode)}»: {', '.join(missing)}. "
            f"Проверьте заголовки в строке {header_row}.")

    # Откат на буквы по умолчанию: только для НЕобязательных полей и
    # только в свободные и пустые слоты (используются лишь незанятые
    # столбцы без заголовка, поэтому чужие данные не затрагиваются).
    claimed = set(colmap.values())
    for field, letter in _DEFAULT_LETTERS.items():
        if field in colmap or letter in claimed:
            continue
        if normalize(ws[f"{letter}{header_row}"].value):  # заголовок есть, но не распознан — не трогаем
            continue
        colmap[field] = letter
        claimed.add(letter)

    # Этажи: столбцы с заголовком правее «Вспомогательного».
    floor_letters = []
    if "AUX" in colmap:
        aux_idx = column_index_from_string(colmap["AUX"])
        floor_letters = [letter for ci, letter, field, raw in headers
                         if ci > aux_idx and normalize(raw)]
    if not floor_letters:
        floor_letters = list(_DEFAULT_FLOORS)

    return colmap, floor_letters


def _floor_sum(row):
    """Формула суммы по всем распознанным столбцам этажей."""
    return f"SUM({FLOOR_LETTERS[0]}{row}:{FLOOR_LETTERS[-1]}{row})"


# ────────────────────────────────────────────────────────────────────
# ФУНКЦИИ РАЗБОРА СТРОК ПО КАТЕГОРИЯМ (ячейка 9) — используют global ws/COLMAP
# ────────────────────────────────────────────────────────────────────
def parse_duct(text, row):
    text = normalize(text)
    N, Q = COLMAP["QTY_PCS"], COLMAP["QTY_PCS_SMETA"]
    M, P = COLMAP["FAKT"], COLMAP["MP_SMETA"]
    O = COLMAP.get("AREA_M2")        # «Кол-во кв.м»
    R = COLMAP.get("AREA_M2_2")      # «Кол-во кв.м СМЕТА»
    ws[f"{N}{row}"] = f"={_floor_sum(row)}"
    ws[f"{Q}{row}"] = f"={N}{row}"
    length_match = re.search(r"[LЛ]\s*=\s*(\d+)", text)
    if length_match:
        length = length_match.group(1)
        ws[f"{M}{row}"] = f"={length}/1000*{N}{row}"
        ws[f"{P}{row}"] = f"={length}/1000*{Q}{row}"
    else:
        ws[f"{M}{row}"] = f"={N}{row}"
        ws[f"{P}{row}"] = f"={Q}{row}"

    size_match = re.search(r"(\d+)\s*[xXхХ×*]\s*(\d+)", text)
    if size_match:
        a, b = size_match.group(1), size_match.group(2)
        if O:
            ws[f"{O}{row}"] = f"=(({a}/1000+{b}/1000)*2*{M}{row})"
        if R:
            ws[f"{R}{row}"] = f"=(({a}/1000+{b}/1000)*2*{P}{row})"
    else:
        diameter = None
        for pat in [r"Ø\s*(\d+)", r"\bD\s*(\d+)", r"\bФ\s*(\d+)", r"\b(\d+)\s*ММ\b"]:
            m = re.search(pat, text)
            if m:
                diameter = m.group(1)
                break
        if diameter:
            if O:
                ws[f"{O}{row}"] = f"=3.14*({diameter}/1000)*{M}{row}"
            if R:
                ws[f"{R}{row}"] = f"=3.14*({diameter}/1000)*{P}{row}"
    area_col = O or R
    if "AREA_SPEC" in COLMAP and "QTY" in COLMAP and area_col:
        H, G = COLMAP["AREA_SPEC"], COLMAP["QTY"]
        ws[f"{H}{row}"] = f"=IFERROR({area_col}{row}/{M}{row}*{G}{row},0)"


def parse_fitting(row):
    calculated_area = calculate_fitting_surface(ws[f"{COLMAP['NAME']}{row}"].value)
    S = COLMAP["AUX"]
    N, Q = COLMAP["QTY_PCS"], COLMAP["QTY_PCS_SMETA"]
    O = COLMAP.get("AREA_M2")        # «Кол-во кв.м»
    R = COLMAP.get("AREA_M2_2")      # «Кол-во кв.м СМЕТА»
    ws[f"{S}{row}"] = calculated_area if calculated_area > 0 else 0
    ws[f"{N}{row}"] = f"={_floor_sum(row)}"
    if O:
        ws[f"{O}{row}"] = f"={N}{row}*{S}{row}"
    ws[f"{Q}{row}"] = f"={N}{row}"
    if R:
        ws[f"{R}{row}"] = f"={O}{row}" if O else f"={N}{row}*{S}{row}"


def parse_equipment(row):
    N, Q = COLMAP["QTY_PCS"], COLMAP["QTY_PCS_SMETA"]
    ws[f"{N}{row}"] = f"={_floor_sum(row)}"
    if "QTY" in COLMAP:
        G = COLMAP["QTY"]
        ws[f"{Q}{row}"] = f"=MAX({G}{row},{N}{row})"
    else:
        ws[f"{Q}{row}"] = f"={N}{row}"


def parse_fastener(row):
    N, Q, S = COLMAP["QTY_PCS"], COLMAP["QTY_PCS_SMETA"], COLMAP["AUX"]
    ws[f"{N}{row}"] = f"=ROUNDUP({S}{row},0)"
    ws[f"{Q}{row}"] = f"=ROUNDUP({N}{row}*1.2,0)"


# ────────────────────────────────────────────────────────────────────
# ГЛАВНЫЙ ЦИКЛ ОБРАБОТКИ (ячейка 10) — теперь функция
# ────────────────────────────────────────────────────────────────────
# Режимы работы и подписи к имени файла результата
MODE_FULL = "full"        # полная обработка (как было)
MODE_FITTING = "fitting"  # только расчёт площади фасонных изделий (столбец S)
MODE_MATCH = "match"      # только сравнение с 1С (столбец I)

MODE_SUFFIX = {
    MODE_FULL: "_full_obr",
    MODE_FITTING: "_фасонные_изделия",
    MODE_MATCH: "_1С",
}

MODE_TITLE = {
    MODE_FULL: "ПОЛНАЯ ОБРАБОТКА",
    MODE_FITTING: "РАСЧЁТ ПЛОЩАДИ ФАСОННЫХ ИЗДЕЛИЙ",
    MODE_MATCH: "СРАВНЕНИЕ С 1С",
}


# Системой считается только код вида П1 / В2 / ДП1 / ДВ1 / ДЕ1 —
# значение, начинающееся с В, П, ДП, ДВ, ДЕ и далее (через необязательный
# разделитель) с цифры. Прочий текст в столбце «Позиция» системой не считается.
_SYSTEM_PREFIX_RE = re.compile(r"^(ДП|ДВ|ДЕ|В|П)[\s.\-_]*\d")

# Заголовки разделов/подразделов в "Наименовании" (не позиции, не товар —
# см. проверку "is_header_row" в цикле по строкам ниже): римская цифра +
# точка ("IV.ОБЩЕОБМЕННАЯ ВЕНТИЛЯЦИЯ...") и буквенный подпункт а./б./в.
# ("б. Материалы") — оба применяются к уже normalize()-нному (значит,
# заглавному) тексту.
_SECTION_TITLE_RE = re.compile(r"^[IVXLCDM]{1,6}\.[А-Я]")
_LETTERED_SUBSECTION_RE = re.compile(r"^[АБВ]\.\s+[А-Я]")


def _is_system_name(value):
    if not value:
        return False
    return bool(_SYSTEM_PREFIX_RE.match(str(value).strip().upper()))


def _apply_table_formatting(ws, header_row=1):
    """
    Финальное форматирование обработанной таблицы:
      • шрифт ISOCPEUR, размер 12 — для всех строк данных;
      • столбец «Позиция» (A) — жирный курсив, размер 20;
      • столбец «Наименование» (B) — по левому краю, по вертикали по центру;
      • остальные столбцы — по центру (и по горизонтали, и по вертикали).
    Шапка (строка header_row, обычно 1) не трогается.
    """
    table_font = Font(name="ISOCPEUR", size=12)
    pos_font = Font(name="ISOCPEUR", size=20, bold=True, italic=True)
    pos_idx = column_index_from_string(COLMAP["POS"]) if "POS" in COLMAP else 1
    name_idx = column_index_from_string(COLMAP["NAME"]) if "NAME" in COLMAP else 2
    max_row = ws.max_row
    max_col = ws.max_column
    for r in range(header_row + 1, max_row + 1):
        for c in range(1, max_col + 1):
            cell = ws.cell(row=r, column=c)
            if c == pos_idx:
                cell.font = pos_font
                cell.alignment = ALIGN_CENTER_WRAP
            elif c == name_idx:
                cell.font = table_font
                cell.alignment = ALIGN_LEFT_WRAP
            else:
                cell.font = table_font
                cell.alignment = ALIGN_CENTER_WRAP


def _apply_header_style(ws, header_row=1):
    """Статичная заливка (шапка + столбцы A и H..R на всю высоту таблицы)
    и группировка столбцов — общая с pdf_to_spec.py (см. common/
    header_style.py). Нужна тут отдельно, т.к. на "Полную обработку"
    файл может прийти не только из PDF-конвертера (где эта заливка уже
    проставлена), но и обычным .xlsx напрямую — в этом случае раскраску
    больше неоткуда взять. Столбцы B..G (данные) не трогает — там
    построчная заливка по категории позиции (GREEN_FILL/ORANGE_FILL/...
    выше), эта функция всегда вызывается уже после неё."""
    for c, rgb in HEADER_FILL_BY_COLUMN.items():
        ws.cell(row=header_row, column=c).fill = PatternFill(fill_type="solid", fgColor=rgb)
    data_fills = {c: PatternFill(fill_type="solid", fgColor=rgb)
                  for c, rgb in DATA_FILL_BY_COLUMN.items()}
    for r in range(header_row + 1, ws.max_row + 1):
        for c, fill in data_fills.items():
            ws.cell(row=r, column=c).fill = fill
    for c_from, c_to in HEADER_COLUMN_GROUPS:
        for c in range(c_from, c_to + 1):
            ws.column_dimensions[get_column_letter(c)].outline_level = 1


def run_processing(spec_file, db_file=None, output_file=None,
                   use_com=False, selected_base=None, force_reload=True,
                   progress_callback=None, mode=MODE_FULL,
                   report_destination=None, report_folder=None,
                   claude_credentials_file=None):
    """
    Главная точка входа для GUI.

    spec_file        — путь к Excel-спецификации (обязательно).
    db_file          — путь к файлу базы 1С (Excel/CSV) либо None при use_com.
    output_file      — куда сохранить результат (по умолчанию рядом со спецификацией).
    use_com          — пытаться подключиться к живой 1С (только Windows + pywin32).
    selected_base    — выбранная база {'name','path'} (из find_1c_bases).
    progress_callback(done, total) — необязательный колбэк прогресса.
    mode             — режим работы:
                         "full"    — полная обработка (раскраска, формулы,
                                      площадь фасонных изделий, сравнение с 1С);
                         "fitting" — ТОЛЬКО площадь фасонных изделий (столбец S),
                                      база 1С не нужна, остальное не трогается;
                         "match"   — ТОЛЬКО сравнение с 1С (столбец I),
                                      формулы/раскраска не трогаются.
    report_destination — место сохранения отчёта о сравнении с 1С (только
                          для mode "full"/"match", для "fitting" отчёт не
                          строится — базы 1С в этом режиме нет):
                            None      — отчёт не создаётся;
                            "sheet"   — доп. лист «Отчёт» в том же файле
                                        (common.report.write_report_sheet);
                            "folder"  — отдельный Excel-файл в report_folder
                                        (common.report.write_report_file).
    report_folder    — папка для report_destination="folder"; если не
                        указана, используется папка output_file.
    claude_credentials_file — путь к JSON с ключом Anthropic для Tier 3
                        (Claude выбирает позицию базы среди кандидатов
                        Tier 2, см. common/claude_matcher.py). None — Tier 3
                        не подключается, всё работает как раньше
                        (Tier 1 → Tier 2).

    Возвращает путь к сохранённому файлу.
    """
    global wb, ws

    mode = (mode or MODE_FULL).lower()
    if mode not in (MODE_FULL, MODE_FITTING, MODE_MATCH):
        raise ValueError(f"Неизвестный режим: {mode}")

    if not spec_file or not os.path.exists(spec_file):
        raise FileNotFoundError(f"Файл спецификации не найден: {spec_file}")

    if not output_file:
        base, _ext = os.path.splitext(spec_file)
        output_file = base + MODE_SUFFIX.get(mode, "_processed") + ".xlsx"

    _log(f"Режим: {MODE_TITLE.get(mode, mode)}")

    # 1. База 1С — нужна только для режимов с сравнением (full / match).
    #    Для расчёта площади фасонных изделий база не требуется.
    if mode in (MODE_FULL, MODE_MATCH):
        load_database(db_file_path=db_file, force_reload=force_reload,
                      use_com=use_com, selected_base=selected_base)
        if not _db_loaded:
            raise RuntimeError("База 1С не загружена — обработка остановлена. "
                               "Проверьте файл базы или подключение к 1С.")
        _setup_tier3(claude_credentials_file)
    else:
        _log("Расчёт площади фасонных изделий — база 1С не требуется, пропускаю её загрузку.")

    # 2. Открываем спецификацию — файл может нести несколько листов
    #    (напр. "Лимит на материалы" отдельными листами по разделам —
    #    ПВ/ОВ(В)/ОВ(П)); раньше обрабатывался только активный лист
    #    книги, остальные молча пропускались целиком.
    _log(f"📑 Открываю спецификацию: {os.path.basename(spec_file)}")
    wb = load_workbook(spec_file)

    # 3. Привязка столбцов по заголовкам — на каждом листе своя шапка
    #    (не обязательно в строке 1, см. _detect_header_row) и, отдельно,
    #    свой COLMAP/FLOOR_LETTERS. Заголовки больше НЕ перезаписываются:
    #    строка шапки — источник сопоставления, пользовательскую
    #    раскладку не трогаем. Лист, где обязательные для режима столбцы
    #    не нашлись ни в одной из первых строк (не похож на таблицу
    #    спецификации — например, титульный лист), пропускается с
    #    предупреждением, а не валит всю обработку файла.
    global COLMAP, FLOOR_LETTERS
    sheets_info = []   # [(ws, header_row, colmap, floor_letters, last_row)]
    skipped_sheets = []
    for candidate_ws in wb.worksheets:
        header_row = _detect_header_row(candidate_ws)
        try:
            sheet_colmap, sheet_floors = resolve_columns(candidate_ws, mode, header_row=header_row)
        except RuntimeError as exc:
            skipped_sheets.append((candidate_ws.title, str(exc)))
            continue
        sheets_info.append((candidate_ws, header_row, sheet_colmap, sheet_floors, candidate_ws.max_row))

    if not sheets_info:
        details = "; ".join(f"«{title}»: {err}" for title, err in skipped_sheets) or "в книге нет листов"
        raise RuntimeError(
            f"Не удалось найти таблицу спецификации ни на одном листе книги. {details}")
    for title, err in skipped_sheets:
        _log(f"  ⚠️  Лист «{title}» пропущен (не похож на таблицу спецификации): {err}")
    _log(f"Листов к обработке: {len(sheets_info)} — "
         + ", ".join(f"«{s[0].title}»" for s in sheets_info))

    # 4. Главный цикл — по каждому подходящему листу
    proc_start_dt = datetime.datetime.now()
    proc_start_perf = time.time()
    _log(f"⏱️  Начало обработки строк спецификации: {proc_start_dt.strftime('%H:%M:%S')}")
    _log("Запуск обработки строк спецификации...")
    total = max(sum(last_row - header_row for _ws, header_row, _c, _f, last_row in sheets_info), 1)
    processed = 0
    counter = 0   # счётчик затронутых строк (для итогового лога)
    tier2_counter = 0  # из них — неподтверждённые подсказки Tier 2 (V2.1)
    tier3_counter = 0  # из них — подсказки Claude (Tier 3)
    match_row_count = 0    # строк с непустым наименованием (для отчёта, V2.3)
    category_counter = Counter()   # разбивка по категориям (для отчёта, V2.3)
    fitting_updates = {}  # Сохраняем только эти числовые значения в исходном XLSX.
    match_time_total = 0.0   # суммарное время внутри find_1c_match_with_tier (замер производительности)

    for ws, header_row, COLMAP, FLOOR_LETTERS, last_row in sheets_info:
        current_position = ""
        _log(f"Привязка столбцов («{ws.title}», шапка в строке {header_row}): "
             + ", ".join(f"{k}={v}" for k, v in sorted(COLMAP.items())))
        _log(f"Столбцы этажей (сумма, «{ws.title}»): " + ", ".join(FLOOR_LETTERS))

        # Статичная заливка шапки/столбцов — ДО главного цикла по этому
        # листу, а не после: он же и красит столбец I (совпадение с 1С,
        # диапазон I..L) базовым цветом. Красить после цикла нельзя —
        # стёрло бы точечные MATCH_*_FILL, которые цикл ставит по
        # качеству совпадения (Tier 2 / не найдено). 100%-е совпадение
        # (Tier 1) как раз и остаётся окрашенным ЭТИМ базовым цветом —
        # своей заливки цикл для него не ставит.
        if mode != MODE_FITTING:
            _apply_header_style(ws, header_row=header_row)

        # Запросы к Claude пачками на весь лист сразу, ДО построчного
        # цикла — см. docstring _prepare_tier3_matches. Ничего не
        # делает, если Tier 3 не подключён (нет файла с ключом Anthropic).
        if mode != MODE_FITTING:
            _prepare_tier3_matches(last_row, mode, header_row=header_row)

        for row in range(header_row + 1, last_row + 1):
            cell_b_raw = ws[f"{COLMAP['NAME']}{row}"].value
            cell_b_raw = normalize_workshop_shorthand(cell_b_raw)
            cell_b = normalize(cell_b_raw)
            pos_raw = ws[f"{COLMAP['POS']}{row}"].value if "POS" in COLMAP else None
            cell_a = normalize(pos_raw)
            cell_c = ws[f"{COLMAP['TYPE']}{row}"].value if "TYPE" in COLMAP else None

            processed += 1
            if progress_callback and processed % 25 == 0:
                progress_callback(processed, total)

            if not cell_b:
                continue

            # Строка-заголовок ("КОРПУС 1. Система общеобменной вытяжной
            # вентиляции", "IV.ОБЩЕОБМЕННАЯ ВЕНТИЛЯЦИЯ НЕЖИЛОЙ ЧАСТИ",
            # "б. Материалы") — не позиция, а название раздела/подраздела, а
            # не товар. Без этой проверки такие строки классифицировались как
            # category=0 (ни один маркер типа не подошёл) и всё равно уходили
            # в Tier 2/3 нечёткий поиск — заголовку могло случайно подобрать
            # посторонний "похожий" товар вместо честного "не наш профиль".
            # ("Пустые остальные столбцы" как признак заголовка не подходит —
            # у реальных позиций тип/код/завод/примечание тоже сплошь и рядом
            # пустые, единственное обязательное поле — "Наименование".)
            # Три признака заголовка (любого достаточно):
            #  1) "Позиция" буквально совпадает с "Наименованием" — конвертер
            #     дублирует туда название текущей группы;
            #  2) начинается с римской цифры и точки ("IV.ОБЩЕОБМЕННАЯ...");
            #  3) начинается с одной буквы и точки — лит. подпункт
            #     ("а. Оборудование", "б. Материалы").
            is_header_row = (
                (bool(cell_a) and cell_a == cell_b)
                or bool(_SECTION_TITLE_RE.match(cell_b))
                or bool(_LETTERED_SUBSECTION_RE.match(cell_b))
            )
            if is_header_row:
                continue

            category = determine_category(cell_b, is_spec_row=True)
            match_row_count += 1
            category_counter[category] += 1

            # ── РЕЖИМ: ТОЛЬКО ПЛОЩАДЬ ФАСОННЫХ ИЗДЕЛИЙ ──────────────────────────
            if mode == MODE_FITTING:
                if is_fitting_row(category, cell_b_raw):
                    area = calculate_fitting_surface(cell_b_raw)
                    fitting_updates.setdefault(ws.title, {})[f"{COLMAP['AUX']}{row}"] = area if area > 0 else 0
                    counter += 1
                continue

            # ── РЕЖИМ: ТОЛЬКО СРАВНЕНИЕ С 1С ─────────────────────────────
            if mode == MODE_MATCH:
                _t0 = time.perf_counter()
                match_result, tier = find_1c_match_with_tier(cell_b_raw, cell_c, category)
                match_time_total += time.perf_counter() - _t0
                cell_i = ws[f"{COLMAP['NAME_1C']}{row}"]
                cell_i.alignment = ALIGN_CENTER_WRAP
                if match_result:
                    cell_i.value = match_result
                    counter += 1
                    if tier == 3:
                        cell_i.fill = MATCH_TIER3_FILL
                        tier3_counter += 1
                    elif tier == 2:
                        cell_i.fill = MATCH_TIER2_FILL
                        tier2_counter += 1
                else:
                    cell_i.fill = MATCH_NONE_FILL
                continue

            # ── РЕЖИМ: ПОЛНАЯ ОБРАБОТКА ──────────────────────────────────
            apply_fill = {1: NO_FILL, 2: GREEN_FILL, 3: ORANGE_FILL,
                          4: GRAY_FILL, 5: YELLOW_FILL}.get(category)
            if apply_fill:
                c_from = column_index_from_string(COLMAP["NAME"])
                c_to = column_index_from_string(
                    COLMAP["QTY"] if "QTY" in COLMAP else _DEFAULT_LETTERS["QTY"])
                for col in range(c_from, c_to + 1):
                    ws.cell(row=row, column=col).fill = apply_fill
                if category in [3, 5] and "AUX" in COLMAP:
                    ws.cell(row=row, column=column_index_from_string(COLMAP["AUX"])).fill = apply_fill

            if "UNIT_1C" in COLMAP and "UNIT" in COLMAP:
                ws[f"{COLMAP['UNIT_1C']}{row}"] = f"={COLMAP['UNIT']}{row}"
            # Текущая система обновляется ТОЛЬКО если значение в «Позиции» —
            # код системы (В, П, ДП, ДВ, ДЕ + цифра, напр. П1, ДВ2). Прочий
            # текст (слова, номера позиций) системой не считается и не сбивает
            # уже установленную систему.
            if cell_a and _is_system_name(pos_raw):
                current_position = str(pos_raw).strip()
            # Для крепежа в строку пишется отдельная подпись, НО текущая
            # система НЕ затирается — иначе «КРЕПЕЖНЫЕ ИЗДЕЛИЯ» протекало бы
            # на идущие ниже воздуховоды/фасонные изделия до следующего маркера.
            system_value = "КРЕПЕЖНЫЕ ИЗДЕЛИЯ" if category == 5 else current_position
            if "SYSTEM" in COLMAP:
                ws[f"{COLMAP['SYSTEM']}{row}"] = system_value

            if   category == 1: parse_equipment(row)
            elif category == 2: parse_duct(cell_b, row)
            elif category == 3: parse_fitting(row)
            elif is_fitting_row(category, cell_b_raw): parse_fitting(row)
            elif category == 5: parse_fastener(row)

            _t0 = time.perf_counter()
            match_result, tier = find_1c_match_with_tier(cell_b_raw, cell_c, category)
            match_time_total += time.perf_counter() - _t0
            cell_i = ws[f"{COLMAP['NAME_1C']}{row}"]
            cell_i.alignment = ALIGN_CENTER_WRAP
            if match_result:
                cell_i.value = match_result
                counter += 1
                if tier == 3:
                    cell_i.fill = MATCH_TIER3_FILL
                    tier3_counter += 1
                elif tier == 2:
                    cell_i.fill = MATCH_TIER2_FILL
                    tier2_counter += 1
            else:
                cell_i.fill = MATCH_NONE_FILL

        if mode != MODE_FITTING:
            _apply_table_formatting(ws, header_row=header_row)

    if progress_callback:
        progress_callback(total, total)

    proc_end_dt = datetime.datetime.now()
    proc_duration_sec = time.time() - proc_start_perf
    _log(f"⏱️  Окончание обработки строк спецификации: {proc_end_dt.strftime('%H:%M:%S')}")
    _log(f"⏱️  Затрачено времени на обработку: {proc_duration_sec:.1f} сек")
    if mode in (MODE_MATCH, MODE_FULL):
        cache_info = find_1c_match_with_tier.cache_info()
        _log(f"⏱️     из них на сопоставление с 1С (Tier 1+2+3): {match_time_total:.1f} сек "
             f"(кэш: {cache_info.hits} повторов, {cache_info.misses} новых запросов)")

    # Отчёт о сравнении с 1С (V2.3) — только для режимов с матчингом
    # (fitting не использует базу 1С, отчёту не о чем говорить).
    report_stats = None
    if mode in (MODE_MATCH, MODE_FULL) and report_destination:
        total_area = None
        if mode == MODE_FULL:
            total_area = 0.0
            for sheet_ws, sheet_header_row, sheet_colmap, _f, sheet_last_row in sheets_info:
                if "AUX" not in sheet_colmap:
                    continue
                aux_idx = column_index_from_string(sheet_colmap["AUX"])
                total_area += sum(
                    v for v in (sheet_ws.cell(row=r, column=aux_idx).value
                                for r in range(sheet_header_row + 1, sheet_last_row + 1))
                    if isinstance(v, (int, float)) and v > 0
                )
        report_stats = {
            "timestamp": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "spec_file": os.path.basename(spec_file),
            "db_file": os.path.basename(db_file) if db_file else None,
            "mode_title": MODE_TITLE.get(mode, mode),
            "proc_start": proc_start_dt.strftime("%H:%M:%S"),
            "proc_end": proc_end_dt.strftime("%H:%M:%S"),
            "proc_duration_sec": round(proc_duration_sec, 1),
            "total": match_row_count,
            "tier1": counter - tier2_counter - tier3_counter,
            "tier2": tier2_counter,
            "tier3": tier3_counter,
            "not_found": match_row_count - counter,
            "categories": dict(category_counter),
            "total_area": total_area,
        }
        tier3_status = _tier3_report_status()
        if tier3_status:
            report_stats["tier3_status"] = tier3_status
        if report_destination == "sheet":
            write_report_sheet(wb, report_stats)

    if mode == MODE_FITTING:
        # Пересохранение через openpyxl меняет даже нетронутые части книги
        # (например, кэш формул). Здесь копируем исходный пакет XLSX,
        # исправляя только значения вычисленных ячеек.
        output_file = _safe_save(wb, output_file, save=lambda path:
                                 save_numeric_cells(spec_file, path, fitting_updates))
    else:
        output_file = _safe_save(wb, output_file)

    if report_stats is not None and report_destination == "folder":
        folder = report_folder or os.path.dirname(output_file)
        report_path = default_report_path(spec_file, folder)
        write_report_file(report_stats, report_path)
        _log(f"    Отчёт сохранён: {report_path}")

    _log("=" * 50)
    if mode == MODE_FITTING:
        _log(f"✅  ГОТОВО: площадь посчитана для {counter} фасонных позиций (столбец S)")
    elif mode == MODE_MATCH:
        _log(f"✅  ГОТОВО: найдено соответствий в 1С — {counter} (столбец I), "
             f"из них по подсказке Claude, Tier 3 (синяя заливка, требует проверки) — {tier3_counter}, "
             f"по подсказке Tier 2 (жёлтая заливка, требует проверки) — {tier2_counter}")
    else:
        _log(f"✅  ОБРАБОТКА ЗАВЕРШЕНА УСПЕШНО (полная); "
             f"по подсказке Claude, Tier 3 (синяя заливка, требует проверки) — {tier3_counter}, "
             f"по подсказке Tier 2 (жёлтая заливка, требует проверки) — {tier2_counter}")
    _log(f"    Файл сохранён: {output_file}")
    _log("=" * 50)
    return output_file


# ════════════════════════════════════════════════════════════════════
# СОЗДАНИЕ БАЗОВОЙ ТАБЛИЦЫ СПЕЦИФИКАЦИИ
# ════════════════════════════════════════════════════════════════════
#
# Вариант 1 — точный порт VBA-макроса «Созданиетаблицы»:
#   21 столбец, заданные ширины/названия, шрифт ISOCPEUR 12, цвета
#   столбцов, границы, выравнивания, в столбце A шрифт 20 жирный курсив,
#   группировка D:E / I:L / P:R (свёрнута), закрепление первой строки.
# Варианты 2+ — заглушки под будущие VBA-макросы.
# ════════════════════════════════════════════════════════════════════

# Названия и ширины столбцов из VBA (21 столбец, A..U)
_V1_COL_NAMES = [
    "Позиция", "Наименование", "Тип,марка", "Код оборудования",
    "Завод-изготовитель", "Ед.измерения", "Кол-во", "Кол-во м2 по спец",
    "Наименование в 1С", "Ед.измерения", "Система", "Примечание",
    "ФАКТ", "Кол-во шт.", "Кол-во кв.м", "Кол-во м.п. смета",
    "Кол-во шт. смета", "Кол-во кв.м СМЕТА", "Вспомогательный", "Тех.подполье", "1",
]
_V1_COL_WIDTHS = [25, 130, 50, 32, 35, 15, 16, 16, 100, 14, 22, 30,
                  15, 15, 15, 15, 15, 15, 27, 25, 25]


def _create_base_table_variant1(output_file):
    """Точный порт VBA-макроса создания базовой таблицы (Вариант 1)."""
    ROWS = 500
    COLS = 21

    wb = Workbook()
    ws = wb.active
    ws.title = "Спецификация"

    # Стили (соответствуют VBA)
    thin = Side(style="thin")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    base_font = Font(name="ISOCPEUR", size=12)
    col1_font = Font(name="ISOCPEUR", size=20, bold=True, italic=True)
    header_align = Alignment(horizontal="center", vertical="center", wrap_text=True)
    center = Alignment(horizontal="center", vertical="center")
    left = Alignment(horizontal="left", vertical="center")

    fill_blue = PatternFill("solid", fgColor="BDD7EE")   # RGB(189,215,238)
    fill_green = PatternFill("solid", fgColor="00B050")  # RGB(0,176,80)
    fill_cyan = PatternFill("solid", fgColor="92CDDC")   # RGB(146,205,220)
    fill_pink = PatternFill("solid", fgColor="EFABC3")   # RGB(239,171,195)
    fill_gray = PatternFill("solid", fgColor="D9D9D9")   # RGB(217,217,217)

    # Базовый шрифт + границы на всю таблицу
    for r in range(1, ROWS + 1):
        for c in range(1, COLS + 1):
            cell = ws.cell(row=r, column=c)
            cell.font = base_font
            cell.border = border

    # Заголовки (строка 1) + оформление шапки
    for c, name in enumerate(_V1_COL_NAMES, start=1):
        cell = ws.cell(row=1, column=c)
        cell.value = name
        cell.alignment = header_align

    # Цвета столбцов
    for r in range(1, ROWS + 1):
        ws.cell(row=r, column=1).fill = fill_blue          # A
        ws.cell(row=r, column=8).fill = fill_green         # H
        for c in range(9, 13):                             # I:L
            ws.cell(row=r, column=c).fill = fill_cyan
        for c in range(13, 16):                            # M:O
            ws.cell(row=r, column=c).fill = fill_pink
        for c in range(16, 19):                            # P:R
            ws.cell(row=r, column=c).fill = fill_gray
    for c in range(2, 8):                                  # B1:G1
        ws.cell(row=1, column=c).fill = fill_blue

    # Выравнивание данных (строки 2..500)
    center_cols = {1, 3, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21}
    for r in range(2, ROWS + 1):
        for c in center_cols:
            ws.cell(row=r, column=c).alignment = center
        ws.cell(row=r, column=2).alignment = left          # столбец B по левому краю
        ws.cell(row=r, column=1).font = col1_font          # столбец A — крупный жирный курсив

    # Ширины столбцов
    for i, w in enumerate(_V1_COL_WIDTHS, start=1):
        ws.column_dimensions[get_column_letter(i)].width = w

    # Высоты строк
    ws.row_dimensions[1].height = 45
    for r in range(2, ROWS + 1):
        ws.row_dimensions[r].height = 30

    # Группировка столбцов (свёрнутая): D:E, I:L, P:R.
    # Делаем ПОЭЛЕМЕНТНО (outlineLevel + hidden на каждый столбец), а не
    # через group(): group() сбрасывает ширины внутри диапазона, из-за чего
    # заданные ширины J/K/L терялись. Поэлементная установка не трогает
    # ширины (dim уже создан выше с нужной шириной).
    try:
        for rng in (("D", "E"), ("I", "L"), ("P", "R")):
            a = column_index_from_string(rng[0])
            b = column_index_from_string(rng[1])
            for ci in range(a, b + 1):
                dim = ws.column_dimensions[get_column_letter(ci)]
                dim.outlineLevel = 1
                dim.hidden = True
        if ws.sheet_properties.outlinePr is None:
            from openpyxl.worksheet.properties import Outline
            ws.sheet_properties.outlinePr = Outline()
        ws.sheet_properties.outlinePr.summaryRight = True
    except Exception as e:
        _log(f"  ⚠️  Группировку столбцов применить не удалось: {e}")

    # Закрепление первой строки
    ws.freeze_panes = "A2"

    return _safe_save(wb, output_file)


# ────────────────────────────────────────────────────────────────────
# ВАРИАНТ 2 — пустая базовая таблица по образцу листа «Расчёт»
# (порт файла «Таблица вариант 2.py»). Логика оформления сохранена
# один-в-один; изменены только имена констант на префикс _V2_, чтобы
# не пересекаться с глобальными именами модуля.
# ────────────────────────────────────────────────────────────────────
_V2_FILL_HEADER = "DDD9C3"      # бежевый — шапка A:R
_V2_FILL_FAKT = "FDEADA"        # оранжевый — блок ФАКТ
_V2_FILL_SMETA_HEAD = "CCC1DA"  # сиреневый шапки O:Q
_V2_FILL_SMETA_BODY = "E6E0EC"  # сиреневый данных O:Q
_V2_FONT_NAME = "ISOCPEUR"

# (буква, заголовок, ширина|None, выравнивание данных, wrap)
_V2_COLUMNS = [
    ("A",  "Поз.",                                              12.66, "l",  False),
    ("B",  "Наименование и техническая характеристика",         76.0,  None, True),
    ("C",  "Тип, марка, обозначение документа, опросного листа", 20.0,  "l",  True),
    ("D",  "Код продукции",                                      26.66, "l",  True),
    ("E",  "Поставщик",                                          15.16, "l",  True),
    ("F",  "Ед.\nизмерения",                                     12.66, "c",  True),
    ("G",  "Коли- чество",                                       12.66, "c",  False),
    ("H",  "Масса 1 ед., кг.",                                   17.33, "l",  True),
    ("I",  "Наименование в 1С",                                  64.16, None, True),
    ("J",  "Ед.изм. в 1С",                                       17.33, "c",  True),
    ("K",  "Примечание",                                         22.16, "l",  True),
    ("L",  "ФАКТ",                                               10.5,  "c",  True),
    ("M",  "Кол-во шт.",                                         11.0,  "c",  True),
    ("N",  "Кол-во кв.м.",                                       9.33,  "c",  False),
    ("O",  "Кол-во  м.п. СМЕТА",                                 9.33,  "c",  False),
    ("P",  "Кол-во шт.СМЕТА",                                    None,  "c",  False),
    ("Q",  "Кол-во кв.м. СМЕТА",                                 None,  "c",  False),
    ("R",  "Наименование системы",                              22.5,  None, False),
    ("S",  "Вспомогательный",                                   14.0,  "c",  False),
    ("T",  "Подземный этаж (-1 этаж) -3.200",                   16.83, None, False),
    ("U",  "Этаж 1",                                            9.33,  None, False),
    ("V",  "Этаж 2 ",                                           None,  None, False),
    ("W",  "Этаж 3",                                            None,  None, False),
    ("X",  "Этаж 4",                                            None,  None, False),
    ("Y",  "Этаж 5",                                            None,  None, False),
    ("Z",  "Этаж 6",                                            None,  None, False),
    ("AA", "Этаж 7",                                            None,  None, False),
    ("AB", "Этаж 8",                                            None,  None, False),
    ("AC", "Этаж 9",                                            None,  None, False),
    ("AD", "Этаж 10",                                           None,  None, False),
    ("AE", "Этаж 11",                                           None,  None, False),
    ("AF", "Технастройка ",                                     None,  None, False),
    ("AG", "Кровля (35,900)",                                   None,  None, False),
]

_V2_COL = {c[0]: i + 1 for i, c in enumerate(_V2_COLUMNS)}
_V2_AUX_COL = _V2_COL["S"]            # «Вспомогательный» — последний с границами
_V2_FAKT = (_V2_COL["L"], _V2_COL["N"])
_V2_SMETA = (_V2_COL["O"], _V2_COL["Q"])
_V2_HIDDEN_COLS = ["D", "H"]
_V2_OUTLINE_COLS = ["I", "J", "O"]    # уровень 1 (свёрнуто)


def _create_base_table_variant2(output_file, rows=500):
    """Порт «Таблица вариант 2.py»: пустая базовая таблица «Расчёт»."""
    thin = Side(style="thin")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)

    header_font = Font(name=_V2_FONT_NAME, size=11, bold=True)
    data_font = Font(name=_V2_FONT_NAME, size=10, bold=False)

    header_align = Alignment(horizontal="center", vertical="center", wrap_text=True)
    fill_header = PatternFill("solid", fgColor=_V2_FILL_HEADER)
    fill_fakt = PatternFill("solid", fgColor=_V2_FILL_FAKT)
    fill_smeta_head = PatternFill("solid", fgColor=_V2_FILL_SMETA_HEAD)
    fill_smeta_body = PatternFill("solid", fgColor=_V2_FILL_SMETA_BODY)

    wb = Workbook()
    ws = wb.active
    ws.title = "Расчёт"

    # Шапка (строка 1)
    for letter, title, width, _al, _wrap in _V2_COLUMNS:
        c = _V2_COL[letter]
        cell = ws.cell(row=1, column=c, value=title)
        cell.font = header_font
        cell.alignment = header_align
        cell.border = border
        if _V2_FAKT[0] <= c <= _V2_FAKT[1]:
            cell.fill = fill_fakt
        elif _V2_SMETA[0] <= c <= _V2_SMETA[1]:
            cell.fill = fill_smeta_head
        elif c <= _V2_AUX_COL:
            cell.fill = fill_header

    ws.row_dimensions[1].height = 75

    # Зона данных (пустая)
    align_map = {}
    for letter, _t, _w, al, wrap in _V2_COLUMNS:
        align_map[_V2_COL[letter]] = Alignment(
            horizontal={"l": "left", "c": "center"}.get(al),
            vertical="center", wrap_text=wrap)

    for r in range(2, rows + 2):
        for letter, _t, _w, _al, _wrap in _V2_COLUMNS:
            c = _V2_COL[letter]
            cell = ws.cell(row=r, column=c)
            cell.font = data_font
            cell.alignment = align_map[c]
            if c <= _V2_AUX_COL:
                cell.border = border
            if _V2_FAKT[0] <= c <= _V2_FAKT[1]:
                cell.fill = fill_fakt
            elif _V2_SMETA[0] <= c <= _V2_SMETA[1]:
                cell.fill = fill_smeta_body

    # Ширины столбцов
    for letter, _t, width, _al, _wrap in _V2_COLUMNS:
        if width is not None:
            ws.column_dimensions[letter].width = width

    # Скрытые столбцы и группировка
    for letter in _V2_HIDDEN_COLS:
        ws.column_dimensions[letter].hidden = True
    for letter in _V2_OUTLINE_COLS:
        ws.column_dimensions[letter].outlineLevel = 1
        ws.column_dimensions[letter].hidden = True
    if ws.sheet_properties.outlinePr is None:
        from openpyxl.worksheet.properties import Outline
        ws.sheet_properties.outlinePr = Outline()
    ws.sheet_properties.outlinePr.summaryRight = True

    # Закрепление шапки (T2: «Вспомогательный» в закреплённой зоне)
    ws.freeze_panes = "T2"

    return _safe_save(wb, output_file)


# Реестр вариантов: 1, 2 — реализованы; 3 — заглушка
BASE_TABLE_VARIANTS = {
    1: ("Вариант 1", _create_base_table_variant1),
    2: ("Вариант 2 (Расчёт)", _create_base_table_variant2),
    3: ("Вариант 3", None),  # заглушка под будущий VBA
}


def create_base_table(output_file, variant=1, progress_callback=None):
    """
    Создать базовую таблицу спецификации.

    variant — номер варианта (1 реализован; остальные — заглушки).
    Возвращает путь к созданному файлу.
    """
    title, fn = BASE_TABLE_VARIANTS.get(variant, (f"Вариант {variant}", None))
    _log(f"Создание базовой таблицы: {title}")
    if fn is None:
        raise NotImplementedError(
            f"{title} ещё не интегрирован (заглушка). "
            f"Пришлите VBA-код этого варианта для переноса в программу.")
    output_file = fn(output_file)
    _log("=" * 50)
    _log(f"✅  Базовая таблица создана ({title})")
    _log(f"    Файл сохранён: {output_file}")
    _log("=" * 50)
    return output_file


# ════════════════════════════════════════════════════════════════════
# САМОСТОЯТЕЛЬНЫЕ ЕДИНИЦЫ (отдельные точки входа для интерфейса)
# ════════════════════════════════════════════════════════════════════

def calc_fitting_area(spec_file, output_file=None, progress_callback=None):
    """Самостоятельная единица: ТОЛЬКО расчёт площади фасонных изделий (столбец S).
    База 1С не требуется."""
    return run_processing(spec_file, output_file=output_file,
                          mode=MODE_FITTING, progress_callback=progress_callback)


def compare_with_1c(spec_file, db_file=None, output_file=None, use_com=False,
                    selected_base=None, force_reload=False, progress_callback=None,
                    report_destination=None, report_folder=None):
    """Самостоятельная единица: ТОЛЬКО сравнение с 1С (столбец I).
    Требует загруженной/указанной номенклатуры 1С. По умолчанию
    force_reload=False — переиспользует уже проиндексированную базу."""
    return run_processing(spec_file, db_file=db_file, output_file=output_file,
                          use_com=use_com, selected_base=selected_base,
                          force_reload=force_reload, mode=MODE_MATCH,
                          progress_callback=progress_callback,
                          report_destination=report_destination, report_folder=report_folder)
