"""Разные размеры и наборы граф, переносы клапанов и страницы без шапки."""
import os
import sys
import tempfile
import unittest
from unittest.mock import patch
from pathlib import Path

import fitz
from openpyxl import load_workbook

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
from pdf_to_spec import extract_spec_rows, convert
from area_convert import convert_to_area
from pdf_layout import detect_columns, visible_page

FONT = fitz.Font('cjk').buffer


def make_pdf(path, scale=1, with_type=True, continuation=True, numbering=False):
    doc = fitz.open()
    edges = [40, 80, 350, 450, 500, 550] if with_type else [40, 80, 350, 400, 450]
    labels = ['Поз.', 'Наименование', 'Тип', 'Ед.', 'Кол.'] if with_type else ['Поз.', 'Наименование', 'Ед.', 'Кол.']
    def page():
        p = doc.new_page(width=650 * scale, height=400 * scale)
        p.insert_font(fontname='Fixture', fontbuffer=FONT)
        return p
    def text(p, x, y, value):
        p.insert_text((x * scale, y * scale), value, fontsize=8 * scale, fontname='Fixture')
    def grid(p, top, bottom, boundaries):
        for x in edges:
            p.draw_line((x * scale, top * scale), (x * scale, bottom * scale))
        for y in boundaries:
            p.draw_line((edges[0] * scale, y * scale), (edges[-1] * scale, y * scale))
        # Нижняя граница из заполненного прямоугольника толщиной 2 pt.
        p.draw_rect(fitz.Rect(edges[0] * scale, (bottom - 1) * scale,
                              edges[-1] * scale, (bottom + 1) * scale), fill=(0, 0, 0))
    p = page()
    text(p, 45, 24, 'Примечание: правила заказа')
    grid(p, 40, 220, [40, 75, 185, 220])
    for x, label in zip(edges, labels):
        text(p, x + 5, 54, label)
    text(p, edges[-3] + 5, 65, 'Изм.')
    if numbering:
        for i, x in enumerate(edges[:-1], 1):
            text(p, x + 5, 85, str(i))
        p.draw_line((edges[0] * scale, 95 * scale), (edges[-1] * scale, 95 * scale))
    text(p, 85, 110, 'Клапан противопожарный')
    text(p, 85, 126, 'с пределом огнестойкости EI60')
    text(p, 85, 142, 'привод снаружи, в комплекте')
    text(p, 85, 158, 'клеммная колодка')
    if with_type:
        text(p, 355, 122, 'КПВ.01(EI60)-НО-К-')
        text(p, 355, 141, '600x300-MBF-220')
    text(p, edges[-3] + 5, 133, 'шт.')
    text(p, edges[-2] + 5, 133, '2')
    text(p, 85, 203, 'Воздуховод 200x200')
    text(p, edges[-3] + 5, 203, 'м')
    text(p, edges[-2] + 5, 203, '5')
    if continuation:
        p = page()
        grid(p, 20, 120, [20, 70, 120])
        text(p, 85, 40, 'Воздухонагреватель водяной')
        text(p, 85, 55, '600x300')
        text(p, edges[-3] + 5, 47, 'шт.')
        text(p, edges[-2] + 5, 47, '1')
        text(p, 85, 95, 'Решетка вентиляционная')
        text(p, edges[-3] + 5, 95, 'шт.')
        text(p, edges[-2] + 5, 95, '3')
    doc.save(str(path), garbage=4, deflate=True)
    doc.close()


class AdaptiveLayoutTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.pdf = Path(self.tmp.name) / 'source.pdf'

    def check_rows(self, **options):
        make_pdf(self.pdf, **options)
        rows, _, _ = extract_spec_rows(str(self.pdf))
        self.assertEqual([r['QTY'] for r in rows], ['2', '5', '1', '3'])
        self.assertEqual(rows[0]['NAME'], 'Клапан противопожарный с пределом огнестойкости EI60 привод снаружи, в комплекте клеммная колодка')
        self.assertEqual(rows[2]['NAME'], 'Воздухонагреватель водяной 600x300')
        self.assertFalse(any('правила заказа' in r['NAME'] for r in rows))
        return rows

    def test_multiline_valve_is_one_position(self):
        rows = self.check_rows()
        self.assertIn('600x300-MBF-220', rows[0]['TYPE'])

    def test_table_can_be_scaled_without_new_template(self):
        for scale in [.7, 1.4, 2]:
            with self.subTest(scale=scale):
                self.check_rows(scale=scale)

    def test_optional_type_column_can_be_absent(self):
        rows = self.check_rows(with_type=False)
        self.assertEqual(rows[0]['TYPE'], '')
        self.assertEqual(rows[0]['CODE'], '')

    def test_column_numbering_does_not_consume_first_position(self):
        self.check_rows(numbering=True)

    def test_both_excel_formats_use_same_positions(self):
        make_pdf(self.pdf)
        for converter, columns in [(convert, 38), (convert_to_area, 6)]:
            path = str(Path(self.tmp.name) / ('result-%s.xlsx' % columns))
            _, count = converter(str(self.pdf), path)
            self.assertEqual(count, 4)
            book = load_workbook(path)
            self.assertEqual(book.active.max_column, columns)
            self.assertEqual(book.active.max_row, 5)
            book.close()

    def test_rotated_headers_define_quantity_and_unit_separately(self):
        make_pdf(self.pdf, continuation=False)
        source = fitz.open(str(self.pdf))
        rotated = fitz.open()
        page = rotated.new_page(width=400, height=650)
        page.show_pdf_page(page.rect, source, 0, rotate=90)
        page.set_rotation(90)
        shown = visible_page(page)
        words = shown.get_text('words')
        bounds = detect_columns(shown, words)
        self.assertIsNotNone(bounds)
        quantities = [w[4] for w in words
                      if bounds['QTY'][0] <= (w[0] + w[2]) / 2 < bounds['QTY'][1]
                      and w[4].isdigit()]
        units = [w[4] for w in words
                 if bounds['UNIT'][0] <= (w[0] + w[2]) / 2 < bounds['UNIT'][1]
                 and w[4] in ['шт.', 'м']]
        self.assertEqual(quantities, ['2', '5'])
        self.assertEqual(units, ['шт.', 'м'])
        rotated.close()
        source.close()

    def test_shared_position_number_does_not_merge_two_quantities(self):
        import pdf_to_spec as core
        bounds = {field: (0, 0) for field in core._COLUMN_ORDER}
        bounds.update(POS=(50, 100), NAME=(100, 300), TYPE=(300, 400),
                      UNIT=(450, 500), QTY=(500, 550))
        lines = []
        for y, entries in [(110, [(60, '7'), (110, 'Воздуховод 500'), (455, 'м'), (505, '1')]),
                           (130, [(110, 'толщиной 0,8 мм')]),
                           (150, [(110, 'Воздуховод 560'), (455, 'м'), (505, '1')])]:
            lines.extend(dict(x0=x, y0=y, text=text, font='ArialNarrow') for x, text in entries)
        with patch.object(core, '_iter_rotated_lines', return_value=lines):
            rows, pending, _ = core._extract_page_rows_rotated(None, bounds)
        self.assertEqual([r['QTY'] for r in rows] + [pending['QTY']], ['1', '1'])
        self.assertIn('толщиной', rows[0]['NAME'])
        self.assertNotIn('560', rows[0]['NAME'])

    def test_graphics_without_text_do_not_produce_successful_empty_excel(self):
        doc = fitz.open()
        doc.new_page().draw_rect(fitz.Rect(30, 30, 400, 600))
        doc.save(str(self.pdf))
        doc.close()
        for converter in [convert, convert_to_area]:
            path = str(Path(self.tmp.name) / 'empty.xlsx')
            with self.assertRaisesRegex(ValueError, 'Позиции спецификации не найдены'):
                converter(str(self.pdf), path)
            self.assertFalse(Path(path).exists())


if __name__ == '__main__':
    unittest.main()
