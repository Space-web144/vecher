"""Режим fitting меняет только значения площади, сохраняя исходный XLSX."""

import os
import re
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path
from xml.etree import ElementTree as ET
from unittest.mock import patch

from openpyxl import Workbook, load_workbook
from openpyxl.comments import Comment
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.worksheet.datavalidation import DataValidation

sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))
import vent_processor as core
from common.xlsx_values import save_numeric_cells, _patch_sheet


class FittingPreservationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.source = os.path.join(self.tmp.name, 'original.xlsx')
        self.output = os.path.join(self.tmp.name, 'result.xlsx')
        wb = Workbook()
        cover = wb.active
        cover.title = 'Титульный'
        cover['A1'] = 'Исходный титульный лист'
        cover.merge_cells('A1:D3')
        ws = wb.create_sheet('ОВ & лист 1')
        ws.append(['Проект', 'Сохраняем без изменений'])
        ws.append([])
        # Нестандартный порядок, шапка в строке 3, целевая колонка C, а не S.
        ws.append(['Примечание', 'Наименование', 'Вспомогательный', 'Количество'])
        ws.append(['Оригинал', 'Отвод 90° Ø200 δ=0.8', 'старое значение', '=2+3'])
        ws.append(['Труба', 'Воздуховод Ø200 L=1000', 987, '=D4*2'])
        ws.append(['Не поддерживается', 'Отвод 77° Ø160', 456, 1])
        ws.append(['Пустая площадь', 'Заглушка 500х1200', None, 2])
        ws.append(['Без имени', None, 654, 3])
        ws['B4'].font = Font(name='Arial', size=15, bold=True, color='123456')
        ws['C4'].fill = PatternFill('solid', fgColor='ABCDEF')
        ws['C4'].alignment = Alignment(horizontal='right')
        ws['C4'].number_format = '0.0000'
        ws['C4'].comment = Comment('Сохранить комментарий', 'Автор')
        ws['A4'].hyperlink = 'https://example.com/spec'
        ws.column_dimensions['B'].width = 43.5
        ws.column_dimensions['D'].hidden = True
        ws.row_dimensions[4].height = 47
        ws.freeze_panes = 'C4'
        ws.auto_filter.ref = 'A3:D8'
        ws.print_area = 'A1:D8'
        validation = DataValidation(type='whole', operator='between', formula1=0, formula2=100)
        ws.add_data_validation(validation)
        validation.add('D4:D8')
        other = wb.create_sheet('Второй расчёт')
        other.append(['Наименование', 'Вспомогательный'])
        other.append(['Отвод 90° Ø200 δ=0.8'])
        other.sheet_state = 'hidden'
        wb.active = 0
        wb.save(self.source)
        # Имитируем сохранённые Excel кэш формулы и неизвестную часть пакета.
        with zipfile.ZipFile(self.source) as z:
            parts = {i.filename: (i, z.read(i)) for i in z.infolist()}
        with zipfile.ZipFile(self.source, 'w') as z:
            for name, (info, data) in parts.items():
                if name == 'xl/worksheets/sheet2.xml':
                    data, count = re.subn(rb'<f>2\+3</f><v(?:\s*/>|>\s*</v>)',
                                          b'<f>2+3</f><v>5</v>', data)
                    self.assertEqual(count, 1, 'Не удалось подготовить кэш формулы')
                z.writestr(info, data)
            z.writestr('customXml/preserved.xml', b'<opaque>Do not rewrite</opaque>')

    def test_only_calculated_cells_change_in_entire_package(self):
        original_bytes = Path(self.source).read_bytes()
        with patch.object(core, '_apply_header_style', side_effect=AssertionError('header style')), \
             patch.object(core, '_apply_table_formatting', side_effect=AssertionError('table style')), \
             patch.object(core, 'load_database', side_effect=AssertionError('database')):
            core.run_processing(self.source, output_file=self.output, mode=core.MODE_FITTING,
                                report_destination='sheet')
        self.assertEqual(Path(self.source).read_bytes(), original_bytes)
        expected = {'xl/worksheets/sheet2.xml': ['C4', 'C6', 'C7'],
                    'xl/worksheets/sheet3.xml': ['B2']}
        with zipfile.ZipFile(self.source) as before, zipfile.ZipFile(self.output) as after:
            self.assertEqual(before.namelist(), after.namelist())
            for name in before.namelist():
                a, b = before.read(name), after.read(name)
                for ref in expected.get(name, []):
                    regex = rb'<c\b[^>]*\br="' + ref.encode() + rb'"[^>]*(?:/>|>.*?</c>)'
                    a, b = re.sub(regex, b'', a), re.sub(regex, b'', b)
                self.assertEqual(a, b, name)
        wb = load_workbook(self.output)
        self.addCleanup(wb.close)
        ws = wb['ОВ & лист 1']
        self.assertEqual(ws['C4'].value, 0.3)
        self.assertEqual(ws['C6'].value, 0)
        self.assertEqual(ws['C7'].value, core.calculate_fitting_surface('Заглушка 500х1200'))
        self.assertEqual(ws['C5'].value, 987)
        self.assertEqual(ws['C8'].value, 654)
        self.assertEqual(ws['D4'].value, '=2+3')
        self.assertEqual(ws['C4'].number_format, '0.0000')
        self.assertEqual(ws['C4'].comment.text, 'Сохранить комментарий')
        self.assertEqual(wb['Второй расчёт']['B2'].value, 0.3)

    def test_no_fittings_leaves_all_parts_identical(self):
        wb = Workbook()
        wb.active.append(['Наименование', 'Вспомогательный'])
        wb.active.append(['Вентилятор', 123])
        wb.save(self.source)
        core.calc_fitting_area(self.source, self.output)
        with zipfile.ZipFile(self.source) as a, zipfile.ZipFile(self.output) as b:
            self.assertEqual({n: a.read(n) for n in a.namelist()},
                             {n: b.read(n) for n in b.namelist()})

    def test_can_write_in_place(self):
        core.calc_fitting_area(self.source, self.source)
        wb = load_workbook(self.source)
        self.addCleanup(wb.close)
        self.assertEqual(wb['ОВ & лист 1']['C4'].value, 0.3)

    def test_error_keeps_existing_destination_intact(self):
        with open(self.output, 'wb') as f:
            f.write(b'previous result')
        with self.assertRaises(ValueError):
            save_numeric_cells(self.source, self.output, {'ОВ & лист 1': {'C9999': 0.3}})
        with open(self.output, 'rb') as f:
            self.assertEqual(f.read(), b'previous result')

    def test_prefixed_xml_single_quotes_and_empty_rows(self):
        xml = (b'<x:worksheet xmlns:x="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
               b'<x:sheetData><x:row r="1"/><x:row r="2"><x:c r="B2" s="3" t="s"><x:v>5</x:v></x:c>'
               b'<x:c r=\'D2\' s=\'1\'/></x:row></x:sheetData></x:worksheet>')
        result = _patch_sheet(xml, {'D2': 0.3, 'C2': 1.5})
        self.assertIn(b'<x:c r=\'D2\' s=\'1\'><x:v>0.3</x:v></x:c>', result)
        self.assertIn(b'<x:c r="C2"><x:v>1.5</x:v></x:c>', result)
        self.assertLess(result.index(b'r="C2"'), result.index(b"r='D2'"))
        self.assertIn(b'<x:c r="B2" s="3" t="s"><x:v>5</x:v></x:c>', result)

    def test_replacing_area_formula_rebuilds_only_calculation_metadata(self):
        with zipfile.ZipFile(self.source) as z:
            parts = {i.filename: (i, z.read(i)) for i in z.infolist()}
        with zipfile.ZipFile(self.source, 'w') as z:
            for name, (info, data) in parts.items():
                if name == 'xl/worksheets/sheet2.xml':
                    data = re.sub(rb'<c r="C4".*?</c>', b'<c r="C4" s="1"><f>1+2</f><v>3</v></c>', data)
                elif name == '[Content_Types].xml':
                    data = data.replace(b'</Types>', b'<Override PartName="/xl/calcChain.xml" '
                                        b'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.calcChain+xml"/></Types>')
                elif name == 'xl/_rels/workbook.xml.rels':
                    data = data.replace(b'</Relationships>', b'<Relationship Id="rId99" '
                                        b'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/calcChain" '
                                        b'Target="calcChain.xml"/></Relationships>')
                z.writestr(info, data)
            z.writestr('xl/calcChain.xml', b'<calcChain xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><c r="C4" i="2"/></calcChain>')
        core.calc_fitting_area(self.source, self.output)
        with zipfile.ZipFile(self.output) as z:
            self.assertNotIn('xl/calcChain.xml', z.namelist())
            for name in ['[Content_Types].xml', 'xl/_rels/workbook.xml.rels']:
                self.assertFalse(any('calcChain' in str(item.attrib) for item in ET.fromstring(z.read(name))))
            self.assertIn(b'<f>2+3</f><v>5</v>', z.read('xl/worksheets/sheet2.xml'))
        wb = load_workbook(self.output)
        self.addCleanup(wb.close)
        self.assertEqual(wb['ОВ & лист 1']['C4'].value, 0.3)

    def test_shared_formula_is_not_broken_by_partial_overwrite(self):
        xml = (b'<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
               b'<sheetData><row r="2"><c r="C2"><f t="shared" si="0" ref="C2:C3">A2*2</f>'
               b'<v>5</v></c></row></sheetData></worksheet>')
        with self.assertRaisesRegex(ValueError, 'групповая формула'):
            _patch_sheet(xml, {'C2': 0.3})


if __name__ == '__main__':
    unittest.main()
