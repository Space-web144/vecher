# -*- coding: utf-8 -*-
"""
Тесты генерации отчёта (V2.3) в run_processing/compare_with_1c: доп. лист
в файле спецификации либо отдельный файл в папке, для режимов match/full.

Запуск: из корня репозитория,
    python -m unittest discover -s program-a/tests -p "test_*.py"
"""

import glob
import os
import shutil
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from openpyxl import Workbook, load_workbook

import vent_processor as core


def _make_db_file(path, names):
    wb = Workbook()
    ws = wb.active
    ws["A1"], ws["B1"] = "Код", "Наименование"
    for i, name in enumerate(names, start=2):
        ws.cell(row=i, column=2, value=name)
    wb.save(path)


class ReportGenerationTests(unittest.TestCase):

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.tmpdir, "db.xlsx")
        _make_db_file(self.db_path, ["Отвод 90° Ø200 δ=0.8"])
        core.load_database(db_file_path=self.db_path, force_reload=True, use_com=False)

        self.spec_path = core.create_base_table(os.path.join(self.tmpdir, "спец.xlsx"))
        wb = load_workbook(self.spec_path)
        ws = wb.active
        ws["B2"] = "Отвод 90° Ø200 δ=0.8"
        ws["B3"] = "Что-то, чего нет в базе совсем"
        wb.save(self.spec_path)

    def test_no_report_by_default(self):
        out = core.compare_with_1c(self.spec_path, db_file=self.db_path, force_reload=False)
        wb = load_workbook(out)
        self.assertNotIn("Отчёт", wb.sheetnames)

    def test_report_destination_sheet_adds_sheet_to_output(self):
        out = core.compare_with_1c(self.spec_path, db_file=self.db_path, force_reload=False,
                                   report_destination="sheet")
        wb = load_workbook(out)
        self.assertIn("Отчёт", wb.sheetnames)
        rows = dict((r[0].value, r[1].value) for r in wb["Отчёт"].iter_rows(min_row=3) if r[0].value)
        self.assertEqual(rows["Точных совпадений (Tier 1)"], 1)
        self.assertEqual(rows["Не найдено"], 1)
        self.assertEqual(rows["  Точное совпадение, %"], 50.0)
        self.assertEqual(rows["  Отсутствие совпадения, %"], 50.0)
        self.assertRegex(rows["Начало обработки"], r"^\d{2}:\d{2}:\d{2}$")
        self.assertRegex(rows["Окончание обработки"], r"^\d{2}:\d{2}:\d{2}$")
        self.assertGreaterEqual(rows["Затрачено времени, сек"], 0)

    def test_report_destination_folder_writes_separate_file(self):
        report_dir = os.path.join(self.tmpdir, "reports")
        os.makedirs(report_dir)
        out = core.compare_with_1c(self.spec_path, db_file=self.db_path, force_reload=False,
                                   report_destination="folder", report_folder=report_dir)
        wb = load_workbook(out)
        self.assertNotIn("Отчёт", wb.sheetnames)
        report_files = glob.glob(os.path.join(report_dir, "*.xlsx"))
        self.assertEqual(len(report_files), 1)
        report_wb = load_workbook(report_files[0])
        self.assertEqual(report_wb.active["A1"].value, "Отчёт по сравнению с 1С")

    def test_fitting_mode_never_builds_report_even_if_requested(self):
        # fitting не использует базу 1С — отчёту не о чем говорить, поэтому
        # report_destination тут игнорируется, а не падает с ошибкой.
        out = core.run_processing(self.spec_path, mode=core.MODE_FITTING,
                                  report_destination="sheet")
        wb = load_workbook(out)
        self.assertNotIn("Отчёт", wb.sheetnames)

    def test_processing_timing_logged_even_without_report(self):
        # Тайминги в окне процессов — независимо от отчёта, для всех режимов
        # (в т.ч. "fitting", где отчёта вообще нет).
        log_lines = []
        core.set_logger(log_lines.append)
        try:
            core.run_processing(self.spec_path, mode=core.MODE_FITTING)
        finally:
            core.set_logger(None)
        joined = "\n".join(log_lines)
        self.assertIn("Начало обработки строк спецификации", joined)
        self.assertIn("Окончание обработки строк спецификации", joined)
        self.assertIn("Затрачено времени на обработку", joined)


class FullModeReportRegressionTests(unittest.TestCase):
    """
    Регрессия на реальный баг (найден на боевом файле пользователя,
    1775 строк): в режиме "full" общий счётчик найденных совпадений
    ("counter") не инкрементировался — только tier2_counter. Отчёт для
    MODE_MATCH этого не ловил (там counter инкрементируется отдельной
    веткой кода), поэтому баг молчал в тестах, пока не собрали report_stats
    для MODE_FULL и не получили отрицательный "Tier 1" и "Не найдено" == "Всего".
    """

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.db_path = os.path.join(self.tmpdir, "db.xlsx")
        _make_db_file(self.db_path, ["Отвод 90° Ø200 δ=0.8"])
        core.load_database(db_file_path=self.db_path, force_reload=True, use_com=False)

        self.spec_path = core.create_base_table(os.path.join(self.tmpdir, "спец.xlsx"))
        wb = load_workbook(self.spec_path)
        ws = wb.active
        ws["B2"] = "Отвод 90° Ø200 δ=0.8"       # Tier 1 — точное совпадение
        ws["B3"] = "Отвод 90° Ø200 δ=1.0"       # Tier 1 отвергает, Tier 2 предлагает
        ws["B4"] = "Что-то, чего нет в базе совсем"  # не найдено вовсе
        wb.save(self.spec_path)

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_full_mode_report_counts_are_non_negative_and_consistent(self):
        out = core.run_processing(self.spec_path, db_file=self.db_path, force_reload=False,
                                  mode=core.MODE_FULL, report_destination="sheet")
        wb = load_workbook(out)
        rows = dict((r[0].value, r[1].value) for r in wb["Отчёт"].iter_rows(min_row=3) if r[0].value)

        self.assertEqual(rows["Всего позиций"], 3)
        self.assertEqual(rows["Точных совпадений (Tier 1)"], 1)
        self.assertEqual(rows["Неподтверждённых подсказок (Tier 2)"], 1)
        self.assertEqual(rows["Не найдено"], 1)
        # Ключевая регрессия: "Не найдено" не должно молча стать равно "Всего",
        # а "Tier 1" не должен уйти в минус.
        self.assertNotEqual(rows["Не найдено"], rows["Всего позиций"])
        self.assertGreaterEqual(rows["Точных совпадений (Tier 1)"], 0)
        self.assertEqual(rows["Покрытие, %"], round(2 / 3 * 100, 1))


if __name__ == "__main__":
    unittest.main()
