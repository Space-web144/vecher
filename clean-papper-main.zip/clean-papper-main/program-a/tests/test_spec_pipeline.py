"""Selective routing, continuation, cached formulas and retry checkpoints."""
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

import fitz
from openpyxl import load_workbook

from test_spec_agent import FakeClient, answer, pdf, row
from test_pdf_systems import make_system_pdf
from spec_conversion import _assess_native, convert_specification
from spec_agent import validate_page, page_words


class SelectivePipelineTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.source, self.output = self.root / 'source.pdf', self.root / 'result.xlsx'

    def convert(self, **kwargs):
        return convert_specification(str(self.source), str(self.output), 'ventspec', **kwargs)

    def test_known_document_does_not_even_construct_api_client(self):
        make_system_pdf(self.source)
        def forbidden():
            self.fail('Known layout must stay on the native path')
        result = self.convert(client_factory=forbidden)
        self.assertEqual(result['engine'], 'native')
        self.assertEqual(result['ai_pages'], [])
        self.assertFalse(result['needs_review'])
        book = load_workbook(self.output, data_only=True)
        self.assertEqual(book.active['K2'].value, 'П1-1')
        self.assertNotIn('Проверка', book.sheetnames)
        book.close()

    def test_mixed_document_sends_only_unknown_page_and_preserves_native_rows(self):
        make_system_pdf(self.source)
        scan = self.root / 'scan.pdf'
        pdf(scan, scan=True)
        with fitz.open(str(self.source)) as doc, fitz.open(str(scan)) as extra:
            doc.insert_pdf(extra)
            temporary = self.root / 'mixed.pdf'
            doc.save(str(temporary))
        temporary.replace(self.source)
        client = FakeClient([answer()])
        result = self.convert(client=client)
        self.assertEqual(result['engine'], 'mixed')
        self.assertEqual(result['ai_pages'], [3])
        self.assertEqual(len(client.calls), 1)
        self.assertEqual(json.loads(client.calls[0][1])['page'], 3)
        book = load_workbook(self.output, data_only=True)
        self.assertEqual(book.active.max_row, 6)
        self.assertEqual(book.active['B2'].value.split()[0], 'Клапан')
        self.assertEqual(book.active['B6'].value, 'Duct')
        self.assertEqual(book.active['K2'].value, 'П1-1')
        self.assertIn('Проверка', book.sheetnames)
        book.close()

    def test_audit_sheet_keeps_formula_and_cache_for_ai_rows(self):
        pdf(self.source)
        value = answer()
        value['rows'][0]['POS'] = 'P1'
        self.convert(client=FakeClient([value]))
        formulas = load_workbook(self.output)
        cached = load_workbook(self.output, data_only=True)
        self.assertEqual(formulas.active['K2'].data_type, 'f')
        self.assertEqual(cached.active['K2'].value, 'P1')
        self.assertIn('A2', formulas.active['K2'].value)
        self.assertIn('Проверка', cached.sheetnames)
        formulas.close()
        cached.close()

    def test_retry_reuses_good_pages_even_with_different_output_filename(self):
        pdf(self.source, scan=True)
        cache = str(self.root / 'shared')
        self.convert(client=FakeClient([answer()]), cache_dir=cache)
        self.output = self.root / 'second.xlsx'
        resumed = FakeClient([])
        self.convert(client=resumed, cache_dir=cache)
        self.assertFalse(resumed.calls)
        self.assertTrue(self.output.exists())

    def test_unknown_layout_without_key_is_explicit_failure(self):
        pdf(self.source)
        with self.assertRaisesRegex(RuntimeError, 'подключение Anthropic'):
            self.convert(client_factory=lambda: None)
        self.assertFalse(self.output.exists())

    def test_unread_page_does_not_publish_partial_result(self):
        pdf(self.source, ['Duct', 'спецификация'])
        unread = answer([], spec=True)
        with self.assertRaisesRegex(RuntimeError, 'позиции не прочитаны'):
            self.convert(client=FakeClient([answer(), unread, unread]))
        self.assertFalse(self.output.exists())

    def test_cross_page_native_position_is_routed_as_a_whole(self):
        pdf(self.source, ['Duct', 'other'])
        with fitz.open(str(self.source)) as doc:
            native = [dict(row(), _PAGE=1, _SOURCE_PAGES=[0, 1])]
            with patch('spec_conversion.detect_columns', side_effect=[{'QTY': (1, 2)}, None]), \
                 patch('spec_conversion.table_extent', return_value=None), \
                 patch('spec_conversion._verify_native', return_value={'ok': True, 'positions_parsed': 1}):
                needed, _ = _assess_native(doc, str(self.source), native)
        self.assertEqual(needed, {0, 1})

    def test_system_names_cannot_be_invented_from_context(self):
        pdf(self.source)
        with fitz.open(str(self.source)) as doc:
            words = page_words(doc[0])
        value = answer()
        value['rows'][0]['SECTION'] = 'Invented'
        value['last_section'] = 'Invented'
        issues = validate_page(value, words, {'section': 'P1'})
        self.assertTrue(any('SECTION' in x for x in issues))
        self.assertTrue(any('last_section' in x for x in issues))


if __name__ == '__main__':
    unittest.main()
