# -*- coding: utf-8 -*-
"""Приёмочные сценарии PDF → модель → проверка → XLSX без внешнего API."""
import copy
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

import fitz
from openpyxl import load_workbook

ROOT = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(ROOT), str(ROOT / "program-a")]
from common.claude_client import ClaudeClient, ClaudeError
from spec_agent import FIELDS, read_specification, validate_page
from spec_conversion import convert_specification


def row(name="Duct", qty="2", continuation=False):
    value = {f: "" for f in FIELDS}
    value.update(NAME=name, QTY=qty, UNIT="pcs" if qty else "", SECTION="P1",
                 bbox=[90, 180, 850, 220], continuation=continuation)
    return value


def answer(rows=None, spec=True):
    return {"is_specification": spec, "last_section": "P1",
            "table_bbox": [90, 180, 850, 220], "quantity_x": [780, 850],
            "warnings": [], "rows": [row()] if rows is None else rows}


class FakeClient:
    model = "test-model"
    effort = "high"

    def __init__(self, responses):
        self.responses = list(responses)
        self.calls = []

    def extract_json(self, system, text, schema, **kwargs):
        self.calls.append((system, text, kwargs))
        if not self.responses:
            raise AssertionError("Лишний запрос к модели")
        value = self.responses.pop(0)
        if isinstance(value, Exception):
            raise value
        return copy.deepcopy(value)


def pdf(path, texts=None, scan=False):
    doc = fitz.open()
    for text in (texts or ["Duct"]):
        page = doc.new_page(width=1000, height=1000)
        page.insert_text((100, 200), text)
        if text == "Duct":
            page.insert_text((100, 150), "P1")
            page.insert_text((800, 200), "2")
            page.insert_text((700, 200), "pcs")
        if scan:
            png = page.get_pixmap().tobytes("png")
            page.clean_contents()
            # Заменяем страницу растровым изображением без текстового слоя.
            index = page.number
            doc.delete_page(index)
            page = doc.new_page(width=1000, height=1000)
            page.insert_image(page.rect, stream=png)
    doc.save(str(path))
    doc.close()


class SpecAgentTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.dir = Path(self.tmp.name)
        self.pdf = self.dir / "source.pdf"
        pdf(self.pdf)

    def test_uses_image_and_coordinates_and_preserves_excel_contracts(self):
        for fmt, columns in (("ventspec", 38), ("area", 6)):
            client = FakeClient([answer()])
            out = str(self.dir / (fmt + ".xlsx"))
            result = convert_specification(str(self.pdf), out, fmt, client=client)
            self.assertTrue(result["needs_review"])
            self.assertEqual(result["engine"], "claude")
            self.assertTrue(client.calls[0][2]["image_png"].startswith(b"\x89PNG"))
            self.assertIn('"box"', client.calls[0][1])
            book = load_workbook(out)
            self.assertEqual(book.active.max_column, columns)
            self.assertEqual(book.active.cell(2, 2).value, "Duct")
            self.assertEqual(book.active.cell(2, 7 if fmt == "ventspec" else 5).value, 2)
            self.assertIn("Проверка", book.sheetnames)
            self.assertIn('"page": 1', str(list(book["Проверка"].values)))
            if fmt == "area":
                self.assertIsNone(book.active.cell(2, 6).value)
            book.close()

    def test_repair_detects_unread_quantity_and_does_not_drop_rows(self):
        wrong = answer([row(qty="3")])
        client = FakeClient([wrong, answer()])
        data = read_specification(str(self.pdf), client)
        self.assertEqual(data["rows"][0]["QTY"], "2")
        self.assertEqual(len(client.calls), 2)
        self.assertFalse(data["pages"][0]["issues"])
        client = FakeClient([wrong, answer([], spec=False)])
        data = read_specification(str(self.pdf), client)
        self.assertEqual(len(data["rows"]), 1)
        self.assertTrue(data["pages"][0]["issues"])

    def test_repair_outage_keeps_first_response_and_warning(self):
        client = FakeClient([answer([row(qty="3")]), ClaudeError("offline")])
        data = read_specification(str(self.pdf), client)
        self.assertEqual(data["rows"][0]["QTY"], "3")
        self.assertTrue(data["pages"][0]["issues"])

    def test_false_classification_with_spec_signs_can_be_repaired(self):
        words = [{"text": "спецификация", "box": [10, 10, 50, 20]}]
        self.assertTrue(validate_page(answer([], spec=False), words))

    def test_resumes_page_checkpoint_and_invalidates_on_model_change(self):
        cache = self.dir / "cache"
        first = FakeClient([answer()])
        read_specification(str(self.pdf), first, cache_dir=str(cache))
        resumed = FakeClient([])
        read_specification(str(self.pdf), resumed, cache_dir=str(cache))
        self.assertFalse(resumed.calls)
        changed = FakeClient([answer()])
        changed.model = "another-model"
        read_specification(str(self.pdf), changed, cache_dir=str(cache))
        self.assertEqual(len(changed.calls), 1)

    def test_continuation_preserves_pages_context_and_conflicting_quantity(self):
        pdf(self.dir / "two.pdf", ["Duct", "extension"])
        extension = row("extension", "", continuation=True)
        client = FakeClient([answer(), answer([extension])])
        data = read_specification(str(self.dir / "two.pdf"), client)
        self.assertEqual(len(data["rows"]), 1)
        self.assertEqual(data["rows"][0]["NAME"], "Duct extension")
        self.assertEqual([s["page"] for s in data["rows"][0]["_SOURCES"]], [1, 2])
        self.assertEqual(json.loads(client.calls[1][1])["context"]["previous_row"]["QTY"], "2")
        # Конфликт сохраняется в исходных фрагментах и помечается.
        extension["QTY"] = "9"
        client = FakeClient([answer(), answer([extension]), answer([extension])])
        data = read_specification(str(self.dir / "two.pdf"), client)
        self.assertEqual(data["rows"][0]["QTY"], "2")
        self.assertEqual(data["rows"][0]["_FRAGMENTS"][0]["QTY"], "9")
        self.assertTrue(data["pages"][1]["issues"])

    def test_scan_is_read_by_vision_and_always_flagged(self):
        pdf(self.dir / "scan.pdf", scan=True)
        result = convert_specification(str(self.dir / "scan.pdf"), str(self.dir / "scan.xlsx"),
                                       "area", client=FakeClient([answer()]))
        self.assertTrue(result["needs_review"])
        with self.assertRaisesRegex(RuntimeError, "нет текстового слоя"):
            convert_specification(str(self.dir / "scan.pdf"), str(self.dir / "no.xlsx"), "area")

    def test_api_failure_does_not_publish_unverified_legacy(self):
        legacy_row = {f: "" for f in FIELDS}
        legacy_row.update(NAME="Duct", QTY="2", UNIT="pcs", _PAGE=0)
        output = str(self.dir / "fallback.xlsx")
        with patch("pdf_to_spec.extract_spec_rows", return_value=([legacy_row], False, False)):
            with self.assertRaisesRegex(RuntimeError, "Не удалось распознать страницу") as caught:
                convert_specification(str(self.pdf), output, "area",
                                      client=FakeClient([ClaudeError("private error detail")]))
        self.assertNotIn("private error detail", str(caught.exception))
        self.assertFalse(Path(output).exists())

    def test_empty_results_do_not_create_successful_workbook(self):
        out = str(self.dir / "empty.xlsx")
        with patch("pdf_to_spec.extract_spec_rows", return_value=([], False, False)):
            with self.assertRaisesRegex(RuntimeError, "Пустой Excel"):
                convert_specification(str(self.pdf), out, "area", client=FakeClient([answer([], spec=False)]))
        self.assertFalse(Path(out).exists())

    def test_unapproved_examples_are_not_sent_and_approved_invalidate_cache(self):
        examples = self.dir / "examples"
        examples.mkdir()
        example = {"approved": False, "source_text": "DO NOT SEND", "expected_rows": []}
        file = examples / "sample.json"
        file.write_text(json.dumps(example), encoding="utf-8")
        client = FakeClient([answer()])
        read_specification(str(self.pdf), client, examples_dir=examples, cache_dir=str(self.dir / "cache"))
        self.assertNotIn("DO NOT SEND", client.calls[0][1])
        example["approved"] = True
        file.write_text(json.dumps(example), encoding="utf-8")
        changed = FakeClient([answer()])
        read_specification(str(self.pdf), changed, examples_dir=examples, cache_dir=str(self.dir / "cache"))
        self.assertIn("DO NOT SEND", changed.calls[0][1])

    def test_formula_like_source_is_literal_text(self):
        value = answer([row("=1+1")])
        value["warnings"] = ["Проверьте наименование"]
        client = FakeClient([value, value])
        out = str(self.dir / "literal.xlsx")
        convert_specification(str(self.pdf), out, "area", client)
        book = load_workbook(out)
        self.assertEqual(book.active["B2"].value, "=1+1")
        self.assertEqual(book.active["B2"].data_type, "s")
        book.close()

    def test_cli_reports_failure_for_blank_pdf_without_key(self):
        blank = self.dir / "blank.pdf"
        doc = fitz.open()
        doc.new_page()
        doc.save(str(blank))
        doc.close()
        status = self.dir / "status.json"
        env = dict(os.environ)
        env.pop("ANTHROPIC_API_KEY", None)
        process = subprocess.run([sys.executable, str(ROOT / "program-a/web_pdf_run.py"),
                                  "--pdf", str(blank), "--output", str(self.dir / "blank.xlsx"),
                                  "--status-file", str(status), "--format", "area"],
                                 env=env, capture_output=True, text=True)
        self.assertEqual(process.returncode, 1)
        self.assertFalse(json.loads(status.read_text(encoding="utf-8"))["ok"])

    def test_rotated_words_are_mapped_to_visible_page(self):
        doc = fitz.open(str(self.pdf))
        doc[0].set_rotation(90)
        from spec_agent import page_words
        word = next(w for w in page_words(doc[0]) if w["text"] == "Duct")
        self.assertGreater(word["box"][0], 700)
        self.assertLess(word["box"][1], 200)
        doc.close()

    def test_wrong_quantity_column_cannot_pass_on_row_text_alone(self):
        from spec_agent import page_words
        with fitz.open(str(self.pdf)) as doc:
            words = page_words(doc[0])
        value = answer()
        value["quantity_x"] = [10, 20]
        self.assertTrue(any("не найдено" in issue for issue in validate_page(value, words)))

    def test_timeout_is_retried_and_wrapped(self):
        client = ClaudeClient(api_key="test")
        with patch.object(client, "_post", side_effect=TimeoutError("timeout")) as post:
            with patch("common.claude_client.time.sleep"):
                with self.assertRaises(ClaudeError):
                    client.extract_json("rules", "text", {})
        self.assertEqual(post.call_count, 3)

    def test_truncated_api_response_is_an_explicit_error(self):
        client = ClaudeClient(api_key="test")
        with patch.object(client, "_post", return_value={"stop_reason": "max_tokens", "content": []}):
            with self.assertRaisesRegex(ClaudeError, "обрезан"):
                client.extract_json("rules", "text", {})


if __name__ == "__main__":
    unittest.main()
