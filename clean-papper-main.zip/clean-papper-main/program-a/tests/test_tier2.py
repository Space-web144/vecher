# -*- coding: utf-8 -*-
"""
Тесты Tier 2 fallback в VentSpec (V2.1) — find_1c_match_with_tier:
приоритет Tier 1 над Tier 2, отсечка по TIER2_MIN_SCORE, покраска ячеек
(проверяется опосредованно через run_processing в test_run_processing.py
не заводим — это уже покрыто ручной регрессией на реальных данных при
разработке; здесь только сама функция find_1c_match_with_tier).

Запуск: из корня репозитория,
    python -m unittest discover -s program-a/tests -p "test_*.py"
(добавляет program-a/ в sys.path, чтобы импортировать vent_processor как
в vent_gui.py).
"""

import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))

from openpyxl import Workbook

import vent_processor as core


def _make_db_file(path, names):
    wb = Workbook()
    ws = wb.active
    ws["A1"], ws["B1"] = "Код", "Наименование"
    for i, name in enumerate(names, start=2):
        ws.cell(row=i, column=2, value=name)
    wb.save(path)


class FindMatchWithTierTests(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.tmpdir = tempfile.mkdtemp()
        cls.db_path = os.path.join(cls.tmpdir, "db.xlsx")
        _make_db_file(cls.db_path, [
            "Отвод 90° Ø200 δ=0.8",
            "Клапан противопожарный избыточного давления прямоугольный стеновой КПВ.03.(EI120)",
            "Декоративная решетка РНСс-600х600 Сигмавент",
        ])
        core.load_database(db_file_path=cls.db_path, force_reload=True, use_com=False)

    def test_tier1_exact_match_returns_tier_1(self):
        name, tier = core.find_1c_match_with_tier("Отвод 90° Ø200 δ=0.8", "", 3)
        self.assertEqual(tier, 1)
        self.assertEqual(name, "Отвод 90° Ø200 δ=0.8")

    def test_tier1_miss_falls_back_to_tier2(self):
        # δ=1.0 вместо 0.8 — Tier 1 сознательно отвергает (строгий критерий),
        # но текст достаточно похож, чтобы Tier 2 предложил кандидата.
        name, tier = core.find_1c_match_with_tier("Отвод 90° Ø200 δ=1.0", "", 3)
        self.assertEqual(tier, 2)
        self.assertEqual(name, "Отвод 90° Ø200 δ=0.8")

    def test_garbage_text_below_threshold_returns_nothing(self):
        # Строка-комментарий, а не наименование изделия — не должна получать
        # притянутую за уши "подсказку" только потому что Tier 2 всегда
        # готов выдать топ-1 без учёта score.
        name, tier = core.find_1c_match_with_tier(
            "Схема с отметками до 23 этажа, а по плану до 24 этажа клапана", "", 0)
        self.assertEqual(tier, 0)
        self.assertIsNone(name)


if __name__ == "__main__":
    unittest.main()
