"""Исключение накладных штампов и редактируемые обозначения систем в K."""
import sys
import tempfile
import unittest
import shutil
import subprocess
from pathlib import Path

import fitz
from openpyxl import load_workbook

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from pdf_to_spec import convert, _clean_position, _pos_marker, _SystemColumn
from pdf_layout import service_text_lines
from test_pdf_layout import make_pdf, FONT


def make_system_pdf(path):
    make_pdf(path)
    doc = fitz.open(str(path))
    page = doc[0]
    page.insert_font(fontname='Fixture', fontbuffer=FONT)
    page.insert_text((42, 133), 'П 1-1', fontsize=7, fontname='Fixture')
    page.insert_text((42, 203), 'В2-1', fontsize=7, fontname='Fixture')
    temporary = str(path) + '.new.pdf'
    doc.save(temporary, garbage=4, deflate=True)
    doc.close()
    Path(temporary).replace(path)


class SystemColumnTests(unittest.TestCase):
    def test_wrapped_and_spaced_markers_are_recognized(self):
        self.assertEqual(_clean_position('П 1-1'), 'П1-1')
        self.assertEqual(_clean_position('В7.4(12)- 1'), 'В7.4(12)-1')
        self.assertEqual(_pos_marker('П 1-1'), 'П1-1')

    def test_description_is_not_part_of_system_column(self):
        links = _SystemColumn(False)
        _, value = links.cell({'POS': 'Вж4.8', 'SECTION': 'Вж4.8 — Вентиляция общеобменная'}, 2)
        self.assertEqual(value, 'Вж4.8')
        _, value = links.cell({'POS': '', 'SECTION': 'Вж4.8 — Вентиляция общеобменная'}, 3)
        self.assertEqual(value, 'Вж4.8')

    def test_multiple_systems_remain_together_and_propagate(self):
        self.assertEqual(_pos_marker('Х3,Х4'), 'Х3, Х4')
        links = _SystemColumn(True)
        position, _ = links.cell({'POS': 'Х3,Х4', 'SECTION': 'Х3, Х4'}, 2)
        self.assertEqual(position, 'Х3, Х4')
        links.cell({'POS': '', 'SECTION': 'Х3, Х4'}, 3)
        self.assertEqual(links.cached, {'K2': 'Х3, Х4', 'K3': 'Х3, Х4'})

    def test_web_workbook_contains_formulas_and_readable_cached_values(self):
        with tempfile.TemporaryDirectory() as temporary:
            source, output = Path(temporary) / 'source.pdf', Path(temporary) / 'result.xlsx'
            make_system_pdf(source)
            convert(str(source), str(output), editable_systems=True)
            formulas = load_workbook(output)
            cached = load_workbook(output, data_only=True)
            try:
                self.assertEqual(formulas.active['A2'].value, 'П1-1')
                self.assertEqual(cached.active['K2'].value, 'П1-1')
                self.assertEqual(cached.active['K3'].value, 'В2-1')
                self.assertEqual(cached.active['K4'].value, 'В2-1')
                self.assertEqual(cached.active['K5'].value, 'В2-1')
                self.assertIn('A2', formulas.active['K2'].value)
                self.assertIn('K3', formulas.active['K4'].value)
                self.assertEqual(formulas.calculation.calcMode, 'auto')
            finally:
                formulas.close()
                cached.close()

    def test_web_entrypoint_enables_editable_systems(self):
        with tempfile.TemporaryDirectory() as temporary:
            import json
            root = Path(temporary)
            source, output, status = root / 'source.pdf', root / 'result.xlsx', root / 'status.json'
            make_system_pdf(source)
            entrypoint = Path(__file__).resolve().parents[1] / 'web_pdf_run.py'
            subprocess.run([sys.executable, str(entrypoint), '--pdf', str(source),
                            '--output', str(output), '--status-file', str(status),
                            '--format', 'ventspec'], check=True,
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE)
            self.assertTrue(json.loads(status.read_text())['ok'])
            book = load_workbook(output)
            try:
                self.assertEqual(book.active['K2'].data_type, 'f')
            finally:
                book.close()

    def test_internal_consumers_keep_literal_values(self):
        with tempfile.TemporaryDirectory() as temporary:
            source, output = Path(temporary) / 'source.pdf', Path(temporary) / 'result.xlsx'
            make_system_pdf(source)
            convert(str(source), str(output))
            book = load_workbook(output)
            try:
                self.assertEqual(book.active['K2'].value, 'П1-1')
                self.assertEqual(book.active['K2'].data_type, 's')
            finally:
                book.close()

    @unittest.skipUnless(shutil.which('soffice'), 'LibreOffice is not installed')
    def test_changing_A_recalculates_the_whole_system_in_Office(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source, output = root / 'source.pdf', root / 'source.xlsx'
            make_system_pdf(source)
            convert(str(source), str(output), editable_systems=True)
            book = load_workbook(output)
            book.active['A3'] = 'В99-2'
            book.save(output)
            book.close()
            destination = root / 'recalculated'
            destination.mkdir()
            profile = root / 'office-profile'
            subprocess.run(['soffice', '-env:UserInstallation=' + profile.as_uri(),
                            '--headless', '--convert-to', 'xlsx', '--outdir',
                            str(destination), str(output)], check=True,
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
            book = load_workbook(destination / output.name, data_only=True)
            try:
                self.assertEqual(book.active['K2'].value, 'П1-1')
                self.assertEqual([book.active['K%d' % r].value for r in [3, 4, 5]], ['В99-2'] * 3)
            finally:
                book.close()

    def test_images_do_not_shift_service_line_identifiers(self):
        doc = fitz.open()
        page = doc.new_page(width=300, height=300)
        pixmap = fitz.Pixmap(fitz.csRGB, fitz.IRect(0, 0, 2, 2), False)
        pixmap.clear_with(255)
        page.insert_image(fitz.Rect(5, 5, 20, 20), pixmap=pixmap)
        page.insert_font(fontname='Fixture', fontbuffer=FONT)
        page.insert_text((100, 118), 'Поставка комплектно', fontsize=8, fontname='Fixture')
        page.draw_rect(fitz.Rect(90, 85, 220, 145))
        for y, text in [(100, 'В производство работ'), (110, '____________'), (140, 'ФИО')]:
            page.insert_text((100, y), text, fontsize=8, fontname='Fixture')
        removed = service_text_lines(page)
        words = page.get_text('words')
        removed_words = [w[4] for w in words if (w[5], w[6]) in removed]
        self.assertIn('производство', removed_words)
        self.assertIn('ФИО', removed_words)
        self.assertNotIn('Поставка', removed_words)
        doc.close()

    def test_real_note_with_stamp_words_is_preserved_without_signature(self):
        doc = fitz.open()
        page = doc.new_page()
        page.insert_font(fontname='Fixture', fontbuffer=FONT)
        page.insert_text((100, 100), 'В производство работ передать комплект',
                         fontsize=8, fontname='Fixture')
        self.assertEqual(service_text_lines(page), set())
        doc.close()

    def test_only_stamp_lines_are_removed_even_in_same_block(self):
        class Page:
            rect = fitz.Rect(0, 0, 200, 200)
            def get_text(self, kind, **kwargs):
                return {'blocks': [{'number': 7, 'lines': [
                    {'bbox': (110, 100, 175, 110), 'spans': [{'text': 'В производство работ'}]},
                    {'bbox': (110, 115, 175, 125), 'spans': [{'text': '___________'}]},
                    {'bbox': (110, 130, 175, 140), 'spans': [{'text': 'ФИО'}]},
                    {'bbox': (110, 145, 175, 155), 'spans': [{'text': 'Поставка комплектно'}]},
                ]}]}
            def get_drawings(self):
                return [{'rect': fitz.Rect(105, 95, 180, 160)}]
        removed = service_text_lines(Page())
        self.assertEqual(removed, {(7, 0), (7, 1), (7, 2)})


if __name__ == '__main__':
    unittest.main()
