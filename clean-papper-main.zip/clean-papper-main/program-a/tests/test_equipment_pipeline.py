"""Entity semantics, range links, source validation and failure visibility."""
import os
from pathlib import Path
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch

import fitz
from openpyxl import load_workbook

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
import equipment_pipeline as ep
import equipment_table as et
from common.claude_client import ClaudeError


def r(source, system, mark, entity='fan', page=1, **kwargs):
    return ep.record(source, system, mark, entity, page, **kwargs)


class ComparisonTests(unittest.TestCase):
    def compare(self, *records):
        return ep.compare(list(records))[0]

    def test_unit_and_internal_fan_are_not_a_mismatch(self):
        rows = self.compare(r('hsov', 'П1', 'ПКО 60-35', 'equipment', alternatives=['ВРП-60-35-4D VA']),
                            r('spec', 'П1', 'ВРП-60-35-4D VA'),
                            r('selection', 'П1', 'ПКО 60-35', 'unit'),
                            r('selection', 'П1', 'ВРП-60-35-4D VA'))
        self.assertEqual(rows[0]['status'], et.STATUS_MATCH)
        self.assertEqual(rows[0]['hsov'], 'ВРП-60-35-4D VA')

    def test_different_internal_fan_is_not_selected_away(self):
        rows = self.compare(r('hsov', 'П1', 'ПКО 60-35', 'equipment', alternatives=['ВРП-60-35-4E VA']),
                            r('spec', 'П1', 'ВРП-60-35-4D VA'),
                            r('selection', 'П1', 'ПКО 60-35', 'unit'),
                            r('selection', 'П1', 'ВРП-60-35-4D VA'))
        self.assertEqual(rows[0]['status'], et.STATUS_MISMATCH)

    def test_ambiguous_alternative_cell_stays_unresolved(self):
        rows = self.compare(r('hsov', 'П1', 'ККО 250', 'equipment', alternatives=['ВКК 250', 'ВКК 200']),
                            r('spec', 'П1', 'ВКК 250'), r('selection', 'П1', 'ККО 250', 'unit'))
        self.assertFalse(rows[0]['hsov'])
        self.assertNotEqual(rows[0]['status'], et.STATUS_MATCH)

    def test_units_compare_as_units_and_preserve_L(self):
        row = self.compare(r('hsov', 'П1', 'ARN 80-50', 'equipment'),
                           r('spec', 'П1', 'ARN 80-50 L', 'unit'),
                           r('selection', 'П1', 'ARN 80-50', 'unit'),
                           r('selection', 'П1', 'RH40C'))[0]
        self.assertEqual(row['entity'], 'unit')
        self.assertEqual(row['selection'], 'ARN 80-50')
        self.assertEqual(row['status'], et.STATUS_MISMATCH)

    def test_equivalent_ranges_share_one_row(self):
        rows = self.compare(r('hsov', 'В6.1-1..В6.3-1', 'ВКК 100', count=3),
                            *[r('spec', 'В6.%s-1' % n, 'ВКК 100', page=n) for n in range(1, 4)],
                            r('selection', 'В6.1-1 - В6.3-1', 'ВКК 100', page=7))
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['status'], et.STATUS_MATCH)
        self.assertEqual(rows[0]['pages']['spec'], [1, 2, 3])
        self.assertNotIn('неполное', rows[0]['notes'])

    def test_truncated_range_requires_review_even_with_count(self):
        rows = self.compare(r('hsov', 'В5.1-1.....', 'ВКК 100', count=3),
                            *[r('spec', 'В5.%s-1' % n, 'ВКК 100') for n in range(1, 4)],
                            r('selection', 'В5.1-1 - В5.3-1', 'ВКК 100'))
        self.assertEqual(len(rows), 1)
        self.assertEqual(rows[0]['status'], ep.REVIEW)
        self.assertEqual(rows[0]['system'], 'В5.1-1.....')

    def test_overlapping_ranges_do_not_make_implicit_links(self):
        rows = self.compare(r('hsov', 'В1..В3', 'ВКК 100', count=3),
                            r('selection', 'В2..В4', 'ВКК 100'), r('spec', 'В2', 'ВКК 100'))
        self.assertFalse(any(row['status'] == et.STATUS_MATCH for row in rows))

    def test_similar_names_and_same_mark_are_not_aliases(self):
        for a, b in [('ДП1-1', 'ДП1.1'), ('ДВ2-1', 'ДВ2'), ('В1-1', 'ВВ1-1')]:
            rows = self.compare(r('hsov', a, 'ВКК 100'), r('spec', a, 'ВКК 100'),
                                r('selection', b, 'ВКК 100'))
            self.assertEqual(len(rows), 2)
            self.assertFalse(any(row['status'] == et.STATUS_MATCH for row in rows))

    def test_unassigned_marks_remain_evidence_without_assignment(self):
        records = [r('hsov', 'В1', 'ВКК 100'), r('spec', 'В1', 'ВКК 100'),
                   r('selection', '', 'ВКК 100', page=8)]
        rows, warnings = ep.compare(records)
        self.assertFalse(rows[0]['selection'])
        self.assertEqual(warnings[0][0], 8)

    def test_real_differences_survive_normalization(self):
        for a, b in [('ROOF-H 220 E2 30', 'ROOF-H 355 E4 30'),
                     ('ROOF-H 450 D4 30', 'ROOF-H 500 D4 30'), ('ВИОС-190-У1', 'ВИОС-190-У2')]:
            rows = self.compare(r('hsov', 'В1', a), r('spec', 'В1', b), r('selection', 'В1', a))
            self.assertEqual(rows[0]['status'], et.STATUS_MISMATCH)

    def test_truncated_mark_is_not_a_confirmed_mismatch_or_match(self):
        rows = self.compare(r('hsov', 'В1', 'ВР-80-70...'),
                            r('spec', 'В1', 'ВР-80-70-04'), r('selection', 'В1', 'ВР-80-70-04'))
        self.assertNotEqual(rows[0]['status'], et.STATUS_MATCH)
        self.assertNotEqual(rows[0]['status'], et.STATUS_MISMATCH)
        self.assertIn('многоточием', rows[0]['notes'])


class ReadingTests(unittest.TestCase):
    def test_rendering_stays_on_main_thread_with_bounded_api_workers(self):
        main = threading.get_ident()
        render_threads, request_threads = [], []
        original = ep.ai.page_png
        def render(page):
            render_threads.append(threading.get_ident())
            return original(page)
        class Client:
            def extract_json(self, *args, **kwargs):
                request_threads.append(threading.get_ident())
                return {'page_type':'selection', 'records':[
                    dict(system='P1',mark='FAN500',entity='fan',count=0)]}
        with tempfile.TemporaryDirectory() as tmp:
            pdf=Path(tmp)/'scans.pdf'
            doc=fitz.open()
            for _ in range(6):doc.new_page()
            doc.save(str(pdf));doc.close()
            with patch.object(ep.ai, 'page_png', side_effect=render):
                records, warnings, pages=ep.read_album(str(pdf),Client())
        self.assertEqual(len(render_threads),6)
        self.assertTrue(all(t==main for t in render_threads))
        self.assertTrue(all(t!=main for t in request_threads))
        self.assertEqual(len(records),6)

    def test_detached_article_is_a_datasheet_not_a_drawing(self):
        text = 'ROOF-H 500 D4 30 | Напряжение 400 Габаритные размеры Диаграмма SFP В4.1-1'
        self.assertEqual(et.classify_page(None, text=text), 'selection')
        self.assertEqual(et._DatasheetReader().system(text), 'В4.1-1')
        self.assertIsNone(et.classify_page(None, text='В1 ROOF-H 500 D4 30 | План кровли'))

    def test_vendor_continuation_keeps_system_and_entity(self):
        class Page:
            def __init__(self, text): self.text = text
            def get_text(self): return self.text
        first = Page('Технические данные Установка В5.1-1 - В5.14-1 (ID 1) Серия ККО Типоразмер 100')
        records, context = ep._native_selection(first, 1, None)
        records2, _ = ep._native_selection(Page('11 Наименование ВКК 100 Рабочее колесо ВКК 100'), 2, context)
        self.assertEqual(records[0]['entity'], 'unit')
        self.assertEqual(records2[0]['system'], 'В5.1-1 - В5.14-1')
        self.assertEqual(records2[0]['mark'], 'ВКК 100')

    def test_continuation_does_not_jump_over_unrelated_pages(self):
        class Page:
            def get_text(self): return 'Наименование ВКК 100 Рабочее колесо ВКК 100'
        context = dict(reader=et._VentartReader(), system='П1', page=1)
        records, _ = ep._native_selection(Page(), 9, context)
        self.assertFalse(any(item['system']=='П1' for item in records))

    def test_model_hallucinated_mark_rejected(self):
        class Page:
            def get_text(self): return 'System P1 fan FAN450'
        class Client:
            def extract_json(self, *a, **k):
                return {'page_type': 'selection', 'records': [dict(system='P1', mark='FAN500', entity='fan', count=0)]}
        with patch.object(ep.ai, 'page_png', return_value=b'image'):
            with self.assertRaises(ValueError): ep._read_model(Page(), 1, Client(), None)

    def test_scan_model_error_cannot_produce_empty_success(self):
        class Client:
            def extract_json(self, *a, **k): raise ClaudeError('fixture unavailable')
        with tempfile.TemporaryDirectory() as tmp:
            pdf = Path(tmp) / 'blank.pdf'
            doc = fitz.open();doc.new_page();doc.save(str(pdf));doc.close()
            with self.assertRaises(ValueError): ep.build(str(pdf), str(Path(tmp)/'out.xlsx'), Client())

    def test_scan_reading_has_explicit_review_and_pages(self):
        class Client:
            def extract_json(self, *a, **k):
                return {'page_type': 'selection', 'records': [dict(system='P1', mark='FAN500', entity='fan', count=0)]}
        with tempfile.TemporaryDirectory() as tmp:
            pdf=Path(tmp)/'scan.pdf';out=Path(tmp)/'out.xlsx'
            doc=fitz.open();doc.new_page();doc.save(str(pdf));doc.close()
            result=ep.build(str(pdf), str(out), Client())
            self.assertTrue(result['needs_review']);self.assertEqual(result['ai_pages'], 1)
            wb=load_workbook(out,data_only=True)
            self.assertEqual(wb['Источники']['E2'].value,1)
            self.assertGreater(wb['Проверка'].max_row,1)

    def test_partial_failure_is_visible_in_report_and_metadata(self):
        class Client:
            def extract_json(self, *a, **k): raise ClaudeError('fixture unavailable')
        with tempfile.TemporaryDirectory() as tmp:
            pdf=Path(tmp)/'scan.pdf';out=Path(tmp)/'out.xlsx'
            doc=fitz.open();doc.new_page();doc.new_page();doc.save(str(pdf));doc.close()
            text='ROOF-H 500 D4 30 | Габаритные размеры SFP В1-1'
            with patch.object(et, '_page_text', side_effect=lambda page: text if page.number==0 else ''):
                result=ep.build(str(pdf),str(out),Client())
            self.assertTrue(result['needs_review']);self.assertEqual(result['ai_pages'],1)
            self.assertIn('fixture unavailable',load_workbook(out,data_only=True)['Проверка']['B2'].value)

    def test_pdf_text_cannot_create_formulas_in_workbook(self):
        records=[r('selection','=HYPERLINK("fixture")','+danger')]
        rows,_=ep.compare(records)
        with tempfile.TemporaryDirectory() as tmp:
            out=Path(tmp)/'out.xlsx';ep.write_workbook(rows,records,[],[],str(out))
            wb=load_workbook(out)
            self.assertFalse(any(c.data_type=='f' for s in wb for row in s for c in row))


@unittest.skipUnless(os.environ.get('EQUIPMENT_CORPUS_PDF'), 'local owner PDF not included in repository')
class OwnerAlbumTests(unittest.TestCase):
    def test_belaya_dacha_all_three_fixes_and_real_differences(self):
        class NoApi:
            calls=0
            def extract_json(self,*a,**k):self.calls+=1;raise AssertionError('API not needed for this album')
        client=NoApi()
        with tempfile.TemporaryDirectory() as tmp:
            out=Path(tmp)/'report.xlsx'
            result=ep.build(os.environ['EQUIPMENT_CORPUS_PDF'],str(out),client)
            self.assertEqual(client.calls,0);self.assertEqual(result['ai_pages'],0)
            self.assertEqual(result['checked_pages'],165)
            wb=load_workbook(out,data_only=True)
            rows={et.normalize_system(row[0]):row for row in list(wb.active.values)[1:]}
            for s in ['П1.1-1','П1.2-1']+['В4.%s-1'%i for i in range(1,8)]:
                self.assertEqual(rows[et.normalize_system(s)][4],et.STATUS_MATCH,s)
            for s in ['В3.%s-1'%i for i in range(3,7)]+['ДП4.2-1','ДП2-1','П2-1','ДП6.1-1']:
                self.assertEqual(rows[et.normalize_system(s)][4],et.STATUS_MISMATCH,s)
            self.assertEqual(rows[et.normalize_system('В6.1-1.. В6.17-1')][3],'ВКК 100')
            self.assertEqual(rows[et.normalize_system('В5.1-1.....')][3],'ВКК 100')
            self.assertIn(et.normalize_system('ВВ1-1'),rows)
            self.assertIn(et.normalize_system('ДП1.1'),rows)
            self.assertEqual(sum(row[0]=='spec' for row in list(wb['Источники'].values)[1:]),62)


if __name__=='__main__':unittest.main()
