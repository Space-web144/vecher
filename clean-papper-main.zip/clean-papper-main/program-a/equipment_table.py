# -*- coding: utf-8 -*-
"""
Блок "Оборудование": сверка марок вентиляторов по трём видам листов
одного альбома РД.

На вход — один PDF (полный проект). Внутри него программа сама находит
три вида листов и берёт из каждого марку вентилятора по системам:

  1. ХСОВ — "Характеристика систем ... вентиляции", таблица в начале
     альбома: обозначение системы + столбец марки вентилятора (первый
     подстолбец группы "Вентилятор" — в разных альбомах он называется
     "Схема исполнения", "Исполнение по варианту" и т.п.);
  2. спецификация оборудования и материалов — строки про вентиляторы
     внутри раздела каждой системы, столбец "Тип, марка";
  3. листы подбора производителя — отдельные листы на систему
     ("ТЕХНИЧЕСКИЕ ДАННЫЕ №...", "Наименование системы ...") с маркой
     подобранного вентилятора.

На выход — Excel с пятью столбцами: система, марка по ХСОВ, по
спецификации, по листу подбора и статус сверки. Совпадением считается
только полное равенство марок после нормализации (регистр, пробелы,
дефисы, похожие кириллические/латинские буквы) — "похоже" не считается,
иначе проверка будет молча пропускать реальные ошибки проектировщика.

Табличные листы (ХСОВ и спецификация) читаются по линиям сетки, см.
pdf_grid.py: границы столбцов берутся из самого листа, а не подбираются
под конкретный альбом, как в pdf_to_spec.py. Листы подбора — не таблицы,
а верстка производителя, поэтому под каждого поставщика свой распознаватель
(см. _SELECTION_READERS); неизвестная вёрстка просто пропускается, и в
итоговой таблице у такой системы будет "нет данных", а не мусор.
"""

import os

# То же, что в начале web_run.py/web_pdf_run.py, и по той же причине:
# openpyxl тянет за собой numpy, а numpy с OpenBLAS при импорте пытается
# поднять поток на каждое ядро (на сервере это 40). На shared-хостинге
# упирается в лимит процессов аккаунта (RLIMIT_NPROC 36), pthread_create
# не проходит, и дальше MemoryError убивает процесс целиком. Один поток
# нам всё равно достаточен — считаем не матрицы, а строки таблиц.
# Выставлять нужно ДО импорта numpy, поэтому и стоит выше всех импортов.
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import re  # noqa: E402
import sys  # noqa: E402
import argparse  # noqa: E402
import collections  # noqa: E402

import fitz  # PyMuPDF  # noqa: E402
from openpyxl import Workbook  # noqa: E402
from openpyxl.styles import (  # noqa: E402
    Font, Alignment, Border, Side, PatternFill)

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import pdf_grid  # noqa: E402
import equipment_assist  # noqa: E402

# ── Виды листов ──────────────────────────────────────────────────────
KIND_HSOV = "hsov"
KIND_SPEC = "spec"
KIND_SELECTION = "selection"

# ── Статусы сверки (пятый столбец) ───────────────────────────────────
STATUS_MATCH = "Совпадает"
STATUS_MISMATCH = "Расхождение"
STATUS_MISSING = "Нет данных"

# Источники — порядок столбцов в отчёте.
SOURCE_HSOV = "hsov"
SOURCE_SPEC = "spec"
SOURCE_SELECTION = "selection"


# ────────────────────────────────────────────────────────────────────
# Нормализация
# ────────────────────────────────────────────────────────────────────

# Кириллические буквы, неотличимые на вид от латинских: в марках их
# путают постоянно (в одном листе "ВКК" кириллицей, в другом — латинскими
# "BKK"), и для сверки это одна и та же марка. Приводим кириллицу к
# латинице, а не наоборот, потому что марки чаще пишут латиницей.
_LOOKALIKE = {
    "А": "A", "В": "B", "Е": "E", "К": "K", "М": "M", "Н": "H", "О": "O",
    "Р": "P", "С": "C", "Т": "T", "У": "Y", "Х": "X",
}

# Символы, которые в марках ничего не значат и в разных листах ставятся
# по-разному: "ROOF-H 400 E4 30" / "ROOF H 400E4-30" — одна марка.
_MARK_NOISE = re.compile(r"[\s\-–—_,.]+")

# Обозначение системы: заглавная буква, ещё до трёх букв любого
# регистра (П, В, Вж, ДВ, ПД, ДП, У, КИД) и сразу за ними цифра.
# Отсекает заголовки разделов ("Общеобменная вентиляция", "Корпус 22.2",
# "Жилая часть", "Вентиляция ДВ2.1") от настоящих строк систем: у них
# между словом и цифрой всегда больше четырёх букв.
_SYSTEM_RE = re.compile(r"^[А-ЯЁA-Z][А-Яа-яЁёA-Za-z]{0,3}\s?\d")

# Отдельное обозначение внутри ячейки: "Вж2.9-Вж2.20" — это две штуки,
# то есть диапазон систем, а "П2.1моп" — одна.
_SYSTEM_TOKEN_RE = re.compile(
    r"[А-ЯЁA-Z][А-Яа-яЁёA-Za-z]{0,3}\s?\d[\d.\-–/]*[а-яёa-z]*")

# Прочерк в ячейке значит "нет оборудования", а не марку.
_DASHES = {"-", "–", "—", "нет", "без"}


def normalize_system(value):
    """Обозначение системы в виде, пригодном для сопоставления между
    листами: "П 1-3" / "п1-3" / "Установка ДП6.1-3" — одно и то же."""
    if not value:
        return ""
    text = str(value).strip()
    text = re.sub(r"^(установка|система|вентилятор)\s+", "", text, flags=re.IGNORECASE)
    text = text.replace("ё", "е").replace("Ё", "Е")
    text = re.sub(r"\s+", "", text).upper()
    return "".join(_LOOKALIKE.get(ch, ch) for ch in text)


def _expand_range(first, second):
    """Систем в диапазоне "Вж2.9-Вж2.20" — двенадцать. Разворачиваем
    его, только если обозначения отличаются ровно одним числом (и ничем
    больше): "В5.1-3,В5.6-3" — это тоже диапазон (секция 3, системы с
    первой по шестую), а вот "П2.1моп" и "В2.1нпки" рядом — нет."""
    if re.sub(r"\d+", "#", first) != re.sub(r"\d+", "#", second):
        return None
    numbers_first = list(re.finditer(r"\d+", first))
    numbers_second = list(re.finditer(r"\d+", second))
    if len(numbers_first) != len(numbers_second):
        return None
    differing = [i for i, (a, b) in enumerate(zip(numbers_first, numbers_second))
                 if a.group() != b.group()]
    if len(differing) != 1:
        return None
    index = differing[0]
    start = int(numbers_first[index].group())
    end = int(numbers_second[index].group())
    if end < start or end - start > 64:
        return None
    match = numbers_first[index]
    return [first[:match.start()] + str(number) + first[match.end():]
            for number in range(start, end + 1)]


def _expand_by_parts(designation, split_parts=True):
    """Системы из обозначения. split_parts=True — запятая разделяет
    перечисленные системы ("В6.2-4..В6.7-4, В6.9-4..В6.17-4" — два
    диапазона), False — вся ячейка читается как один диапазон от первого
    обозначения до последнего ("В5.1-3,В5.6-3")."""
    parts = re.split(r"[,;]", designation) if split_parts else [designation]
    members = []
    for part in parts:
        tokens = [token.strip(" .,-–—/…") for token in _SYSTEM_TOKEN_RE.findall(part)]
        tokens = [token for token in tokens if token]
        if not tokens:
            continue
        if len(tokens) == 2:
            expanded = _expand_range(tokens[0], tokens[1])
            if expanded:
                tokens = expanded
        for token in tokens:
            key = normalize_system(token)
            if key and key not in members:
                members.append(key)
    return members


def expand_systems(designation, expected=None):
    """Все системы, которые покрывает ячейка с обозначением. Обычно одна,
    но в ХСОВ одной строкой часто записывают диапазон однотипных систем
    ("Вж2.9-Вж2.20", кол-во систем 12) — сама строка в отчёте остаётся
    одна (так договорились), но найтись по ней должна любая система
    диапазона, иначе их разделы в спецификации выглядели бы как
    отсутствующие в ХСОВ.

    expected — сколько систем в этой строке по столбцу "Кол. систем",
    если он на листе есть."""
    if not designation:
        return []

    listed = _expand_by_parts(designation)

    # Запятая в обозначении значит то перечисление ("В6.1-4, В6.8-4" —
    # две системы), то диапазон ("В5.1-3,В5.6-3" — шесть систем секции 3).
    # По самой записи их не различить, зато различает столбец "Кол.
    # систем": берём то прочтение, которое сходится с ним.
    if expected and len(listed) != expected:
        whole = _expand_by_parts(designation, split_parts=False)
        if len(whole) == expected:
            return whole
    return listed


def normalize_mark(value):
    """Марка в виде, пригодном для сравнения: без регистра, пробелов,
    дефисов и кириллическо-латинских двойников."""
    if not value:
        return ""
    text = str(value).strip().upper()
    text = "".join(_LOOKALIKE.get(ch, ch) for ch in text)
    return _MARK_NOISE.sub("", text)


def _is_empty_mark(value):
    if not value:
        return True
    return str(value).strip().lower() in _DASHES


# ────────────────────────────────────────────────────────────────────
# Определение вида листа
# ────────────────────────────────────────────────────────────────────

def _page_text(page):
    return " ".join(page.get_text().split())


def classify_page(page, text=None):
    """Вид листа или None, если лист не из трёх интересующих нас видов
    (чертёж, титул, ведомость, схема)."""
    if text is None:
        text = _page_text(page)
    low = text.lower()

    # ХСОВ: шапка с группами "Вентилятор"/"Электродвигатель" над
    # столбцами и обозначение системы в первом столбце. Проверяется
    # первой: на таком листе есть и слово "вентилятор", и слово
    # "спецификация" в штампе.
    if "электродвигатель" in low and "вентилятор" in low and "обозн" in low:
        return KIND_HSOV

    # Спецификация оборудования и материалов (ГОСТ 21.110) — шапка
    # таблицы повторяется на каждом листе раздела.
    if "наименование и техническая характеристика" in low and "тип, марка" in low:
        return KIND_SPEC

    for reader in _SELECTION_READERS:
        if reader.matches(low, text) or reader.continues(low, text):
            return KIND_SELECTION

    return None


# ────────────────────────────────────────────────────────────────────
# ХСОВ
# ────────────────────────────────────────────────────────────────────

# Выше какой доли высоты листа искать название группы шапки: шапка
# ХСОВ занимает верхнюю часть таблицы, а слово "Вентилятор" ниже по листу
# встречается и в данных ("Радиальный вентилятор дымоудаления"), и в
# примечаниях.
_HEADER_ZONE = 0.25


_HAS_LETTER = re.compile(r"[A-Za-zА-Яа-яЁё]")
_HAS_DIGIT = re.compile(r"\d")


def _looks_like_marks(values):
    """Похож ли столбец на столбец марок.

    Соседние столбцы ХСОВ различаются составом значений, и это надёжнее
    любых названий: в марке есть и буквы, и цифры ("ROOF-H 450 D4 30",
    "ВРП-60-35-4D VA", "turbo 100"); в типе установки — только слова
    ("крышный", "канальный осевой"); в расходе, напоре и оборотах —
    только числа.
    """
    values = [value for value in values if value and not _is_empty_mark(value)]
    if not values:
        return False
    mixed = sum(1 for value in values
                if _HAS_LETTER.search(value) and _HAS_DIGIT.search(value))
    return mixed * 2 >= len(values)


def _fan_mark_column(page, table, system_col):
    """Столбец марки вентилятора — первый подстолбец группы "Вентилятор".

    Сначала по чертежу: название группы в шапке нарисовано одной ячейкой
    на несколько столбцов, поэтому от слова "Вентилятор" идём влево, пока
    слева не окажется линия, доходящая до высоты этого слова. В части
    альбомов линия левой границы группы нарисована не на всю высоту
    шапки, и так можно уехать на столбец-другой левее — в тип установки.
    Поэтому результат проверяется по данным: берём первый столбец
    вправо, значения которого выглядят как марки.
    """
    matrix = page.rotation_matrix
    limit = page.rect.height * _HEADER_ZONE
    label = None
    for x0, y0, x1, y1, word, _b, _l, _w in page.get_text("words"):
        if word.strip().lower() != "вентилятор":
            continue
        rect = fitz.Rect(x0, y0, x1, y1) * matrix
        if rect.y0 >= limit:
            continue
        if label is None or rect.y0 < label.y0:
            label = rect
    if label is None:
        return None

    label_col = table.column_at((label.x0 + label.x1) / 2.0)
    if label_col is None:
        return None
    start = table.group_first_column(label_col, (label.y0 + label.y1) / 2.0)

    data_rows = [row for row in range(table.n_rows)
                 if _SYSTEM_RE.match(table.cell(row, system_col) or "")]

    def marks_here(column):
        return _looks_like_marks([table.cell(row, column) for row in data_rows])

    # Сначала внутри найденной группы, слева направо: марка — её первый
    # подстолбец, дальше идут расход, напор и обороты.
    for column in range(start, label_col + 1):
        if marks_here(column):
            return column
    # Ничего похожего на марки в группе нет — значит левая граница
    # найдена неверно (в альбомах встречается и обратный порядок: марка
    # в столбце "Тип (наименование)", а следом "Исполнение по
    # взрывозащите" с типом установки). Идём левее, от границы к
    # обозначению системы, и берём ближайший столбец с марками.
    for column in range(start - 1, system_col, -1):
        if marks_here(column):
            return column
    return start


def read_hsov_page(page):
    """Строки ХСОВ одного листа: [(обозначение системы, марка)].

    Столбец марки — первый подстолбец группы "Вентилятор". Название у
    него в каждом альбоме своё ("Схема исполнения", "Исполнение по
    варианту"), поэтому ищем его по чертежу: находим название группы и
    идём влево до границы группы (см. _fan_group_first_column).
    """
    table = pdf_grid.read_table(page)
    if table is None:
        return []

    system_col = table.find_column("обозн")
    if system_col is None:
        return []

    mark_col = _fan_mark_column(page, table, system_col)
    if mark_col is None:
        # Запасной путь, если название группы на листе не нашлось:
        # столбец, в шапке которого есть "исполнение". По названию
        # "Тип (наименование)" ориентироваться нельзя — так называется и
        # первый подстолбец группы "Электродвигатель", и марка вентилятора
        # подменялась мощностью двигателя из соседнего столбца.
        mark_col = table.find_column("исполнени")
    if mark_col is None:
        return []

    # "Кол. систем" — сколько систем покрывает строка. Нужен там, где
    # одной строкой записан диапазон: по самой записи "В5.1-3,В5.6-3"
    # не понять, две это системы или шесть (см. expand_systems).
    count_col = table.find_column("кол. систем", "кол.систем", "кол-во систем")

    rows = []
    for row in range(table.n_rows):
        system = table.cell(row, system_col)
        if not system or not _SYSTEM_RE.match(system):
            continue
        count = None
        if count_col is not None:
            digits = re.sub(r"\D", "", table.cell(row, count_col))
            count = int(digits) if digits else None
        mark = table.cell(row, mark_col)
        if not mark and table.is_merged_with_previous(row, mark_col):
            # Ячейка объединена с предыдущей строкой (пара "рабочий /
            # холодный резерв" — марка написана один раз на две системы).
            for previous in range(row - 1, -1, -1):
                candidate = table.cell(previous, mark_col)
                if candidate:
                    mark = candidate
                    break
        if _is_empty_mark(mark):
            mark = ""
        rows.append((system.strip(), mark.strip(), count))
    return rows


# ────────────────────────────────────────────────────────────────────
# Спецификация
# ────────────────────────────────────────────────────────────────────

# Наименование позиции считается вентилятором, если в нём есть одно из
# этих слов...
_FAN_WORDS = (
    "вентилятор",
    "установка приточ", "установка вытяж", "установка притоно",
    "установка приточно", "установка вентиляц", "вентагрегат",
)

# ...и при этом позиция не из тех, у кого слово "вентилятор" есть в
# наименовании, но сама она вентилятором не является: стакан "для
# крышных вентиляторов", виброизоляторы вентилятора, решётка и т.п.
# Сверяется по первому слову наименования — оно и называет изделие.
_NOT_FAN_FIRST_WORDS = (
    "стакан", "шумоглушитель", "виброизолятор", "виброизоляторы",
    "кронштейн", "крепление", "детали", "решетка", "решётка", "зонт",
    "дефлектор", "клапан", "переходник", "рама", "козырек", "козырёк",
    "гибкая", "вставка", "площадка", "ограждение", "монтажный",
    "регулятор", "преобразователь", "щит", "пульт", "кабель",
)


def _is_fan_name(name):
    if not name:
        return False
    low = name.lower()
    if not any(word in low for word in _FAN_WORDS):
        return False
    first = re.split(r"[\s,.]+", low.strip(), 1)[0]
    return first not in _NOT_FAN_FIRST_WORDS


# Подзаголовки внутри раздела системы ("а. Оборудование", "б. Материалы")
# — это оформление, а не новая группа: они не должны подменять собой
# текущую систему.
_SUBHEADING_RE = re.compile(r"^[а-яa-z]\s*[.)]\s|^(оборудование|материалы)$",
                            re.IGNORECASE)


# Разделы спецификации не по системам: под таким заголовком тоже бывают
# вентиляторы, и относить их к системе, которая шла выше, нельзя.
_SECTION_HEADINGS = (
    "резервное оборудование", "дополнительные материалы",
    "дополнительное оборудование",
)


def _leading_system(text):
    """Обозначение системы в начале строки-заголовка раздела:
    "ВЕ3 (Помещение СС (малое))" -> "ВЕ3", "Вж2.9-Вж2.20" -> весь
    диапазон, "нормально открытый, EI60" -> ничего."""
    text = (text or "").strip()
    if not _SYSTEM_RE.match(text):
        return ""
    tokens = _SYSTEM_TOKEN_RE.findall(text)
    if not tokens:
        return ""
    designation = tokens[0]
    for separator in ("-", "–", ","):
        pair = tokens[0] + separator + (tokens[1] if len(tokens) > 1 else "")
        if len(tokens) > 1 and text.startswith(pair):
            designation = pair
            break
    rest = text[len(designation):].strip()
    # Марка оборудования начинается так же, как обозначение системы
    # ("IRFD 500x300-4 VIM", "TUBE 315 XL" — буквы, потом цифры), и
    # перепутать их нельзя: после обозначения системы в заголовке раздела
    # идёт либо ничего, либо пояснение в скобках или через тире
    # ("ВЕ3 (Помещение СС (малое))"), а у марки — продолжение самой марки.
    if rest and rest[0] not in "(—–-":
        return ""
    return designation


def _system_from_cell(text):
    """Обозначение системы, если ячейка "Поз." его содержит.

    Обычно там ровно обозначение ("В2.1моп", "Вж2.9-Вж2.20"), но
    попадается и с пояснением ("Вентиляция ДВ2.1") — тогда берём из него
    само обозначение. Ячейки вроде "Воздухозабор" обозначением не
    являются: в них нет ни одной цифры после букв.
    """
    text = (text or "").strip()
    if not text:
        return ""
    if _SYSTEM_RE.match(text):
        return text
    tokens = _SYSTEM_TOKEN_RE.findall(text)
    if len(tokens) == 1 and len(text.split()) <= 3 and text.endswith(tokens[0]):
        return tokens[0]
    return ""


def read_spec_page(page, current_system=""):
    """Вентиляторы одного листа спецификации:
    ([(система, наименование, марка)], система на конец листа).

    Раздел системы в спецификации открывается строкой, где заполнен
    только столбец "Поз." (обозначение системы), а дальше идут её
    позиции — так же, как это устроено во втором шаблоне
    pdf_to_spec.py. Раздел может продолжаться на следующий лист,
    поэтому текущая система передаётся между листами.
    """
    table = pdf_grid.read_table(page)
    if table is None:
        return [], current_system

    pos_col = table.find_column("поз.", "позиция")
    name_col = table.find_column("наименование и техническая")
    type_col = table.find_column("тип, марка")
    if pos_col is None or name_col is None or type_col is None:
        return [], current_system
    unit_col = table.find_column("ед.", "единица")
    qty_col = table.find_column("кол.", "количество")

    fans = []
    for row in range(table.n_rows):
        pos = table.cell(row, pos_col).strip()
        name = table.cell(row, name_col).strip()
        mark = table.cell(row, type_col).strip()
        unit = table.cell(row, unit_col).strip() if unit_col is not None else ""
        qty = table.cell(row, qty_col).strip() if qty_col is not None else ""

        system = _system_from_cell(pos)
        if system:
            current_system = system
        elif name and not mark and not unit and not qty:
            # Строка без единой характеристики — либо заголовок раздела,
            # либо продолжение длинного наименования, перенесённого на
            # следующую строку ("нормально открытый, EI60,"). Заголовком
            # считаем только то, что им выглядит: обозначение системы в
            # начале строки (в части альбомов раздел системы открывается
            # именно так, а не значением в "Поз.") или раздел не по
            # системам ("Резервное оборудование") — иначе перенос
            # наименования подменил бы собой текущую систему.
            heading = _leading_system(name)
            if heading:
                current_system = heading
            elif name.strip().lower().rstrip(":.") in _SECTION_HEADINGS:
                current_system = name.strip()

        if not _is_fan_name(name):
            continue
        fans.append((current_system, name, "" if _is_empty_mark(mark) else mark))

    return fans, current_system


# ────────────────────────────────────────────────────────────────────
# Листы подбора
# ────────────────────────────────────────────────────────────────────

class _SelectionReader(object):
    """Распознаватель листов подбора одного поставщика.

    Лист подбора одной установки занимает несколько страниц: обозначение
    системы напечатано на первой, а марка вентилятора — дальше, в
    разделе "Вентилятор". Поэтому читается не страница, а серия страниц:
    system() говорит, начинается ли на странице новая установка, а
    mark() достаёт марку с любой страницы этой серии.
    """

    name = ""

    def matches(self, low, text):
        """Правда ли, что с этой страницы начинается лист подбора."""
        raise NotImplementedError

    def continues(self, low, text):
        """Правда ли, что это продолжение уже начатого листа подбора:
        разделы установки печатаются на отдельных страницах, и та, где
        стоит марка вентилятора, шапки листа уже не содержит."""
        return False

    def system(self, text):
        """Обозначение системы, если оно напечатано на этой странице."""
        return None

    def mark(self, text):
        """Марка самого вентилятора — то, что сверяется с ХСОВ и
        спецификацией."""
        return None

    def fallback_mark(self, text):
        """Марка установки целиком (серия + типоразмер) — подставляется
        только если марки вентилятора в листе подбора не нашлось: в ХСОВ
        и спецификации у приточных установок стоит именно вентилятор, и
        сравнивать установку с вентилятором было бы сравнением разных
        вещей."""
        return None


class _VentartReader(_SelectionReader):
    """ВентАрт/Ноиззлесс: "ТЕХНИЧЕСКИЕ ДАННЫЕ №VR25-009129-01 ...",
    "Установка П2.2охр (ID 4723142)", далее разделы установки, среди них
    "N. Вентилятор Наименование ВКК 200"."""

    name = "ventart"

    _SYSTEM = re.compile(r"Установка\s+(.+?)\s*\(ID", re.IGNORECASE)
    _FAN = re.compile(
        r"Вентилятор\s+Наименование\s+(.+?)\s+(?:Рабочее колесо|Расход|Напор|Обороты)",
        re.IGNORECASE)
    # Запасной путь — марка самой установки (серия + типоразмер), если
    # раздела с вентилятором в листе нет.
    _SERIES = re.compile(r"Серия\s+(\S+)\s+Типоразмер\s+(\S+)", re.IGNORECASE)

    def matches(self, low, text):
        return "технические данные" in low and "установка" in low

    def continues(self, low, text):
        # Страница с разделом "N. Вентилятор" — шапки листа на ней нет,
        # а марка вентилятора есть только здесь.
        return "рабочее колесо" in low

    def system(self, text):
        found = self._SYSTEM.search(text)
        return found.group(1).strip() if found else None

    def mark(self, text):
        found = self._FAN.search(text)
        return found.group(1).strip() if found else None

    def fallback_mark(self, text):
        found = self._SERIES.search(text)
        if found:
            return (found.group(1) + " " + found.group(2)).strip()
        return None


class _AironeReader(_SelectionReader):
    """AirOne/airqlick: "Наименование системы ДВ2.1 Дата подбора ...",
    "Вентилятор ВР-80-70К-10,0-... График и технические данные"."""

    name = "airone"

    _SYSTEM = re.compile(r"Наименование системы\s+(\S+)\s+Дата подбора", re.IGNORECASE)
    _FAN = re.compile(r"Вентилятор\s+(\S+)\s+График", re.IGNORECASE)

    def matches(self, low, text):
        return "наименование системы" in low and "дата подбора" in low

    def system(self, text):
        found = self._SYSTEM.search(text)
        return found.group(1).strip() if found else None

    def mark(self, text):
        found = self._FAN.search(text)
        return found.group(1).strip() if found else None


class _DatasheetReader(_SelectionReader):
    """Технический лист на сам вентилятор.

    Две виденные вёрстки одного и того же поставщика (Ноиззлесс):
    заголовок "Технические характеристики ROOF-H 400 E4 30 | 131092" —
    и лист, где в заголовке стоит только марка, а марка с артикулом
    ("ROOF-H 450 D4 30 | 131105") напечатана ниже, под диаграммой.

    Обозначение системы на таком листе бывает и есть ("В4.5-4" рядом с
    маркой), и нет. Если есть — лист привязывается к системе, как любой
    другой; если нет — марка кладётся в общий "мешок" и подставляется
    той системе, у которой марка совпала.
    """

    name = "datasheet"

    _MARK_TITLE = re.compile(r"Технические характеристики\s+(.+?)\s*\|", re.IGNORECASE)
    # Марка с артикулом: "ROOF-H 450 D4 30 | 131105". Артикул — 5-7 цифр,
    # этим он отличается от прочих вертикальных черт на листе
    # ("Напряжение UN 400 | 3~").
    _CODE = re.compile(r"\|\s*\d{5,7}(?!\d)")
    # Экспортируемые листы могут печатать артикул отдельным блоком,
    # далеко от «|». Марка при этом остаётся возле разделителя.
    _DETACHED_CODE_MARK = re.compile(
        r"(?<![A-Za-zА-Яа-яЁё0-9])"
        r"([A-ZА-ЯЁ][A-ZА-ЯЁ0-9-]{2,}\s+\d{2,4}\s+[DE]\d\s+\d{2})\s*\|")
    # Сама марка — последние слова перед артикулом. Ищем их справа
    # налево (регулярка привязана к концу строки), иначе совпадение
    # начинается где-нибудь в предыдущем абзаце и в марку уезжает
    # половина листа.
    _MARK_TAIL = re.compile(
        r"(?<![A-Za-zА-Яа-яЁё0-9/])((?:[A-ZА-ЯЁ0-9][A-ZА-ЯЁ0-9\-/.]*)"
        r"(?:\s+[A-ZА-ЯЁ0-9][A-ZА-ЯЁ0-9\-/.]*){0,4})\s*$")
    # Обозначение системы на таком листе — отдельное слово кириллицей:
    # "В4.5-4". Латиницу не берём, иначе в обозначение попала бы часть
    # самой марки ("H 450" из "ROOF-H 450 D4 30").
    _SYSTEM = re.compile(
        r"(?<![0-9A-Za-zА-Яа-яЁё])"
        r"([А-ЯЁ][А-Яа-яЁё]{0,2}\d(?:[.\-–]?\d+)*[а-яё]{0,4})"
        r"(?![0-9A-Za-zА-Яа-яЁё])")
    def matches(self, low, text):
        return self.mark(text) is not None

    def _code_mark(self, text):
        found = self._CODE.search(text)
        if not found:
            low = text.lower()
            technical = sum(hint in low for hint in (
                'габаритные размеры', 'электрическая схема', 'диаграмма',
                'sfp', 'sound power', 'степ. защиты'))
            detached = self._DETACHED_CODE_MARK.search(text) if technical >= 2 else None
            return detached.group(1).strip() if detached else None
        tail = self._MARK_TAIL.search(text[:found.start()])
        return tail.group(1).strip() if tail else None

    @staticmethod
    def _plausible(value):
        """Отсев случайных совпадений: в марке есть цифры, она короткая и
        в ней нет обычных русских слов. Без этой проверки в марку уезжала
        оговорка "В технические характеристики могут вноситься
        изменения...", напечатанная на каждом листе Ноиззлесс."""
        if not value or len(value) > 48:
            return False
        if not _HAS_DIGIT.search(value):
            return False
        return not re.search(r"[а-яё]{3,}", value)

    def system(self, text):
        # Обозначение системы печатают где придётся: у одного альбома —
        # в шапке рядом с маркой ("ROOF-H 450 D4 30 В4.5-4"), у другого —
        # в самом низу листа, после выходных данных ("... TCPDF ... В2.1 8").
        # Поэтому ищем по всему тексту. Ложных срабатываний почти нет:
        # обозначение — кириллица с цифрой сразу за буквами, а технические
        # данные на таких листах набраны латиницей ("LWA5", "IP54", "P1").
        found = self._SYSTEM.search(text)
        return found.group(1).strip() if found else None

    def mark(self, text):
        # Сначала марка с артикулом — она однозначна; заголовок листа
        # берём только если артикула на листе нет.
        for candidate in (self._code_mark(text), self._title_mark(text)):
            if self._plausible(candidate):
                return candidate
        return None

    def _title_mark(self, text):
        found = self._MARK_TITLE.search(text)
        return found.group(1).strip() if found else None


_SELECTION_READERS = (_VentartReader(), _AironeReader(), _DatasheetReader())


def read_selection_pages(pages_text):
    """Подбор по всему альбому: (по системам {система: [марки]}, марки
    без системы [марки]).

    pages_text — [(номер страницы, текст)] только тех страниц, которые
    classify_page() отнёс к листам подбора.
    """
    # Марки вентиляторов и запасные марки установок копятся раздельно:
    # лист подбора приточной установки называет и то, и другое (серия
    # ККО 200 — сама установка, ВКК 200 — вентилятор внутри неё), а в
    # отчёт должна попасть одна строка, и именно с вентилятором.
    fans = collections.OrderedDict()
    fallbacks = collections.OrderedDict()
    loose = []

    current_system = None
    current_reader = None
    for _page_no, text in pages_text:
        low = text.lower()
        reader = next((r for r in _SELECTION_READERS if r.matches(low, text)), None)
        if reader is None:
            # Продолжение листа того же поставщика (см. continues) —
            # система остаётся прежней, меняется только откуда берём марку.
            if current_reader is not None and current_reader.continues(low, text):
                reader = current_reader
            else:
                continue

        system = reader.system(text)
        if system:
            current_system = system
            current_reader = reader
            fans.setdefault(system, [])
            fallbacks.setdefault(system, [])
        elif current_reader is not None and reader.name != current_reader.name:
            # Пошёл лист другого поставщика без обозначения системы —
            # к предыдущей установке он отношения не имеет.
            current_system = None

        mark = reader.mark(text)
        fallback = reader.fallback_mark(text)

        if current_system:
            for value, storage in ((mark, fans), (fallback, fallbacks)):
                if value and value not in storage[current_system]:
                    storage[current_system].append(value)
        elif mark:
            loose.append(mark)

    by_system = collections.OrderedDict()
    for system in fans:
        by_system[system] = fans[system] or fallbacks.get(system, [])

    return by_system, loose


# ────────────────────────────────────────────────────────────────────
# Сведение трёх источников
# ────────────────────────────────────────────────────────────────────

def _align(primary, secondary):
    """Переставить secondary так, чтобы совпадающие по марке позиции
    встали напротив позиций primary. Нужно, когда у системы несколько
    вентиляторов: пары "марка из ХСОВ — марка из спецификации" должны
    сойтись по смыслу, а не по случайному порядку строк в документе.
    Несовпавшие позиции дописываются в конец в исходном порядке."""
    rest = list(secondary)
    aligned = []
    for value in primary:
        key = normalize_mark(value)
        found = next((item for item in rest if normalize_mark(item) == key), None)
        if found is None:
            aligned.append(None)
        else:
            rest.remove(found)
            aligned.append(found)
    # Оставшиеся позиции занимают пустые места по порядку: если у системы
    # по одному вентилятору в каждом источнике и марки разные, это одна
    # строка с расхождением, а не две строки с "нет данных".
    for index, value in enumerate(aligned):
        if value is None and rest:
            aligned[index] = rest.pop(0)
    aligned.extend(rest)
    return aligned


def _row_status(values):
    present = [v for v in values if v]
    if len(present) >= 2 and len({normalize_mark(v) for v in present}) > 1:
        return STATUS_MISMATCH
    if len(present) < len(values):
        return STATUS_MISSING
    return STATUS_MATCH


def merge_sources(hsov, spec, selection, loose_marks=()):
    """Итоговые строки отчёта.

    hsov — [(система, марка, кол-во систем)], spec — [(система,
    наименование, марка)],
    selection — {система: [марки]}, loose_marks — марки с листов подбора
    без обозначения системы.

    Порядок систем: как в ХСОВ, затем те, что встретились только в
    спецификации, затем только в подборе — объединение всех трёх
    источников, чтобы было видно и "есть в подборе, но нет в ХСОВ".
    """
    order = []
    hsov_by_system = collections.OrderedDict()
    spec_by_system = collections.OrderedDict()
    selection_by_system = collections.OrderedDict()
    titles = {}
    # Система -> строка отчёта, в которую она попадает. Совпадает с
    # обозначением системы, кроме строк ХСОВ с диапазоном ("Вж2.9-
    # Вж2.20"): туда сводятся все системы диапазона.
    aliases = {}

    def remember(system, members=()):
        key = normalize_system(system)
        if not key:
            return key
        if key not in order:
            order.append(key)
            titles[key] = system.strip()
        for member in members:
            aliases.setdefault(member, key)
        return key

    def resolve(system):
        key = normalize_system(system)
        return aliases.get(key, key)

    for entry in hsov:
        system, mark = entry[0], entry[1]
        count = entry[2] if len(entry) > 2 else None
        key = remember(system, members=expand_systems(system, expected=count))
        hsov_by_system.setdefault(key, []).append(mark)

    for system, _name, mark in spec:
        key = resolve(system)
        if key not in order:
            key = remember(system)
        spec_by_system.setdefault(key, []).append(mark)

    for system, marks in selection.items():
        key = resolve(system)
        if key not in order:
            key = remember(system)
        selection_by_system.setdefault(key, []).extend(marks)

    # Диапазон систем ХСОВ ("Вж2.9-Вж2.20") собирает разделы всех своих
    # систем — а там одна и та же марка повторена по разу на систему.
    # В строку отчёта она должна попасть один раз; разные марки внутри
    # диапазона остаются все, это и есть расхождение, которое надо
    # показать.
    for storage in (spec_by_system, selection_by_system):
        for key, marks in storage.items():
            if len(hsov_by_system.get(key, [])) == 1 and len(marks) > 1:
                unique = []
                for mark in marks:
                    if normalize_mark(mark) not in {normalize_mark(m) for m in unique}:
                        unique.append(mark)
                storage[key] = unique

    pool = collections.Counter(normalize_mark(m) for m in loose_marks if m)
    pool_display = {}
    for mark in loose_marks:
        pool_display.setdefault(normalize_mark(mark), mark)

    rows = []
    for key in order:
        base = [m for m in hsov_by_system.get(key, []) if m] or hsov_by_system.get(key, [])
        spec_marks = spec_by_system.get(key, [])
        selection_marks = selection_by_system.get(key, [])

        if base:
            spec_aligned = _align(base, spec_marks)
            selection_aligned = _align(base, selection_marks)
            hsov_aligned = list(base) + [None] * (
                max(len(spec_aligned), len(selection_aligned)) - len(base))
        else:
            hsov_aligned = list(base)
            spec_aligned = list(spec_marks)
            selection_aligned = _align(spec_marks, selection_marks) if spec_marks \
                else list(selection_marks)

        height = max(len(hsov_aligned), len(spec_aligned), len(selection_aligned), 1)

        def at(values, index):
            if index < len(values) and values[index]:
                return values[index]
            return ""

        for index in range(height):
            hsov_value = at(hsov_aligned, index)
            spec_value = at(spec_aligned, index)
            selection_value = at(selection_aligned, index)

            if not selection_value:
                # Лист подбора без обозначения системы (технический лист
                # на вентилятор) — подставляем его той системе, у которой
                # марка совпала, каждый лист не больше одного раза.
                for candidate in (hsov_value, spec_value):
                    candidate_key = normalize_mark(candidate)
                    if candidate_key and pool.get(candidate_key):
                        pool[candidate_key] -= 1
                        selection_value = pool_display[candidate_key]
                        break

            values = (hsov_value, spec_value, selection_value)
            if not any(values):
                # Система есть в ХСОВ, но вентилятора у неё нет ни в
                # одном источнике (в ХСОВ прочерк — например,
                # "оборудование закупается арендатором"). Сверять нечего,
                # и строка только засоряла бы отчёт.
                continue
            rows.append({
                "system": titles[key],
                SOURCE_HSOV: hsov_value,
                SOURCE_SPEC: spec_value,
                SOURCE_SELECTION: selection_value,
                "status": _row_status(values),
            })

    return rows


# ────────────────────────────────────────────────────────────────────
# Разбор альбома целиком
# ────────────────────────────────────────────────────────────────────

def extract_album(pdf_path, progress_callback=None, assistant=None, assist_log=None):
    """Разобрать альбом: (строки ХСОВ, вентиляторы спецификации, подбор
    по системам, марки подбора без системы).

    assistant — клиент Claude API или None. Если он есть, листы, которые
    не разобрал ни один распознаватель, дочитывает модель (см.
    equipment_assist). Без него всё работает как раньше, просто такие
    листы остаются непрочитанными.
    """
    doc = fitz.open(pdf_path)

    hsov = []
    spec = []
    selection_pages = []
    unknown_pages = []
    spec_system = ""

    for index, page in enumerate(doc):
        text = _page_text(page)
        kind = classify_page(page, text=text)
        if kind == KIND_HSOV:
            hsov.extend(read_hsov_page(page))
        elif kind == KIND_SPEC:
            page_fans, spec_system = read_spec_page(page, current_system=spec_system)
            spec.extend(page_fans)
        elif kind == KIND_SELECTION:
            selection_pages.append((index + 1, text))
        else:
            unknown_pages.append((index + 1, text))
        if progress_callback:
            progress_callback(index + 1, doc.page_count)

    selection, loose = read_selection_pages(selection_pages)

    if assistant is not None:
        assisted, assisted_loose = equipment_assist.read_pages(
            unknown_pages, assistant, log=assist_log)
        for system, mark in assisted:
            # Распознанное распознавателем важнее: оно читается из
            # вёрстки точно, а не восстанавливается по тексту.
            marks = selection.setdefault(system, [])
            if mark not in marks:
                marks.append(mark)
        loose = list(loose) + [mark for mark in assisted_loose if mark not in loose]

    return hsov, spec, selection, loose


# ────────────────────────────────────────────────────────────────────
# Запись результата
# ────────────────────────────────────────────────────────────────────

_HEADERS = [
    "Наименование системы",
    "ХСОВ",
    "По спецификации",
    "По листу подбора",
    "Статус",
]

_COLUMN_WIDTHS = [26, 34, 34, 34, 16]

_HEADER_FILL = PatternFill(fill_type="solid", fgColor="D9E1F2")
_MISMATCH_FILL = PatternFill(fill_type="solid", fgColor="FFC7CE")
_MISSING_FILL = PatternFill(fill_type="solid", fgColor="FFEB9C")

_HEADER_FONT = Font(name="Arial", size=10, bold=True)
_DATA_FONT = Font(name="Arial", size=10)
_BORDER = Border(*[Side(style="thin")] * 4)


def write_workbook(rows, output_path):
    wb = Workbook()
    ws = wb.active
    ws.title = "Оборудование"

    ws.append(_HEADERS)
    for cell in ws[1]:
        cell.font = _HEADER_FONT
        cell.fill = _HEADER_FILL
        cell.border = _BORDER
        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
    for index, width in enumerate(_COLUMN_WIDTHS, start=1):
        ws.column_dimensions[ws.cell(row=1, column=index).column_letter].width = width
    ws.row_dimensions[1].height = 30
    ws.freeze_panes = "A2"

    for row in rows:
        values = [
            row["system"],
            row[SOURCE_HSOV],
            row[SOURCE_SPEC],
            row[SOURCE_SELECTION],
            row["status"],
        ]
        ws.append(values)
        fill = None
        if row["status"] == STATUS_MISMATCH:
            fill = _MISMATCH_FILL
        elif row["status"] == STATUS_MISSING:
            fill = _MISSING_FILL
        for cell in ws[ws.max_row]:
            cell.font = _DATA_FONT
            cell.border = _BORDER
            cell.alignment = Alignment(vertical="top", wrap_text=True)
            if fill is not None:
                cell.fill = fill

    wb.save(output_path)
    return output_path


def build(pdf_path, output_path=None, progress_callback=None, assistant=None):
    """Возвращает (путь к сохранённому Excel, число строк таблицы).

    assistant — клиент Claude API или None, см. extract_album."""
    if not output_path:
        base, _ext = os.path.splitext(pdf_path)
        output_path = base + "_oborud.xlsx"

    hsov, spec, selection, loose = extract_album(
        pdf_path, progress_callback=progress_callback, assistant=assistant)
    rows = merge_sources(hsov, spec, selection, loose)
    write_workbook(rows, output_path)
    return output_path, len(rows)


def _assistant():
    """Клиент Claude API, если ключ задан. Нет ключа — работаем без
    модели: это штатный режим, а не ошибка (см. common/claude_client)."""
    from common.claude_client import client_from_environment
    client = client_from_environment()
    if client is None:
        print("ANTHROPIC_API_KEY не задан — незнакомые листы подбора "
              "разбираться не будут", file=sys.stderr)
    return client


def debug_report(pdf_path, rows_per_page=6, assistant=None):
    """Что программа увидела в альбоме — для разбора, когда результат
    выглядит неправильно: какие листы к какому виду отнесены, какие
    столбцы ХСОВ распознаны и что в них прочиталось.

    Печатается в stdout; на сервере это единственный способ понять, где
    именно расходятся ожидание и разбор, не пересылая сам альбом.
    """
    doc = fitz.open(pdf_path)
    print(f"Листов в альбоме: {doc.page_count}")

    kinds = collections.defaultdict(list)
    for index, page in enumerate(doc):
        kind = classify_page(page)
        if kind:
            kinds[kind].append(index + 1)
    for kind, name in ((KIND_HSOV, "ХСОВ"), (KIND_SPEC, "спецификация"),
                       (KIND_SELECTION, "листы подбора")):
        pages = kinds.get(kind, [])
        print(f"{name}: {len(pages)} лист(ов) {pages[:20]}{' ...' if len(pages) > 20 else ''}")

    for page_number in kinds.get(KIND_HSOV, []):
        page = doc[page_number - 1]
        table = pdf_grid.read_table(page)
        print(f"\n── ХСОВ, лист {page_number}: сетка "
              f"{table.n_rows if table else 0} x {table.n_cols if table else 0}")
        if table is None:
            continue
        system_col = table.find_column("обозн")
        mark_col = _fan_mark_column(page, table, system_col) if system_col is not None else None
        count_col = table.find_column("кол. систем", "кол.систем", "кол-во систем")
        print(f"   столбцы: обозначение={system_col}, марка={mark_col}, кол-во={count_col}")
        if system_col is None or mark_col is None:
            continue
        # Шапка каждого столбца — чтобы было видно, какой именно взят.
        for column in range(table.n_cols):
            header = " ".join(table.cell(row, column) for row in range(min(8, table.n_rows))).strip()
            if header:
                mark = " <- марка" if column == mark_col else ""
                print(f"     [{column}] {header[:48]}{mark}")
        for system, mark, count in read_hsov_page(page)[:rows_per_page]:
            print(f"   {system} | {mark} | кол-во систем: {count}")

    # Лист подбора за листом: кто его распознал, какую систему и марку
    # прочитал. По этому видно, почему у системы пусто в отчёте — листа
    # в альбоме нет вовсе или он есть, но не разобран.
    print("\n── Листы подбора")
    for page_number in kinds.get(KIND_SELECTION, []):
        text = _page_text(doc[page_number - 1])
        low = text.lower()
        reader = next((r for r in _SELECTION_READERS if r.matches(low, text)), None)
        continued = ""
        if reader is None:
            reader = next((r for r in _SELECTION_READERS if r.continues(low, text)), None)
            continued = " (продолжение)"
        if reader is None:
            print(f"   лист {page_number}: не распознан")
            continue
        print(f"   лист {page_number}: {reader.name}{continued} | система: "
              f"{reader.system(text) or '-'} | марка: {reader.mark(text) or '-'}"
              f" | установка: {reader.fallback_mark(text) or '-'}")

    if assistant is not None:
        import equipment_ai
        assist_log = []
        hsov, spec, selection, loose = equipment_ai.read_album(
            pdf_path, assistant, log=assist_log)
        print("\n── Что прочитала модель (Claude API)")
        for line in assist_log:
            print(f"   {line}")
    else:
        hsov, spec, selection, loose = extract_album(pdf_path)
    print(f"\nВсего: систем в ХСОВ {len(hsov)}, вентиляторов в спецификации {len(spec)}, "
          f"листов подбора с системой {len(selection)}, без системы {len(loose)}")


def main():
    parser = argparse.ArgumentParser(
        description="Сверка марок вентиляторов по альбому РД (ХСОВ / спецификация / листы подбора)")
    parser.add_argument("pdf", help="путь к PDF-альбому проекта")
    parser.add_argument("-o", "--output", default=None, help="путь для сохранения .xlsx")
    parser.add_argument("--debug", action="store_true",
                        help="не считать сверку, а показать, что программа увидела в альбоме")
    parser.add_argument("--page", type=int, default=None,
                        help="напечатать текст одного листа как его видит программа "
                             "(для разбора незнакомой вёрстки листа подбора)")
    parser.add_argument("--claude", action="store_true",
                        help="читать альбом через Claude API: листы ХСОВ, "
                             "спецификации и подбора уходят в модель (нужен ключ "
                             "в переменной окружения ANTHROPIC_API_KEY)")
    parser.add_argument("--workers", type=int, default=None,
                        help="сколько листов отправлять в Claude API параллельно")
    args = parser.parse_args()

    if args.page:
        doc = fitz.open(args.pdf)
        print(_page_text(doc[args.page - 1]))
        return

    assistant = _assistant() if args.claude else None

    if args.debug:
        debug_report(args.pdf, assistant=assistant)
        return

    if assistant is not None:
        import equipment_ai
        log = []
        output_path, total = equipment_ai.build(
            args.pdf, assistant, output_path=args.output, log=log,
            workers=args.workers or equipment_ai.DEFAULT_WORKERS)
        for line in log:
            print(f"   {line}", file=sys.stderr)
    else:
        output_path, total = build(args.pdf, args.output)
    print(f"Готово: {total} строк -> {output_path}")


if __name__ == "__main__":
    main()
