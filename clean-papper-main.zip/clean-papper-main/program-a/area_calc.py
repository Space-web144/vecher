# -*- coding: utf-8 -*-
"""
Area — самостоятельный инструмент: расчёт площади металла (м²) для
плоского списка позиций (воздуховоды + фасонные изделия), без остальной
"Полной обработки" VentSpec (без раскраски, без сравнения с 1С, без
38-колоночной структуры спецификации).

Использует ровно ту же калиброванную логику расчёта площади, что и
"Полная обработка"/"Только расчёт площади фасонных изделий" — common/area.py
(calculate_fitting_surface, calculate_duct_area) и common/matcher.py
(determine_category) для определения типа строки. Здесь нет НИКАКОЙ
своей математики — только чтение/запись столбцов под другой (более
простой) формат файла.

Формат входного файла: первая строка — заголовки, среди столбцов есть
"Наименование" и "Площадь" (порядок и остальные столбцы не важны,
регистр и лишние пробелы в заголовке — тоже). Строки без имени просто
пропускаются; строки, для которых площадь по формуле не считается
(не воздуховод и не фасонные изделия калиброванного типа), остаются пустыми —
не подставляем 0 там, где на самом деле "не наш профиль", чтобы не
перепутать с "посчитали и вышло 0".
"""

import os

from openpyxl import load_workbook

from common.matcher import determine_category
from common.area import calculate_fitting_surface, calculate_duct_area, is_fitting_row


def _find_column(ws, header_substr, max_col=20):
    """Ищет столбец в первой строке по вхождению подстроки (без учёта
    регистра/лишних пробелов) — формат этого инструмента, в отличие от
    VentSpec, не фиксирован по номерам столбцов."""
    target = header_substr.strip().upper()
    for c in range(1, max_col + 1):
        val = ws.cell(row=1, column=c).value
        if val and target in str(val).strip().upper():
            return c
    return None


def run_area_calc(spec_file, output_file=None, progress_callback=None, log=None):
    """Самостоятельная единица: расчёт площади для плоского списка
    (инструмент Area). Возвращает путь к сохранённому файлу."""
    def _log(msg):
        if log:
            log(msg)

    if not output_file:
        base, _ext = os.path.splitext(spec_file)
        output_file = base + "_area.xlsx"

    wb = load_workbook(spec_file)
    ws = wb.active

    name_col = _find_column(ws, "Наименование")
    area_col = _find_column(ws, "Площадь")
    if name_col is None:
        raise ValueError('Не найден столбец "Наименование" в первой строке файла.')
    if area_col is None:
        raise ValueError('Не найден столбец "Площадь" в первой строке файла.')

    total_rows = max(ws.max_row - 1, 0)
    computed = 0
    skipped = 0
    for row in range(2, ws.max_row + 1):
        name = ws.cell(row=row, column=name_col).value
        if progress_callback:
            progress_callback(row - 1, total_rows)
        if not name or not str(name).strip():
            continue
        name = str(name)
        category = determine_category(name, is_spec_row=True)
        area = 0.0
        if category == 2:
            area = calculate_duct_area(name)
        elif is_fitting_row(category, name):
            area = calculate_fitting_surface(name, log=log)
        if area:
            ws.cell(row=row, column=area_col).value = round(area, 2)
            computed += 1
        else:
            skipped += 1

    wb.save(output_file)
    _log(f"Area: посчитано {computed} из {total_rows} строк "
         f"({skipped} без площади — не воздуховод/фасонные изделия или недостаточно данных).")
    return output_file
