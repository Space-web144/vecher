# -*- coding: utf-8 -*-
"""Постраничный разбор спецификации Claude: геометрия, проверка и один ремонт.

Без сетевого SDK; клиент внедряется снаружи. Секретов и вызовов API на импорте нет.
Кэш относится к PDF, модели, усилию, правилам, примерам и контексту страницы.
"""
import hashlib
import json
import math
import os
import re
import tempfile
from pathlib import Path
from collections import Counter

import fitz

FIELDS = ("POS", "NAME", "TYPE", "CODE", "VENDOR", "UNIT", "QTY", "MASS", "NOTE", "SECTION")
MAX_PAGES = 200
MAX_WORDS = 14000
MAX_IMAGE_SIDE = 2600
MAX_REPAIR = 1
PROMPT_PATH = Path(__file__).parent / "prompts" / "specification.md"
EXAMPLES_DIR = Path(__file__).parent / "spec_examples"


def _obj(properties):
    return {"type": "object", "properties": properties,
            "required": list(properties), "additionalProperties": False}


def _array(item, size=None):
    # Длины проверяет Python: схема использует совместимое подмножество JSON Schema.
    return {"type": "array", "items": item}


SCHEMA = _obj({
    "is_specification": {"type": "boolean"},
    "last_section": {"type": "string"},
    "table_bbox": _array({"type": "number"}, 4),
    "quantity_x": _array({"type": "number"}, 2),
    "warnings": _array({"type": "string"}),
    "rows": _array(_obj(dict(
        [(field, {"type": "string"}) for field in FIELDS]
        + [("bbox", _array({"type": "number"}, 4)),
           ("continuation", {"type": "boolean"})])))})


class SpecAgentError(RuntimeError):
    pass


def _digest(value):
    return hashlib.sha256(json.dumps(value, ensure_ascii=False, sort_keys=True).encode("utf-8")).hexdigest()


def _atomic_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = None
    try:
        with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=str(path.parent),
                                         delete=False) as handle:
            temporary = handle.name
            json.dump(value, handle, ensure_ascii=False)
        os.replace(temporary, str(path))
    finally:
        if temporary and os.path.exists(temporary):
            os.unlink(temporary)


def load_examples(folder=EXAMPLES_DIR):
    """Только явно одобренные человеком примеры, с ограничением контекста."""
    examples = []
    for path in sorted(Path(folder).glob("*.json")):
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            raise SpecAgentError("Некорректный пример: " + path.name)
        if data.get("approved") is not True:
            continue
        if not isinstance(data.get("source_text"), str) or not isinstance(data.get("expected_rows"), list):
            raise SpecAgentError("Некорректный пример: " + path.name)
        if len(json.dumps(data, ensure_ascii=False)) > 12000:
            raise SpecAgentError("Пример слишком большой: " + path.name)
        examples.append({"source_text": data["source_text"], "expected_rows": data["expected_rows"]})
        if len(examples) == 4:
            break
    return examples


def _norm(value):
    return re.sub(r"[\W_]+", "", str(value).lower(), flags=re.UNICODE)


def _number(value):
    value = str(value).replace("\u00a0", "").replace(" ", "").replace(",", ".")
    if not re.fullmatch(r"[+-]?\d+(?:\.\d+)?", value):
        return None
    number = float(value)
    return number if math.isfinite(number) else None


def page_words(page):
    from pdf_layout import service_text_lines
    mat = page.rotation_matrix
    ignored = service_text_lines(page)
    result = []
    for word in page.get_text("words"):
        if (word[5], word[6]) in ignored:
            continue
        box = fitz.Rect(word[:4]) * mat
        result.append({"text": word[4], "box": [
            round(box.x0 / page.rect.width * 1000, 2),
            round(box.y0 / page.rect.height * 1000, 2),
            round(box.x1 / page.rect.width * 1000, 2),
            round(box.y1 / page.rect.height * 1000, 2)]})
    return sorted(result, key=lambda w: (round(w["box"][1] / 3), w["box"][0]))


def _box(value):
    return (isinstance(value, list) and len(value) == 4
            and all(isinstance(v, (int, float)) and not isinstance(v, bool)
                    and math.isfinite(v) and 0 <= v <= 1000 for v in value)
            and value[0] < value[2] and value[1] < value[3])


def _inside(word, box):
    x = (word["box"][0] + word["box"][2]) / 2
    y = (word["box"][1] + word["box"][3]) / 2
    return box[0] - 3 <= x <= box[2] + 3 and box[1] - 3 <= y <= box[3] + 3


def _source_confirms(value, words):
    text = " ".join(w["text"] for w in words)
    if _norm(value) in _norm(text):
        return True
    # Колонки могут вклиниваться между переносами наименования.
    # Проверяем наличие каждого исходного слова с учётом повторов.
    tokens = lambda s: Counter(re.findall(r"\w+", s.casefold(), re.UNICODE))
    return not (tokens(value) - tokens(text))


def validate_page(answer, words, context=None):
    """Не доверяем схеме API/кэшу. Проверяем типы, источники и колонку количеств."""
    if not isinstance(answer, dict) or not isinstance(answer.get("is_specification"), bool):
        raise SpecAgentError("Модель вернула некорректный тип страницы")
    if not isinstance(answer.get("rows"), list) or len(answer["rows"]) > 1000:
        raise SpecAgentError("Некорректный список позиций")
    if not isinstance(answer.get("last_section"), str):
        raise SpecAgentError("Некорректное название раздела")
    if not isinstance(answer.get("warnings"), list) or any(not isinstance(w, str) for w in answer["warnings"]):
        raise SpecAgentError("Некорректные предупреждения")
    issues = list(answer["warnings"])
    context = context or {}
    if not answer["is_specification"]:
        if answer["rows"]:
            raise SpecAgentError("Позиции на странице, объявленной не спецификацией")
        # Решение о пропуске фиксируется; явные признаки таблицы вызывают ремонт.
        text = " ".join(w["text"] for w in words).lower()
        if "спецификац" in text or ("наименован" in text and "кол" in text):
            issues.append("Страница с признаками спецификации пропущена моделью")
        return issues
    if not answer["rows"]:
        issues.append("На странице спецификации не прочитано ни одной позиции")
    if not words:
        issues.append("Нет текстового слоя: чтение по изображению, значения требуют проверки")
    for index, row in enumerate(answer["rows"], 1):
        if not isinstance(row, dict) or any(not isinstance(row.get(f), str) for f in FIELDS):
            raise SpecAgentError("Некорректные поля позиции %s" % index)
        if not isinstance(row.get("continuation"), bool) or not _box(row.get("bbox")):
            raise SpecAgentError("Некорректная область позиции %s" % index)
        local = [w for w in words if _inside(w, row["bbox"])]
        text = _norm(" ".join(w["text"] for w in local))
        for field in ("NAME", "TYPE", "CODE", "VENDOR", "UNIT", "QTY", "MASS", "NOTE"):
            if words and row[field] and not _source_confirms(row[field], local):
                issues.append("Позиция %s: %s не подтверждено текстом в её области" % (index, field))
        if not row["NAME"] and not row["continuation"]:
            issues.append("Позиция %s: пустое наименование" % index)
        for field in ("POS", "SECTION"):
            allowed = [str(context.get("section") or ""),
                       str((context.get("previous_row") or {}).get(field) or "")]
            if words and row[field] and not _source_confirms(row[field], words) and not any(
                    _norm(row[field]) == _norm(value) for value in allowed if value):
                issues.append("Позиция %s: %s не подтверждено источником или предыдущей системой" % (index, field))
    if (words and answer["last_section"]
            and not _source_confirms(answer["last_section"], words)
            and _norm(answer["last_section"]) != _norm(context.get("section") or "")):
        issues.append("last_section не подтверждено источником или предыдущей системой")
    # Проверяем каждое число в независимо прочитанной полосе количества.
    # Границы полосы всё ещё предложены моделью: это контроль, не доказательство полноты.
    table = answer.get("table_bbox")
    band = answer.get("quantity_x")
    if not _box(table) or not isinstance(band, list) or len(band) != 2 or not all(
            isinstance(v, (int, float)) and math.isfinite(v) for v in band) or not 0 <= band[0] < band[1] <= 1000:
        issues.append("Не определены область таблицы или колонка количества")
    elif words:
        qty_box = [band[0], table[1], band[1], table[3]]
        candidates = [w for w in words if _inside(w, qty_box)]
        lines = []
        for word in sorted(candidates, key=lambda w: (w["box"][1], w["box"][0])):
            y = (word["box"][1] + word["box"][3]) / 2
            if lines and abs(lines[-1][0] - y) <= 3:
                lines[-1][1].append(word)
            else:
                lines.append([y, [word]])
        linked_rows = set()
        for _y, line in lines:
            number = _number("".join(w["text"] for w in sorted(line, key=lambda w: w["box"][0])))
            if number is None:
                continue
            matching = [i for i, r in enumerate(answer["rows"])
                        if all(_inside(w, r["bbox"]) for w in line) and _number(r["QTY"]) == number]
            if len(matching) != 1:
                issues.append("Количество %s на y≈%s не связано ровно с одной позицией" % (number, round(_y)))
            else:
                linked_rows.add(matching[0])
        for i, row in enumerate(answer["rows"]):
            if _number(row["QTY"]) is not None and i not in linked_rows:
                issues.append("Позиция %s: количество не найдено в указанной колонке" % (i + 1))
    return list(dict.fromkeys(issues))


def _merge(rows, answer, page_number, issues):
    for item in answer["rows"]:
        row = {field: item[field] for field in FIELDS}
        source = {"page": page_number, "bbox": item["bbox"]}
        if item["continuation"] and rows and rows[-1]["_SOURCES"][-1]["page"] == page_number - 1:
            previous = rows[-1]
            for field in FIELDS:
                if row[field] and row[field] != previous[field]:
                    if field in ("QTY", "UNIT", "POS", "SECTION") and previous[field]:
                        issues.append("Продолжение: конфликт %s; исходное значение сохранено, фрагмент — в протоколе" % field)
                    else:
                        previous[field] = (previous[field] + " " + row[field]).strip()
            previous["_SOURCES"].append(source)
            previous["_FRAGMENTS"].append(row)
            continue
        if item["continuation"]:
            issues.append("Продолжение не связано с предыдущей страницей; сохранено отдельно")
        row["_PAGE"] = page_number - 1
        row["_SOURCES"] = [source]
        row["_FRAGMENTS"] = []
        rows.append(row)


def read_page(page, client, number, context=None, checkpoint=None, fingerprint="",
              progress=None, total_pages=1, rules=None, examples=None):
    """Прочитать одну сложную страницу; результат проверяется до кэширования."""
    rules = rules if rules is not None else PROMPT_PATH.read_text(encoding="utf-8")
    examples = examples if examples is not None else load_examples()
    context = context or {"section": "", "previous_row": None}
    words = page_words(page)
    if len(words) > MAX_WORDS:
        raise SpecAgentError("Слишком много текста на странице %s; разделите лист" % number)
    checkpoint = Path(checkpoint) if checkpoint else None
    key = _digest({"fingerprint": fingerprint, "page": number, "context": context,
                   "model": client.model, "effort": getattr(client, "effort", ""),
                   "rules": rules, "examples": examples, "schema": SCHEMA})
    answer = None
    if checkpoint and checkpoint.is_file():
        try:
            saved = json.loads(checkpoint.read_text(encoding="utf-8"))
            if saved.get("key") == key:
                validate_page(saved["answer"], words, context)
                answer = saved["answer"]
        except (ValueError, KeyError, SpecAgentError):
            pass
    if answer is None:
        scale = min(2.0, MAX_IMAGE_SIDE / max(page.rect.width, page.rect.height))
        image = page.get_pixmap(matrix=fitz.Matrix(scale, scale), alpha=False).tobytes("png")
        request = json.dumps({"page": number, "context": context, "words": words,
                              "approved_examples": examples}, ensure_ascii=False)
        answer = client.extract_json(rules, request, SCHEMA, image_png=image)
        issues = validate_page(answer, words, context)
        for _attempt in range(MAX_REPAIR):
            if not issues or not words:
                break
            if progress:
                progress(number, total_pages, "Проверка и повторное чтение страницы %s" % number)
            try:
                repaired = client.extract_json(rules, request + "\nРасхождения:\n" + json.dumps(
                    issues, ensure_ascii=False), SCHEMA, image_png=image)
                repaired_issues = validate_page(repaired, words, context)
            except (RuntimeError, ValueError):
                # Уже прочитанную страницу не теряем из-за сбоя ремонта.
                break
            # Не принимаем «исправление», удалившее строки или всю таблицу.
            if ((repaired["is_specification"] or not answer["is_specification"])
                    and len(repaired["rows"]) >= len(answer["rows"])
                    and len(repaired_issues) < len(issues)):
                answer, issues = repaired, repaired_issues
        cacheable = answer["is_specification"] and bool(answer["rows"]) and (
            not issues or (not words and len(issues) == 1 and "Нет текстового слоя" in issues[0]))
        if checkpoint and cacheable:
            _atomic_json(checkpoint, {"key": key, "answer": answer})
    issues = validate_page(answer, words, context)
    return answer, issues


def read_specification(pdf_path, client, cache_dir=None, progress=None, examples_dir=EXAMPLES_DIR):
    rules = PROMPT_PATH.read_text(encoding="utf-8")
    examples = load_examples(examples_dir)
    fingerprint = _digest({"pdf": hashlib.sha256(Path(pdf_path).read_bytes()).hexdigest(),
                           "model": client.model, "effort": getattr(client, "effort", ""),
                           "rules": rules, "examples": examples, "schema": SCHEMA})
    rows, pages = [], []
    section = ""
    with fitz.open(pdf_path) as doc:
        if doc.needs_pass:
            raise SpecAgentError("PDF защищён паролем")
        if not 0 < len(doc) <= MAX_PAGES:
            raise SpecAgentError("Допускается от 1 до %s страниц; разделите большой альбом" % MAX_PAGES)
        for index, page in enumerate(doc):
            number = index + 1
            if progress:
                progress(number, len(doc), "Чтение страницы %s из %s" % (number, len(doc)))
            context = {"section": section, "previous_row": rows[-1] if rows else None}
            if context["previous_row"]:
                context["previous_row"] = {f: rows[-1][f] for f in FIELDS}
            checkpoint = Path(cache_dir) / ("%04d.json" % number) if cache_dir else None
            answer, issues = read_page(page, client, number, context, checkpoint, fingerprint,
                                       progress, len(doc), rules, examples)
            _merge(rows, answer, number, issues)
            pages.append({"page": number, "is_specification": answer["is_specification"],
                          "issues": issues, "rows": len(answer["rows"])})
            if answer["is_specification"]:
                section = answer["last_section"] or section
    if not rows:
        raise SpecAgentError("Позиции спецификации не найдены. Проверьте PDF или состав альбома")
    return {"rows": rows, "pages": pages, "engine": "claude", "model": client.model,
            "examples": len(examples), "warnings": []}
