# -*- coding: utf-8 -*-
"""
Сопоставление листов между редакциями.

Основной способ — по штампу (марка + номер листа, см. stamp.py): он
не зависит от порядка страниц в файле, поэтому вставленный лист не
сдвигает весь комплект.

Но в комплекте всегда есть листы БЕЗ штампа: приложения («Рисунок 7»),
схемы, таблицы событий, листы нестандартного формата. На присланном
комплекте ПС их 34 из 147 — почти четверть. Сопоставить их по штампу
нечем, и раньше они просто исчезали из отчёта, что инженер прочитал бы
как «изменений нет».

Здесь они сопоставляются по содержанию: одинаковый размер листа и
похожий текст. Замер на реальной паре редакций: 14 из 18 таких листов
совпали со схожестью 1.00, а все несовпавшие дали 0.78 и ниже — граница
чёткая, поэтому порог строгий.

Неоднозначный остаток можно отдать модели (match_with_model) — она
видит только короткие выжимки текста, а решение проверяет код: пары
обязаны быть взаимно однозначными и не ниже минимальной схожести.
"""
import difflib
import json
import re

# Сколько первых слов листа берём как его «подпись» для сравнения.
# Больше — медленнее и без пользы: шапка и первые надписи уже опознают
# лист однозначно.
_SIGNATURE_WORDS = 120

# Порог уверенного совпадения. Взят по замеру: настоящие совпадения дали
# 1.00, ближайшее ложное — 0.78.
CONTENT_MATCH_THRESHOLD = 0.85

# Ниже этого не принимаем даже решение модели: если тексты настолько
# разные, это разные листы, что бы модель ни ответила.
MODEL_MATCH_FLOOR = 0.30

# Допуск на размер листа: страницы одного листа в разных редакциях
# совпадают точно, расхождение означает другой формат.
_SIZE_TOL_PT = 2.0

_TITLE_STOP = re.compile(r"^[\d.,;:()\-+±°№]+$")


def page_signature(words):
    return " ".join(words[:_SIGNATURE_WORDS])


def page_title(words, limit=8):
    """Короткая подпись листа для отчёта и для промпта — первые
    осмысленные слова, без голых чисел и обозначений."""
    picked = [w for w in words[:40] if not _TITLE_STOP.match(w)][:limit]
    return " ".join(picked).strip()


def _comparable(a, b):
    return (abs(a["width"] - b["width"]) <= _SIZE_TOL_PT
            and abs(a["height"] - b["height"]) <= _SIZE_TOL_PT)


def similarity(a, b, floor=0.0):
    """Схожесть двух листов по их подписям.

    quick_ratio — оценка сверху по набору символов, без учёта порядка:
    два совершенно разных русских текста дают по ней 0.6. Поэтому она
    годится только как быстрый отсев, а решение принимается по настоящей
    ratio. Замер на реальной паре редакций: у совпадающих листов ratio
    равна 1.00, у всех остальных — не выше 0.07, середины нет."""
    if not _comparable(a, b):
        return 0.0
    matcher = difflib.SequenceMatcher(None, a["signature"], b["signature"])
    if matcher.quick_ratio() < floor:
        return 0.0
    return matcher.ratio()


def match_by_content(old_pages, new_pages, threshold=CONTENT_MATCH_THRESHOLD):
    """Жадное взаимно однозначное сопоставление по убыванию схожести.

    Возвращает (pairs, unmatched_old, unmatched_new), где pairs —
    список (old_page, new_page, score)."""
    scored = []
    for old in old_pages:
        for new in new_pages:
            score = similarity(old, new, floor=threshold)
            if score >= threshold:
                scored.append((score, old, new))
    scored.sort(key=lambda item: -item[0])

    pairs = []
    used_old, used_new = set(), set()
    for score, old, new in scored:
        if old["page"] in used_old or new["page"] in used_new:
            continue
        used_old.add(old["page"])
        used_new.add(new["page"])
        pairs.append((old, new, score))

    unmatched_old = [p for p in old_pages if p["page"] not in used_old]
    unmatched_new = [p for p in new_pages if p["page"] not in used_new]
    return pairs, unmatched_old, unmatched_new


def _prompt_pages(pages):
    return [{"страница": p["page"], "формат": f"{p['width']:.0f}x{p['height']:.0f}",
             "начало листа": p.get("title") or page_title(p.get("words") or [], limit=14)}
            for p in pages]


_JSON_FENCE_RE = re.compile(r"^\s*```(?:json)?\s*|\s*```\s*$", re.IGNORECASE)


def _parse_pairs(text):
    payload = _JSON_FENCE_RE.sub("", (text or "").strip())
    start, end = payload.find("["), payload.rfind("]")
    if start == -1 or end == -1 or end < start:
        return []
    try:
        data = json.loads(payload[start:end + 1])
    except ValueError:
        return []
    out = []
    if isinstance(data, list):
        for item in data:
            if not isinstance(item, dict):
                continue
            old, new = item.get("старая"), item.get("новая")
            if isinstance(old, int) and isinstance(new, int):
                out.append((old, new))
    return out


def match_with_model(client, old_pages, new_pages, ask, log=print):
    """Сопоставляет остаток листов без штампа с помощью модели.

    ask — функция (prompt, facts_obj, max_tokens) -> текст; сюда её
    передаёт narrative.py, чтобы этот модуль не знал ни про клиента, ни
    про формат запросов.

    Модель видит только номера страниц, формат и первые слова листа.
    Её ответ проверяется кодом: пара должна быть взаимно однозначной,
    страницы — существовать, а тексты листов не могут быть совсем
    непохожими (MODEL_MATCH_FLOOR). Всё, что не прошло проверку,
    отбрасывается."""
    if not old_pages or not new_pages:
        return []

    prompt = (
        "Ниже листы одного комплекта рабочей документации, у которых нет "
        "штампа, поэтому сопоставить их по обозначению нельзя. Слева листы "
        "старой редакции, справа — новой. Определи, какой лист старой "
        "редакции соответствует какому листу новой.\n"
        "Соответствие — это один и тот же лист комплекта, изменившийся между "
        "редакциями. Если для листа пары нет, не придумывай её: лучше "
        "пропустить, чем связать разные листы.\n"
        "Ответь массивом JSON без пояснений: "
        "[{\"старая\": номер страницы, \"новая\": номер страницы}, …]"
    )
    facts = {"старая редакция": _prompt_pages(old_pages),
             "новая редакция": _prompt_pages(new_pages)}
    text = ask(prompt, facts, 4000)

    by_old = {p["page"]: p for p in old_pages}
    by_new = {p["page"]: p for p in new_pages}
    used_old, used_new = set(), set()
    pairs = []
    for old_no, new_no in _parse_pairs(text):
        old, new = by_old.get(old_no), by_new.get(new_no)
        if old is None or new is None:
            log(f"[листы] модель назвала несуществующую пару {old_no}→{new_no}, отброшена")
            continue
        if old_no in used_old or new_no in used_new:
            log(f"[листы] модель повторно использовала страницу в паре {old_no}→{new_no}, отброшена")
            continue
        score = similarity(old, new, floor=MODEL_MATCH_FLOOR)
        if score < MODEL_MATCH_FLOOR:
            log(f"[листы] пара {old_no}→{new_no} отброшена: тексты листов непохожи "
                f"(схожесть {score:.2f})")
            continue
        used_old.add(old_no)
        used_new.add(new_no)
        pairs.append((old, new, score))
    return pairs
