# -*- coding: utf-8 -*-
"""
Разбор углового штампа (основной надписи по ГОСТ 21.101) листа РД —
даёт устойчивый ключ листа (марка + номер листа), не зависящий от того,
на каком месте лист лежит в PDF (при перевыпуске изменения листы часто
переставляются/добавляются/убираются — сравнивать по номеру страницы
нельзя, см. историю переписки по этому инструменту).

Работает по словам (page.get_text("words")) в правом нижнем углу листа,
где ГОСТ-овский штамп всегда расположен, и опирается на взаимное
расположение подписей "Стадия"/"Лист"/"Листов" — сам штамп типовой и
одинаковый для всех листов одного комплекта, так что эта привязка не
подгонка под один конкретный файл.
"""
import re

import fitz

# Разбор текста страницы — самая дорогая операция всего сравнения, и почти
# всё её время уходит на распаковку встроенных картинок, на которые
# сравнение даже не смотрит. Замер на реальном комплекте: 30 страниц
# разбираются 17.0 с со стандартными флагами и 0.37 с без картинок, при
# том же составе текстовых блоков (432 против 432 на проверенной
# странице). Флаги общие для всего разбора: и для слов штампа, и для строк
# геометрии.
TEXT_FLAGS = fitz.TEXTFLAGS_TEXT & ~fitz.TEXT_PRESERVE_IMAGES

# Штамп всегда в правом нижнем углу листа — с запасом, чтобы не зависеть
# от точного формата (А1/А3/…), но не залезать в основное поле чертежа.
_REGION_X_FRAC = 0.55
_REGION_Y_FRAC = 0.70

# Обозначение комплекта ("марка") в разных организациях пишется
# по-разному: "143/23-ГК-РД-1-ПС" у одного заказчика, "01-ИЖ-МСК-ПИР-
# 2.3-2.4-Р-ВК0.1" у другого. Привязываться к конкретному префиксу
# нельзя — опознаём по структуре: группы из букв и цифр, разделённые
# дефисом/точкой/слэшем, обязательно хотя бы один дефис (он отличает
# обозначение от слогана вида "Архитектура.Изыскания.Проектирование" и
# от слипшихся подписей на чертеже вроде "22.1ЗКПС24.8"), и обязательно
# есть и буква, и цифра.
_MARKA_RE = re.compile(
    r"^[0-9A-Za-zА-Яа-яЁё]+(?:[-./][0-9A-Za-zА-Яа-яЁё]+){2,}$", re.UNICODE)
# Кавычки, скобки и точку в конце срезаем: марка нередко встречается в
# тексте листа как ссылка ("...см. 143/23-ГК-РД-0-ПС.") и попадает в
# токен вместе с соседним знаком препинания.
_MARKA_TRIM = " .,;:()«»\"'"
_MARKA_MIN_LEN = 8
_MARKA_MAX_LEN = 60
# Полоса вокруг опорной строки штампа, в которой ищем марку. Поле
# "Обозначение" стоит вплотную к строке "Стадия/Лист/Листов" (на обоих
# калибровочных комплектах — ровно 65 pt выше), а у формы 2а лежит на
# одной высоте с надписью "Лист". Полоса с запасом в обе стороны.
_MARKA_BAND_PT = 150.0
# Сцепка соседних слов в одно обозначение: сколько слов подряд пробуем
# склеить и какой зазор между ними ещё считаем частью одного токена.
_MARKA_MAX_PIECES = 8
_MARKA_JOIN_GAP_PT = 6.0

# Суффикс части комплекта в марке: ".СО" (спецификация оборудования),
# ".КЖ", ".Р1" — буквенный (с необязательной цифрой) хвост после точки.
# Точки внутри самого обозначения ("...-2.3-2.4-Р-ВК0.1") под него не
# подходят, поэтому срезаем именно суффикс, а не всё после первой точки.
_PART_SUFFIX_RE = re.compile(r"\.[А-ЯЁA-Z]{1,3}\d?$", re.UNICODE)

# Номер листа не всегда целое число — встречаются подлисты вида "1.1"
# (несколько чертежей с одной общей маркой и общим "Листов", но разбитые
# на подпункты нумерации листа).
_SHEET_NO_RE = re.compile(r"^\d+(\.\d+)?$")

# Дата в штампе ("01.25", "10.04") формально подходит под шаблон номера
# листа — отсекаем её отдельно, номеров листа вида "01.25" не бывает.
_DATE_LIKE_RE = re.compile(r"^\d{2}\.\d{2}$")

# Полоса под заголовком, где стоит его значение, и допуск на смещение
# значения относительно колонки заголовка (калибровано на двух реальных
# комплектах: верное число стоит в ~5 pt от своей колонки, посторонние —
# в сотнях pt).
_VALUE_DY_MIN = 8.0
_VALUE_DY_MAX = 40.0
_MAX_VALUE_OFFSET = 20.0

# Соседние подписи, по которым отличаем нужную пару "Лист"/"Листов" от
# омонимичного заголовка "Лист" в таблице изменений (Изм./Кол.уч./Лист/
# №док./Подпись/Дата) — та лежит в отдельной строке штампа, без "Стадия"
# и "Листов" рядом.
_ROW_ANCHOR_WORDS = {"Стадия", "Листов"}


def _row_key(y, tol=3.0):
    return round(y / tol)


def _group_rows(words):
    rows = {}
    for w in words:
        x0, y0, x1, y1, text = w[0], w[1], w[2], w[3], w[4]
        rows.setdefault(_row_key(y0), []).append((x0, y0, x1, y1, text))
    for key in rows:
        rows[key].sort(key=lambda w: w[0])
    return rows


def _marka_candidates(rows):
    """Все токены зоны штампа, похожие на обозначение комплекта —
    списком (x0, y, текст), без выбора лучшего.

    Обозначение в PDF нередко разбито на несколько соседних слов, причём
    дефис между ними бывает отдельным словом ("01-ИЖ-МСК-ПИР-2.3-2.4-Р" +
    "-" + "ВК0.2"), а зазоры между ними чуть больше обычного склеивания.
    Поэтому проверяем не только отдельные слова, но и их сцепки — беря
    для каждого начала самую длинную, которая ещё похожа на марку.

    Сцепка идёт по словам, стоящим вплотную по горизонтали и
    перекрывающимся по высоте, а не по строкам из _group_rows. У PyMuPDF
    1.24 (стоит на хостинге) рамка куска слова бывает выше на высоту
    другого шрифта: «89/21-ГК-2-РД-1.5-» и «ВК» на ВК 89_21 расходились по
    верху на 5 pt, попадали в разные строки, и марка не читалась вовсе —
    вместо неё бралась ссылка на смежный комплект («см.89/21-…-ПЧ2-ВК1»),
    а листы сопоставлялись не с теми."""
    words = sorted((w for row in rows.values() for w in row), key=lambda w: w[0])
    out = []
    for i, first in enumerate(words):
        best = None
        text = first[4]
        prev = first
        for _step in range(_MARKA_MAX_PIECES - 1):
            cand = text.strip(_MARKA_TRIM)
            if _is_marka(cand):
                best = (first[0], first[1], cand)
            nxt = _next_piece(words, i, prev, first)
            if nxt is None:
                break
            text += nxt[4]
            prev = nxt
        else:
            cand = text.strip(_MARKA_TRIM)
            if _is_marka(cand):
                best = (first[0], first[1], cand)
        if best is not None:
            out.append(best)
    return out


def _next_piece(words, start, prev, first):
    """Ближайшее справа слово, продолжающее сцепку: вплотную к prev и
    на одной высоте с first. words отсортированы по x0."""
    best = None
    for word in words[start + 1:]:
        if word[0] > prev[2] + _MARKA_JOIN_GAP_PT:
            break
        # Начало слова может заходить на хвост предыдущего (рамки слов в
        # PDF неточные), но не левее его начала.
        if word is prev or word[0] <= prev[0]:
            continue
        if not _same_line(word, first):
            continue
        if best is None or word[0] < best[0]:
            best = word
    return best


def _same_line(a, b):
    """Перекрываются ли слова по высоте хотя бы на половину меньшего."""
    overlap = min(a[3], b[3]) - max(a[1], b[1])
    return overlap >= 0.5 * min(a[3] - a[1], b[3] - b[1])


# Самая длинная буквенная часть обозначения. В марках это коды вроде
# «ГК», «ПИР», «ВК»; длинное слово — значит, сцепились слова надписи
# («инфраструктуры.Этап2-Многофункциональный» из названия объекта).
_MARKA_MAX_WORD = 10
_LONG_WORD_RE = re.compile(r"[A-Za-zА-Яа-яЁё]{%d,}" % (_MARKA_MAX_WORD + 1))


def _is_marka(cand):
    if not (_MARKA_MIN_LEN <= len(cand) <= _MARKA_MAX_LEN):
        return False
    if _LONG_WORD_RE.search(cand):
        return False
    if "-" not in cand:
        return False
    if not _MARKA_RE.match(cand):
        return False
    return any(ch.isdigit() for ch in cand) and any(ch.isalpha() for ch in cand)


def _find_marka(rows, anchor_y=None):
    """Марка листа. Похожие на обозначение токены встречаются и в поле
    чертежа (ссылки на смежные комплекты — "далее см. 143/23-ГК-РД-0-ПС"),
    поэтому из кандидатов берём самый ПРАВЫЙ в полосе вокруг опорной
    строки штампа: поле "Обозначение" прижато к правому краю листа, а
    ссылки в тексте — левее. Без опорной строки (штамп не опознан)
    ограничиваемся тем же правилом по всей зоне — на таких листах марка
    всё равно перепроверяется голосованием по всему комплекту, см.
    pick_document_marka."""
    cands = _marka_candidates(rows)
    if not cands:
        return None
    if anchor_y is not None:
        banded = [c for c in cands if abs(c[1] - anchor_y) <= _MARKA_BAND_PT]
        if banded:
            cands = banded
    return max(cands, key=lambda c: c[0])[2]


def _find_header_row(rows):
    """Строка "Разработал … Стадия Лист Листов" — полный штамп по ГОСТ
    21.101 (формы 1 и 2, первый лист марки и основные листы)."""
    for row in rows.values():
        words = {text for *_, text in row}
        if _ROW_ANCHOR_WORDS <= words and "Лист" in words:
            return row
    return None


def _find_lone_sheet_label(rows):
    """Форма 2а — упрощённый штамп листов-продолжения: полей "Стадия" и
    "Листов" там нет вовсе, есть только надпись "Лист" у правого края и
    номер под ней. Именно из-за этой формы на реальном комплекте штамп
    читался лишь у трети листов.

    Омонимичный заголовок "Лист" внутри таблицы изменений (Изм./Кол.уч./
    Лист/№док./Подпись/Дата) отсеиваем по соседям в той же строке."""
    best = None
    for row in rows.values():
        words = {text for *_, text in row}
        if "Лист" not in words:
            continue
        if words & {"Изм.", "№док.", "Кол.уч.", "Подпись", "Листов", "Стадия"}:
            continue
        for x0, y0, x1, y1, text in row:
            if text == "Лист" and (best is None or x0 > best[0]):
                best = (x0, y0)
    return best


def _value_under(rows, target_x, header_y):
    """Значение под заголовком штампа — число, ближайшее по горизонтали
    к его колонке.

    Перебираем ВСЕ строки в полосе под заголовком, а не только ближайшую
    сверху вниз: под штампом попадаются дата ("01.25") и номер корпуса из
    названия объекта ("Корпус 2.3"), которые формально проходят под
    шаблон номера листа. Раньше такая строка забирала выбор на себя, в
    ней не находилось числа рядом с колонкой — и номер листа терялся,
    хотя строкой ниже он был, в 5 pt от своей колонки.

    "Листов" (общее число листов марки) на продолжающих листах часто не
    печатается — ограничение по расстоянию не даёт приписать сюда число
    из чужой колонки."""
    best = best_dist = best_dy = None
    for row in rows.values():
        dy = row[0][1] - header_y
        if not (_VALUE_DY_MIN <= dy <= _VALUE_DY_MAX):
            continue
        for x0, y0, x1, y1, text in row:
            value = text.strip()
            if not _SHEET_NO_RE.match(value) or _DATE_LIKE_RE.match(value):
                continue
            dist = abs(x0 - target_x)
            if dist > _MAX_VALUE_OFFSET:
                continue
            if best_dist is None or dist < best_dist or (dist == best_dist and dy < best_dy):
                best, best_dist, best_dy = value, dist, dy
    return best


def _find_sheet_numbers(rows, header_row=None, sheet_label=None):
    if header_row is not None:
        header_by_text = {}
        for x0, y0, x1, y1, text in header_row:
            if text in ("Лист", "Листов"):
                header_by_text.setdefault(text, (x0, y0))
        if "Лист" in header_by_text:
            sheet_no = _value_under(rows, *header_by_text["Лист"])
            total_sheets = None
            if "Листов" in header_by_text:
                total_sheets = _value_under(rows, *header_by_text["Листов"])
            return sheet_no, total_sheets
        return None, None

    if sheet_label is not None:
        return _value_under(rows, *sheet_label), None
    return None, None


def _single_sheet_fallback(sheet_no, total_sheets):
    """По ГОСТ 21.101 у документа из одного листа поле "Лист" оставляют
    пустым, а "Листов" заполняют единицей (так оформлены, например,
    отдельные расчёты внутри комплекта). Для сопоставления ревизий такой
    лист — первый и единственный."""
    if sheet_no is None and total_sheets == "1":
        return "1"
    return sheet_no


def _find_change_log(rows):
    """Штатная таблица изменений в штампе (Изм./Кол.уч./Лист/№док./
    Подпись/Дата) — берём все заполненные строки сверху вниз по мере
    накопления изменений (штамп заполняется снизу вверх относительно
    заголовка, самая новая строка ближе всего к заголовку).

    В этой же горизонтальной полосе часто лежит перенос названия объекта
    (соседний блок штампа) — ограничиваемся x-диапазоном самих заголовков
    таблицы, чтобы не подхватить посторонний текст сбоку."""
    header_row = None
    for row in rows.values():
        words = {text for *_, text in row}
        if {"Изм.", "Кол.уч.", "№док."} <= words:
            header_row = row
            break
    if header_row is None:
        return []

    header_y = header_row[0][1]
    table_x_min = min(x0 for x0, *_r in header_row) - 10
    table_x_max = max(x1 for _x0, _y0, x1, *_r in header_row) + 15

    entries = []
    for key, row in rows.items():
        dy = row[0][1] - header_y
        if -40 <= dy < -1:
            texts = [text for x0, y0, x1, y1, text in row if table_x_min <= x0 <= table_x_max]
            if texts:
                entries.append((row[0][1], " ".join(texts)))
    entries.sort(key=lambda e: e[0])
    return [text for _, text in entries]


# ── Зоны штампа, исключаемые из сравнения чертежей ──
#
# Заполнение штампа — это не изменение чертежа: новая строка в таблице
# изменений, подпись и дата попадают в находки на КАЖДОМ изменённом листе
# и отбирают карточки у настоящих правок. Штатная запись об изменении и
# так показана в отчёте отдельной колонкой «Штамп заявляет изменение».
#
# Зоны привязаны к реально найденным строкам штампа, а не к зоне поиска
# (_REGION_*_FRAC): та вчетверо больше самого штампа и на листе А1
# захватила бы правую нижнюю четверть чертежа вместе с настоящими
# изменениями. Не нашли строк — не исключаем ничего: пропустить шум
# безопаснее, чем спрятать правку.
_CHANGE_TABLE_UP_PT = 45.0
_CHANGE_TABLE_DOWN_PT = 15.0
_ZONE_PAD_PT = 4.0


def _row_bounds(row):
    return (min(w[0] for w in row), min(w[1] for w in row),
            max(w[2] for w in row), max(w[3] for w in row))


def _change_table_zone(rows):
    """Таблица изменений штампа (Изм./Кол.уч./Лист/№док./Подпись/Дата)
    вместе со строками над заголовком, куда её и заполняют."""
    for row in rows.values():
        words = {text for *_, text in row}
        if {"Изм.", "Кол.уч.", "№док."} <= words:
            x0, y0, x1, y1 = _row_bounds(row)
            return (x0 - _ZONE_PAD_PT, y0 - _CHANGE_TABLE_UP_PT,
                    x1 + _ZONE_PAD_PT, y1 + _CHANGE_TABLE_DOWN_PT)
    return None


def _main_block_zone(page_rect, header_row, sheet_label):
    """Основной блок штампа — от опорной строки до правого нижнего угла
    листа. Штамп по ГОСТ всегда прижат к углу, поэтому правая и нижняя
    границы известны точно, а левая и верхняя берутся от найденной
    строки."""
    if header_row is not None:
        x0, y0, _x1, _y1 = _row_bounds(header_row)
    elif sheet_label is not None:
        x0, y0 = sheet_label
    else:
        return None
    return (x0 - _ZONE_PAD_PT, y0 - _ZONE_PAD_PT, page_rect.x1, page_rect.y1)


def _stamp_zones(page_rect, rows, header_row, sheet_label):
    zones = []
    for zone in (_change_table_zone(rows), _main_block_zone(page_rect, header_row, sheet_label)):
        if zone is not None:
            zones.append(zone)
    return zones


def in_zones(bbox, zones):
    """Попадает ли элемент в одну из зон штампа — по центру: подпись на
    границе зоны должна решаться однозначно, а не наполовину."""
    if not zones:
        return False
    cx = (bbox[0] + bbox[2]) / 2.0
    cy = (bbox[1] + bbox[3]) / 2.0
    for x0, y0, x1, y1 in zones:
        if x0 <= cx <= x1 and y0 <= cy <= y1:
            return True
    return False


def stamp_zones(page):
    """Зоны штампа листа в координатах page.rect — см. _stamp_zones."""
    return extract_stamp(page)["zones"]


def _page_words(page):
    """Слова листа в тех же координатах, в которых задан page.rect.

    У повёрнутых листов (в комплекте встречаются /Rotate 270 — лист
    формата А1, физически лежащий боком) get_text отдаёт координаты в
    НЕповёрнутой системе: штамп оказывается не в правом нижнем углу, а
    за пределами page.rect, и зона поиска его не захватывает. Приводим
    координаты к повёрнутой системе, тогда геометрия штампа одинакова
    для всех листов."""
    words = page.get_text("words", flags=TEXT_FLAGS)
    if not page.rotation:
        return words
    matrix = page.rotation_matrix
    out = []
    for word in words:
        rect = (fitz.Rect(word[0], word[1], word[2], word[3]) * matrix).normalize()
        out.append((rect.x0, rect.y0, rect.x1, rect.y1) + tuple(word[4:]))
    return out


def page_words(page):
    """Слова листа в координатах page.rect — публичная обёртка над
    _page_words: тем же представлением пользуется сопоставление листов
    без штампа (sheet_match.py), и разбирать страницу дважды незачем."""
    return _page_words(page)


def extract_stamp(page, words=None):
    """Возвращает dict: marka, sheet_no, total_sheets, change_log (список
    строк таблицы изменений штампа, снизу вверх — новейшая последней).

    words — уже разобранные слова листа. Разбор текста страницы это самая
    дорогая операция всего сравнения, и вызывающий код, которому слова
    нужны и для другого, не должен платить за них дважды."""
    w, h = page.rect.width, page.rect.height
    if words is None:
        words = _page_words(page)
    region = [wd for wd in words if wd[1] > h * _REGION_Y_FRAC and wd[0] > w * _REGION_X_FRAC]
    rows = _group_rows(region)

    header_row = _find_header_row(rows)
    sheet_label = _find_lone_sheet_label(rows) if header_row is None else None
    if header_row is not None:
        anchor_y = header_row[0][1]
    elif sheet_label is not None:
        anchor_y = sheet_label[1]
    else:
        anchor_y = None

    marka = _find_marka(rows, anchor_y)
    sheet_no, total_sheets = _find_sheet_numbers(rows, header_row, sheet_label)
    sheet_no = _single_sheet_fallback(sheet_no, total_sheets)
    change_log = _find_change_log(rows)

    zones = _stamp_zones(page.rect, rows, header_row, sheet_label)
    title = sheet_title(region, zones)
    return {
        "marka": marka,
        "sheet_no": sheet_no,
        "total_sheets": total_sheets,
        "change_log": change_log,
        "zones": zones,
        # Наименование чертежа («Схема …», «План …») — лист с чертежом,
        # даже если в примечаниях над штампом сказано «общие указания см.
        # лист общих данных»: по этой фразе схемы ВК принимались за
        # текстовые листы и выпадали из графического сравнения.
        "text_sheet": None if title else _text_sheet_title(region, zones),
        "title": title,
    }


# Наименования листов, на которых нет чертежа: таблицы и текст. Их
# правки — это сдвинувшиеся строки и переписанные абзацы, и в графическом
# отчёте они только заслоняют изменения трассировки и оборудования
# (отзыв заказчика: «не понятно что это, но это тоже не нужно»).
# Содержание спецификации сверяет книга Excel.
_TEXT_SHEET_RE = re.compile(
    r"общие\s+данные|общие\s+указания|ведомость\s+(рабочих|ссылочных|документов|"
    r"чертежей|основных|прилагаемых)|спецификация\s+(оборудования|изделий|материалов)|"
    r"пояснительная\s+записка|титульный\s+лист|содержание\s+тома",
    re.IGNORECASE)


def _text_sheet_title(region, zones):
    """Наименование листа из штампа, если это лист без чертежа (общие
    данные, ведомость, спецификация), иначе None.

    Ищется в самом штампе: в остальной полосе у нижнего края
    бывают примечания к чертежу («см. спецификацию»), и по ним план
    приняли бы за таблицу. Штамп не найден — тогда по всей полосе:
    у листов с нераспознанной маркой штамп всё равно стоит на месте."""
    words = [wd for wd in region if not zones or in_zones(wd[:4], zones)]
    found = _TEXT_SHEET_RE.search(" ".join(wd[4] for wd in words))
    return found.group(0) if found else None


# Начало наименования листа в основной надписи.
_TITLE_START_RE = re.compile(
    r"^(?:План|Планы|Схема|Схемы|Узел|Узлы|Разрез|Разрезы|Фрагмент|Фрагменты|"
    r"Аксонометрическая|Аксонометрические|Принципиальная|Принципиальные|Деталь|Детали|"
    r"Расположение|Размещение|Монтажная|Монтажные|Трассировка|Установка|Фасад|Сечение|"
    r"Сечения|Вид|Виды)\b")
# Наименование кончается там, где начинается следующая графа штампа.
_TITLE_END_RE = re.compile(r"\s(?:Стадия|Лист|Листов|Формат|Изм\.|ООО|АО)\b")


def sheet_title(region, zones):
    """Наименование листа из основной надписи («План 2-го этажа с
    системами …»), или "".

    В графе наименования те же блоки текста, что и фамилии подписантов:
    они стоят в левом столбце штампа, а наименование — правее. Поэтому
    берутся строки, начатые не левее первой строки наименования и идущие
    под ней без разрыва, и только левее графы «Стадия» (правее —
    повёрнутый логотип организации)."""
    if not zones:
        return ""
    words = [wd for wd in region if in_zones(wd[:4], zones)]
    lines = {}
    for wd in words:
        key = (wd[5], wd[6]) if len(wd) > 6 else (round(wd[1]), 0)
        lines.setdefault(key, []).append(wd)
    rows = sorted((sorted(line, key=lambda wd: wd[0]) for line in lines.values()),
                  key=lambda line: (min(wd[1] for wd in line), line[0][0]))
    start = next((line for line in rows
                  if _TITLE_START_RE.match(" ".join(wd[4] for wd in line))), None)
    if start is None:
        return ""
    x0 = start[0][0]
    top, bottom = min(wd[1] for wd in start), max(wd[3] for wd in start)
    height = max(bottom - top, 1.0)
    right = min([wd[0] for wd in words if wd[4] in ("Стадия", "Лист", "Листов")
                 and wd[0] > x0 + height] or [float("inf")])
    parts = [" ".join(wd[4] for wd in start if wd[0] < right)]
    for line in rows:
        y0 = min(wd[1] for wd in line)
        if line is start or y0 <= top + 0.5:
            continue
        if y0 - bottom > height * 0.9:
            break
        kept = [wd[4] for wd in line if x0 - height <= wd[0] < right]
        if kept and line[0][0] >= x0 - height:
            parts.append(" ".join(kept))
            bottom = max(bottom, max(wd[3] for wd in line))
    title = " ".join(" ".join(parts).split())
    title = _TITLE_END_RE.split(title)[0]
    return title.strip(" ,.;")[:150]


def sheet_key(stamp):
    """Ключ листа для сопоставления между ревизиями — None, если штамп не
    распознан (страница без штампа, например обложка без марки, тогда
    сопоставлять её не пытаемся)."""
    if not stamp.get("marka") or not stamp.get("sheet_no"):
        return None
    return (stamp["marka"], stamp["sheet_no"])


def pick_document_marka(stamps):
    """Марка всего комплекта — самая частая среди распознанных на листах.

    На отдельном листе в поле штампа может попасть ссылка на смежный
    комплект, а на листах-продолжениях марка несёт суффикс части
    (".СО" — спецификация оборудования, ".КЖ" и т.п.). Комплект при этом
    один, поэтому голосование по всем листам устойчивее любого разбора
    одной страницы. Суффикс части при подсчёте отбрасываем, но возвращаем
    марку в том виде, как она напечатана.
    """
    counts = {}
    for stamp in stamps:
        marka = (stamp or {}).get("marka")
        if not marka:
            continue
        base = _PART_SUFFIX_RE.sub("", marka)
        counts[base] = counts.get(base, 0) + 1
    if not counts:
        return None
    return max(sorted(counts), key=counts.get)
