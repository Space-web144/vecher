# -*- coding: utf-8 -*-
"""Иллюстрации к зонам — как в эталонном отчёте заказчика.

- Обзор листа: новая редакция приглушена, исчезнувшее — красным,
  появившееся — зелёным; рамки и номера зон рисуются поверх (в отчёте —
  векторно, цветом категории; для модели — прямо в картинке).
- Фрагмент зоны: слева прежняя редакция на розовом фоне, справа новая на
  зелёном; изменившиеся штрихи перекрашены в пурпурный, остальное как на
  листе.

Всё на numpy и PyMuPDF: opencv, которым это рисует rdgraph, на хостинге
нет.
"""
import fitz
import numpy as np

import rdiff

# Разрешение картинок отчёта. Обзор листа рисуется заново, а не из растра
# сравнения (100 dpi): на А1 тот после ужатия до 2200 px давал ~66 dpi, и
# марки на обзоре не читались. Теперь — до 150 dpi, но не больше
# OVERVIEW_MAX_SIDE по длинной стороне (А1 — ~120 dpi, А0 — ~85 dpi).
OVERVIEW_DPI = 150
OVERVIEW_MAX_SIDE = 4000
# Фрагменты зон — 200 dpi; крупная зона рисуется с меньшим разрешением,
# а не ужимается потом прореживанием (от него «лесенка» на линиях).
FRAGMENT_DPI = 200
FRAGMENT_MAX_SIDE = 2000
MODEL_MAX_SIDE = 1568
JPEG_QUALITY = 85

_REMOVED = (225, 40, 40)
_ADDED = (30, 160, 30)
_TINT_OLD = (255, 226, 226)
_TINT_NEW = (226, 244, 226)
_CHANGED = (200, 0, 200)
_BACKGROUND = 235


def jpeg(arr, quality=JPEG_QUALITY):
    arr = np.ascontiguousarray(arr)
    pix = fitz.Pixmap(fitz.csRGB, arr.shape[1], arr.shape[0], arr.tobytes(), False)
    try:
        return pix.tobytes("jpg", jpg_quality=quality)
    except (TypeError, ValueError):  # старая сборка PyMuPDF без jpg_quality
        return pix.tobytes("png")


def page_dpi(page, dpi=OVERVIEW_DPI, max_side=OVERVIEW_MAX_SIDE):
    """Разрешение, с которым лист целиком укладывается в max_side пикселей."""
    longest = max(page.rect.width, page.rect.height) / 72.0
    return min(dpi, max_side / max(longest, 1e-6))


def _resample(mask, shape):
    """Маска, приведённая к размеру shape (ближайший пиксель). Перед
    уменьшением маска расширяется, чтобы тонкий штрих не пропал."""
    h, w = shape
    sh, sw = mask.shape
    if (h, w) == (sh, sw):
        return mask
    grow = int(max(sh / max(h, 1), sw / max(w, 1)) // 2)
    if grow > 0:
        mask = rdiff.dilate(mask, grow)
    ys = np.minimum((np.arange(h) * sh / float(h)).astype(int), sh - 1)
    xs = np.minimum((np.arange(w) * sw / float(w)).astype(int), sw - 1)
    return mask[ys][:, xs]


def overview(new_page, diff):
    """Обзор листа новой редакции с подсвеченными изменениями.
    Возвращает (JPEG, ширина, высота, масштаб от пикселей диффа).
    Здесь и ниже страница может быть и её DisplayList (rdiff.render)."""
    dpi = page_dpi(new_page)
    scale = dpi / float(rdiff.DPI)
    img = rdiff.render(new_page, dpi=dpi)
    gray = rdiff._gray(img).astype(np.uint16)
    del img
    faded = (gray * 45 // 100 + 140).astype(np.uint8)
    out = np.repeat(faded[:, :, None], 3, axis=2)
    dx, dy = diff["shifts"][0][0], diff["shifts"][0][1]
    rem = rdiff.shifted(diff["rem_a"], dx, dy, diff["size"])
    # Подсвечиваются только изменения внутри зон: россыпь мелких отметок
    # по всему листу (ниже порога значимости) только мешает читать.
    inside = np.zeros(diff["size"], dtype=bool)
    for zone in diff["zones"]:
        x0, y0, x1, y1 = zone["box"]
        inside[y0:y1, x0:x1] = True
    shape = out.shape[:2]
    out[_resample(rdiff.dilate(rem & inside, 1), shape)] = _REMOVED
    out[_resample(rdiff.dilate(diff["add_b"] & inside, 1), shape)] = _ADDED
    return jpeg(out), out.shape[1], out.shape[0], scale


def _crop_box(zone, size):
    """Рамка фрагмента в пикселях диффа: зона с полями, не меньше
    минимального размера (как detail у rdgraph)."""
    pad = rdiff._px(15.0)
    min_w, min_h = rdiff._px(88.0), rdiff._px(60.0)
    x0, y0, x1, y1 = zone["box"]
    cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
    w = max(x1 - x0 + 2 * pad, min_w)
    h = max(y1 - y0 + 2 * pad, min_h)
    H, W = size
    return (int(max(0, cx - w / 2)), int(max(0, cy - h / 2)),
            int(min(W, cx + w / 2)), int(min(H, cy + h / 2)))


def _paint(img, mask, tint):
    """Фон фрагмента — оттенком редакции, изменившиеся штрихи — пурпурным."""
    gray = rdiff._gray(img)
    out = img.copy()
    out[gray >= _BACKGROUND] = tint
    if mask is not None and mask.any():
        out[mask & (gray < rdiff.INK_GRAY)] = _CHANGED
    return out


def _fit(arr, max_side):
    """Картинка, уменьшенная до max_side по длинной стороне — с
    усреднением (fitz), а не прореживанием: у прореженной тонкие линии
    рвутся, а мелкий текст не читается."""
    h, w = arr.shape[:2]
    scale = min(1.0, max_side / float(max(h, w)))
    if scale >= 1.0:
        return arr
    arr = np.ascontiguousarray(arr)
    pix = fitz.Pixmap(fitz.csRGB, w, h, arr.tobytes(), False)
    small = fitz.Pixmap(pix, max(1, int(w * scale)), max(1, int(h * scale)), None)
    out = np.frombuffer(small.samples, dtype=np.uint8).reshape(small.height, small.stride)
    return out[:, :small.width * 3].reshape(small.height, small.width, 3).copy()


def fragments(old_page, new_page, diff, zone):
    """Фрагменты зоны: (JPEG «было», JPEG «стало», ширина, высота)."""
    k = 72.0 / rdiff.DPI
    bx0, by0, bx1, by1 = _crop_box(zone, diff["size"])
    sx, sy = zone.get("shift") or diff["shifts"][0][:2]
    clip_new = fitz.Rect(bx0 * k, by0 * k, bx1 * k, by1 * k) & new_page.rect
    clip_old = fitz.Rect((bx0 - sx) * k, (by0 - sy) * k, (bx1 - sx) * k, (by1 - sy) * k)
    dpi = min(FRAGMENT_DPI, FRAGMENT_MAX_SIDE * 72.0 / max(clip_new.width, clip_new.height, 1.0))
    new_img = rdiff.render(new_page, dpi=dpi, clip=clip_new)
    old_img = _render_padded(old_page, clip_old, new_img.shape[:2], dpi)

    add = diff["add_b"][by0:by1, bx0:bx1]
    ah, aw = diff["rem_a"].shape
    oy0, ox0 = by0 - sy, bx0 - sx
    rem = np.zeros((by1 - by0, bx1 - bx0), dtype=bool)
    ys0, xs0 = max(0, oy0), max(0, ox0)
    ys1, xs1 = min(ah, oy0 + rem.shape[0]), min(aw, ox0 + rem.shape[1])
    if ys1 > ys0 and xs1 > xs0:
        rem[ys0 - oy0:ys1 - oy0, xs0 - ox0:xs1 - ox0] = diff["rem_a"][ys0:ys1, xs0:xs1]
    new_mask = _resample(rdiff.dilate(add, 1), new_img.shape[:2]) if add.size else None
    old_mask = _resample(rdiff.dilate(rem, 1), old_img.shape[:2]) if rem.size else None
    old_out = _paint(old_img, old_mask, _TINT_OLD)
    new_out = _paint(new_img, new_mask, _TINT_NEW)
    return jpeg(old_out), jpeg(new_out), new_out.shape[1], new_out.shape[0]


def _render_padded(page, clip, shape, dpi=FRAGMENT_DPI):
    """Вырезка старой редакции того же размера, что и новая: то, что
    выходит за лист, — белое поле."""
    h, w = shape
    out = np.full((h, w, 3), 255, dtype=np.uint8)
    inside = clip & page.rect
    if inside.is_empty or inside.width < 1 or inside.height < 1:
        return out
    part = rdiff.render(page, dpi=dpi, clip=inside)
    k = dpi / 72.0
    oy = int(round((inside.y0 - clip.y0) * k))
    ox = int(round((inside.x0 - clip.x0) * k))
    ph = min(part.shape[0], h - oy)
    pw = min(part.shape[1], w - ox)
    if ph > 0 and pw > 0:
        out[oy:oy + ph, ox:ox + pw] = part[:ph, :pw]
    return out


def side_by_side(old_jpeg, new_jpeg, max_side=MODEL_MAX_SIDE):
    """Склейка «было | стало» одной картинкой — для модели."""
    a, b = _decode(old_jpeg), _decode(new_jpeg)
    h = max(a.shape[0], b.shape[0])
    gap = np.full((h, 12, 3), 60, dtype=np.uint8)

    def pad(img):
        if img.shape[0] == h:
            return img
        return np.vstack([img, np.full((h - img.shape[0], img.shape[1], 3), 255, np.uint8)])
    return jpeg(_fit(np.hstack([pad(a), gap, pad(b)]), max_side), quality=80)


def _decode(data):
    pix = fitz.Pixmap(data)
    if pix.n != 3 or pix.alpha:
        pix = fitz.Pixmap(fitz.csRGB, pix)
    arr = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.stride)
    return arr[:, :pix.width * 3].reshape(pix.height, pix.width, 3)


def numbered_overview(overview_jpeg, width, height, zones, scale, colors=None,
                      labels=None, max_side=MODEL_MAX_SIDE):
    """Обзор с рамками и номерами зон, нарисованными в самой картинке.
    colors — {номер зоны: (r, g, b) 0–1}, по умолчанию оранжевый; labels —
    {номер зоны: номер в отчёте} (после того как модель отбросила
    несущественные зоны, оставшиеся нумеруются подряд)."""
    doc = fitz.open()
    page = doc.new_page(width=width, height=height)
    page.insert_image(page.rect, stream=overview_jpeg)
    for zone in zones:
        color = (colors or {}).get(zone["n"], (0.95, 0.45, 0.0))
        x0, y0, x1, y1 = (v * scale for v in zone["box"])
        page.draw_rect(fitz.Rect(x0 - 4, y0 - 4, x1 + 4, y1 + 4), color=color, width=3)
        label = str((labels or {}).get(zone["n"], zone["n"]))
        bw = 10 + 9 * len(label)
        tag = fitz.Rect(x0 - 4, max(0, y0 - 26), x0 - 4 + bw, max(22, y0 - 4))
        page.draw_rect(tag, color=color, fill=color)
        page.insert_text((tag.x0 + 4, tag.y1 - 5), label, fontsize=16, color=(1, 1, 1))
    zoom = min(1.0, max_side / float(max(width, height)))
    pix = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom), alpha=False)
    data = pix.tobytes("jpg", jpg_quality=80)
    doc.close()
    return data
