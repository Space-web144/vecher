# -*- coding: utf-8 -*-
"""
Сравнение спецификации (таблица оборудования/материалов) между
ревизиями — переиспользует уже откалиброванный конвертер PDF→Excel
(program-a/pdf_to_spec.py) вместо собственного разбора таблицы:
результат надёжнее любого визуального сравнения, раз данные уже есть
структурированными строками.

Листы спецификации находим по штампу (marka с суффиксом ".СО"/".CO" —
"спецификация оборудования") — так же, как страницы чертежей, но здесь
не сравниваем их по отдельности между собой геометрически: собираем
единый непрерывный блок страниц и прогоняем через конвертер целиком,
как и для обычной загрузки в VentSpec, чтобы не сломать перенос
незакрытой позиции на следующую страницу (см. convert()/carry).
"""
import collections
import os
import re
import sys

import fitz
from openpyxl import load_workbook

from stamp import extract_stamp

_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_PROGRAM_A = os.path.join(_REPO_ROOT, "program-a")
for _path in (_REPO_ROOT, _PROGRAM_A):
    if _path not in sys.path:
        sys.path.insert(0, _path)

from pdf_to_spec import convert  # noqa: E402
from verify_so import (filters_note, gate_note, gate_verdict,  # noqa: E402
                       verify_spec)
from common.parameters import normalize  # noqa: E402


def _is_spec_marka(marka):
    if not marka:
        return False
    return marka.upper().endswith(".CO") or marka.upper().endswith(".СО")


def _spec_page_range(doc):
    """Непрерывный диапазон страниц спецификации (по штампу) — None, если
    в документе спецификации нет вовсе."""
    indices = []
    for i in range(len(doc)):
        stamp = extract_stamp(doc[i])
        if _is_spec_marka(stamp.get("marka")):
            indices.append(i)
    if not indices:
        return None
    return min(indices), max(indices)


# Единица измерения в строке позиции. Границы \b не годятся: "м" внутри
# русского слова ловится ими как отдельное слово только с оговорками,
# поэтому смотрим на соседние буквы явно.
_UNIT_RE = re.compile(
    r"(?<![А-Яа-яA-Za-z])(шт|компл|кг|м2|м\.п|пог\.?\s?м|м|л|т)\.?(?![А-Яа-яA-Za-z])",
    re.UNICODE)
_DIGIT_RE = re.compile(r"\d")

# Ниже какой доли разобранных позиций считаем, что таблица прочитана не
# полностью. Замер по имеющимся комплектам: ОВ2 изм.1 — 99%, ОВ2 изм.2 —
# 99%, "Белая дача" ОВ2.3 — 93%, ПС исходная — 100%, ВК Ижорка — 88% (и
# там 492 позиции, ровно как в эталонном отчёте заказчика, то есть разбор
# верен, а грубый счётчик завышает). Провальный случай — ПС изм.1 с 59%.
# Порог 0.8 эти случаи разделяет с запасом в обе стороны.
_COVERAGE_FLOOR = 0.8
# На короткой спецификации доля скачет от одной строки, поэтому нужен ещё
# и абсолютный разрыв.
_COVERAGE_MIN_GAP = 10


def count_visible_positions(doc, page_range):
    """Грубая оценка числа позиций на листах спецификации: строки, где есть
    и единица измерения, и цифра.

    Считает по словам с координатами, мимо конвертера и его шаблонов —
    именно поэтому и годится как независимая проверка. Оценка заведомо
    неточная (заголовки разделов и многострочные наименования могут
    попасть), но систематически завышает, а не занижает, так что
    пригодна как нижняя граница ожидаемого.
    """
    lo, hi = page_range
    total = 0
    for index in range(lo, hi + 1):
        lines = collections.defaultdict(list)
        for word in doc[index].get_text("words"):
            lines[round((word[1] + word[3]) / 2 / 3)].append(word)
        for words in lines.values():
            line = " ".join(w[4] for w in sorted(words, key=lambda w: w[0]))
            if _UNIT_RE.search(line) and _DIGIT_RE.search(line):
                total += 1
    return total


def extract_spec_rows(pdf_path, tmp_dir, notes_out=None, verdicts_out=None):
    """Возвращает список строк спецификации ({"pos","name","type","unit",
    "qty","system"}) — пусто, если в файле нет листов спецификации.

    "system" (колонка "Наименование системы" конвертера) нужна отчёту в
    Excel: по ней позиции группируются, и по ней же отличается "позиции
    в редакции нет" от "раздел в этой редакции не выпускался".

    verdicts_out — если передан список, в него добавляется вердикт
    приёмочного гейта по этому файлу. Он нужен агенту: без вердикта резюме
    пишется про альбом так, будто разбор сведён, и фраза «количество
    выросло на 27» читается как факт, даже когда числа на листах с отчётом
    не сошлись.

    notes_out — если передан список, в него добавляется предупреждение,
    когда разобрана заметно не вся таблица. Молчаливый недочёт здесь
    опаснее любой ошибки: непрочитанные позиции выглядят в отчёте как
    исключённые из спецификации, и отличить одно от другого по готовому
    файлу нельзя. Так и случилось на ПС изм.1 — 27 позиций из 46, и 32
    позиции были помечены как исключённые, хотя их просто не прочитали.
    """
    doc = fitz.open(pdf_path)
    page_range = _spec_page_range(doc)
    if page_range is None:
        return []
    lo, hi = page_range

    sub = fitz.open()
    sub.insert_pdf(doc, from_page=lo, to_page=hi)
    base = os.path.splitext(os.path.basename(pdf_path))[0]
    sub_pdf_path = os.path.join(tmp_dir, base + "_spec_subset.pdf")
    sub.save(sub_pdf_path)

    out_xlsx = os.path.join(tmp_dir, base + "_spec_subset.xlsx")
    convert(sub_pdf_path, out_xlsx)

    visible = count_visible_positions(doc, page_range)
    wb = load_workbook(out_xlsx)
    ws = wb.active
    rows = []
    for r in range(2, ws.max_row + 1):
        name = ws.cell(row=r, column=2).value
        if not name or not str(name).strip():
            continue
        rows.append({
            "pos": ws.cell(row=r, column=1).value or "",
            "name": str(name),
            "type": ws.cell(row=r, column=3).value or "",
            "unit": ws.cell(row=r, column=6).value or "",
            "qty": ws.cell(row=r, column=7).value,
            "system": ws.cell(row=r, column=11).value or "",
        })

    # Приёмочный гейт (verify_so): независимый контур по словам страницы.
    # Он строго сильнее грубой оценки покрытия — сверяет не долю, а каждое
    # число и его порядок, — поэтому оценка покрытия остаётся только на
    # случай, когда гейт пройден: два предупреждения об одном и том же
    # инженеру ничего не добавляют.
    note = None
    try:
        protocol = verify_spec(sub_pdf_path)
        # В предупреждении — имя альбома, а не внутренней выжимки листов
        # спецификации: инженер ищет файл у себя, а не у нас в tmp.
        protocol["file"] = os.path.basename(pdf_path)
        note = gate_note(protocol)
        if verdicts_out is not None:
            verdicts_out.append(gate_verdict(protocol))
        # Допущения пишутся всегда, не только при расхождении: сработавший
        # фильтр служебных строк — это решение, принятое за инженера, и
        # знать о нём он должен независимо от вердикта.
        assumptions = filters_note(protocol)
        if assumptions and notes_out is not None:
            notes_out.append(assumptions)
    except Exception as exc:                      # noqa: BLE001
        # Сбой самой проверки не должен ронять сравнение: отчёт
        # детерминирован и без неё, но молчать об этом нельзя.
        note = (f"Внимание: проверку спецификации «{os.path.basename(pdf_path)}» "
                f"выполнить не удалось ({exc}) — сверьте количества по исходному PDF.")
    if note is None:
        note = coverage_note(os.path.basename(pdf_path), visible, len(rows))
    if note and notes_out is not None:
        notes_out.append(note)
    return rows


def coverage_note(file_name, visible, parsed):
    """Текст предупреждения о неполном разборе таблицы — или None."""
    if not visible or parsed >= visible - _COVERAGE_MIN_GAP:
        return None
    if parsed >= visible * _COVERAGE_FLOOR:
        return None
    return (f"Внимание: в файле «{file_name}» на листах спецификации видно около "
            f"{visible} позиций, а разобрано {parsed}. Непрочитанные позиции выглядят "
            "в таблице как исключённые из спецификации — проверьте их по исходному PDF, "
            "прежде чем пользоваться отчётом.")


def _row_key(row):
    # "Поз." — если это не пустая позиция и не голое число (для типового
    # оборудования это обычно устойчивый буквенно-числовой код по схеме,
    # например "ДВ2.1.1", который однозначно определяет позицию лучше
    # наименования — а вот для повторяющихся общих материалов Поз. либо
    # пусто, либо простой порядковый номер строки, ненадёжный между
    # ревизиями, поэтому такие в ключ не включаем).
    pos = str(row.get("pos") or "").strip()
    pos_part = pos if pos and not pos.isdigit() else ""
    return pos_part + "|" + normalize(row["name"]) + "|" + normalize(row["type"])


def _qty_equal(a, b):
    try:
        return abs(float(a) - float(b)) < 1e-6
    except (TypeError, ValueError):
        return a == b


def diff_spec_rows(old_rows, new_rows):
    """Построчное сравнение спецификации по ключу (наименование+тип) —
    номер позиции ("Поз.") нестабилен между ревизиями (перенумеровывается
    при добавлении/удалении строк), поэтому не участвует в ключе.

    Для ключей с ровно одной строкой в каждой версии — прямое сравнение
    (типичный случай: единичная позиция оборудования), в "изменено"
    попадает пара с разным количеством. Но многие материалы (утеплитель,
    огнезащитное покрытие воздуховодов) повторяются в спецификации
    десятками строк с ОДНИМ и тем же наименованием и пустым "Тип" — без
    привязки к конкретному участку воздуховода нет способа понять, какая
    именно старая строка соответствует какой новой. Для таких групп
    (больше одной строки хоть с одной стороны) честнее сравнить как
    мультимножество количеств: то же количество есть в обеих версиях —
    не считаем изменением; лишнее в одной версии — добавлено/удалено.
    Так вместо кучи случайных ложных "5.1 → 1.4" (реально просто разные
    строки, не связанная пара) — только реальный дисбаланс количеств."""
    old_by_key = {}
    for row in old_rows:
        old_by_key.setdefault(_row_key(row), []).append(row)
    new_by_key = {}
    for row in new_rows:
        new_by_key.setdefault(_row_key(row), []).append(row)

    added, removed, qty_changed = [], [], []
    all_keys = set(old_by_key) | set(new_by_key)
    for key in all_keys:
        old_group = old_by_key.get(key, [])
        new_group = new_by_key.get(key, [])

        if len(old_group) <= 1 and len(new_group) <= 1:
            if not old_group:
                added.extend(new_group)
            elif not new_group:
                removed.extend(old_group)
            elif not _qty_equal(old_group[0]["qty"], new_group[0]["qty"]):
                qty_changed.append((old_group[0], new_group[0]))
            continue

        remaining_new = list(new_group)
        for old_row in old_group:
            match_i = None
            for i, new_row in enumerate(remaining_new):
                if _qty_equal(old_row["qty"], new_row["qty"]):
                    match_i = i
                    break
            if match_i is not None:
                remaining_new.pop(match_i)
            else:
                removed.append(old_row)
        added.extend(remaining_new)

    return {"added": added, "removed": removed, "qty_changed": qty_changed}
