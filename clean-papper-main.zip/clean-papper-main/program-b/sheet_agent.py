# -*- coding: utf-8 -*-
"""Разбор изменённых листов моделью — по образцу эталонного отчёта
заказчика и агента rdgraph («алгоритмы сравнения»).

Зоны изменений находит код (rdiff.py). Модель получает по каждому
изменённому листу обзор с пронумерованными зонами и фрагменты зон
«было | стало» и возвращает по каждой зоне систему, категорию и
описание изменения — то, что без зрения не написать: «Коллектор 700×450
→ 700×500 / 550×500 L3950, добавлены 4 клапана КПВ». Зоны, которые
модель признала несущественными, в отчёт не идут.

Затем по каждому изменению комплекта модель пишет «Ключевые изменения»
и «Сверку с разрешениями» — уже по готовым разборам листов, текстом.

Запросы к листам идут параллельно: по одному они занимали большую часть
40 минут прогона на сайте.
"""
import base64
import json
import threading
from concurrent.futures import ThreadPoolExecutor

from common.anthropic_client import AnthropicError, extract_text

import system_prompts

# Модель выбрал заказчик: быстрее и дешевле Fable 5.1, а описать фрагмент
# чертежа по картинке ей по силам.
SHEET_MODEL = "claude-opus-5-5"
SHEET_EFFORT = "medium"
SUMMARY_EFFORT = "medium"
# Предохранитель, а не длина ответа: в max_tokens входят и токены
# размышления.
SHEET_MAX_TOKENS = 16000
SUMMARY_MAX_TOKENS = 16000
PARALLEL_REQUESTS = 4
# Сколько зон листа показывать фрагментами (остальные модель видит на
# обзоре и по надписям): каждая картинка — ~1.5 тыс. токенов.
MAX_ZONE_IMAGES = 10
MAX_WORDS_SHOWN = 20

CATEGORIES = ["Трасса", "Оборудование", "Трасса + оборудование",
              "Огнезащита/изоляция", "Замечание", "Несущественно"]
INSIGNIFICANT = "Несущественно"

SHEET_SCHEMA = {
    "type": "object",
    "properties": {
        "zones": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "n": {"type": "integer"},
                    "system": {"type": "string"},
                    "category": {"type": "string", "enum": CATEGORIES},
                    "description": {"type": "string"},
                },
                "required": ["n", "system", "category", "description"],
                "additionalProperties": False,
            },
        },
        "sheet_summary": {"type": "string"},
        "remarks": {"type": "array", "items": {"type": "string"}},
    },
    "required": ["zones", "sheet_summary", "remarks"],
    "additionalProperties": False,
}

_ITEM = {
    "type": "object",
    "properties": {"lead": {"type": "string"}, "text": {"type": "string"}},
    "required": ["lead", "text"],
    "additionalProperties": False,
}
SUMMARY_SCHEMA = {
    "type": "object",
    "properties": {
        "key_changes": {"type": "array", "items": _ITEM},
        "permit_check": {"type": "array", "items": _ITEM},
    },
    "required": ["key_changes", "permit_check"],
    "additionalProperties": False,
}


def requests_needed(sheet_count, pair_count):
    """Сколько запросов к модели нужно на прогон — для предохранителя
    клиента (с запасом на сопоставление листов и спецификацию)."""
    return sheet_count + pair_count + 16 * max(1, pair_count) + 8


def _image(path):
    with open(path, "rb") as handle:
        data = base64.b64encode(handle.read()).decode("ascii")
    return {"type": "image", "source": {"type": "base64", "media_type": "image/jpeg",
                                        "data": data}}


def _system(section, kind):
    # Системный промт одинаков у всех листов прогона — кэшируется.
    return [{"type": "text", "text": system_prompts.build_prompt(section, kind),
             "cache_control": {"type": "ephemeral"}}]


def _words(words):
    shown = ", ".join("«%s»" % w for w in words[:MAX_WORDS_SHOWN])
    return shown + (" …" if len(words) > MAX_WORDS_SHOWN else "")


def sheet_content(sheet):
    """Сообщение модели по одному листу: факты, обзор, фрагменты зон."""
    intro = [
        "Изменение: %s." % sheet["pair"],
        "Лист: %s%s%s." % (sheet["label"], " (%s)" % sheet["how"] if sheet.get("how") else "",
                           (" — " + sheet["title"]) if sheet.get("title") else ""),
        "Разрешение по этому листу: %s." % (sheet.get("permit_note") or "записи нет"),
        "Зон изменений найдено: %d. Первая картинка — обзор листа новой редакции с "
        "пронумерованными зонами." % len(sheet["zones"]),
    ]
    blocks = [{"type": "text", "text": "\n".join(intro)}, _image(sheet["model_overview"])]
    shown = set()
    by_size = sorted(sheet["zones"], key=lambda z: -(z["rem"] + z["add"]))
    for zone in by_size[:MAX_ZONE_IMAGES]:
        if zone.get("model_img"):
            shown.add(zone["n"])
    for zone in sheet["zones"]:
        line = "Зона %d: исчезло %d px штрихов, появилось %d px." % (
            zone["n"], zone["rem"], zone["add"])
        if zone.get("w_minus"):
            line += " Исчезли надписи: %s." % _words(zone["w_minus"])
        if zone.get("w_plus"):
            line += " Появились надписи: %s." % _words(zone["w_plus"])
        if zone["n"] in shown:
            line += " Фрагмент «было | стало» ниже."
            blocks.append({"type": "text", "text": line})
            blocks.append(_image(zone["model_img"]))
        else:
            line += " Фрагмента нет — смотри зону на обзоре."
            blocks.append({"type": "text", "text": line})
    blocks.append({"type": "text", "text":
                   "Разбери каждую зону: n, system, category, description; "
                   "затем sheet_summary и remarks."})
    return blocks


def review_sheet(client, sheet, section, log=None):
    """Разбор одного листа: словарь по SHEET_SCHEMA или None при сбое."""
    try:
        response = client.messages(
            [{"role": "user", "content": sheet_content(sheet)}],
            system=_system(section, "sheet"), model=SHEET_MODEL,
            max_tokens=SHEET_MAX_TOKENS, effort=SHEET_EFFORT, output_schema=SHEET_SCHEMA)
        data = json.loads(extract_text(response))
    except (AnthropicError, ValueError, OSError) as exc:
        if log:
            log("[%s] разбор листа моделью не удался: %s" % (sheet["label"], exc))
        return None
    known = {z["n"] for z in sheet["zones"]}
    data["zones"] = [z for z in data.get("zones") or [] if z.get("n") in known]
    return data


class Reviewer(object):
    """Разбор изменённых листов моделью по мере их готовности.

    Листы приходят частями из дочерних процессов сравнения (submit), и
    модель разбирает их в потоках, пока следующие части ещё считаются:
    время модели прячется за временем сравнения. finish() дожидается всех
    ответов и вписывает их в листы — уже в основном потоке.

    log должен быть безопасен для потоков (см. compare._locked)."""

    def __init__(self, client, section, log=print, parallel=PARALLEL_REQUESTS):
        self.client = client
        self.section = section
        self.log = log
        self._pool = ThreadPoolExecutor(max_workers=max(1, parallel))
        self._jobs = []
        self._lock = threading.Lock()
        self._done = 0

    def submit(self, sheet):
        if not sheet["zones"] or sheet.get("reworked"):
            return
        future = self._pool.submit(review_sheet, self.client, sheet, self.section, self.log)
        self._jobs.append((sheet, future))
        future.add_done_callback(lambda _f, label=sheet["label"]: self._progress(label))

    def _progress(self, label):
        with self._lock:
            self._done += 1
            done = self._done
        self.log("[графика] модель разобрала лист %d из %d: %s" % (done, len(self._jobs), label))

    def finish(self):
        """Дождаться разборов и вписать их в листы. Возвращает число листов."""
        try:
            for sheet, future in self._jobs:
                try:
                    review = future.result()
                except Exception as exc:  # noqa: BLE001 — лист остаётся без разбора
                    self.log("[%s] разбор листа моделью не удался: %s" % (sheet["label"], exc))
                    review = None
                apply_review(sheet, review)
        finally:
            self._pool.shutdown(wait=True)
        return len(self._jobs)


def review_sheets(client, sheets, section, log=print, parallel=PARALLEL_REQUESTS):
    """Разбор готового списка листов (без наложения на сравнение)."""
    reviewer = Reviewer(client, section, log=log, parallel=parallel)
    for sheet in sheets:
        reviewer.submit(sheet)
    return reviewer.finish()


def apply_review(sheet, review):
    """Зоны листа с разбором модели; несущественные отброшены, остальные
    перенумерованы подряд. Без разбора зоны остаются как нашёл код."""
    if review is None:
        for zone in sheet["zones"]:
            zone.setdefault("system", "—")
            zone.setdefault("category", "Не разобрано")
            zone.setdefault("description",
                            "Изменение графики; разобрать моделью не удалось — смотрите фрагмент.")
        return sheet
    by_n = {z["n"]: z for z in review.get("zones") or []}
    kept = []
    for zone in sheet["zones"]:
        verdict = by_n.get(zone["n"])
        if verdict is None:
            zone.update({"system": "—", "category": "Не разобрано",
                         "description": "Модель зону не описала — смотрите фрагмент."})
        elif verdict["category"] == INSIGNIFICANT:
            continue
        else:
            zone.update({"system": verdict["system"].strip() or "—",
                         "category": verdict["category"],
                         "description": verdict["description"].strip()})
        kept.append(zone)
    for number, zone in enumerate(kept, 1):
        zone["n_report"] = number
    sheet["zones"] = kept
    sheet["summary"] = (review.get("sheet_summary") or "").strip()
    sheet["remarks"] = [r.strip() for r in review.get("remarks") or [] if r and r.strip()]
    return sheet


def summary_content(pair):
    """Сообщение модели для сводки по одному изменению: разборы листов и
    сверка с разрешением, текстом."""
    facts = {
        "изменение": pair["label"],
        "разрешение": pair.get("permit"),
        "сверка_кода": pair.get("permit_check"),
        "листы": [{
            "лист": s["label"], "наименование": s.get("title") or "",
            "переработан_целиком": bool(s.get("reworked")),
            "суть": s.get("summary") or "",
            "замечания": s.get("remarks") or [],
            "зоны": [{"система": z.get("system"), "категория": z.get("category"),
                      "изменение": z.get("description")} for z in s["zones"]],
        } for s in pair["sheets"]],
    }
    return ("Разборы листов и сверка по изменению (JSON):\n"
            + json.dumps(facts, ensure_ascii=False, indent=1))


def summarize_pair(client, pair, section, log=print):
    """Ключевые изменения и сверка с разрешением по одному изменению:
    словарь по SUMMARY_SCHEMA или None при сбое."""
    try:
        response = client.messages(
            [{"role": "user", "content": summary_content(pair)}],
            system=_system(section, "summary"), model=SHEET_MODEL,
            max_tokens=SUMMARY_MAX_TOKENS, effort=SUMMARY_EFFORT,
            output_schema=SUMMARY_SCHEMA)
        return json.loads(extract_text(response))
    except (AnthropicError, ValueError) as exc:
        log("[%s] сводку по изменению модель не написала: %s" % (pair["label"], exc))
        return None
