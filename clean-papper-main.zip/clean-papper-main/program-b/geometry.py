# -*- coding: utf-8 -*-
"""
Извлечение графических примитивов листа (текстовые подписи и векторные
пути — линии/полилинии из CAD-экспорта) для последующего сравнения
между ревизиями в diff_engine.py.

Ничего не сравнивает сама — только достаёт из PyMuPDF-страницы плоский
список объектов с их bbox, годный для геометрического сопоставления.
"""
import math

import fitz

from stamp import TEXT_FLAGS, in_zones


# Минимальная толщина пути в pt (см. extract_paths): прямая линия
# приходит с нулевой толщиной, а дальше по коду bbox должен быть
# невырожденным — и при сравнении, и при отрисовке вырезки.
_MIN_PATH_EXTENT = 0.5


def _finite(value):
    return isinstance(value, (int, float)) and math.isfinite(value) and abs(value) < 1e6


def _display_matrix(page):
    """Матрица приведения координат к системе page.rect.

    У повёрнутых листов (/Rotate 90/270 — лист А1, физически лежащий в
    файле боком) get_text и get_drawings отдают координаты в НЕповёрнутой
    системе, тогда как page.rect — уже повёрнутый. Из-за этого вырезка
    "было/стало" строилась по координатам вне листа и отрисовка падала на
    пустой картинке. Приводим всю геометрию листа к одной системе — той,
    в которой лист видит человек и в которой работает get_pixmap(clip=)."""
    return page.rotation_matrix if page.rotation else None


def _mapped(bbox, matrix):
    if matrix is None:
        return tuple(bbox)
    rect = (fitz.Rect(bbox) * matrix).normalize()
    return (rect.x0, rect.y0, rect.x1, rect.y1)


def _drop_zones(items, zones):
    """Убирает элементы, попавшие в зоны штампа (см. stamp.stamp_zones).
    Пустой список зон ничего не меняет — сравнение остаётся прежним."""
    if not zones:
        return items
    return [it for it in items if not in_zones(it["bbox"], zones)]


def extract_text_lines(page, zones=None):
    """Список текстовых строк: {"bbox": (x0,y0,x1,y1), "spans": [{"text":
    str, "bbox": (...)}, ...]} — используем готовую группировку по
    строкам от PyMuPDF (page.get_text("dict")), а не собственную
    геометрическую кластеризацию.

    Строки, а не отдельные "спаны" по отдельности — при сравнении важно
    сохранить порядок соседних фрагментов внутри строки: если в середину
    строки вставили новую подпись, все фрагменты после неё физически
    сдвигаются вправо и при независимом сравнении по позиции ложно
    считались бы "изменившимися", хотя на самом деле не менялись, просто
    сместились из-за вставки перед ними (см. diff_engine.diff_text_lines)."""
    lines = []
    matrix = _display_matrix(page)
    d = page.get_text("dict", flags=TEXT_FLAGS)
    for block in d.get("blocks", []):
        for line in block.get("lines", []):
            spans = []
            for span in line.get("spans", []):
                text = span.get("text", "")
                if not text.strip():
                    continue
                spans.append({"text": text, "bbox": _mapped(span["bbox"], matrix)})
            if spans:
                lines.append({"bbox": _mapped(line["bbox"], matrix), "spans": spans})
    return _drop_zones(lines, zones)


def extract_texts(page, zones=None):
    """Плоский список всех подписей (без деления на строки) — для оценки
    сдвига листа (diff_engine.estimate_offset), где порядок фрагментов
    внутри строки не важен, важны только совпадающие по тексту пары."""
    texts = []
    for line in extract_text_lines(page, zones=zones):
        texts.extend(line["spans"])
    return texts


def extract_paths(page, zones=None):
    """Список векторных путей (линии, полилинии, дуги — как их отдаёт
    PyMuPDF page.get_drawings()) по их bbox. Каждый path — как правило,
    один "нарисованный" объект чертежа (стенка, воздуховод, выноска и
    т.п.), а не сборная геометрия всего листа одним объектом — это
    подтверждено на реальных файлах (счёт путей на лист — тысячи)."""
    paths = []
    matrix = _display_matrix(page)
    # get_cdrawings, а не get_drawings: то же самое, но без построения
    # объектов Rect и разбора необязательных полей. На листе ВК с 45
    # тысячами путей это 0.26 с против 0.48 и на треть меньше памяти, а
    # извлечение вектора — 68% всего времени сравнения таких листов.
    # Толщина линии не извлекается — сравнение путей идёт по bbox. Цвет
    # извлекается: на планах инженерных сетей сами сети цветные, а
    # подоснова (стены, оси, размеры) — чёрно-серая, и по одному этому
    # признаку находка относится к «Сетям» или к «Подоснове/графике»
    # (категории из эталонного отчёта заказчика).
    for drawing in page.get_cdrawings():
        rect = drawing.get("rect")
        if not rect:
            continue
        x0, y0, x1, y1 = rect[0], rect[1], rect[2], rect[3]
        if not (_finite(x0) and _finite(y0) and _finite(x1) and _finite(y1)):
            continue
        if x0 > x1 or y0 > y1:
            continue
        # Строго горизонтальная или вертикальная линия даёт вырожденный
        # bbox (нулевая высота или ширина) — а это ровно трассировка:
        # воздуховоды, трубопроводы, оси. Раньше такие пути отбрасывались
        # как "пустой прямоугольник", и в сравнение не попадала треть
        # всего вектора листа (замер на ОВ2: 589 из 1917 путей на листе
        # 12, 652 из 2031 на листе 13) — то есть изменения трассировки
        # отчёт в принципе не видел. Вместо отбрасывания раздуваем такой
        # bbox до минимальной толщины: дальше с ним работают как с
        # обычным, а fitz.Rect от него уже не пустой.
        if x1 - x0 < _MIN_PATH_EXTENT:
            mid = (x0 + x1) / 2.0
            x0, x1 = mid - _MIN_PATH_EXTENT / 2.0, mid + _MIN_PATH_EXTENT / 2.0
        if y1 - y0 < _MIN_PATH_EXTENT:
            mid = (y0 + y1) / 2.0
            y0, y1 = mid - _MIN_PATH_EXTENT / 2.0, mid + _MIN_PATH_EXTENT / 2.0
        paths.append({"bbox": _mapped((x0, y0, x1, y1), matrix),
                       "colored": _is_colored(drawing),
                       "light": _is_light(drawing)})
    return _drop_zones(paths, zones)


# Насколько компоненты цвета должны разойтись, чтобы считать его
# цветным, а не оттенком серого. Чёрный, белый и серый дают разброс 0.
_COLOR_SPREAD = 0.12


def _is_colored(drawing):
    for key in ("color", "fill"):
        value = drawing.get(key)
        if not value or len(value) < 3:
            continue
        if max(value[:3]) - min(value[:3]) >= _COLOR_SPREAD:
            return True
    return False


# Светлее этого — подоснова: архитектурный план, который инженерные
# разделы получают от архитектора и выводят светло-серым (0.7–0.8 на
# всех присланных комплектах), и белые маски. Сети при этом цветные или
# чёрные.
_LIGHT_MIN = 0.5


def _is_light(drawing):
    """Светло-серый или белый путь — подоснова, не трассировка и не
    оборудование. Цвет берётся у линии, а если её нет — у заливки."""
    for key in ("color", "fill"):
        value = drawing.get(key)
        if not value or len(value) < 3:
            continue
        spread = max(value[:3]) - min(value[:3])
        return spread < _COLOR_SPREAD and sum(value[:3]) / 3.0 >= _LIGHT_MIN
    return False


def extract_elements(page, zones=None):
    """zones — прямоугольники, которые в сравнении не участвуют (зоны
    штампа, см. stamp.stamp_zones). Заполнение штампа — не изменение
    чертежа, а на каждом изменённом листе оно даёт находки.

    Текст разбирается ОДИН раз: page.get_text("dict") — самая дорогая
    операция всего сравнения (1.1 с на лист по замеру, в пятьдесят раз
    дороже разбора вектора), а плоский список подписей получается из уже
    разобранных строк простым перебором. Раньше здесь было два разбора
    одной и той же страницы подряд."""
    lines = extract_text_lines(page, zones=zones)
    texts = []
    for line in lines:
        texts.extend(line["spans"])
    return {"texts": texts, "lines": lines, "paths": extract_paths(page, zones=zones)}
