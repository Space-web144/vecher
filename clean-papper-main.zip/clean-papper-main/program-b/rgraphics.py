# -*- coding: utf-8 -*-
"""Разбор листов пары редакций — в дочернем процессе, частями.

Для каждого сопоставленного листа: зоны изменений (rdiff), картинки к ним
(rfigures) — в файлы во временной папке, а наружу — только описание
листа: что изменилось, где лежат картинки. Картинки в память родителя не
передаются: у процессов на хостинге жёсткий предел памяти.
"""
import gc
import os

import fitz

import rdiff
import rfigures

# Сколько зон листа показывать фрагментами в отчёте и сколько — модели.
MAX_FRAGMENTS = 16
MAX_MODEL_FRAGMENTS = 10
# Как часто переоткрывать файлы: MuPDF копит кэш разобранных страниц.
REOPEN_EVERY = 5

def _write(path, data):
    with open(path, "wb") as handle:
        handle.write(data)
    return path


def sheet_record(old_page, new_page, key, how, stamp_new, label, number, pair_label,
                 tmp_dir, tag, permit_note):
    """Разбор одного листа: (строка сводки, описание для отчёта или None)."""
    # Содержимое листов разбирается один раз: из него рисуются и растр
    # для сравнения, и обзор, и все фрагменты зон.
    old_list, new_list = rdiff.display_list(old_page), rdiff.display_list(new_page)
    diff = rdiff.diff_pages(old_page, new_page, ignore_pt=stamp_new.get("zones") or (),
                            old_list=old_list, new_list=new_list)
    title = stamp_new.get("title") or ""
    stamp_claims = ("штампа нет" if not key[0]
                    else ("да" if stamp_new.get("change_log") else "нет"))
    changed = bool(diff["zones"]) or diff["reworked"]
    # Последний столбец — как сопоставлен лист («был лист 15», «по
    # содержанию»): отдельно от подписи, по ней лист ищут в разрешении.
    row = [label, "Изменён" if changed else "Без изменений", stamp_claims,
           title, f"{100.0 * diff['changed_share']:.2f}%", how]
    if not changed:
        return row, None

    record = {"label": label, "number": number, "how": how, "title": title, "pair": pair_label,
              "permit_note": permit_note, "reworked": diff["reworked"],
              "share": diff["changed_share"], "zones": []}
    base = os.path.join(tmp_dir, "gfx_%s" % tag)
    if diff["reworked"]:
        for side, page in (("old", old_list), ("new", new_list)):
            data, w, h = plain_sheet(page)
            record["%s_full" % side] = {"file": _write(base + "_%s.jpg" % side, data),
                                        "w": w, "h": h}
        return row, record

    data, w, h, scale = rfigures.overview(new_list, diff)
    record["overview"] = {"file": _write(base + "_ov.jpg", data), "w": w, "h": h,
                          "scale": scale}
    record["model_overview"] = _write(
        base + "_ovm.jpg", rfigures.numbered_overview(data, w, h, diff["zones"], scale))
    by_size = sorted(diff["zones"], key=lambda z: -(z["rem"] + z["add"]))
    with_fragment = {z["n"] for z in by_size[:MAX_FRAGMENTS]}
    for_model = {z["n"] for z in by_size[:MAX_MODEL_FRAGMENTS]}
    for zone in diff["zones"]:
        item = {k: zone[k] for k in ("n", "box", "rem", "add", "w_minus", "w_plus")}
        if zone["n"] in with_fragment:
            old_jpg, new_jpg, fw, fh = rfigures.fragments(old_list, new_list, diff, zone)
            item["frag_old"] = _write(base + "_z%d_a.jpg" % zone["n"], old_jpg)
            item["frag_new"] = _write(base + "_z%d_b.jpg" % zone["n"], new_jpg)
            item["frag_w"], item["frag_h"] = fw, fh
            if zone["n"] in for_model:
                item["model_img"] = _write(base + "_z%d_m.jpg" % zone["n"],
                                           rfigures.side_by_side(old_jpg, new_jpg))
        record["zones"].append(item)
    return row, record


def plain_sheet(page):
    """Лист целиком (для переработанного листа): JPEG, ширина, высота.
    page — страница или её DisplayList."""
    img = rdiff.render(page, dpi=rfigures.page_dpi(page))
    return rfigures.jpeg(img), img.shape[1], img.shape[0]


def graphics_chunk(old_path, new_path, chunk, stamps_new, tmp_dir, tag, first_sheet,
                   total_sheets, label, pair_label, permit_notes, without_drawing, log,
                   memory_text=lambda: ""):
    """Разбор части листов пары. chunk — [(ключ, стр. старой, стр. новой,
    как сопоставлен)]. Возвращает {"rows", "records", "unfinished"}:
    unfinished — листы, начиная с упавшего (процесс после сбоя внутри
    PyMuPDF уже не годен, их разберут в свежих процессах)."""
    old_doc, new_doc = fitz.open(old_path), fitz.open(new_path)
    rows, records, unfinished = [], [], []
    for offset, (key, oi, ni, how) in enumerate(chunk):
        sheet_no = first_sheet + offset
        sheet_label = _label(key)
        number = key[1] if key[0] else None
        stamp_new = stamps_new[ni] or {}
        try:
            if without_drawing(key, stamp_new):
                # Спецификация, общие данные, ведомости: изменился ли лист,
                # нужно для сверки с разрешением, а зоны — нет.
                diff = rdiff.diff_pages(old_doc[oi], new_doc[ni],
                                        ignore_pt=stamp_new.get("zones") or ())
                changed = bool(diff["zones"]) or diff["reworked"]
                rows.append([sheet_label, "Изменён" if changed else "Без изменений",
                             "да" if stamp_new.get("change_log") else "нет", "", "без чертежа",
                             how])
                del diff
            else:
                row, record = sheet_record(
                    old_doc[oi], new_doc[ni], key, how, stamp_new, sheet_label, number,
                    pair_label, tmp_dir, "%s_%02d" % (tag, offset),
                    permit_notes.get(number) if number else None)
                rows.append(row)
                if record is not None:
                    records.append(record)
        except Exception as exc:  # noqa: BLE001 — лист не должен ронять прогон
            reason = str(exc) or type(exc).__name__
            log(f"[{label}] лист {sheet_label} не разобран: {reason}" + memory_text())
            unfinished = list(chunk[offset:])
            break
        if sheet_no % REOPEN_EVERY == 0 or sheet_no == total_sheets:
            old_doc.close()
            new_doc.close()
            gc.collect()
            old_doc, new_doc = fitz.open(old_path), fitz.open(new_path)
            log(f"[{label}] разобрано листов {sheet_no} из {total_sheets}" + memory_text())
    old_doc.close()
    new_doc.close()
    return {"rows": rows, "records": records, "unfinished": unfinished}


def _label(key):
    marka, sheet_no = key
    if not marka:
        return f"лист без штампа — стр. {sheet_no}"
    return f"{marka} — лист {sheet_no}"
