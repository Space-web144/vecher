# -*- coding: utf-8 -*-
"""Поиск зон изменения на паре листов — алгоритм rdgraph, присланный
заказчиком («алгоритмы сравнения»), по которому собран и его эталонный
отчёт («Графическое сравнение 143/23-ГК-РД-1-ОВ2»).

Из раздела «Как» эталона:
- растр листа с учётом поворота;
- совмещение по уникальным надписям: несколько сдвигов (рамка и план
  бывают сдвинуты по-разному), плюс локальное совмещение фрагментов —
  перенесённый блок схемы изменением не считается;
- сравнивается только «цветной слой» — сети и оборудование; подоснова
  (серое, жёлтые и бледные заливки) и текст в счёт не идут;
- зоны меньше порога изменённых штрихов отбрасываются как малое.

У rdgraph это opencv и poppler; на хостинге их нет, поэтому здесь то же
самое на numpy и PyMuPDF. Пороги заданы в миллиметрах листа и
пересчитываются в пиксели от DPI: rdgraph считал при 75 dpi, эталон — при
150, здесь — 100: при 75 на ВК терялся новый трап (кружок в 35 мм
штриха), а выигрыш по времени мал — на тяжёлых листах его съедает сама
отрисовка.
"""
from collections import Counter, defaultdict

import fitz
import numpy as np

from stamp import page_words

DPI = 100

# Пиксель — «чернила», если серый темнее этого (ink_gray у rdgraph).
INK_GRAY = 215
# Цветной штрих: насыщенность выше этого (0–255, как S в HSV у rdgraph).
COLOR_SAT = 70
# Тёмный штрих (чёрные сети, оборудование, выноски): темнее этого.
# Светло-серая подоснова — 178 и светлее.
DARK_GRAY = 110


def _px(mm):
    """Миллиметры листа в пиксели при DPI."""
    return max(1, int(round(mm / 25.4 * DPI)))


# Совмещение по словам: шаг корзины сдвигов, минимум слов и доля.
SHIFT_BIN_MM = 1.0
SHIFT_MIN_WORDS = 4
SHIFT_MIN_SHARE = 0.08
SHIFT_MAX_CLUSTERS = 3
# Допуск совпадения штриха (match_dilate 5 px при 75 dpi ≈ 1.7 мм).
MATCH_MM = 0.85
# Шумовой гейт: разница размытых плотностей чернил.
BLUR_MM = 1.35
BLUR_THRESH = 0.15
# Регионы и зоны (при 75 dpi у rdgraph: group 31, pad 35, min 40 px).
CELL_MM = 1.0
REGION_GAP_MM = 3.0
ZONE_PAD_MM = 12.0
ZONE_PAD_FINE_MM = 5.0
ZONE_SPLIT_SHARE = 0.05
ZONE_DROP_SHARE = 0.20
MIN_REGION_MM = 4.5          # длина штриха в мм: меньше — соринка
LINE_PTP_MM = 1.7            # тонкая прямая — след сдвига длинной линии
NEAR_DUP_MM = 5.0
NEAR_DUP_SHARE = 0.90
NEAR_DUP_MAX_MM = 45.0
# «Что отброшено как малое»: зона, где изменилось меньше этого (мм
# штриха). У эталона ~100 мм, но на ВК так пропадает новый трап или
# воронка — кружок в 35 мм штриха. Порог ниже, а несущественные зоны
# отсеивает модель, которая видит фрагмент (см. sheet_agent).
ZONE_MIN_MM = 30.0
# Локальное совмещение: блок, перенесённый не дальше этого, не изменение.
LOCAL_SHIFT_MM = 50.0
LOCAL_MATCH_SHARE = 0.75
# Перенос блока вместе с подписями (на любое расстояние): сдвиг берётся
# по надписям, исчезнувшим и появившимся в стольких мм от области.
LABEL_REACH_MM = 15.0
# Сколько зон показывать на листе (остальные — самые мелкие).
MAX_ZONES = 24
# Лист переработан целиком (перекомпонован, другой чертёж под тем же
# номером), если изменилась такая доля его значимых штрихов: зоны на нём
# — это весь лист, нарезанный на куски, и в отчёте он идёт одной строкой
# с обзором обеих редакций. На ВК 89_21: обычные изменённые листы —
# 0.1–1.6%, перекомпонованные в изм. 2 — от 4.7 до 23%.
# Доля считается после отсева перенесённых блоков и мелочи и только по
# линиям: сплошная заливка (на ОВ2 — выделенные зелёным области плана)
# весит в пикселях как сотни линий, и лист с одной снятой заливкой
# выглядел перекомпонованным.
REWORKED_SHARE = 0.04
# …и только если изменённых областей много: смысл «переработан целиком» —
# не резать лист на сотни зон. Лист схем ОВ2 с двумя новыми схемами из
# четырнадцати областей набирает 5% (схемы разрежены, линий на листе
# мало) — это обычный изменённый лист, и зоны на нём нужны.
REWORKED_MIN_REGIONS = 40
# Выше этой доли (ещё до отсева) лист заведомо другой — регионы на нём
# не разбираются вовсе: их сотни, и это минуты счёта.
REWORKED_HARD_SHARE = 0.25
# Толще этого — заливка, а не линия: её внутренность в долю не идёт.
FILL_MM = 0.75


def _len_px(mm):
    """Длина штриха в мм -> число пикселей тонкой линии при DPI."""
    return mm / 25.4 * DPI


# ---------------------------------------------------------------- растр

def display_list(page):
    """Разобранное содержимое листа — для многократной отрисовки."""
    return page.get_displaylist()


def render(page, dpi=DPI, clip=None, antialias=True):
    """Страница в RGB (uint8, H×W×3), как она отображается (с поворотом).

    page — страница или её fitz.DisplayList (см. display_list): каждый
    page.get_pixmap заново разбирает всё содержимое листа, а фрагментов
    у изменённого листа до двух десятков.

    antialias=False — для сравнения: со сглаживанием линия тоньше
    пикселя становится серой той же яркости, что и светло-серая
    подоснова (178), и отличить чёрную сеть от подосновы нельзя. Без
    сглаживания чёрное остаётся чёрным."""
    saved = None
    if not antialias:
        saved = fitz.TOOLS.show_aa_level()
        fitz.TOOLS.set_aa_level(0)
    try:
        zoom = dpi / 72.0
        pix = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom), colorspace=fitz.csRGB,
                              alpha=False, clip=clip)
    finally:
        if saved is not None:
            fitz.TOOLS.set_aa_level(saved["graphics"])
    arr = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.stride)
    return arr[:, :pix.width * 3].reshape(pix.height, pix.width, 3).copy()


def _gray(rgb):
    return (rgb[..., 0].astype(np.uint16) * 77 + rgb[..., 1].astype(np.uint16) * 150
            + rgb[..., 2].astype(np.uint16) * 29 >> 8).astype(np.uint8)


def _colored(rgb):
    """Насыщенность выше COLOR_SAT: (max − min) / max > COLOR_SAT / 255.
    В целых без деления: обе части умножены на 255 / 5."""
    hi = np.maximum(np.maximum(rgb[..., 0], rgb[..., 1]), rgb[..., 2]).astype(np.uint16)
    lo = np.minimum(np.minimum(rgb[..., 0], rgb[..., 1]), rgb[..., 2]).astype(np.uint16)
    return (hi - lo) * 51 > hi * (COLOR_SAT // 5)


def layers(rgb, words=()):
    """(чернила, значимый слой).

    Значимый слой — то, что несёт сети и оборудование: цветные штрихи и
    тёмные (чёрные) штрихи. Светло-серая подоснова АР в него не входит,
    надписи текстового слоя тоже (у эталона «подоснова АР … и текст в
    счёт не идут»): изменившиеся подписи описывают зону словами, но зону
    сами по себе не создают."""
    gray = _gray(rgb)
    ink = gray < INK_GRAY
    significant = ink & (_colored(rgb) | (gray < DARK_GRAY))
    h, w = gray.shape
    for word in words:
        x0, y0, x1, y1 = (int(v) for v in word[2:6])
        significant[max(0, y0 - 1):min(h, y1 + 2), max(0, x0 - 1):min(w, x1 + 2)] = False
    return ink, significant


# ----------------------------------------------------------- морфология

def dilate(mask, radius):
    """Расширение маски квадратом (2r+1)², по осям раздельно."""
    if radius <= 0:
        return mask
    out = mask
    for axis in (0, 1):
        grown = out.copy()
        for step in range(1, radius + 1):
            head = tuple(slice(None, -step) if a == axis else slice(None) for a in (0, 1))
            tail = tuple(slice(step, None) if a == axis else slice(None) for a in (0, 1))
            grown[head] |= out[tail]
            grown[tail] |= out[head]
        out = grown
    return out


def _box_blur(arr, width):
    """Скользящее среднее окном width по обеим осям (через суммы)."""
    out = arr.astype(np.float32)
    if width <= 1:
        return out
    half = width // 2
    for axis in (0, 1):
        pad = [(0, 0), (0, 0)]
        pad[axis] = (half + 1, half)
        cs = np.cumsum(np.pad(out, pad, mode="edge"), axis=axis, dtype=np.float32)
        n = out.shape[axis]
        hi = [slice(None), slice(None)]
        lo = [slice(None), slice(None)]
        hi[axis] = slice(width, width + n)
        lo[axis] = slice(0, n)
        out = ((cs[tuple(hi)] - cs[tuple(lo)]) / width).astype(np.float32)
    return out


# Плотность для шумового гейта считается на растре, уменьшенном в
# BLUR_FACTOR раз: размытие на полном листе А0 стоило 7 с из 17, а гейту
# нужна только плотность штрихов вокруг пикселя.
BLUR_FACTOR = 4


def _shrink(mask):
    """Доля чернил в клетках BLUR_FACTOR×BLUR_FACTOR (float32)."""
    f = BLUR_FACTOR
    h, w = mask.shape
    rows, cols = -(-h // f), -(-w // f)
    padded = np.zeros((rows * f, cols * f), dtype=np.float32)
    padded[:h, :w] = mask
    return padded.reshape(rows, f, cols, f).mean(axis=(1, 3))


def _expand(small, shape):
    """Клетки уменьшенного растра обратно в пиксели (обрезано по shape)."""
    f = BLUR_FACTOR
    rows, cols = small.shape
    full = np.broadcast_to(small[:, None, :, None], (rows, f, cols, f)).reshape(rows * f, cols * f)
    return full[:shape[0], :shape[1]]


def density(mask, sigma_px):
    """Размытая плотность чернил на уменьшенном растре (см. BLUR_FACTOR):
    приближение гауссова размытия тремя проходами скользящего среднего."""
    f = BLUR_FACTOR
    small = _shrink(mask)
    sigma = sigma_px / f
    width = max(1, int(round((4.0 * sigma * sigma + 1.0) ** 0.5)))
    if width % 2 == 0:
        width += 1
    for _ in range(3):
        small = _box_blur(small, width)
    return small


def density_full(small, shape):
    """Плотность, растянутая обратно до растра листа."""
    return np.ascontiguousarray(_expand(small, shape))


def shifted(arr, dx, dy, shape=None, fill=0):
    """arr, сдвинутый на (dx, dy) пикселей: out[y + dy, x + dx] = arr[y, x]."""
    h, w = shape if shape is not None else arr.shape[:2]
    out = np.full((h, w) + arr.shape[2:], fill, dtype=arr.dtype)
    sh, sw = arr.shape[:2]
    y0, x0 = max(0, dy), max(0, dx)
    y1, x1 = min(h, sh + dy), min(w, sw + dx)
    if y1 > y0 and x1 > x0:
        out[y0:y1, x0:x1] = arr[y0 - dy:y1 - dy, x0 - dx:x1 - dx]
    return out


# ------------------------------------------------------------- слова

def words_px(page, dpi=DPI):
    """Слова листа: (cx, cy, x0, y0, x1, y1, текст) в пикселях."""
    k = dpi / 72.0
    out = []
    for w in page_words(page):
        text = str(w[4]).strip()
        if not text:
            continue
        x0, y0, x1, y1 = w[0] * k, w[1] * k, w[2] * k, w[3] * k
        out.append(((x0 + x1) / 2, (y0 + y1) / 2, x0, y0, x1, y1, text))
    return out


def _unique(words):
    count = Counter(w[6] for w in words)
    return {w[6]: w for w in words if count[w[6]] == 1 and len(w[6]) >= 2}


# Слово, встречающееся на листе чаще, в голосовании не участвует: его
# пары с одноимёнными словами другой редакции — почти сплошь шум.
SHIFT_MAX_REPEAT = 6


def word_shifts(wa, wb):
    """Кластеры сдвигов листа по общим словам: [(dx, dy, n)].
    Первый — основной. Несколько — когда рамка и план сдвинуты по-разному.

    Голосуют все пары одноимённых слов, с весом 1 / (сколько раз слово
    повторяется). Одних уникальных слов мало: на схеме К2 изм. 2 правую
    половину сдвинули на 44 мм, а уникальных слов в ней шесть — остальное
    отметки этажей и марки стояков, которые есть и слева. Найденный
    сдвиг забирает объяснённые им пары слов, и следующий ищется по
    оставшимся: иначе одинаковые подписи двух половин схемы голосуют за
    ложный сдвиг «половина на половину»."""
    step = max(1, _px(SHIFT_BIN_MM))
    left_a = [w for w in wa if len(w[6]) >= 2]
    left_b = [w for w in wb if len(w[6]) >= 2]
    total = None
    out = []
    while len(out) < SHIFT_MAX_CLUSTERS:
        votes, classes = _shift_votes(left_a, left_b, step)
        if total is None:
            total = classes
        if not votes:
            break
        dx, dy, n = _shift_peak(votes, step)
        if n < SHIFT_MIN_WORDS or n < SHIFT_MIN_SHARE * total:
            break
        if any(abs(dx - x) <= 2 * step and abs(dy - y) <= 2 * step for x, y, _n in out):
            break
        out.append((dx, dy, int(round(n))))
        left_a, left_b = _unexplained(left_a, left_b, dx, dy, 2 * step)
    return out


def _shift_votes(wa, wb, step):
    """{корзина: вес} и число голосующих текстов."""
    in_a = Counter(w[6] for w in wa)
    by_text = {}
    for w in wb:
        by_text.setdefault(w[6], []).append(w)
    votes = {}
    classes = 0
    for a in wa:
        found = by_text.get(a[6])
        if not found:
            continue
        repeat = max(in_a[a[6]], len(found))
        if repeat > SHIFT_MAX_REPEAT:
            continue
        weight = 1.0 / repeat
        for b in found:
            ddx, ddy = b[0] - a[0], b[1] - a[1]
            cell = (int(round(ddx / step)), int(round(ddy / step)))
            votes[cell] = votes.get(cell, 0.0) + weight
    for text, count in in_a.items():
        found = by_text.get(text)
        if found and max(count, len(found)) <= SHIFT_MAX_REPEAT:
            classes += 1
    return votes, classes


def _shift_peak(votes, step):
    """Самая полная корзина: (dx, dy, вес). Вес — вместе с соседними
    корзинами (ровный сдвиг округлением делится между двумя), сдвиг —
    центр корзины: подписи между редакциями «дрожат» на доли миллиметра
    при неподвижной графике, и точнее корзины слова сдвиг не знают."""
    x, y = max(votes, key=lambda c: (votes[c], -abs(c[0]) - abs(c[1])))
    weight = sum(votes[(x + i, y + j)] for i in (-1, 0, 1) for j in (-1, 0, 1)
                 if (x + i, y + j) in votes)
    return x * step, y * step, weight


def _unexplained(wa, wb, dx, dy, tol):
    """Слова, которых сдвиг (dx, dy) не объясняет: пары «слово в A —
    то же слово в B на месте A + сдвиг» вычёркиваются из обеих
    редакций."""
    by_text = {}
    for index, w in enumerate(wb):
        by_text.setdefault(w[6], []).append(index)
    used_b = set()
    rest_a = []
    for a in wa:
        tx, ty = a[0] + dx, a[1] + dy
        hit = None
        for index in by_text.get(a[6], ()):
            b = wb[index]
            if index not in used_b and abs(b[0] - tx) <= tol and abs(b[1] - ty) <= tol:
                hit = index
                break
        if hit is None:
            rest_a.append(a)
        else:
            used_b.add(hit)
    return rest_a, [w for index, w in enumerate(wb) if index not in used_b]


def phase_shift(a, b, factor=4):
    """Сдвиг b относительно a по фазовой корреляции (без слов)."""
    sa = a[::factor, ::factor].astype(np.float32)
    sb = b[::factor, ::factor].astype(np.float32)
    h, w = max(sa.shape[0], sb.shape[0]), max(sa.shape[1], sb.shape[1])
    pa = np.zeros((h, w), np.float32)
    pb = np.zeros((h, w), np.float32)
    pa[:sa.shape[0], :sa.shape[1]] = sa
    pb[:sb.shape[0], :sb.shape[1]] = sb
    fa, fb = np.fft.rfft2(pa), np.fft.rfft2(pb)
    cross = fb * np.conj(fa)
    cross /= np.maximum(np.abs(cross), 1e-9)
    corr = np.fft.irfft2(cross, s=(h, w))
    y, x = np.unravel_index(int(np.argmax(corr)), corr.shape)
    if y > h // 2:
        y -= h
    if x > w // 2:
        x -= w
    return int(x * factor), int(y * factor)


# ------------------------------------------------------------ регионы

def _components(active, gap):
    """Связные группы активных ячеек; ячейки ближе gap — одна группа."""
    bridged = dilate(active, gap) if gap else active
    seen = np.zeros(active.shape, dtype=bool)
    rows, cols = active.shape
    groups = []
    for r0, c0 in zip(*np.nonzero(active)):
        if seen[r0, c0]:
            continue
        stack = [(r0, c0)]
        seen[r0, c0] = True
        cells = []
        while stack:
            r, c = stack.pop()
            if active[r, c]:
                cells.append((r, c))
            for nr in (r - 1, r, r + 1):
                for nc in (c - 1, c, c + 1):
                    if 0 <= nr < rows and 0 <= nc < cols and not seen[nr, nc] and bridged[nr, nc]:
                        seen[nr, nc] = True
                        stack.append((nr, nc))
        if cells:
            groups.append(cells)
    return groups


def _cell_sum(mask, cell):
    h, w = mask.shape
    rows, cols = -(-h // cell), -(-w // cell)
    padded = np.zeros((rows * cell, cols * cell), dtype=np.uint16)
    padded[:h, :w] = mask
    return padded.reshape(rows, cell, cols, cell).sum(axis=(1, 3))


def _boxes(changed, cell, gap):
    """Рамки групп изменённых пикселей: [(x0, y0, x1, y1)] в пикселях."""
    active = _cell_sum(changed, cell) > 0
    out = []
    h, w = changed.shape
    for cells in _components(active, gap):
        rs = [r for r, _c in cells]
        cs = [c for _r, c in cells]
        out.append((min(cs) * cell, min(rs) * cell,
                    min(w, (max(cs) + 1) * cell), min(h, (max(rs) + 1) * cell)))
    return out


def _moved_locally(box, rem, add, match):
    """Перенесён ли блок целиком (у эталона «перенос блоков схем до 300 px
    не считается изменением»): исчезнувшее в рамке при каком-то сдвиге в
    пределах LOCAL_SHIFT_MM ложится на появившееся, и наоборот.

    Сравнивается именно с появившимся, а не со всеми штрихами другой
    редакции: на плотном чертеже удалённый воздуховод иначе «совпал» бы
    с любыми соседними параллельными линиями. Всё считается в окне вокруг
    рамки: на перекомпонованном листе регионов сотни, и массивы во весь
    лист на каждый стоили минут."""
    reach = _px(LOCAL_SHIFT_MM)
    x0, y0, x1, y1 = box
    h, w = rem.shape
    wx0, wy0 = max(0, x0 - reach), max(0, y0 - reach)
    wx1, wy1 = min(w, x1 + reach), min(h, y1 + reach)
    win_rem = rem[wy0:wy1, wx0:wx1]
    win_add = add[wy0:wy1, wx0:wx1]
    bx0, by0, bx1, by1 = x0 - wx0, y0 - wy0, x1 - wx0, y1 - wy0

    def explained(win_part, win_other):
        """Доля пикселей части в рамке, которые при лучшем сдвиге ложатся
        на другую маску окна."""
        tpl = np.zeros(win_part.shape, dtype=np.float32)
        tpl[by0:by1, bx0:bx1] = win_part[by0:by1, bx0:bx1]
        total = float(tpl.sum())
        if total == 0:
            return 1.0
        target = dilate(win_other, match)
        if not target.any():
            return 0.0
        corr = np.fft.irfft2(np.fft.rfft2(target.astype(np.float32)) * np.conj(np.fft.rfft2(tpl)),
                             s=tpl.shape)
        dy, dx = np.unravel_index(int(np.argmax(corr)), corr.shape)
        if dy > tpl.shape[0] // 2:
            dy -= tpl.shape[0]
        if dx > tpl.shape[1] // 2:
            dx -= tpl.shape[1]
        if abs(dx) > reach or abs(dy) > reach:
            return 0.0
        moved = shifted(tpl > 0, int(dx), int(dy))
        return float((moved & target).sum()) / total

    return (explained(win_rem, win_add) >= LOCAL_MATCH_SHARE
            and explained(win_add, win_rem) >= LOCAL_MATCH_SHARE)


def _lines(mask, fill):
    """Маска без внутренностей заливок: пиксели, у которых в квадрате
    (2·fill+1)² есть пустое место. Линии остаются целиком, у заливки —
    только кромка."""
    return mask & dilate(~mask, fill)


def _window(arr, x0, y0, x1, y1):
    """Кусок маски [y0:y1, x0:x1]; то, что за краем листа, — пусто."""
    h, w = arr.shape
    out = np.zeros((y1 - y0, x1 - x0), dtype=arr.dtype)
    sx0, sy0, sx1, sy1 = max(0, x0), max(0, y0), min(w, x1), min(h, y1)
    if sx1 > sx0 and sy1 > sy0:
        out[sy0 - y0:sy1 - y0, sx0 - x0:sx1 - x0] = arr[sy0:sy1, sx0:sx1]
    return out


def _moved_with_labels(box, rem, add, gone, new, dx, dy, match):
    """Перенесён ли блок вместе со своими подписями — на любое расстояние.

    Схемы на листе переставляют блоками (ОВ2 изм. 2, лист «Схемы систем
    Вж2.9 – Вж2.32»: каждая схема на своё место), и общих сдвигов листа
    тогда больше, чем находит голосование по всему листу. У каждого блока
    свои подписи: надпись, исчезнувшая рядом с областью, появилась там,
    куда блок переехал. Сдвиг — по таким парам, и блок считается
    перенесённым, если исчезнувшее в области при этом сдвиге ложится на
    появившееся (и наоборот) не меньше чем на LOCAL_MATCH_SHARE."""
    if not gone or not new:
        return False
    step = max(1, _px(SHIFT_BIN_MM))
    reach = _px(LABEL_REACH_MM)
    x0, y0, x1, y1 = box

    def near(x, y):
        return x0 - reach <= x <= x1 + reach and y0 - reach <= y <= y1 + reach

    gone_b = [(w[0] + dx, w[1] + dy, w[6]) for w in gone]
    new_b = [(w[0], w[1], w[6]) for w in new]
    new_by, gone_by = defaultdict(list), defaultdict(list)
    for w in new_b:
        new_by[w[2]].append(w)
    for w in gone_b:
        gone_by[w[2]].append(w)
    votes = Counter()
    for g in gone_b:
        if near(g[0], g[1]):
            for n in new_by.get(g[2], ()):
                votes[(int(round((n[0] - g[0]) / step)), int(round((n[1] - g[1]) / step)))] += 1
    for n in new_b:
        if near(n[0], n[1]):
            for g in gone_by.get(n[2], ()):
                votes[(int(round((n[0] - g[0]) / step)), int(round((n[1] - g[1]) / step)))] += 1
    part_rem = rem[y0:y1, x0:x1]
    part_add = add[y0:y1, x0:x1]
    total = int(part_rem.sum()) + int(part_add.sum())
    if not total:
        return False
    for (cx, cy), count in votes.most_common(3):
        if count < 2:
            break
        sx, sy = cx * step, cy * step
        hit = int((part_rem & dilate(_window(add, x0 + sx, y0 + sy, x1 + sx, y1 + sy), match)).sum())
        hit += int((part_add & dilate(_window(rem, x0 - sx, y0 - sy, x1 - sx, y1 - sy), match)).sum())
        if hit >= LOCAL_MATCH_SHARE * total:
            return True
    return False


# ---------------------------------------------------------------- QR

# QR-код в штампе меняется с каждой выгрузкой. Размеры — как у rdgraph
# (qr_box 25, qr_min 20, qr_max 130 px при 75 dpi).
QR_BOX_MM = 8.5
QR_DENSITY = 0.38
QR_MIN_MM = 6.8
QR_MAX_MM = 44.0
QR_ZONE_X = 0.70
QR_ZONE_Y = 0.60


def qr_mask(ink):
    """Места QR-кодов: плотные квадраты чернил. В правом нижнем углу
    листа (у штампа) — любой такой квадрат; в поле — только похожий на
    QR (много переходов и пустая «тихая зона» вокруг)."""
    h, w = ink.shape
    # Плотность — на уменьшенном растре: размытие окном 8.5 мм во весь
    # лист А0 стоило полсекунды на каждую редакцию.
    dens = _box_blur(_shrink(ink), max(1, _px(QR_BOX_MM) // BLUR_FACTOR) | 1)
    hot = _expand(dens > QR_DENSITY, ink.shape)
    out = np.zeros_like(ink)
    cell = _px(CELL_MM)
    lo, hi = _px(QR_MIN_MM), _px(QR_MAX_MM)
    margin = _px(QR_BOX_MM) // 2 + _px(2.0)
    for x0, y0, x1, y1 in _boxes(hot, cell, 0):
        bw, bh = x1 - x0, y1 - y0
        if not (lo < bw < hi and lo < bh < hi and 0.6 < bw / float(bh) < 1.6):
            continue
        ex0, ey0 = max(0, x0 - margin), max(0, y0 - margin)
        ex1, ey1 = min(w, x1 + margin), min(h, y1 + margin)
        corner = x0 > w * QR_ZONE_X and y0 > h * QR_ZONE_Y
        if corner or _looks_like_qr(ink[ey0:ey1, ex0:ex1]):
            out[ey0:ey1, ex0:ex1] = True
    return out


def _looks_like_qr(box):
    if box.size == 0:
        return False
    bh, bw = box.shape
    if not 0.8 < bw / float(bh) < 1.25:
        return False
    dens = box.mean()
    if not 0.30 < dens < 0.80:
        return False
    rows = np.abs(np.diff(box.astype(np.int8), axis=1)).sum(axis=1).mean()
    cols = np.abs(np.diff(box.astype(np.int8), axis=0)).sum(axis=0).mean()
    return rows >= 6 and cols >= 6


# --------------------------------------------------------------- диф

def diff_pages(old_page, new_page, ignore_pt=(), words_old=None, words_new=None,
               old_list=None, new_list=None):
    """Зоны изменения пары листов. Возвращает словарь:
    shifts — [(dx, dy, n)] в пикселях DPI, первый основной;
    zones — [{box: (x0, y0, x1, y1) px листа B, rem, add, color,
              w_minus, w_plus, shift}];
    rem_a / add_b — маски исчезнувшего (в координатах A) и появившегося
    (в координатах B); size — (h, w) листа B; changed_share — доля
    изменившихся значимых штрихов; reworked — лист переработан целиком."""
    wa = words_old if words_old is not None else words_px(old_page)
    wb = words_new if words_new is not None else words_px(new_page)
    ink_a, lay_a = layers(render(old_list or old_page, antialias=False), wa)
    ink_b, lay_b = layers(render(new_list or new_page, antialias=False), wb)
    shape = ink_b.shape

    shifts = word_shifts(wa, wb)
    if not shifts:
        dx, dy = phase_shift(ink_a, ink_b)
        shifts = [(dx, dy, 0)]
    # Нулевой сдвиг проверяется всегда: рамка, штамп и таблицы листа
    # обычно стоят на месте, даже когда план на листе переставлен.
    if not any(abs(sx) <= _px(SHIFT_BIN_MM) * 2 and abs(sy) <= _px(SHIFT_BIN_MM) * 2
               for sx, sy, _n in shifts):
        shifts.append((0, 0, 0))

    match = _px(MATCH_MM)
    sigma = BLUR_MM / 25.4 * DPI
    dens_a, dens_b = density(ink_a, sigma), density(ink_b, sigma)
    full_a = density_full(dens_a, ink_a.shape)
    full_b = density_full(dens_b, shape)
    rem_a = lay_a.copy()
    add_b = lay_b.copy()
    for sx, sy, _n in shifts:
        b_in_a = shifted(ink_b, -sx, -sy, ink_a.shape)
        a_in_b = shifted(ink_a, sx, sy, shape)
        rem_a &= ~dilate(b_in_a, match)
        rem_a &= (full_a - shifted(full_b, -sx, -sy, ink_a.shape)) > BLUR_THRESH
        add_b &= ~dilate(a_in_b, match)
        add_b &= (full_b - shifted(full_a, sx, sy, shape)) > BLUR_THRESH
    del dens_a, dens_b, full_a, full_b

    dx, dy = shifts[0][0], shifts[0][1]
    rem = shifted(rem_a, dx, dy, shape)
    add = add_b.copy()
    ink_a0 = shifted(ink_a, dx, dy, shape)

    # QR-коды и штамп с графой изменений — не изменение чертежа.
    blocked = dilate(qr_mask(ink_b) | qr_mask(ink_a0), _px(2.0))
    k = DPI / 72.0
    for rect in ignore_pt:
        x0, y0, x1, y1 = (int(v * k) for v in tuple(rect)[:4])
        blocked[max(0, y0):max(0, y1), max(0, x0):max(0, x1)] = True
    rem &= ~blocked
    add &= ~blocked
    rem_a &= ~shifted(blocked, -dx, -dy, rem_a.shape)
    add_b = add

    # Лист переработан целиком — дальше не режем: зоны на нём были бы
    # всем листом, нарезанным на куски (и стоили бы минут счёта).
    drawn = max(int(lay_a.sum()), int(lay_b.sum()), 1)
    rem_l, add_l = rem, add
    share = float(rem.sum() + add.sum()) / (2.0 * drawn)
    if share >= REWORKED_SHARE / 2:
        # Заливки считаются, только когда изменений вообще заметно: на
        # обычном листе (доли процента) это четыре лишних прохода по
        # всему листу, а решение очевидно и без них.
        fill = _px(FILL_MM)
        drawn = max(int(_lines(lay_a, fill).sum()), int(_lines(lay_b, fill).sum()), 1)
        rem_l, add_l = _lines(rem, fill), _lines(add, fill)
        share = float(rem_l.sum() + add_l.sum()) / (2.0 * drawn)
    if share >= REWORKED_HARD_SHARE:
        return {"shifts": shifts, "zones": [], "dropped_small": 0,
                "rem_a": rem_a, "add_b": add_b, "size": shape,
                "changed_share": share, "reworked": True}

    cell = _px(CELL_MM)
    changed = rem | add
    regions = []
    near = _px(NEAR_DUP_MM)
    gone, new = _word_changes(wa, wb, shifts)
    for box in _boxes(changed, cell, max(1, _px(REGION_GAP_MM) // cell)):
        x0, y0, x1, y1 = box
        nr = int(rem[y0:y1, x0:x1].sum())
        na = int(add[y0:y1, x0:x1].sum())
        # Мелочь, тонкая полоса и почти-дубль отбрасываются, только если
        # в регионе не поменялись надписи (как у rdgraph): с новой маркой
        # рядом даже короткий штрих — изменение, а не шум.
        if not _has_words(box, gone, new, dx, dy):
            if nr + na < _len_px(MIN_REGION_MM):
                continue
            sub = changed[y0:y1, x0:x1]
            ys, xs = np.nonzero(sub)
            if len(xs) and (np.ptp(xs) <= _px(LINE_PTP_MM) or np.ptp(ys) <= _px(LINE_PTP_MM)):
                continue
            if nr + na < _len_px(NEAR_DUP_MAX_MM):
                close = int((rem[y0:y1, x0:x1] & dilate(ink_b[y0:y1, x0:x1], near)).sum()
                            + (add[y0:y1, x0:x1] & dilate(ink_a0[y0:y1, x0:x1], near)).sum())
                if close >= NEAR_DUP_SHARE * (nr + na):
                    continue
        if _moved_locally(box, rem, add, match):
            continue
        if _moved_with_labels(box, rem, add, gone, new, dx, dy, match):
            continue
        regions.append({"box": box, "rem": nr, "add": na,
                        "lines": int(rem_l[y0:y1, x0:x1].sum() + add_l[y0:y1, x0:x1].sum())})

    # Что осталось после отсева — и есть изменение листа; много и по доле,
    # и по числу областей — лист перекомпонован.
    share = sum(r["lines"] for r in regions) / (2.0 * drawn)
    if share >= REWORKED_SHARE and len(regions) > REWORKED_MIN_REGIONS:
        return {"shifts": shifts, "zones": [], "dropped_small": 0,
                "rem_a": rem_a, "add_b": add_b, "size": shape,
                "changed_share": share, "reworked": True}

    page_area = shape[0] * shape[1]
    zones = []
    for box, group in _cluster(regions, _px(ZONE_PAD_MM)):
        if _area(box) > ZONE_SPLIT_SHARE * page_area and len(group) > 1:
            for box2, group2 in _cluster(group, _px(ZONE_PAD_FINE_MM)):
                if _area(box2) > ZONE_SPLIT_SHARE * page_area and len(group2) > 1:
                    zones.extend((r["box"], [r]) for r in group2)
                else:
                    zones.append((box2, group2))
        else:
            zones.append((box, group))
    out = []
    for box, group in zones:
        if _area(box) > ZONE_DROP_SHARE * page_area:
            continue
        nr = sum(r["rem"] for r in group)
        na = sum(r["add"] for r in group)
        if nr + na < _len_px(ZONE_MIN_MM):
            continue
        out.append({"box": tuple(int(v) for v in box), "rem": nr, "add": na})
    out.sort(key=lambda z: -(z["rem"] + z["add"]))
    dropped = max(0, len(out) - MAX_ZONES)
    out = out[:MAX_ZONES]
    out.sort(key=lambda z: (z["box"][1] // _px(75.0), z["box"][0]))

    _attach_words(out, gone, new, dx, dy)
    for i, zone in enumerate(out, 1):
        zone["n"] = i
        zone["shift"] = _zone_shift(zone["box"], wa, wb, shifts)
    return {"shifts": shifts, "zones": out, "dropped_small": dropped,
            "rem_a": rem_a, "add_b": add_b, "size": shape,
            "changed_share": share, "reworked": False}


def _area(box):
    return max(0, box[2] - box[0]) * max(0, box[3] - box[1])


def _cluster(regions, pad):
    """Объединение регионов, рамки которых ближе pad, — как _cluster у
    rdgraph. Возвращает [(рамка, [регионы])]."""
    boxes = [list(r["box"]) for r in regions]
    groups = [[r] for r in regions]
    changed = True
    while changed:
        changed = False
        for i in range(len(boxes)):
            for j in range(i + 1, len(boxes)):
                a, b = boxes[i], boxes[j]
                if a[0] - pad <= b[2] and b[0] - pad <= a[2] and a[1] - pad <= b[3] and b[1] - pad <= a[3]:
                    boxes[i] = [min(a[0], b[0]), min(a[1], b[1]), max(a[2], b[2]), max(a[3], b[3])]
                    groups[i] += groups[j]
                    del boxes[j], groups[j]
                    changed = True
                    break
            if changed:
                break
    return [(tuple(b), g) for b, g in zip(boxes, groups)]


def _word_changes(wa, wb, shifts):
    """Слова, исчезнувшие из A и появившиеся в B (пословный диф с теми же
    сдвигами): (gone, new)."""
    tol = _px(2.0)
    by_b = defaultdict(list)
    by_a = defaultdict(list)
    for w in wb:
        by_b[w[6]].append(w)
    for w in wa:
        by_a[w[6]].append(w)

    def matched(word, index, sign):
        for sx, sy, _n in shifts:
            for other in index.get(word[6], ()):
                if abs(other[0] - (word[0] + sign * sx)) <= tol and \
                        abs(other[1] - (word[1] + sign * sy)) <= tol:
                    return True
        return False

    return ([w for w in wa if not matched(w, by_b, 1)],
            [w for w in wb if not matched(w, by_a, -1)])


def _has_words(box, gone, new, dx, dy):
    x0, y0, x1, y1 = box
    return (any(x0 <= w[0] + dx <= x1 and y0 <= w[1] + dy <= y1 for w in gone)
            or any(x0 <= w[0] <= x1 and y0 <= w[1] <= y1 for w in new))


def _attach_words(zones, gone, new, dx, dy):
    """Надписи, исчезнувшие и появившиеся в зоне: подсказка модели, что
    было и что стало."""
    for zone in zones:
        x0, y0, x1, y1 = zone["box"]
        zone["w_minus"] = [w[6] for w in gone if x0 <= w[0] + dx <= x1 and y0 <= w[1] + dy <= y1]
        zone["w_plus"] = [w[6] for w in new if x0 <= w[0] <= x1 and y0 <= w[1] <= y1]


def _zone_shift(box, wa, wb, shifts):
    """Сдвиг, которым зона совмещена со старой редакцией: кластер, у
    которого больше всего общих слов рядом с зоной."""
    if len(shifts) == 1:
        return shifts[0][:2]
    ua, ub = _unique(wa), _unique(wb)
    reach = _px(ZONE_PAD_MM) * 3
    x0, y0, x1, y1 = box[0] - reach, box[1] - reach, box[2] + reach, box[3] + reach
    step = max(1, _px(SHIFT_BIN_MM))
    votes = Counter()
    for text, b in ub.items():
        a = ua.get(text)
        if a is None or not (x0 <= b[0] <= x1 and y0 <= b[1] <= y1):
            continue
        for sx, sy, _n in shifts:
            if abs((b[0] - a[0]) - sx) <= 2 * step and abs((b[1] - a[1]) - sy) <= 2 * step:
                votes[(sx, sy)] += 1
    if not votes:
        return shifts[0][:2]
    return votes.most_common(1)[0][0]
