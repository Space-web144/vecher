# -*- coding: utf-8 -*-
"""
Тесты разбора имён редакций (program-b/revisions.py).

Имена взяты из присланных заказчиком комплектов — там три разных способа
записать одно и то же:

    143_23-ГК-РД-1-ПС.pdf
    143_23-ГК-РД-1-ПС изм.1.pdf
    143-23-ГК-РД-2-ОВ2_Изм2.pdf
    01-ИЖ-МСК-ПИР-2.3-2.4-Р-ВК0.1 (изм 2) от Солнышкова 03.08.2026 почта.pdf

Перепутанный порядок ревизий даёт отчёт, по которому закупят не то,
поэтому при любой неоднозначности здесь ошибка с просьбой переименовать,
а не догадка.

Запуск: python -m unittest discover -s program-b/tests -p "test_*.py"
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import revisions as m


class ParseTests(unittest.TestCase):
    def test_original_revision_has_no_marker(self):
        self.assertEqual(m.parse_revision("143_23-ГК-РД-1-ПС.pdf"),
                         ("143-23-ГК-РД-1-ПС", 0))

    def test_marker_with_dot(self):
        self.assertEqual(m.parse_revision("143_23-ГК-РД-1-ПС изм.1.pdf"),
                         ("143-23-ГК-РД-1-ПС", 1))

    def test_marker_glued_and_capitalised(self):
        self.assertEqual(m.parse_revision("143-23-ГК-РД-2-ОВ2_Изм2.pdf"),
                         ("143-23-ГК-РД-2-ОВ2", 2))

    def test_marker_in_parentheses_with_trailing_note(self):
        """Всё, что стоит после номера, к обозначению не относится."""
        name = "01-ИЖ-МСК-ПИР-2.3-2.4-Р-ВК0.1 (изм 2) от Солнышкова 03.08.2026 почта.pdf"
        self.assertEqual(m.parse_revision(name), ("01-ИЖ-МСК-ПИР-2.3-2.4-Р-ВК0.1", 2))

    def test_separators_do_not_make_a_different_set(self):
        """Один комплект присылают то через дефис, то через подчёркивание."""
        self.assertEqual(m.parse_revision("143_23-ГК-РД-1-ПС.pdf")[0],
                         m.parse_revision("143-23-ГК-РД-1-ПС изм.1.pdf")[0])

    def test_label(self):
        self.assertEqual(m.revision_label("143_23-ГК-РД-1-ПС.pdf"), "исходная редакция")
        self.assertEqual(m.revision_label("143_23-ГК-РД-1-ПС изм.2.pdf"), "изм. 2")


class OrderTests(unittest.TestCase):
    def test_orders_by_revision_number(self):
        ordered = m.order_revisions([
            "комплект изм.2.pdf", "комплект.pdf", "комплект изм.1.pdf"])
        self.assertEqual([os.path.basename(p) for p in ordered],
                         ["комплект.pdf", "комплект изм.1.pdf", "комплект изм.2.pdf"])

    def test_paths_are_kept_intact(self):
        ordered = m.order_revisions(["/данные/комплект изм.1.pdf", "/данные/комплект.pdf"])
        self.assertEqual(ordered, ["/данные/комплект.pdf", "/данные/комплект изм.1.pdf"])

    def test_four_revisions(self):
        ordered = m.order_revisions(["к изм.3.pdf", "к.pdf", "к изм.1.pdf", "к изм.2.pdf"])
        self.assertEqual([m.parse_revision(p)[1] for p in ordered], [0, 1, 2, 3])


class RefusalTests(unittest.TestCase):
    """Каждый отказ — с текстом, готовым к показу инженеру."""

    def test_single_file(self):
        with self.assertRaises(m.RevisionError) as ctx:
            m.order_revisions(["комплект.pdf"])
        self.assertIn("две редакции", str(ctx.exception))

    def test_too_many_files(self):
        with self.assertRaises(m.RevisionError) as ctx:
            m.order_revisions([f"к изм.{i}.pdf" for i in range(1, 7)])
        self.assertIn("не больше 4", str(ctx.exception))

    def test_different_sets(self):
        with self.assertRaises(m.RevisionError) as ctx:
            m.order_revisions(["01-ИЖ-МСК-ПИР-2.3-2.4-Р-ВК0.1 (изм 2).pdf",
                               "01-ИЖ-МСК-ПИР-2.3-2.4-Р-ВК0.2 (Изм 1).pdf"])
        message = str(ctx.exception)
        self.assertIn("разным комплектам", message)
        self.assertIn("ВК0.1", message)
        self.assertIn("ВК0.2", message)

    def test_two_files_with_the_same_revision_number(self):
        with self.assertRaises(m.RevisionError) as ctx:
            m.order_revisions(["комплект изм.1.pdf", "комплект_изм 1 копия.pdf"])
        self.assertIn("номером изменения 1", str(ctx.exception))

    def test_two_files_without_a_marker(self):
        """Обе без «изм.» — обе претендуют на исходную редакцию."""
        with self.assertRaises(m.RevisionError) as ctx:
            m.order_revisions(["комплект.pdf", "комплект (2).pdf"])
        self.assertIn("исходной редакцией", str(ctx.exception))


if __name__ == "__main__":
    unittest.main()
