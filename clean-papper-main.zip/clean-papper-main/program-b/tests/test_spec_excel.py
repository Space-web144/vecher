# -*- coding: utf-8 -*-
"""
Тесты Excel-отчёта сравнения спецификаций (program-b/spec_excel.py).

Главное, что здесь закреплено, — разница между нулём и пустой ячейкой.
Пакет изменений содержит только заменённые листы, поэтому отсутствие
позиции в нём сплошь и рядом означает "раздел не переиздавался", а не
"позицию исключили". Спутать эти два случая в отчёте, по которому
закупают материалы, нельзя.

Запуск: python -m unittest discover -s program-b/tests -p "test_*.py"
"""

import os
import sys
import tempfile
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from openpyxl import load_workbook

import spec_excel as m


def _row(name, qty, system="В1", type_="", unit="шт."):
    return {"name": name, "qty": qty, "system": system, "type": type_, "unit": unit}


def _build(revisions):
    path = os.path.join(tempfile.mkdtemp(prefix="spec_xlsx_"), "spec.xlsx")
    m.build_spec_workbook(revisions, path, title="Тестовое сравнение")
    return load_workbook(path)[m.SHEET_TITLE]


def _find_row(sheet, name):
    for row in sheet.iter_rows(min_row=1):
        if row[1].value == name:
            return row
    raise AssertionError("строка %r в отчёте не найдена" % name)


class QuantityParsingTests(unittest.TestCase):
    def test_decimal_comma(self):
        self.assertEqual(m._qty("4,57"), 4.57)

    def test_thousands_separator(self):
        self.assertEqual(m._qty("1 250"), 1250)

    def test_whole_number_stays_integer(self):
        self.assertEqual(m._qty("31.0"), 31)

    def test_garbage_is_not_a_quantity(self):
        self.assertIsNone(m._qty("см. примечание"))
        self.assertIsNone(m._qty(None))


class CollectPositionsTests(unittest.TestCase):
    def test_same_position_lands_in_one_row(self):
        positions, _ = m.collect_positions([
            {"label": "исх", "rows": [_row("Извещатель", 62)]},
            {"label": "изм1", "rows": [_row("Извещатель", 70)]},
        ])
        self.assertEqual(len(positions), 1)
        self.assertEqual(positions[0]["qty"], [62, 70])

    def test_repeated_rows_are_summed(self):
        """Материалы вроде утеплителя идут десятками строк с одним
        наименованием — в отчёте это одна позиция с общим количеством."""
        positions, _ = m.collect_positions([
            {"label": "исх", "rows": [_row("Труба", 10), _row("Труба", 5)]},
            {"label": "изм1", "rows": [_row("Труба", 20)]},
        ])
        self.assertEqual(positions[0]["qty"], [15, 20])

    def test_systems_are_tracked_per_revision(self):
        _, systems = m.collect_positions([
            {"label": "исх", "rows": [_row("Труба", 10, system="В1"),
                                       _row("Кран", 2, system="К1")]},
            {"label": "изм1", "rows": [_row("Труба", 12, system="В1")]},
        ])
        self.assertEqual(systems[0], {"В1", "К1"})
        self.assertEqual(systems[1], {"В1"})


class ZeroVersusBlankTests(unittest.TestCase):
    def test_missing_position_in_released_section_is_zero(self):
        """Система в редакции выпущена, а позиции в ней нет — значит её
        действительно исключили."""
        sheet = _build([
            {"label": "исх", "rows": [_row("Труба", 10, system="В1"),
                                       _row("Кран", 2, system="В1")]},
            {"label": "изм1", "rows": [_row("Труба", 12, system="В1")]},
        ])
        self.assertEqual(_find_row(sheet, "Кран")[5].value, 0)

    def test_section_not_reissued_stays_blank(self):
        """Системы в пакете изменений нет вовсе — утверждать, что позицию
        исключили, нельзя."""
        sheet = _build([
            {"label": "исх", "rows": [_row("Труба", 10, system="В1"),
                                       _row("Кран", 2, system="К1")]},
            {"label": "изм1", "rows": [_row("Труба", 12, system="В1")]},
        ])
        self.assertIsNone(_find_row(sheet, "Кран")[5].value)

    def test_legend_explains_both_cases(self):
        sheet = _build([{"label": "исх", "rows": [_row("Труба", 1)]},
                        {"label": "изм1", "rows": [_row("Труба", 1)]}])
        legend = " ".join(str(c[0].value) for c in sheet.iter_rows(min_row=1, max_row=8))
        self.assertIn("0 —", legend)
        self.assertIn("Пустая ячейка", legend)


class HighlightAndDeltaTests(unittest.TestCase):
    def test_changed_quantity_is_highlighted(self):
        sheet = _build([{"label": "исх", "rows": [_row("Труба", 10)]},
                        {"label": "изм1", "rows": [_row("Труба", 12)]}])
        row = _find_row(sheet, "Труба")
        self.assertEqual(row[4].fill.start_color.rgb[-6:], "A2DAC5")
        self.assertTrue(row[4].font.bold)

    def test_unchanged_quantity_is_not_highlighted(self):
        sheet = _build([{"label": "исх", "rows": [_row("Труба", 10)]},
                        {"label": "изм1", "rows": [_row("Труба", 10)]}])
        row = _find_row(sheet, "Труба")
        self.assertIn(row[4].fill.fill_type, (None, "none"))

    def test_delta_is_a_formula(self):
        """Формулой, а не числом: инженер правит количество руками и
        сразу видит пересчитанную разницу."""
        sheet = _build([{"label": "исх", "rows": [_row("Труба", 10)]},
                        {"label": "изм1", "rows": [_row("Труба", 12)]}])
        row = _find_row(sheet, "Труба")
        self.assertEqual(row[6].value, f"=F{row[0].row}-E{row[0].row}")

    def test_no_delta_when_a_revision_did_not_touch_the_section(self):
        sheet = _build([
            {"label": "исх", "rows": [_row("Труба", 10, system="В1"),
                                       _row("Кран", 2, system="К1")]},
            {"label": "изм1", "rows": [_row("Труба", 12, system="В1")]},
        ])
        self.assertIsNone(_find_row(sheet, "Кран")[6].value)


class LayoutTests(unittest.TestCase):
    def test_column_per_revision(self):
        sheet = _build([{"label": "исх", "rows": [_row("Труба", 1)]},
                        {"label": "изм1", "rows": [_row("Труба", 2)]},
                        {"label": "изм2", "rows": [_row("Труба", 3)]}])
        row = _find_row(sheet, "Труба")
        self.assertEqual([c.value for c in row[4:7]], [1, 2, 3])
        self.assertEqual(row[7].value, f"=G{row[0].row}-E{row[0].row}")

    def test_totals_are_formulas(self):
        sheet = _build([{"label": "исх", "rows": [_row("Труба", 10)]},
                        {"label": "изм1", "rows": [_row("Труба", 12)]}])
        texts = [str(r[0].value) for r in sheet.iter_rows(min_row=1)]
        self.assertTrue(any("Итого количество" in t for t in texts))
        formulas = [c.value for r in sheet.iter_rows(min_row=1) for c in r
                    if isinstance(c.value, str) and c.value.startswith("=SUM(")]
        self.assertTrue(formulas)

    def test_header_carries_revision_labels(self):
        sheet = _build([{"label": "исходник.pdf", "rows": [_row("Труба", 1)]},
                        {"label": "изм1.pdf", "rows": [_row("Труба", 2)]}])
        header = " ".join(str(c.value) for r in sheet.iter_rows(min_row=1) for c in r
                          if c.value and str(c.value).startswith("Проект"))
        self.assertIn("исходник.pdf", header)
        self.assertIn("изм1.pdf", header)


if __name__ == "__main__":
    unittest.main()
