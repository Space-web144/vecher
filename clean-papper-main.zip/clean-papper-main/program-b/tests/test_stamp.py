# -*- coding: utf-8 -*-
"""
Тесты разбора углового штампа (program-b/stamp.py).

Штампы для тестов рисуются здесь же, в памяти — так в наборе закреплены
ровно те ловушки, на которых разбор спотыкался на реальных комплектах
"Ижорка" (ВК) и "Коровинское шоссе" (ПС), и их не нужно тащить в
репозиторий тяжёлыми PDF:

* марка в формате другого заказчика ("01-ИЖ-..." против "143/23-ГК-...");
* марка, разбитая в PDF на несколько слов с дефисом отдельным словом;
* дата в штампе ("01.25") и номер корпуса из названия объекта ("2.3") —
  оба подходят под шаблон номера листа и стоят ближе к заголовку, чем
  настоящий номер;
* ссылка на смежный комплект в поле чертежа — похожа на марку, но стоит
  левее штампа;
* упрощённый штамп листов-продолжения (ГОСТ 21.101, форма 2а) — без
  полей "Стадия" и "Листов";
* повёрнутый лист (/Rotate 270), у которого координаты текста приходят
  в неповёрнутой системе.

Запуск: python -m unittest discover -s program-b/tests -p "test_*.py"
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import fitz

import stamp as m

_FONT_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "fonts", "DejaVuSans.ttf")

# Страница теста — альбомный лист; штамп по ГОСТ в правом нижнем углу,
# внутри зоны поиска (правее 0.55 ширины и ниже 0.70 высоты). Координаты
# задаём долями листа, а не пунктами: у повёрнутого листа page.rect
# меняет пропорции, а раскладка штампа относительно листа — нет.
_W, _H = 800.0, 600.0
_FONT_SIZE = 6


class _Sheet(object):
    """Лист с текстом, расставленным по координатам ОТОБРАЖЕНИЯ — то есть
    так, как его видит человек, открывший PDF. У повёрнутого листа они
    пересчитываются в систему хранения, как это и происходит в реальных
    файлах: внутри PDF текст лежит неповёрнутым, а /Rotate доворачивает
    его при показе."""

    def __init__(self, rotation=0):
        self.doc = fitz.open()
        self.page = self.doc.new_page(width=_W, height=_H)
        if rotation:
            self.page.set_rotation(rotation)

    def put(self, fx, fy, text):
        rect = self.page.rect
        point = fitz.Point(rect.x0 + fx * rect.width, rect.y0 + fy * rect.height)
        if self.page.rotation:
            point = point * self.page.derotation_matrix
        self.page.insert_text(point, text, fontsize=_FONT_SIZE,
                              fontname="F0", fontfile=_FONT_PATH)
        return self

    def stamp(self):
        return m.extract_stamp(self.page)

    def close(self):
        self.doc.close()


def _full_stamp(sheet, marka, sheet_no="21", total="75"):
    """Полный штамп (формы 1/2): строка заголовков и строка значений."""
    sheet.put(0.750, 0.833, marka)
    sheet.put(0.563, 0.883, "Разработал")
    sheet.put(0.625, 0.883, "Крушинская")
    sheet.put(0.700, 0.883, "10.04.26")
    sheet.put(0.800, 0.883, "Стадия")
    sheet.put(0.863, 0.883, "Лист")
    sheet.put(0.913, 0.883, "Листов")
    sheet.put(0.806, 0.917, "Р")
    if sheet_no is not None:
        sheet.put(0.864, 0.917, sheet_no)
    if total is not None:
        sheet.put(0.914, 0.917, total)
    return sheet


class MarkaTests(unittest.TestCase):
    def test_gk_format(self):
        sheet = _full_stamp(_Sheet(), "143/23-ГК-РД-1-ПС")
        try:
            self.assertEqual(sheet.stamp()["marka"], "143/23-ГК-РД-1-ПС")
        finally:
            sheet.close()

    def test_msk_format_is_not_rejected(self):
        """Формат другого заказчика: раньше отбрасывался жёстким шаблоном
        "NNN/NN-" — на комплекте "Ижорка" не читался ни один лист."""
        sheet = _full_stamp(_Sheet(), "01-ИЖ-МСК-ПИР-2.3-2.4-Р-ВК0.1")
        try:
            self.assertEqual(sheet.stamp()["marka"], "01-ИЖ-МСК-ПИР-2.3-2.4-Р-ВК0.1")
        finally:
            sheet.close()

    def test_marka_split_across_words(self):
        """В PDF обозначение нередко разбито на слова, причём дефис между
        ними — отдельное слово."""
        sheet = _Sheet()
        _full_stamp(sheet, "")
        sheet.put(0.700, 0.833, "01-ИЖ-МСК-ПИР-2.3-2.4-Р")
        sheet.put(0.790, 0.833, "-")
        sheet.put(0.795, 0.833, "ВК0.2")
        try:
            self.assertEqual(sheet.stamp()["marka"], "01-ИЖ-МСК-ПИР-2.3-2.4-Р-ВК0.2")
        finally:
            sheet.close()

    def test_cross_reference_in_drawing_ignored(self):
        """Ссылка на смежный комплект в поле чертежа похожа на марку, но
        стоит левее штампа — берём правую."""
        sheet = _full_stamp(_Sheet(), "143/23-ГК-РД-1-ПС")
        sheet.put(0.563, 0.830, "143/23-ГК-РД-0-ПС.")
        try:
            self.assertEqual(sheet.stamp()["marka"], "143/23-ГК-РД-1-ПС")
        finally:
            sheet.close()

    def test_slogan_without_digits_is_not_marka(self):
        """Строка "Архитектура.Изыскания.Проектирование" в штампе стоит
        правее марки — но это не обозначение: нет ни дефиса, ни цифр."""
        sheet = _full_stamp(_Sheet(), "143/23-ГК-РД-1-ПС")
        sheet.put(0.875, 0.950, "Архитектура.Изыскания.Проектирование")
        try:
            self.assertEqual(sheet.stamp()["marka"], "143/23-ГК-РД-1-ПС")
        finally:
            sheet.close()


class SheetNumberTests(unittest.TestCase):
    def test_plain_number(self):
        sheet = _full_stamp(_Sheet(), "143/23-ГК-РД-1-ПС", sheet_no="2", total="147")
        try:
            got = sheet.stamp()
            self.assertEqual(got["sheet_no"], "2")
            self.assertEqual(got["total_sheets"], "147")
        finally:
            sheet.close()

    def test_date_row_does_not_steal_the_number(self):
        """Строка "Проверил … 01.25" лежит ближе к заголовку, чем строка
        значений, и дата проходит под шаблон номера листа. Раньше выбор
        уходил на неё и номер листа терялся."""
        sheet = _full_stamp(_Sheet(), "143/23-ГК-РД-1-ПС", sheet_no="2")
        sheet.put(0.563, 0.903, "Проверил")
        sheet.put(0.625, 0.903, "Граков")
        sheet.put(0.700, 0.903, "01.25")
        try:
            self.assertEqual(sheet.stamp()["sheet_no"], "2")
        finally:
            sheet.close()

    def test_object_name_number_does_not_steal_the_number(self):
        """Тот же случай, но мешает номер корпуса из названия объекта."""
        sheet = _full_stamp(_Sheet(), "01-ИЖ-МСК-ПИР-2.3-2.4-Р-ВК0.1", sheet_no="21")
        sheet.put(0.569, 0.902, "Корпус")
        sheet.put(0.613, 0.902, "2.3")
        try:
            self.assertEqual(sheet.stamp()["sheet_no"], "21")
        finally:
            sheet.close()

    def test_continuation_sheet_form_2a(self):
        """Лист-продолжение: полей "Стадия"/"Листов" нет, есть только
        надпись "Лист" и номер под ней. Из-за этой формы на комплекте ПС
        читалась лишь треть листов."""
        sheet = _Sheet()
        sheet.put(0.863, 0.867, "Лист")
        sheet.put(0.750, 0.883, "143/23-ГК-РД-1-ПС.КЖ")
        sheet.put(0.864, 0.900, "6")
        sheet.put(0.563, 0.925, "Изм.")
        sheet.put(0.600, 0.925, "Кол.уч.")
        sheet.put(0.650, 0.925, "Лист")
        sheet.put(0.688, 0.925, "№док.")
        try:
            got = sheet.stamp()
            self.assertEqual(got["marka"], "143/23-ГК-РД-1-ПС.КЖ")
            self.assertEqual(got["sheet_no"], "6")
        finally:
            sheet.close()

    def test_single_sheet_document(self):
        """По ГОСТ у документа из одного листа поле "Лист" пустое, а
        "Листов" — единица."""
        sheet = _full_stamp(_Sheet(), "143/23-ГК-РД-1-ПС.Р1", sheet_no=None, total="1")
        try:
            self.assertEqual(sheet.stamp()["sheet_no"], "1")
        finally:
            sheet.close()


class RotatedPageTests(unittest.TestCase):
    def test_rotated_sheet(self):
        """/Rotate 270: координаты текста приходят в неповёрнутой системе,
        и штамп оказывается вне зоны поиска, если их не привести."""
        sheet = _full_stamp(_Sheet(rotation=270), "143/23-ГК-РД-1-ПС", sheet_no="5")
        try:
            got = sheet.stamp()
            self.assertEqual(got["marka"], "143/23-ГК-РД-1-ПС")
            self.assertEqual(got["sheet_no"], "5")
        finally:
            sheet.close()


class SheetKeyTests(unittest.TestCase):
    def test_key_needs_both_parts(self):
        self.assertIsNone(m.sheet_key({"marka": "143/23-ГК-РД-1-ПС", "sheet_no": None}))
        self.assertIsNone(m.sheet_key({"marka": None, "sheet_no": "3"}))
        self.assertEqual(
            m.sheet_key({"marka": "143/23-ГК-РД-1-ПС", "sheet_no": "3"}),
            ("143/23-ГК-РД-1-ПС", "3"))


class DocumentMarkaTests(unittest.TestCase):
    def test_suffix_of_part_does_not_split_the_set(self):
        stamps = [{"marka": "143/23-ГК-РД-1-ПС"}] * 3 + \
                 [{"marka": "143/23-ГК-РД-1-ПС.КЖ"}] * 24 + \
                 [{"marka": "143/23-ГК-РД-1-ПС.СО"}] * 2
        self.assertEqual(m.pick_document_marka(stamps), "143/23-ГК-РД-1-ПС")

    def test_dots_inside_marka_are_kept(self):
        """У "01-ИЖ-...-ВК0.1" точки свои — обрезать по первой точке, как
        по суффиксу части, нельзя."""
        stamps = [{"marka": "01-ИЖ-МСК-ПИР-2.3-2.4-Р-ВК0.1"}] * 5
        self.assertEqual(m.pick_document_marka(stamps), "01-ИЖ-МСК-ПИР-2.3-2.4-Р-ВК0.1")

    def test_stray_designation_loses_the_vote(self):
        """Случайное обозначение смежного комплекта, попавшее в штамп
        одного листа, не должно становиться маркой всего комплекта."""
        stamps = [{"marka": "143/23-ГК-РД-1-ПС"}] * 10 + [{"marka": "143/23-ГК-РД-1-ЭМ"}]
        self.assertEqual(m.pick_document_marka(stamps), "143/23-ГК-РД-1-ПС")

    def test_no_stamps_at_all(self):
        self.assertIsNone(m.pick_document_marka([{"marka": None}, {}]))


if __name__ == "__main__":
    unittest.main()
