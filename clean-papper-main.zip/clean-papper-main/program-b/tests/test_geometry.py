# -*- coding: utf-8 -*-
"""
Тесты геометрии листа (program-b/geometry.py) и обрезки вырезок
(program-b/report.py).

Главное, что здесь закреплено, — повёрнутые листы. В комплекте ПС таких
48 из 147: лист А1 лежит в файле боком, с /Rotate 270. get_text и
get_drawings отдают для него координаты в НЕповёрнутой системе, а
page.rect — уже повёрнутый. Пока геометрия не приводилась к одной
системе, вырезка "было/стало" строилась по координатам вне листа, и
сборка отчёта падала внутри MuPDF на пустой картинке.

Запуск: python -m unittest discover -s program-b/tests -p "test_*.py"
"""

import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import fitz

import geometry as g
import report as r

_FONT_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "fonts", "DejaVuSans.ttf")


def _sheet_with_text(rotation=0):
    doc = fitz.open()
    page = doc.new_page(width=800, height=600)
    if rotation:
        page.set_rotation(rotation)
    rect = page.rect
    point = fitz.Point(rect.x0 + 0.5 * rect.width, rect.y0 + 0.5 * rect.height)
    if page.rotation:
        point = point * page.derotation_matrix
    page.insert_text(point, "отметка -1.580", fontsize=8,
                     fontname="F0", fontfile=_FONT_PATH)
    return doc, page


class RotatedGeometryTests(unittest.TestCase):
    def _assert_inside_page(self, page):
        lines = g.extract_text_lines(page)
        self.assertTrue(lines, "подписи на листе не найдены")
        for line in lines:
            self.assertTrue(
                fitz.Rect(line["bbox"]).intersects(page.rect),
                "подпись %r лежит вне листа %s" % (line["bbox"], page.rect))
            for span in line["spans"]:
                self.assertTrue(fitz.Rect(span["bbox"]).intersects(page.rect))

    def test_upright_sheet(self):
        doc, page = _sheet_with_text()
        try:
            self._assert_inside_page(page)
        finally:
            doc.close()

    def test_rotated_sheet_coordinates_are_brought_to_page_rect(self):
        doc, page = _sheet_with_text(rotation=270)
        try:
            self._assert_inside_page(page)
        finally:
            doc.close()

    def test_rotated_sheet_crop_renders(self):
        """Сквозная проверка того, ради чего приведение и делалось:
        по координатам из geometry должна рисоваться вырезка."""
        doc, page = _sheet_with_text(rotation=270)
        try:
            bbox = g.extract_text_lines(page)[0]["bbox"]
            clip = r._clamped_clip(fitz.Rect(bbox), page.rect)
            self.assertIsNotNone(clip)
            pixmap = page.get_pixmap(dpi=50, clip=clip)
            self.assertTrue(pixmap.tobytes("png"))
        finally:
            doc.close()


class ClampedClipTests(unittest.TestCase):
    _PAGE = fitz.Rect(0, 0, 800, 600)

    def test_clip_inside_page_is_kept(self):
        clip = r._clamped_clip(fitz.Rect(100, 100, 200, 180), self._PAGE)
        self.assertEqual(tuple(clip), (100.0, 100.0, 200.0, 180.0))

    def test_clip_partly_outside_is_trimmed(self):
        """Находка у края листа: к её bbox добавляются поля, и вырезка
        вылезает за лист — обрезаем, а не теряем находку."""
        clip = r._clamped_clip(fitz.Rect(-40, -40, 120, 90), self._PAGE)
        self.assertEqual(tuple(clip), (0.0, 0.0, 120.0, 90.0))

    def test_clip_fully_outside_gives_none(self):
        """Именно этот случай ронял сборку отчёта: MuPDF не отдаёт пустую
        картинку, а падает."""
        self.assertIsNone(r._clamped_clip(fitz.Rect(900, 700, 1000, 800), self._PAGE))

    def test_degenerate_clip_gives_none(self):
        self.assertIsNone(r._clamped_clip(fitz.Rect(100, 100, 100.5, 180), self._PAGE))


if __name__ == "__main__":
    unittest.main()


def _cluster(n_items, bbox):
    return {"items": [{"kind": "text_changed"}] * n_items, "bbox": bbox}


class RankClustersTests(unittest.TestCase):
    """Потолок на число карточек: на реальном листе их набиралось до 216,
    и отчёт по комплекту вырастал до тысяч вырезок. Картинками показываем
    самые заметные, все находки остаются в сводной таблице."""

    def test_everything_fits_under_the_limit(self):
        clusters = [_cluster(1, (0, 0, 10, 10)) for _ in range(5)]
        self.assertEqual(r.rank_clusters(clusters, limit=12), clusters)

    def test_most_touched_findings_win(self):
        small = _cluster(1, (0, 0, 10, 10))
        big = _cluster(9, (100, 100, 140, 140))
        chosen = r.rank_clusters([small, big], limit=1)
        self.assertEqual(chosen, [big])

    def test_area_breaks_the_tie(self):
        narrow = _cluster(2, (0, 0, 10, 10))
        wide = _cluster(2, (100, 100, 400, 300))
        self.assertEqual(r.rank_clusters([narrow, wide], limit=1), [wide])

    def test_order_on_the_sheet_is_kept(self):
        """Читателю удобнее идти по листу сверху вниз, а не по убыванию
        веса находки."""
        first = _cluster(5, (0, 0, 50, 50))
        skipped = _cluster(1, (0, 60, 10, 70))
        last = _cluster(7, (0, 100, 80, 200))
        chosen = r.rank_clusters([first, skipped, last], limit=2)
        self.assertEqual(chosen, [first, last])


class ChangeCardTests(unittest.TestCase):
    """Отрисовка карточки без копирования листа на каждую находку:
    чертёж рендерится как есть, а рамки подсветки отдаются долями от
    вырезки и рисуются поверх картинки уже в отчёте."""

    def _pair(self):
        old_doc, _ = _sheet_with_text()
        new_doc, _ = _sheet_with_text()
        return old_doc, new_doc, r.SheetPair(old_doc, new_doc, 0, 0)

    def test_card_has_images_and_highlights_inside_the_crop(self):
        old_doc, new_doc, pair = self._pair()
        try:
            cluster = {"bbox": (380, 280, 420, 300),
                       "items": [{"kind": "text_changed",
                                  "old_bbox": (380, 280, 420, 300),
                                  "new_bbox": (380, 280, 420, 300),
                                  "before": "-1.580", "after": "-1.640", "repeat": 1}]}
            card = r.render_change_card(pair, cluster, (0.0, 0.0))
            self.assertIsNotNone(card)
            self.assertTrue(card["png_old"] and card["png_new"])
            self.assertTrue(card["highlights_new"])
            for x0, y0, x1, y1, color in card["highlights_new"]:
                self.assertTrue(0.0 <= x0 <= 1.0 and 0.0 <= x1 <= 1.0, (x0, x1))
                self.assertTrue(0.0 <= y0 <= 1.0 and 0.0 <= y1 <= 1.0, (y0, y1))
                self.assertEqual(len(color), 3)
        finally:
            pair.close(); old_doc.close(); new_doc.close()

    def test_card_outside_the_sheet_is_skipped(self):
        old_doc, new_doc, pair = self._pair()
        try:
            cluster = {"bbox": (5000, 5000, 5050, 5050),
                       "items": [{"kind": "text_added",
                                  "old_bbox": None,
                                  "new_bbox": (5000, 5000, 5050, 5050),
                                  "text": "новая подпись", "repeat": 1}]}
            self.assertIsNone(r.render_change_card(pair, cluster, (0.0, 0.0)))
        finally:
            pair.close(); old_doc.close(); new_doc.close()

    def test_pair_copies_each_sheet_once(self):
        """Ровно то, ради чего переделка: на паре листов — две копии,
        сколько бы карточек с неё ни рисовали."""
        old_doc, new_doc, pair = self._pair()
        try:
            self.assertEqual(pair.old_page.number, 0)
            self.assertEqual(pair.new_page.number, 0)
            self.assertEqual(pair.old_page.parent.page_count, 1)
            self.assertEqual(pair.new_page.parent.page_count, 1)
        finally:
            pair.close(); old_doc.close(); new_doc.close()


class CardBudgetTests(unittest.TestCase):
    """Общий на отчёт потолок карточек: комплект из полусотни изменённых
    листов давал 600 вырезок и отчёт на 56 МБ, чего не выдержит диск при
    хранении три месяца."""

    def test_budget_is_shared_between_sheets(self):
        budget = r.CardBudget(pairs=1, total=60, per_sheet=12)
        budget.open_pair(sheets=50)
        self.assertEqual(budget.take(), 1)

    def test_few_sheets_get_the_per_sheet_cap(self):
        budget = r.CardBudget(pairs=1, total=60, per_sheet=12)
        budget.open_pair(sheets=2)
        self.assertEqual(budget.take(), 12)

    def test_unspent_share_goes_to_later_sheets(self):
        budget = r.CardBudget(pairs=1, total=20, per_sheet=12)
        budget.open_pair(sheets=4)
        first = budget.take()          # 20 // 4 = 5
        budget.spend(1)                # лист обошёлся одной карточкой
        second = budget.take()         # 19 // 3 = 6
        self.assertEqual((first, second), (5, 6))

    def test_exhausted_budget_stops_cards(self):
        budget = r.CardBudget(pairs=1, total=3, per_sheet=12)
        budget.open_pair(sheets=3)
        budget.take()
        budget.spend(3)
        self.assertEqual(budget.take(), 0)

    def test_budget_is_split_between_revision_pairs(self):
        """Четыре ревизии — это три сравнения, и весь бюджет не должен
        уходить первому из них."""
        budget = r.CardBudget(pairs=3, total=60, per_sheet=12)
        budget.open_pair(sheets=1)
        self.assertEqual(budget.take(), 12)
        budget.spend(12)
        budget.open_pair(sheets=1)
        self.assertEqual(budget.take(), 12)
