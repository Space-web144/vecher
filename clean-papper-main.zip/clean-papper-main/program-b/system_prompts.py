# -*- coding: utf-8 -*-
"""
Промт и эталон отчёта — свои для каждого раздела проекта.

Раздел выбирает инженер при загрузке (ОВ, ВК, ЭОМ, СС — см.
VERRATA_SECTIONS в web/config.php). По нему подбирается:

* часть промта — чем в этом разделе считается изменение и какими словами
  о нём писать: у вентиляции это воздуховоды, решётки и клапаны, у
  водоснабжения — стояки, выпуски и диаметры, у электрики — щиты,
  кабельные трассы и группы;
* примеры из эталонного отчёта — образец формы, на который модель
  равняется.

Файлы лежат рядом, в program-b/prompts/: правит их технолог, не
программист, поэтому это обычные текстовые файлы, а не строки в коде.
Имя файла — код раздела латиницей (ov.md, vk.md, eom.md, ss.md) плюс
общие graphics.md (разбор листа) и graphics.summary.md (сводка по
изменению), которые подставляются всегда.
"""
import os

PROMPTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "prompts")

# Код раздела → имя файла. Кириллические коды разделов в именах файлов
# не используем: комплект выкладывается на хостинг по FTP, и там с
# кириллицей в именах бывает всякое.
SECTION_FILES = {
    "ОВ": "ov",
    "ВК": "vk",
    "ЭОМ": "eom",
    "СС": "ss",
}

# Промт разбора листа и промт сводки по изменению — общие для всех
# разделов; к ним добавляется часть раздела (словарь: что в нём
# меняется и как это называть) и примеры из эталонного отчёта.
SHEET_FILE = "graphics"
SUMMARY_FILE = "graphics.summary"
EXAMPLES_FILE = "graphics.examples"


class PromptError(Exception):
    """Промт не найден или пуст."""


def _read(name):
    path = os.path.join(PROMPTS_DIR, name)
    if not os.path.exists(path):
        return ""
    with open(path, encoding="utf-8") as handle:
        return handle.read().strip()


def known_sections():
    return sorted(SECTION_FILES)


def section_code(section):
    """Код файла по разделу; None — если раздел незнакомый."""
    if not section:
        return None
    return SECTION_FILES.get(str(section).strip().upper())


def examples(section):
    """Примеры из эталонного отчёта: свои для раздела
    (graphics.<код>.examples.md), иначе общие (graphics.examples.md —
    из эталона заказчика по ОВ)."""
    code = section_code(section)
    own = _read("graphics.%s.examples.md" % code) if code else ""
    return own or _read(EXAMPLES_FILE + ".md")


def build_prompt(section, kind="sheet"):
    """Системный промт: общая часть (разбор листа или сводка) + часть
    раздела + примеры из эталона.

    Раздел не указан или незнаком — остаётся общая часть: сравнение
    всё равно должно отработать, просто без терминов конкретного
    раздела."""
    name = SHEET_FILE if kind == "sheet" else SUMMARY_FILE
    base = _read(name + ".md")
    if not base:
        raise PromptError(
            "Не найден промт program-b/prompts/%s.md — без него модели нечего "
            "отправить." % name)
    parts = [base]
    code = section_code(section)
    special = _read(code + ".md") if code else ""
    if special:
        parts.append(special)
    sample = examples(section)
    if sample:
        parts.append(sample)
    return "\n\n".join(parts)


def describe(section):
    """Что подобралось под раздел — для журнала прогона."""
    code = section_code(section)
    if code is None:
        return "раздел не распознан, взят общий промт"
    own = _read("graphics.%s.examples.md" % code)
    return "промт: graphics.md + %s.md, примеры: %s" % (
        code, "graphics.%s.examples.md" % code if own else "graphics.examples.md (эталон ОВ)")
