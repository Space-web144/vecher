# -*- coding: utf-8 -*-
"""Сравнение листа по изображению — запасной путь для «тяжёлых» листов.

Обычное сравнение векторное: геометрия листа читается целиком в Python
(geometry.extract_elements), и на листе в несколько миллионов элементов
(схемы из AutoCAD, где текст нарисован линиями) одно это чтение съедает
больше памяти, чем хостинг даёт процессу. Такой лист раньше просто
выпадал из отчёта: «аварийное падение внутри PyMuPDF».

Отрисовка того же листа MuPDF идёт прямо в картинку, без объекта на
каждый элемент, поэтому помещается в пределы с запасом. Здесь обе
редакции рисуются целиком, вычитаются по пикселям тем же приёмом, что и
подложка карточек (report._change_masks), и места правок собираются в
зоны. Дальше зоны идут в отчёт обычным порядком — карточки рисуются
теми же функциями, что и для векторных находок.

Чего этот путь не умеет: отличить линию от надписи и трассировку от
оборудования. Поэтому зоны таких листов описаны честно — «по
изображению», без подсчёта линий.
"""
import fitz

try:
    import numpy as np
except ImportError:  # pragma: no cover - на хостинге numpy стоит
    np = None

# Длинная сторона отрисовки, пикселей. Лист А0 (3370 pt) выходит около
# 64 dpi: линия в 0.25 мм ещё видна, а картинка в оттенках серого — 7 МБ.
MAX_SIDE_PX = 3000

# Если и на это не хватает памяти, лист рисуется мельче: грубое сравнение
# лучше, чем лист, выпавший из отчёта.
FALLBACK_SIDES_PX = (3000, 2000, 1400)

# Ячейка, по которой собираются зоны, и сколько изменившихся пикселей в
# ней нужно, чтобы считать её правкой, а не соринкой сглаживания.
CELL_PT = 10.0
MIN_CELL_PX = 4

# Зазор между ячейками, при котором они ещё одна зона. Если зон выходит
# больше MAX_ZONES, зазор растёт: сотня мелких зон на одном листе — это
# перечерченный лист, и читать его удобнее крупными кусками.
GAPS_CELLS = (2, 4, 8, 16)
MAX_ZONES = 40

# Насколько лист может сдвинуться между редакциями, пунктов.
MAX_SHIFT_PT = 40.0

_INK_MAX = 215
_MATCH_PT = 1.2


class RasterUnavailable(Exception):
    """Без numpy сравнивать по изображению нечем."""


def _render(page, dpi):
    pix = page.get_pixmap(dpi=dpi, colorspace=fitz.csGRAY, alpha=False)
    arr = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.stride)
    return arr[:, :pix.width] < _INK_MAX


def _dilate(mask, radius):
    out = mask
    for axis in (0, 1):
        grown = out.copy()
        for step in range(1, radius + 1):
            head = tuple(slice(None, -step) if a == axis else slice(None) for a in (0, 1))
            tail = tuple(slice(step, None) if a == axis else slice(None) for a in (0, 1))
            grown[head] |= out[tail]
            grown[tail] |= out[head]
        out = grown
    return out


def _best_shift(old_profile, new_profile, limit):
    """Сдвиг (в пикселях), при котором профили чернил совпадают лучше
    всего: new[i] ≈ old[i - shift]."""
    old_profile = old_profile.astype(np.float64)
    new_profile = new_profile.astype(np.float64)
    n = min(len(old_profile), len(new_profile))
    old_profile, new_profile = old_profile[:n], new_profile[:n]
    best, best_score = 0, None
    for shift in range(-limit, limit + 1):
        if shift >= 0:
            score = float(np.dot(new_profile[shift:], old_profile[:n - shift]))
        else:
            score = float(np.dot(new_profile[:n + shift], old_profile[-shift:]))
        if best_score is None or score > best_score:
            best, best_score = shift, score
    return best


def _shifted(mask, dx, dy, shape):
    """mask, сдвинутый на (dx, dy) пикселей и обрезанный до shape."""
    out = np.zeros(shape, dtype=bool)
    h, w = shape
    src = mask[max(0, -dy):, max(0, -dx):]
    y0, x0 = max(0, dy), max(0, dx)
    hh = min(h - y0, src.shape[0])
    ww = min(w - x0, src.shape[1])
    if hh > 0 and ww > 0:
        out[y0:y0 + hh, x0:x0 + ww] = src[:hh, :ww]
    return out


def _cell_counts(mask, cell_px):
    h, w = mask.shape
    rows = -(-h // cell_px)
    cols = -(-w // cell_px)
    padded = np.zeros((rows * cell_px, cols * cell_px), dtype=np.uint16)
    padded[:h, :w] = mask
    return padded.reshape(rows, cell_px, cols, cell_px).sum(axis=(1, 3))


def _components(active, gap):
    """Связные группы активных ячеек; ячейки ближе gap — одна группа.
    Возвращает списки (row, col) исходных активных ячеек."""
    bridged = _dilate(active, gap) if gap else active
    seen = np.zeros(active.shape, dtype=bool)
    rows, cols = active.shape
    groups = []
    for r0, c0 in zip(*np.nonzero(active)):
        if seen[r0, c0]:
            continue
        stack = [(r0, c0)]
        seen[r0, c0] = True
        cells = []
        while stack:
            r, c = stack.pop()
            if active[r, c]:
                cells.append((r, c))
            for nr in (r - 1, r, r + 1):
                for nc in (c - 1, c, c + 1):
                    if 0 <= nr < rows and 0 <= nc < cols and not seen[nr, nc] \
                            and bridged[nr, nc]:
                        seen[nr, nc] = True
                        stack.append((nr, nc))
        if cells:
            groups.append(cells)
    return groups


def sheet_zones(old_page, new_page, ignore=(), max_side_px=MAX_SIDE_PX):
    """Зоны правок листа по изображению.

    ignore — прямоугольники в координатах новой редакции, которые в
    сравнение не идут (штамп). Возвращает (зоны, сдвиг): зона —
    словарь в том же виде, что кластер векторных находок (bbox в пунктах
    новой редакции, пустые items), с пометкой "raster": сколько
    пикселей исчезло и сколько появилось. Сдвиг (dx, dy) в пунктах —
    как diff["offset"]: точка старой редакции = точка новой − сдвиг."""
    if np is None:
        raise RasterUnavailable("нет numpy")
    side = max(new_page.rect.width, new_page.rect.height, 1.0)
    dpi = max(24, int(72.0 * max_side_px / side))
    scale = dpi / 72.0

    ink_old = _render(old_page, dpi)
    ink_new = _render(new_page, dpi)
    shape = ink_new.shape

    limit = int(MAX_SHIFT_PT * scale)
    dx = _best_shift(ink_old.sum(axis=0), ink_new.sum(axis=0), limit)
    dy = _best_shift(ink_old.sum(axis=1), ink_new.sum(axis=1), limit)
    ink_old = _shifted(ink_old, dx, dy, shape)

    match = max(1, int(round(_MATCH_PT * scale)))
    removed = ink_old & ~_dilate(ink_new, match)
    added = ink_new & ~_dilate(ink_old, match)
    del ink_old, ink_new

    for rect in ignore:
        x0, y0, x1, y1 = (int(v * scale) for v in tuple(rect)[:4])
        removed[max(0, y0):max(0, y1), max(0, x0):max(0, x1)] = False
        added[max(0, y0):max(0, y1), max(0, x0):max(0, x1)] = False

    cell_px = max(2, int(round(CELL_PT * scale)))
    removed_cells = _cell_counts(removed, cell_px)
    added_cells = _cell_counts(added, cell_px)
    del removed, added
    active = (removed_cells + added_cells) >= MIN_CELL_PX

    groups = []
    for gap in GAPS_CELLS:
        groups = _components(active, gap)
        if len(groups) <= MAX_ZONES:
            break

    cell_pt = cell_px / scale
    page_w, page_h = new_page.rect.width, new_page.rect.height
    zones = []
    for cells in groups:
        rs = [r for r, _c in cells]
        cs = [c for _r, c in cells]
        bbox = (min(cs) * cell_pt, min(rs) * cell_pt,
                min(page_w, (max(cs) + 1) * cell_pt), min(page_h, (max(rs) + 1) * cell_pt))
        zones.append({
            "bbox": bbox,
            "items": [],
            "labels": [],
            "raster": {
                "removed": int(sum(removed_cells[r, c] for r, c in cells)),
                "added": int(sum(added_cells[r, c] for r, c in cells)),
            },
        })
    return zones, (dx / scale, dy / scale)


def sheet_zones_within_memory(old_page, new_page, ignore=()):
    """sheet_zones, при нехватке памяти — с меньшим разрешением."""
    for side in FALLBACK_SIDES_PX[:-1]:
        try:
            return sheet_zones(old_page, new_page, ignore=ignore, max_side_px=side)
        except MemoryError:
            pass
    return sheet_zones(old_page, new_page, ignore=ignore, max_side_px=FALLBACK_SIDES_PX[-1])


def zone_weight(zone):
    """Вес зоны для отбора под карточки: сколько изменилось и где."""
    x0, y0, x1, y1 = zone["bbox"]
    changed = zone["raster"]["removed"] + zone["raster"]["added"]
    return (changed, (x1 - x0) * (y1 - y0))
