# -*- coding: utf-8 -*-
"""
Книга сравнения спецификаций в формате эталона раздела ОВ.

Эталон прислал заказчик (сравнение 143-23-ГК-РД-1-ОВ2: первоначальная
редакция → Изм.1 → Изм.2), и он отличается от общего формата
(spec_excel.py, собран по эталонам «Коровинское шоссе» и «Ижорка»):

* таблица начинается с первой строки — вся легенда на своём листе
  «Легенда», а не над таблицей;
* колонок дельт нет: что изменилось, видно по заливке, и заливка своя
  у каждого перехода — зелёная, если количество в изм.1 отличается от
  первоначальной редакции, сиреневая — если в изм.2 отличается от изм.1;
* порядок строк — по первоначальной редакции, а новые позиции стоят в
  фактическом месте документа, после ближайшей общей позиции, а не в
  конце таблицы;
* сопоставление по ключу «система + наименование + тип, марка +
  ед. изм.» с нормализацией регистра, ё/е, х/x и пробелов;
* одна позиция с разной полнотой графы «Тип, марка» в разных редакциях
  (пусто → «ОБМ-5ф») сводится в одну строку, если варианты не
  встречаются в одной редакции вместе, — и перечисляется на листе
  «Слияния».

Смысл нуля и пустой ячейки тот же, что в общем формате: 0 — позиция
исключена (система в редакции есть), пусто — системы в редакции нет.
"""
import re

from openpyxl import Workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side

from spec_excel import COMMENTS_TITLE, REVIEW_MARK

SHEET_TITLE = "Сравнение СО"
LEGEND_TITLE = "Легенда"
MERGES_TITLE = "Слияния"

FIXED_COLUMNS = ("Название системы", "Наименование материала", "Размерность",
                 "Тип, марка и обозначение")
# Ширины — как в эталоне.
_FIXED_WIDTHS = (9.6, 110, 12, 52)
_REVISION_WIDTH = 26

_HEADER_FILL = PatternFill("solid", fgColor="263C5C")
_HEADER_FONT = Font(bold=True, color="FFFFFF", size=10)
# Заливка по переходам: первый — зелёная, второй — сиреневая (из эталона);
# третий переход (четыре редакции) эталон не показывает — жёлтая.
TRANSITION_FILLS = ("A2DAC5", "DCC6F0", "FFE699")
TRANSITION_NAMES = ("Зелёная", "Сиреневая", "Жёлтая")

_THIN = Side(style="thin", color="BFBFBF")
_BORDER = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)


# --------------------------------------------------------------------------
# Сопоставление
# --------------------------------------------------------------------------

def _norm(text):
    """Нормализация для ключа: регистр, ё/е, латинская x и кириллическая х
    (в размерах «300х200» пишут обе), пробелы."""
    text = str(text or "").lower().replace("ё", "е").replace("x", "х")
    return " ".join(text.split())


def _qty(value):
    if value is None or value == "":
        return None
    if isinstance(value, (int, float)):
        return value
    text = str(value).strip().replace(" ", "").replace(" ", "").replace(",", ".")
    try:
        number = float(text)
    except ValueError:
        return None
    return int(number) if number == int(number) else number


def _round(value):
    if value is None or isinstance(value, int):
        return value
    value = round(value, 3)
    return int(value) if value == int(value) else value


def _clean(text):
    return " ".join(str(text or "").split())


def system_code(row):
    """Код системы для колонки «Название системы»: «В2.1 — Вентиляция
    общеобменная» → «В2.1». В эталоне колонка узкая и в ней только код;
    полное название инженер видит в самой спецификации."""
    return _clean(str(row.get("system") or "").split(" — ")[0])


def _unit(row):
    """Единица без точки на конце: «м.» и «м» — одна единица."""
    return _clean(row.get("unit")).rstrip(".")


def position_key(row):
    """Ключ позиции: система + наименование + тип, марка + ед. изм."""
    return (_norm(system_code(row)), _norm(row.get("name")),
            _norm(row.get("type")), _norm(_unit(row)))


def collect_positions(revisions):
    """Позиции всех редакций в одну таблицу — в порядке документа.

    Порядок задаёт первая редакция; позиция, которой в ней нет, ставится
    после ближайшей общей позиции той редакции, где она появилась, — то
    есть туда, где она стоит в документе, а не в конец таблицы (правило
    эталона «Порядок строк»).

    Одинаковый ключ внутри одной редакции (один и тот же воздуховод в
    одной системе несколькими строками — разные участки) — это разные
    строки спецификации, и сводить их нельзя: они сопоставляются по
    порядку появления, первая с первой."""
    count = len(revisions)
    entries = {}         # (ключ, номер повтора) -> позиция
    order = []
    systems = [set() for _ in revisions]

    for index, revision in enumerate(revisions):
        seen = {}
        anchor = -1          # позиция в order, после которой вставлять новое
        for row in revision.get("rows") or ():
            key = position_key(row)
            nth = seen.get(key, 0)
            seen[key] = nth + 1
            ident = (key, nth)
            systems[index].add(_norm(system_code(row)))
            entry = entries.get(ident)
            if entry is None:
                entry = {"ident": ident, "system": system_code(row),
                         "name": _clean(row.get("name")), "unit": _unit(row),
                         "type": _clean(row.get("type")), "types": [None] * count,
                         "qty": [None] * count}
                entries[ident] = entry
                order.insert(anchor + 1, ident)
                anchor += 1
            else:
                anchor = order.index(ident)
            value = _qty(row.get("qty"))
            if value is not None:
                entry["qty"][index] = (entry["qty"][index] or 0) + value
            entry["types"][index] = _clean(row.get("type"))
    positions = [entries[ident] for ident in order]
    for entry in positions:
        entry["qty"] = [_round(v) for v in entry["qty"]]
    return positions, systems


def merge_type_variants(positions, count):
    """Сводит варианты одной позиции, которые отличаются только полнотой
    графы «Тип, марка» (пусто в одной редакции, «ОБМ-5ф» в другой).

    Сводятся только варианты, которые НЕ встречаются в одной редакции
    вместе: если в какой-то редакции есть оба — это две разные позиции, и
    сводить их было бы ошибкой.

    Возвращает (позиции, слияния); слияние — строка для листа «Слияния»."""
    groups = {}
    for entry in positions:
        system, name, _type, unit = entry["ident"][0]
        groups.setdefault((system, name, unit, entry["ident"][1]), []).append(entry)

    place = {id(entry): index for index, entry in enumerate(positions)}
    merged_away = set()
    merges = []
    for group in groups.values():
        if len(group) < 2:
            continue
        typed = [e for e in group if e["type"]]
        empty = [e for e in group if not e["type"]]
        if len(typed) != 1 or len(empty) != 1:
            continue
        full, bare = typed[0], empty[0]
        if any(full["qty"][i] is not None and bare["qty"][i] is not None
               for i in range(count)):
            continue
        # Сводная строка встаёт на место того варианта, что раньше в
        # документе, а «Тип, марка» берёт полный.
        keep, drop = (full, bare) if place[id(full)] < place[id(bare)] else (bare, full)
        for i in range(count):
            if keep["qty"][i] is None and drop["qty"][i] is not None:
                keep["qty"][i] = drop["qty"][i]
            if keep["types"][i] is None and drop["types"][i] is not None:
                keep["types"][i] = drop["types"][i]
        keep["type"] = full["type"]
        merged_away.add(id(drop))
        merges.append(keep)

    kept = [entry for entry in positions if id(entry) not in merged_away]
    return kept, merges


# --------------------------------------------------------------------------
# Книга
# --------------------------------------------------------------------------

def _cell_value(entry, index, systems):
    value = entry["qty"][index]
    if value is not None:
        return value
    return 0 if _norm(entry["system"]) in systems[index] else None


def _revision_header(revision):
    """«143-23-ГК-РД-1-ОВ2 Изм.1\\n(изм.1, кол-во)» — как в эталоне:
    документ и роль редакции."""
    document = revision.get("document") or revision.get("note") or ""
    document = re.sub(r"\.pdf$", "", str(document), flags=re.IGNORECASE)
    role = str(revision.get("label") or "редакция")
    return f"{document}\n({role}, кол-во)" if document else f"{role}\n(кол-во)"


def build(revisions, output_path, legend=None):
    """Книга в формате эталона ОВ. legend — что известно о комплекте и
    редакциях, для листа «Легенда» (см. compare.spec_legend)."""
    count = len(revisions)
    positions, systems = collect_positions(revisions)
    positions, merges = merge_type_variants(positions, count)

    workbook = Workbook()
    sheet = workbook.active
    sheet.title = SHEET_TITLE

    headers = list(FIXED_COLUMNS) + [_revision_header(r) for r in revisions]
    for column, text in enumerate(headers, start=1):
        cell = sheet.cell(row=1, column=column, value=text)
        cell.fill = _HEADER_FILL
        cell.font = _HEADER_FONT
        cell.alignment = Alignment(wrap_text=True, vertical="center", horizontal="center")
        cell.border = _BORDER
    sheet.row_dimensions[1].height = 46

    changed = [0] * count
    fills = [PatternFill("solid", fgColor=c) for c in TRANSITION_FILLS]
    for offset, entry in enumerate(positions):
        row = 2 + offset
        for column, value in enumerate((entry["system"], entry["name"], entry["unit"],
                                         entry["type"]), start=1):
            cell = sheet.cell(row=row, column=column, value=value)
            cell.alignment = Alignment(wrap_text=True, vertical="top")
            cell.border = _BORDER
        values = [_cell_value(entry, i, systems) for i in range(count)]
        for i, value in enumerate(values):
            cell = sheet.cell(row=row, column=len(FIXED_COLUMNS) + 1 + i, value=value)
            cell.border = _BORDER
            cell.alignment = Alignment(horizontal="right", vertical="top")
            # Заливка по переходу: колонка редакции красится, если её
            # количество отличается от предыдущей. Пустая ячейка с любой
            # стороны — системы в редакции нет, это не изменение.
            if i > 0 and value is not None and values[i - 1] is not None \
                    and value != values[i - 1]:
                cell.fill = fills[min(i - 1, len(fills) - 1)]
                changed[i] += 1

    last = len(positions) + 1
    # Области не закрепляются — как в отчёте ВК (просьба заказчика).
    if positions:
        sheet.auto_filter.ref = f"A1:{sheet.cell(row=1, column=len(headers)).column_letter}{last}"
    widths = list(_FIXED_WIDTHS) + [_REVISION_WIDTH] * count
    for index, width in enumerate(widths, start=1):
        sheet.column_dimensions[sheet.cell(row=1, column=index).column_letter].width = width

    _write_legend(workbook, revisions, legend or {}, positions, merges, changed, systems)
    _write_merges(workbook, revisions, merges)
    workbook.save(output_path)
    return {"rows": len(positions), "changed": changed, "merges": len(merges)}


def _write_legend(workbook, revisions, legend, positions, merges, changed, systems):
    sheet = workbook.create_sheet(LEGEND_TITLE)
    rows = []
    if legend.get("object"):
        rows.append(("Объект", legend["object"]))
    if legend.get("section"):
        rows.append(("Раздел", legend["section"]))
    infos = list(legend.get("revisions") or ())
    infos += [{}] * (len(revisions) - len(infos))
    for index, (revision, info) in enumerate(zip(revisions, infos)):
        parts = [revision.get("note") or ""]
        if info.get("pages"):
            parts[0] += f" — {info['pages']} стр."
        if info.get("permit"):
            parts.append("разрешение " + info["permit"])
        if info.get("spec_pages"):
            parts.append("СО листы PDF " + info["spec_pages"])
        parts.append(f"{sum(1 for p in positions if p['qty'][index] is not None)} позиций")
        rows.append((str(revision.get("label") or "").capitalize(), ", ".join(p for p in parts if p)))
    rows.append(("", ""))
    for i in range(1, len(revisions)):
        name = TRANSITION_NAMES[min(i - 1, len(TRANSITION_NAMES) - 1)]
        rows.append((f"{name} заливка",
                     f"кол-во в {revisions[i].get('label')} отличается от "
                     f"{revisions[i - 1].get('label')}"))
    rows.append(("0", "позиция исключена из редакции (система в редакции есть)"))
    rows.append(("Пусто", "системы нет в этой редакции"))
    rows.append(("Порядок строк", "по первой редакции; новые позиции вставлены в фактическое "
                                  "место документа (после ближайшей общей позиции), не в конец"))
    rows.append(("Сопоставление", "по ключу: система + наименование + тип/марка + ед. изм. "
                                  "(нормализация регистра, ё/е, х/x, пробелов)"))
    rows.append(("Слияния вариантов",
                 f"{len(merges)} строк: одна позиция с разной полнотой графы «Тип, марка» в "
                 "разных редакциях (напр. пусто → «ОБМ-5ф»), варианты не сосуществуют в "
                 "одной редакции; см. лист «Слияния»" if merges else "нет"))
    new_systems = []
    for i in range(1, len(revisions)):
        for system in sorted(systems[i] - set().union(*systems[:i])):
            if system:
                shown = next((p["system"] for p in positions if _norm(p["system"]) == system), system)
                new_systems.append(f"{shown} — с {revisions[i].get('label')}")
    if new_systems:
        rows.append(("Новые системы", "; ".join(new_systems)))
    for note in legend.get("verification") or ():
        rows.append(("Верификация", note))
    totals = f"строк всего {len(positions)}"
    for i in range(1, len(revisions)):
        totals += f"; изменено в {revisions[i].get('label')}: {changed[i]}"
    rows.append(("Итог изменений", totals))
    notes = list(legend.get("notes") or ())
    for note in notes:
        if REVIEW_MARK not in note:
            rows.append(("Примечание", note))
    # Предположения «Требует проверки инженером» (возможные
    # переименования позиций, их бывает по нескольку десятков) — как в
    # отчёте ВК: под заголовком COMMENTS_TITLE, свёрнутой группой.
    review = [note for note in notes if REVIEW_MARK in note]
    if review:
        rows.append((COMMENTS_TITLE, None))
        rows.extend(("", note) for note in review)

    heading_row = None
    for row, (label, text) in enumerate(rows, start=1):
        a = sheet.cell(row=row, column=1, value=label or None)
        a.font = Font(bold=True)
        a.alignment = Alignment(vertical="top")
        b = sheet.cell(row=row, column=2, value=text or None)
        b.alignment = Alignment(wrap_text=True, vertical="top")
        if label == COMMENTS_TITLE:
            heading_row = row
        elif heading_row is not None:
            sheet.row_dimensions[row].outlineLevel = 1
            sheet.row_dimensions[row].hidden = True
    if heading_row is not None:
        sheet.row_dimensions[heading_row].collapsed = True
        sheet.sheet_properties.outlinePr.summaryBelow = False
        sheet.sheet_format.outlineLevelRow = 1
    sheet.column_dimensions["A"].width = 26
    sheet.column_dimensions["B"].width = 140


def _write_merges(workbook, revisions, merges):
    sheet = workbook.create_sheet(MERGES_TITLE)
    labels = [str(r.get("label") or "") for r in revisions]
    headers = (["Система", "Наименование", "Тип, марка: " + " → ".join(labels)]
               + [f"Кол-во {label}" for label in labels])
    for column, text in enumerate(headers, start=1):
        cell = sheet.cell(row=1, column=column, value=text)
        cell.fill = _HEADER_FILL
        cell.font = _HEADER_FONT
        cell.alignment = Alignment(wrap_text=True, vertical="center")
    for row, entry in enumerate(merges, start=2):
        types = " → ".join(t if t else "(пусто)" for t in
                           [t if t is not None else "—" for t in entry["types"]])
        values = [entry["system"], entry["name"], types] + list(entry["qty"])
        for column, value in enumerate(values, start=1):
            sheet.cell(row=row, column=column, value=value)
    for column, width in zip("ABCDEFG", (12, 80, 60, 14, 14, 14, 14)):
        sheet.column_dimensions[column].width = width
