# -*- coding: utf-8 -*-
"""
Приёмочный гейт спецификации: тройная проверка «число ↔ наименование».

Разбор таблицы может ошибиться молча, и это опаснее любой явной ошибки:
непрочитанная позиция выглядит в отчёте как исключённая из спецификации, а
по готовому файлу одно от другого не отличить. Так и случилось на ПС изм.1
— 27 позиций из 46, и 32 позиции были помечены как исключённые, хотя их
просто не прочитали.

Поэтому результат проверяется НЕЗАВИСИМЫМ контуром: он читает страницу
словами с координатами, минуя табличный разбор, и сверяет три вещи по
каждой странице каждой редакции:

  A. счёт и сумма  — сколько чисел в полосе «Кол.» и какова их сумма
                     против позиций разбора (Δ счёта = 0, |Δ суммы| ≤ 0,005);
  B. порядок       — последовательность чисел сверху вниз против
                     последовательности позиций (полное совпадение);
  C. близость имени — слова полосы «Наименование» в окне ±11 pt от числа
                     входят в наименование позиции (доля ≥ 50% на строку).

Проверка A одна ловит недобор позиций, но не ловит сдвиг: если разбор
прочитал все числа, но приклеил их к чужим наименованиям, счёт и сумма
сойдутся. Это и проверяют B и C.

Фильтры служебных строк обязаны быть СИММЕТРИЧНЫ фильтрам разбора, иначе
контур начинает спорить с разбором о мусоре, а не о данных. Обратная
сторона симметрии: одинаковый мусор по обе стороны проходит гейт
насквозь (строка нумерации граф «1 2 … 9» давала «позицию» со значением
7, и независимый счёт её подтверждал). Поэтому каждый сработавший фильтр
попадает в протокол прогона — молчаливая фильтрация запрещена.

Срез по вертикали делается только по доказанным зонам штампа
(stamp.stamp_zones), а не числом: таблица на реальных листах доходит до
y≈790 pt, и «на глаз» выбранная граница срезает последние позиции.
"""
import collections
import difflib
import os
import re
import sys

import fitz

from stamp import page_words, stamp_zones, in_zones

_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
_PROGRAM_A = os.path.join(_REPO_ROOT, "program-a")
for _path in (_REPO_ROOT, _PROGRAM_A):
    if _path not in sys.path:
        sys.path.insert(0, _path)

from pdf_to_spec import (  # noqa: E402
    _PAGE_KEY, extract_spec_rows, select_template)

# Допуски §7. Это не «примерно столько»: цифры взяты из принятых прогонов
# и любое расхождение разбирается до нуля, а не списывается на допуск.
SUM_TOLERANCE = 0.005
NAME_WINDOW_PT = 11.0
NAME_MIN_SHARE = 0.5
NAME_MIN_WORD_LEN = 3

# Строка одной высоты: слова одной строки таблицы отклоняются от её
# середины на единицы pt, а соседние строки отстоят минимум на ~8 pt.
_LINE_TOL_PT = 3.0
# Насколько далеко от числа может стоять наименование его позиции. У
# позиции с переносом количество печатается между строками наименования,
# поэтому «на той же строке» мало — нужен шаг строки. Зато дальше этого
# наименования нет вовсе, и число позицией не является: так в полосу «Кол.»
# попадала «6» из адреса объекта в штампе («земельный участок 6»), которую
# доказанная зона штампа не захватывает — она начинается ниже.
# Порог выбран по замеру, а не на глаз: по семи альбомам ВСЕ законные
# числа стоят не дальше 20 pt от наименования (у позиций с переносом — до
# 20, у остальных до 6), а единственное мусорное — «6» из адреса объекта —
# в 78,3 pt. Двадцать четыре лежат с запасом по обе стороны.
_NAME_NEAR_PT = 24.0

_NUMBER_RE = re.compile(r"^-?\d+(?:[.,]\d+)?$")
_DIGITS_ONLY_RE = re.compile(r"^\d$")
# Отметка «Корпус X.Y» штампа: сама по себе она занимает полосу имени
# целиком и ничего кроме номера корпуса не содержит. Проверять вхождение
# слова нельзя — «Корпус металлический с монтажной панелью» и «Фланец для
# корпусов ST» это позиции, а не отметки, и такой фильтр выбрасывал 17
# законных позиций в двух альбомах, не поймав при этом ни одной отметки:
# настоящую снимают раньше доказанные зоны штампа (stamp.stamp_zones).
_CORPUS_RE = re.compile(r"^корпус\.?\s*\d+(?:[.,]\d+)*$", re.IGNORECASE)


def _to_float(text):
    try:
        return float(str(text).replace(",", ".").replace(" ", ""))
    except (TypeError, ValueError):
        return None


def _band(words, bounds, column):
    """Слова полосы графы.

    У ГОСТ-шаблона границы заданы тройкой: первый элемент говорит, по
    какому краю слова решать — количества в нём выровнены по правому краю
    ("x1"), остальные графы по левому. Без этого контур падал на таком
    альбоме целиком, то есть не проверял ровно тот комплект (ПС изм.1),
    из-за которого гейт и появился.
    """
    spec = bounds[column]
    if len(spec) == 3:
        coord, x0, x1 = spec
        edge = (lambda w: w[0]) if coord == "x0" else (lambda w: w[2])
    else:
        x0, x1 = spec
        edge = lambda w: (w[0] + w[2]) / 2.0        # noqa: E731
    return [w for w in words if x0 <= edge(w) < x1]


def _lines(words):
    """Слова по строкам: {середина строки: [слова]}, отсортировано по y."""
    buckets = collections.defaultdict(list)
    for word in words:
        buckets[round((word[1] + word[3]) / 2.0 / _LINE_TOL_PT)].append(word)
    return [(key * _LINE_TOL_PT, sorted(group, key=lambda w: w[0]))
            for key, group in sorted(buckets.items())]


def _page_quantities(page, bounds, notes):
    """[(y, количество)] полосы «Кол.» одной страницы — независимо от разбора.

    notes — список, куда дописываются сработавшие фильтры: гейт обязан
    объяснять, что он выбросил и почему.
    """
    zones = stamp_zones(page)
    words = [w for w in page_words(page) if not in_zones(w[:4], zones)]
    qty_words = _band(words, bounds, "QTY")
    name_words = _band(words, bounds, "NAME")
    unit_words = _band(words, bounds, "UNIT")
    out = []
    for y, group in _lines(qty_words):
        numbers = [w for w in group if _NUMBER_RE.match(w[4].strip())]
        if not numbers:
            continue
        line_names = [w for w in name_words if abs((w[1] + w[3]) / 2.0 - y) <= _LINE_TOL_PT]
        line_units = [w for w in unit_words if abs((w[1] + w[3]) / 2.0 - y) <= _LINE_TOL_PT]
        # Строка нумерации граф «1 2 … 9»: в полосе имени и единицы стоят
        # одиночные цифры, а не текст.
        neighbours = line_names + line_units
        if neighbours and all(_DIGITS_ONLY_RE.match(w[4].strip()) for w in neighbours):
            notes.append("строка нумерации граф")
            continue
        name_text = " ".join(w[4] for w in sorted(line_names, key=lambda w: w[0])).strip()
        if _CORPUS_RE.match(name_text):
            notes.append("отметка «Корпус» штампа")
            continue
        # У числа обязано быть наименование — своё или перенесённой строки
        # позиции. Нет наименования в пределах шага строки — это не
        # позиция, а надпись штампа или рамки.
        near = [w for w in name_words
                if abs((w[1] + w[3]) / 2.0 - y) <= _NAME_NEAR_PT]
        if not near:
            notes.append("число без наименования (надпись штампа или рамки)")
            continue
        # Сдвоенное количество «площадь / масса» при слэш-единице: берётся
        # второе число (ведомость расхода материалов, см. §5 документа).
        if len(numbers) > 1 and any("/" in w[4] for w in line_units):
            notes.append("сдвоенное количество «площадь / масса» → масса")
            value = _to_float(numbers[-1][4])
        else:
            value = _to_float(numbers[0][4])
        if value is None:
            continue
        out.append((y, value, line_names))
    return out


def _name_share(line_names, row_text):
    """Доля слов полосы имени (длиннее трёх знаков), вошедших в позицию."""
    words = [w[4].strip(" .,:;") for w in line_names
             if len(w[4].strip(" .,:;")) > NAME_MIN_WORD_LEN]
    if not words:
        return None
    target = row_text.lower()
    hits = sum(1 for word in words if word.lower() in target)
    return hits / len(words)


def _row_text(row):
    return " ".join(str(row.get(key) or "") for key in ("NAME", "TYPE", "CODE"))


def expected_numbers(doc, bounds):
    """Все числа полосы «Кол.» документа в порядке чтения + протокол фильтров.

    Последовательность сквозная, а не постраничная. Постраничное
    сравнение ломается на позиции, переходящей через границу листов:
    разбор закрывает её на следующей странице, а число напечатано на
    предыдущей, и обе страницы расходятся на единицу при полностью
    верном разборе (проверено на 108-1123: все 22 листа «не прошли»
    именно так, хотя разбор верен).
    """
    out, notes = [], []
    for index in range(len(doc)):
        page_notes = []
        for y, value, names in _page_quantities(doc[index], bounds, page_notes):
            out.append({"page": index + 1, "y": y, "value": value, "names": names})
        for note in sorted(set(page_notes)):
            notes.append({"page": index + 1, "filter": note})
    return out, notes


def _token(value):
    return f"{round(float(value), 3):g}"


def _divergences(expected, parsed):
    """Расхождения двух последовательностей количеств — и где именно.

    difflib, а не поэлементное сравнение: нужно не «совпало/нет», а место
    и вид расхождения, иначе одна пропущенная позиция делает «неверными»
    все следующие за ней.
    """
    left = [_token(item["value"]) for item in expected]
    right = [_token(qty) for _row, qty in parsed]
    matcher = difflib.SequenceMatcher(a=left, b=right, autojunk=False)
    diffs, equal = [], []
    for tag, i1, i2, j1, j2 in matcher.get_opcodes():
        if tag == "equal":
            equal.extend(zip(range(i1, i2), range(j1, j2)))
            continue
        pages = sorted({item["page"] for item in expected[i1:i2]}) or \
            sorted({row.get(_PAGE_KEY, 0) + 1 for row, _q in parsed[j1:j2]})
        diffs.append({
            "kind": {"replace": "подменено", "delete": "не прочитано",
                     "insert": "лишнее"}[tag],
            "pages": pages,
            "on_sheet": [item["value"] for item in expected[i1:i2]][:6],
            "in_report": [qty for _row, qty in parsed[j1:j2]][:6],
            "names": [str(row.get("NAME") or "")[:48] for row, _q in parsed[j1:j2]][:6],
        })
    return diffs, equal


def verify_spec(pdf_path, rows=None):
    """Протокол гейта по файлу спецификации: три проверки §7.

    rows — уже разобранные позиции (с ключом страницы). Если не переданы,
    разбирается тот же файл: проверка обязана смотреть ровно на тот
    результат, который пойдёт в отчёт, а не на пересобранный заново.
    """
    doc = fitz.open(pdf_path)
    if rows is None:
        rows, _rotated, _gost = extract_spec_rows(pdf_path)
    bounds, _extract, _rotated, _gost, _tail = select_template(doc)

    expected, filters = expected_numbers(doc, bounds)
    parsed = [(row, _to_float(row.get("QTY"))) for row in rows]
    parsed = [(row, qty) for row, qty in parsed if qty is not None]

    count_delta = len(parsed) - len(expected)
    sum_delta = round(sum(q for _r, q in parsed)
                      - sum(item["value"] for item in expected), 4)
    diffs, equal = _divergences(expected, parsed)

    name_fails = []
    for i, j in equal:
        share = _name_share(expected[i]["names"], _row_text(parsed[j][0]))
        if share is not None and share < NAME_MIN_SHARE:
            name_fails.append({
                "page": expected[i]["page"],
                "name": str(parsed[j][0].get("NAME") or "")[:48],
                "share": round(share, 2),
                "words": [w[4] for w in expected[i]["names"]][:8],
            })

    pages_bad = sorted({page for d in diffs for page in d["pages"]}
                       | {f["page"] for f in name_fails})
    checks = {
        "A_count_and_sum": count_delta == 0 and abs(sum_delta) <= SUM_TOLERANCE,
        "B_order": not diffs,
        "C_name": not name_fails,
    }
    ok = all(checks.values())
    return {
        "file": os.path.basename(pdf_path),
        "pages_total": len(doc),
        "positions_parsed": len(parsed),
        "numbers_on_sheets": len(expected),
        "count_delta": count_delta,
        "sum_delta": sum_delta,
        "checks": checks,
        "divergences": diffs,
        "name_fails": name_fails,
        "filters": filters,
        "pages_failed": pages_bad,
        "ok": ok,
        "verdict": "0/0/0" if ok else "/".join(
            "0" if checks[key] else "✗"
            for key in ("A_count_and_sum", "B_order", "C_name")),
    }


def filters_note(protocol):
    """Какие служебные строки гейт выбросил — или None, если ни одной.

    Отдельно от вердикта: фильтр срабатывает и на пройденном гейте, и это
    всё равно допущение, которое инженер вправе знать. Молчаливая
    фильтрация запрещена — одинаковый мусор по обе стороны проходит
    проверку насквозь, и единственный его след это вот этот список.
    """
    if not protocol.get("filters"):
        return None
    by_filter = collections.defaultdict(list)
    for item in protocol["filters"]:
        by_filter[item["filter"]].append(item["page"])
    total = protocol.get("pages_total") or 0
    parts = []
    for name, pages in sorted(by_filter.items()):
        # Шапка таблицы с нумерацией граф стоит на КАЖДОМ листе
        # спецификации, и перечисление всех страниц ничего не говорит —
        # важно только то, что строка отброшена везде.
        if total and len(set(pages)) >= total:
            parts.append(f"{name} (на всех листах)")
            continue
        unique = sorted(set(pages))
        shown = ", ".join(str(p) for p in unique[:6])
        if len(unique) > 6:
            shown += f" и ещё {len(unique) - 6}"
        parts.append(f"{name} (стр. {shown})")
    return (f"Принятые допущения при разборе «{protocol['file']}»: "
            + "; ".join(parts)
            + ". Эти строки в количества не включены.")


def gate_verdict(protocol):
    """Вердикт гейта для пакета фактов — компактно, для агента.

    Агент пишет резюме поверх посчитанных чисел и обязан знать, сведены
    они с листами или нет: «количество выросло на 27» про альбом с
    непройденной проверкой читается как установленный факт, которым оно не
    является. Расхождения идут образцом, а не списком: полный перечень
    инженер видит в шапке книги, а резюме нужен характер расхождения.
    """
    return {
        "file": protocol.get("file", ""),
        "verdict": protocol.get("verdict", ""),
        "reconciled": bool(protocol.get("ok")),
        "positions_in_report": protocol.get("positions_parsed"),
        "numbers_on_sheets": protocol.get("numbers_on_sheets"),
        "sum_delta": protocol.get("sum_delta"),
        "divergences_total": len(protocol.get("divergences") or ()),
        "divergences_sample": [
            {"pages": d.get("pages"), "kind": d.get("kind"),
             "on_sheet": d.get("on_sheet"), "in_report": d.get("in_report")}
            for d in (protocol.get("divergences") or ())[:3]
        ],
    }


def gate_note(protocol):
    """Текст для отчёта — или None, если гейт пройден."""
    if protocol.get("ok"):
        return None
    parts = []
    if protocol["count_delta"]:
        parts.append(f"позиций в отчёте {protocol['positions_parsed']}, "
                     f"чисел на листах {protocol['numbers_on_sheets']}")
    if abs(protocol["sum_delta"]) > SUM_TOLERANCE:
        parts.append(f"сумма расходится на {protocol['sum_delta']:g}")
    for d in protocol["divergences"][:3]:
        pages = ", ".join(str(p) for p in d["pages"])
        parts.append(f"стр. {pages}: {d['kind']} — на листах {d['on_sheet']}, "
                     f"в отчёте {d['in_report']}")
    if protocol["name_fails"]:
        first = protocol["name_fails"][0]
        parts.append(f"наименование не подтверждено у {len(protocol['name_fails'])} "
                     f"позиций (стр. {first['page']}: «{first['name']}»)")
    return (f"Внимание: проверка спецификации «{protocol['file']}» не пройдена "
            f"({protocol['verdict']}). " + "; ".join(parts)
            + ". Непрочитанные позиции выглядят в таблице как исключённые из "
              "спецификации — сверьте их по исходному PDF, прежде чем "
              "пользоваться отчётом.")
