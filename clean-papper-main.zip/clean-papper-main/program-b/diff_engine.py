# -*- coding: utf-8 -*-
"""
Сравнение двух версий листа (список текстовых подписей + векторных
путей от geometry.py) с допуском на технический "люфт" — небольшой
сдвиг всего листа между экспортами (единицы pt), который не должен
считаться изменением (см. обсуждение с заказчиком: "съехавшая картинка
на несколько пикселей — не изменение").

Порядок:
1. Регистрация (выравнивание) — по подписям, которые совпадают текстом
   и стоят близко на обеих версиях, считаем медианный сдвиг (dx, dy) и
   переносим им координаты старой версии. Медиана, а не среднее — чтобы
   единичные настоящие изменения (переместившийся текст) не тянули
   оценку сдвига на себя.
2. Сопоставление после выравнивания — по допуску TOLERANCE_PT: рядом и
   с тем же содержимым — не изменилось; рядом, но с другим текстом —
   изменено (это и случай высотных отметок: то же место, другое
   значение); без пары в одной из версий — добавлено/удалено.
"""
import difflib
from collections import defaultdict

# Допуск после выравнивания — во сколько pt считаем позицию "той же".
# Калибровано на паре реальных листов (изм.1 лист 1 / изм.2 лист 1, тот
# же типоразмер А1) — подобрать позже точнее не проблема, тут не жёстко
# зашитая правда, а параметр вызова.
DEFAULT_TOLERANCE_PT = 3.0

# Пути (линии чертежа) — отдельный, более широкий допуск, чем у текста.
# У длинной линии (воздуховод через весь чертёж) даже небольшая разница
# в угле между двумя экспортами того же чертежа даёт заметную абсолютную
# разницу координат конца линии, хотя сама трасса не менялась — при
# допуске текста (3pt) это массово ложно засчитывалось как "изменение".
DEFAULT_PATH_TOLERANCE_PT = 8.0

# Максимальное расстояние для поиска "якорных" пар при оценке сдвига —
# больше, чем сам допуск, с большим запасом на случай реального небольшого
# смещения листа целиком (не только под-pt дрожание рендера).
_ANCHOR_MAX_DIST = 40.0


def _center(bbox):
    return ((bbox[0] + bbox[2]) / 2.0, (bbox[1] + bbox[3]) / 2.0)


def _dist(a, b):
    return ((a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2) ** 0.5


def estimate_offset(old_texts, new_texts, max_dist=_ANCHOR_MAX_DIST):
    """Медианный сдвиг (dx, dy) старой версии относительно новой, по
    подписям с идентичным текстом, стоящим близко друг к другу."""
    by_text = defaultdict(list)
    for t in new_texts:
        by_text[t["text"]].append(t)

    dxs, dys = [], []
    for old in old_texts:
        candidates = by_text.get(old["text"])
        if not candidates:
            continue
        oc = _center(old["bbox"])
        best, best_d = None, None
        for cand in candidates:
            cc = _center(cand["bbox"])
            d = _dist(oc, cc)
            if d <= max_dist and (best_d is None or d < best_d):
                best, best_d = cand, d
        if best is not None:
            nc = _center(best["bbox"])
            dxs.append(nc[0] - oc[0])
            dys.append(nc[1] - oc[1])

    if not dxs:
        return 0.0, 0.0
    dxs.sort()
    dys.sort()
    n = len(dxs)
    return dxs[n // 2], dys[n // 2]


def _shift_bbox(bbox, dx, dy):
    return (bbox[0] + dx, bbox[1] + dy, bbox[2] + dx, bbox[3] + dy)


def _grid_key(point, cell):
    return (int(point[0] // cell), int(point[1] // cell))


def _top_left(bbox):
    return (bbox[0], bbox[1])


def _nearest_match(old_items, new_items, tol, point_fn=_center):
    """Общий "жадный ближайший сосед" по опорной точке bbox (центр — для
    отдельных подписей/путей; левый верхний угол — для целых строк
    текста, у которых вставка в середину меняет ширину и уводит центр,
    хотя сама строка не сдвигалась, см. point_fn=_top_left в вызовах
    ниже) в пределах допуска, через grid-корзины (иначе на тысячах
    путей на лист — квадратичный перебор). Возвращает список пар
    (old_item|None, new_item|None) — None с одной из сторон значит "нет
    пары" (добавлено/удалено)."""
    cell = max(tol * 2, 4.0)
    buckets = defaultdict(list)
    for j, item in enumerate(new_items):
        buckets[_grid_key(point_fn(item["bbox"]), cell)].append(j)

    matched_new = set()
    pairs = []
    for old in old_items:
        op = point_fn(old["bbox"])
        gk = _grid_key(op, cell)
        best_j, best_d = None, None
        for gx in (gk[0] - 1, gk[0], gk[0] + 1):
            for gy in (gk[1] - 1, gk[1], gk[1] + 1):
                for j in buckets.get((gx, gy), ()):
                    if j in matched_new:
                        continue
                    d = _dist(op, point_fn(new_items[j]["bbox"]))
                    if d <= tol and (best_d is None or d < best_d):
                        best_j, best_d = j, d
        if best_j is not None:
            matched_new.add(best_j)
            pairs.append((old, new_items[best_j]))
        else:
            pairs.append((old, None))

    for j, item in enumerate(new_items):
        if j not in matched_new:
            pairs.append((None, item))
    return pairs


def diff_text_lines(old_lines, new_lines, dx, dy, tol=DEFAULT_TOLERANCE_PT):
    """Сравнение подписей на уровне строк (а не отдельных фрагментов по
    отдельности) — построчная привязка по позиции, а *внутри* строки
    сравнение через посимвольный/пофрагментный sequence-diff (как в
    difflib), а не независимое сопоставление каждого фрагмента по
    координатам.

    Это важно: если в середину строки вписали новую подпись, все
    фрагменты после неё физически сдвигаются вправо. При независимом
    позиционном сравнении это давало десятки ложных "изменено" на ровном
    месте (см. калибровку на реальном листе). Sequence-diff корректно
    находит ровно то, что вставили, а "хвост" строки, пусть и физически
    сдвинутый, распознаёт как тот же самый неизменный текст."""
    shifted_old = [{"bbox": _shift_bbox(ln["bbox"], dx, dy), "spans": ln["spans"]} for ln in old_lines]
    pairs = _nearest_match(shifted_old, new_lines, tol=max(tol * 4, 12.0), point_fn=_top_left)

    added, removed, changed, unchanged = [], [], [], []
    idx = 0
    for old_line, new_line in pairs:
        if old_line is not None and new_line is None:
            merged = _merge_spans(old_lines[idx]["spans"])
            if merged:
                removed.append(merged)
            idx += 1
        elif old_line is not None and new_line is not None:
            _diff_line_spans(old_lines[idx]["spans"], new_line["spans"],
                              added, removed, changed, unchanged)
            idx += 1
        else:
            merged = _merge_spans(new_line["spans"])
            if merged:
                added.append(merged)
    return {"added": added, "removed": removed, "changed": changed, "unchanged": unchanged}


def _merge_spans(spans):
    """Склеивает несколько фрагментов одной правки (например, вставка
    сразу нескольких слов подряд в середину строки — см. diff_text_lines)
    в одну цельную находку: один читаемый текст + общий bbox, а не кучу
    самостоятельных обрывков. Без этого при группировке по кластерам
    (report.build_change_items) несвязанные фрагменты из одного кластера
    склеивались наивным join() в нечитаемую кашу из символов."""
    if not spans:
        return None
    if len(spans) == 1:
        return spans[0]
    text = "".join(s["text"] for s in spans)
    x0 = min(s["bbox"][0] for s in spans)
    y0 = min(s["bbox"][1] for s in spans)
    x1 = max(s["bbox"][2] for s in spans)
    y1 = max(s["bbox"][3] for s in spans)
    return {"text": text, "bbox": (x0, y0, x1, y1)}


def _same_text(old_span, new_span):
    """Один и тот же текст с точностью до пробелов.

    Пробелы сравнивать нельзя вовсе, а не только схлопывать их:
    экспортёр PDF режет строку по начертаниям и кернингу, и пробел между
    словами то попадает во фрагмент, то исчезает. Заказчик прислал
    карточку «НЕвАВТОМАТИЧЕСКОМрежимедвигательПДлифта» → «НЕ в
    АВТОМАТИЧЕСКОМ режиме двигатель ПД лифта»: это один и тот же текст,
    а прежнее сравнение (схлопывание пробелов) считало его изменённым,
    потому что в старой редакции пробелов не было ни одного."""
    if old_span is None or new_span is None:
        return False
    return "".join(old_span["text"].split()) == "".join(new_span["text"].split())


def _diff_line_spans(old_spans, new_spans, added, removed, changed, unchanged):
    old_texts = [s["text"] for s in old_spans]
    new_texts = [s["text"] for s in new_spans]
    sm = difflib.SequenceMatcher(None, old_texts, new_texts, autojunk=False)
    for tag, i1, i2, j1, j2 in sm.get_opcodes():
        if tag == "equal":
            for i, j in zip(range(i1, i2), range(j1, j2)):
                unchanged.append((old_spans[i], new_spans[j]))
        elif tag == "replace":
            old_merged = _merge_spans(old_spans[i1:i2])
            new_merged = _merge_spans(new_spans[j1:j2])
            if _same_text(old_merged, new_merged):
                # Текст тот же, изменилось только его разбиение на
                # фрагменты: экспортёр PDF режет строку по начертаниям и
                # кернингу, и между редакциями режет по-разному
                # (["С", "/у"] против ["С/у"]). difflib сравнивает списки
                # фрагментов и видит замену там, где подпись не менялась.
                # На реальной паре редакций это давало 39% всех находок
                # вида "изменён текст" — «Изменено: «С/у» → «С/у»» по 144
                # раза на лист, при медианном смещении 0.7 pt.
                unchanged.append((old_merged, new_merged))
            else:
                changed.append((old_merged, new_merged))
        elif tag == "delete":
            merged = _merge_spans(old_spans[i1:i2])
            if merged:
                removed.append(merged)
        elif tag == "insert":
            merged = _merge_spans(new_spans[j1:j2])
            if merged:
                added.append(merged)


def diff_paths(old_paths, new_paths, dx, dy, tol=DEFAULT_TOLERANCE_PT):
    """Пути сравниваются строже, чем текст — не только центр, но и весь
    bbox (все 4 координаты) в пределах допуска, иначе перетрассированная
    линия с тем же центром, но другой формой/протяжённостью, ложно
    считалась бы неизменившейся."""
    shifted_old = [{"bbox": _shift_bbox(p["bbox"], dx, dy)} for p in old_paths]

    cell = max(tol * 2, 4.0)
    buckets = defaultdict(list)
    for j, item in enumerate(new_paths):
        buckets[_grid_key(_center(item["bbox"]), cell)].append(j)

    matched_new = set()
    added, removed = [], []
    for i, old in enumerate(shifted_old):
        oc = _center(old["bbox"])
        gk = _grid_key(oc, cell)
        best_j, best_d = None, None
        for gx in (gk[0] - 1, gk[0], gk[0] + 1):
            for gy in (gk[1] - 1, gk[1], gk[1] + 1):
                for j in buckets.get((gx, gy), ()):
                    if j in matched_new:
                        continue
                    nb = new_paths[j]["bbox"]
                    ob = old["bbox"]
                    max_delta = max(abs(ob[0] - nb[0]), abs(ob[1] - nb[1]),
                                     abs(ob[2] - nb[2]), abs(ob[3] - nb[3]))
                    if max_delta <= tol and (best_d is None or max_delta < best_d):
                        best_j, best_d = j, max_delta
        if best_j is not None:
            matched_new.add(best_j)
        else:
            removed.append(old_paths[i])

    for j, item in enumerate(new_paths):
        if j not in matched_new:
            added.append(item)

    return {"added": added, "removed": removed}


def _cancel_relocated(added, removed, key_fn):
    """Если один и тот же объект (по key_fn) нашёлся и среди "добавленных",
    и среди "удалённых" — значит он просто переехал в пределах листа, а
    не появился/исчез. По требованию заказчика такое не считается
    изменением: "если объект просто поменял своё местоположение... это
    не считается изменением". Возвращает (added_kept, removed_kept,
    relocated_pairs) — relocated_pairs пригодится, если понадобится
    показать перемещения отдельно, сейчас в отчёт не идут."""
    removed_by_key = defaultdict(list)
    for r in removed:
        removed_by_key[key_fn(r)].append(r)

    kept_added = []
    relocated = []
    for a in added:
        k = key_fn(a)
        bucket = removed_by_key.get(k)
        if bucket:
            relocated.append((bucket.pop(0), a))
        else:
            kept_added.append(a)

    kept_removed = [r for bucket in removed_by_key.values() for r in bucket]
    return kept_added, kept_removed, relocated


# Сдвиг части листа. Бывает, что между редакциями переставлен не весь
# лист, а его часть: на ВК 89_21 (изм. 1 → изм. 2) план на листе 14
# переехал внутри рамки на ~180 pt, а рамка и таблица справа остались
# на месте. Общий сдвиг по подписям — это сдвиг рамки, и весь план
# выходил «удалённым и нарисованным заново»: 427 зон на одном листе.
#
# Поэтому после общего совмещения среди оставшихся «удалённых» и
# «добавленных» подписей ищется ещё один общий сдвиг: одинаковые
# подписи, разнесённые на одно и то же расстояние. Если таких набирается
# достаточно, это сдвинутый фрагмент листа, и его элементы
# сопоставляются уже с этим сдвигом. Переставленный фрагмент изменением
# не считается — так же, как переместившийся объект.
_SHIFT_MAX_PT = 2000.0
_SHIFT_BIN_PT = 2.0
_SHIFT_MIN_ANCHORS = 6
_SHIFT_MIN_PATHS = 20
_SHIFT_MAX_EXTRA = 3
# Подпись, встречающаяся на листе чаще, в голосовании за сдвиг не
# участвует: «с1.5» в таблице повторяется десятки раз и дала бы десятки
# ложных сдвигов.
_SHIFT_MAX_REPEATS = 3


def _norm_text(text):
    return "".join(str(text).split())


def _shift_mode(old_spans, new_spans):
    """Самый частый сдвиг между одинаковыми подписями двух наборов и число
    подписей, которые за него «голосуют», либо None."""
    by_text = defaultdict(list)
    for span in new_spans:
        by_text[_norm_text(span["text"])].append(span)
    old_count = defaultdict(int)
    for span in old_spans:
        old_count[_norm_text(span["text"])] += 1

    votes = defaultdict(list)
    for old in old_spans:
        key = _norm_text(old["text"])
        cands = by_text.get(key)
        if not key or not cands or len(cands) > _SHIFT_MAX_REPEATS \
                or old_count[key] > _SHIFT_MAX_REPEATS:
            continue
        oc = _center(old["bbox"])
        for cand in cands:
            cc = _center(cand["bbox"])
            ddx, ddy = cc[0] - oc[0], cc[1] - oc[1]
            if abs(ddx) > _SHIFT_MAX_PT or abs(ddy) > _SHIFT_MAX_PT:
                continue
            votes[(round(ddx / _SHIFT_BIN_PT), round(ddy / _SHIFT_BIN_PT))].append((ddx, ddy))
    if not votes:
        return None
    # Голоса соседних корзин складываются: сдвиг 179.9 и 180.1 — один сдвиг.
    best = []
    for (kx, ky) in votes:
        pooled = [v for nx in (kx - 1, kx, kx + 1) for ny in (ky - 1, ky, ky + 1)
                  for v in votes.get((nx, ny), ())]
        if len(pooled) > len(best):
            best = pooled
    if len(best) < _SHIFT_MIN_ANCHORS:
        return None
    xs = sorted(v[0] for v in best)
    ys = sorted(v[1] for v in best)
    return (xs[len(xs) // 2], ys[len(ys) // 2]), len(best)


def _bbox_union(boxes):
    boxes = list(boxes)
    if not boxes:
        return None
    return (min(b[0] for b in boxes), min(b[1] for b in boxes),
            max(b[2] for b in boxes), max(b[3] for b in boxes))


def _inside(point, region):
    return (region is not None and region[0] <= point[0] <= region[2]
            and region[1] <= point[1] <= region[3])


def _match_spans(old_spans, new_spans, dx, dy, tol):
    """Одинаковые подписи, совпавшие со сдвигом (dx, dy): возвращает
    (оставшиеся старые, оставшиеся новые)."""
    shifted = [{"bbox": _shift_bbox(s["bbox"], dx, dy), "text": s["text"], "_src": s}
               for s in old_spans]
    pairs = _nearest_match(shifted, new_spans, tol)
    left_old, left_new = [], []
    for old, new in pairs:
        if old is not None and new is not None and _norm_text(old["text"]) == _norm_text(new["text"]):
            continue
        if old is not None:
            left_old.append(old["_src"])
        if new is not None:
            left_new.append(new)
    return left_old, left_new


def _shifted_fragments(text_diff, path_diff, primary, tol, path_tol):
    """Ищет сдвинутые фрагменты листа и снимает их элементы из
    добавленных/удалённых (см. _SHIFT_MAX_PT). Меняет text_diff и
    path_diff на месте и возвращает список фрагментов:
    [{"offset": (dx, dy), "old_region": bbox, "new_region": bbox}]."""
    shifts = []
    for _ in range(_SHIFT_MAX_EXTRA):
        old_pool = list(text_diff["removed"]) + [o for o, _n in text_diff["changed"]]
        new_pool = list(text_diff["added"]) + [n for _o, n in text_diff["changed"]]
        mode = _shift_mode(old_pool, new_pool)
        if mode is None:
            break
        (bx, by), _votes = mode
        if any(_dist((bx, by), sh["offset"]) <= path_tol
               for sh in shifts + [{"offset": primary}]):
            break
        removed_paths = path_diff["removed"]
        moved = diff_paths(removed_paths, path_diff["added"], bx, by, path_tol)
        kept_ids = set(id(p) for p in moved["removed"])
        matched_old = [p for p in removed_paths if id(p) not in kept_ids]
        if len(matched_old) < _SHIFT_MIN_PATHS:
            break
        old_region = _bbox_union(p["bbox"] for p in matched_old)
        new_region = _shift_bbox(old_region, bx, by)
        path_diff["removed"], path_diff["added"] = moved["removed"], moved["added"]

        # Подписи фрагмента: «изменённые» пары внутри него — это подписи,
        # случайно сведённые общим совмещением с чужими; разбираем их
        # обратно и сопоставляем уже со сдвигом фрагмента.
        kept_changed, old_spans, new_spans = [], list(text_diff["removed"]), list(text_diff["added"])
        for old_span, new_span in text_diff["changed"]:
            if _inside(_center(old_span["bbox"]), old_region):
                old_spans.append(old_span)
                new_spans.append(new_span)
            else:
                kept_changed.append((old_span, new_span))
        left_old, left_new = _match_spans(old_spans, new_spans, bx, by, max(tol * 4, 12.0))
        text_diff["changed"] = kept_changed
        text_diff["removed"], text_diff["added"] = left_old, left_new
        shifts.append({"offset": (bx, by), "old_region": old_region, "new_region": new_region})
    return shifts


def offset_at(diff, bbox):
    """Сдвиг, которым место bbox (координаты новой редакции) совмещено со
    старой: сдвиг фрагмента, если место внутри сдвинутого фрагмента
    листа, иначе общий."""
    point = _center(bbox)
    for shift in diff.get("shifts") or ():
        if _inside(point, shift["new_region"]):
            return shift["offset"]
    return diff["offset"]


def old_offset_at(diff, old_bbox):
    """То же для места в координатах СТАРОЙ редакции."""
    point = _center(old_bbox)
    for shift in diff.get("shifts") or ():
        if _inside(point, shift["old_region"]):
            return shift["offset"]
    return diff["offset"]


def diff_elements(old_elements, new_elements, tol=DEFAULT_TOLERANCE_PT, path_tol=DEFAULT_PATH_TOLERANCE_PT):
    """Полное сравнение листа: считает сдвиг по подписям и сравнивает и
    подписи, и векторные пути с этой поправкой. Затем ищет сдвинутые
    внутри листа фрагменты (см. _shifted_fragments)."""
    dx, dy = estimate_offset(old_elements["texts"], new_elements["texts"])
    text_diff = diff_text_lines(old_elements["lines"], new_elements["lines"], dx, dy, tol)
    path_diff = diff_paths(old_elements["paths"], new_elements["paths"], dx, dy, path_tol)
    shifts = _shifted_fragments(text_diff, path_diff, (dx, dy), tol, path_tol)

    text_diff["added"], text_diff["removed"], text_diff["relocated"] = _cancel_relocated(
        text_diff["added"], text_diff["removed"], key_fn=lambda t: t["text"])

    def _path_shape_key(p):
        # Округление до целого, не до 0.1pt: длинная линия (воздуховод
        # через весь чертёж) от экспорта к экспорту может чуть менять
        # длину/угол на суб-пиксельном уровне без реального изменения
        # трассы — при более точном округлении такие пары не считались
        # "тем же объектом, просто съехавшим" и раздували число находок.
        b = p["bbox"]
        return (round(b[2] - b[0]), round(b[3] - b[1]))

    path_diff["added"], path_diff["removed"], path_diff["relocated"] = _cancel_relocated(
        path_diff["added"], path_diff["removed"], key_fn=_path_shape_key)

    return {"offset": (dx, dy), "shifts": shifts, "texts": text_diff, "paths": path_diff}


def has_changes(diff):
    """Есть ли вообще расхождения между версиями листа — включая
    текстовые. В отчёт текстовые не идут (см. report.build_change_items),
    но для служебных решений («лист вообще трогали?») предикат нужен."""
    t, p = diff["texts"], diff["paths"]
    return bool(t["added"] or t["removed"] or t["changed"] or p["added"] or p["removed"])


def has_graphic_changes(diff):
    """Изменился ли сам чертёж — трассировка или оборудование. Именно
    это считается изменением листа в отчёте: правка подписи без правки
    геометрии изменением чертежа не считается (требование заказчика)."""
    p = diff["paths"]
    return bool(p["added"] or p["removed"])
