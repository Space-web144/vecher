# -*- coding: utf-8 -*-
"""
Порядок редакций по именам файлов и проверка, что загружено одно и то же.

Инженер загружает от двух до четырёх PDF одного комплекта: исходную
редакцию и пакеты изменений. Порядок определяется именем файла — так
решил заказчик, и это разумно: другого надёжного источника нет. Дата
файла врёт (пакеты пересылают почтой, даты переписываются), номер
изменения в штампе есть не на всех листах, а на сканах его нет вовсе.

Правило: файл без пометки "изм." — исходная редакция, дальше по
возрастанию номера изменения. Всё, что стоит в имени после номера
("от Солнышкова 03.08.2026 почта"), к делу не относится и отбрасывается.

Любое несоответствие — не повод гадать. Перепутанные ревизии дают отчёт,
по которому закупят не то, поэтому здесь ошибка с просьбой переименовать,
а не догадка: текст сообщения пишется сразу для показа пользователю.
"""
import os
import re

MIN_REVISIONS = 2
MAX_REVISIONS = 4

# "изм 1", "изм.1", "Изм2", "(изм 2)", "_ИЗМ.3" — разделитель между словом
# и номером любой (или его нет вовсе), регистр любой.
_REVISION_RE = re.compile(r"изм\.?\s*[№#]?\s*(\d{1,2})", re.IGNORECASE | re.UNICODE)

# Хвост имени, который не относится к обозначению комплекта: скобки,
# подчёркивания, пробелы и знаки препинания по краям.
_TRIM = " _-—–.,;()[]{}«»\"'\t"

# Пометка копии, которую дописывают браузер и проводник: "(1)", "(2)",
# "копия", "- copy". К обозначению комплекта она не относится, а без её
# отбрасывания две копии одного файла объявлялись бы разными комплектами
# вместо честного "обе претендуют на исходную редакцию".
_COPY_SUFFIX_RE = re.compile(
    r"(\s*\(\s*\d{1,2}\s*\)|\s*[-–—]?\s*(копия|copy))\s*$", re.IGNORECASE | re.UNICODE)


class RevisionError(ValueError):
    """Ошибка разбора имён с текстом, готовым к показу пользователю."""


def parse_revision(path):
    """(базовое имя комплекта, номер изменения) из имени файла.

    Исходная редакция — номер 0: она "нулевая" по журналу изменений
    штампа, и это ставит её первой при обычной сортировке.
    """
    name = os.path.splitext(os.path.basename(path))[0]
    match = _REVISION_RE.search(name)
    if match is None:
        return _normalize_base(name), 0
    return _normalize_base(name[:match.start()]), int(match.group(1))


def _normalize_base(text):
    """Обозначение комплекта в сравнимом виде.

    Пробелы схлопываем, регистр не учитываем, а "-", "_" и пробел между
    группами считаем одним и тем же разделителем: один и тот же комплект
    в разных редакциях присылают то как "143_23-ГК-РД-1-ПС", то как
    "143-23-ГК-РД-1-ПС". Отвергать такую пару как "разные проекты" —
    придирка, из-за которой инженер будет переименовывать файлы вручную.
    """
    cleaned = " ".join(str(text).split())
    previous = None
    while previous != cleaned:
        previous = cleaned
        cleaned = _COPY_SUFFIX_RE.sub("", cleaned).strip()
    cleaned = cleaned.strip(_TRIM)
    cleaned = re.sub(r"[\s_]+", "-", cleaned)
    cleaned = re.sub(r"-+", "-", cleaned)
    return cleaned.strip("-").upper()


def display_base(path):
    """Обозначение комплекта как оно написано в имени файла — для
    сообщений пользователю: нормализованный вид ему ни о чём не говорит."""
    name = os.path.splitext(os.path.basename(path))[0]
    match = _REVISION_RE.search(name)
    if match is not None:
        name = name[:match.start()]
    return " ".join(name.split()).strip(_TRIM)


def order_revisions(paths, minimum=MIN_REVISIONS):
    """Файлы в порядке редакций: исходная, затем пакеты изменений.

    Бросает RevisionError с текстом для пользователя, если по именам
    нельзя однозначно выстроить цепочку.
    """
    paths = list(paths)
    if len(paths) < minimum:
        raise RevisionError(
            "Нужно загрузить хотя бы две редакции: исходную и пакет изменений.")
    if len(paths) > MAX_REVISIONS:
        raise RevisionError(
            f"За один раз сравниваются не больше {MAX_REVISIONS} редакций, "
            f"загружено {len(paths)}.")

    parsed = [(path,) + parse_revision(path) for path in paths]

    bases = {base for _path, base, _no in parsed}
    if len(bases) > 1:
        names = ", ".join(sorted("«%s»" % display_base(p) for p, _b, _n in parsed))
        raise RevisionError(
            "Файлы относятся к разным комплектам: " + names + ". "
            "Загрузите редакции одного комплекта — обозначение в именах "
            "файлов должно совпадать, различаться должна только пометка "
            "«изм.»")

    by_number = {}
    for path, _base, number in parsed:
        by_number.setdefault(number, []).append(path)
    for number, group in sorted(by_number.items()):
        if len(group) > 1:
            names = ", ".join("«%s»" % os.path.basename(p) for p in sorted(group))
            what = ("без пометки «изм.» — значит, обе считаются исходной редакцией"
                    if number == 0 else f"с одним и тем же номером изменения {number}")
            raise RevisionError(
                f"Загружены два файла {what}: {names}. "
                "Уточните нумерацию в именах файлов.")

    return [path for path, _base, _number in sorted(parsed, key=lambda item: item[2])]


def apply_roles(paths, roles):
    """Пути в порядке РОЛЕЙ, подтверждённых инженером.

    Имя файла — догадка, и документ заказчика прямо называет её ненадёжной
    («имена врут: Copy, (1), даты выгрузки»). Поэтому инженеру показывается
    карточка «Что я нашёл», и его решение побеждает имя. Проверки здесь те
    же, что у разбора имён: роль не может достаться двум файлам, и нельзя
    подтвердить роль файла, которого нет в задаче — перепутанные роли дают
    отчёт, по которому закупят не то.

    roles — {имя файла: номер изменения}, 0 — исходная редакция.
    """
    paths = list(paths)
    unknown = sorted(set(roles) - {os.path.basename(p) for p in paths})
    if unknown:
        raise RevisionError(
            "Подтверждены роли файлов, которых нет в задаче: "
            + ", ".join("«%s»" % name for name in unknown) + ".")
    missing = sorted(os.path.basename(p) for p in paths
                     if os.path.basename(p) not in roles)
    if missing:
        raise RevisionError(
            "Не указаны роли для файлов: "
            + ", ".join("«%s»" % name for name in missing) + ".")
    by_number = {}
    for path in paths:
        by_number.setdefault(roles[os.path.basename(path)], []).append(path)
    for number, group in sorted(by_number.items()):
        if len(group) > 1:
            names = ", ".join("«%s»" % os.path.basename(p) for p in sorted(group))
            what = ("исходной редакцией" if number == 0
                    else f"изменением {number}")
            raise RevisionError(
                f"Два файла отмечены как {what}: {names}. "
                "У каждой редакции должна быть своя роль.")
    return [path for path in sorted(paths, key=lambda p: roles[os.path.basename(p)])]


def revision_label(path, roles=None):
    """Подпись редакции для отчёта: «исходная редакция» или «изм. N».

    roles — подтверждённые инженером роли ({имя файла: номер}); с ними
    подпись берётся из них, а не из имени файла."""
    if roles and os.path.basename(path) in roles:
        number = roles[os.path.basename(path)]
    else:
        _base, number = parse_revision(path)
    return "исходная редакция" if number == 0 else f"изм. {number}"
