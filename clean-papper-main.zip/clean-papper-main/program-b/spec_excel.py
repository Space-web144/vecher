# -*- coding: utf-8 -*-
"""
Excel-отчёт сравнения спецификаций между ревизиями.

Формат собран по двум эталонным отчётам заказчика ("Коровинское шоссе" —
две редакции, "Ижорка" — три): таблица позиций, по колонке на редакцию,
дельта между первой и последней, подсветка изменившихся значений и блок
итогов формулами (не числами — инженер должен видеть, как они получены,
и иметь возможность пересчитать после ручной правки).

Отдельного внимания стоит РАЗНИЦА между нулём и пустой ячейкой, она взята
из эталона и отражает реальность пакетов изменений:

    0            — позиция в этой редакции отсутствует, хотя раздел
                   спецификации в ней выпущен (реально исключена/добавлена);
    пусто        — раздела в этой редакции нет вовсе, изменение его не
                   затрагивало. Утверждать "исключено" тут нельзя.

Пакет изменений содержит только заменённые листы, поэтому второй случай —
не редкость, а норма, и путать его с исключением позиции недопустимо: по
такому отчёту закупают материалы.
"""
import re

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

SHEET_TITLE = "Сравнение СО"

# Цвета из эталонных отчётов заказчика.
_HEADER_FILL = PatternFill("solid", fgColor="263C5C")
_HEADER_FONT = Font(bold=True, color="FFFFFF", size=10)
_CHANGED_FILL = PatternFill("solid", fgColor="A2DAC5")
_TOTALS_FILL = PatternFill("solid", fgColor="D9D9D9")

_THIN = Side(style="thin", color="BFBFBF")
_BORDER = Border(left=_THIN, right=_THIN, top=_THIN, bottom=_THIN)

_FIXED_COLUMNS = ("Наименование системы", "Наименование материала",
                  "Единица измерения", "Тип, марка и обозначение")
# Третья колонка шире прежнего: заголовок "Единица измерения" длиннее, чем
# стоявшая здесь раньше "Размерность", и в прежние 13 знаков не влезает.
_FIXED_WIDTHS = (22, 70, 18, 30)
# Колонка количества узкая: в ней число, а не текст, и колонок этих
# столько же, сколько редакций — до четырёх.
_REVISION_WIDTH = 17
_DELTA_WIDTH = 15


def _qty(value):
    """Количество числом. В спецификации попадаются "5,2" и пробелы
    разрядов — приводим к числу, иначе Excel не сложит колонку."""
    if value is None or value == "":
        return None
    if isinstance(value, (int, float)):
        return value
    text = str(value).strip().replace(" ", "").replace(" ", "").replace(",", ".")
    try:
        number = float(text)
    except ValueError:
        return None
    return int(number) if number == int(number) else number


def _round(value):
    """Сумма количеств в двоичной дробной арифметике даёт хвост: 4442.7
    складывается из строк спецификации в 4442.700000000004, и в отчёте, по
    которому закупают материалы, такое число читается как ошибка счёта.
    Спецификация задаёт количества не точнее третьего знака, до него и
    округляем."""
    if value is None or isinstance(value, int):
        return value
    value = round(value, 3)
    return int(value) if value == int(value) else value


def _label(revision):
    """Подпись колонки: «Исходная редакция», «Изм. 1». Её задаёт вызывающий
    (см. compare._spec_revisions) — имя файла в шапку колонки не годится,
    инженер сравнивает редакции, а не имена файлов."""
    text = " ".join(str(revision.get("label") or "").split())
    return text[:1].upper() + text[1:] if text else "редакция"


def _match_key(name):
    """Наименование в сравнимом виде — регистр, пунктуация и пробелы не в
    счёт. Нужно только для наряда-заказа: его пишет снабжение, а
    спецификацию проектировщик, и расходятся они в мелочах («Вентиялятор»
    против «Вентилятор», лишняя запятая, другой регистр). Между редакциями
    одного комплекта наименования совпадают дословно, и там ослаблять ключ
    незачем."""
    text = (name or "").lower().replace("ё", "е")
    return " ".join(re.sub(r"[^0-9a-zа-я]+", " ", text).split())


def _is_partial(revision):
    """Источник, который НЕ перечисляет спецификацию целиком.

    Наряд-заказ выписывают на то, чего в РД нет, и отсутствие позиции в
    нём не значит ничего. Поэтому пустая ячейка, а не ноль: ноль здесь
    читался бы как «исключено», что неверно."""
    return bool(revision.get("partial"))


def _name_type(row):
    return (" ".join(str(row.get("name") or "").split()),
            " ".join(str(row.get("type") or "").split()))


def _section(row):
    return str(row.get("system") or "").strip()


def _ambiguous_names(revisions):
    """Позиции, которые внутри одной редакции встречаются больше одного
    раза — то есть одно и то же оборудование в разных разделах.

    Только для них раздел входит в ключ. Иначе сравнение ломается на
    ровном месте: пакет изменений выпускается одним листом и заголовков
    разделов в нём может не быть вовсе (в присланном изм.1 их нет ни
    одного), и тогда ВСЕ позиции с разделом в ключе не сопоставились бы
    ни с чем."""
    ambiguous = set()
    for revision in revisions:
        seen = {}
        for row in revision.get("rows") or ():
            key = _name_type(row)
            seen[key] = seen.get(key, 0) + 1
            if seen[key] > 1:
                ambiguous.add(key)
    return ambiguous


def collect_positions(revisions):
    """Сводит позиции всех редакций в общую таблицу.

    revisions: список {"label": подпись колонки, "rows": строки
    спецификации (spec_diff.extract_spec_rows)}.

    Возвращает (positions, systems_per_revision):
      positions — список словарей с ключом позиции, единицей измерения и
      количеством по индексу редакции;
      systems_per_revision — какие системы вообще присутствуют в каждой
      редакции (по ним отличаем "позиции нет" от "раздел не выпускался").
    """
    ambiguous = _ambiguous_names(revisions)
    positions = {}
    order = []
    by_name = {}
    systems = [set() for _ in revisions]
    for index, revision in enumerate(revisions):
        partial = _is_partial(revision)
        for row in revision.get("rows") or ():
            name_type = _name_type(row)
            section = _section(row)
            key = (name_type + (section,)) if name_type in ambiguous else name_type
            # Строку наряда сначала пробуем подшить к уже найденной позиции
            # спецификации по одному наименованию: колонки «Тип, марка» в
            # наряде нет вовсе, и по полному ключу он не сошёлся бы ни с чем.
            if partial and key not in positions:
                key = by_name.get(_match_key(name_type[0]), key)
            systems[index].add(section)
            entry = positions.get(key)
            if entry is None:
                entry = {"key": key, "system": section,
                         "name": name_type[0], "type": name_type[1],
                         "unit": str(row.get("unit") or "").strip(),
                         "qty": [None] * len(revisions)}
                positions[key] = entry
                order.append(key)
                if not partial:
                    by_name.setdefault(_match_key(name_type[0]), key)
            if not entry["unit"]:
                entry["unit"] = str(row.get("unit") or "").strip()
            value = _qty(row.get("qty"))
            if value is not None:
                entry["qty"][index] = (entry["qty"][index] or 0) + value
    result = [positions[k] for k in order]
    for entry in result:
        entry["qty"] = [_round(value) for value in entry["qty"]]
    return result, systems


def _cell_value(entry, index, systems, partial=False):
    """Количество позиции в редакции: число, ноль или пусто — см. пояснение
    про ноль и пустую ячейку в шапке модуля.

    Судить по разделам можно только если редакция их вообще печатает:
    пакет изменений выпускается одним листом, и заголовков разделов в нём
    может не быть. Тогда про "раздел не переиздавался" сказать нечего —
    спецификация в редакции есть, значит отсутствие позиции в ней это
    ноль."""
    value = entry["qty"][index]
    if value is not None:
        return value
    if partial:
        # Наряд-заказ перечисляет не всю спецификацию — см. _is_partial.
        return None
    known_sections = {s for s in systems[index] if s}
    if not known_sections:
        return 0 if systems[index] else None
    return 0 if entry["system"] in systems[index] else None


def _is_changed(values, revisions=None):
    """Изменилось ли количество МЕЖДУ РЕДАКЦИЯМИ (пустые не в счёт —
    редакция, не затронувшая раздел, изменением не является).

    Колонки нарядов-заказов в счёт не идут: их количества — это
    дополнительный объём, а не другое значение того же. Иначе зелёным
    залилась бы почти вся таблица."""
    if revisions is not None:
        values = [v for v, r in zip(values, revisions) if not _is_partial(r)]
    known = [v for v in values if v is not None]
    return len(known) > 1 and len(set(known)) > 1


def _revision_columns(revisions, first_column):
    """Номера колонок редакций (без нарядов) — по ним считаются дельта и
    итоги."""
    return [first_column + index for index, revision in enumerate(revisions)
            if not _is_partial(revision)]


class ReportRowError(Exception):
    """Строку отчёта прочитать нельзя — текст сразу для показа инженеру."""


_HEADER_SCAN_ROWS = 400

# Пояснения-предположения («возможно, переименована позиция … Требует
# проверки инженером»): их бывает по нескольку десятков, и над таблицей они
# собраны в свёрнутую группу под заголовком COMMENTS_TITLE.
REVIEW_MARK = "Требует проверки инженер"
COMMENTS_TITLE = "Комментарии к отчету"


def read_report_row(path, row_number):
    """Одна строка готового отчёта как факты для вопроса по ней.

    Читается именно КНИГА, а не пересобранный разбор: инженер спрашивает
    про то, что видит, и ответ обязан опираться на те же числа. Формат
    книги знает этот модуль — поэтому и читатель живёт рядом с писателем,
    иначе они разойдутся при первой правке шапки.
    """
    workbook = load_workbook(path)
    sheet = workbook.active
    header_row = None
    legend = []
    # Шапка с пояснениями бывает длинной: одних «возможно, переименована»
    # на комплекте ВК больше тридцати строк.
    for row in sheet.iter_rows(min_row=1, max_row=_HEADER_SCAN_ROWS):
        value = row[0].value
        # «Название системы» — шапка книги в формате эталона ОВ
        # (spec_excel_ov.py): таблица там с первой строки, а легенда на
        # отдельном листе.
        if value in (_FIXED_COLUMNS[0], "Название системы"):
            header_row = row[0].row
            break
        if value:
            legend.append(str(value))
    if header_row is not None and "Легенда" in workbook.sheetnames:
        for label, text in workbook["Легенда"].iter_rows(min_row=1, max_col=2, values_only=True):
            if label or text:
                legend.append(f"{label}: {text}" if label else str(text))
    if header_row is None:
        raise ReportRowError("Это не отчёт сравнения спецификаций.")
    if row_number <= header_row:
        raise ReportRowError(f"Строка {row_number} — это шапка отчёта, а не позиция.")

    headers = [str(cell.value).replace("\n", " ") if cell.value else ""
               for cell in sheet[header_row]]
    cells = sheet[row_number]
    if len(cells) < len(_FIXED_COLUMNS) or not cells[1].value:
        raise ReportRowError(f"В строке {row_number} нет позиции.")

    fixed = dict(zip(_FIXED_COLUMNS, [cells[i].value for i in range(len(_FIXED_COLUMNS))]))
    quantities, deltas = [], []
    for index in range(len(_FIXED_COLUMNS), min(len(headers), len(cells))):
        caption = headers[index]
        value = cells[index].value
        if caption.startswith("Дельта"):
            deltas.append(caption)
        else:
            quantities.append({"column": caption, "qty": value})
    # Дельта в книге — формула ("=F13-E13"), и разбирать её ни инженеру, ни
    # модели не нужно: это разность соседних количеств, считаем сами.
    numeric = [q["qty"] if isinstance(q["qty"], (int, float)) else None
               for q in quantities]
    if not deltas and len(quantities) > 1:
        deltas = [f"Дельта {quantities[i + 1]['column']} − {quantities[i]['column']}"
                  for i in range(len(quantities) - 1)]
    deltas = [
        {"column": caption,
         "delta": (None if numeric[index] is None or numeric[index + 1] is None
                   else round(numeric[index + 1] - numeric[index], 3))}
        for index, caption in enumerate(deltas)
        if index + 1 < len(numeric)
    ]
    return {
        "row": row_number,
        "system": fixed.get(_FIXED_COLUMNS[0]),
        "name": fixed.get(_FIXED_COLUMNS[1]),
        "unit": fixed.get(_FIXED_COLUMNS[2]),
        "type": fixed.get(_FIXED_COLUMNS[3]),
        "quantities": quantities,
        "deltas": deltas,
        "legend": legend,
    }


def _delta_pairs(revisions, first_column):
    """Пары соседних редакций для колонок дельт: (колонка «было», колонка
    «стало»).

    Дельт столько же, сколько переходов между редакциями, а не одна на всю
    книгу: при трёх редакциях инженеру нужно отдельно видеть, что изменило
    изм.1 и что изм.2 — в утверждённом формате это Δ (П2−П1) и Δ (П3−П2).
    Наряды-заказы в дельты не входят (см. _revision_columns)."""
    columns = _revision_columns(revisions, first_column)
    return list(zip(columns, columns[1:]))


# Основание хронологии по умолчанию: роль редакции взята из ИМЕНИ ФАЙЛА.
# Это допущение, а не факт из документа — номер изменения в штампе стоит не
# на всех листах, а на сканах его нет вовсе. Когда инженер подтвердил роли
# на карточке «Что я нашёл», вызывающий код передаёт свой текст.
CHRONOLOGY_FROM_NAMES = (
    "Порядок редакций определён по именам файлов (пометка «изм. N»): файл "
    "без пометки — исходная редакция. Проверьте роли по штампам; если "
    "порядок неверен, переименуйте файлы и повторите сравнение.")
CHRONOLOGY_CONFIRMED = (
    "Порядок редакций подтверждён пользователем на карточке разбора — "
    "роли взяты из его выбора, а не из имён файлов.")


# Разделы, у которых свой эталон книги. Остальные собираются в общем
# формате (с колонками дельт), пока для них эталона нет.
SECTION_LAYOUTS = {"ОВ": "ov"}


def build_spec_workbook(revisions, output_path, title=None, subtitle=None, notes=(),
                        chronology=None, section=None, legend=None):
    """Собирает книгу сравнения спецификаций и сохраняет по output_path.

    section — раздел проекта: если для него есть свой эталон (сейчас ОВ),
    книга собирается в его формате (spec_excel_ov.py)."""
    if SECTION_LAYOUTS.get(str(section or "").strip().upper()) == "ov" \
            and not any(_is_partial(r) for r in revisions):
        import spec_excel_ov
        legend = dict(legend or {})
        legend.setdefault("notes", list(notes) + ([chronology] if chronology else []))
        spec_excel_ov.build(revisions, output_path, legend=legend)
        return output_path
    positions, systems = collect_positions(revisions)
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = SHEET_TITLE

    # Ширина легенды над таблицей — по всей таблице, включая все колонки
    # дельт (их столько, сколько переходов между редакциями).
    columns = (len(_FIXED_COLUMNS) + len(revisions)
               + max(1, len(_delta_pairs(revisions, len(_FIXED_COLUMNS) + 1))))
    row_index = _write_header_block(sheet, revisions, columns, title, subtitle, notes,
                                    chronology)
    header_row = row_index
    _write_table_header(sheet, revisions, header_row)
    first_data_row = header_row + 1

    for offset, entry in enumerate(positions):
        _write_position(sheet, first_data_row + offset, entry, revisions, systems)

    last_data_row = first_data_row + len(positions) - 1
    if positions:
        _write_totals(sheet, revisions, first_data_row, last_data_row)

    _apply_widths(sheet, revisions)
    # Области не закрепляются: шапка с пояснениями высокая, и закреплённая
    # она занимала полэкрана (просьба заказчика по отчёту ВК).
    if positions:
        sheet.auto_filter.ref = (f"A{header_row}:"
                                 f"{get_column_letter(columns)}{last_data_row}")
    workbook.save(output_path)
    return output_path


def _write_header_block(sheet, revisions, columns, title, subtitle, notes,
                        chronology=None):
    """Шапка отчёта: что с чем сравнивали и как читать подсветку."""
    row = 1
    lines = []
    if title:
        lines.append((title, True))
    if subtitle:
        lines.append((subtitle, False))
    for revision in revisions:
        text = _label(revision)
        note = revision.get("note")
        if note:
            text += f" — файл {note}"
        lines.append((text, False))
    # Основание хронологии — допущение, а не факт из документа: роль
    # редакции взята из ИМЕНИ ФАЙЛА (пометка «изм. N»), потому что номер
    # изменения в штампе стоит не на всех листах, а на сканах его нет
    # вовсе. Перепутанные роли дают отчёт, по которому закупят не то,
    # поэтому основание названо прямо, а проверка оставлена инженеру.
    if sum(1 for r in revisions if not _is_partial(r)) > 1:
        lines.append((chronology or CHRONOLOGY_FROM_NAMES, False))
    if any(_is_partial(r) for r in revisions):
        lines.append((
            "Колонки «Наряд-заказ» — дополнительный объём по НЗ, а не количество "
            "по проекту. Пустая ячейка в такой колонке значит, что наряд этой "
            "позиции не касался; ноль там не ставится никогда. В дельту и в "
            "подсветку изменений наряды не входят.", False))
    lines.append((
        "Заливка ячейки зелёным — количество изменилось между редакциями. "
        "0 — позиции в этой редакции нет, хотя спецификация в ней выпущена. "
        "Пустая ячейка — спецификация в этой редакции не выпускалась, "
        "изменение раздел не затрагивало.", False))
    review = [note for note in notes if REVIEW_MARK in note]
    for note in notes:
        if REVIEW_MARK not in note:
            lines.append((note, False))

    def put(text, bold):
        cell = sheet.cell(row=row, column=1, value=text)
        cell.font = Font(bold=bold, size=12 if bold else 10)
        cell.alignment = Alignment(vertical="center", wrap_text=False)
        sheet.merge_cells(start_row=row, start_column=1, end_row=row, end_column=columns)

    for text, bold in lines:
        put(text, bold)
        row += 1
    if review:
        # Заголовок, под ним свёрнутая группа: «+» слева от заголовка
        # раскрывает строки. Таблица при этом не уезжает на экран вниз.
        put(COMMENTS_TITLE, True)
        sheet.row_dimensions[row].collapsed = True
        sheet.sheet_properties.outlinePr.summaryBelow = False
        # Без уровня группировки в формате листа Excel не рисует поле с
        # «+», и свёрнутые строки не раскрыть.
        sheet.sheet_format.outlineLevelRow = 1
        row += 1
        for note in review:
            put(note, False)
            sheet.row_dimensions[row].outlineLevel = 1
            sheet.row_dimensions[row].hidden = True
            row += 1
    return row + 1  # пустая строка-отбивка перед таблицей


def _write_table_header(sheet, revisions, row):
    headers = list(_FIXED_COLUMNS)
    headers += [(f"Наряд-заказ\n{_label(r)}" if _is_partial(r)
                 else f"Количество\n{_label(r)}") for r in revisions]
    only = [r for r in revisions if not _is_partial(r)]
    if len(only) > 1:
        headers += [f"Дельта\n{_label(b)} − {_label(a)}"
                    for a, b in zip(only, only[1:])]
    else:
        headers.append("Дельта")
    for column, text in enumerate(headers, start=1):
        cell = sheet.cell(row=row, column=column, value=text)
        cell.fill = _HEADER_FILL
        cell.font = _HEADER_FONT
        cell.alignment = Alignment(wrap_text=True, vertical="center", horizontal="center")
        cell.border = _BORDER
    sheet.row_dimensions[row].height = 46


def _write_position(sheet, row, entry, revisions, systems):
    for column, value in enumerate((entry["system"], entry["name"], entry["unit"], entry["type"]),
                                   start=1):
        cell = sheet.cell(row=row, column=column, value=value)
        cell.alignment = Alignment(wrap_text=True, vertical="top")
        cell.border = _BORDER

    # Позиция, которой нет ни в одной редакции, пришла из наряда-заказа:
    # в проекте её не было никогда, и ноль в колонках редакций читался бы
    # как «исключена из спецификации». Пусто.
    in_project = any(entry["qty"][index] is not None
                     for index, revision in enumerate(revisions)
                     if not _is_partial(revision))
    values = [_cell_value(entry, index, systems, _is_partial(revision) or not in_project)
              for index, revision in enumerate(revisions)]
    changed = _is_changed(values, revisions)
    first_column = len(_FIXED_COLUMNS) + 1
    for offset, value in enumerate(values):
        cell = sheet.cell(row=row, column=first_column + offset, value=value)
        cell.border = _BORDER
        cell.alignment = Alignment(horizontal="right", vertical="top")
        if changed and value is not None:
            cell.fill = _CHANGED_FILL
            cell.font = Font(bold=True)

    # Дельты — формулами, а не числами: инженер правит количество в колонке
    # редакции и сразу видит пересчитанную разницу.
    pairs = _delta_pairs(revisions, first_column)
    delta_column = first_column + len(revisions)
    for offset, (before, after) in enumerate(pairs or [(None, None)]):
        cell = sheet.cell(row=row, column=delta_column + offset)
        cell.border = _BORDER
        cell.alignment = Alignment(horizontal="right", vertical="top")
        if before is None:
            continue
        if (values[before - first_column] is not None
                and values[after - first_column] is not None):
            a = get_column_letter(before)
            b = get_column_letter(after)
            cell.value = f"={b}{row}-{a}{row}"


def _write_totals(sheet, revisions, first_row, last_row):
    """Итоги формулами — чтобы пересчитывались после ручной правки."""
    first_column = len(_FIXED_COLUMNS) + 1
    columns = _revision_columns(revisions, first_column)
    first = get_column_letter(columns[0])
    last = get_column_letter(columns[-1])
    pairs = _delta_pairs(revisions, first_column)
    delta_columns = [get_column_letter(first_column + len(revisions) + offset)
                     for offset in range(max(1, len(pairs)))]

    def span(column):
        # Букву столбца обязаны нести ОБА конца диапазона: "E7:276" Excel
        # считает битой формулой и при открытии предлагает восстановить
        # файл, вырезав её, — вместе с итогами. Ровно на этом отчёт и
        # ломался, хотя сама таблица считалась верно.
        return f"{column}{first_row}:{column}{last_row}"

    rows = [
        ("Добавлено позиций (не было в первой редакции)",
         f'=COUNTIF({span(first)},0)'),
        ("Исключено позиций (нет в последней редакции)",
         f'=COUNTIF({span(last)},0)'),
        ("Изменилось количество",
         "=" + "+".join(f'COUNTIFS({span(d)},"<>0",{span(d)},"<>")'
                        for d in delta_columns)
         + f'-COUNTIF({span(first)},0)-COUNTIF({span(last)},0)'),
        ("Всего позиций в таблице", f"={last_row}-{first_row}+1"),
    ]
    row = last_row + 2
    for label, formula in rows:
        title_cell = sheet.cell(row=row, column=1, value=label)
        title_cell.font = Font(bold=True)
        sheet.merge_cells(start_row=row, start_column=1,
                          end_row=row, end_column=len(_FIXED_COLUMNS))
        value_cell = sheet.cell(row=row, column=first_column, value=formula)
        value_cell.font = Font(bold=True)
        value_cell.fill = _TOTALS_FILL
        row += 1

    total_cell = sheet.cell(row=row, column=1, value="Итого количество по колонкам")
    total_cell.font = Font(bold=True)
    sheet.merge_cells(start_row=row, start_column=1,
                      end_row=row, end_column=len(_FIXED_COLUMNS))
    for index in range(len(revisions)):
        column = get_column_letter(first_column + index)
        cell = sheet.cell(row=row, column=first_column + index,
                          value=f"=SUM({span(column)})")
        cell.font = Font(bold=True)
        cell.fill = _TOTALS_FILL


def _apply_widths(sheet, revisions):
    pairs = _delta_pairs(revisions, len(_FIXED_COLUMNS) + 1)
    widths = (list(_FIXED_WIDTHS) + [_REVISION_WIDTH] * len(revisions)
              + [_DELTA_WIDTH] * max(1, len(pairs)))
    for index, width in enumerate(widths, start=1):
        sheet.column_dimensions[get_column_letter(index)].width = width
