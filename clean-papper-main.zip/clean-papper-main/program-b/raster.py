# -*- coding: utf-8 -*-
"""
Растровые вставки: листы без текстового слоя.

В комплект попадают отсканированные или вставленные картинкой листы. У
них нет ни текста, ни вектора, поэтому сравнить их с прошлой редакцией
нечем — в отчёте они честно помечаются «не проанализирован». Но и строка
«стр. 52, 53, 54 — растровое изображение» инженеру мало что говорит.

Здесь модель смотрит на такой лист и называет его: «Рисунок 12, схема
подключения ШУН». Не сравнивает — сравнивать нечего, — а опознаёт, чтобы
в сводке вместо номера страницы стояло понятное имя.

Единственное место во всём разборе, куда уходит картинка, и потому с
жёстким потолком: на присланном комплекте ПС таких листов 44, и без
потолка одно сравнение стоило бы доллар с лишним. Потолок и разрешение
подобраны так, чтобы прочитать заголовок и штамп, а не разглядывать
чертёж.
"""
import os
import sys

import fitz

# Модуль самодостаточен: ему нужен common/, и он сам об этом заботится, а
# не полагается на то, что кто-то настроил пути раньше.
_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

from common.anthropic_client import AnthropicError, image_block  # noqa: E402

# Сколько листов вообще описываем за прогон. Восемь — это примерно
# 8 тысяч входных токенов, то есть копейки; сорок четыре обошлись бы
# дороже всего остального чернового текста вместе взятого.
MAX_PAGES_DESCRIBED = 8

# Ширина картинки в пикселях. Хватает, чтобы прочитать крупный заголовок
# и штамп; мелкие выноски на такой картинке неразличимы, но они здесь и
# не нужны — лист всё равно не сравнивается.
TARGET_WIDTH_PX = 1000

_SYSTEM_PROMPT = (
    "Ты смотришь на лист рабочей документации, вставленный в комплект "
    "картинкой (скан или растровая вставка). Назови, что это за лист: "
    "номер или обозначение, если они видны, и о чём лист — одной короткой "
    "строкой, не длиннее десяти слов. Не описывай содержимое чертежа "
    "подробно и не делай выводов о проекте. Если разобрать ничего нельзя, "
    "ответь: не разобрать."
)


# Назвать лист по картинке — короткая работа со зрением: та же модель, что
# у комментариев по листам (narrative.SHEETS_MODEL, поле model_secondary).
RASTER_MODEL = "claude-opus-5-5"


def render_page(page, target_width=TARGET_WIDTH_PX):
    """PNG страницы. Масштаб считаем от ширины: листы в комплекте разного
    формата, от А4 до А0, и фиксированный dpi дал бы то мелкую картинку,
    то огромную."""
    width = max(page.rect.width, 1.0)
    zoom = min(max(target_width / width, 0.2), 4.0)
    pixmap = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom), colorspace=fitz.csGRAY)
    try:
        return pixmap.tobytes("png")
    finally:
        pixmap = None


def describe_pages(client, doc, page_numbers, log=print, limit=MAX_PAGES_DESCRIBED):
    """Возвращает {номер страницы: короткое описание}.

    Сбой запроса не должен ронять прогон: лист просто останется без
    описания, как было до этой возможности."""
    if client is None or not page_numbers:
        return {}

    described = {}
    for number in list(page_numbers)[:limit]:
        index = number - 1
        if index < 0 or index >= len(doc):
            continue
        try:
            png = render_page(doc[index])
        except Exception as exc:  # noqa: BLE001 — картинка не должна ронять отчёт
            log(f"[растр] не удалось отрисовать стр. {number}: {exc}")
            continue
        try:
            text = client.chat_completion([
                {"role": "system", "content": _SYSTEM_PROMPT},
                {"role": "user", "content": [
                    image_block(png),
                    {"type": "text", "text": "Что это за лист?"},
                ]},
            ], max_tokens=1500, model=getattr(client, "model_secondary", None) or RASTER_MODEL)
        except AnthropicError as exc:
            log(f"[растр] не удалось описать стр. {number}: {exc}")
            break  # если сломалось на одном листе, сломается и на остальных
        text = " ".join(str(text).split())
        if text and "не разобрать" not in text.lower():
            described[number] = text[:120]
    if len(page_numbers) > limit:
        log(f"[растр] растровых листов {len(page_numbers)}, описано {len(described)} "
            f"(потолок {limit}) — остальные остаются без описания")
    return described
