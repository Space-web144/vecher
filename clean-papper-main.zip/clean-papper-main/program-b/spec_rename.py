# -*- coding: utf-8 -*-
"""
Переименованные позиции спецификации.

Позиции сравниваются по наименованию и типу (см. spec_excel.py), поэтому
«Клапан КПС-1» → «Клапан противопожарный КПС-1» читается как «одну
позицию убрали, другую добавили». Для инженера это одна строка: позицию
переименовали, а не заменили.

Здесь модель получает ТОЛЬКО списки убранных и добавленных позиций —
наименование, тип, единицу, количество — и называет пары, которые на
самом деле одна и та же позиция. Никаких чертежей и никаких файлов.

Решение модели остаётся предположением: таблица от него не меняется,
позиции по-прежнему показаны как убранная и добавленная, а предположение
выводится отдельной пометкой. Подтверждает инженер. Поэтому ошибка модели
стоит лишней строки примечания, а не подменённой позиции в закупке.
"""
import difflib
import json
import re

# Ниже этой схожести наименований пару не принимаем, что бы модель ни
# ответила: разные позиции не становятся одной от её уверенности.
NAME_SIMILARITY_FLOOR = 0.35

# Сколько позиций уходит в один запрос. Пакет изменений редко больше,
# а на крупных комплектах длинный промпт и дороже, и хуже по качеству.
MAX_POSITIONS_PER_SIDE = 60

_JSON_FENCE_RE = re.compile(r"^\s*```(?:json)?\s*|\s*```\s*$", re.IGNORECASE)


def _name(row):
    return " ".join(str(row.get("name") or "").split())


def _full(row):
    parts = [_name(row), str(row.get("type") or "").strip()]
    return " ".join(p for p in parts if p)


def similarity(old_row, new_row):
    return difflib.SequenceMatcher(None, _full(old_row).lower(), _full(new_row).lower()).ratio()


def _prompt_rows(rows):
    out = []
    for index, row in enumerate(rows[:MAX_POSITIONS_PER_SIDE], start=1):
        out.append({"№": index, "наименование": _name(row)[:120],
                    "тип": str(row.get("type") or "")[:60],
                    "ед": str(row.get("unit") or "")[:12],
                    "кол-во": row.get("qty")})
    return out


def _parse(text):
    payload = _JSON_FENCE_RE.sub("", (text or "").strip())
    start, end = payload.find("["), payload.rfind("]")
    if start == -1 or end == -1 or end < start:
        return []
    try:
        data = json.loads(payload[start:end + 1])
    except ValueError:
        return []
    return data if isinstance(data, list) else []


def find_renames(ask, removed, added, log=print):
    """Возвращает список (removed_row, added_row, similarity).

    Пара принимается, только если обе позиции есть в запросе, ни одна не
    использована дважды и наименования достаточно похожи."""
    if not removed or not added or ask is None:
        return []

    prompt = (
        "Ниже позиции спецификации, пропавшие из новой редакции и появившиеся в "
        "ней. Часть из них — одна и та же позиция, которую переименовали или "
        "уточнили её тип, а не заменили на другую.\n"
        "Назови такие пары. Позиции разного назначения парой не являются, даже "
        "если названия похожи. Если пары нет — не придумывай: лучше пропустить, "
        "чем выдать замену за переименование.\n"
        "Ответь массивом JSON без пояснений: "
        "[{\"убрана\": номер, \"добавлена\": номер}, …]"
    )
    facts = {"убраны из новой редакции": _prompt_rows(removed),
             "добавлены в новой редакции": _prompt_rows(added)}
    text = ask(prompt, facts, 4000)

    used_old, used_new = set(), set()
    pairs = []
    for item in _parse(text):
        if not isinstance(item, dict):
            continue
        old_no, new_no = item.get("убрана"), item.get("добавлена")
        if not isinstance(old_no, int) or not isinstance(new_no, int):
            continue
        if not (1 <= old_no <= min(len(removed), MAX_POSITIONS_PER_SIDE)):
            log(f"[спека] модель назвала несуществующую позицию {old_no}, пара отброшена")
            continue
        if not (1 <= new_no <= min(len(added), MAX_POSITIONS_PER_SIDE)):
            log(f"[спека] модель назвала несуществующую позицию {new_no}, пара отброшена")
            continue
        if old_no in used_old or new_no in used_new:
            log("[спека] позиция использована в паре дважды, пара отброшена")
            continue
        old_row, new_row = removed[old_no - 1], added[new_no - 1]
        score = similarity(old_row, new_row)
        if score < NAME_SIMILARITY_FLOOR:
            log(f"[спека] пара «{_name(old_row)[:40]}» → «{_name(new_row)[:40]}» отброшена: "
                f"наименования непохожи (схожесть {score:.2f})")
            continue
        used_old.add(old_no)
        used_new.add(new_no)
        pairs.append((old_row, new_row, score))
    return pairs


def rename_notes(pairs):
    """Пометки для отчёта — предположения, а не факты."""
    notes = []
    for old_row, new_row, _score in pairs:
        note = (f"Возможно, переименована позиция: «{_name(old_row)}» → «{_name(new_row)}»")
        qty_old, qty_new = old_row.get("qty"), new_row.get("qty")
        if qty_old not in (None, "") and qty_new not in (None, "") and qty_old != qty_new:
            note += f" (количество {qty_old} → {qty_new})"
        notes.append(note + ". Требует проверки инженером.")
    return notes
