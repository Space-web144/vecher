# -*- coding: utf-8 -*-
"""
Предобработка поисковых запросов для Tier 2 (гибридного) поиска —
порт matching_system query_processor.py (без изменений логики нормализации;
убрана зависимость от StrictParameterValidator внутри конструктора — она
подключается centrally в common.hybrid_matcher, чтобы не грузить конфиг
дважды и не плодить print()-логи при построении индекса).
"""

import re
import json
import os
from typing import Dict, List, Optional

_DEFAULT_SYNONYMS_PATH = os.path.join(os.path.dirname(__file__), "config", "synonyms.json")


class QueryProcessor:

    def __init__(self, synonyms_path: str = _DEFAULT_SYNONYMS_PATH):
        self.stop_words = {
            'применяется', 'для', 'систем', 'системы', 'с', 'в', 'на', 'из',
            'тип', 'материал', 'габаритами', 'габариты', 'толщиной', 'толщина',
            'комплекте', 'комплект', 'состав', 'включает', 'шт', 'мм', 'см', 'м',
            'при', 'по', 'до', 'или', 'и', 'а', 'но', 'же', 'бы', 'ли'
        }

        self.synonyms = {}
        self.system_synonyms = {}
        self.size_synonyms = {}
        self.brands_to_ignore = []

        if os.path.exists(synonyms_path):
            with open(synonyms_path, 'r', encoding='utf-8') as f:
                data = json.load(f)
                self.synonyms = data.get('синонимы', {})
                self.system_synonyms = data.get('синонимы_по_системам', {})
                self.size_synonyms = data.get('размеры_дюймы_DN', {})
                self.brands_to_ignore = data.get('бренды_игнорировать', [])

    def expand_query_with_synonyms(self, query: str, system: str = 'default') -> str:
        expanded = query
        query_lower = query.lower()

        for term, synonyms in self.synonyms.items():
            if term in query_lower:
                if synonyms and synonyms[0] not in query_lower:
                    if '-' in synonyms[0] or '-' in term:
                        expanded = re.sub(re.escape(term), synonyms[0], expanded, flags=re.IGNORECASE)
                    else:
                        expanded += f" {synonyms[0]}"

        system_synonyms = self.system_synonyms.get(system, {})
        for term, synonyms in system_synonyms.items():
            if term in query_lower:
                if synonyms and synonyms[0] not in query_lower:
                    if '-' in synonyms[0] or '-' in term:
                        expanded = re.sub(re.escape(term), synonyms[0], expanded, flags=re.IGNORECASE)
                    else:
                        expanded += f" {synonyms[0]}"

        for size, dn_variants in self.size_synonyms.items():
            if size in query:
                for dn in dn_variants[:2]:
                    if dn not in expanded:
                        expanded += f" {dn}"

        return expanded.strip()

    def remove_brands(self, text: str) -> str:
        cleaned = text
        for brand in self.brands_to_ignore:
            pattern = r'\b' + re.escape(brand) + r'\b'
            cleaned = re.sub(pattern, '', cleaned, flags=re.IGNORECASE)
        cleaned = re.sub(r'\s+', ' ', cleaned).strip()
        return cleaned

    def preprocess_for_matching(self, text: str, expand: bool = True, system: str = 'default') -> str:
        processed = text

        processed = re.sub(r'(\d+)\s*[хxXХ×]\s*(\d+)', r'\1x\2', processed, flags=re.IGNORECASE)
        processed = re.sub(r'[øфØФøØ]\s*(\d+)', r'Ø\1', processed)

        processed = re.sub(r'\bДКК-?(\d+)', r'дроссель-клапан круглый диаметр \1', processed, flags=re.IGNORECASE)
        processed = re.sub(r'\bДКП\s+(\d+x\d+)', r'дроссель-клапан прямоугольный \1', processed, flags=re.IGNORECASE)
        processed = re.sub(r'\bДК\s+Ø(\d+)', r'дроссель-клапан круглый диаметр \1', processed, flags=re.IGNORECASE)

        processed = re.sub(r'[lL]\s*=\s*(\d+)\s*мм', r'L=\1мм', processed)
        processed = re.sub(r'[δб]\s*=\s*(\d+[.,]\d+)\s*мм', r'\1мм', processed)

        processed = processed.replace(',', '.')

        replacements = [
            (r'\bоцинкованн(?:ой|ый|ого|ая|ые)\b', 'оцинк.'),
            (r'\bнержавеющ(?:ей|ий|его|ая|ие)\b', 'нерж.'),
            (r'\bдроссель.клапан\s+круглый\b', 'дроссель-клапан круглого сечения'),
            (r'\bдроссель.клапан\s+прямоугольный\b', 'дроссель-клапан прямоуг'),
            (r'\bчёрной\b|\bчерной\b', 'черн.'),
            (r'материал:\s*сталь[.,]?', ''),
            (r'покрытие:\s*оцинкованное[.,]?', 'оцинк.'),
            (r'тип\s+исполнения:[^,\.]*', ''),
            (r'тип\s+соединения:[^,\.]*', ''),
            (r'класса\s+герметичности\s+.{0,3}([A-BА-ЯВН]).{0,3}', r'кл. \1'),
            (r'по\s+ГОСТ\s+Р\s+59972-2021', ''),
            (r'по\s+ГОСТ\s+Р\s+\d+[-\d]*', ''),
            (r'\bплотн(?:ые|ый|ая|ое)\b', ''),
        ]
        for pattern, replacement in replacements:
            processed = re.sub(pattern, replacement, processed, flags=re.IGNORECASE)

        processed = re.sub(r'\s*,\s*', ' ', processed)
        processed = re.sub(r'\s+', ' ', processed)
        processed = self.remove_brands(processed)

        if 'переход' in processed.lower():
            tip_m = re.search(r'\bтип\s*(\d+)\b', processed, re.IGNORECASE)
            if tip_m:
                num = tip_m.group(1)
                processed = re.sub(r'\bтип\s*\d+\b', '', processed, flags=re.IGNORECASE).strip()
                processed += f' Тип {num}.'
            pair_m = re.search(r'(\d+x\d+)\s*[-–]\s*(\d+x\d+)', processed, re.IGNORECASE)
            if pair_m:
                s1, s2 = pair_m.group(1), pair_m.group(2)
                if s1 != s2:
                    processed += f' {s2}-{s1}'

        q_low = processed.lower()
        if 'шайба' in q_low and 'усилен' in q_low and 'din' not in q_low:
            processed += ' DIN9021'
        if 'гайка' in q_low and 'оц' in q_low and 'din' not in q_low:
            processed += ' DIN 934'
        if 'болт' in q_low and ('полная резьба' in q_low or 'полной резьбой' in q_low) and 'din' not in q_low:
            processed += ' DIN 933'

        if expand:
            processed = self.expand_query_with_synonyms(processed, system=system)

        return processed.strip()
