# -*- coding: utf-8 -*-
"""Клиент Anthropic Messages API (модель Claude) — только транспорт.

Используется program-b/narrative.py для черновых связных текстов отчёта
Verrata (резюме, комментарии по листам, выводы), common/claude_matcher.py
для Tier 3 сравнения с 1С в VentSpec и проверки дублей при приёме
номенклатуры и common/web_agent_chat.py — чат «Ассистент» на сайте. САМ клиент про это не знает и знать не должен — он умеет
только "отправить сообщения, получить текст".

Почему свой HTTP, а не официальный SDK: на хостинге Python 3.8.6
(/opt/python/python-3.8.8/bin/python3), а пакет anthropic требует 3.10+.
Запрос к /v1/messages — это один POST с JSON, тут нечего экономить.

=== Секреты ===
Ключ API и пароль SOCKS-прокси НИКОГДА не передаются ни аргументами
командной строки (argv видно всем в `ps aux` на общем хостинге), ни через
окружение из PHP. Клиент сам читает файл с правами 600, лежащий ВЫШЕ
корня сайта, например /var/www/u2980659/data/secrets/anthropic.json:

    {
      "api_key": "sk-ant-...",
      "proxy": "socks5h://ventproxy:ПАРОЛЬ@92.113.151.211:1080",
      "model": "claude-fable-5-1",
      "model_secondary": "claude-opus-5-5",
      "model_matching": "claude-opus-5-5",
      "model_chat": "claude-opus-5-5",
      "model_rv": "claude-opus-5-5",
      "effort_rv": "high",
      "effort_rv_mark": "medium",
      "effort": "low"
    }

PHP знает только ПУТЬ к этому файлу (web/config.php ->
ANTHROPIC_CREDENTIALS_FILE) и передаёт путь, а не содержимое.

=== Прокси ===
У API Anthropic нет российских адресов, с IP хостинга (31.31.196.50)
запрос не проходит, поэтому трафик идёт через SOCKS5 на своей виртуалке
(dante). Схема socks5h означает "имя api.anthropic.com разрешает сам
прокси" (аналог curl --socks5-hostname); для socks5 DNS был бы локальным.
SOCKS в urllib нет, нужен пакет pysocks (см. web/requirements-web.txt).

=== Особенности модели claude-fable-5-1 ===
* размышление (thinking) включено всегда и его токены тоже считаются в
  max_tokens — поэтому max_tokens ставим с запасом, а краткость ответа
  задаём формулировкой промпта и параметром effort, а НЕ max_tokens
  (иначе бюджет уйдёт на размышление и текста в ответе не будет вовсе);
* параметры выборки (temperature и т.п.) не принимаются — 400;
* при отказе классификатора приходит HTTP 200 со stop_reason="refusal",
  ответ при этом без текста (см. AnthropicRefusal) — и опционально
  включается серверный переход на другую модель (fallbacks).
"""
from __future__ import annotations

import base64
import http.client
import json
import os
import re
import socket
import ssl
import stat
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import List, Optional

MESSAGES_URL = "https://api.anthropic.com/v1/messages"
FILES_URL = "https://api.anthropic.com/v1/files"
API_VERSION = "2023-06-01"

# Files API: файл загружается один раз, дальше в запросах — только его
# file_id (чат «Ассистент», см. common/agent_files.py). Срок жизни файла
# в хранилище Anthropic задаётся при загрузке, не больше 90 дней.
FILE_EXPIRES_MAX_SEC = 90 * 24 * 3600
_UPLOAD_CHUNK = 1024 * 1024

DEFAULT_MODEL = "claude-fable-5-1"
# Серверный переход на другую модель, если классификатор отказался
# отвечать (stop_reason="refusal"): API сам повторяет тот же запрос на
# запасной модели внутри того же вызова. Заголовок и форма параметра
# жёстко связаны — массив ставится только с ...-2026-06-01.
FALLBACK_MODEL = "claude-opus-4-8"
FALLBACK_BETA = "server-side-fallback-2026-06-01"
MCP_BETA = "mcp-client-2025-11-20"

# Задача — переизложить словами уже посчитанные факты, а не рассуждать;
# низкий effort на такой работе почти не теряет качества, но заметно
# дешевле и быстрее (размышление — это выходные токены по $50/млн).
DEFAULT_EFFORT = "low"
EFFORT_LEVELS = ("low", "medium", "high", "xhigh", "max")

# max_tokens здесь — предохранитель, а не способ укоротить ответ: в него
# входят и токены размышления. Занижать нельзя, см. шапку файла.
DEFAULT_MAX_TOKENS = 4000

# Предохранитель от зацикливания: сколько запросов вообще может сделать
# один клиент за прогон. Значение по умолчанию рассчитано на одну пару
# редакций; вызывающий код, знающий их число, задаёт свой потолок
# (см. program-b/compare.py). Настоящий потолок расходов задаётся лимитом
# ключа в консоли Anthropic — это лишь страховка от ошибки в коде,
# которая уже однажды сработала не по делу и съела черновой текст.
DEFAULT_MAX_REQUESTS = 40

DEFAULT_TIMEOUT_SEC = 180
MAX_RETRIES = 3
RETRY_BASE_DELAY_SEC = 2.0
# 429 — лимит запросов, 529 — перегрузка API, 5xx — сбой на стороне
# сервиса; всё это осмысленно повторить. 4xx кроме 429 повторять нельзя:
# запрос не станет правильнее от повтора.
RETRY_STATUSES = frozenset({408, 429, 500, 502, 503, 504, 529})
MAX_RETRY_DELAY_SEC = 60.0

# Ответ больше этого — не текст на несколько абзацев, а ошибка или обрыв
# соединения; лучше упасть понятным сообщением, чем съесть память
# (у процессов на хостинге жёсткий лимит).
MAX_RESPONSE_BYTES = 8 * 1024 * 1024
_FALLBACK_READ_CHUNK = 16 * 1024

# Путь по умолчанию — ровно тот, что заведён на хостинге. Обычно путь
# приходит явным параметром (web/config.php), это подстраховка для
# ручного запуска на сервере.
DEFAULT_CREDENTIALS_FILES = (
    "/var/www/u2980659/data/secrets/anthropic.json",
)

# Цены за миллион токенов ($ вход / $ выход) — для оценки расходов в
# логе прогона. Неизвестная модель считается по самому дорогому тарифу,
# чтобы оценка не оказалась оптимистичнее реальности.
PRICES_USD_PER_MTOK = {
    "claude-fable-5-1": (10.0, 50.0),
    "claude-fable-5": (10.0, 50.0),
    "claude-opus-5-5": (4.0, 20.0),
    "claude-opus-5": (5.0, 25.0),
    "claude-sonnet-5-5": (2.0, 10.0),
    "claude-haiku-5-5": (0.10, 0.50),
    "claude-opus-4-8": (5.0, 25.0),
    "claude-sonnet-5": (3.0, 15.0),
    "claude-haiku-4-5-20251001": (1.0, 5.0),
}
_MOST_EXPENSIVE_PRICE = max(PRICES_USD_PER_MTOK.values())

_KEY_RE = re.compile(r"sk-[A-Za-z0-9_\-]+")


class AnthropicError(RuntimeError):
    """status — HTTP-код, если запрос отклонил сам API (401 — ключ, 429 —
    лимит и т.д.); по нему вызывающий код подбирает понятный человеку
    текст, а подробности остаются в журнале."""

    def __init__(self, message, status=None):
        super().__init__(message)
        self.status = status


class AnthropicConfigError(AnthropicError):
    """Неисправна настройка на сервере: нет файла с ключом, ключ испорчен,
    нет pysocks, не проверяется сертификат. Повтор не поможет — чинит
    администратор."""


class AnthropicConnectionError(AnthropicError):
    """До API не достучались: прокси, сеть, таймаут. Повтор позже может
    помочь."""


class AnthropicRefusal(AnthropicError):
    """Классификатор отказался отвечать (stop_reason="refusal").

    Отдельный класс, потому что это НЕ поломка: отчёт выпускается и без
    черновых текстов, а повторять такой запрос бессмысленно."""


def _read_capped(resp, cap_bytes: int = MAX_RESPONSE_BYTES) -> bytes:
    """Читает ответ по Content-Length, а без него — маленькими порциями.
    Один большой resp.read() на этом хостинге уже приводил к MemoryError
    внутри http.client."""
    headers = getattr(resp, "headers", None)
    length_header = headers.get("Content-Length") if headers is not None else None
    if length_header is not None:
        try:
            length = int(length_header)
        except (TypeError, ValueError):
            length = None
        if length is not None:
            if length > cap_bytes:
                raise AnthropicError(
                    f"Ответ Anthropic заявлен размером {length} байт — больше "
                    f"{cap_bytes // (1024 * 1024)} МБ, это похоже на ошибку, а не на текст.")
            return resp.read(length)

    chunks = []
    total = 0
    while True:
        piece = resp.read(_FALLBACK_READ_CHUNK)
        if not piece:
            break
        total += len(piece)
        if total > cap_bytes:
            raise AnthropicError(
                f"Ответ Anthropic превысил {cap_bytes // (1024 * 1024)} МБ — "
                "похоже на обрыв соединения, а не на реальные данные.")
        chunks.append(piece)
    return b"".join(chunks)


def _check_file_mode(path: Path) -> Optional[str]:
    """Возвращает текст предупреждения, если файл с секретами доступен не
    только владельцу. Хостинг общий: ключ, который может прочитать любой
    процесс на машине, надо считать утёкшим."""
    try:
        mode = path.stat().st_mode
    except OSError:
        return None
    if mode & (stat.S_IROTH | stat.S_IWOTH):
        return (f"Файл с ключом {path} доступен всем на чтение — на общем хостинге "
                f"это утечка ключа. Исправьте: chmod 600 {path}")
    if mode & (stat.S_IRGRP | stat.S_IWGRP):
        return (f"Файл с ключом {path} доступен группе; безопаснее chmod 600 {path}")
    return None


def load_credentials(path=None) -> dict:
    """Читает JSON с ключом (и, если нужно, с адресом прокси и моделью).

    Порядок поиска: явный путь -> переменная окружения
    ANTHROPIC_CREDENTIALS_FILE -> DEFAULT_CREDENTIALS_FILES. Сам ключ
    через окружение НЕ ищем: его туда кладёт только человек вручную для
    отладки, в бою это делает файл (см. шапку файла)."""
    candidates = []
    if path:
        candidates.append(str(path))
    else:
        env_path = os.environ.get("ANTHROPIC_CREDENTIALS_FILE")
        if env_path:
            candidates.append(env_path)
        candidates.extend(DEFAULT_CREDENTIALS_FILES)

    for candidate in candidates:
        found = Path(candidate)
        if found.is_file():
            break
    else:
        raise AnthropicConfigError(
            "Не найден файл с ключом Anthropic. Ожидался один из путей: "
            + ", ".join(candidates)
            + ". Он создаётся вручную на сервере выше корня сайта, права 600, "
              "формат: {\"api_key\": \"sk-ant-...\", \"proxy\": \"socks5h://...\"}")

    warning = _check_file_mode(found)

    try:
        with found.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
    except (OSError, ValueError) as exc:
        # Текст ошибки json может содержать фрагмент строки с ключом —
        # поэтому сообщаем только сам факт и путь, без подробностей.
        raise AnthropicConfigError(f"Не удалось прочитать {found}: файл повреждён или недоступен "
                             f"({type(exc).__name__}).") from exc

    if not isinstance(data, dict):
        raise AnthropicConfigError(f"В {found} ожидался объект JSON с полем api_key.")

    api_key = (data.get("api_key") or "").strip()
    if not api_key:
        raise AnthropicConfigError(f"В {found} нет непустого поля api_key.")
    if not api_key.startswith("sk-"):
        raise AnthropicConfigError(
            f"В {found} поле api_key не похоже на ключ Anthropic (ключ начинается с sk-). "
            "Проверьте, что в файл попал сам ключ, а не подсказка вроде <ВАШ_КЛЮЧ>.")
    if not _KEY_RE.fullmatch(api_key):
        # Ключ состоит только из латиницы, цифр, «-» и «_». Пробел внутри,
        # перевод строки или невидимый символ, прилипший при копировании,
        # API считает другим ключом и отвечает 401 — понятнее сказать здесь.
        # Сам ключ (даже кусок) в сообщение не попадает.
        raise AnthropicConfigError(
            f"В {found} в поле api_key есть посторонние символы (пробел внутри, перевод "
            f"строки или невидимый символ; длина {len(api_key)}, у ключа Anthropic обычно "
            "108). Скопируйте ключ из консоли Anthropic заново.")

    result = {
        "api_key": api_key,
        "proxy": (data.get("proxy") or "").strip() or None,
        "model": (data.get("model") or "").strip() or None,
        # Вторая, более дешёвая модель для однотипной массовой работы —
        # какой именно, решает вызывающий код (транспорт про это не знает).
        "model_secondary": (data.get("model_secondary") or "").strip() or None,
        # Модель для сверки позиций с базой 1С (common/claude_matcher.py) —
        # там свой выбор по умолчанию, поле нужно только чтобы его сменить.
        "model_matching": (data.get("model_matching") or "").strip() or None,
        # Модель чата «Ассистент» (common/web_agent_chat.py) — аналогично.
        "model_chat": (data.get("model_chat") or "").strip() or None,
        "chat_mcp_servers": data.get("chat_mcp_servers"),
        # Уровень усилия чата «Ассистент» — отдельно от общего effort: тот
        # настроен на дешёвые черновые тексты Verrata ("low"), а чату нужен
        # глубокий разбор. Пусто — значение по умолчанию из web_agent_chat.py.
        "effort_chat": (data.get("effort_chat") or "").strip() or None,
        # Модель и усилие агента РВ (program-c/rv_agent.py) — свои значения
        # по умолчанию там же; поля нужны только чтобы их сменить.
        "model_rv": (data.get("model_rv") or "").strip() or None,
        "effort_rv": (data.get("effort_rv") or "").strip() or None,
        "effort_rv_mark": (data.get("effort_rv_mark") or "").strip() or None,
        "effort": (data.get("effort") or "").strip() or None,
        # Нужен только если в системном хранилище хостинга не окажется
        # корневых сертификатов — см. _ssl_context ниже.
        "ca_bundle": (data.get("ca_bundle") or "").strip() or None,
        "path": str(found),
        "warning": warning,
    }
    return result


def _socks_connector(socks_module, host, port, username, password, rdns):
    """Подменяет фабрику сокетов у http.client: сам TLS (и проверку
    сертификата по имени api.anthropic.com) дальше делает стандартный
    HTTPSConnection.connect, мы меняем только способ добраться до хоста."""
    def create_connection(address, timeout=None, source_address=None):
        sock = socks_module.socksocket()
        sock.set_proxy(socks_module.SOCKS5, host, port, rdns=rdns,
                       username=username, password=password)
        if timeout is not None and timeout is not socket._GLOBAL_DEFAULT_TIMEOUT:
            sock.settimeout(timeout)
        if source_address:
            sock.bind(source_address)
        sock.connect(address)
        return sock
    return create_connection


def _socks_connection_class(socks_module, host, port, username, password, rdns):
    class _SocksHTTPSConnection(http.client.HTTPSConnection):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._create_connection = _socks_connector(
                socks_module, host, port, username, password, rdns)
    return _SocksHTTPSConnection


class _SocksHTTPSHandler(urllib.request.HTTPSHandler):
    def __init__(self, connection_class, context=None):
        super().__init__(context=context)
        self._connection_class = connection_class

    def https_open(self, req):
        return self.do_open(self._connection_class, req, context=self._context)


def _ssl_context(ca_bundle=None):
    """Обычная проверка сертификата api.anthropic.com по системному
    хранилищу. ca_bundle нужен, только если в системном хранилище хостинга
    корневых сертификатов нет (тогда был бы CERTIFICATE_VERIFY_FAILED) —
    проверку отключать нельзя ни в каком случае: через прокси идёт ключ."""
    if ca_bundle:
        if not Path(ca_bundle).is_file():
            raise AnthropicConfigError(f"Не найден файл сертификатов ca_bundle: {ca_bundle}")
        return ssl.create_default_context(cafile=ca_bundle)
    return ssl.create_default_context()


def build_opener(proxy_url=None, context=None, ca_bundle=None):
    """urllib-opener: напрямую, через обычный HTTP-прокси или через SOCKS5."""
    context = context or _ssl_context(ca_bundle)
    if not proxy_url:
        return urllib.request.build_opener(urllib.request.HTTPSHandler(context=context))

    parts = urllib.parse.urlsplit(proxy_url)
    scheme = (parts.scheme or "").lower()

    if scheme in ("http", "https"):
        return urllib.request.build_opener(
            urllib.request.ProxyHandler({"http": proxy_url, "https": proxy_url}),
            urllib.request.HTTPSHandler(context=context))

    if scheme not in ("socks5", "socks5h"):
        raise AnthropicConfigError(
            f"Неизвестная схема прокси {scheme!r}. Поддерживаются socks5h:// "
            "(имя хоста разрешает прокси, так настроено у нас), socks5://, http://")

    try:
        import socks  # pysocks
    except ImportError as exc:
        raise AnthropicConfigError(
            "Для SOCKS5-прокси нужен пакет pysocks. Установка на хостинге: "
            "/opt/python/python-3.8.8/bin/python3 -m pip install --user pysocks") from exc

    if not parts.hostname:
        raise AnthropicConfigError("В адресе прокси не указан хост.")
    # unquote: пароль в URL закодирован процентами, dante ждёт исходный.
    username = urllib.parse.unquote(parts.username) if parts.username else None
    password = urllib.parse.unquote(parts.password) if parts.password else None
    connection_class = _socks_connection_class(
        socks, parts.hostname, parts.port or 1080, username, password,
        rdns=(scheme == "socks5h"))
    return urllib.request.build_opener(_SocksHTTPSHandler(connection_class, context=context))


_HTTP_HINTS = {
    400: "запрос отклонён как некорректный",
    401: "неверный ключ API",
    402: "закончились средства на балансе Anthropic",
    403: "ключу запрещён этот запрос",
    404: "неизвестная модель или адрес",
    413: "запрос слишком большой",
    429: "превышен лимит запросов",
    500: "сбой на стороне Anthropic",
    529: "API Anthropic перегружен",
}


def _retry_after(headers, default_delay):
    value = headers.get("retry-after") if headers is not None else None
    try:
        delay = float(value)
    except (TypeError, ValueError):
        return default_delay
    return min(max(delay, 0.0), MAX_RETRY_DELAY_SEC)


class AnthropicClient:
    """Один экземпляр на весь прогон обработки (внутри — один opener и,
    значит, одно TLS-соединение к API через прокси).

    Ключ берётся из файла (см. load_credentials) и наружу не отдаётся:
    ни в сообщениях об ошибках, ни в логе."""

    def __init__(self, api_key=None, credentials_file=None, proxy=None, model=None,
                  model_secondary=None, effort=None, max_tokens=DEFAULT_MAX_TOKENS, timeout=DEFAULT_TIMEOUT_SEC,
                  max_retries=MAX_RETRIES, max_requests=DEFAULT_MAX_REQUESTS,
                  fallbacks=True, log=None):
        self._log = log
        creds = {}
        if not api_key:
            creds = load_credentials(credentials_file)
            api_key = creds["api_key"]
            if creds.get("warning"):
                self._note(creds["warning"])
        self._api_key = api_key
        self._proxy = proxy or creds.get("proxy")
        self.model = model or creds.get("model") or DEFAULT_MODEL
        self.model_secondary = model_secondary or creds.get("model_secondary") or None
        self.model_matching = creds.get("model_matching") or None
        self.model_chat = creds.get("model_chat") or None
        effort = effort or creds.get("effort") or DEFAULT_EFFORT
        if effort not in EFFORT_LEVELS:
            raise AnthropicConfigError(
                f"Недопустимый effort {effort!r}; допустимо: {', '.join(EFFORT_LEVELS)}")
        self.effort = effort
        self.chat_mcp_servers = creds.get("chat_mcp_servers")
        self.effort_chat = creds.get("effort_chat") or None
        if self.effort_chat is not None and self.effort_chat not in EFFORT_LEVELS:
            raise AnthropicConfigError(
                f"Недопустимый effort_chat {self.effort_chat!r}; допустимо: "
                f"{', '.join(EFFORT_LEVELS)}")
        self.model_rv = creds.get("model_rv") or None
        self.effort_rv = creds.get("effort_rv") or None
        self.effort_rv_mark = creds.get("effort_rv_mark") or None
        for field in ("effort_rv", "effort_rv_mark"):
            value = getattr(self, field)
            if value is not None and value not in EFFORT_LEVELS:
                raise AnthropicConfigError(
                    f"Недопустимый {field} {value!r}; допустимо: {', '.join(EFFORT_LEVELS)}")
        self.max_tokens = max_tokens
        self._timeout = timeout
        self._max_retries = max(1, int(max_retries))
        self._max_requests = max(1, int(max_requests))
        self._fallbacks = bool(fallbacks)
        self._opener = build_opener(self._proxy, ca_bundle=creds.get("ca_bundle"))
        # Запросы могут идти из нескольких потоков сразу (разбор листов
        # графики, см. program-b/sheet_agent.py): счётчики и предохранитель
        # меняются только под замком.
        self._lock = threading.Lock()
        self.usage = {"requests": 0, "input_tokens": 0, "output_tokens": 0,
                      "cache_read_input_tokens": 0, "cost_usd": 0.0}

    def _note(self, message):
        if self._log:
            self._log(f"[anthropic] {message}")

    # ── HTTP ──

    def _message_headers(self, payload: dict, accept: str) -> dict:
        headers = {
            "content-type": "application/json",
            "accept": accept,
            "x-api-key": self._api_key,
            "anthropic-version": API_VERSION,
        }
        betas = []
        if payload.get("fallbacks"):
            betas.append(FALLBACK_BETA)
        if payload.get("mcp_servers"):
            betas.append(MCP_BETA)
        if betas:
            headers["anthropic-beta"] = ",".join(betas)
        return headers

    def _post(self, payload: dict) -> dict:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        headers = self._message_headers(payload, "application/json")
        request = urllib.request.Request(MESSAGES_URL, data=body, method="POST", headers=headers)
        with self._opener.open(request, timeout=self._timeout) as resp:
            raw = _read_capped(resp)
        try:
            return json.loads(raw.decode("utf-8"))
        except (ValueError, UnicodeDecodeError) as exc:
            raise AnthropicError("Ответ Anthropic не разобрался как JSON.") from exc

    def _request(self, payload: dict, on_event=None) -> dict:
        """Запрос к /v1/messages: обычный или потоковый (on_event задан —
        значит поток, см. _stream)."""
        state = {"payload": payload}

        def drop_fallbacks(exc, detail):
            if not (exc.code == 400 and self._fallbacks and "fallback" in detail.lower()):
                return False
            # Серверные переходы могут быть не включены у организации или
            # не поддержаны выбранной моделью — они не обязательны,
            # отказываемся от них и повторяем.
            self._note("серверные переходы (fallbacks) не поддержаны, "
                       "повторяю запрос без них")
            self._fallbacks = False
            state["payload"] = dict(state["payload"])
            state["payload"].pop("fallbacks", None)
            return True

        if on_event is None:
            return self._with_retries(lambda: self._post(state["payload"]), drop_fallbacks)
        # Повторяется открытие потока и — один раз — ошибка в самом начале
        # потока, до первого блока ответа (перегрузка API приходит и так).
        # Ответ, оборвавшийся на середине, заново не запрашиваем: он уже
        # частично оплачен, а длинный ответ с размышлением повторно стоил
        # бы столько же.
        for attempt in (1, 2):
            resp = self._with_retries(lambda: self._open_stream(state["payload"]), drop_fallbacks)
            try:
                message = read_stream(resp, on_event)
            except AnthropicError as exc:
                if attempt == 1 and getattr(exc, "before_content", False) \
                        and exc.status in RETRY_STATUSES:
                    self._note(f"ошибка в начале потока ({exc}), повтор через "
                               f"{RETRY_BASE_DELAY_SEC:.0f} с")
                    time.sleep(RETRY_BASE_DELAY_SEC)
                    continue
                raise
            finally:
                resp.close()
            unknown = message.pop("_unknown_deltas", None)
            if unknown:
                self._note("в потоке незнакомые виды изменений блоков: " + ", ".join(unknown))
            return message
        raise AnthropicError("Anthropic API: исчерпаны повторы запроса.")

    def _open_stream(self, payload: dict):
        body = json.dumps(dict(payload, stream=True), ensure_ascii=False).encode("utf-8")
        headers = self._message_headers(payload, "text/event-stream")
        request = urllib.request.Request(MESSAGES_URL, data=body, method="POST", headers=headers)
        # timeout здесь — молчание сокета, а не длина ответа: пока модель
        # думает или идёт поиск, API шлёт в поток ping.
        return self._opener.open(request, timeout=self._timeout)

    def _with_retries(self, call, on_http_error=None) -> dict:
        """Повторы при перегрузке, лимите и сбое связи — общие для
        сообщений и для Files API. on_http_error(exc, detail) -> True
        значит «запрос поправлен, повторить сразу»."""
        delay = RETRY_BASE_DELAY_SEC
        for attempt in range(1, self._max_retries + 1):
            try:
                return call()
            except urllib.error.HTTPError as exc:
                detail = _read_capped(exc).decode("utf-8", "replace").strip()[:1000]
                if on_http_error is not None and on_http_error(exc, detail):
                    continue
                if exc.code in RETRY_STATUSES and attempt < self._max_retries:
                    wait = _retry_after(getattr(exc, "headers", None), delay)
                    self._note(f"HTTP {exc.code}, повтор через {wait:.0f} с "
                               f"(попытка {attempt} из {self._max_retries})")
                    time.sleep(wait)
                    delay = min(delay * 2, MAX_RETRY_DELAY_SEC)
                    continue
                hint = _HTTP_HINTS.get(exc.code, "запрос не удался")
                raise AnthropicError(f"Anthropic API: {hint} (HTTP {exc.code}). {detail}",
                                     status=exc.code) from exc
            except (urllib.error.URLError, socket.timeout, OSError,
                    http.client.HTTPException) as exc:
                # HTTPException — обрыв посреди ответа (IncompleteRead и
                # т.п.): это не OSError, и без него сбой связи уходил бы
                # наружу мимо AnthropicError и ронял вызывающий код.
                reason = getattr(exc, "reason", exc)
                if isinstance(reason, ssl.SSLError):
                    # Повторы тут бессмысленны: сертификат не станет
                    # доверенным со второй попытки.
                    raise AnthropicConfigError(
                        f"Не удалось проверить сертификат api.anthropic.com: {reason}. "
                        "Если в системном хранилище хостинга нет корневых сертификатов, "
                        "укажите путь к ним полем ca_bundle в файле с ключом. Проверку "
                        "сертификата отключать нельзя: через это соединение идёт ключ."
                    ) from exc
                if attempt < self._max_retries:
                    self._note(f"нет связи с API ({reason}), повтор через {delay:.0f} с")
                    time.sleep(delay)
                    delay = min(delay * 2, MAX_RETRY_DELAY_SEC)
                    continue
                raise AnthropicConnectionError(
                    f"Не удалось соединиться с Anthropic API: {reason}. "
                    "Проверьте, что виртуалка с прокси включена и dante запущен."
                ) from exc
        raise AnthropicError("Anthropic API: исчерпаны повторы запроса.")

    # ── Files API ──

    def _files_call(self, method, url, body=None, headers=None) -> dict:
        all_headers = {
            "accept": "application/json",
            "x-api-key": self._api_key,
            "anthropic-version": API_VERSION,
        }
        all_headers.update(headers or {})
        request = urllib.request.Request(url, data=body() if body else None, method=method,
                                         headers=all_headers)
        with self._opener.open(request, timeout=self._timeout) as resp:
            raw = _read_capped(resp)
        if not raw.strip():
            return {}
        try:
            return json.loads(raw.decode("utf-8"))
        except (ValueError, UnicodeDecodeError) as exc:
            raise AnthropicError("Ответ Files API не разобрался как JSON.") from exc

    def upload_file(self, path, mime_type, expires_in_seconds=FILE_EXPIRES_MAX_SEC,
                    filename=None) -> str:
        """Загружает файл с диска в Files API и возвращает его file_id.

        Файл не читается в память целиком: тело запроса идёт с диска
        кусками по мегабайту (у процессов на хостинге жёсткий лимит
        памяти).

        filename — имя файла в хранилище. Для блоков document/image оно
        не важно: модель видит название из блока сообщения (title). Для
        container_upload это имя файла в контейнере исполнения кода — там
        модель находит файл по имени, поэтому туда идёт исходное имя
        (см. common/agent_files.container_name). Если API не примет имя
        с кириллицей, файл грузится ещё раз под именем латиницей — какое имя
        в итоге у файла, возвращает upload_file_named."""
        if not filename:
            extension = os.path.splitext(path)[1].lower()
            if not re.fullmatch(r"\.[a-z0-9]{1,8}", extension):
                extension = ""
            return self._upload(path, mime_type, expires_in_seconds, "file" + extension)
        return self.upload_file_named(path, mime_type, filename, expires_in_seconds)[0]

    def upload_file_named(self, path, mime_type, filename,
                          expires_in_seconds=FILE_EXPIRES_MAX_SEC):
        """Как upload_file с именем, но возвращает (file_id, имя файла в
        хранилище): если исходное имя не принято, файл получает уникальное
        имя латиницей (file_<случайные символы>.<расширение>), и модели
        нужно сказать именно его."""
        try:
            return self._upload(path, mime_type, expires_in_seconds, filename), filename
        except AnthropicError as exc:
            # Повторяем только отказ из-за имени: файл может весить 150 МБ,
            # а с другой ошибкой второй раз он не пройдёт так же.
            if exc.status != 400 or "name" not in str(exc).lower():
                raise
            extension = os.path.splitext(filename)[1].lower()
            if not re.fullmatch(r"\.[a-z0-9]{1,8}", extension):
                extension = ""
            fallback = "file_%s%s" % (os.urandom(4).hex(), extension)
            self._note(f"Files API не принял имя файла, гружу как {fallback}: {exc}")
            return self._upload(path, mime_type, expires_in_seconds, fallback), fallback

    def _upload(self, path, mime_type, expires_in_seconds, filename) -> str:
        size = os.path.getsize(path)
        boundary = "alfastroi-" + os.urandom(12).hex()
        # Имя в заголовке части — UTF-8 как есть (RFC 7578); кавычки,
        # обратная косая и переводы строк в нём недопустимы — их здесь
        # уже нет (см. agent_files.container_name), но подстрахуемся.
        quoted = re.sub(r'["\\\r\n]', "_", filename)
        head = b""
        if expires_in_seconds:
            head += ("--%s\r\nContent-Disposition: form-data; name=\"expires_in_seconds\"\r\n\r\n"
                     "%d\r\n" % (boundary, int(expires_in_seconds))).encode("ascii")
        head += ("--%s\r\nContent-Disposition: form-data; name=\"file\"; filename=\"%s\"\r\n"
                 "Content-Type: %s\r\n\r\n" % (boundary, quoted, mime_type)).encode("utf-8")
        tail = ("\r\n--%s--\r\n" % boundary).encode("ascii")

        def body():
            yield head
            with open(path, "rb") as handle:
                while True:
                    chunk = handle.read(_UPLOAD_CHUNK)
                    if not chunk:
                        break
                    yield chunk
            yield tail

        headers = {
            "content-type": "multipart/form-data; boundary=" + boundary,
            "content-length": str(len(head) + size + len(tail)),
        }
        payload = self._with_retries(lambda: self._files_call("POST", FILES_URL, body, headers))
        file_id = payload.get("id") if isinstance(payload, dict) else None
        if not file_id:
            raise AnthropicError("Files API не вернул номер загруженного файла.")
        return file_id

    def delete_file(self, file_id) -> bool:
        """Удаляет файл из хранилища Anthropic. False — его там уже нет."""
        url = FILES_URL + "/" + urllib.parse.quote(str(file_id), safe="")
        try:
            self._with_retries(lambda: self._files_call("DELETE", url))
        except AnthropicError as exc:
            if exc.status == 404:
                return False
            raise
        return True

    def file_metadata(self, file_id) -> dict:
        """Сведения о файле: filename, mime_type, size_bytes, downloadable."""
        url = FILES_URL + "/" + urllib.parse.quote(str(file_id), safe="")
        payload = self._with_retries(lambda: self._files_call("GET", url))
        if not isinstance(payload, dict) or not payload.get("id"):
            raise AnthropicError("Files API не вернул сведения о файле.")
        return payload

    def download_file(self, file_id, dest_path, max_bytes) -> int:
        """Скачивает файл, который создала модель (исполнение кода), на диск
        кусками — в память целиком не читается. Загруженные нами файлы
        скачать нельзя (API отвечает 400) — только созданные моделью.
        Возвращает размер; больше max_bytes — ошибка, недокачанное удаляется."""
        url = (FILES_URL + "/" + urllib.parse.quote(str(file_id), safe="") + "/content")

        def call():
            request = urllib.request.Request(url, method="GET", headers={
                "x-api-key": self._api_key,
                "anthropic-version": API_VERSION,
            })
            total = 0
            try:
                with self._opener.open(request, timeout=self._timeout) as resp, \
                        open(dest_path, "wb") as handle:
                    while True:
                        chunk = resp.read(_UPLOAD_CHUNK)
                        if not chunk:
                            break
                        total += len(chunk)
                        if total > max_bytes:
                            raise AnthropicError(
                                f"Файл больше {max_bytes // (1024 * 1024)} МБ — не скачан.")
                        handle.write(chunk)
            except BaseException:
                try:
                    os.remove(dest_path)
                except OSError:
                    pass
                raise
            return total

        return self._with_retries(call)

    # ── учёт расходов ──

    def _account(self, payload: dict) -> None:
        usage = payload.get("usage") or {}
        served_model = payload.get("model") or self.model
        price_in, price_out = PRICES_USD_PER_MTOK.get(served_model, _MOST_EXPENSIVE_PRICE)
        tokens_in = int(usage.get("input_tokens") or 0)
        tokens_out = int(usage.get("output_tokens") or 0)
        cached = int(usage.get("cache_read_input_tokens") or 0)
        with self._lock:
            self.usage["input_tokens"] += tokens_in
            self.usage["output_tokens"] += tokens_out
            self.usage["cache_read_input_tokens"] += cached
            self.usage["cost_usd"] += (tokens_in * price_in + tokens_out * price_out) / 1_000_000.0

    def usage_summary(self) -> str:
        u = self.usage
        return (f"запросов {u['requests']}, токенов на входе {u['input_tokens']}, "
                f"на выходе {u['output_tokens']}, оценка расходов "
                f"${u['cost_usd']:.2f}")

    # ── публичный интерфейс ──

    def messages(self, turns: List[dict], system=None, model=None, max_tokens=None,
                  effort=None, output_schema=None, cache=False, tools=None,
                  container=None, on_event=None, mcp_servers=None) -> dict:
        """Один вызов /v1/messages. turns — список {"role": "user"|"assistant",
        "content": str}. Возвращает разобранный JSON-ответ целиком.

        tools — инструменты модели (серверные: исполнение кода, поиск и
        чтение страниц в интернете — их выполняет сам API; и свои, которые
        выполняет вызывающий код, см. common/agent_tools.py). mcp_servers —
        серверы MCP, инструменты которых объявлены в tools. container —
        id контейнера исполнения кода из прошлого ответа: файлы, созданные
        в нём, остаются доступны.

        on_event — потоковый ответ: функция получает каждое событие потока
        (текст по мере написания, начало вызова инструмента) и может
        прервать ответ исключением. Итог — то же сообщение целиком, что и
        без потока (см. read_stream). Поток нужен длинным ответам: без него
        минуты размышления — это минуты тишины в открытом соединении.

        output_schema — JSON-схема ответа (структурированный вывод): тогда
        текст ответа — гарантированно валидный JSON по ней.

        cache=True — автоматический кэш промта: API сам ставит точку кэша
        на последний блок и сдвигает её по мере роста переписки, так что
        начало длинного чата при следующем вопросе оплачивается по цене
        чтения кэша. Короткий промт (меньше порога модели) просто не
        кэшируется — ошибки нет. cache="1h" — то же, но кэш живёт час, а
        не 5 минут: запись дороже вдвое, зато большой документ в чате не
        оплачивается целиком заново, если следующий вопрос задан через
        20 минут."""
        if not turns:
            raise AnthropicError("Пустой список сообщений.")
        for turn in turns:
            if turn.get("role") not in ("user", "assistant"):
                raise AnthropicError(f"Недопустимая роль сообщения: {turn.get('role')!r}")
            content = turn.get("content")
            if isinstance(content, list):
                # Сообщение из блоков — так передаются картинки вместе с
                # вопросом (см. image_block).
                if not content or not all(isinstance(b, dict) and b.get("type") for b in content):
                    raise AnthropicError("Пустой или неправильный блок сообщения.")
                continue
            if not isinstance(content, str) or not content.strip():
                raise AnthropicError("Сообщение без текста.")
        if turns[0]["role"] != "user":
            raise AnthropicError("Первое сообщение должно быть от пользователя (role=user).")

        payload = {
            "model": model or self.model,
            "max_tokens": int(max_tokens or self.max_tokens),
            "messages": turns,
            # Размышление у fable включено всегда; параметры выборки
            # (temperature) эта модель не принимает — не передаём.
            "output_config": {"effort": effort or self.effort},
        }
        if output_schema is not None:
            payload["output_config"]["format"] = {"type": "json_schema", "schema": output_schema}
        if system:
            payload["system"] = system
        if cache:
            payload["cache_control"] = {"type": "ephemeral"}
            if cache == "1h":
                payload["cache_control"]["ttl"] = "1h"
        if tools:
            payload["tools"] = tools
        if mcp_servers:
            payload["mcp_servers"] = mcp_servers
        if container:
            payload["container"] = container
        if self._fallbacks:
            payload["fallbacks"] = [{"model": FALLBACK_MODEL}]

        with self._lock:
            if self.usage["requests"] >= self._max_requests:
                raise AnthropicError(
                    f"Превышен предохранитель: {self._max_requests} запросов к модели за "
                    "один прогон. Похоже на зацикливание — остальные запросы пропущены.")
            # Место занимается до запроса: иначе параллельные потоки
            # проскочили бы предохранитель все разом.
            self.usage["requests"] += 1

        response = self._request(payload, on_event)
        self._account(response)
        return response

    def chat_completion(self, messages: List[dict], model=None, max_tokens=None,
                         effort=None) -> str:
        """Вход — список {"role": "system"|"user"|"assistant",
        "content": str}: системные сообщения переносятся в отдельное поле
        system, как требует Anthropic API. Возвращает готовый текст
        ответа. Так с клиентом работает program-b/narrative.py."""
        system_parts = [m["content"] for m in messages
                        if m.get("role") == "system" and m.get("content")]
        turns = [{"role": m["role"], "content": m["content"]}
                 for m in messages if m.get("role") != "system"]
        response = self.messages(
            turns, system="\n\n".join(system_parts) or None,
            model=model, max_tokens=max_tokens, effort=effort)
        return extract_text(response)


# ── потоковый ответ (server-sent events) ──

# Поток с результатами поиска может быть заметно больше обычного ответа,
# но не бесконечным: больше — это сбой, а не данные (у процессов на
# хостинге жёсткий лимит памяти). Одно событие — одна строка data:; её
# предел — на случай PDF со страницы, пришедшего в ответе целиком.
MAX_STREAM_BYTES = 64 * 1024 * 1024
MAX_EVENT_BYTES = 32 * 1024 * 1024

# Тип ошибки в событии error посреди потока -> HTTP-код, по которому
# вызывающий код подбирает понятный человеку текст (как для обычных ошибок).
_STREAM_ERROR_STATUS = {
    "invalid_request_error": 400,
    "authentication_error": 401,
    "billing_error": 402,
    "permission_error": 403,
    "not_found_error": 404,
    "request_too_large": 413,
    "rate_limit_error": 429,
    "api_error": 500,
    "overloaded_error": 529,
}


class StreamAccumulator:
    """Собирает из событий потока то же сообщение, что вернул бы обычный
    запрос: блоки content по порядку, stop_reason, usage, container.

    Блоки (в том числе размышление с подписью и вызовы инструментов)
    сохраняются ровно в том виде, в каком их ждёт API, если сообщение
    нужно отправить обратно — продолжение после pause_turn и ответ на
    вызов инструмента требуют вернуть их без изменений."""

    def __init__(self):
        self.message = {"role": "assistant", "content": [], "usage": {}}
        self.blocks = {}
        self._json = {}
        self.unknown_deltas = set()
        # Вызов инструмента, оборванный по max_tokens, приходит с
        # недописанным JSON: это не сбой, а обрыв ответа — его покажет
        # stop_reason="max_tokens", а уже готовое (текст, файлы) не пропадёт.
        self.broken_json = False

    def apply(self, event: dict) -> None:
        kind = event.get("type")
        if kind == "message_start":
            message = dict(event.get("message") or {})
            message["content"] = []
            message.setdefault("usage", {})
            self.message = message
        elif kind == "content_block_start":
            index = event.get("index")
            self.blocks[index] = dict(event.get("content_block") or {})
            self._json[index] = []
        elif kind == "content_block_delta":
            self._delta(self.blocks.setdefault(event.get("index"), {}),
                        event.get("index"), event.get("delta") or {})
        elif kind == "content_block_stop":
            self._finish(event.get("index"))
        elif kind == "message_delta":
            for key, value in (event.get("delta") or {}).items():
                self.message[key] = value
            usage = event.get("usage")
            if isinstance(usage, dict):
                self.message.setdefault("usage", {}).update(usage)
        elif kind == "error":
            error = event.get("error") or {}
            exc = AnthropicError(
                "Anthropic API прервал ответ: %s" % (error.get("message") or error.get("type")),
                status=_STREAM_ERROR_STATUS.get(error.get("type")))
            # До первого блока ответа ничего не потеряно — такой запрос
            # можно повторить (см. AnthropicClient._request).
            exc.before_content = not self.blocks
            raise exc

    def _delta(self, block, index, delta):
        kind = delta.get("type")
        if kind == "text_delta":
            block["text"] = block.get("text", "") + delta.get("text", "")
        elif kind == "thinking_delta":
            block["thinking"] = block.get("thinking", "") + delta.get("thinking", "")
        elif kind == "signature_delta":
            block["signature"] = delta.get("signature", "")
        elif kind == "input_json_delta":
            self._json.setdefault(index, []).append(delta.get("partial_json", ""))
        elif kind == "citations_delta":
            citations = block.get("citations")
            if not isinstance(citations, list):
                citations = block["citations"] = []
            citations.append(delta.get("citation"))
        elif kind:
            self.unknown_deltas.add(kind)

    def _finish(self, index):
        parts = self._json.pop(index, None)
        if parts and "".join(parts).strip():
            try:
                self.blocks[index]["input"] = json.loads("".join(parts))
            except ValueError:
                self.blocks[index]["input"] = {}
                self.broken_json = True

    def result(self) -> dict:
        for index in list(self._json):
            self._finish(index)
        message = dict(self.message)
        message["content"] = [self.blocks[i] for i in sorted(self.blocks, key=lambda i: (i is None, i))]
        if self.unknown_deltas:
            message["_unknown_deltas"] = sorted(self.unknown_deltas)
        if self.broken_json and message.get("stop_reason") != "max_tokens":
            # Недописанный вызов без обрыва по длине — это уже сбой.
            raise AnthropicError("Вызов инструмента пришёл с испорченным JSON.")
        return message


def read_stream(resp, on_event=None) -> dict:
    """Читает поток событий ответа построчно (формат SSE: строки «event:» и
    «data:», событие кончается пустой строкой) и возвращает сообщение
    целиком. on_event(event, accumulator) вызывается после каждого события."""
    accumulator = StreamAccumulator()
    data_lines = []
    total = 0
    stopped = False
    while True:
        # Сетевые сбои — только здесь: исключение из on_event (например,
        # нет места на диске при записи хода работы) — не «нет связи».
        try:
            line = resp.readline(MAX_EVENT_BYTES + 1)
        except (socket.timeout, OSError, http.client.HTTPException) as exc:
            raise AnthropicConnectionError(
                f"Связь с Anthropic оборвалась посреди ответа: {exc}") from exc
        if not line:
            break
        if len(line) > MAX_EVENT_BYTES:
            raise AnthropicError("Событие потока Anthropic больше %d МБ — похоже на сбой."
                                 % (MAX_EVENT_BYTES // (1024 * 1024)))
        total += len(line)
        if total > MAX_STREAM_BYTES:
            raise AnthropicError("Поток ответа Anthropic превысил %d МБ — похоже на сбой."
                                 % (MAX_STREAM_BYTES // (1024 * 1024)))
        line = line.rstrip(b"\r\n")
        if line.startswith(b"data:"):
            data_lines.append(line[5:].lstrip(b" "))
            continue
        if line:
            continue                                  # event:, id:, комментарии
        if not data_lines:
            continue
        raw = b"\n".join(data_lines)
        data_lines = []
        try:
            event = json.loads(raw.decode("utf-8"))
        except (ValueError, UnicodeDecodeError) as exc:
            raise AnthropicError("Событие потока Anthropic не разобралось как JSON.") from exc
        if not isinstance(event, dict):
            continue
        accumulator.apply(event)
        if on_event is not None:
            on_event(event, accumulator)
        if event.get("type") == "message_stop":
            stopped = True
            break
    if not stopped:
        raise AnthropicConnectionError("Поток ответа Anthropic оборвался до конца сообщения.")
    return accumulator.result()


def image_block(data: bytes, media_type: str = "image/png") -> dict:
    """Картинка как блок сообщения. Данные уходят в теле запроса, файлы
    на диск не кладутся и по сети иначе не передаются."""
    return {
        "type": "image",
        "source": {"type": "base64", "media_type": media_type,
                   "data": base64.b64encode(data).decode("ascii")},
    }


# Предел на один запрос по документации API — 32 МБ ТЕЛА запроса. PDF
# уходит в теле в base64, а base64 раздувает данные на треть: 32 МБ тела
# это около 24 МБ самого PDF, и ещё нужно место под промт и факты.
# Отсюда 22 МБ на документ. Проверить дешевле, чем получить отказ API.
MAX_DOCUMENT_BYTES = 22 * 1024 * 1024


class DocumentTooLarge(AnthropicError):
    """PDF не влезает в один запрос."""


def document_block(data: bytes, media_type: str = "application/pdf",
                    title: str = None, cache: bool = False) -> dict:
    """PDF как блок сообщения — модель видит страницы целиком, и текстом,
    и картинкой, как видит их человек.

    cache=True помечает блок для кэша промта: один и тот же лист в
    нескольких запросах подряд (вопрос по листу, уточнение) тогда
    оплачивается по цене чтения кэша, а не полной.

    Данные уходят в теле запроса; файлы на диск не кладутся и иначе по
    сети не передаются."""
    if len(data) > MAX_DOCUMENT_BYTES:
        raise DocumentTooLarge(
            f"PDF весит {len(data) // (1024 * 1024)} МБ — в один запрос "
            f"влезает {MAX_DOCUMENT_BYTES // (1024 * 1024)} МБ")
    block = {
        "type": "document",
        "source": {"type": "base64", "media_type": media_type,
                    "data": base64.b64encode(data).decode("ascii")},
    }
    if title:
        block["title"] = title
    if cache:
        block["cache_control"] = {"type": "ephemeral"}
    return block


def extract_text(response: dict) -> str:
    """Текст из ответа: блоки размышления и служебные блоки пропускаем,
    отказ и обрыв по max_tokens отличаем от пустого ответа."""
    stop_reason = response.get("stop_reason")
    if stop_reason == "refusal":
        raise AnthropicRefusal(
            "Модель отказалась отвечать на этот запрос (stop_reason=refusal); "
            "черновой текст по этому фрагменту пропущен.")

    blocks = response.get("content")
    if not isinstance(blocks, list):
        raise AnthropicError("В ответе Anthropic нет блока content.")
    texts = [b.get("text", "") for b in blocks
             if isinstance(b, dict) and b.get("type") == "text"]
    text = "\n".join(t for t in texts if t).strip()
    if text:
        return text

    if stop_reason == "max_tokens":
        raise AnthropicError(
            "Весь бюджет max_tokens ушёл на размышление модели, текста в ответе нет — "
            "увеличьте max_tokens или понизьте effort.")
    raise AnthropicError(f"В ответе Anthropic нет текста (stop_reason={stop_reason!r}).")


def _check(argv=None):
    """Проверка связи одной командой: читает файл с ключом, идёт через
    прокси, спрашивает модель, печатает ответ и расход.

    Нужна при настройке и после смены ключа или пароля прокси. Ошибку
    печатает словами и возвращает код 2 — секреты при этом не выводятся
    ни при каком исходе.

    Запуск на сервере:
      /opt/python/python-3.8.8/bin/python3 common/anthropic_client.py \
          --credentials /var/www/u2980659/data/secrets/anthropic.json
    """
    import argparse

    parser = argparse.ArgumentParser(
        description="Проверка связи с Anthropic API (ключ читается из файла, не из аргументов)")
    parser.add_argument("--credentials", default=None,
                        help="путь к JSON с ключом; по умолчанию — путь для этого хостинга")
    parser.add_argument("--prompt", default="ответь одним словом: связь")
    parser.add_argument("--model", default=None, help="проверить другую модель")
    args = parser.parse_args(argv)

    def note(message):
        print(message, file=sys.stderr)

    try:
        client = AnthropicClient(credentials_file=args.credentials, log=note)
    except AnthropicError as exc:
        print(f"НЕ ГОТОВО: {exc}")
        return 2

    print(f"модель: {args.model or client.model}"
          + (f", через прокси: {'да' if client._proxy else 'нет'}"))
    try:
        answer = client.chat_completion(
            [{"role": "user", "content": args.prompt}], model=args.model, max_tokens=2000)
    except AnthropicError as exc:
        print(f"НЕ ГОТОВО: {exc}")
        return 2

    print(f"ответ модели: {answer}")
    print(f"расход: {client.usage_summary()}")
    print("СВЯЗЬ ЕСТЬ")
    return 0


if __name__ == "__main__":
    raise SystemExit(_check())
