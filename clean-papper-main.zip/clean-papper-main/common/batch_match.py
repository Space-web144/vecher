# -*- coding: utf-8 -*-
"""
Офлайн пакетный матчинг: Excel-спецификация → точный поиск (Tier 1,
common.matcher) по базе номенклатуры (JSON) → Excel-отчёт с результатом
по каждой строке и статистикой совпадений.

Без сервера, без БД, без сети — только локальные файлы.

Опционально подключает Tier 2 (гибридный keyword/fuzzy поиск,
common.hybrid_matcher) как fallback: для строк, где Tier 1 не нашёл точного
совпадения, вместо пустой строки — топ-N кандидатов со score, а не тишина.

Использование как CLI:
    python -m common.batch_match спецификация.xlsx номенклатура.json результат.xlsx
    python -m common.batch_match спецификация.xlsx номенклатура.json результат.xlsx --tier2

Использование как библиотеки:
    from common.batch_match import run_batch_match
    summary, results = run_batch_match("спецификация.xlsx", "номенклатура.json",
                                        output_path="результат.xlsx")
    print(summary["percent"], "% найдено")
"""

import argparse
import json
import sys

from openpyxl import load_workbook
from openpyxl.styles import PatternFill, Font, Alignment
from openpyxl.utils import get_column_letter

from common.matcher import NomenclatureIndex, determine_category
from common.hybrid_matcher import build_default_hybrid_matcher
from common.area import calculate_fitting_surface, is_fitting_row

CATEGORY_NAMES = {
    0: "Не определено",
    1: "Оборудование",
    2: "Воздуховоды",
    3: "Фасонные изделия",
    4: "Изоляция/прочее",
    5: "Крепёж",
}

GREEN_FILL = PatternFill(start_color="C6E0B4", end_color="C6E0B4", fill_type="solid")
RED_FILL = PatternFill(start_color="FCE4D6", end_color="FCE4D6", fill_type="solid")
YELLOW_FILL = PatternFill(start_color="FFF2CC", end_color="FFF2CC", fill_type="solid")
HEADER_FILL = PatternFill(start_color="DDEBF7", end_color="DDEBF7", fill_type="solid")
HEADER_FONT = Font(bold=True)
HEADER_ALIGN = Alignment(horizontal="center", vertical="center", wrap_text=True)


def load_nomenclature(path):
    """Читает справочник номенклатуры — список словарей с полем ``name``
    (формат nomenclature_alfastroy.json из matching_system: id/code/name/...)."""
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, list):
        raise ValueError(f"Ожидался список позиций в {path}, получено: {type(data)}")
    return data


def load_spec_rows(spec_path, name_col="B", model_col="C", header_row=1):
    """Читает строки спецификации: (номер_строки, наименование, тип/марка).
    По умолчанию колонки B/C, заголовок в строке 1 — как в шаблоне VentSpec
    ("Вариант 1"). header_row позволяет указать другую строку заголовка,
    если формат спецификации отличается."""
    wb = load_workbook(spec_path, read_only=True)
    ws = wb.active
    rows = []
    for row_idx in range(header_row + 1, ws.max_row + 1):
        name = ws[f"{name_col}{row_idx}"].value
        model = ws[f"{model_col}{row_idx}"].value
        if name and str(name).strip():
            rows.append((row_idx, str(name).strip(), str(model).strip() if model else ""))
    wb.close()
    return rows


def match_rows(rows, index, tier2=None, top_k_candidates=3):
    """
    Прогоняет строки через Tier 1 матчер. Если tier2 (HybridMatcher) передан
    и Tier 1 не нашёл точного совпадения — запрашивает у Tier 2 топ-N
    кандидатов со score вместо пустого результата.
    """
    results = []
    for row_idx, name, model in rows:
        category = determine_category(name, is_spec_row=True)
        match = index.find_exact(name, model, category)

        candidates = []
        if match is None and tier2 is not None:
            for material, score, _scores_dict in tier2.search(name, top_k=top_k_candidates):
                candidates.append({"code": material.get("code"), "name": material.get("name"), "score": score})

        area = calculate_fitting_surface(name) if is_fitting_row(category, name) else None

        results.append({
            "row": row_idx,
            "name": name,
            "category": category,
            "matched": match is not None,
            "code": (match or {}).get("code"),
            "matched_name": (match or {}).get("name"),
            "system": (match or {}).get("system"),
            "tier2_candidates": candidates,
            "area_m2": area,
        })
    return results


def summarize(results):
    total = len(results)
    matched = sum(1 for r in results if r["matched"])
    percent = round(matched / total * 100, 1) if total else 0.0

    tier2_offered = sum(1 for r in results if not r["matched"] and r["tier2_candidates"])
    unresolved = sum(1 for r in results if not r["matched"] and not r["tier2_candidates"])

    fitting_rows = [r for r in results if r["area_m2"] is not None]
    area_total = round(sum(r["area_m2"] for r in fitting_rows), 2)
    area_zero_count = sum(1 for r in fitting_rows if r["area_m2"] == 0)

    by_category = {}
    for r in results:
        c = by_category.setdefault(r["category"], {"total": 0, "matched": 0})
        c["total"] += 1
        c["matched"] += int(r["matched"])
    for c in by_category.values():
        c["percent"] = round(c["matched"] / c["total"] * 100, 1) if c["total"] else 0.0

    return {
        "total": total, "matched": matched, "percent": percent, "by_category": by_category,
        "tier2_offered": tier2_offered, "unresolved": unresolved,
        "fitting_rows": len(fitting_rows), "area_total_m2": area_total, "area_zero_count": area_zero_count,
    }


def write_report(spec_path, results, summary, output_path, name_col="B", header_row=1):
    """
    Копирует исходную спецификацию, дописывает справа три колонки
    (Найдено / Код / Наименование в базе, зелёная/красная заливка по
    статусу) и добавляет отдельный лист "Статистика" с процентом
    совпадений — общим и по категориям.
    """
    wb = load_workbook(spec_path)
    ws = wb.active

    name_col_idx = ws[f"{name_col}{header_row}"].column
    out_col = name_col_idx + 1
    while ws.cell(row=header_row, column=out_col).value:
        out_col += 1

    headers = ["Найдено в базе", "Код", "Наименование в базе", "Система", "Площадь, м²",
               "Tier2: код (не подтверждено)", "Tier2: наименование", "Tier2: score"]
    for offset, title in enumerate(headers):
        cell = ws.cell(row=header_row, column=out_col + offset, value=title)
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
        cell.alignment = HEADER_ALIGN

    by_row = {r["row"]: r for r in results}
    for row_idx, r in by_row.items():
        found_cell = ws.cell(row=row_idx, column=out_col, value="да" if r["matched"] else "нет")
        found_cell.fill = GREEN_FILL if r["matched"] else RED_FILL
        ws.cell(row=row_idx, column=out_col + 1, value=r["code"] or "")
        ws.cell(row=row_idx, column=out_col + 2, value=r["matched_name"] or "")
        ws.cell(row=row_idx, column=out_col + 3, value=r["system"] or "")
        if r.get("area_m2") is not None:
            ws.cell(row=row_idx, column=out_col + 4, value=r["area_m2"])

        candidates = r.get("tier2_candidates") or []
        if candidates:
            best = candidates[0]
            ws.cell(row=row_idx, column=out_col + 5, value=best["code"] or "").fill = YELLOW_FILL
            ws.cell(row=row_idx, column=out_col + 6,
                    value="; ".join(f"{c['name']} ({c['score']:.2f})" for c in candidates))
            ws.cell(row=row_idx, column=out_col + 7, value=round(best["score"], 3))

    stats = wb.create_sheet("Статистика")
    stats.append(["Показатель", "Значение"])
    for cell in stats[1]:
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
    stats.append(["Всего строк", summary["total"]])
    stats.append(["Найдено точных совпадений (Tier 1)", summary["matched"]])
    stats.append(["Процент точных совпадений", f"{summary['percent']}%"])
    stats.append(["Есть кандидаты Tier 2 (не подтверждено)", summary["tier2_offered"]])
    stats.append(["Не найдено совсем", summary["unresolved"]])
    stats.append(["Строк с расчётом площади (фасонные изделия)", summary["fitting_rows"]])
    stats.append(["Суммарная площадь, м²", summary["area_total_m2"]])
    stats.append(["  из них площадь не посчиталась (0 м²)", summary["area_zero_count"]])
    stats.append([])
    stats.append(["Категория", "Всего", "Найдено", "Процент"])
    for cell in stats[11]:
        cell.fill = HEADER_FILL
        cell.font = HEADER_FONT
    for cat, c in sorted(summary["by_category"].items()):
        stats.append([CATEGORY_NAMES.get(cat, f"Кат.{cat}"), c["total"], c["matched"], f"{c['percent']}%"])
    for col_letter in ("A", "B", "C", "D"):
        stats.column_dimensions[col_letter].width = 28

    wb.save(output_path)


def run_batch_match(spec_path, nomenclature_path, output_path=None, name_col="B", model_col="C",
                     header_row=1, index=None, tier2=None, use_tier2=False, cache_dir="data/cache",
                     top_k_candidates=3, log=None):
    """
    Полный цикл: читает спецификацию и номенклатуру, матчит, опционально
    пишет Excel-отчёт. Возвращает (summary, results).

    index    — уже построенный NomenclatureIndex (Tier 1), чтобы не
               индексировать заново при обработке нескольких спецификаций.
    tier2    — уже построенный HybridMatcher (Tier 2 fallback); если не
               передан и use_tier2=True, строится автоматически через
               build_default_hybrid_matcher(nomenclature_path, cache_dir).
    """
    if index is None:
        nomenclature = load_nomenclature(nomenclature_path)
        index = NomenclatureIndex(nomenclature, name_key="name")

    if tier2 is None and use_tier2:
        tier2 = build_default_hybrid_matcher(nomenclature_path, cache_dir=cache_dir, log=log)

    rows = load_spec_rows(spec_path, name_col, model_col, header_row)
    results = match_rows(rows, index, tier2=tier2, top_k_candidates=top_k_candidates)
    summary = summarize(results)

    if output_path:
        write_report(spec_path, results, summary, output_path, name_col, header_row)

    return summary, results


def _main():
    parser = argparse.ArgumentParser(description="Офлайн пакетный матчинг спецификации по базе номенклатуры")
    parser.add_argument("spec", help="Excel-файл спецификации (наименование в колонке B по умолчанию)")
    parser.add_argument("nomenclature", help="JSON-файл номенклатуры (список позиций с полем name)")
    parser.add_argument("output", help="Куда сохранить Excel-отчёт с результатом и статистикой")
    parser.add_argument("--name-col", default="B", help="Буква колонки с наименованием (по умолчанию B)")
    parser.add_argument("--model-col", default="C", help="Буква колонки с типом/маркой (по умолчанию C)")
    parser.add_argument("--header-row", type=int, default=1, help="Номер строки заголовка (по умолчанию 1)")
    parser.add_argument("--tier2", action="store_true",
                         help="Подключить гибридный keyword/fuzzy поиск как fallback для строк без точного совпадения")
    parser.add_argument("--cache-dir", default="data/cache", help="Папка для кэша индексов Tier 2")
    args = parser.parse_args()

    summary, _ = run_batch_match(args.spec, args.nomenclature, args.output,
                                  args.name_col, args.model_col, args.header_row,
                                  use_tier2=args.tier2, cache_dir=args.cache_dir, log=print)

    print(f"Всего строк: {summary['total']}")
    print(f"Найдено точных совпадений: {summary['matched']} ({summary['percent']}%)")
    print(f"Суммарная площадь фасонных изделий: {summary['area_total_m2']} м² "
          f"({summary['fitting_rows']} строк, из них 0 м² у {summary['area_zero_count']})")
    if args.tier2:
        print(f"Есть кандидаты Tier 2 (не подтверждено): {summary['tier2_offered']}")
        print(f"Не найдено совсем: {summary['unresolved']}")
    print("По категориям:")
    for cat, c in sorted(summary["by_category"].items()):
        print(f"  {CATEGORY_NAMES.get(cat, f'Кат.{cat}'):<20} {c['matched']}/{c['total']} ({c['percent']}%)")
    print(f"Отчёт сохранён: {args.output}")


if __name__ == "__main__":
    sys.exit(_main())
