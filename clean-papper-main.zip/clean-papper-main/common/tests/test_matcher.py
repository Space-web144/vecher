# -*- coding: utf-8 -*-
"""
Тесты common.matcher (Tier 1 — точный матчер).

Поведение сверено дифференциальным тестом против оригинального
find_1c_match из VentSpec vent_processor.py V1.9.1 (0 расхождений на ~30
запросах, включая КПВ-сверку с лишними/недостающими полями и защиту от
конфликта типоразмера крепежа). Здесь — юнит-тесты на конкретные бизнес-
правила, чтобы регрессии ловились без обращения к оригинальному коду.
"""

import unittest

from common.matcher import NomenclatureIndex, determine_category


def build_index(names):
    return NomenclatureIndex([{"name": n} for n in names], name_key="name")


class CategoryTests(unittest.TestCase):

    def test_equipment(self):
        self.assertEqual(determine_category("Диффузор тарельчатый ДПУ-100"), 1)

    def test_duct(self):
        self.assertEqual(determine_category("Воздуховод 400х200"), 2)

    def test_fitting(self):
        self.assertEqual(determine_category("Отвод 90° Ø200"), 3)

    def test_insulation(self):
        self.assertEqual(determine_category("Изоляция огнезащитная EI30"), 4)

    def test_fastener(self):
        self.assertEqual(determine_category("Гайка М8 DIN934"), 5)

    def test_undefined(self):
        self.assertEqual(determine_category("Совершенно неизвестная позиция"), 0)


class GeometricMatchTests(unittest.TestCase):

    def test_otvod_exact_match(self):
        idx = build_index(["Отвод 90° Ø200 δ=0.8", "Отвод 90° Ø200 δ=1.0"])
        found = idx.find_exact("Отвод 90° Ø200 δ=0.8")
        self.assertEqual(found["name"], "Отвод 90° Ø200 δ=0.8")

    def test_otvod_thickness_is_strict(self):
        # δ=0.8 не должен матчиться с δ=1.0 — разные изделия.
        idx = build_index(["Отвод 90° Ø200 δ=1.0"])
        self.assertIsNone(idx.find_exact("Отвод 90° Ø200 δ=0.8"))

    def test_duct_requires_length(self):
        # У воздуховода без L= сравнения быть не должно (нельзя подставить
        # произвольную длину).
        idx = build_index(["Воздуховод 400х200 L=1000"])
        self.assertIsNone(idx.find_exact("Воздуховод 400х200"))

    def test_duct_orientation_matters(self):
        # 400х200 ≠ 200х400 — переворот сечения запрещён.
        idx = build_index(["Воздуховод 400х200 L=1000"])
        self.assertIsNone(idx.find_exact("Воздуховод 200х400 L=1000"))

    def test_zaglushka_orientation_free(self):
        # У заглушки ориентация не важна: XxY = YxX.
        idx = build_index(["Заглушка 500х1200"])
        found = idx.find_exact("Заглушка 1200х500")
        self.assertEqual(found["name"], "Заглушка 500х1200")

    def test_perekhod_ends_order_free(self):
        idx = build_index(["Переход 400х300-200х100 L=300"])
        found = idx.find_exact("Переход 200х100-400х300 L=300")
        self.assertEqual(found["name"], "Переход 400х300-200х100 L=300")

    def test_no_match_returns_none_not_error(self):
        idx = build_index(["Отвод 90° Ø200"])
        self.assertIsNone(idx.find_exact("Тройник Ø160-Ø160-Ø100"))


class KpvMatchTests(unittest.TestCase):

    def setUp(self):
        self.idx = build_index([
            "Клапан противопожарный КПВ.02-НЗ-К-Ø200-MBE(230)-ВН-Г-МС",
        ])

    def test_exact_code_matches(self):
        found = self.idx.find_exact("Клапан противопожарный КПВ.02-НЗ-К-Ø200-MBE(230)-ВН-Г-МС")
        self.assertIsNotNone(found)

    def test_different_mode_rejected(self):
        # НЗ ≠ НО — разные изделия.
        self.assertIsNone(
            self.idx.find_exact("Клапан противопожарный КПВ.02-НО-К-Ø200-MBE(230)-ВН-Г-МС"))

    def test_different_section_rejected(self):
        self.assertIsNone(
            self.idx.find_exact("Клапан противопожарный КПВ.02-НЗ-К-Ø250-MBE(230)-ВН-Г-МС"))

    def test_candidate_with_extra_zk_field_rejected(self):
        # Симметричная сверка: кандидат с ЛИШНИМ полем ЗК (только для СН) при
        # отсутствии его у спеки — не должен матчиться.
        idx = build_index(["Клапан противопожарный КПВ.02-НЗ-К-Ø200-MBE(230)-СН-Г-МС-ЗК"])
        self.assertIsNone(
            idx.find_exact("Клапан противопожарный КПВ.02-НЗ-К-Ø200-MBE(230)-СН-Г-МС"))


class FastenerAndEquipmentGuardTests(unittest.TestCase):

    def test_thread_size_conflict_rejected(self):
        # М8 ≠ М10 — конфликт типоразмера, кандидат отвергается.
        idx = build_index(["Гайка М10 DIN934"])
        self.assertIsNone(idx.find_exact("Гайка М8 DIN934"))

    def test_thread_exact_match(self):
        idx = build_index(["Гайка М8 DIN934", "Гайка М10 DIN934"])
        found = idx.find_exact("Гайка М8 DIN934")
        self.assertEqual(found["name"], "Гайка М8 DIN934")

    def test_equipment_type_mismatch_rejected(self):
        # «Дроссель-клапан» ≠ «Клапан воздушный» — разные типы оборудования.
        idx = build_index(["Клапан воздушный КВ-100"])
        self.assertIsNone(idx.find_exact("Дроссель-клапан ДК-100"))

    def test_too_generic_spec_not_matched(self):
        # «Решетка декоративная» без марки и размера — слишком общая спека,
        # лучше пусто, чем случайное совпадение.
        idx = build_index(["Решетка декоративная РКДК 600х400 Виктория"])
        self.assertIsNone(idx.find_exact("Решетка декоративная"))

    def test_fire_resistance_class_distinguishes_insulation(self):
        idx = build_index(["Изоляция огнезащитная EI30 базальтовая",
                            "Изоляция огнезащитная EI60 базальтовая"])
        found = idx.find_exact("Изоляция огнезащитная EI30")
        self.assertEqual(found["name"], "Изоляция огнезащитная EI30 базальтовая")


class ArbitraryItemPayloadTests(unittest.TestCase):
    """NomenclatureIndex возвращает исходный item целиком (не только имя) —
    так вызывающий код может достать code/id для дальнейшей работы (в
    отличие от оригинального VentSpec, где матчер работал со строками)."""

    def test_returns_full_item_with_code(self):
        idx = NomenclatureIndex(
            [{"code": "БП-123", "name": "Отвод 90° Ø200", "unit": "шт"}],
            name_key="name",
        )
        found = idx.find_exact("Отвод 90° Ø200")
        self.assertEqual(found["code"], "БП-123")
        self.assertEqual(found["unit"], "шт")


if __name__ == "__main__":
    unittest.main()
