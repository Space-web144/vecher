# -*- coding: utf-8 -*-
"""Тесты common.report — построение и сохранение отчёта по сравнению с 1С."""

import os
import shutil
import tempfile
import unittest

from openpyxl import Workbook, load_workbook

from common.report import (
    build_report_rows, write_report_sheet, write_report_file, default_report_path,
)


STATS = {
    "timestamp": "2026-08-13 12:00:00",
    "spec_file": "спецификация.xlsx",
    "db_file": "номенклатура.xlsx",
    "mode_title": "СРАВНЕНИЕ С 1С",
    "proc_start": "12:00:00",
    "proc_end": "12:00:07",
    "proc_duration_sec": 7.3,
    "total": 100,
    "tier1": 70,
    "tier2": 20,
    "not_found": 10,
    "categories": {1: 15, 2: 40, 3: 35},
}


class BuildReportRowsTests(unittest.TestCase):

    def test_coverage_percent_computed_from_tier1_and_tier2(self):
        rows = dict(build_report_rows(STATS))
        self.assertEqual(rows["Покрытие, %"], 90.0)

    def test_processing_timing_included(self):
        rows = dict(build_report_rows(STATS))
        self.assertEqual(rows["Начало обработки"], "12:00:00")
        self.assertEqual(rows["Окончание обработки"], "12:00:07")
        self.assertEqual(rows["Затрачено времени, сек"], 7.3)

    def test_zero_total_does_not_divide_by_zero(self):
        rows = dict(build_report_rows({**STATS, "total": 0}))
        self.assertEqual(rows["Покрытие, %"], 0)
        self.assertEqual(rows["  Точное совпадение, %"], 0)
        self.assertEqual(rows["  Неточное совпадение (Tier 2), %"], 0)
        self.assertEqual(rows["  Отсутствие совпадения, %"], 0)

    def test_result_percentages_computed_per_bucket(self):
        rows = dict(build_report_rows(STATS))
        self.assertEqual(rows["  Точное совпадение, %"], 70.0)
        self.assertEqual(rows["  Неточное совпадение (Tier 2), %"], 20.0)
        self.assertEqual(rows["  Отсутствие совпадения, %"], 10.0)

    def test_category_breakdown_included(self):
        rows = build_report_rows(STATS)
        labels = [label for label, _ in rows]
        self.assertIn("  Оборудование", labels)
        self.assertIn("  Воздуховоды", labels)
        self.assertIn("  Фасонные изделия", labels)

    def test_total_area_omitted_when_not_provided(self):
        rows = dict(build_report_rows(STATS))
        self.assertNotIn("Суммарная площадь фасонных изделий, м²", rows)

    def test_total_area_included_when_provided(self):
        rows = dict(build_report_rows({**STATS, "total_area": 123.456}))
        self.assertEqual(rows["Суммарная площадь фасонных изделий, м²"], 123.46)


class WriteReportSheetTests(unittest.TestCase):

    def test_adds_sheet_to_existing_workbook(self):
        wb = Workbook()
        write_report_sheet(wb, STATS)
        self.assertIn("Отчёт", wb.sheetnames)
        ws = wb["Отчёт"]
        self.assertEqual(ws["A1"].value, "Отчёт по сравнению с 1С")

    def test_overwrites_existing_report_sheet(self):
        wb = Workbook()
        write_report_sheet(wb, STATS)
        write_report_sheet(wb, {**STATS, "total": 5})
        self.assertEqual(wb.sheetnames.count("Отчёт"), 1)


class WriteReportFileTests(unittest.TestCase):

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_writes_standalone_file(self):
        path = os.path.join(self.tmpdir, "отчёт.xlsx")
        write_report_file(STATS, path)
        self.assertTrue(os.path.exists(path))
        wb = load_workbook(path)
        self.assertEqual(wb.active["A1"].value, "Отчёт по сравнению с 1С")


class DefaultReportPathTests(unittest.TestCase):

    def test_derives_name_from_spec_file(self):
        path = default_report_path("C:/спец/файл.xlsx", "C:/результаты")
        self.assertTrue(os.path.basename(path).startswith("файл_отчёт_"))
        self.assertTrue(path.endswith(".xlsx"))


if __name__ == "__main__":
    unittest.main()
