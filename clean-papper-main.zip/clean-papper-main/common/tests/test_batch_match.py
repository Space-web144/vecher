# -*- coding: utf-8 -*-
"""Тесты common.batch_match — офлайн Excel-in/Excel-out пайплайн."""

import json
import os
import shutil
import tempfile
import unittest

from openpyxl import Workbook, load_workbook

from common.batch_match import run_batch_match, summarize, match_rows, load_spec_rows
from common.matcher import NomenclatureIndex
from common.keyword_search import KeywordMatcher
from common.fuzzy_search import FuzzyMatcher
from common.query_processor import QueryProcessor
from common.hybrid_matcher import HybridMatcher


NOMENCLATURE = [
    {"code": "БП-001", "name": "Отвод 90° Ø200 δ=0.8", "system": "Вентиляция"},
    {"code": "БП-002", "name": "Воздуховод 400х200 L=1000 δ=0.8", "system": "Вентиляция"},
    {"code": "БП-003", "name": "Заглушка 500х1200", "system": "Вентиляция"},
    {"code": "БП-004", "name": "Гайка М8 DIN934", "system": "Крепёж"},
]


def _make_spec_workbook(path, rows):
    """rows: список (наименование, тип/марка)."""
    wb = Workbook()
    ws = wb.active
    ws["A1"], ws["B1"], ws["C1"] = "Позиция", "Наименование", "Тип"
    for i, (name, model) in enumerate(rows, start=2):
        ws[f"A{i}"] = i - 1
        ws[f"B{i}"] = name
        ws[f"C{i}"] = model
    wb.save(path)


class BatchMatchTests(unittest.TestCase):

    def setUp(self):
        self.tmpdir = tempfile.mkdtemp()
        self.spec_path = os.path.join(self.tmpdir, "spec.xlsx")
        self.nomen_path = os.path.join(self.tmpdir, "nomenclature.json")
        self.output_path = os.path.join(self.tmpdir, "result.xlsx")

        _make_spec_workbook(self.spec_path, [
            ("Отвод 90° Ø200 δ=0.8", ""),          # найдётся
            ("Воздуховод 400х200 L=1000 δ=0.8", ""),  # найдётся
            ("Заглушка 1200х500", ""),              # найдётся (ориентация не важна)
            ("Гайка М8 DIN934", ""),                # найдётся
            ("Совершенно неизвестная позиция", ""),  # не найдётся
        ])
        with open(self.nomen_path, "w", encoding="utf-8") as f:
            json.dump(NOMENCLATURE, f, ensure_ascii=False)

    def tearDown(self):
        shutil.rmtree(self.tmpdir, ignore_errors=True)

    def test_summary_percent(self):
        summary, results = run_batch_match(self.spec_path, self.nomen_path)
        self.assertEqual(summary["total"], 5)
        self.assertEqual(summary["matched"], 4)
        self.assertEqual(summary["percent"], 80.0)

    def test_matched_codes_are_correct(self):
        _, results = run_batch_match(self.spec_path, self.nomen_path)
        by_name = {r["name"]: r for r in results}
        self.assertEqual(by_name["Отвод 90° Ø200 δ=0.8"]["code"], "БП-001")
        self.assertEqual(by_name["Заглушка 1200х500"]["code"], "БП-003")
        self.assertFalse(by_name["Совершенно неизвестная позиция"]["matched"])
        self.assertIsNone(by_name["Совершенно неизвестная позиция"]["code"])

    def test_report_file_is_created_with_columns_and_stats_sheet(self):
        summary, _ = run_batch_match(self.spec_path, self.nomen_path, output_path=self.output_path)
        self.assertTrue(os.path.exists(self.output_path))

        wb = load_workbook(self.output_path)
        self.assertIn("Статистика", wb.sheetnames)

        ws = wb.active
        headers = [c.value for c in ws[1]]
        self.assertIn("Найдено в базе", headers)
        self.assertIn("Код", headers)

        found_col = headers.index("Найдено в базе") + 1
        code_col = headers.index("Код") + 1
        self.assertEqual(ws.cell(row=2, column=found_col).value, "да")
        self.assertEqual(ws.cell(row=2, column=code_col).value, "БП-001")
        self.assertEqual(ws.cell(row=6, column=found_col).value, "нет")

        stats = wb["Статистика"]
        stats_values = [row[1].value for row in stats.iter_rows(min_row=2, max_row=3)]
        self.assertEqual(stats_values, [5, 4])

    def test_original_spec_columns_untouched(self):
        run_batch_match(self.spec_path, self.nomen_path, output_path=self.output_path)
        wb = load_workbook(self.output_path)
        ws = wb.active
        self.assertEqual(ws["B2"].value, "Отвод 90° Ø200 δ=0.8")
        self.assertEqual(ws["B1"].value, "Наименование")

    def test_tier2_fallback_offers_candidate_instead_of_blank(self):
        qp = QueryProcessor()
        km = KeywordMatcher(query_processor=qp)
        km.initialize(self.nomen_path, cache_dir=os.path.join(self.tmpdir, "cache_kw"))
        fm = FuzzyMatcher()
        fm.initialize(self.nomen_path, cache_dir=os.path.join(self.tmpdir, "cache_fz"))
        tier2 = HybridMatcher(keyword_matcher=km, fuzzy_matcher=fm)

        summary, results = run_batch_match(self.spec_path, self.nomen_path,
                                            output_path=self.output_path, tier2=tier2)

        # "Совершенно неизвестная позиция" всё ещё не находит ничего разумного
        # (нет пересечения слов) — но должна получить шанс через Tier 2, а не
        # автоматически считаться найденной.
        unresolved_or_candidate = [r for r in results if r["name"] == "Совершенно неизвестная позиция"][0]
        self.assertFalse(unresolved_or_candidate["matched"])

        self.assertEqual(summary["matched"], 4)
        self.assertEqual(summary["tier2_offered"] + summary["unresolved"], 1)

        wb = load_workbook(self.output_path)
        ws = wb.active
        headers = [c.value for c in ws[1]]
        self.assertIn("Tier2: код (не подтверждено)", headers)


if __name__ == "__main__":
    unittest.main()
