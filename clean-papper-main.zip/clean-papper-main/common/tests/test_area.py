# -*- coding: utf-8 -*-
"""
Тесты common.area — расчёт площади фасонных изделий, порт FasonkaMath из VentSpec.

Сверено дифференциальным тестом против оригинала (0 расхождений на 25
наименованиях + 7 контрольных замерах из журнала версий V1.9.1). Здесь —
контрольные замеры как юнит-тесты, чтобы регрессии ловились без обращения
к оригинальному коду.
"""

import unittest

from common.area import FasonkaMath, calculate_fitting_surface, get_fitting_type, is_fitting_row


class CalibratedFormulaTests(unittest.TestCase):
    """Контрольные замеры сверены с калькулятором wentprom.ru/software."""

    def test_incut_straight_rect(self):
        self.assertEqual(FasonkaMath.incut_straight_rect_area(1200, 2200, 100), 0.68)

    def test_cap_rect(self):
        self.assertEqual(FasonkaMath.cap_rect_area(1200, 500), 0.68)

    def test_incut_straight_round(self):
        self.assertEqual(FasonkaMath.incut_straight_round_area(1000, 500), 1.57)

    def test_tee_round_rect(self):
        self.assertEqual(FasonkaMath.tee_round_rect_area(1000, 1000, 500, 500, 100), 3.34)

    def test_offset_rect(self):
        self.assertEqual(FasonkaMath.offset_rect_area(1000, 1000, 1000, 0), 4.40)

    def test_collar_round(self):
        self.assertEqual(FasonkaMath.collar_round_area(1000, 500, 100), 0.75)

    def test_collar_rect(self):
        self.assertEqual(FasonkaMath.collar_rect_area(500, 500, 1000, 100), 0.83)


class DispatchTests(unittest.TestCase):

    def test_otvod_round(self):
        self.assertEqual(calculate_fitting_surface("Отвод 90° Ø200 δ=0.8"), 0.3)

    def test_otvod_explicit_angle_outside_site_set_returns_zero(self):
        # Источник считает только 15/30/45/60/90. Угол без "°"/"град" вне
        # этого набора не распознаётся вовсе и откатывается на 90 по
        # умолчанию (см. common.parameters.extract_angle) — площадь всё
        # равно считается. А вот ЯВНО указанный "77°" — угол распознан,
        # но он вне набора источника, поэтому площадь не считается.
        self.assertEqual(calculate_fitting_surface("Отвод 77° Ø160"), 0)
        self.assertEqual(calculate_fitting_surface("Отвод 75 Ø160"), 0.21)

    def test_zaglushka_orientation_free(self):
        self.assertEqual(calculate_fitting_surface("Заглушка 500х1200"),
                          calculate_fitting_surface("Заглушка 1200х500"))

    def test_flat_plate_incut_not_calculated(self):
        self.assertEqual(calculate_fitting_surface("Врезка в прямоугольную плоскость 500х500"), 0)

    def test_duck_without_shift_not_calculated(self):
        self.assertEqual(calculate_fitting_surface("Утка прямоугольная 1000х1000 L=1000"), 0)

    def test_no_formula_types_return_zero(self):
        for name in ("Адаптер переходной 400х75", "Фланец Ø200", "Ниппель Ø100"):
            self.assertEqual(calculate_fitting_surface(name), 0)

    def test_unrelated_row_returns_zero_not_error(self):
        self.assertEqual(calculate_fitting_surface("Решетка декоративная 200х200"), 0)

    def test_combined_transition_with_straight_run(self):
        area = calculate_fitting_surface(
            "Переход Ø128-Ø100 L=200мм совместно с прямым участком 400х200 L=100мм")
        self.assertEqual(area, 0.23)

    def test_get_fitting_type_head_word_only(self):
        # "Адаптер ... с врезкой" не должен определяться как ВРЕЗКА —
        # тип берётся по головному слову, не по вхождению где угодно.
        st, _reason = get_fitting_type("Адаптер плоский с врезкой 400х75")
        self.assertIsNone(st)

    def test_is_fitting_row_duck_included_via_category_3_exception(self):
        # УТКА не попадает в категорию 3 (determine_category её не знает),
        # но is_fitting_row всё равно должен включить её в расчёт площади.
        self.assertTrue(is_fitting_row(category=0, text="Утка прямоугольная 1000х1000 L=1000 смещ.300"))
        self.assertTrue(is_fitting_row(category=3, text="Отвод 90° Ø200"))
        self.assertFalse(is_fitting_row(category=1, text="Диффузор тарельчатый"))


if __name__ == "__main__":
    unittest.main()
