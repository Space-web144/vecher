# -*- coding: utf-8 -*-
"""Тесты common.two_tier.TwoTierMatcher."""

import json
import os
import shutil
import tempfile
import unittest

from common.matcher import NomenclatureIndex
from common.keyword_search import KeywordMatcher
from common.fuzzy_search import FuzzyMatcher
from common.query_processor import QueryProcessor
from common.hybrid_matcher import HybridMatcher
from common.two_tier import TwoTierMatcher


NOMENCLATURE = [
    {"code": "A1", "name": "Отвод 90° Ø200 δ=0.8", "search_text": "Отвод 90° Ø200 δ=0.8", "system": "Вентиляция"},
    {"code": "A2", "name": "Воздуховод круглый Ø315 L=1000мм", "search_text": "Воздуховод круглый Ø315 L=1000мм", "system": "Вентиляция"},
]


class TwoTierMatcherTests(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.tmpdir = tempfile.mkdtemp()
        json_path = os.path.join(cls.tmpdir, "nomenclature.json")
        with open(json_path, "w", encoding="utf-8") as f:
            json.dump(NOMENCLATURE, f, ensure_ascii=False)

        cls.tier1 = NomenclatureIndex(NOMENCLATURE, name_key="name")

        qp = QueryProcessor()
        km = KeywordMatcher(query_processor=qp)
        km.initialize(json_path, cache_dir=os.path.join(cls.tmpdir, "cache_kw"))
        fm = FuzzyMatcher()
        fm.initialize(json_path, cache_dir=os.path.join(cls.tmpdir, "cache_fz"))
        cls.tier2 = HybridMatcher(keyword_matcher=km, fuzzy_matcher=fm)

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmpdir, ignore_errors=True)

    def test_tier1_exact_hit_short_circuits_tier2(self):
        matcher = TwoTierMatcher(self.tier1, self.tier2)
        result = matcher.match("Отвод 90° Ø200 δ=0.8")
        self.assertEqual(result["tier"], 1)
        self.assertEqual(result["item"]["code"], "A1")
        self.assertIsNone(result["candidates"])

    def test_tier1_miss_falls_back_to_tier2_candidates(self):
        matcher = TwoTierMatcher(self.tier1, self.tier2)
        # Другая толщина — Tier 1 сознательно отвергает (строгий критерий),
        # но Tier 2 должен предложить кандидата вместо тишины.
        result = matcher.match("Отвод 90° Ø200 δ=1.0")
        self.assertEqual(result["tier"], 2)
        self.assertIsNone(result["item"])
        self.assertTrue(result["candidates"])
        self.assertEqual(result["candidates"][0][0]["code"], "A1")

    def test_no_tier2_configured_returns_tier_zero(self):
        matcher = TwoTierMatcher(self.tier1, tier2=None)
        result = matcher.match("Совершенно неизвестная позиция")
        self.assertEqual(result["tier"], 0)
        self.assertIsNone(result["candidates"])


if __name__ == "__main__":
    unittest.main()
