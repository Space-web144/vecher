# -*- coding: utf-8 -*-
"""
Тесты Tier 2 (common.hybrid_matcher + common.strict_filter). Используют
keyword (BM25) + fuzzy — оба полностью офлайн и детерминированы.
"""

import json
import os
import shutil
import tempfile
import unittest

from common.keyword_search import KeywordMatcher
from common.fuzzy_search import FuzzyMatcher
from common.query_processor import QueryProcessor
from common.hybrid_matcher import HybridMatcher
from common.strict_filter import StrictParameterValidator


NOMENCLATURE = [
    {"code": "A1", "name": "Воздуховод круглый Ø200 L=1000мм δ=0.8мм оцинкованный",
     "search_text": "Воздуховод круглый Ø200 L=1000мм δ=0.8мм оцинкованный",
     "system": "Вентиляция", "systems": "Вентиляция"},
    {"code": "A2", "name": "Воздуховод круглый Ø250 L=1000мм δ=0.8мм оцинкованный",
     "search_text": "Воздуховод круглый Ø250 L=1000мм δ=0.8мм оцинкованный",
     "system": "Вентиляция", "systems": "Вентиляция"},
    {"code": "A3", "name": "Отвод 90° круглого сечения Ø200 δ=0.8мм",
     "search_text": "Отвод 90° круглого сечения Ø200 δ=0.8мм",
     "system": "Вентиляция", "systems": "Вентиляция"},
    {"code": "A4", "name": "Дроссель-клапан круглый ДКК-100",
     "search_text": "Дроссель-клапан круглый ДКК-100",
     "system": "Вентиляция", "systems": "Вентиляция"},
    {"code": "A5", "name": "Клапан воздушный КВ-100",
     "search_text": "Клапан воздушный КВ-100",
     "system": "Вентиляция", "systems": "Вентиляция"},
    {"code": "A6", "name": "Гайка оцинкованная М10 DIN 934",
     "search_text": "Гайка оцинкованная М10 DIN 934",
     "system": "Вентиляция", "systems": "Вентиляция"},
    {"code": "A7", "name": "Гайка оцинкованная М8 DIN 934",
     "search_text": "Гайка оцинкованная М8 DIN 934",
     "system": "Вентиляция", "systems": "Вентиляция"},
]


class HybridMatcherTests(unittest.TestCase):

    @classmethod
    def setUpClass(cls):
        cls.tmpdir = tempfile.mkdtemp()
        cls.json_path = os.path.join(cls.tmpdir, "nomenclature.json")
        with open(cls.json_path, "w", encoding="utf-8") as f:
            json.dump(NOMENCLATURE, f, ensure_ascii=False)

        qp = QueryProcessor()
        cls.keyword_matcher = KeywordMatcher(query_processor=qp)
        cls.keyword_matcher.initialize(cls.json_path, cache_dir=os.path.join(cls.tmpdir, "cache_kw"))
        cls.fuzzy_matcher = FuzzyMatcher()
        cls.fuzzy_matcher.initialize(cls.json_path, cache_dir=os.path.join(cls.tmpdir, "cache_fz"))
        cls.hybrid = HybridMatcher(keyword_matcher=cls.keyword_matcher, fuzzy_matcher=cls.fuzzy_matcher)

    @classmethod
    def tearDownClass(cls):
        shutil.rmtree(cls.tmpdir, ignore_errors=True)

    def _top_code(self, query, **kwargs):
        results = self.hybrid.search(query, top_k=3, **kwargs)
        self.assertTrue(results, f"пустой результат для запроса: {query}")
        return results[0][0]["code"]

    def test_exact_phrase_ranks_first(self):
        self.assertEqual(self._top_code("Воздуховод круглый Ø200 L=1000мм δ=0.8мм"), "A1")

    def test_dkk_code_normalized_to_drossel_klapan(self):
        # "ДКК-100" в query_processor разворачивается в "дроссель-клапан
        # круглый диаметр 100" — не должен путаться с обычным "клапан".
        self.assertEqual(self._top_code("Дроссель клапан круглый диаметр 100"), "A4")

    def test_thread_size_distinguishes_nuts(self):
        self.assertEqual(self._top_code("Гайка оцинкованная М8"), "A7")
        self.assertEqual(self._top_code("Гайка оцинкованная М10"), "A6")

    def test_results_are_score_sorted_descending(self):
        results = self.hybrid.search("Воздуховод круглый Ø200", top_k=5)
        scores = [r[1] for r in results]
        self.assertEqual(scores, sorted(scores, reverse=True))

    def test_scores_dict_has_component_breakdown(self):
        results = self.hybrid.search("Воздуховод круглый Ø200 L=1000мм", top_k=1)
        _material, _score, scores_dict = results[0]
        self.assertTrue({"keyword", "fuzzy"} & set(scores_dict.keys()))

    def test_batch_search_matches_single_search_top_result(self):
        queries = ["Воздуховод круглый Ø200 L=1000мм", "Гайка оцинкованная М8"]
        batch_results = self.hybrid.batch_search(queries, top_k=1, use_fuzzy=True)
        self.assertEqual(batch_results[0][0][0]["code"], "A1")
        self.assertEqual(batch_results[1][0][0]["code"], "A7")


class StrictFilterFormatTests(unittest.TestCase):
    """
    Регрессия на исправленный баг: оригинал ждал {"rules": {...}}, реальный
    JSON — плоский словарь с required_params/tolerances. Раньше это тихо
    отключало фильтр (KeyError в try/except); теперь загружается и
    применяется.
    """

    def test_validator_loads_real_config_without_error(self):
        validator = StrictParameterValidator()
        self.assertGreater(len(validator.rules), 0)
        self.assertIn('воздуховод круглого сечения', validator.rules)

    def test_diameter_mismatch_rejected_for_duct(self):
        validator = StrictParameterValidator()
        valid, reason = validator.validate_result(
            query="Воздуховод круглого сечения Ø100",
            material_name="Воздуховод круглого сечения Ø150",
            query_params={}, material_params={},
        )
        self.assertFalse(valid)
        self.assertIn("diameter", reason)

    def test_diameter_within_tolerance_accepted(self):
        validator = StrictParameterValidator()
        # tolerance для diameter у воздуховода круглого сечения = 2 (мм)
        valid, _reason = validator.validate_result(
            query="Воздуховод круглого сечения Ø100",
            material_name="Воздуховод круглого сечения Ø101",
            query_params={}, material_params={},
        )
        self.assertTrue(valid)


if __name__ == "__main__":
    unittest.main()
