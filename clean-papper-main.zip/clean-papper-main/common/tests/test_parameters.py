# -*- coding: utf-8 -*-
"""
Тесты common.parameters.

Ядро (normalize/get_strict_type/extract_sections/extract_angle/...) проверено
на примерах из докстрингов и журнала версий VentSpec vent_processor.py
V1.9.1 — поведение должно совпадать с оригиналом один в один.

Расширения (extract_dn/extract_thread/extract_fire_resistance/...) проверены
на тестовых кейсах из matching_system utils/parameter_extractor.py
(блок `if __name__ == "__main__"`).
"""

import unittest

from common import parameters as p


class NormalizeTests(unittest.TestCase):

    def test_uppercase_and_whitespace(self):
        self.assertEqual(p.normalize("  отвод   90° "), "ОТВОД 90°")

    def test_comma_to_dot(self):
        self.assertEqual(p.normalize("b=0,8"), "B=0.8")

    def test_diameter_symbols_unified(self):
        # ⌀ (U+2300) и ∅ (U+2205) должны превращаться в Ø (U+00D8), как в VentSpec 1.9.1.
        self.assertIn("Ø100", p.normalize("⌀100"))
        self.assertIn("Ø100", p.normalize("∅100"))

    def test_none_input(self):
        self.assertEqual(p.normalize(None), "")


class NormalizeDiameterTokensTests(unittest.TestCase):

    def test_various_diameter_letters_unified(self):
        for text in ("Ф8", "D8", "Ø8", "ф 8"):
            self.assertIn("Ø8", p.normalize_diameter_tokens(text))


class GetStrictTypeTests(unittest.TestCase):

    def test_vozdukhovod(self):
        self.assertEqual(p.get_strict_type("Воздуховод 400х200"), "ВОЗДУХОВОД")

    def test_otvod(self):
        self.assertEqual(p.get_strict_type("Отвод 90° Ø200"), "ОТВОД")

    def test_trojnik(self):
        self.assertEqual(p.get_strict_type("Тройник Ø160-Ø160-Ø100"), "ТРОЙНИК")

    def test_krestovina(self):
        self.assertEqual(p.get_strict_type("Крестовина 400х200"), "КРЕСТОВИНА")

    def test_strict_grammar_blocks_partial_vozdukhov(self):
        # "Воздуховоды" содержит "ВОЗДУХОВ", но не целое слово "ВОЗДУХОВОД" —
        # со strict_grammar=True (спека) не должно давать ложный тип.
        self.assertIsNone(p.get_strict_type("Воздуховоды прочие", strict_grammar=True))

    def test_no_type_found(self):
        self.assertIsNone(p.get_strict_type("Решетка декоративная"))


class ExtractAngleTests(unittest.TestCase):

    def test_explicit_grad_symbol(self):
        self.assertEqual(p.extract_angle("Отвод 90° Ø200"), 90)

    def test_explicit_grad_word(self):
        self.assertEqual(p.extract_angle("Отвод 45 град Ø200"), 45)

    def test_bare_number_from_allowed_set(self):
        self.assertEqual(p.extract_angle("Отвод 30 Ø200"), 30)

    def test_diameter_not_mistaken_for_angle(self):
        # Диаметр Ø90 не должен приниматься за угол — там нет доп. допустимого угла.
        self.assertEqual(p.extract_angle("Отвод Ø90"), 0)

    def test_length_not_mistaken_for_angle(self):
        # L=90 (длина) не должно давать угол 90.
        self.assertEqual(p.extract_angle("Патрубок L=90"), 0)

    def test_default_returned_when_absent(self):
        self.assertEqual(p.extract_angle("Заглушка 200х100", default=90), 90)


class ExtractSectionsTests(unittest.TestCase):

    def test_tee_triple(self):
        self.assertEqual(
            p.extract_sections("Тройник Ø160-Ø250-Ø160", "ТРОЙНИК"),
            [(160, 250, 160)],
        )

    def test_orientation_preserved_for_duct(self):
        # 400х200 не должно превращаться в (200, 400) — ориентация значима.
        self.assertEqual(p.extract_sections("Воздуховод 400х200", "ВОЗДУХОВОД"), [(400, 200)])

    def test_zaglushka_pair_is_sorted(self):
        # У заглушки ориентация пары не важна: XxY = YxX.
        self.assertEqual(p.extract_sections("Заглушка 500х1200", "ЗАГЛУШКА"), [(500, 1200)])
        self.assertEqual(p.extract_sections("Заглушка 1200х500", "ЗАГЛУШКА"), [(500, 1200)])

    def test_perekhod_sections_sorted(self):
        # У перехода порядок концов не важен: XxY-ZxK = ZxK-XxY.
        a = p.extract_sections("Переход 400х300-200х100", "ПЕРЕХОД")
        b = p.extract_sections("Переход 200х100-400х300", "ПЕРЕХОД")
        self.assertEqual(a, b)

    def test_small_diameter_below_threshold_dropped(self):
        # Одиночные числа < 50 не считаются диаметром (защита от ложных срабатываний).
        self.assertEqual(p.extract_sections("Отвод 45 Ø200", "ОТВОД"), [(200,)])


class ExtractThicknessLengthMaterialTests(unittest.TestCase):

    def test_delta_notation(self):
        self.assertEqual(p.extract_thickness("Воздуховод δ=0.8"), 0.8)

    def test_b_notation(self):
        self.assertEqual(p.extract_thickness("Отвод b=1.0"), 1.0)

    def test_word_form(self):
        self.assertEqual(p.extract_thickness("толщина стенки 0.9"), 0.9)

    def test_no_thickness(self):
        self.assertEqual(p.extract_thickness("Воздуховод 400х200"), 0.0)

    def test_length_l_equals(self):
        self.assertEqual(p.extract_length_mm("Патрубок L=300"), 300)

    def test_length_absent(self):
        self.assertEqual(p.extract_length_mm("Отвод 90 Ø200"), 0)

    def test_material_default_galvanized(self):
        self.assertEqual(p.extract_material("Воздуховод 400х200"), "ОЦИНКОВАННАЯ")

    def test_material_stainless(self):
        self.assertEqual(p.extract_material("Воздуховод нержавеющий"), "НЕРЖАВЕЮЩАЯ")

    def test_material_pvc(self):
        self.assertEqual(p.extract_material("Воздуховод ПВХ"), "ПВХ")


class ExtractGeometryTests(unittest.TestCase):

    def test_otvod_defaults_to_90(self):
        geom = p.extract_geometry("Отвод Ø200")
        self.assertEqual(geom["kw"], "ОТВОД")
        self.assertEqual(geom["angle"], 90)

    def test_full_combination(self):
        geom = p.extract_geometry("Воздуховод 400х200 δ=0.8 L=1000 нержавеющий")
        self.assertEqual(geom["kw"], "ВОЗДУХОВОД")
        self.assertEqual(geom["thickness"], 0.8)
        self.assertEqual(geom["length"], 1000)
        self.assertEqual(geom["material"], "НЕРЖАВЕЮЩАЯ")


class ExtensionsTests(unittest.TestCase):
    """Кейсы взяты из matching_system utils/parameter_extractor.py (тестовый блок)."""

    def test_dn_from_gost_pipe(self):
        self.assertEqual(p.extract_dn("Труба стальная электросварная DN150 ГОСТ 10704-91"), "DN150")

    def test_dn_falls_back_to_inches(self):
        # extract_dn сливает явную запись DN и вывод из дюймов в одно поле —
        # так же, как оригинальный ParameterExtractor.
        self.assertEqual(p.extract_dn('Кран шаровой 1/2"'), "DN15")

    def test_gost(self):
        self.assertEqual(p.extract_gost("Труба стальная электросварная DN150 ГОСТ 10704-91"), "ГОСТ 10704-91")

    def test_thread_simple(self):
        thread, values = p.extract_thread("Гайка оцинкованная М10 DIN 934")
        self.assertEqual(thread, "М10")
        self.assertEqual(values, ["М10"])

    def test_thread_slash_pair(self):
        thread, values = p.extract_thread("Хомут для крепления воздуховодов М8/М10 Ø250мм с рез.профилем")
        self.assertEqual(thread, "М8/М10")
        self.assertEqual(values, ["М8", "М10"])

    def test_fire_resistance(self):
        self.assertEqual(p.extract_fire_resistance("Изоляция огнезащитная EI30 базальтовый рулонный"), "EI30")
        self.assertEqual(p.extract_fire_resistance("Двухкомпонентная система огнезащиты EI150 ОБМ-5Ф"), "EI150")

    def test_inch_to_dn(self):
        dn, inch = p.extract_inch_dn('Кран шаровой 1/2"')
        self.assertEqual(dn, "DN15")
        self.assertEqual(inch, "1/2")

    def test_equipment_subtypes_diffuser(self):
        subtypes = p.extract_equipment_subtypes("Диффузор тарельчатый универсальный DVA 100")
        self.assertEqual(subtypes["diffuser_subtype"], "тарельчатый")
        self.assertEqual(subtypes["airflow_direction"], "универсальный")

    def test_article_pattern(self):
        article = p.extract_article("PatAIR-UFD-1-60-НО-315-НП-MP-2")
        self.assertTrue(article and article.startswith("PatAIR"))


if __name__ == "__main__":
    unittest.main()
