# -*- coding: utf-8 -*-
"""
Fuzzy-поиск (rapidfuzz) — порт matching_system utils/fuzzy_matcher.py.
Логика не менялась; кэш-директория — параметр вместо захардкоженного пути.
"""

import json
import os
import pickle
from typing import List, Dict, Tuple

from rapidfuzz import fuzz, process


class FuzzyMatcher:
    """Нечёткий поиск (опечатки, вариации написания)."""

    def __init__(self):
        self.nomenclature_data = []
        self.search_texts = []

    def load_nomenclature(self, json_path: str) -> bool:
        if not os.path.exists(json_path):
            return False
        with open(json_path, 'r', encoding='utf-8') as f:
            self.nomenclature_data = json.load(f)
        return True

    def prepare_search_texts(self):
        if not self.nomenclature_data:
            return False
        self.search_texts = [item.get('search_text', item.get('name', '')) for item in self.nomenclature_data]
        return True

    def build_from_items(self, items):
        """Строит индекс прямо из списка словарей в памяти, без файла и без
        кэша на диск — см. KeywordMatcher.build_from_items."""
        self.nomenclature_data = items
        self.prepare_search_texts()

    def search(self, query_text: str, top_k: int = 10, score_cutoff: float = 50.0) -> List[Tuple[Dict, float]]:
        if not self.search_texts:
            return []
        matches = process.extract(
            query_text, self.search_texts,
            scorer=fuzz.token_sort_ratio, limit=top_k, score_cutoff=score_cutoff,
        )
        return [(self.nomenclature_data[idx], score) for _text, score, idx in matches]

    def search_with_method(self, query_text: str, top_k: int = 10,
                            method: str = 'token_sort_ratio', score_cutoff: float = 50.0):
        if not self.search_texts:
            return []
        scorers = {
            'ratio': fuzz.ratio, 'partial_ratio': fuzz.partial_ratio,
            'token_sort_ratio': fuzz.token_sort_ratio, 'token_set_ratio': fuzz.token_set_ratio,
        }
        scorer = scorers.get(method, fuzz.token_sort_ratio)
        matches = process.extract(query_text, self.search_texts, scorer=scorer, limit=top_k, score_cutoff=score_cutoff)
        return [(self.nomenclature_data[idx], score, method) for _text, score, idx in matches]

    def save_index(self, cache_dir: str = 'data/cache'):
        os.makedirs(cache_dir, exist_ok=True)
        with open(os.path.join(cache_dir, 'fuzzy_texts.pkl'), 'wb') as f:
            pickle.dump(self.search_texts, f)
        with open(os.path.join(cache_dir, 'fuzzy_data.pkl'), 'wb') as f:
            pickle.dump(self.nomenclature_data, f)

    def load_index(self, cache_dir: str = 'data/cache') -> bool:
        try:
            with open(os.path.join(cache_dir, 'fuzzy_texts.pkl'), 'rb') as f:
                self.search_texts = pickle.load(f)
            with open(os.path.join(cache_dir, 'fuzzy_data.pkl'), 'rb') as f:
                self.nomenclature_data = pickle.load(f)
            return True
        except Exception:
            return False

    def initialize(self, json_path: str, cache_dir: str = 'data/cache'):
        os.makedirs(cache_dir, exist_ok=True)
        cache_exists = (os.path.exists(os.path.join(cache_dir, 'fuzzy_texts.pkl')) and
                        os.path.exists(os.path.join(cache_dir, 'fuzzy_data.pkl')))
        if cache_exists and self.load_index(cache_dir):
            return True

        if not self.load_nomenclature(json_path):
            return False
        if not self.prepare_search_texts():
            return False
        self.save_index(cache_dir)
        return True
