# -*- coding: utf-8 -*-
"""
Keyword-поиск (BM25) — порт matching_system utils/keyword_matcher.py.
Логика поиска не менялась; кэш-директория теперь параметр конструктора
вместо захардкоженного 'data/cache', а нормализация текста берёт
QueryProcessor как явную зависимость вместо импорта из корня пакета.
"""

import os
import json
import pickle
import re
import time
from collections import defaultdict
from typing import List, Dict, Tuple

import numpy as np
from rank_bm25 import BM25Okapi


class KeywordMatcher:
    """Keyword-поиск (BM25) с кэшированием и batch-обработкой."""

    def __init__(self, query_processor=None):
        self.bm25 = None
        self.materials = []
        self.tokenized_corpus = []
        self.query_processor = query_processor
        self._postings = None   # см. _scores: {слово: (номера документов, частоты)}
        self._doc_len = None

    def initialize(self, json_path: str, cache_dir: str = "data/cache"):
        os.makedirs(cache_dir, exist_ok=True)
        bm25_cache_path = os.path.join(cache_dir, 'keyword_bm25.pkl')
        materials_cache_path = os.path.join(cache_dir, 'keyword_materials.json')

        if os.path.exists(bm25_cache_path) and os.path.exists(materials_cache_path):
            with open(bm25_cache_path, 'rb') as f:
                self.bm25 = pickle.load(f)
            with open(materials_cache_path, 'r', encoding='utf-8') as f:
                self.materials = json.load(f)
        else:
            with open(json_path, 'r', encoding='utf-8') as f:
                materials = json.load(f)
            self.build_from_items(materials)
            with open(bm25_cache_path, 'wb') as f:
                pickle.dump(self.bm25, f)
            with open(materials_cache_path, 'w', encoding='utf-8') as f:
                json.dump(self.materials, f, ensure_ascii=False, indent=2)

    def build_from_items(self, items, query_processor=None):
        """Строит индекс прямо из списка словарей в памяти, без файла и без
        кэша на диск — для источников без стабильного файла-справочника
        (например, список наименований VentSpec из выгрузки/COM 1С,
        собираемый заново при каждой загрузке базы)."""
        self.materials = items
        qp = query_processor or self.query_processor
        self.tokenized_corpus = []
        for mat in self.materials:
            text = mat.get('search_text', mat['name'])
            normalized_text = qp.preprocess_for_matching(text, expand=False) if qp else text
            tokens = self._preprocess_text(normalized_text).split()
            self.tokenized_corpus.append(tokens)
        self.bm25 = BM25Okapi(self.tokenized_corpus)
        self._postings = None

    @staticmethod
    def _preprocess_text(text: str) -> str:
        text = text.lower()
        text = re.sub(r'[^\w\s]', ' ', text)
        text = re.sub(r'\s+', ' ', text)
        return text.strip()

    def _build_postings(self):
        """Обратный индекс по self.bm25.doc_freqs: для каждого слова —
        номера документов, где оно есть, и сколько раз. Строится один раз
        на базу (в т.ч. после загрузки bm25 из pickle-кэша)."""
        docs, freqs = defaultdict(list), defaultdict(list)
        for idx, doc in enumerate(self.bm25.doc_freqs):
            for word, freq in doc.items():
                docs[word].append(idx)
                freqs[word].append(freq)
        self._postings = {word: (np.array(docs[word], dtype=np.intp),
                                 np.array(freqs[word], dtype=np.int64))
                          for word in docs}
        self._doc_len = np.array(self.bm25.doc_len)

    def _scores(self, query_tokens):
        """То же, что BM25Okapi.get_scores, но без перебора всей базы.

        get_scores на каждое слово запроса обходит словари ВСЕХ документов
        в чистом Python — на базе 1С в 42 тыс. позиций это ~0,25 с на поиск
        и основная часть времени обработки спецификации. Документ без слова
        запроса получает от этого слова ровно 0.0 (частота 0 в числителе),
        поэтому вклад считается только по документам из обратного индекса —
        той же формулой, в том же порядке слов (повторы слова в запросе
        тоже считаются повторно). Итоговый массив побитово совпадает с
        get_scores, значит и сортировка в search() даёт тот же порядок
        (проверено common/tests/test_keyword_search.py)."""
        if self._postings is None:
            self._build_postings()
        bm25 = self.bm25
        score = np.zeros(bm25.corpus_size)
        for q in query_tokens:
            idf = bm25.idf.get(q) or 0
            posting = self._postings.get(q)
            if posting is None or not idf:
                continue
            idx, q_freq = posting
            doc_len = self._doc_len[idx]
            score[idx] += idf * (q_freq * (bm25.k1 + 1) /
                                 (q_freq + bm25.k1 * (1 - bm25.b + bm25.b * doc_len / bm25.avgdl)))
        return score

    def search(self, query: str, top_k: int = 10) -> List[Tuple[Dict, float]]:
        query_tokens = self._preprocess_text(query).split()
        if not query_tokens:
            return []
        scores = self._scores(query_tokens)
        top_indices = scores.argsort()[-top_k:][::-1]
        return [(self.materials[idx], float(scores[idx])) for idx in top_indices if scores[idx] > 0]

    def batch_search(self, queries: List[str], top_k: int = 10) -> List[List[Tuple[Dict, float]]]:
        return [self.search(q, top_k) for q in queries]
