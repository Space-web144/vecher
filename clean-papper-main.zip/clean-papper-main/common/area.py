# -*- coding: utf-8 -*-
"""
Расчёт площади металла фасонных изделий вентиляции (м²) — порт
VentSpec vent_processor.py V1.9.1 (FasonkaMath + calculate_fitting_surface
и весь диспетчер формул). Логика НЕ МЕНЯЛАСЬ: сверена по 18 контрольным
замерам с калькулятором-источником wentprom.ru/software — см. докстринги
отдельных формул, там же зафиксированы контрольные значения.

До этого расчёт площади умела делать только сама VentSpec (десктоп); в
общий инструмент (common.batch_match) он не был перенесён. Этот модуль
закрывает разрыв — теперь площадь можно посчитать для ЛЮБОЙ фасонной
позиции, не только внутри VentSpec.

Отличие от get_strict_type (common.matcher, используется матчером):
get_fitting_type здесь смотрит только на ГОЛОВНОЕ слово наименования —
«Адаптер … с врезкой 400х75» не должен определяться как ВРЕЗКА и получать
площадь по размерам адаптера. Трогать эту границу нельзя: расчёт площади
и матчер сознательно используют разные функции определения типа.
"""

import re
import math

from common.parameters import normalize, extract_angle

# Решения, принятые при сверке с источником (менять только по согласованию
# со сметчиком — см. журнал версий VentSpec V1.9.1):
BRANCH_LENGTH_MM = 50        # длина врезного патрубка тройника
TRANSITION_DEFAULT_L = 300   # длина перехода, если в наименовании нет L=
DUCT_DEFAULT_L = 100         # длина прямого участка в составном изделии
SITE_ANGLES = (15, 30, 45, 60, 90)   # набор углов отвода у источника

_RX_PAIR = r'(\d+)\s*[XХ×\*]\s*(\d+)'
_RX_DIAM = r'(?:Ø|D|Ф)\s*(\d+)'
_RX_LEN = r'[LЛ]\s*=\s*(\d+)'
_RX_SHIFT = r'СМЕЩ\w*\.?\s*(\d+)'
_RX_COMBINED = r'СОВМЕСТНО\s+С\s+ПРЯМЫМ\s+УЧАСТКОМ'
_RX_FLAT_PLATE = r'\bВ\s+(?:ПРЯМОУГОЛЬНУЮ|КРУГЛУЮ)\s+ПЛОСКОСТ\w*'

# Изделия, у которых формы на сайте-источнике нет — площадь не считается
# сознательно (лучше пусто, чем выдуманная методика).
_NO_FORMULA = {
    "АДАПТЕР": "формы нет у источника",
    "ПЛАСТИНА": "формы нет у источника",
    "ФЛАНЕЦ": "формы нет у источника",
    "НИППЕЛЬ": "формы нет у источника",
    "ЗОНТ": "форма есть у источника, не перенесена",
}

# Типы, которые умеет считать модуль площади — отдельно от get_strict_type
# (common.matcher): та используется матчером, эта — только здесь.
_FITTING_HEADS = (
    ("ОТВОД", r'^ОТВОД'),
    ("ПЕРЕХОД", r'^ПЕРЕХОД'),
    ("ТРОЙНИК", r'^ТРОЙНИК'),
    ("КРЕСТОВИНА", r'^КРЕСТОВИН'),
    ("ВРЕЗКА", r'^ВРЕЗК'),
    ("ЗАГЛУШКА", r'^ЗАГЛУШК'),
    ("УТКА", r'^УТК[АИ]\b'),
)


def get_fitting_type(text):
    """Тип изделия ДЛЯ РАСЧЁТА ПЛОЩАДИ — по головному слову наименования.
    Возвращает (тип, причина_пропуска). Тип None означает, что площадь не
    считается, причина поясняет почему."""
    t = normalize(text)
    if not t:
        return None, ""
    head = re.split(r'[\s,.]+', t.strip())[0]
    for kw, pattern in _FITTING_HEADS:
        if re.match(pattern, t):
            return kw, ""
    for kw, reason in _NO_FORMULA.items():
        if head.startswith(kw[:6]):
            return None, reason
    return None, "тип не распознан"


def is_fitting_row(category, text):
    """Считать ли для строки площадь. Категория 3 (фасонные изделия, common.matcher)
    — всегда; плюс утка, которую determine_category не выделяет отдельно."""
    if category == 3:
        return True
    st, _ = get_fitting_type(text)
    return st == "УТКА"


def _duct_area(text, length_mm):
    """Прямой участок: периметр × длину, без припусков."""
    rect = re.search(_RX_PAIR, text)
    diam = re.search(_RX_DIAM, text)
    if rect:
        return (int(rect.group(1)) + int(rect.group(2))) * 2 * length_mm / 1_000_000
    if diam:
        return math.pi * int(diam.group(1)) * length_mm / 1_000_000
    return 0.0


def calculate_duct_area(text):
    """Публичная обёртка над _duct_area — для самостоятельного расчёта
    площади воздуховода (инструмент Area) вне полной обработки VentSpec,
    где длина сейчас строится в формулу Excel через отдельные столбцы
    (parse_duct в vent_processor.py), а не считается тут же числом.
    Длина берётся из самого наименования (L=/Л=...); без неё посчитать
    нечего — 0, как и у calculate_fitting_surface при недостатке данных."""
    norm_text = normalize(text)
    length_match = re.search(_RX_LEN, norm_text)
    if not length_match:
        return 0.0
    return round(_duct_area(norm_text, int(length_match.group(1))), 2)


class FasonkaMath:
    @staticmethod
    def tap_round_area(diameter, angle):
        element_number = 2 if angle in [90, 60] else 0
        ratios = {90: 2, 60: 3, 45: 4, 30: 6, 15: 12}
        ratio = ratios.get(angle, 2)
        neck = ((math.pi / ratio * diameter / 2) / (element_number + 2)) + 15
        section = (math.pi / ratio * diameter) / (element_number * 2 + 2)
        sq1 = math.pi * diameter / 1000 * 0.1
        sq2 = (math.pi * diameter * (2 * (neck + section / 2) + element_number * (neck + section))) / 1_000_000
        return round(sq1 + sq2, 2)

    @staticmethod
    def tap_rectangular_area(width, height, angle):
        w, h = width / 1000, height / 1000
        area = ((w + h) * 0.2 + math.pi * ((0.125 + w)**2 - 0.125**2) * angle * 2 / 360
                + math.pi * 0.125 * angle * h / 180 + math.pi * (0.125 + w) * angle * h / 180)
        return round(area, 2)

    @staticmethod
    def transition_round_round_area(d1, d2, length):
        d1, d2, l = d1 / 1000, d2 / 1000, length / 1000
        return round(math.pi * math.sqrt(l**2 + ((d1 - d2) / 2)**2) * (d1 / 2 + d2 / 2)
                     + math.pi * d1 * 0.05 + math.pi * d2 * 0.05, 2)

    @staticmethod
    def transition_rect_rect_area(w1, h1, w2, h2, length):
        w1, h1, w2, h2, l = w1/1000, h1/1000, w2/1000, h2/1000, length/1000
        ratio_w = math.sqrt(((h1 - h2) / 2)**2 + l**2)
        ratio_h = math.sqrt(((w1 - w2) / 2)**2 + l**2)
        return round(2 * (w1 + w2) / 2 * ratio_w + 2 * (h1 + h2) / 2 * ratio_h
                     + (2*w1 + 2*h1 + 2*w2 + 2*h2) * 0.05, 2)

    @staticmethod
    def transition_round_rect_area(width, height, diameter, length):
        return round((((width + height) * 2.8 + 3.14 * diameter) / 2 * length) / 1_000_000, 2)

    @staticmethod
    def incut_straight_round_area(diameter, length):
        """Врезка прямая круглая. Замер: D=1000, L=500 -> 1.57 (припуска нет)."""
        return round((diameter * math.pi * length) / 1_000_000, 2)

    @staticmethod
    def incut_straight_rect_area(width, height, length):
        """Врезка прямая прямоугольная: периметр сечения × высоту патрубка.
        Замер: A=1200, B=2200, L=100 -> 0.68."""
        return round(((width + height) * 2 * length) / 1_000_000, 2)

    @staticmethod
    def tee_round_round_area(d1, d2, length, length1):
        return round((math.pi * (d1 / 1000) * (length / 1000))
                     + (math.pi * (d2 / 1000) * (length1 / 1000)), 2)

    @staticmethod
    def tee_rect_round_area(width, height, length, diameter, length1):
        w, h, l, d, l1 = width/1000, height/1000, length/1000, diameter/1000, length1/1000
        return round(((w + h) * 2 * l) + (math.pi * d * l1) - (math.pi * d**2 / 4), 2)

    @staticmethod
    def tee_rect_rect_area(w1, h1, length, w2, h2, length1):
        w1, h1, w2, h2 = w1/1000, h1/1000, w2/1000, h2/1000
        l = length / 1000
        l1 = length1 / 1000
        return round(((w1 + h1) * 2 * l) + ((w2 + h2) * 2 * l1) - (w2 * h2), 2)

    @staticmethod
    def cap_round_area(diameter):
        d = diameter / 1000
        return round((math.pi * d**2 / 4) + (math.pi * d * 0.05), 2)

    @staticmethod
    def cap_rect_area(width, height):
        """Заглушка прямоугольная. Борт считается по ПОЛОВИНЕ периметра —
        у круглой по полной окружности. Замер: 1200х500 -> 0.68."""
        w, h = width / 1000, height / 1000
        return round((w * h) + ((w + h) * 0.05), 2)

    @staticmethod
    def tee_round_rect_area(diameter, length, width, height, length1):
        """Тройник: круглый ствол, прямоугольная врезка. При круглом стволе
        источник отверстие НЕ вычитает. Замер: D=1000,L=1000,A=500,B=500,
        L1=100 -> 3.34."""
        d, l = diameter / 1000, length / 1000
        w, h, l1 = width / 1000, height / 1000, length1 / 1000
        return round((math.pi * d * l) + ((w + h) * 2 * l1), 2)

    @staticmethod
    def offset_rect_area(width, height, length, shift):
        """Утка прямоугольного сечения со смещением в одной плоскости.
        Порядок сторон значим — сортировать пару нельзя."""
        a, b = width / 1000, height / 1000
        l, h = length / 1000, shift / 1000
        return round(2 * a * math.sqrt(l ** 2 + h ** 2)
                     + 2 * b * l
                     + (a + b) * 2 * 0.05 * 2, 2)

    @staticmethod
    def collar_round_area(d_branch, d_main, length):
        """Круглая врезка с воротником в круглую магистраль."""
        dv, dm, l = d_branch / 1000, d_main / 1000, length / 1000
        return round(math.pi * dv * l + math.pi * dm * (dv + 0.1) / 4, 2)

    @staticmethod
    def collar_rect_area(width, height, d_main, length):
        """Прямоугольная врезка с воротником в круглую магистраль. На
        воротник влияет ТОЛЬКО ширина A. Порядок сторон значим."""
        a, b = width / 1000, height / 1000
        dm, l = d_main / 1000, length / 1000
        return round((a + b) * 2 * l + math.pi * dm * (a + 0.1) / 3, 2)


def _transition_area(text, length_mm):
    """Переход: выбор ветки по тому, что найдено в ЭТОМ фрагменте строки."""
    rp = re.findall(_RX_PAIR, text)
    dd = re.findall(_RX_DIAM, text)
    if len(rp) >= 2:
        return FasonkaMath.transition_rect_rect_area(
            int(rp[0][0]), int(rp[0][1]), int(rp[1][0]), int(rp[1][1]), length_mm)
    if rp and dd:
        return FasonkaMath.transition_round_rect_area(
            int(rp[0][0]), int(rp[0][1]), int(dd[0]), length_mm)
    if len(dd) >= 2:
        return FasonkaMath.transition_round_round_area(int(dd[0]), int(dd[1]), length_mm)
    return None


def _tee_area(text):
    """Тройник и крестовина. Ствол определяется по ПОРЯДКУ записи."""
    rp = re.findall(_RX_PAIR, text)
    rp_m = re.search(_RX_PAIR, text)
    dd_m = re.search(_RX_DIAM, text)
    lm = re.search(_RX_LEN, text)
    length = int(lm.group(1)) if lm else 500
    L1 = BRANCH_LENGTH_MM

    if len(rp) >= 2:
        return FasonkaMath.tee_rect_rect_area(
            int(rp[0][0]), int(rp[0][1]), length, int(rp[1][0]), int(rp[1][1]), L1)

    if rp_m and dd_m:
        if dd_m.start() < rp_m.start():
            return FasonkaMath.tee_round_rect_area(
                int(dd_m.group(1)), length, int(rp_m.group(1)), int(rp_m.group(2)), L1)
        return FasonkaMath.tee_rect_round_area(
            int(rp_m.group(1)), int(rp_m.group(2)), length, int(dd_m.group(1)), L1)

    dd = re.findall(_RX_DIAM, text)
    if len(dd) >= 2:
        return FasonkaMath.tee_round_round_area(int(dd[0]), int(dd[1]), length, L1)
    return None


def _dispatch_fitting_area(st, text, log=None):
    """Выбор формулы по типу изделия. Возвращает площадь либо None."""
    def _log(msg):
        if log:
            log(msg)

    if st == "ОТВОД":
        angle = extract_angle(text, default=90)
        if angle not in SITE_ANGLES:
            _log(f"угол {angle}° вне набора источника, площадь не считается: {text[:60]}")
            return None
        rect = re.search(_RX_PAIR, text)
        diam = re.search(_RX_DIAM, text)
        if rect:
            return FasonkaMath.tap_rectangular_area(int(rect.group(1)), int(rect.group(2)), angle)
        if diam:
            return FasonkaMath.tap_round_area(int(diam.group(1)), angle)
        return None

    if st == "ПЕРЕХОД":
        if re.search(_RX_COMBINED, text):
            head, tail = re.split(_RX_COMBINED, text, maxsplit=1)
            l_head = re.findall(_RX_LEN, head)
            l_tail = re.findall(_RX_LEN, tail)
            if l_head:
                l_tr = int(l_head[0])
            elif len(l_tail) >= 2:
                l_tr = int(l_tail[-1])
            else:
                l_tr = TRANSITION_DEFAULT_L
            l_st = int(l_tail[0]) if l_tail else DUCT_DEFAULT_L
            tr = _transition_area(head, l_tr)
            if tr is None:
                return None
            return round(tr + _duct_area(tail, l_st), 2)

        lm = re.search(_RX_LEN, text)
        return _transition_area(text, int(lm.group(1)) if lm else TRANSITION_DEFAULT_L)

    if st == "ТРОЙНИК":
        return _tee_area(text)

    if st == "КРЕСТОВИНА":
        # Формы крестовины у источника нет — считаем как тройник по первым
        # двум сечениям (осознанное расширение, зафиксировано в VentSpec).
        return _tee_area(text)

    if st == "ВРЕЗКА":
        if re.search(_RX_FLAT_PLATE, text):
            _log(f"врезка в плоский лист — формы нет, площадь 0: {text[:60]}")
            return None
        lm = re.search(_RX_LEN, text)
        l = int(lm.group(1)) if lm else DUCT_DEFAULT_L
        diam_main = re.search(r'МАГИСТРАЛ\w*\s*(?:Ø|D|Ф)\s*(\d+)', text)
        rect = re.search(_RX_PAIR, text)
        diam = re.search(_RX_DIAM, text)
        if diam_main:
            if rect:
                return FasonkaMath.collar_rect_area(
                    int(rect.group(1)), int(rect.group(2)), int(diam_main.group(1)), l)
            if diam:
                return FasonkaMath.collar_round_area(int(diam.group(1)), int(diam_main.group(1)), l)
            return None
        if diam and not rect:
            return FasonkaMath.incut_straight_round_area(int(diam.group(1)), l)
        if rect:
            return FasonkaMath.incut_straight_rect_area(int(rect.group(1)), int(rect.group(2)), l)
        if diam:
            return FasonkaMath.incut_straight_round_area(int(diam.group(1)), l)
        return None

    if st == "ЗАГЛУШКА":
        rect = re.search(_RX_PAIR, text)
        diam = re.search(_RX_DIAM, text)
        if diam and not rect:
            return FasonkaMath.cap_round_area(int(diam.group(1)))
        if rect:
            return FasonkaMath.cap_rect_area(int(rect.group(1)), int(rect.group(2)))
        if diam:
            return FasonkaMath.cap_round_area(int(diam.group(1)))
        return None

    if st == "УТКА":
        rect = re.search(_RX_PAIR, text)
        lm = re.search(_RX_LEN, text)
        hm = re.search(_RX_SHIFT, text)
        if rect and lm and hm:
            return FasonkaMath.offset_rect_area(
                int(rect.group(1)), int(rect.group(2)), int(lm.group(1)), int(hm.group(1)))
        _log(f"утка без смещения или длины, площадь 0: {text[:60]}")
        return None

    return None


def calculate_fitting_surface(text, log=None):
    """
    Площадь фасонного изделия, м². 0 — если формулы для изделия нет или
    размеров в наименовании недостаточно. Диспетчер сверен с калькулятором
    wentprom.ru/software (см. FasonkaMath и журнал версий VentSpec V1.9.1).
    """
    def _log(msg):
        if log:
            log(msg)

    try:
        st, reason = get_fitting_type(text)
        if not st:
            if reason:
                _log(f"площадь не считается ({reason}): {normalize(text)[:70]}")
            return 0
        norm_text = normalize(text)
        area = _dispatch_fitting_area(st, norm_text, log=log)
        if area is None:
            return 0
        if area < 0:
            _log(f"отрицательная площадь, врезка крупнее ствола: {norm_text[:70]}")
            return 0
        return area
    except Exception as exc:
        _log(f"ошибка расчёта площади ({exc}): {normalize(text)[:70]}")
        return 0
