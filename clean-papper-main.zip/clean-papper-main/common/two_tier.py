# -*- coding: utf-8 -*-
"""
Двухуровневый матчер: Tier 1 (точный, common.matcher.NomenclatureIndex) +
Tier 2 (гибридный keyword/fuzzy fallback, common.hybrid_matcher.HybridMatcher).

Идея: Tier 1 почти никогда не ошибается, когда срабатывает, но либо находит
точно, либо не находит совсем. Tier 2 находит почти всегда, но с разной
степенью уверенности. Вызывая Tier 2 ТОЛЬКО когда Tier 1 не сработал,
получаем точность там, где это возможно, и подсказки (не тишину) там, где
точного совпадения по регулярным выражениям не нашлось — опечатка, другая
формулировка, синоним.
"""

from common.matcher import NomenclatureIndex, determine_category


class TwoTierMatcher:

    def __init__(self, tier1_index: NomenclatureIndex, tier2=None):
        self.tier1 = tier1_index
        self.tier2 = tier2

    def match(self, text, model="", top_k_candidates=3):
        """
        Возвращает словарь:
          tier=1, item=<найденная позиция>                    — точный матч
          tier=2, candidates=[(item, score, scores_dict), ...]  — Tier 1 не
                  нашёл, вот кандидаты от гибридного поиска (может быть [])
          tier=0, candidates=None                               — Tier 2 не
                  подключён, Tier 1 не нашёл
        """
        category = determine_category(text, is_spec_row=True)
        item = self.tier1.find_exact(text, model, category)
        if item is not None:
            return {"tier": 1, "item": item, "candidates": None}

        if self.tier2 is None:
            return {"tier": 0, "item": None, "candidates": None}

        candidates = self.tier2.search(text, top_k=top_k_candidates)
        return {"tier": 2, "item": None, "candidates": candidates}
