# -*- coding: utf-8 -*-
"""
Точный (Tier 1) матчер номенклатуры вентиляции — порт вычислительной логики
VentSpec vent_processor.py V1.9.1 (determine_category, КПВ-сверка,
геометрический/fuzzy/wordset матч, find_1c_match), построенный на общем
common.parameters.

Отличие от оригинала VentSpec: там индекс строился по плоскому списку строк
из выгрузки 1С, и результат матча — тоже строка. Здесь индекс строится по
списку словарей номенклатуры (как в matching_system: id/code/name/...),
результат — сам найденный словарь (item), чтобы можно было достать code для
дальнейшей работы (Tier 2, экспорт и т.д.).

Логика поиска НЕ ИЗМЕНЕНА относительно VentSpec — см. common/tests/
test_matcher.py, где есть дифференциальные проверки против оригинала.

Этот модуль — Tier 1 объединённого матчера: быстрый, точный, без внешних
зависимостей (никакого ML/БД/сети — чистый Python + regex, работает
полностью офлайн). Если он не находит совпадение, вызывающий код должен
передать строку дальше, в Tier 2 (гибридный поиск matching_system).
"""

import re
from collections import defaultdict

from common.parameters import (
    normalize,
    get_strict_type,
    extract_sections,
    extract_geometry,
)

# ────────────────────────────────────────────────────────────────────
# КАТЕГОРИЗАЦИЯ — порт determine_category (vent_processor.py)
# ────────────────────────────────────────────────────────────────────

_EQUIPMENT_MARKERS = [
    "ДИФФУЗОР", "РЕШЕТКА", "ДРОССЕЛЬ", "КЛАПАН", "ГИБКАЯ",
    "ШУМОГЛУШИТЕЛЬ", "ВЕНТИЛЯТОР", "СЕТКА", "ВОЗДУХОНАГРЕВАТЕЛЬ",
    "ФИЛЬТР", "СТАКАН",
]

_FASTENER_MARKERS = [
    "СКОТЧ", "ШНУР", "СКОБА", "ГАЙКА", "БОЛТ", "ШАЙБА", "ШИНА",
    "УГОЛОК", "ГЕРМЕТИК", "АНКЕР", "САМОРЕЗ", "ТРАВЕРСА", "ШПИЛЬКА",
    "ХОМУТ", "НИППЕЛЬ", "ЦАНГА", "ВИБРОРЕЗ", "ВИБРО", "АНКЕРНЫЙ", "УГФ",
    "ПРОВОЛОКА", "ШТРИПС", "ШТИФТ", "ДЮБЕЛЬ", "КРОНШТЕЙН", "ОПОРА",
]

_INSULATION_MARKERS = [
    "ИЗОЛЯЦИЯ", "ДЕТАЛИ", "ЛЕНТА", "ОКОЖУШКА",
    "ПРОТИВОМОРОЗНЫЙ", "ТЕПЛОИЗОЛЯЦИЯ", "КЛЕЕВЫЙ", "ОГНЕЗАЩИТ",
    "ГРУНТОВКА", "РАСТВОРИТЕЛЬ", "КЛЕЙ ", "ГВОЗДИ",
]

# "СОСТАВ" отдельно от списка выше: как подстрока он ловит не только
# материалы («клеевой состав», «противоморозный состав»), но и фразу
# «в составе <установки/сборки>» — то же слово в значении «входит в»,
# никак не связанном с изоляцией. Проверяем отдельно и исключаем именно
# эту фразу, а не пытаемся отличать по границе слова (это буквально одно
# и то же слово в обоих случаях).
_COMPOSITION_MARKER = "СОСТАВ"
_ASSEMBLY_MEMBERSHIP_PHRASE = "В СОСТАВЕ"

# Категории: 1=оборудование, 2=воздуховод, 3=фасонные изделия, 4=изоляция/прочее,
# 5=крепёж, 0=не определено.


def determine_category(text, is_spec_row=False):
    text_norm = normalize(text)
    if any(kw in text_norm for kw in _EQUIPMENT_MARKERS):
        return 1

    st = get_strict_type(text, strict_grammar=is_spec_row)
    if st in ["ОТВОД", "ПЕРЕХОД", "ТРОЙНИК", "ВРЕЗКА", "ЗАГЛУШКА", "КРЕСТОВИНА"]:
        return 3
    if st == "ВОЗДУХОВОД":
        return 2
    if any(kw in text_norm for kw in _FASTENER_MARKERS):
        return 5
    if any(kw in text_norm for kw in _INSULATION_MARKERS):
        return 4
    if _COMPOSITION_MARKER in text_norm and _ASSEMBLY_MEMBERSHIP_PHRASE not in text_norm:
        return 4
    return 0


# ────────────────────────────────────────────────────────────────────
# КПВ (противопожарные клапаны) — порт _kpv_* (vent_processor.py)
# ────────────────────────────────────────────────────────────────────

_KPV_ACTUATORS = ("MBE", "MBF", "BLE", "BLF", "ЭM")
_KPV_F7 = ("СН", "ВН")
_KPV_F8 = ("ВГ", "ВВ", "ГВ", "ГН", "Г")
_KPV_F9 = ("ОМС", "МС", "КЛ", "ЛС", "СЛ")

_HOMOGLYPH = str.maketrans("АВЕКМНОРСТУХ", "ABEKMHOPCTYX")


def _homoglyph_lat(s):
    return s.translate(_HOMOGLYPH)


def _kpv_clean(text):
    t = normalize(text).replace("\n", " ")
    t = re.sub(r'(?<=\d)\s+(?=\d)', '', t)
    t = re.sub(r'\s*[ХXхx×*]\s*', 'Х', t)
    return t


def _kpv_features(text):
    t = _kpv_clean(text)
    f = {}
    m = re.search(r'КПВ\W{0,2}0?([123])', t)
    if m:
        f["model"] = "КПВ" + m.group(1)
        f["ei"] = {"1": "60", "2": "90", "3": "120"}[m.group(1)]
    me = re.search(r'EI\W{0,2}(60|90|120)|(?<!\d)(60|90|120)\s*МИН', t)
    if me:
        f["ei"] = me.group(1) or me.group(2)
    if re.search(r'(?<![А-Я])НЗ(?![А-Я])', t):
        f["mode"] = "НЗ"
    elif re.search(r'(?<![А-Я])НО(?![А-Я])', t):
        f["mode"] = "НО"
    mts = re.search(r'(?<![А-Я])([КС])[\s\-]+(Ø?\d+(?:Х\d+)?)', t)
    if mts:
        f["type"] = mts.group(1)
        sec = mts.group(2)
        if "Х" in sec:
            a, b = sec.split("Х")
            f["sec"] = ("P", int(a), int(b))
        else:
            f["sec"] = ("R", int(sec.replace("Ø", "")))
    else:
        mr = re.search(r'Ø\s*(\d+)', t)
        mp = re.search(r'(\d+)Х(\d+)', t)
        if mr:
            f["sec"] = ("R", int(mr.group(1)))
        elif mp:
            f["sec"] = ("P", int(mp.group(1)), int(mp.group(2)))
    for a in _KPV_ACTUATORS:
        if re.search(r'(?<![A-ZА-Я])' + a + r'(?![A-ZА-Я])', _homoglyph_lat(t)):
            f["act"] = a
            break
    mv = re.search(r'(?:MBE|MBF|BLE|BLF|ЭM)\W{0,2}\(?(230|220|24)\)?', _homoglyph_lat(t))
    if mv:
        f["volt"] = mv.group(1)
    for x in _KPV_F7:
        if re.search(r'(?<![А-Я])' + x + r'(?![А-Я])', t):
            f["f7"] = x
            break
    for x in _KPV_F8:
        if re.search(r'(?<![А-Я])' + x + r'(?![А-Я])', t):
            f["f8"] = x
            break
    for x in _KPV_F9:
        if re.search(r'(?<![А-Я])' + x + r'(?![А-Я])', t):
            f["f9"] = x
            break
    if re.search(r'(?<![А-Я])ЗК(?![А-Я])', t):
        f["zk"] = True
    return f


def _kpv_features_match(s, d):
    """Сравнение уже готовых наборов признаков КПВ (см. _kpv_features) —
    вынесено из kpv_match(), чтобы при переборе многих кандидатов (см.
    NomenclatureIndex.kpv_index) не пересчитывать признаки одного и того
    же кандидата заново на каждый вызов — они не зависят от того, с чем
    сейчас сравниваем, и один раз посчитаны при индексации базы."""
    if not s.get("model") or not d.get("model"):
        return False
    for key in ("model", "ei", "mode", "type", "act", "volt", "f7", "f8", "f9", "sec"):
        if s.get(key) != d.get(key):
            return False
    if bool(s.get("zk")) != bool(d.get("zk")):
        return False
    return True


def kpv_match(spec_text, db_text):
    """Жёсткая симметричная сверка КПВ по коду (модель+EI, режим, тип, сечение,
    привод, напряжение, поля 7-9, ЗК). Поле 11 (К/КК) и бренд не различающие."""
    return _kpv_features_match(_kpv_features(spec_text), _kpv_features(db_text))


# ────────────────────────────────────────────────────────────────────
# ЗАЩИТА ОТ ЛОЖНЫХ ТЕКСТОВЫХ СОВПАДЕНИЙ — порт size_conflict /
# equipment_type_ok / validate_other_category_dimensions
# ────────────────────────────────────────────────────────────────────

_SIZE_FAMILIES = [
    ("M",   r'\bМ(\d+)(?:Х\d+)?\b'),
    ("NUM", r'№\s*(\d+)'),
    ("DIN", r'DIN\s*(\d+)'),
    ("DIA", r'(?:Ø|Д|Ф)\s*=?\s*(\d+)'),
]


def _size_families(text):
    t = normalize(text)
    out = {}
    for fam, pat in _SIZE_FAMILIES:
        vals = set(re.findall(pat, t))
        if vals:
            out[fam] = vals
    return out


def size_conflict(spec_text, db_text):
    """True, если спека и кандидат конфликтуют хотя бы по одному размерному
    семейству (М8≠М10, №20≠№30, DIN933≠DIN934, Ø8≠Ø10)."""
    s = _size_families(spec_text)
    d = _size_families(db_text)
    for fam, sv in s.items():
        dv = d.get(fam)
        if dv and not (sv & dv):
            return True
    return False


_GENERIC_WORDS = {"РЕШЕТКА", "РЕШЁТКА", "КЛАПАН", "ДЕКОРАТИВНАЯ", "ДЕКОРАТИВНЫЙ",
                  "ВЕНТИЛЯЦИОННАЯ", "ВЕНТИЛЯЦИОННЫЙ", "ПРОТИВОПОЖАРНЫЙ",
                  "КАНАЛЬНЫЙ", "ПРОФИЛЬ", "ТИП", "ИСПОЛНЕНИЯ", "ИСПОЛНЕНИЕ",
                  "СЕЧЕНИЯ", "СЕЧЕНИЕ", "ОБЩЕПРОМЫШЛЕННЫЙ", "ОБЩЕПРОМЫШЛЕННАЯ",
                  "СТАЛИ", "СТАЛЬ", "ОЦИНКОВАННОЙ", "ОЦИНКОВАННЫЙ", "МОНТАЖНАЯ"}


def distinctive_keywords(spec_text, spec_model=""):
    """Значимые слова спеки для текстового матча — без общих слов-типов,
    чисел и одиночных символов."""
    combined = f"{normalize(spec_text)} {normalize(spec_model or '')}".strip()
    words = set(re.findall(r'[A-ZА-Я0-9\-]+', combined))
    return {w for w in words
            if len(w) > 1 and w not in _GENERIC_WORDS and not w.replace('.', '', 1).isdigit()}


def has_size_token(text):
    """Есть ли в тексте различающий размер: AxB, Ø/Д/Ф-диаметр, М-резьба, №."""
    t = normalize(text)
    if re.search(r'\d+\s*[XХ×\*]\s*\d+', t):        return True
    if re.search(r'(?:Ø|Д|Ф)\s*=?\s*\d+', t):        return True
    if re.search(r'\bМ\d+\b', t):                    return True
    if re.search(r'№\s*\d+', t):                     return True
    return False


_EQUIP_TYPE_PRIORITY = [
    "ДРОССЕЛЬ", "ДИФФУЗОР", "ШУМОГЛУШИТЕЛЬ", "ВЕНТИЛЯТОР", "ФИЛЬТР",
    "ВОЗДУХОНАГРЕВАТЕЛЬ", "СЕТКА", "СТАКАН", "ЗОНТ", "ШИБЕР",
]


def equipment_type_ok(spec_text, db_text):
    """Тип оборудования спеки должен совпасть с типом кандидата
    («Дроссель-клапан» ≠ «Клапан воздушный»; ДРОССЕЛЬ допускает ДК)."""
    s = normalize(spec_text)
    d = normalize(db_text)
    for marker in _EQUIP_TYPE_PRIORITY:
        if marker in s:
            if marker in d:
                return True
            if marker == "ДРОССЕЛЬ" and re.search(r'(?<![А-Я])ДК(?![А-Я])', d):
                return True
            return False
        if marker in d:
            return False
    return True


def validate_other_category_dimensions(spec_text, db_text):
    """Полная проверка для категорий 1/4/5 (оборудование/изоляция/крепёж):
    КПВ — отдельная жёсткая сверка; иначе — конфликт типоразмера, тип
    оборудования, точное совпадение прямоугольных сечений и диаметров."""
    spec_text, db_text = normalize(spec_text), normalize(db_text)
    if "КПВ" in re.sub(r'[\s.]', '', spec_text):
        return kpv_match(spec_text, db_text)
    if size_conflict(spec_text, db_text):
        return False
    if not equipment_type_ok(spec_text, db_text):
        return False
    spec_rects = re.findall(r'(\d+)\s*[XХ×\*]\s*(\d+)', spec_text)
    db_rects = re.findall(r'(\d+)\s*[XХ×\*]\s*(\d+)', db_text)
    for pair in spec_rects:
        spec_sorted = sorted([int(pair[0]), int(pair[1])])
        if not any(sorted([int(d[0]), int(d[1])]) == spec_sorted for d in db_rects):
            return False
    spec_diams = re.findall(r'(?:Ø|D|Ф)\s*(\d+)', spec_text)
    if spec_diams:
        db_wo_rects = re.sub(r'\d+\s*[XХ×\*]\s*\d+', ' ', db_text)
        db_nums = set(re.findall(r'(?<!\d)(\d+)(?!\d)', db_wo_rects))
        for d in spec_diams:
            if d not in db_nums:
                return False
    return True


# Хвост вида ", в составе вентиляционной установки ПЕ4.3" встречается во
# многих строках спецификаций (комплектующие, привязанные к конкретной
# установке) — он описывает принадлежность позиции, а не саму позицию, и
# в номенклатуре 1С почти никогда не встречается дословно. Для Tier 2
# (BM25, common.hybrid_matcher) это чистый шум: лишние токены топят
# релевантность коротких точных наименований («Клапан обратный... Ø100» —
# на реальных данных score падал с 2.0 до 0.014 из-за этого хвоста, хотя
# нужный клапан есть в базе). На Tier 1 (геометрия/строгий тип выше) это
# не влияет — там боилерплейт и так не мешал.
_ASSEMBLY_MEMBERSHIP_NOTE_RE = re.compile(
    r",?\s*в\s+составе\s+вентиляционной\s+установки[^,]*",
    re.IGNORECASE,
)


def strip_assembly_membership_note(text):
    """Убирает хвост ", в составе вентиляционной установки <код>" перед
    Tier 2 поиском — см. комментарий у _ASSEMBLY_MEMBERSHIP_NOTE_RE."""
    if not text:
        return text
    return _ASSEMBLY_MEMBERSHIP_NOTE_RE.sub("", str(text)).strip()


# ────────────────────────────────────────────────────────────────────
# ИНДЕКС И ПОИСК — порт _build_indexes / execute_*_match / find_1c_match
# ────────────────────────────────────────────────────────────────────


class NomenclatureIndex:
    """
    Индексирует список позиций номенклатуры (словари с текстовым полем
    ``name_key``) и ищет точное совпадение для строки спецификации —
    воспроизводит find_1c_match из VentSpec, но работает с произвольными
    записями (не только со строками 1С) и возвращает сам найденный item,
    а не только его название.

    Полностью офлайн: без БД, без сети, без ML — только regex-логика.
    """

    def __init__(self, items, name_key="name"):
        self.name_key = name_key
        self.geo_index = defaultdict(list)
        self.text_index = defaultdict(list)
        # word_index[cat][word] -> список записей text_index[cat], где это
        # слово встречается (см. _candidates_by_rarest_word) — ускоряет
        # три прохода по категориям 1/4/5 (main loop/wordset/fuzzy_token):
        # без него на каждую нераспознанную строку уходило 3 полных
        # прохода по всей корзине (для оборудования — 9361 позиция),
        # больше секунды на строку. Выбор кандидатов через это НЕ меняет
        # результат: раз слово реально нужно для совпадения (стоит в
        # обязательных токенах), кандидат без этого слова заведомо не
        # пройдёт дальнейшую проверку — просто не тратим время на его
        # проверку в лоб.
        self.word_index = defaultdict(lambda: defaultdict(list))
        # kpv_index[cat] -> записи, у кого "КПВ" реально есть в названии
        # (без пробелов) — раньше это искалось заново на каждый вызов
        # find_exact(), проходом по ВСЕЙ корзине с созданием новой строки
        # (.replace(" ", "")) на каждую запись только чтобы отфильтровать
        # НЕ-КПВ позиции. КПВ — больше трети категории "Оборудование"
        # (3568 из 9361 в реальной базе), так что игра не в исключение
        # редких, а в то, чтобы не пересчитывать этот фильтр по 9361 раз
        # на каждую строку спецификации.
        self.kpv_index = defaultdict(list)
        self.items = []
        self._build(items)

    def _candidates_by_rarest_word(self, cat, words):
        """Из всех записей self.text_index[cat] — только те, что содержат
        САМОЕ РЕДКОЕ (по числу вхождений) слово из words. Корректно
        сужает перебор для проверок вида "все токены должны найтись у
        кандидата" (AND по словам): кандидат без хотя бы одного из них
        отсеется в любом случае, а редкое слово даёт наименьший список
        для начала. Если ни одно слово не проиндексировано (не должно
        случаться для непустых words) — отдаёт всю корзину как раньше."""
        bucket = self.word_index.get(cat)
        if not bucket:
            return self.text_index.get(cat, [])
        best = None
        for w in words:
            lst = bucket.get(w)
            if lst is not None and (best is None or len(lst) < len(best)):
                best = lst
        return best if best is not None else self.text_index.get(cat, [])

    def _text_of(self, item):
        return item[self.name_key] if isinstance(item, dict) else getattr(item, self.name_key)

    def _build(self, items):
        for item in items:
            name = self._text_of(item)
            if not name:
                continue
            geom = extract_geometry(name, is_spec_row=True)
            cat = determine_category(name, is_spec_row=True)
            entry = {"item": item, "original": name, "geom": geom, "category": cat}

            if cat in (2, 3) and geom["kw"] is not None:
                entry["_sec"] = extract_sections(name, geom["kw"], False)
                entry["_sec_sorted"] = extract_sections(name, geom["kw"], True)
                self.geo_index[(geom["kw"], geom["material"])].append(entry)
            elif cat in (1, 4, 5):
                self.text_index[cat].append(entry)
                entry["_norm"] = normalize(name)
                entry["_words"] = set(re.findall(r'[A-Z0-9А-Я\-]+', entry["_norm"]))
                for w in entry["_words"]:
                    self.word_index[cat][w].append(entry)
                if "КПВ" in entry["_norm"].replace(" ", ""):
                    entry["_kpv_feat"] = _kpv_features(entry["_norm"])
                    self.kpv_index[cat].append(entry)

            self.items.append(entry)

    # ── геометрический матч (воздуховод/фасонные изделия) ──────────────────────
    def _execute_geometric_match(self, spec_text, spec_geom, force_sort_pairs=False):
        spec_text_norm = normalize(spec_text)
        spec_sections = extract_sections(spec_text, spec_geom["kw"], force_sort_pairs=force_sort_pairs)
        is_spec_flexible = "ГИБКИ" in spec_text_norm
        field = "_sec_sorted" if force_sort_pairs else "_sec"

        candidates = self.geo_index.get((spec_geom["kw"], spec_geom["material"]), [])

        if spec_geom["kw"] == "ВОЗДУХОВОД" and spec_geom["length"] == 0:
            return None

        # Тройник и врезка без длины в спеке — в отличие от воздуховода/
        # перехода, у них нет одного НАДЁЖНО доминирующего стандартного
        # отрезка на каждый типоразмер (у тройника длина сильно зависит от
        # сечения; у врезки 100мм — самый частый вариант, но не для всех
        # размеров — конкретно проверено: 550х150 в базе есть только при
        # L=160мм) — поэтому вместо одного подставленного значения
        # собираем ВСЕХ кандидатов, подходящих по сечению+толщине, и
        # матчим только если он единственный; если вариантов длины
        # несколько — неоднозначно, честно не находим, а не берём первый
        # попавшийся (или всегда один и тот же неверный "стандарт").
        ambiguous_length = spec_geom["kw"] in ("ТРОЙНИК", "ВРЕЗКА") and spec_geom["length"] == 0
        matched = []

        for entry in candidates:
            db_geom = entry["geom"]
            db_text_norm = normalize(entry["original"])
            if is_spec_flexible != ("ГИБКИ" in db_text_norm):
                continue
            if spec_sections != entry[field]:
                continue
            if spec_geom["kw"] == "ОТВОД" and spec_geom["angle"] != db_geom["angle"]:
                continue
            if spec_geom["thickness"] > 0 and db_geom["thickness"] > 0:
                if spec_geom["thickness"] != db_geom["thickness"]:
                    continue
            if spec_geom["length"] > 0 and db_geom["length"] > 0:
                if spec_geom["length"] != db_geom["length"]:
                    continue
            if ambiguous_length:
                matched.append(entry)
                continue
            return entry["item"]

        if ambiguous_length:
            return matched[0]["item"] if len(matched) == 1 else None
        return None

    # ── fuzzy по токенам (запасной вариант для категорий 1/4/5) ────────
    def _execute_fuzzy_token_match(self, spec_text, spec_model, spec_category):
        spec_text_norm = normalize(spec_text)
        spec_model_norm = normalize(spec_model) if spec_model else ""
        combined_spec = f"{spec_text_norm} {spec_model_norm}".strip()

        if not has_size_token(combined_spec) and len(distinctive_keywords(spec_text, spec_model)) < 2:
            return None

        has_dk_spec = bool(re.search(r'\bДК\b', combined_spec))
        has_rkdk_spec = bool(re.search(r'\bРКДК\b', combined_spec))

        stop_words = {"РЕШЕТКА", "ВЕНТИЛЯЦИОННАЯ", "КЛАПАН", "ПРОТИВОПОЖАРНЫЙ",
                      "КАНАЛЬНЫЙ", "ПРОФИЛЬ", "ТИП", "ИСПОЛНЕНИЯ", "ШТ", "ММ"}
        spec_words = set(re.findall(r'[A-Z0-9А-Я\-]+', combined_spec))
        spec_keywords = {w for w in spec_words
                         if len(w) > 1 and w not in stop_words and not w.replace('.', '', 1).isdigit()}
        if not spec_keywords:
            return None

        # validate_other_category_dimensions — дорогая проверка (свои
        # регулярки на конфликт размеров/тип оборудования), а пересечение
        # слов — дешёвая (пересечение множеств). Раньше валидация
        # вызывалась для КАЖДОГО кандидата в корзине, даже для тех, что
        # заведомо не наберут нужное пересечение или не станут новым
        # лучшим — на категории "Оборудование" (9361 позиция) это была
        # большая часть времени всей функции find_1c_match_with_tier (до
        # 0.5 сек на одну нераспознанную строку). Условие то же самое,
        # просто дешёвая часть проверяется первой — какие записи в итоге
        # выбираются, не меняется.
        min_overlap = len(spec_keywords) * 0.7
        best_item, max_overlap = None, 0
        for entry in self.text_index.get(spec_category, []):
            db_text = entry["_norm"]
            if has_dk_spec and not (re.search(r'\bДК\b', db_text) or "ДРОССЕЛЬ-КЛАПАН" in db_text):
                continue
            if has_rkdk_spec and not re.search(r'\bРКДК\b', db_text):
                continue
            n_overlap = len(spec_keywords.intersection(entry["_words"]))
            if n_overlap < min_overlap or n_overlap <= max_overlap:
                continue
            if not validate_other_category_dimensions(combined_spec, db_text):
                continue
            max_overlap = n_overlap
            best_item = entry["item"]
        return best_item

    # ── совпадение по набору слов, без учёта порядка ───────────────────
    def _execute_wordset_match(self, spec_text, spec_model, spec_category):
        from common.parameters import normalize_diameter_tokens

        spec_text_norm = normalize_diameter_tokens(spec_text)
        spec_model_norm = normalize_diameter_tokens(spec_model) if spec_model else ""
        combined_spec = f"{spec_text_norm} {spec_model_norm}".strip()
        spec_words = set(re.findall(r'[A-ZА-Я0-9\-]+', combined_spec))

        stop = {"ТИП", "ИСПОЛНЕНИЯ", "ИСПОЛНЕНИЕ", "ШТ", "ММ", "М", "ДЛЯ",
                "С", "И", "ИЗ", "НА", "ПО", "КЛАСС", "МАТЕРИАЛ", "ПРОФИЛЬ",
                "РАЗМЕР", "РАЗМЕРЫ", "ОБЩЕПРОМЫШЛЕННЫЙ", "ОБЩЕПРОМЫШЛЕННАЯ"}

        best = None
        for entry in self.text_index.get(spec_category, []):
            db_norm = normalize_diameter_tokens(entry["original"])
            db_words = set(re.findall(r'[A-ZА-Я0-9\-]+', db_norm))

            db_key = {w for w in db_words
                      if len(w) > 1 and w not in stop and not w.replace('.', '', 1).isdigit()}
            if not db_key:
                continue
            if not db_key.issubset(spec_words):
                continue
            if not validate_other_category_dimensions(combined_spec, db_norm):
                continue
            if best is None or len(db_key) > best[0]:
                best = (len(db_key), entry["item"])

        return best[1] if best else None

    # ── главная точка входа Tier 1 ──────────────────────────────────────
    def find_exact(self, spec_text, spec_model="", spec_category=None):
        """
        Точный матч строки спецификации. Возвращает найденный item либо None
        (если None — значит, стоит передать строку в Tier 2, keyword/fuzzy
        поиск, а не считать её "не найденной").
        """
        if not spec_text:
            return None
        spec_text_norm = normalize(spec_text)
        spec_model_norm = normalize(spec_model) if spec_model else ""

        if spec_category is None:
            spec_category = determine_category(spec_text, is_spec_row=True)

        if spec_category in (2, 3):
            spec_geom = extract_geometry(spec_text, is_spec_row=True)
            if spec_geom["kw"] is None:
                return None
            # Воздуховод без указанной длины (L=...) в спеке — обычная
            # ситуация, когда метраж считается по столбцу "Количество", а
            # не по позиции: тогда подставляем стандартную длину отрезка
            # (круглый — 3000мм, прямоугольный — 1250мм), под которую и
            # нарезается металл на практике. Если в базе для этого
            # сечения+толщины такого стандартного отрезка нет — обычное
            # сравнение длины (ниже, в _execute_geometric_match) само не
            # даст матч, никакой отдельной обработки для этого не нужно.
            # Только для самой строки спеки — база 1С всегда несёт свою
            # настоящую длину в названии, её не трогаем.
            if spec_geom["kw"] == "ВОЗДУХОВОД" and spec_geom["length"] == 0:
                probe_sections = extract_sections(spec_text, "ВОЗДУХОВОД", False)
                if probe_sections:
                    is_round = len(probe_sections[0]) == 1
                    spec_geom = {**spec_geom, "length": 3000 if is_round else 1250}
            # Врезка без длины в спеке — в отличие от воздуховода, единого
            # надёжного стандарта на все размеры нет (100мм — самый частый
            # вариант, 327 из 407 позиций, но не для всех: конкретно
            # 550х150 в базе есть только при L=160мм) — значение по
            # умолчанию не подставляем, вместо этого используется
            # неоднозначная проверка внутри _execute_geometric_match (см.
            # ambiguous_length): матчим, только если для сечения+толщины
            # в базе ровно один вариант длины, каким бы он ни был.
            # Переход без длины — тот же случай: 4908 из 5977 позиций
            # "Переход" в базе — L=300 (проверено на реальной
            # номенклатуре), это и есть длина по умолчанию.
            elif spec_geom["kw"] == "ПЕРЕХОД" and spec_geom["length"] == 0:
                spec_geom = {**spec_geom, "length": 300}
            res = self._execute_geometric_match(spec_text, spec_geom, False)
            if res is not None:
                return res
            res = self._execute_geometric_match(spec_text, spec_geom, True)
            if res is not None:
                return res
            # Оригинал VentSpec делает здесь третью попытку с
            # ignore_len_thick=True, но у execute_geometric_match этот
            # параметр принимался и нигде не использовался в теле функции —
            # третий вызов был тождественен второму. Опущен как настоящий
            # no-op (проверено дифференциальным тестом).
            return None

        combined = f"{spec_text_norm} {spec_model_norm}".strip()
        if "КПВ" in re.sub(r'[\s.]', '', combined):
            if "КИД" in combined:
                return None
            spec_kpv_feat = _kpv_features(combined)
            for entry in self.kpv_index.get(spec_category, []):
                if _kpv_features_match(spec_kpv_feat, entry["_kpv_feat"]):
                    return entry["item"]
            return None

        if not has_size_token(combined) and len(distinctive_keywords(spec_text, spec_model)) < 2:
            return None

        # parts/parts_b раньше пересчитывались через re.findall НА КАЖДОГО
        # кандидата (не зависят от entry вообще) — вынесено один раз перед
        # циклом. Кандидаты сразу сужаются до тех, что содержат самое
        # редкое из обязательных слов (_candidates_by_rarest_word) — раз
        # совпадение требует ВСЕХ токенов сразу (AND), кандидат без него
        # заведомо не пройдёт проверку ниже, но раньше мы всё равно
        # тратили на него регулярку. На категории "Оборудование" (9361
        # позиция) это было главной причиной по секунде+ на нераспознанную
        # строку.
        if spec_model_norm:
            parts = [p for p in re.findall(r'[A-Z0-9А-Я\-]+', spec_model_norm) if len(p) > 1]
            required_words = parts if parts else [spec_model_norm]
        else:
            parts = None
            skip = {"РЕШЕТКА", "ВЕНТИЛЯЦИОННАЯ", "КЛАПАН", "ПРОТИВОПОЖАРНЫЙ",
                    "КАНАЛЬНЫЙ", "ПРОФИЛЬ", "ТИП", "ИСПОЛНЕНИЯ"}
            parts_b = [p for p in re.findall(r'[A-Z0-9А-Я\-]+', spec_text_norm)
                       if len(p) > 2 and p not in skip]
            required_words = parts_b if parts_b else None

        if required_words:
            candidates = self._candidates_by_rarest_word(spec_category, required_words)
            for entry in candidates:
                db_text = entry["_norm"]
                if spec_model_norm:
                    if parts:
                        if not all(re.search(r'\b' + re.escape(p) + r'\b', db_text) for p in parts):
                            continue
                    else:
                        if not re.search(r'\b' + re.escape(spec_model_norm) + r'\b', db_text):
                            continue
                else:
                    if not all(re.search(r'\b' + re.escape(p) + r'\b', db_text) for p in parts_b):
                        continue
                if not validate_other_category_dimensions(spec_text_norm, db_text):
                    continue
                return entry["item"]
        # required_words пуст (только когда spec_model_norm нет и parts_b
        # пуст) — оригинал делал continue на каждой итерации, то есть
        # никогда тут не находил; ни этот цикл, ни его отсутствие ничего
        # не меняют — сразу к запасным вариантам.

        res = self._execute_wordset_match(spec_text, spec_model, spec_category)
        if res is not None:
            return res
        res = self._execute_fuzzy_token_match(spec_text, spec_model, spec_category)
        if res is not None:
            return res
        return None


# ── дубли внутри самой базы (не "запрос против базы", а "база против
#    себя") — см. web/onec_db_duplicates.php ───────────────────────────
def find_text_duplicate_groups(items, name_key="name"):
    """
    Группы позиций В ОДНОМ И ТОМ ЖЕ списке с ПОЛНОСТЬЮ совпадающим
    нормализованным текстом наименования (normalize() схлопывает пробелы,
    регистр и запятую/точку как разделитель дробной части — например,
    "0.8мм" и "0,8мм" после нормализации неразличимы, это по-прежнему
    считается полным дублем). Никакой геометрической интерпретации (тип/
    сечения/толщина/длина — то, что проверяет NomenclatureIndex.
    _execute_geometric_match) здесь сознательно НЕТ — заказчик явно
    попросил жёсткий посимвольный критерий вместо "умной" геометрии:
    разбор геометрии неоднократно давал ложные совпадения на реальной
    базе (позиции без распознанного размера вроде "Заглушка" без Ду —
    раньше геометрически совпадали по умолчаниям; "Лист/Пластина ... с
    врезкой ..." — разные размеры врезки на одном листе раньше
    схлопывались в один размер листа). Жёсткий текстовый критерий таких
    ложных совпадений в принципе не даёт ценой того, что не ловит
    настоящие дубли, записанные РАЗНЫМИ словами при одинаковой геометрии
    — сознательный компромисс в пользу точности, а не полноты.

    НАМЕРЕННО не метод NomenclatureIndex и не строит его: конструктор
    индекса разбирает геометрию КАЖДОЙ позиции (determine_category/
    extract_geometry/extract_sections, плюс построение word_index для
    категорий 1/4/5) — а этой функции ничего из разобранного не нужно,
    только нормализованный текст. На реальной базе (~66 тыс. позиций)
    полная сборка NomenclatureIndex заняла ~5.5 сек, а сама эта функция —
    ~0.1 сек: воспроизведено на сервере как 502 (таймаут шлюза) при
    удалении дублей, где этот разбор, никак не используемый результатом,
    выполнялся заново на каждый запрос (см. _validate_codes в
    common/web_db_duplicates_remove_run.py).

    Возвращает список групп — каждая список исходных item (в порядке
    появления в items), минимум по 2 позиции.
    """
    by_norm = defaultdict(list)
    for it in items:
        name = it.get(name_key) if isinstance(it, dict) else getattr(it, name_key, None)
        if not name:
            continue
        by_norm[normalize(name)].append(it)

    return [group for group in by_norm.values() if len(group) >= 2]
