# -*- coding: utf-8 -*-
"""
Отчёт по результатам сравнения спецификации с номенклатурой 1С (Tier 1 +
Tier 2) — сколько строк сопоставлено точно, сколько по неподтверждённой
подсказке, сколько не найдено вовсе, разбивка по категориям.

Два способа сохранить одни и те же данные:
  - write_report_sheet  — добавляет лист-отчёт в уже открытую книгу
    (openpyxl.Workbook), перед сохранением — тот же файл, что и обработанная
    спецификация.
  - write_report_file   — пишет отдельный Excel-файл с тем же содержанием
    (для сохранения в отдельную папку).

Выбор места (доп. лист / отдельный файл) — решение пользователя в GUI,
контент отчёта одинаков в обоих случаях.
"""

import os

from openpyxl import Workbook
from openpyxl.styles import Font

CATEGORY_NAMES = {
    0: "Не определено",
    1: "Оборудование",
    2: "Воздуховоды",
    3: "Фасонные изделия",
    4: "Изоляция/прочее",
    5: "Крепёж",
}

_TITLE_FONT = Font(bold=True, size=14)
_LABEL_FONT = Font(bold=True)


def _pct(part, total):
    return round(part / total * 100, 1) if total else 0


def build_report_rows(stats):
    """stats (словарь) -> список пар (метка, значение) для построчного вывода."""
    total = stats.get("total", 0)
    tier1 = stats.get("tier1", 0)
    tier2 = stats.get("tier2", 0)
    tier3 = stats.get("tier3", 0)
    not_found = stats.get("not_found", 0)
    coverage = round((tier1 + tier2 + tier3) / total * 100, 1) if total else 0

    rows = [
        ("Дата формирования", stats.get("timestamp", "")),
        ("Файл спецификации", stats.get("spec_file", "") or "—"),
        ("Файл номенклатуры", stats.get("db_file", "") or "—"),
        ("Режим", stats.get("mode_title", "")),
        ("Начало обработки", stats.get("proc_start", "")),
        ("Окончание обработки", stats.get("proc_end", "")),
        ("Затрачено времени, сек", stats.get("proc_duration_sec", "")),
        ("", ""),
        ("Всего позиций", total),
        ("Точных совпадений (Tier 1)", tier1),
        ("Подсказок Claude (Tier 3)", tier3),
        ("Неподтверждённых подсказок (Tier 2)", tier2),
        ("Не найдено", not_found),
        ("Покрытие, %", coverage),
        ("", ""),
        ("Проценты по результату", ""),
        ("  Точное совпадение, %", _pct(tier1, total)),
        ("  Подсказка Claude (Tier 3), %", _pct(tier3, total)),
        ("  Неточное совпадение (Tier 2), %", _pct(tier2, total)),
        ("  Отсутствие совпадения, %", _pct(not_found, total)),
    ]
    if stats.get("tier3_status"):
        # Без этой строки «Tier 3: 0» выглядит одинаково, когда Tier 3
        # выключен, упал по связи или честно ничего не нашёл.
        rows.append(("Tier 3 (Claude)", stats["tier3_status"]))
    if stats.get("total_area") is not None:
        rows.append(("Суммарная площадь фасонных изделий, м²", round(stats["total_area"], 2)))

    categories = stats.get("categories") or {}
    if categories:
        rows.append(("", ""))
        rows.append(("Разбивка по категориям", ""))
        for cat, count in sorted(categories.items()):
            rows.append((f"  {CATEGORY_NAMES.get(cat, f'Кат.{cat}')}", count))

    return rows


def _write_rows(ws, rows):
    ws["A1"] = "Отчёт по сравнению с 1С"
    ws["A1"].font = _TITLE_FONT
    r = 3
    for label, value in rows:
        ws.cell(row=r, column=1, value=label).font = _LABEL_FONT
        ws.cell(row=r, column=2, value=value)
        r += 1
    ws.column_dimensions["A"].width = 42
    ws.column_dimensions["B"].width = 28


def write_report_sheet(wb, stats, sheet_name="Отчёт"):
    """Добавляет лист-отчёт в уже открытую книгу (вызывать перед save())."""
    if sheet_name in wb.sheetnames:
        del wb[sheet_name]
    ws = wb.create_sheet(sheet_name)
    _write_rows(ws, build_report_rows(stats))
    return ws


def write_report_file(stats, output_path):
    """Пишет отдельный Excel-файл с тем же содержанием, что и write_report_sheet."""
    wb = Workbook()
    ws = wb.active
    ws.title = "Отчёт"
    _write_rows(ws, build_report_rows(stats))
    wb.save(output_path)
    return output_path


def default_report_path(spec_file, folder):
    """Путь файла-отчёта по умолчанию: <папка>/<спецификация>_otch.xlsx"""
    base = os.path.splitext(os.path.basename(spec_file))[0] if spec_file else "спецификация"
    return os.path.join(folder, f"{base}_otch.xlsx")
