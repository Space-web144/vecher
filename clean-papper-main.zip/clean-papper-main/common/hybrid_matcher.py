# -*- coding: utf-8 -*-
"""
Tier 2 — гибридный (BM25 + fuzzy) поиск с параметрическим бустингом, порт
matching_system utils/hybrid_matcher.py (актуальная версия, не мёртвый
дубликат из корня).

Отличия от оригинала:
  - self.param_extractor.extract_parameters(...) заменён на
    common.parameters.extract_matching_params(...) — тот же набор полей
    (проверено дифференциальным тестом в common/tests), без дублирования
    кода между Tier 1/Tier 2 и без зависимости на этот класс отдельно.
  - RAGSystem/Ollama убраны: в оригинале self.rag_system создавался, но
    нигде не вызывался в search()/batch_search() — мёртвый код, тянущий
    необязательную зависимость от локальной LLM.
  - StrictParameterValidator берётся из common.strict_filter — версия с
    исправленным форматом конфига (см. докстринг там).
  - Semantic-бэкенд оригинала убран — Tier 2 работает только на
    keyword (BM25) + fuzzy, полностью офлайн, без ML-зависимостей.
  - Вычислительная логика весов/бустинга/type-boost/batch — не менялась.
"""

import json
import os
import re
from typing import List, Dict, Tuple, Optional

from common.query_processor import QueryProcessor
from common.query_classifier import classify_query
from common.parameters import extract_matching_params
from common.strict_filter import StrictParameterValidator, apply_strict_filtering
from common.keyword_search import KeywordMatcher
from common.fuzzy_search import FuzzyMatcher

_DEFAULT_WEIGHTS_PATH = os.path.join(os.path.dirname(__file__), "config", "system_weights.json")


def build_default_hybrid_matcher(nomenclature_path, cache_dir="data/cache", log=None):
    """
    Собирает готовый к работе HybridMatcher: BM25 + fuzzy, полностью
    офлайн, лёгкие зависимости. `log`, если передан, вызывается с
    текстовым статусом каждого шага (для CLI-вывода).
    """
    def _log(msg):
        if log:
            log(msg)

    qp = QueryProcessor()

    keyword_matcher = KeywordMatcher(query_processor=qp)
    keyword_matcher.initialize(nomenclature_path, cache_dir=cache_dir)
    _log("✓ Keyword-поиск (BM25) готов")

    fuzzy_matcher = FuzzyMatcher()
    fuzzy_matcher.initialize(nomenclature_path, cache_dir=cache_dir)
    _log("✓ Fuzzy-поиск готов")

    return HybridMatcher(keyword_matcher=keyword_matcher, fuzzy_matcher=fuzzy_matcher)


def build_hybrid_matcher_from_items(items, log=None):
    """
    То же самое, что build_default_hybrid_matcher, но без файла и без кэша
    на диск — строит BM25+fuzzy прямо из списка словарей в памяти. Нужен
    источникам без стабильного файла-справочника (VentSpec: список
    наименований из выгрузки Excel/CSV или живого COM-подключения к 1С,
    который заново собирается при каждой загрузке базы).
    """
    def _log(msg):
        if log:
            log(msg)

    qp = QueryProcessor()

    keyword_matcher = KeywordMatcher(query_processor=qp)
    keyword_matcher.build_from_items(items, query_processor=qp)
    _log("✓ Tier 2: keyword-поиск (BM25) готов")

    fuzzy_matcher = FuzzyMatcher()
    fuzzy_matcher.build_from_items(items)
    _log("✓ Tier 2: fuzzy-поиск готов")

    return HybridMatcher(keyword_matcher=keyword_matcher, fuzzy_matcher=fuzzy_matcher)


class HybridMatcher:

    def __init__(
        self,
        keyword_matcher=None,
        fuzzy_matcher=None,
        system_weights_path: str = _DEFAULT_WEIGHTS_PATH,
        use_strict_filter: bool = True,
    ):
        self.keyword_matcher = keyword_matcher
        self.fuzzy_matcher = fuzzy_matcher

        self.system_weights = self._load_system_weights(system_weights_path)
        self.query_processor = QueryProcessor()

        self.strict_validator = None
        if use_strict_filter:
            try:
                self.strict_validator = StrictParameterValidator()
            except Exception:
                self.strict_validator = None

    @staticmethod
    def _load_system_weights(path: str) -> Dict:
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        return {
            'default': {
                'weights': {'keyword': 0.65, 'fuzzy': 0.35},
                'parameter_boost': {'dn': 2.5, 'diameter': 2.0},
            }
        }

    def _get_weights_for_system(self, system: str) -> Dict:
        return self.system_weights.get(system, self.system_weights['default'])

    def _get_weights_for_material(self, material: Dict, query_system: str) -> Dict:
        systems_str = material.get('systems', material.get('system', ''))
        material_systems = [s.strip() for s in systems_str.split(',') if s.strip()]
        if query_system in material_systems:
            return self.system_weights.get(query_system, self.system_weights['default'])
        primary = material.get('system', 'default')
        return self.system_weights.get(primary, self.system_weights['default'])

    def _apply_type_boost(self, query: str, materials: List[Tuple], system: str) -> List[Tuple]:
        system_config = self._get_weights_for_system(system)
        product_type_boost = system_config.get('product_type_boost', {})
        angle_boost = system_config.get('angle_boost', {})
        shape_boost = system_config.get('shape_boost', {})

        if not product_type_boost and not angle_boost and not shape_boost:
            return materials

        query_lower = query.lower()

        critical_types = [
            'дроссель-клапан', 'воздуховод', 'заглушка', 'переход', 'тройник',
            'решетка', 'диффузор', 'адаптер', 'фланец', 'врезка', 'ниппель',
            'дроссель', 'клапан', 'отвод',
        ]

        query_type = None
        for t in critical_types:
            if re.search(r'\b' + re.escape(t), query_lower):
                query_type = t
                break

        if query_type == 'дроссель' and 'клапан' in query_lower:
            query_type = 'дроссель-клапан'

        is_fastener_query = any(w in query_lower for w in ['болт', 'гайка', 'шайба', 'шпилька'])
        is_anchor_query = 'анкер' in query_lower or 'анкерный' in query_lower

        boosted = []
        for material, score, scores_dict in materials:
            material_name_lower = material['name'].lower()
            material_search_lower = material.get('search_text', '').lower()

            boost_factor = 1.0
            boost_reasons = []

            material_type_matched = False
            sorted_types = sorted(product_type_boost.items(), key=lambda x: len(x[0]), reverse=True)

            for product_type, boost_value in sorted_types:
                if '-' in product_type:
                    pattern = r'\b' + re.escape(product_type) + r'\b'
                else:
                    pattern = r'(?<!-)' + r'\b' + re.escape(product_type)

                if re.search(pattern, query_lower, re.IGNORECASE):
                    if (re.search(pattern, material_name_lower, re.IGNORECASE) or
                            re.search(pattern, material_search_lower, re.IGNORECASE)):
                        if query_type == 'дроссель-клапан' and product_type == 'клапан':
                            if 'дроссель' not in material_name_lower and 'дроссель' not in material_search_lower:
                                break
                        boost_factor *= boost_value
                        boost_reasons.append(f"type:{product_type}x{boost_value}")
                        material_type_matched = True
                        break

            for angle, boost_value in angle_boost.items():
                angle_in_query = (
                    f"{angle}°" in query_lower or f"{angle} °" in query_lower or
                    f"{angle}град" in query_lower or
                    bool(re.search(rf'(?<!\d){re.escape(angle)}(?!\d)', query_lower))
                )
                angle_in_material = (
                    f"{angle}°" in material_name_lower or f"{angle}°" in material_search_lower or
                    f"{angle} °" in material_name_lower or f"{angle}град" in material_name_lower or
                    bool(re.search(rf'(?<!\d){re.escape(angle)}(?!\d)', material_name_lower))
                )
                if angle_in_query and angle_in_material:
                    boost_factor *= boost_value
                    boost_reasons.append(f"angle:{angle}x{boost_value}")
                    break

            for shape, boost_value in shape_boost.items():
                if shape in query_lower:
                    if shape in material_name_lower or shape in material_search_lower:
                        boost_factor *= boost_value
                        boost_reasons.append(f"shape:{shape}x{boost_value}")
                        break

            if query_type and not material_type_matched:
                type_in_material = query_type in material_name_lower or query_type in material_search_lower
                if query_type == 'дроссель-клапан':
                    type_in_material = (
                        'дроссель-клапан' in material_name_lower or
                        'дроссель-клапан' in material_search_lower or
                        ('дроссель' in material_name_lower and 'клапан' in material_name_lower) or
                        ('дроссель' in material_search_lower and 'клапан' in material_search_lower)
                    )
                if not type_in_material:
                    if query_type == 'дроссель-клапан':
                        boost_factor *= 0.001
                        boost_reasons.append('type_mismatch:дроссель-клапан_penalty_x0.001')
                    else:
                        boost_factor *= 0.015
                        boost_reasons.append(f'type_mismatch:{query_type}_penalty_x0.015')

            if is_fastener_query and not is_anchor_query:
                if 'анкер' in material_name_lower or 'анкерный' in material_name_lower:
                    boost_factor *= 0.01
                    boost_reasons.append('anchor_penalty_for_fastener')

            new_score = score * boost_factor
            if boost_factor != 1.0:
                scores_dict_copy = scores_dict.copy()
                scores_dict_copy['type_boost'] = boost_factor
                scores_dict_copy['boost_reasons'] = boost_reasons
                boosted.append((material, new_score, scores_dict_copy))
            else:
                boosted.append((material, new_score, scores_dict))

        return boosted

    def search(
        self,
        query_text: str,
        top_k: int = 10,
        use_keyword: bool = True,
        use_fuzzy: bool = True,
        boost_parameters: bool = True,
        system: Optional[str] = None,
    ) -> List[Tuple[Dict, float, Dict[str, float]]]:

        if system is None:
            system, _confidence = classify_query(query_text)

        system_config = self._get_weights_for_system(system)
        param_boost_config = system_config.get('parameter_boost', {})

        processed_query = self.query_processor.preprocess_for_matching(query_text, expand=False)

        query_params = extract_matching_params(query_text) if boost_parameters else {}

        all_results = {}

        if use_keyword and self.keyword_matcher:
            for material, score in self.keyword_matcher.search(processed_query, top_k=top_k * 3):
                code = material['code']
                all_results.setdefault(code, {'material': material, 'scores': {}, 'params': {}})
                all_results[code]['scores']['keyword'] = score

        if use_fuzzy and self.fuzzy_matcher:
            for material, score in self.fuzzy_matcher.search(processed_query, top_k=top_k * 3):
                code = material['code']
                all_results.setdefault(code, {'material': material, 'scores': {}, 'params': {}})
                all_results[code]['scores']['fuzzy'] = score

        if boost_parameters and query_params:
            for code, data in all_results.items():
                material_text = data['material'].get('search_text', data['material']['name'])
                data['params'] = extract_matching_params(material_text)

        final_results = []
        for code, data in all_results.items():
            scores = data['scores']
            material = data['material']

            mat_config = self._get_weights_for_material(material, system)
            weights = mat_config['weights']
            mat_param_boost_config = mat_config.get('parameter_boost', param_boost_config)

            normalized = {}
            if 'keyword' in scores:
                normalized['keyword'] = min(scores['keyword'] / 15.0, 1.0)
            if 'fuzzy' in scores:
                normalized['fuzzy'] = min(scores['fuzzy'] / 100.0, 1.0)

            final_score, total_weight = 0.0, 0.0
            for method, weight in weights.items():
                if method in normalized:
                    final_score += normalized[method] * weight
                    total_weight += weight
            if total_weight > 0:
                final_score = final_score / total_weight

            scores_dict = normalized.copy()

            if boost_parameters and query_params and data['params']:
                param_boost = self._calculate_parameter_boost(query_params, data['params'], mat_param_boost_config)
                final_score = final_score * param_boost
                if param_boost != 1.0:
                    scores_dict['parameter_boost'] = param_boost

            final_results.append((material, final_score, scores_dict))

        final_results = self._apply_type_boost(processed_query, final_results, system)

        if self.strict_validator:
            results_for_filter = [
                {'name': material['name'], 'code': material['code'], 'score': score,
                 'params': query_params if boost_parameters else {}}
                for material, score, _sd in final_results
            ]
            filtered = apply_strict_filtering(query_text, results_for_filter, query_params, self.strict_validator)
            filtered_codes = {r['code'] for r in filtered}
            final_results = [(m, s, sd) for m, s, sd in final_results if m['code'] in filtered_codes]

        final_results.sort(key=lambda x: x[1], reverse=True)
        return final_results[:top_k]

    def batch_search(
        self,
        queries: List[str],
        top_k: int = 10,
        use_keyword: bool = True,
        use_fuzzy: bool = False,
        boost_parameters: bool = True,
        system: Optional[str] = None,
    ) -> List[List[Tuple[Dict, float, Dict[str, float]]]]:

        if not queries:
            return []

        num_queries = len(queries)
        systems = [system for _ in queries] if system else [classify_query(q)[0] for q in queries]

        processed_queries = [
            self.query_processor.preprocess_for_matching(q, expand=True, system=systems[j])
            for j, q in enumerate(queries)
        ]

        query_params_list = [extract_matching_params(q) for q in queries] if boost_parameters else []

        keyword_batch, fuzzy_batch = [], []

        if use_keyword and self.keyword_matcher:
            keyword_batch = self.keyword_matcher.batch_search(processed_queries, top_k=top_k * 10)
        if use_fuzzy and self.fuzzy_matcher:
            fuzzy_batch = [self.fuzzy_matcher.search(q, top_k=top_k * 3) for q in processed_queries]

        final_results = []
        for i in range(num_queries):
            system_i = systems[i]
            system_config = self._get_weights_for_system(system_i)
            param_boost_config = system_config.get('parameter_boost', {})

            all_results = {}
            if use_keyword and i < len(keyword_batch):
                for material, score in keyword_batch[i]:
                    code = material['code']
                    all_results.setdefault(code, {'material': material, 'scores': {}, 'params': {}})
                    all_results[code]['scores']['keyword'] = score
            if use_fuzzy and i < len(fuzzy_batch):
                for material, score in fuzzy_batch[i]:
                    code = material['code']
                    all_results.setdefault(code, {'material': material, 'scores': {}, 'params': {}})
                    all_results[code]['scores']['fuzzy'] = score

            if boost_parameters and query_params_list:
                for code, data in all_results.items():
                    material_text = data['material'].get('search_text', data['material']['name'])
                    data['params'] = extract_matching_params(material_text)

            query_results = []
            for code, data in all_results.items():
                scores = data['scores']
                material = data['material']

                mat_config = self._get_weights_for_material(material, system_i)
                weights = mat_config['weights']
                mat_param_boost_config = mat_config.get('parameter_boost', param_boost_config)

                normalized = {}
                if 'keyword' in scores:
                    normalized['keyword'] = min(scores['keyword'] / 15.0, 1.0)
                if 'fuzzy' in scores:
                    normalized['fuzzy'] = min(scores['fuzzy'] / 100.0, 1.0)

                final_score, total_weight = 0.0, 0.0
                for method, weight in weights.items():
                    if method in normalized:
                        final_score += normalized[method] * weight
                        total_weight += weight
                if total_weight > 0:
                    final_score = final_score / total_weight

                if boost_parameters and query_params_list:
                    boost = self._calculate_parameter_boost(query_params_list[i], data['params'], mat_param_boost_config)
                    final_score = final_score * boost

                query_results.append((material, final_score, normalized))

            query_results = self._apply_type_boost(processed_queries[i], query_results, system_i)

            if self.strict_validator and query_params_list:
                results_for_filter = [
                    {'name': material['name'], 'code': material['code'], 'score': score, 'params': query_params_list[i]}
                    for material, score, _sd in query_results
                ]
                filtered = apply_strict_filtering(queries[i], results_for_filter, query_params_list[i], self.strict_validator)
                filtered_codes = {r['code'] for r in filtered}
                query_results = [(m, s, sd) for m, s, sd in query_results if m['code'] in filtered_codes]

            query_results.sort(key=lambda x: x[1], reverse=True)
            final_results.append(query_results[:top_k])

        return final_results

    @staticmethod
    def _calculate_parameter_boost(query_params: Dict, material_params: Dict, boost_config: Dict) -> float:
        boost = 1.0

        query_has_diameter = 'diameter' in query_params
        query_has_dimensions = 'dimensions' in query_params
        material_has_diameter = 'diameter' in material_params
        material_has_dimensions = 'dimensions' in material_params

        if (query_has_diameter and material_has_dimensions) or (query_has_dimensions and material_has_diameter):
            if not (query_has_diameter and query_has_dimensions and material_has_diameter and material_has_dimensions):
                boost *= 0.05
                return boost

        if query_params.get('section_shape') == 'круглый':
            if material_has_dimensions and not material_has_diameter:
                boost *= 0.05
                return boost
        if query_params.get('section_shape') == 'прямоугольный':
            if material_has_diameter and not material_has_dimensions:
                boost *= 0.05
                return boost

        if 'dn' in query_params and 'dn' in material_params:
            dn_boost = boost_config.get('dn', 2.5)
            boost *= dn_boost if query_params['dn'] == material_params['dn'] else 0.15

        if 'diameter' in query_params and 'diameter' in material_params:
            diam_boost = boost_config.get('diameter', 2.0)
            try:
                q_d, m_d = float(query_params['diameter']), float(material_params['diameter'])
                if abs(q_d - m_d) <= 2:
                    boost *= diam_boost
                elif abs(q_d - m_d) <= 5:
                    boost *= 1.2
                else:
                    boost *= 0.01
            except ValueError:
                boost *= diam_boost if query_params['diameter'] == material_params['diameter'] else 0.2

        if 'diameter_compound' in query_params and 'diameter_compound' in material_params:
            boost *= 5.0 if query_params['diameter_compound'] == material_params['diameter_compound'] else 0.1

        if 'dimensions' in query_params and 'dimensions' in material_params:
            dim_boost = boost_config.get('dimensions', 2.0)
            boost *= dim_boost if query_params['dimensions'] == material_params['dimensions'] else 0.05

        if 'length' in query_params and 'length' in material_params:
            length_boost = boost_config.get('length', 2.5)
            try:
                q_l, m_l = float(query_params['length']), float(material_params['length'])
                if abs(q_l - m_l) <= 10:
                    boost *= length_boost
                elif abs(q_l - m_l) <= 50:
                    boost *= 1.5
                elif abs(q_l - m_l) <= 200:
                    boost *= 0.5
                else:
                    boost *= 0.3
            except ValueError:
                boost *= length_boost if query_params['length'] == material_params['length'] else 0.3

        if 'thickness' in query_params and 'thickness' in material_params:
            thickness_boost = boost_config.get('thickness', 8.0)
            try:
                q_t, m_t = float(query_params['thickness']), float(material_params['thickness'])
                if abs(q_t - m_t) <= 0.05:
                    boost *= thickness_boost
                elif abs(q_t - m_t) <= 0.1:
                    boost *= (thickness_boost * 0.5)
                else:
                    boost *= 0.2
            except ValueError:
                boost *= thickness_boost if query_params['thickness'] == material_params['thickness'] else 0.2

        if 'thread' in query_params and 'thread' in material_params:
            q_thread, m_thread = query_params['thread'], material_params['thread']
            if q_thread == m_thread:
                boost *= 8.0
            elif 'thread_values' in query_params and m_thread in query_params['thread_values']:
                boost *= 6.0
            elif 'thread_values' in material_params and q_thread in material_params['thread_values']:
                boost *= 6.0
            else:
                boost *= 0.1

        if 'fire_resistance' in query_params and 'fire_resistance' in material_params:
            boost *= 10.0 if query_params['fire_resistance'] == material_params['fire_resistance'] else 0.05

        if 'article' in query_params and 'article' in material_params:
            art_boost = boost_config.get('article', 1.8)
            if query_params['article'].upper() == material_params['article'].upper():
                boost *= art_boost

        if 'gost' in query_params and 'gost' in material_params:
            gost_boost = boost_config.get('gost', 1.5)
            if query_params['gost'] == material_params['gost']:
                boost *= gost_boost

        if 'perekhod_tip' in query_params and 'perekhod_tip' in material_params:
            boost *= 15.0 if query_params['perekhod_tip'] == material_params['perekhod_tip'] else 0.05

        if 'perekhod_sizes' in query_params and 'perekhod_sizes' in material_params:
            q_s = query_params['perekhod_sizes']
            q_sr = query_params.get('perekhod_sizes_rev', '')
            m_s = material_params['perekhod_sizes']
            boost *= 10.0 if (q_s == m_s or q_sr == m_s) else 0.05

        if 'material_type' in query_params and 'material_type' in material_params:
            boost *= 3.0 if query_params['material_type'] == material_params['material_type'] else 0.01

        if 'connection_type' in query_params and 'connection_type' in material_params:
            boost *= 5.0 if query_params['connection_type'] == material_params['connection_type'] else 0.2

        if 'kpv_execution' in query_params and 'kpv_execution' in material_params:
            boost *= 20.0 if query_params['kpv_execution'] == material_params['kpv_execution'] else 0.05

        if 'section_shape' in query_params and 'section_shape' in material_params:
            boost *= 3.0 if query_params['section_shape'] == material_params['section_shape'] else 0.1

        return boost
