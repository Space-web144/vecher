# -*- coding: utf-8 -*-
"""
Строгая пост-фильтрация результатов Tier 2 по критичным параметрам
(диаметр/размеры/толщина/угол/длина) — порт matching_system
utils/strict_parameter_filter.py, С ИСПРАВЛЕНИЕМ реального бага оригинала.

Баг оригинала: StrictParameterValidator.__init__ делал
    self.rules = config['rules']
ожидая JSON вида {"rules": {категория: {...}}}. Но реальный файл
system_configs/strict_parameter_rules.json — плоский словарь категорий БЕЗ
обёртки "rules", и поля внутри называются "required_params"/"tolerances",
а не "required_exact"/"required_close", которые ждал validate_result().
Из-за try/except в местах создания валидатора эта рассинхронизация не
роняла систему, а тихо отключала строгую фильтрацию — комментарии в коде
("✅ Строгие правила проверки параметров активированы") печатались, но
фильтр никогда не применялся.

Здесь validate_result() читает реальный формат файла напрямую: каждый
параметр из required_params обязателен, если он есть в запросе, и
сравнивается с допуском из tolerances (по умолчанию 0 — точное совпадение).
"""

import json
import os
import re
from typing import Dict, List, Tuple, Optional

_DEFAULT_RULES_PATH = os.path.join(os.path.dirname(__file__), "config", "strict_parameter_rules.json")


class StrictParameterValidator:

    def __init__(self, config_path: str = _DEFAULT_RULES_PATH):
        with open(config_path, 'r', encoding='utf-8') as f:
            self.rules = json.load(f)

    def _detect_category(self, query: str) -> Optional[str]:
        query_lower = query.lower()
        has_diameter = bool(re.search(r'[øфØФ]\s*\d+', query))
        has_dimensions = bool(re.search(r'\d+\s*[хx×]\s*\d+', query))

        if 'воздуховод' in query_lower:
            if has_diameter or 'круг' in query_lower:
                return 'воздуховод круглого сечения'
            elif has_dimensions or 'прямоуг' in query_lower:
                return 'воздуховод прямоугольного сечения'
            elif has_dimensions:
                return 'воздуховод прямоугольного сечения'

        if 'отвод' in query_lower:
            angle = None
            if '90' in query:
                angle = '90°'
            elif '45' in query:
                angle = '45°'
            elif '15' in query or '30' in query:
                angle = f"{re.search(r'(15|30)', query).group(1)}°"

            if angle:
                if has_diameter or 'круг' in query_lower:
                    return f'отвод {angle} круглого сечения'
                elif has_dimensions or 'прямоуг' in query_lower:
                    return f'отвод {angle} прямоугольного сечения'
            else:
                if has_diameter or 'круг' in query_lower:
                    return 'отвод круглого сечения'
                elif has_dimensions or 'прямоуг' in query_lower:
                    return 'отвод прямоугольного сечения'

        if 'тройник' in query_lower:
            if has_diameter or 'круг' in query_lower:
                return 'тройник круглого сечения'
            elif has_dimensions or 'прямоуг' in query_lower:
                return 'тройник прямоугольного сечения'

        if 'заглушка' in query_lower:
            if has_diameter or 'круг' in query_lower:
                return 'заглушка круглого сечения'
            elif has_dimensions or 'прямоуг' in query_lower:
                return 'заглушка прямоугольного сечения'

        if 'переход' in query_lower:
            if has_diameter and not has_dimensions:
                return 'переход круглого сечения'
            elif has_dimensions and not has_diameter:
                return 'переход прямоугольного сечения'
            else:
                return 'переход'

        if 'врезка' in query_lower:
            return 'врезка прямоугольного сечения'

        if 'ниппель' in query_lower:
            return 'ниппель круглого сечения'

        return None

    def _extract_param_value(self, text: str, param_name: str) -> Optional[str]:
        text_lower = text.lower()

        if param_name == 'thickness':
            match = re.search(r'[δбtолщин=\s](\d+[.,]\d+)\s*мм', text_lower)
            if match:
                return match.group(1).replace(',', '.')
        elif param_name == 'diameter':
            match = re.search(r'[ØøФф]\s*(\d{2,4})', text)
            if match:
                return match.group(1)
        elif param_name == 'dimensions':
            match = re.search(r'(\d{2,4})\s*[хx×]\s*(\d{2,4})', text)
            if match:
                w, h = int(match.group(1)), int(match.group(2))
                return f"{min(w, h)}x{max(w, h)}"
        elif param_name == 'angle':
            match = re.search(r'\b(90|45|30|60|15)[°]?\b', text)
            if match:
                return match.group(1)
        elif param_name == 'length':
            match = re.search(r'[lLдлин]\s*[=]?\s*(\d{2,5})\s*мм', text_lower)
            if match:
                return match.group(1)
        return None

    @staticmethod
    def _compare_exact(val1: str, val2: str, tolerance: float = 0) -> bool:
        if val1 == val2:
            return True
        try:
            return abs(float(val1) - float(val2)) <= tolerance
        except ValueError:
            return val1 == val2

    def validate_result(self, query: str, material_name: str, query_params: Dict, material_params: Dict) -> Tuple[bool, str]:
        category = self._detect_category(query)
        if not category:
            return True, "no_strict_rules"
        if category not in self.rules:
            return True, "no_rules_for_category"

        rule = self.rules[category]
        required_params = rule.get('required_params', [])
        tolerances = rule.get('tolerances', {})

        for param_name in required_params:
            tolerance = tolerances.get(param_name, 0)
            query_val = query_params.get(param_name) or self._extract_param_value(query, param_name)
            material_val = material_params.get(param_name) or self._extract_param_value(material_name, param_name)

            if query_val:
                if not material_val:
                    return False, f"missing_{param_name}"
                if not self._compare_exact(query_val, material_val, tolerance):
                    return False, f"{param_name}_mismatch:{query_val}≠{material_val}"

        return True, "valid"

    def filter_results(self, query: str, results: List[Dict], query_params: Dict) -> Tuple[List[Dict], Dict]:
        category = self._detect_category(query)
        if not category:
            return results, {'applied': False, 'category': None}
        if category not in self.rules:
            return results, {'applied': False, 'category': category, 'reason': 'no_rules'}

        filtered, rejected = [], []
        for result in results:
            material_name = result.get('name', '')
            material_params = result.get('params', {})
            valid, reason = self.validate_result(query, material_name, query_params, material_params)
            if valid:
                filtered.append(result)
            else:
                rejected.append({'material': material_name[:60], 'reason': reason, 'score': result.get('score', 0)})

        stats = {
            'applied': True, 'category': category,
            'total': len(results), 'passed': len(filtered), 'rejected': len(rejected),
            'rejected_details': rejected[:5],
        }
        return filtered, stats


def apply_strict_filtering(query: str, results: List[Dict], query_params: Dict,
                            validator: Optional[StrictParameterValidator] = None) -> List[Dict]:
    if validator is None:
        try:
            validator = StrictParameterValidator()
        except Exception:
            return results
    filtered, _stats = validator.filter_results(query, results, query_params)
    return filtered
