"""Запись числовых значений без пересохранения остальных частей XLSX."""

import math
import os
import posixpath
import re
import tempfile
import zipfile
from xml.etree import ElementTree as ET
from xml.parsers import expat


def _sheet_paths(archive):
    root = ET.fromstring(archive.read('_rels/.rels'))
    workbook = next(r.attrib['Target'].lstrip('/') for r in root
                    if r.attrib.get('Type', '').endswith('/officeDocument'))
    directory = posixpath.dirname(workbook)
    rels = ET.fromstring(archive.read(posixpath.join(
        directory, '_rels', posixpath.basename(workbook) + '.rels')))
    targets = {r.attrib['Id']: r.attrib['Target'] for r in rels}
    paths = {}
    for sheet in ET.fromstring(archive.read(workbook)).iter():
        if sheet.tag.rsplit('}', 1)[-1] != 'sheet':
            continue
        rid = next(v for k, v in sheet.attrib.items() if k.endswith('}id'))
        target = targets[rid]
        paths[sheet.attrib['name']] = (target.lstrip('/') if target.startswith('/')
                                      else posixpath.normpath(posixpath.join(directory, target)))
    return paths


def _patch_sheet(xml, values):
    # Expat сообщает смещения в исходных байтах. Вне целевых ячеек XML
    # остаётся буквально тем же, включая расширения Excel и кэш формул.
    parser = expat.ParserCreate(namespace_separator='}')
    stack, cells, rows, row_cells = [], {}, {}, {}
    current = None
    current_row = None

    def start(name, attrs):
        nonlocal current, current_row
        tag = name.rsplit('}', 1)[-1]
        if tag == 'row' and stack[-1:] == ['sheetData']:
            current_row = (int(attrs['r']), parser.CurrentByteIndex)
            row_cells[current_row[0]] = []
        if tag == 'c' and stack[-2:] == ['sheetData', 'row']:
            current = (attrs.get('r'), parser.CurrentByteIndex)
        stack.append(tag)

    def end(name):
        nonlocal current
        tag = name.rsplit('}', 1)[-1]
        if tag == 'c' and stack[-3:] == ['sheetData', 'row', 'c']:
            ref, offset = current
            stop = parser.CurrentByteIndex
            opening_stop = xml.index(b'>', offset) + 1
            if xml[offset:opening_stop].rstrip().endswith(b'/>'):
                stop = opening_stop
            else:
                stop = xml.index(b'>', stop) + 1
            cells[ref] = (offset, stop)
            row_cells[current_row[0]].append(ref)
            current = None
        elif tag == 'row' and stack[-2:] == ['sheetData', 'row']:
            # У строк с вычисляемым наименованием уже есть хотя бы одна ячейка.
            stop = parser.CurrentByteIndex
            opening_stop = xml.index(b'>', current_row[1]) + 1
            if not xml[current_row[1]:opening_stop].rstrip().endswith(b'/>'):
                prefix = re.match(rb'</((?:[\w.-]+:)?)row\b', xml[stop:]).group(1)
                rows[current_row[0]] = (stop, prefix)
        stack.pop()

    parser.StartElementHandler, parser.EndElementHandler = start, end
    parser.Parse(xml, True)
    replacements, inserts = [], {}
    for ref, value in values.items():
        if not re.fullmatch(r'[A-Z]{1,3}[1-9]\d*', ref) or not math.isfinite(value):
            raise ValueError('Некорректная ячейка или площадь: ' + ref)
        number = repr(value).encode('ascii')
        if ref in cells:
            offset, stop = cells[ref]
            old = xml[offset:stop]
            opening, body = old.split(b'>', 1)
            prefix = re.match(rb'<([^\s>]*:)c\b|<(c)\b', opening)
            prefix = prefix.group(1) if prefix.group(1) is not None else b''
            opening = re.sub(rb'\s+t\s*=\s*([\'"])[^\'"]*\1', b'', opening).rstrip(b'/')
            body = re.sub(rb'</' + re.escape(prefix) + rb'c\s*>$', b'', body)
            if re.search(rb'<' + re.escape(prefix) + rb'f\b[^>]*\bt=[\'"](?:shared|array|dataTable)[\'"]', body):
                raise ValueError('В ячейке ' + ref + ' групповая формула. '
                                 'Для записи площади выделите отдельный столбец «Вспомогательный».')
            # Удаляем прежнее значение/формулу только в целевой ячейке.
            for tag in (b'f', b'v', b'is'):
                qname = re.escape(prefix + tag)
                body = re.sub(rb'<' + qname + rb'\b[^>]*(?:/>|>.*?</' + qname + rb'\s*>)', b'', body, flags=re.S)
            new = opening + b'><' + prefix + b'v>' + number + b'</' + prefix + b'v>' + body + b'</' + prefix + b'c>'
            replacements.append((offset, stop, new))
        else:
            row = int(re.search(r'\d+$', ref).group())
            if row not in rows:
                raise ValueError('Нет строки для записи площади: ' + ref)
            stop, prefix = rows[row]
            new = b'<' + prefix + b'c r="' + ref.encode('ascii') + b'"><' + prefix + b'v>' + number + b'</' + prefix + b'v></' + prefix + b'c>'
            # Ячейки должны идти по столбцам, в том числе в переставленной таблице.
            col = re.match(r'[A-Z]+', ref).group()
            order = (len(col), col)
            for existing in row_cells[row]:
                offset, _ = cells[existing]
                other = re.match(r'[A-Z]+', existing).group()
                if (len(other), other) > order:
                    stop = offset
                    break
            inserts.setdefault(stop, []).append(new)
    replacements.extend((offset, offset, b''.join(parts)) for offset, parts in inserts.items())
    parts, cursor = [], 0
    for offset, stop, new in sorted(replacements):
        parts.extend((xml[cursor:offset], new))
        cursor = stop
    parts.append(xml[cursor:])
    return b''.join(parts)


def save_numeric_cells(source, destination, updates):
    """updates: {имя листа: {адрес: число}}. Остальные данные не меняются.

    Если значение заменяет формулу площади, служебная calcChain удаляется,
    чтобы Excel перестроил порядок вычислений при открытии.

    Атомарная запись допускает destination == source и не оставляет
    повреждённый результат, если запись не удалась.
    """
    temporary = None
    try:
        with zipfile.ZipFile(source) as original:
            paths = _sheet_paths(original)
            patches = {paths[sheet]: _patch_sheet(original.read(paths[sheet]), values)
                       for sheet, values in updates.items() if values}
            removed = set()
            # При замене формулы в самой ячейке площади Excel должен
            # перестроить цепочку вычислений. Остальные формулы и их кэш
            # остаются исходными; удаляется только служебная calcChain.
            formulas_replaced = any(
                cell.attrib.get('r') in values and
                any(child.tag.rsplit('}', 1)[-1] == 'f' for child in cell)
                for sheet, values in updates.items() if values
                for cell in ET.fromstring(original.read(paths[sheet])).iter()
                if cell.tag.rsplit('}', 1)[-1] == 'c')
            if formulas_replaced:
                types = ET.fromstring(original.read('[Content_Types].xml'))
                for item in list(types):
                    if item.attrib.get('ContentType', '').endswith('.calcChain+xml'):
                        removed.add(item.attrib['PartName'].lstrip('/'))
                        types.remove(item)
                if removed:
                    patches['[Content_Types].xml'] = ET.tostring(types, encoding='utf-8')
                    for name in original.namelist():
                        if not name.endswith('.rels'):
                            continue
                        rels = ET.fromstring(original.read(name))
                        chain = [r for r in rels if r.attrib.get('Type', '').endswith('/calcChain')]
                        for item in chain:
                            rels.remove(item)
                        if chain:
                            patches[name] = ET.tostring(rels, encoding='utf-8')
            with tempfile.NamedTemporaryFile(dir=os.path.dirname(os.path.abspath(destination)),
                                             suffix='.xlsx', delete=False) as handle:
                temporary = handle.name
            with zipfile.ZipFile(temporary, 'w') as result:
                result.comment = original.comment
                for info in original.infolist():
                    if info.filename not in removed:
                        result.writestr(info, patches.get(info.filename, original.read(info)))
        os.replace(temporary, destination)
    finally:
        if temporary and os.path.exists(temporary):
            os.unlink(temporary)
