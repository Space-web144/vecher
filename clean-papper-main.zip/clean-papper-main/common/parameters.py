# -*- coding: utf-8 -*-
"""
Общий модуль извлечения параметров из наименований вентиляционной номенклатуры.

Первый шаг объединения двух программ:
  - VentSpec (program-a)      — детерминированный расчёт площади фасонных изделий и
                                 точный матч со спецификацией 1С;
  - matching_system (program-b) — гибридный (semantic+BM25+fuzzy) поиск по
                                 общему справочнику номенклатуры.

Обе программы независимо разбирают одни и те же поля из текста наименования
(диаметр Ø, сечение AxB, толщина δ/b, длина L=, угол отвода, материал) —
логика была продублирована и местами разошлась. Этот модуль — единый
источник истины для этой части.

Раздел "ЯДРО" — порт функций из VentSpec vent_processor.py V1.9.1 БЕЗ
ИЗМЕНЕНИЙ ЛОГИКИ (та версия сверена по 18 контрольным замерам с калькулятором
wentprom.ru — расходиться с ней нельзя, иначе площадь/матч в VentSpec
сломается). Раздел "РАСШИРЕНИЯ" — функции из matching_system
utils/parameter_extractor.py, которых не было в VentSpec (DN, дюймы, ГОСТ,
резьба, класс огнестойкости, артикул, подтипы оборудования) — добавлены как
есть, аддитивно, ядро не трогают.
"""

import re

# ────────────────────────────────────────────────────────────────────
# ЯДРО — порт из VentSpec vent_processor.py (V1.9.1), логика не менялась
# ────────────────────────────────────────────────────────────────────


def normalize(text):
    """Верхний регистр, унификация запятой/точки и символов диаметра (Ø/⌀/∅→Ø)."""
    if text is None:
        return ""
    text = str(text).upper()
    text = text.replace("\n", " ").replace(",", ".")
    text = text.replace("⌀", "Ø").replace("∅", "Ø")
    return " ".join(text.split())


def clean_whitespace(text):
    """Только пробелы: несколько подряд (включая переводы строк/табы) —
    в один, пробелы по краям — убрать. В отличие от normalize() регистр и
    остальной текст НЕ трогает — для хранимого наименования позиции (как
    есть, для человека), а не для текста, который потом сравнивается
    матчером."""
    if text is None:
        return ""
    return " ".join(str(text).split())


def normalize_diameter_tokens(text):
    """
    Приводит разные записи диаметра к единому виду для текстового сравнения:
    «Ф8», «D8», «Ø8», «ф 8» → «Ø8». Применяется ТОЛЬКО в текстовом поиске,
    не влияет на геометрию воздуховодов (extract_sections/extract_geometry).
    """
    text = normalize(text)
    text = re.sub(r'\b[ØDФF]\s*(\d+)', r'Ø\1', text)
    return text


_DUCT_GEOMETRY_RE = re.compile(r'Ø\s*\d+|\d+\s*[ХX×]\s*\d+')


def get_strict_type(text, strict_grammar=True):
    """
    Тип фасонного изделия ДЛЯ МАТЧЕРА — ключевое слово в любом месте строки.
    (Для расчёта площади VentSpec использует другую функцию, get_fitting_type,
    которая смотрит только на головное слово — она осталась в vent_processor.py,
    т.к. завязана на таблицы формул площади и в общий модуль не переносится.)
    """
    text = normalize(text)
    if not text:
        return None
    if re.search(r'\bВОЗДУХОВОД\b', text):
        return "ВОЗДУХОВОД"
    # Множественное число ("Воздуховоды прямоугольного сечения... сеч.
    # 500x250") тоже воздуховод — но только если у строки ЕСТЬ головное
    # слово "воздуховод(ы/а/ов)" в самом начале И реальная геометрия
    # (сечение/диаметр), иначе посчитать нечего. Без этого условия
    # "Детали крепления воздуховодов" (слово не в начале, без размеров)
    # тоже ловилось бы — а обобщённое "Воздуховоды прочие" (в начале, но
    # без размеров) как раз должно остаться неопределённым, см.
    # test_strict_grammar_blocks_partial_vozdukhov.
    if text.startswith("ВОЗДУХОВОД") and _DUCT_GEOMETRY_RE.search(text):
        return "ВОЗДУХОВОД"
    # Явный маркер другого типа фасонных изделий (переход/отвод/тройник/...) —
    # проверяем ДО блокировки по "ВОЗДУХОВ": "Переход ВОЗДУХОВОДА с
    # круглого на прямоугольное сечение..." — это переход, ссылка на
    # "воздуховода" тут просто часть описания, а не признак того, что
    # позиция сама пытается быть воздуховодом. Блокировка ниже нужна
    # только для случаев без такого маркера (см. test_strict_grammar_
    # blocks_partial_vozdukhov/test_plural_vozdukhovod_not_at_start_
    # still_blocked — оба без слов "переход"/"отвод"/... в тексте, эту
    # перестановку не задевают).
    type_patterns = {
        "ОТВОД":      r'\bОТВОД[А-Я]*\b',
        "ПЕРЕХОД":    r'\bПЕРЕХОД[А-Я]*\b',
        "ТРОЙНИК":    r'\bТРОЙНИК[А-Я]*\b',
        "ВРЕЗКА":     r'\bВРЕЗК[А-Я]*\b',
        "ЗАГЛУШКА":   r'\bЗАГЛУШК[А-Я]*\b',
        "КРЕСТОВИНА": r'\bКРЕСТОВИН[А-Я]*\b',
    }
    for kw, pattern in type_patterns.items():
        if re.search(pattern, text):
            return kw
    if strict_grammar and "ВОЗДУХОВ" in text:
        return None
    fallback = {
        "ОТВОД":      ["ОТВОД", "ОТВОДЫ", "ОТВОДА", "ОТВОДОВ"],
        "ПЕРЕХОД":    ["ПЕРЕХОД", "ПЕРЕХОДЫ", "ПЕРЕХОДА", "ПЕРЕХОДОВ"],
        "ТРОЙНИК":    ["ТРОЙНИК", "ТРОЙНИКИ", "ТРОЙНИКА", "ТРОЙНИКОВ"],
        "ВРЕЗКА":     ["ВРЕЗКА", "ВРЕЗКИ", "ВРЕЗОК"],
        "ЗАГЛУШКА":   ["ЗАГЛУШКА", "ЗАГЛУШКИ", "ЗАГЛУШЕК"],
        "КРЕСТОВИНА": ["КРЕСТОВИНА", "КРЕСТОВИНЫ"],
    }
    for kw, words in fallback.items():
        if any(w in text for w in words):
            return kw
    return None


def _reorder_tee_triple(seq):
    """Тройник в некоторых форматах спецификации записан как "магистраль-
    магистраль-ответвление" (первые два значения совпадают), а в 1С
    хранится как "магистраль-ответвление-магистраль" (совпадают первое и
    третье, ответвление — в середине) — без этого список сечений спеки
    никогда не совпадёт с базой, даже если это буквально один и тот же
    тройник. Переставляем, только если совпадение первых двух и правда
    похоже на этот случай (не трогаем тройники, где всё уже в порядке
    1С, или где нет ни одной пары совпадений). Работает и для тройки
    диаметров круглого тройника, и для тройки пар AxB прямоугольного —
    вызывающий код передаёт то, что нужно переставить целиком."""
    if len(seq) == 3 and seq[0] == seq[1] and seq[2] != seq[0]:
        a, b, c = seq
        return (a, c, b) if isinstance(seq, tuple) else [a, c, b]
    return seq


def extract_sections(text, item_type, force_sort_pairs=False):
    """
    Извлекает сечения (диаметры и пары AxB) из наименования, с учётом типа
    изделия: тройник ищет тройную запись X-Y-Z, переход сортирует пары,
    заглушка сортирует единственную пару (ориентация не важна), у остальных
    типов ориентация сечения сохраняется строго (400х200 ≠ 200х400).
    """
    if not text:
        return []
    text = normalize(text)
    # Ссылка на ГОСТ («по ГОСТ Р 59972-2021», «ГОСТ 14918-2020») — номер и год
    # стандарта не геометрия, но без этой вырезки год «2021» и номер «59972»
    # (разделены дефисом, не Х/×, поэтому не распознаются как пара) попадали
    # в sections как два лишних одиночных "сечения" и портили сопоставление —
    # воспроизведено вживую на реальном файле (сотни строк воздуховодов с
    # такой пометкой в наименовании ни разу не находились в базе).
    text = re.sub(r'ГОСТ\s*Р?\s*\d+[-\d.]*', ' ', text)
    text = re.sub(r'\d+\s*(?:ГРАД|°)', ' ', text)
    if item_type == "ОТВОД":
        ang = extract_angle(text)
        if ang:
            text = re.sub(r'\b' + str(ang) + r'\b(?!\s*[XХ×*])', ' ', text, count=1)
    text = re.sub(r'\bEI\s*\d+\b', ' ', text)
    text = re.sub(r'\b(?:ТИП|ИСП|ИСПОЛНЕНИЕ|КЛАСС|КЛ)\S*\s*[A-ZА-Я0-9-]*\d+\b', ' ', text)
    text = re.sub(r'\b[УУ]\s*\d\b', ' ', text)
    text = re.sub(r'\b[FG]\s*\d\b', ' ', text)
    text = re.sub(r'(?:[LЛ]\s*=?|ДЛИНА\s+)\s*\d+\s*(?:ММ)?\b', ' ', text)
    text = re.sub(r'(?:B|S|Б)\s*=\s*[\d\.]+', ' ', text)
    text = re.sub(r'(?:ТОЛЩ\w*|СТЕНК\w*)(?:\s+СТЕНК\w*)?\s*[\d\.]+', ' ', text)
    text = re.sub(r'\b\d+\.\d+\b', ' ', text)
    text = text.replace("Ø", "").replace("D", "").replace("Ф", "")

    # Ориентацию сечения переворачивать НЕЛЬЗЯ ни для тройников/крестовин,
    # ни для воздуховодов: «500х400» ≠ «400х500». Сортировку пар не применяем.
    sort_pairs = False

    if item_type == "ТРОЙНИК":
        triple = re.findall(r'\b(\d+)\s*[-\/\s]\s*(\d+)\s*[-\/\s]\s*(\d+)\b', text)
        if triple:
            return [_reorder_tee_triple((int(m[0]), int(m[1]), int(m[2])))
                    for m in triple]

    matches = re.findall(r'(\d+)\s*[XХ×\*]\s*(\d+)|(\d+)', text)
    sections = []
    for m in matches:
        if m[0] and m[1]:
            pair = (int(m[0]), int(m[1]))
            sections.append(tuple(sorted(pair)) if sort_pairs else pair)
        elif m[2]:
            d = int(m[2])
            if d >= 50:
                sections.append((d,))

    if item_type == "ТРОЙНИК" and len(sections) == 2:
        sections.append(sections[0])
    if item_type == "ТРОЙНИК" and len(sections) == 3:
        sections = _reorder_tee_triple(sections)
    # Врезка в некоторых форматах спецификации записывается как "AxB-AxB"
    # (сечение повторено дважды через дефис — судя по реальным файлам,
    # всегда одно и то же значение), а не одним сечением, как хранится
    # позиция в 1С ("Врезка ... 350х150 L=100 ..."). Без схлопывания
    # список сечений спеки ([(350,150),(350,150)]) никогда не совпадёт с
    # базой ([(350,150)]) — оставляем только первое значение, оно и есть
    # собственно сечение врезки.
    if item_type == "ВРЕЗКА" and len(sections) >= 2:
        sections = sections[:1]
    # Отвод в некоторых форматах спецификации тоже записывается как
    # "AxB-AxB" (сечение до и после отвода — при простом отводе они
    # всегда одинаковые, в отличие от переходного отвода, где до и после
    # разные размеры, см. "Отвод 90° переходной ... 500х900-520х920" в
    # базе — там схлопывать нельзя, оба значения значимы). Схлопываем
    # только когда оба значения дословно совпадают — простой отвод в 1С
    # хранится одним сечением.
    if item_type == "ОТВОД" and len(sections) == 2 and sections[0] == sections[1]:
        sections = sections[:1]
    if item_type in ["ЗАГЛУШКА"] or sort_pairs:
        sections = [tuple(sorted(s)) for s in sections]
    if item_type == "ПЕРЕХОД":
        sections = sorted(sections)
    return sections


def extract_angle(text, default=0):
    """
    Определение угла отвода. Запись вариативна: «90 град», «90°» или просто
    число без обозначения. Основной метод: угол — ДВУЗНАЧНОЕ число из набора
    15, 30, 45, 60, 90, не входящее в размеры (диаметр Ø/D/Ф, сечение AxB,
    длину L=, толщину). Сначала пробуем явное «град/°», затем — число.
    """
    t = normalize(text)
    m = re.search(r'(\d{1,3})\s*(?:ГРАД\w*|°)', t)
    if m:
        return int(m.group(1))
    masked = re.sub(r'(?:Ø|D|Ф|F)\s*\d+', ' ', t)                 # диаметры
    masked = re.sub(r'\d+\s*[XХ×\*]\s*\d+', ' ', masked)          # сечения AxB
    masked = re.sub(r'[LЛ]\s*=?\s*\d+', ' ', masked)             # длина
    masked = re.sub(r'(?:B|S|Б)\s*=\s*\d+(?:\.\d+)?', ' ', masked)  # толщина
    for num in re.findall(r'(?<!\d)(\d{2})(?!\d)', masked):
        v = int(num)
        if v in (15, 30, 45, 60, 90):
            return v
    return default


def extract_thickness(text):
    """Толщина металла: «δ=0.8», «b=0.8», «S=0.8», «Б=0.8» или «толщина 0.8»."""
    text = normalize(text)
    thick_match = re.search(r'(?:Δ|δ|B|S|Б)\s*=\s*(\d+\.\d+|\d+)', text)
    if thick_match:
        return float(thick_match.group(1))
    thick_text = re.search(r'(?:ТОЛЩ\w*|СТЕНК\w*)(?:\s+СТЕНК\w*)?\s*(\d+\.\d+|\d+)', text)
    if thick_text:
        return float(thick_text.group(1))
    return 0.0


def extract_length_mm(text):
    """Длина патрубка/участка: «L=300», «Л=300», без обязательного «мм»."""
    text = normalize(text)
    len_match = re.search(r'[LЛ]\s*=?\s*(\d+)', text)
    if len_match:
        return int(len_match.group(1))
    return 0


def extract_material(text):
    """Материал изделия — оцинкованная сталь по умолчанию."""
    text = normalize(text)
    if "НЕРЖ" in text:
        return "НЕРЖАВЕЮЩАЯ"
    if "ПВХ" in text or "ПЛАСТИК" in text:
        return "ПВХ"
    if "ЧЕРН" in text:
        return "ЧЕРНАЯ"
    if "АЛЮМ" in text or "АЛЛЮМ" in text:
        return "АЛЮМИНИЕВАЯ"
    return "ОЦИНКОВАННАЯ"


def extract_geometry(text, is_spec_row=False):
    """
    Полная геометрия строки для матчера: тип, угол (90° по умолчанию для
    отвода), толщина, длина, материал. Соответствует VentSpec
    extract_full_geometry — используется индексацией базы 1С и сравнением.
    """
    text = normalize(text)
    kw = get_strict_type(text, strict_grammar=is_spec_row)
    angle = extract_angle(text, default=(90 if kw == "ОТВОД" else 0))
    return {
        "kw": kw,
        "angle": angle,
        "thickness": extract_thickness(text),
        "length": extract_length_mm(text),
        "material": extract_material(text),
    }


# ────────────────────────────────────────────────────────────────────
# ПРЕДОБРАБОТКА — цеховая "заявка на изготовление" (напр. "Лимит на
# материалы"), где геометрия записана через дефис вместо маркеров δ=/L=
# (см. normalize_workshop_shorthand). Ядро выше (extract_sections/
# extract_thickness/extract_length_mm) не трогаем — вместо этого текст
# переписывается в уже понятный ядру вид ДО того, как попадёт в матчер.
# ────────────────────────────────────────────────────────────────────

# Толщина — последнее дробное число в дефисной цепочке, возможно с
# буквенным суффиксом-кодом исполнения после него ("...-1,0-НП").
_SHORTHAND_THICKNESS_RE = re.compile(r'-(\d+\.\d+)((?:-[А-ЯA-Z]+)*)\s*$')
# Радиус/смещение отвода или заглушки ("R150", "ш100") — не геометрия
# и не длина, просто убираются.
_SHORTHAND_RADIUS_RE = re.compile(r'-[RШ]\d+\b')
# Угол отвода стоит СРАЗУ после ключевого слова через ПРОБЕЛ (а не дефис,
# как всё остальное в этой записи) — по нему отличаем "голый" диаметр
# круглого отвода от угла на строках без явного сечения AxB.
_SHORTHAND_OTVOD_ANGLE_RE = re.compile(r'^\S+\s+(?:15|30|45|60|90)\b')
_SHORTHAND_DIM_RE = re.compile(r'\d+\s*[ХX×]\s*\d+|\d+')
_SHORTHAND_EXISTING_MARKERS_RE = re.compile(r'[ΔDBSБ]\s*=|[LЛ]\s*=')


def normalize_workshop_shorthand(text):
    """
    Некоторые файлы (заявки цеха на изготовление, "Лимит на материалы")
    записывают геометрию через дефис вместо явных маркеров — например
    "Воздуховод 800х500-1500-0,7" (сечение-длина-толщина), "Отвод
    90-450х1050-R150-1,0" (угол-сечение-радиус-толщина), "Тройник
    450х1050/510х1010-870-1,0" (магистраль/ответвление-длина-толщина).
    Без маркеров extract_thickness()/extract_length_mm() ничего не
    находят (тихо возвращают 0), а extract_sections() принимает "голую"
    длину или радиус за ещё одно сечение и портит геометрический ключ
    сравнения с 1С (воздуховод 800х500 никогда не найдётся в базе, если
    в его сечения затесалась ещё и длина).

    Переписывает такую строку в вид, который калиброванное ядро уже
    понимает (δ=/L=) — само ядро не трогаем. Активируется только когда:
      - get_strict_type распознаёт тип фасонных изделий (иначе просто нечего
        аккуратно переписывать — не геометрический матч);
      - в строке ещё НЕТ ни одного уже понятного маркера (δ=/b=/S=/Б=/
        L=/Л=) — так исходный (уже поддерживаемый) формат гарантированно
        не переписывается повторно.
    Если строка не подходит ни под один случай — возвращается как есть.
    """
    if not text:
        return text
    t = normalize(text)
    # Пояснительное примечание в скобках в конце строки ("...-870-1,0
    # (смещение врезки 510х1010 300мм, длина врезки 300мм)") — не часть
    # геометрии, но из-за него дробная толщина перестаёт быть последним,
    # что стоит в строке, и её распознавание ниже (привязанное к концу
    # строки) не срабатывает вовсе. Отбрасываем перед разбором — само
    # примечание для сопоставления с 1С не нужно.
    t = re.sub(r'\s*\([^)]*\)\s*$', '', t)
    if not t or _SHORTHAND_EXISTING_MARKERS_RE.search(t):
        return text
    item_type = get_strict_type(t, strict_grammar=True)
    if not item_type:
        return text

    m = _SHORTHAND_THICKNESS_RE.search(t)
    if not m:
        return text
    thickness, suffix = m.group(1), (m.group(2) or "")
    body = t[:m.start()]
    body = _SHORTHAND_RADIUS_RE.sub('', body)

    prefix_end = 0
    if item_type == "ОТВОД":
        angle_m = _SHORTHAND_OTVOD_ANGLE_RE.match(body)
        if angle_m:
            prefix_end = angle_m.end()

    tokens = list(_SHORTHAND_DIM_RE.finditer(body, prefix_end))
    if not tokens:
        return f"{body} δ={thickness}{suffix}".strip()

    # Первый геометрический токен — а если следом через "/" идёт второй
    # (переход/тройник: магистраль/ответвление) — то и он тоже, оставляем
    # как есть.
    idx = 0
    while idx + 1 < len(tokens):
        between = body[tokens[idx].end():tokens[idx + 1].start()]
        if "/" in between and between.strip("/ ") == "":
            idx += 1
        else:
            break

    # Первое голое (не AxB) число ПОСЛЕ сечения, достаточно большое, чтобы
    # быть длиной, а не случайным служебным числом (напр. "-1-" у части
    # круглых отводов, назначение которого не установлено, но оно всегда
    # меньше 50 — тем же порогом, что и остальной код этого модуля,
    # отличает диаметр/сечение от мусора).
    length_tok = None
    for tok in tokens[idx + 1:]:
        g = tok.group()
        if 'Х' not in g and 'X' not in g and '×' not in g and int(g) >= 50:
            length_tok = tok
            break
    if length_tok:
        body = (body[:length_tok.start()] + " L=" + length_tok.group()
                + " " + body[length_tok.end():])

    return f"{body.strip()} δ={thickness}{suffix}".strip()


# ────────────────────────────────────────────────────────────────────
# РАСШИРЕНИЯ — порт из matching_system utils/parameter_extractor.py.
# Полей, которых не было в VentSpec: DN, дюймы, ГОСТ, резьба, класс
# огнестойкости (обобщённый — отдельно от КПВ-специфичной сверки в
# VentSpec _kpv_features), артикул, подтипы вент.оборудования.
# ────────────────────────────────────────────────────────────────────

_INCH_TO_DN = {
    '1/2': 'DN15', '3/4': 'DN20', '1': 'DN25',
    '1 1/4': 'DN32', '1 1/2': 'DN40', '2': 'DN50',
    '2 1/2': 'DN65', '3': 'DN80', '4': 'DN100',
}


def extract_dn_direct(text):
    """DN/ДН/Ду — номинальный диаметр трубопровода, записанный явно. None, если не найден."""
    text_lower = text.lower()
    for pattern in (r'dn\s*(\d+)', r'дн\s*(\d+)', r'ду[\s\-]*(\d+)'):
        m = re.search(pattern, text_lower)
        if m:
            return f"DN{m.group(1)}"
    return None


def extract_inch_dn(text):
    """Дюймовая резьба (1/2", 3/4" и т.д.) → (DN-обозначение, исходная запись дюймов) либо (None, None)."""
    for pattern in (r'(\d+\s*\d*/\d+)\s*["\']', r'(\d+/\d+)\s*["\']', r'(\d+)\s*["\']'):
        m = re.search(pattern, text)
        if m:
            inch_str = m.group(1).strip()
            inch_normalized = inch_str.replace(' ', '')
            for key, dn_value in _INCH_TO_DN.items():
                if key.replace(' ', '') == inch_normalized or inch_str == key:
                    return dn_value, inch_str
            break
    return None, None


def extract_dn(text):
    """
    DN трубопровода — явная запись (DN/ДН/Ду) либо, если её нет, выведенная
    из дюймовой резьбы (1/2"→DN15 и т.д.). Совпадает с полем `dn` оригинального
    matching_system.ParameterExtractor, где эти два источника были слиты в одно поле.
    """
    dn = extract_dn_direct(text)
    if dn:
        return dn
    dn, _inch = extract_inch_dn(text)
    return dn


def extract_gost(text):
    """Номер ГОСТа, например «ГОСТ 10704-91»."""
    m = re.search(r'гост\s+([\d\-\.]+)', text.lower())
    return f"ГОСТ {m.group(1)}" if m else None


def extract_thread(text):
    """
    Метрическая резьба: «М10», либо slash-нотация «М8/М10» (универсальный
    хомут — оба значения сохраняются в thread_values).
    Возвращает (thread, thread_values) — thread_values=[thread] для одиночной резьбы.
    """
    m = re.search(r'\bМ(\d+)/М(\d+)\b', text)
    if m:
        thread = f"М{m.group(1)}/М{m.group(2)}"
        return thread, [f"М{m.group(1)}", f"М{m.group(2)}"]
    m = re.search(r'\bМ(\d+)\b', text)
    if m:
        thread = f"М{m.group(1)}"
        return thread, [thread]
    return None, None


def extract_fire_resistance(text):
    """
    Класс огнестойкости EI30/60/90/120/150 — обобщённая версия для изоляции
    и прочего оборудования. Для клапанов КПВ используется отдельная
    строгая сверка по коду (не входит в этот модуль).
    """
    m = re.search(r'\bEI\s*(\d+)\b', text, re.IGNORECASE)
    return f"EI{m.group(1)}" if m else None


_ARTICLE_PATTERNS = [
    r'\b(DRr|DCGAr)\b',
    r'\b(PatAIR[-A-ZА-Я0-9хx×]+)',
    r'\b(ГОСТ\s*\d+[-\d]*)\b',
    r'\b(DIN\s*\d+)\b',
    r'\b(EI\d+)\b',
    r'([A-ZА-Я]{2,}[-\s]?[A-ZА-Я0-9-]+)',
    r'\b([A-ZА-Я]{2,6})\s+(\d{2,4})\b',
    r'\b([A-ZА-Я]+\d+)\b',
]


def extract_article(text):
    """Артикул/код изделия — набор эвристических паттернов (первый совпавший побеждает)."""
    for pattern in _ARTICLE_PATTERNS:
        matches = re.findall(pattern, text)
        if matches:
            first = matches[0]
            if isinstance(first, tuple):
                return ''.join(first)
            return first
    return None


_DIFFUSER_TYPES = {
    'тарельчатый': ['тарельчат'],
    'щелевой': ['щелев', 'щелоч'],
    'вихревой': ['вихрев'],
    'анемостат': ['анемостат'],
}
_AIRFLOW_DIRECTIONS = {
    'приточный': ['приточ'],
    'вытяжной': ['вытяж'],
    'универсальный': ['универсальн'],
}
_CONNECTION_TYPES = {
    'ниппель': ['ниппель'],
    'фланец': ['фланец', 'фланцев'],
}
_SECTION_SHAPES = {
    'круглый': ['круглый', 'круглого сечения', 'круглое сечение'],
    'прямоугольный': ['прямоугольный', 'прямоугольного сечения', 'прямоугольное сечение'],
}


def extract_equipment_subtypes(text):
    """
    Категориальные подтипы вент.оборудования: тип диффузора, направление
    воздушного потока, тип соединения, форма сечения. Используется
    matching_system для дополнительного бустинга/фильтрации кандидатов —
    в VentSpec такого разбиения не было.
    """
    subtypes = {}
    text_lower = text.lower()
    for key, table in (
        ("diffuser_subtype", _DIFFUSER_TYPES),
        ("airflow_direction", _AIRFLOW_DIRECTIONS),
        ("connection_type", _CONNECTION_TYPES),
        ("section_shape", _SECTION_SHAPES),
    ):
        for value, keywords in table.items():
            if any(kw in text_lower for kw in keywords):
                subtypes[key] = value
                break
    return subtypes


# ────────────────────────────────────────────────────────────────────
# Остальные поля, нужные Tier 2 (common.hybrid_matcher) для бустинга —
# порт оставшейся части matching_system ParameterExtractor._extract_with_regex,
# которая раньше не переносилась (только regex-извлечение, без LLM/Ollama).
# ────────────────────────────────────────────────────────────────────


def extract_diameter_compound(text):
    """Составной диаметр тройника/перехода: «Ø100-Ø100-Ø100» → '100-100-100'."""
    compound = re.findall(r'[øфøØ]\s*(\d+)', text.lower())
    return '-'.join(compound) if len(compound) >= 2 else None


def extract_diameter(text):
    """Одиночный диаметр в мм (как строка) — Ø/диаметр N/d N мм."""
    text_lower = text.lower()
    for pattern in (r'[øфøØ]\s*(\d+)(?!\d)', r'диаметр\s+(\d+)', r'd\s*(\d+)\s*мм'):
        m = re.search(pattern, text_lower)
        if m:
            return m.group(1)
    return None


def extract_dimensions(text):
    """Прямоугольные размеры «600×400» или «ДхШхВ» через ×."""
    for pattern in (r'(\d+)\s*[хx×]\s*(\d+)\s*[хx×]\s*(\d+)', r'(\d+)\s*[хx×]\s*(\d+)'):
        m = re.search(pattern, text)
        if m:
            return "×".join(m.groups())
    return None


def extract_perekhod_tip(text):
    """Тип перехода: «Тип 1.» / «тип 2» → 1 (int) либо None."""
    m = re.search(r'\bтип\s*(\d+)', text, re.IGNORECASE)
    return int(m.group(1)) if m else None


def extract_perekhod_sizes(text):
    """Пара размеров перехода «300х300-450х200» → (прямая, обратная) либо (None, None)."""
    m = re.search(r'(\d+)[хx](\d+)\s*[-–]\s*(\d+)[хx](\d+)', text, re.IGNORECASE)
    if not m:
        return None, None
    a1, a2, b1, b2 = m.groups()
    return f"{a1}х{a2}-{b1}х{b2}", f"{b1}х{b2}-{a1}х{a2}"


def extract_kpv_execution(text):
    """Код исполнения КПВ (ГВ/ВВ/МС/ВГ и т.п.) из марки «...-СН-XX-...»."""
    text_lower = text.lower()
    if 'кпв' not in text_lower:
        return None
    m = re.search(r'-СН-([А-ЯЁA-Z]{2})-', text, re.IGNORECASE)
    return m.group(1).upper() if m else None


def classify_material_class(text):
    """
    Класс материала для Tier 2 бустинга: galvanized/stainless/flexible.
    Отдельно от extract_material() (ОЦИНКОВАННАЯ/НЕРЖАВЕЮЩАЯ/...) — тот
    служит геометрическому Tier 1 матчу, этот — англоязычным ключам,
    которых ждёт портированный из matching_system скоринг бустов.
    """
    text_lower = text.lower()
    if any(w in text_lower for w in ('оцинк', 'оцинкованн', 'покрытие: оцинк', 'galvanized')):
        return 'galvanized'
    if any(w in text_lower for w in ('нерж', 'stainless', 'aisi')):
        return 'stainless'
    if any(w in text_lower for w in ('epdm', 'резин', 'гибк', 'полимер')):
        return 'flexible'
    return None


def extract_matching_params(text):
    """
    Полный набор параметров для Tier 2 (common.hybrid_matcher) — объединяет
    все extract_*/classify_* функции этого модуля в один словарь, faithful
    порт matching_system ParameterExtractor.extract_parameters(use_llm=False):
    dn, diameter, diameter_compound, dimensions, gost, thread/thread_values,
    fire_resistance, article, thickness, length, perekhod_tip,
    perekhod_sizes/perekhod_sizes_rev, kpv_execution, material_type,
    + подтипы оборудования (diffuser_subtype/airflow_direction/
    connection_type/section_shape).
    """
    params = {}

    dn = extract_dn_direct(text)
    inch_dn, inch = extract_inch_dn(text)
    if dn:
        params['dn'] = dn
    elif inch_dn:
        params['dn'] = inch_dn
        params['inch'] = inch

    diameter_compound = extract_diameter_compound(text)
    if diameter_compound:
        params['diameter_compound'] = diameter_compound

    diameter = extract_diameter(text)
    if diameter:
        params['diameter'] = diameter

    dimensions = extract_dimensions(text)
    if dimensions:
        params['dimensions'] = dimensions

    gost = extract_gost(text)
    if gost:
        params['gost'] = gost

    thread, thread_values = extract_thread(text)
    if thread:
        params['thread'] = thread
        if '/' in thread:
            # thread_values только для slash-нотации (М8/М10) — как в оригинале,
            # где одиночная резьба (thread_match) его не выставляет.
            params['thread_values'] = thread_values

    perekhod_tip = extract_perekhod_tip(text)
    if perekhod_tip is not None:
        params['perekhod_tip'] = perekhod_tip

    perekhod_sizes, perekhod_sizes_rev = extract_perekhod_sizes(text)
    if perekhod_sizes:
        params['perekhod_sizes'] = perekhod_sizes
        params['perekhod_sizes_rev'] = perekhod_sizes_rev

    fire_resistance = extract_fire_resistance(text)
    if fire_resistance:
        params['fire_resistance'] = fire_resistance

    article = extract_article(text)
    if article:
        params['article'] = article

    thickness = extract_thickness(text)
    if thickness:
        params['thickness'] = str(thickness)

    length = extract_length_mm(text)
    if length:
        params['length'] = str(length)

    kpv_execution = extract_kpv_execution(text)
    if kpv_execution:
        params['kpv_execution'] = kpv_execution

    material_type = classify_material_class(text)
    if material_type:
        params['material_type'] = material_type

    params.update(extract_equipment_subtypes(text))
    return params
