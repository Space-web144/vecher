"""Клиент Claude API (Anthropic) — один запрос Messages API с ответом
строго по JSON-схеме.

Зачем нужен: разбор листов подбора в блоке "Оборудование". Вёрстка у
каждого поставщика своя, и распознаватель под неё пишется руками (см.
program-a/equipment_table.py, _SELECTION_READERS). Незнакомая вёрстка
до сих пор просто пропускалась — в отчёте у такой системы стояло "нет
данных". Модель закрывает ровно этот случай: читает текст листа и
говорит, что на нём за система и какая марка. Сравнение марок она НЕ
делает и делать не должна — оно остаётся точным, посимвольным (см.
equipment_table.normalize_mark).

Почему не официальный SDK anthropic. На сервере Python 3.8.8, а SDK
версии 1.x требует 3.10+; последняя версия SDK с поддержкой 3.8 — 0.72,
две мажорные версии назад, и в ней нет output_config. Плюс у хостинга
жёсткий лимит памяти процесса (та же история, что с потоками OpenBLAS,
см. web_run.py). Поэтому — стандартная библиотека, как и в соседнем
common/gigachat_client.py. Если на сервере появится Python 3.10+,
переход на SDK будет локальной правкой: тело запроса здесь собирается
ровно в том виде, в каком его отправляет SDK.

Ключ (ANTHROPIC_API_KEY) передаётся вызывающим кодом — обычно через
переменную окружения, которую задаёт web/process_pdf.php перед запуском
фонового процесса. Здесь он не хранится, не логируется и не попадает в
аргументы командной строки (их видно в ps aux всем пользователям
хостинга).
"""
from __future__ import annotations

import base64
import json
import os
import sys
import time
import urllib.error
import urllib.request
from urllib.parse import urlparse
from typing import Optional

API_URL = "https://api.anthropic.com/v1/messages"
# Версия API фиксируется заголовком, а не датой выпуска клиента —
# так ответ не поменяет форму под нами после обновления на стороне
# Anthropic.
API_VERSION = "2023-06-01"

DEFAULT_MODEL = "claude-opus-5-5"
# Усилие: high — прочитать лист подбора и не перепутать марку важнее
# скорости (решение владельца 01.11.2026). Меняется полем effort_equipment
# в файле с ключом (web/process_pdf.php передаёт его как ANTHROPIC_EFFORT).
DEFAULT_EFFORT = "high"
EFFORT_LEVELS = ("low", "medium", "high", "xhigh", "max")
# С листа подбора приходит два поля, а с листа ХСОВ — все его строки
# (в реальных альбомах до трёх десятков). Размышление модели тоже входит
# в этот предел, а на high оно бывает длинным — поэтому с запасом.
DEFAULT_MAX_TOKENS = 16000
DEFAULT_TIMEOUT_SEC = 300

# Ответ крупнее — почти наверняка не то, чего мы ждём (страница ошибки
# прокси, обрыв с бесконечным чтением). Читаем с потолком, чтобы падать
# понятной ошибкой, а не MemoryError (тот же приём, что в
# gigachat_client.py, и по той же причине — лимит памяти хостинга).
MAX_RESPONSE_BYTES = 4 * 1024 * 1024
_READ_CHUNK = 16 * 1024

# Повторяем только то, что имеет смысл повторять: перегрузку и пятисотки.
_RETRY_CODES = (408, 409, 429, 500, 502, 503, 504)
_MAX_RETRIES = 2
_RETRY_BASE_DELAY_SEC = 2.0


class ClaudeError(RuntimeError):
    pass


def _read_capped(resp, cap_bytes: int = MAX_RESPONSE_BYTES) -> bytes:
    chunks = []
    total = 0
    while True:
        chunk = resp.read(_READ_CHUNK)
        if not chunk:
            break
        total += len(chunk)
        if total > cap_bytes:
            raise ClaudeError("Ответ Claude API неожиданно большой — прерываю чтение")
        chunks.append(chunk)
    return b"".join(chunks)


def _build_opener(proxy):
    """Открыватель запросов с учётом прокси.

    С хостинга в России api.anthropic.com напрямую недоступен, поэтому
    запрос идёт через прокси, адрес которого лежит рядом с ключом.
    Поддерживаются два вида:

      http://host:port, https://... — умеет сама стандартная библиотека;
      socks5://... и socks5h://... — нужен PySocks (pip install --user
        pysocks). Он подменяет сокет глобально, поэтому подменяем только
        когда прокси действительно socks, и говорим об этом вслух в
        ошибке, если библиотеки нет.

    socks5h отличается от socks5 тем, что имя хоста разрешает прокси, а
    не наш сервер, — для закрытого извне домена это и нужно.
    """
    if not proxy:
        return urllib.request.build_opener()

    scheme = urlparse(proxy).scheme.lower()
    if scheme in ("http", "https"):
        return urllib.request.build_opener(
            urllib.request.ProxyHandler({"http": proxy, "https": proxy}))

    if scheme.startswith("socks"):
        try:
            import socks  # noqa: F401  (PySocks)
            import socket
            from sockshandler import SocksiPyHandler  # type: ignore
        except ImportError:
            # sockshandler идёт вместе с PySocks, но не везде; если его
            # нет, подменяем сокет сами — процесс одноразовый и фоновый,
            # другой сети в нём не бывает.
            try:
                import socks
                import socket
            except ImportError:
                raise ClaudeError(
                    "Для прокси socks5 нужен пакет PySocks: "
                    "pip install --user pysocks")
            parsed = urlparse(proxy)
            socks.set_default_proxy(
                socks.SOCKS5, parsed.hostname, parsed.port or 1080,
                rdns=scheme.endswith("h"),
                username=parsed.username, password=parsed.password)
            socket.socket = socks.socksocket
            return urllib.request.build_opener()

        parsed = urlparse(proxy)
        return urllib.request.build_opener(SocksiPyHandler(
            socks.SOCKS5, parsed.hostname, parsed.port or 1080,
            rdns=scheme.endswith("h"),
            username=parsed.username, password=parsed.password))

    raise ClaudeError(f"Неизвестный вид прокси: {scheme}")


class ClaudeClient:
    """Минимальный клиент: один метод, один запрос, ответ по схеме."""

    def __init__(self, api_key=None, model=None, timeout=DEFAULT_TIMEOUT_SEC,
                 proxy=None, effort=None, max_retries=_MAX_RETRIES):
        self.api_key = api_key or os.environ.get("ANTHROPIC_API_KEY") or ""
        if not self.api_key:
            raise ClaudeError("Не задан ключ Claude API (ANTHROPIC_API_KEY)")
        self.model = model or os.environ.get("ANTHROPIC_MODEL") or DEFAULT_MODEL
        if effort is not None and effort not in EFFORT_LEVELS:
            raise ClaudeError("Недопустимый уровень усилия %r; допустимо: %s"
                              % (effort, ", ".join(EFFORT_LEVELS)))
        env_effort = os.environ.get("ANTHROPIC_EFFORT") or ""
        if env_effort and env_effort not in EFFORT_LEVELS:
            # Опечатка в файле с ключом не должна останавливать разбор альбома.
            print("effort_equipment %r не распознан, усилие %s" % (env_effort, DEFAULT_EFFORT), file=sys.stderr)
            env_effort = ""
        self.effort = effort or env_effort or DEFAULT_EFFORT
        self.timeout = timeout
        if not isinstance(max_retries, int) or not 0 <= max_retries <= _MAX_RETRIES:
            raise ClaudeError("Недопустимое число повторов API")
        self.max_retries = max_retries
        self.proxy = proxy if proxy is not None else os.environ.get("ANTHROPIC_PROXY", "")
        self._opener = _build_opener(self.proxy)

    def _post(self, body):
        request = urllib.request.Request(
            API_URL,
            data=json.dumps(body).encode("utf-8"),
            method="POST",
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
                "x-api-key": self.api_key,
                "anthropic-version": API_VERSION,
            },
        )
        with self._opener.open(request, timeout=self.timeout) as resp:
            return json.loads(_read_capped(resp).decode("utf-8"))

    def extract_json(self, system, text, schema, max_tokens=DEFAULT_MAX_TOKENS,
                     image_png=None):
        """Ответ модели как словарь, разобранный по schema.

        text — текст запроса; image_png — картинка страницы (байты PNG)
        или None. Картинка кладётся ПЕРЕД текстом: так рекомендует
        документация Anthropic, и на листах чертежей это заметно по
        качеству ответа.

        output_config.format гарантирует, что в ответе будет валидный
        JSON по этой схеме, — не нужно ни просить "ответь только JSON"
        в промпте, ни вычищать markdown-обёртку из ответа.
        """
        content = []
        if image_png:
            content.append({
                "type": "image",
                "source": {
                    "type": "base64",
                    "media_type": "image/png",
                    "data": base64.b64encode(image_png).decode("ascii"),
                },
            })
        content.append({"type": "text", "text": text})

        body = {
            "model": self.model,
            "max_tokens": max_tokens,
            "system": system,
            "messages": [{"role": "user", "content": content}],
            "output_config": {"effort": self.effort,
                              "format": {"type": "json_schema", "schema": schema}},
        }

        last_error = None
        for attempt in range(self.max_retries + 1):
            try:
                payload = self._post(body)
                break
            except urllib.error.HTTPError as exc:
                detail = _read_capped(exc).decode("utf-8", "replace")
                if exc.code in _RETRY_CODES and attempt < self.max_retries:
                    last_error = f"{exc.code}: {detail}"
                    time.sleep(_RETRY_BASE_DELAY_SEC * (2 ** attempt))
                    continue
                raise ClaudeError(f"Claude API ответил ошибкой ({exc.code}): {detail}") from exc
            except (urllib.error.URLError, TimeoutError, ConnectionError) as exc:
                if attempt < self.max_retries:
                    last_error = str(getattr(exc, "reason", exc))
                    time.sleep(_RETRY_BASE_DELAY_SEC * (2 ** attempt))
                    continue
                raise ClaudeError(f"Не удалось соединиться с Claude API: {getattr(exc, 'reason', exc)}") from exc
        else:  # pragma: no cover — цикл всегда выходит через break или raise
            raise ClaudeError(f"Claude API недоступен: {last_error}")

        # Модель может отказаться отвечать (stop_reason "refusal") — тогда
        # содержимого в ответе нет, и читать content бессмысленно.
        if payload.get("stop_reason") == "max_tokens":
            raise ClaudeError("Ответ Claude обрезан лимитом длины; разделите страницу")
        if payload.get("stop_reason") == "refusal":
            raise ClaudeError("Claude API отказался обрабатывать запрос")

        for block in payload.get("content") or []:
            if block.get("type") == "text":
                return json.loads(block["text"])
        raise ClaudeError(f"В ответе Claude API нет текста: {payload}")


def client_from_environment(model=None):
    """Клиент, если ключ задан, и None, если нет.

    Блок "Оборудование" работает и без модели — просто разбирает меньше
    листов подбора. Поэтому отсутствие ключа это не ошибка, а штатный
    режим, и решать это должен вызывающий код, а не исключение.
    """
    if not os.environ.get("ANTHROPIC_API_KEY"):
        return None
    return ClaudeClient(model=model)
