# CleanPapper: Project Profiler v1

## Purpose
Before taking quantities, inspect source compatibility. The profile is bound to the SHA-256 of the original PDF. It is a diagnostic layer, not an approved measurement profile. It does not replace the existing per-page automatic preview profile.

- All sheets: extracted-text coverage and actual PDF dimensions.
- Up to six sheets, chosen by detected kind (plans, axonometry, mixed, unclassified, other): painted vector/image operations, limited stroke-color and line-weight counts, explicit printed scale candidates. A page with more than 12,000 painted paths is marked as too complex for full style inspection. These are not duct counts.
- The source page IDs and coverage are stored in JSON. A title, stroke color or printed scale cannot by itself approve a system, calibrated scale, floor multiplier or duct length.
- If the register is not verified or the specification range is ambiguous, display that status rather than guessing.

## Interface
After album analysis the compatibility profile appears before the specification controls; it shows warnings and sampled pages and can be downloaded as JSON. No extra API calls and no permanent upload storage. The project-specific geometry settings remain unapproved until independent evidence exists.

## Validation
Five synthetic tests cover color and neutral linework, arbitrary scale 1:75, varying PDF sizes, image-only pages and bounded stratified sampling. A local diagnostic using the original 181-page ventilation PDF and previously exported page classification found seven page dimension variants and several extremely complex drawing pages (up to roughly 594,000 painted vector operations in the sample); the profile deliberately did not infer their stroke style from a truncated sample. Full integrated album latency and independent ventilation projects still need testing. This does not establish automatic takeoff accuracy.

## Next
Use a second independent ventilation PDF + verified quantity sheet. Add spatially bounded style extraction, general scale calibration, neutral-line topology, alternate register layouts and held-out precision/recall metrics. Geometry thresholds and floor multiplicity must remain project-specific, not copied from the reference object.
