# -*- coding: utf-8 -*-
"""PDF-отчёт графического сравнения — по образцу эталона заказчика
(«Графическое сравнение 143/23-ГК-РД-1-ОВ2»):

1. Общие сведения — редакции, что и как сравнивалось, что отброшено.
2. Ключевые изменения — по каждому изменению комплекта, по сути.
3. Сводка по листам — лист × изменение: сколько зон каких категорий.
4. Сверка с разрешениями — несоответствия и замечания.
5. Изменения по листам — обзор листа с зонами, таблица зон и фрагменты
   «было | стало».

Текстовые разделы верстаются HTML (fitz.Story), страницы листов
собираются вручную: Story не умеет разорвать строку таблицы между
страницами и на широкой картинке рядом с длинной таблицей зацикливается.
"""
import html
import io
import os

import fitz


_FONT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fonts")
PAGE = fitz.paper_rect("a4-l")
MARGIN = 34.0
NAVY = "#263C5C"
_MAX_FLOW_PAGES = 300

CATEGORY_COLORS = {
    "Трасса": "#1F5BD8",
    "Оборудование": "#E67E00",
    "Трасса + оборудование": "#8E24AA",
    "Огнезащита/изоляция": "#7F8C8D",
    "Замечание": "#C0392B",
    "Не разобрано": "#555555",
}
CATEGORY_SHORT = {
    "Трасса": "Трасса",
    "Оборудование": "Оборудование",
    "Трасса + оборудование": "Тр.+обор.",
    "Огнезащита/изоляция": "Огнезащита",
    "Замечание": "Замечание",
    "Не разобрано": "Не разобрано",
}

_CSS = """
@font-face {font-family: dv; src: url(DejaVuSans.ttf);}
@font-face {font-family: dv; src: url(DejaVuSans-Bold.ttf); font-weight: bold;}
* {font-family: dv; font-size: 7.6pt; line-height: 1.25;}
h1 {font-size: 14pt; color: %(navy)s; margin: 0 0 4pt 0;}
h2 {font-size: 11pt; color: %(navy)s; margin: 8pt 0 3pt 0;}
h3 {font-size: 9pt; color: %(navy)s; margin: 5pt 0 2pt 0;}
p {margin: 0 0 3pt 0;}
table {border-collapse: collapse; width: 100%%;}
td, th {border: 0.5pt solid #9AA5B5; padding: 1.5pt 3pt; vertical-align: top; text-align: left;}
th {color: %(navy)s; font-weight: bold; border-bottom: 1.2pt solid %(navy)s;}
.note {color: #555555; font-size: 7pt;}
.item {margin: 0 0 2pt 10pt;}
""" % {"navy": NAVY}


def _archive():
    archive = fitz.Archive()
    for name in ("DejaVuSans.ttf", "DejaVuSans-Bold.ttf"):
        with open(os.path.join(_FONT_DIR, name), "rb") as handle:
            archive.add(handle.read(), name)
    return archive


def e(text):
    return html.escape(str(text if text is not None else ""))


def _category_html(category):
    color = CATEGORY_COLORS.get(category, "#333333")
    return '<span style="color:%s"><b>%s</b></span>' % (color, e(category))


def _rgb(hex_color):
    hex_color = hex_color.lstrip("#")
    return tuple(int(hex_color[i:i + 2], 16) / 255.0 for i in (0, 2, 4))


# ------------------------------------------------------- текстовые разделы

def _flow(doc, body, archive):
    """HTML-раздел, разлитый по страницам, — в конец doc. Story рисует
    только через DocumentWriter, поэтому — через PDF в памяти."""
    out = io.BytesIO()
    writer = fitz.DocumentWriter(out)
    story = fitz.Story(html=body, user_css=_CSS, archive=archive)
    where = PAGE + (MARGIN, MARGIN, -MARGIN, -MARGIN - 10)
    more = 1
    pages = 0
    while more and pages < _MAX_FLOW_PAGES:
        device = writer.begin_page(PAGE)
        more, filled = story.place(where)
        story.draw(device)
        writer.end_page()
        pages += 1
        # Ничего не уместилось — дальше будет то же самое: Story не умеет
        # разорвать слишком высокий элемент, выходим, а не крутимся.
        if more and fitz.Rect(filled).is_empty:
            break
    writer.close()
    part = fitz.open("pdf", out.getvalue())
    doc.insert_pdf(part)
    part.close()


def general_section(info):
    rows = "".join(
        "<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>"
        % (e(r["label"]), e(r["file"]), e(r["permit"]), e(r["pages"]), e(r["graphic"]))
        for r in info["editions"])
    parts = [
        "<h1>Графическое сравнение редакций РД %s</h1>" % e(info.get("marka") or ""),
        "<p>%s</p>" % e(info["object"]) if info.get("object") else "",
        "<h2>1. Общие сведения</h2>",
        "<table><tr><th>Редакция</th><th>Файл</th><th>Разрешение</th><th>Стр.</th>"
        "<th>Графические листы (PDF-стр.)</th></tr>%s</table>" % rows,
        "<p><b>Что сравнивалось.</b> %s</p>" % e(info["compared"]),
        "<p><b>Как.</b> Растр листов с учётом поворота; совмещение по уникальным "
        "надписям — несколько сдвигов, если рамка и план сдвинуты по-разному, — плюс "
        "локальное совмещение фрагментов (перенос блока схемы не считается изменением). "
        "Сравниваются сети и оборудование — цветные и чёрные штрихи; светло-серая "
        "подоснова АР и надписи текстового слоя в счёт не идут. QR-коды, штамп и графа "
        "изменений исключены.</p>",
        "<p><b>Что отброшено как малое.</b> Зоны менее ~30 мм изменённых штрихов, "
        "парные сдвиги линий, смена тона штриховки. Каждую оставшуюся зону просмотрела "
        "модель (%s) по фрагментам «было | стало» и отнесла к категории: %s; "
        "несущественные (сдвиг подосновы, марки и привязки без изменения графики, "
        "оформление) в отчёт не вошли.</p>" % (e(info.get("model") or "модель не подключена"),
                                                ", ".join(_category_html(c) for c in (
                                                    "Трасса", "Оборудование",
                                                    "Трасса + оборудование",
                                                    "Огнезащита/изоляция", "Замечание"))),
        "<p class='note'>На обзорах листов: <span style='color:#E12828'>красное</span> — "
        "удалено, <span style='color:#1EA01E'>зелёное</span> — добавлено, фон — новая "
        "редакция. На фрагментах: слева прежняя редакция (розовый фон), справа новая "
        "(зелёный фон); изменившиеся штрихи — пурпурные.</p>",
    ]
    return "".join(parts)


def key_changes_section(pairs):
    out = ["<h2>2. Ключевые изменения</h2>"]
    for pair in pairs:
        out.append("<h3>%s</h3>" % e(pair["change"]))
        summary = pair.get("summary") or {}
        items = summary.get("key_changes") or []
        if items:
            for item in items:
                out.append("<p class='item'><b>%s</b> %s</p>" % (e(item["lead"]), e(item["text"])))
            continue
        # Без модели — перечень изменённых листов и их зон.
        changed = [s for s in pair["sheets"] if s["zones"] or s.get("reworked")]
        if not changed:
            out.append("<p class='item'>Существенных графических изменений не найдено.</p>")
        for sheet in changed:
            if sheet.get("reworked"):
                text = "лист переработан целиком."
            else:
                text = "; ".join("зона %d — %s" % (z.get("n_report", z["n"]), z["description"])
                                 for z in sheet["zones"][:4])
            out.append("<p class='item'><b>%s.</b> %s</p>" % (e(sheet["label"]), e(text)))
    return "".join(out)


def _cell(sheet):
    if sheet is None:
        return ""
    if sheet.get("status_text"):
        return sheet["status_text"]
    if sheet.get("reworked"):
        return "Переработан целиком"
    counts = {}
    for zone in sheet["zones"]:
        short = CATEGORY_SHORT.get(zone.get("category"), zone.get("category") or "?")
        counts[short] = counts.get(short, 0) + 1
    if not counts:
        return "—"
    return ", ".join("%s %d" % (k, v) for k, v in counts.items())


# Строк в одной таблице сводки. Story переносит таблицу на следующую
# страницу только один раз: таблица длиннее двух страниц вылезала за
# нижний край, а всё после неё (сверка с разрешениями) пропадало. Поэтому
# сводка — подряд идущими таблицами, каждая не длиннее страницы.
_ROWS_PER_TABLE = 15


def sheets_section(pairs, order):
    """Сводка по листам: строки — листы в порядке альбома, колонки — пары."""
    head = "<tr><th>Лист</th><th>Наименование</th>%s</tr>" % "".join(
        "<th>%s</th>" % e(p["label"]) for p in pairs)
    rows = []
    for label, title, sheets in order:
        cells = "".join("<td>%s</td>" % e(_cell(sheet)) for sheet in sheets)
        rows.append("<tr><td>%s</td><td>%s</td>%s</tr>" % (e(label), e(title), cells))
    # Части — поровну: ширину колонок Story подбирает по содержимому
    # каждой таблицы, и хвост из одной строки выходил узкой таблицей
    # другого вида.
    parts = max(1, -(-len(rows) // _ROWS_PER_TABLE))
    size = -(-len(rows) // parts) if rows else 1
    tables = "".join("<table>%s%s</table>" % (head, "".join(rows[i:i + size]))
                     for i in range(0, len(rows), size))
    return ("<h2>3. Сводка по листам (существенные зоны)</h2>%s"
            "<p class='note'>«—» — существенных изменений трасс и оборудования нет; "
            "пусто — листа в этой паре редакций нет.</p>" % tables)


def permit_section(pairs):
    out = ["<h2>4. Сверка с разрешениями</h2>"]
    for pair in pairs:
        summary = pair.get("summary") or {}
        items = summary.get("permit_check")
        if items:
            for item in items:
                out.append("<p class='item'><b>%s</b> %s</p>" % (e(item["lead"]), e(item["text"])))
            continue
        for line in pair.get("permit_lines") or []:
            out.append("<p class='item'><b>%s.</b> %s</p>" % (e(pair["change"]), e(line)))
    return "".join(out)


# --------------------------------------------------------- страницы листов

def _fit(rect, w, h):
    """Прямоугольник с пропорциями w×h, вписанный в rect (по левому верху)."""
    scale = min(rect.width / float(w), rect.height / float(h))
    return fitz.Rect(rect.x0, rect.y0, rect.x0 + w * scale, rect.y0 + h * scale)


def _zone_rows(zones):
    return ["<tr><td>%d</td><td>%s</td><td>%s</td><td>%s</td></tr>"
            % (z.get("n_report", z["n"]), e(z.get("system")), _category_html(z.get("category")),
               e(z.get("description"))) for z in zones]


_ZONE_HEAD = "<tr><th>№</th><th>Система</th><th>Категория</th><th>Изменение</th></tr>"


def _table_pages(doc, first_page, rect, rows, archive, heading):
    """Таблица зон в rect первой страницы; что не поместилось — на
    следующих страницах во всю ширину."""
    page, box = first_page, rect
    while rows:
        count = len(rows)
        while count > 0:
            spare, _scale = page.insert_htmlbox(
                box, "<table>%s%s</table>" % (_ZONE_HEAD, "".join(rows[:count])),
                css=_CSS, archive=archive, scale_low=1)
            if spare >= 0:
                break
            count -= 1
        if count == 0:
            count = 1  # строка не помещается даже одна — ужимаем её
            page.insert_htmlbox(box, "<table>%s%s</table>" % (_ZONE_HEAD, rows[0]),
                                css=_CSS, archive=archive, scale_low=0.3)
        rows = rows[count:]
        if rows:
            page = doc.new_page(width=PAGE.width, height=PAGE.height)
            page.insert_htmlbox(fitz.Rect(MARGIN, MARGIN, PAGE.width - MARGIN, MARGIN + 18),
                                "<h3>%s (продолжение)</h3>" % e(heading), css=_CSS, archive=archive)
            box = fitz.Rect(MARGIN, MARGIN + 22, PAGE.width - MARGIN, PAGE.height - MARGIN - 12)


def _zone_frames(page, rect, overview, zones):
    """Рамки и номера зон поверх обзора — векторами страницы отчёта, а не
    в самой картинке: так обзор не пережимается второй раз, а рамки и
    цифры чёткие при любом увеличении."""
    k = rect.width / float(overview["w"]) * overview["scale"]
    for zone in zones:
        color = _rgb(CATEGORY_COLORS.get(zone.get("category"), "#333333"))
        x0, y0, x1, y1 = zone["box"]
        frame = fitz.Rect(rect.x0 + x0 * k - 1.5, rect.y0 + y0 * k - 1.5,
                          rect.x0 + x1 * k + 1.5, rect.y0 + y1 * k + 1.5) & rect
        page.draw_rect(frame, color=color, width=0.9)
        label = str(zone.get("n_report", zone["n"]))
        width = 3 + 4.2 * len(label)
        top = frame.y0 - 8 if frame.y0 - 8 >= rect.y0 else frame.y0
        tag = fitz.Rect(frame.x0, top, frame.x0 + width, top + 8)
        page.draw_rect(tag, color=color, fill=color, width=0.5)
        page.insert_text((tag.x0 + 1.5, tag.y1 - 1.8), label, fontsize=6.5,
                         fontname="helv", color=(1, 1, 1))


def sheet_pages(doc, pair, sheet, archive, section_title=None):
    heading = "Лист %s%s%s · %s" % (sheet["number"] or sheet["label"],
                                    " (%s)" % sheet["how"] if sheet.get("how") else "",
                                    (" — " + sheet["title"]) if sheet.get("title") else "",
                                    pair["label"])
    page = doc.new_page(width=PAGE.width, height=PAGE.height)
    head = "<h3>%s</h3>" % e(heading)
    if section_title:
        head = "<h2>%s</h2>" % e(section_title) + head
    head_h = 52 if section_title else 30
    page.insert_htmlbox(fitz.Rect(MARGIN, MARGIN, PAGE.width - MARGIN, MARGIN + head_h),
                        head, css=_CSS, archive=archive, scale_low=0.6)
    top = MARGIN + head_h + 2
    if sheet.get("reworked"):
        page.insert_htmlbox(
            fitz.Rect(MARGIN, top, PAGE.width - MARGIN, top + 30),
            "<p><b>Лист переработан целиком</b>: изменилось %.0f%% значимых штрихов — "
            "перекомпонован или под тем же номером выпущен другой чертёж. Зоны изменений "
            "не выделяются: сравните редакции листа целиком (слева прежняя, справа новая)."
            "</p>" % (100.0 * sheet.get("share", 0.0)), css=_CSS, archive=archive)
        half = (PAGE.width - 2 * MARGIN - 12) / 2.0
        y0 = top + 34
        for i, (data, w, h) in enumerate((sheet["old_full"], sheet["new_full"])):
            x0 = MARGIN + i * (half + 12)
            rect = _fit(fitz.Rect(x0, y0, x0 + half, PAGE.height - MARGIN - 14), w, h)
            page.insert_image(rect, stream=data)
            page.draw_rect(rect, color=(0.6, 0.6, 0.6), width=0.5)
        return

    ov = sheet["overview"]
    left = fitz.Rect(MARGIN, top, MARGIN + (PAGE.width - 2 * MARGIN) * 0.52,
                     PAGE.height - MARGIN - 14)
    rect = _fit(left, ov["w"], ov["h"])
    page.insert_image(rect, stream=ov["data"])
    page.draw_rect(rect, color=(0.7, 0.7, 0.7), width=0.4)
    _zone_frames(page, rect, ov, sheet["zones"])
    right = fitz.Rect(left.x1 + 10, top, PAGE.width - MARGIN, PAGE.height - MARGIN - 14)
    _table_pages(doc, page, right, _zone_rows(sheet["zones"]), archive, heading)

    # Фрагменты зон — по две на страницу.
    shown = [z for z in sheet["zones"] if z.get("frag_old")]
    for start in range(0, len(shown), 2):
        page = doc.new_page(width=PAGE.width, height=PAGE.height)
        slot_h = (PAGE.height - 2 * MARGIN - 14) / 2.0
        for i, zone in enumerate(shown[start:start + 2]):
            y0 = MARGIN + i * slot_h
            caption = "<p><b>Лист %s, зона %d</b> · %s · %s — %s</p>" % (
                e(sheet["number"] or sheet["label"]), zone.get("n_report", zone["n"]),
                e(zone.get("system")), _category_html(zone.get("category")),
                e(zone.get("description")))
            spare, _s = page.insert_htmlbox(fitz.Rect(MARGIN, y0, PAGE.width - MARGIN, y0 + 30),
                                            caption, css=_CSS, archive=archive, scale_low=0.6)
            img_top = y0 + 32
            half = (PAGE.width - 2 * MARGIN - 16) / 2.0
            for j, data in enumerate((zone["frag_old"], zone["frag_new"])):
                x0 = MARGIN + j * (half + 16)
                box = fitz.Rect(x0, img_top, x0 + half, y0 + slot_h - 6)
                rect = _fit(box, zone["frag_w"], zone["frag_h"])
                page.insert_image(rect, stream=data)


def _footer(doc, text):
    for index, page in enumerate(doc, 1):
        page.insert_text((MARGIN, PAGE.height - 14), text, fontsize=6.5,
                         fontname="dv", fontfile=os.path.join(_FONT_DIR, "DejaVuSans.ttf"),
                         color=(0.45, 0.45, 0.45))
        label = "стр. %d" % index
        page.insert_text((PAGE.width - MARGIN - 30, PAGE.height - 14), label, fontsize=6.5,
                         fontname="dv", fontfile=os.path.join(_FONT_DIR, "DejaVuSans.ttf"),
                         color=(0.45, 0.45, 0.45))


def build(output_path, info, pairs, order, log=print):
    """info — общие сведения; pairs — изменения комплекта с разобранными
    листами; order — [(лист, наименование, [лист в каждой паре])] в
    порядке альбома (см. compare._sheet_order)."""
    archive = _archive()
    doc = fitz.open()
    body = (general_section(info) + key_changes_section(pairs)
            + sheets_section(pairs, order) + permit_section(pairs))
    _flow(doc, body, archive)
    title = "5. Изменения по листам"
    for pair in pairs:
        for sheet in pair["sheets"]:
            if not (sheet["zones"] or sheet.get("reworked")):
                continue
            sheet_pages(doc, pair, sheet, archive, section_title=title)
            title = None
    _footer(doc, info.get("footer") or "")
    for page in doc:
        page.clean_contents()
    # garbage=4 сливает одинаковые потоки: каждый текстовый блок страницы
    # встраивает шрифт заново, и без слияния 205 копий DejaVu давали 75 МБ
    # из 100 МБ отчёта ВК.
    doc.save(output_path, deflate=True, garbage=4)
    log("Отчёт по чертежам собран: %d стр." % len(doc))
    return len(doc)
