#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Инвентаризация задачи Verrata для веб-страницы — карточка «Что я нашёл».

Запускается в фоне, как и само сравнение: чтение штампов всех листов трёх
альбомов занимает десяток секунд, дольше, чем живёт HTTP-соединение.
Пишет тот же файл статуса, что и основной прогон, и заканчивает состоянием
awaiting_confirm — страница подтверждения ждёт именно его.

Запуск (из web/verrata_process.php):
    python3 web_verrata_inventory.py --status-file ... --card-file ... \\
        [--nz a.pdf b.pdf] -- rev1.pdf rev2.pdf
"""
import argparse
import json
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import startup_check  # noqa: E402  — причина падения на импорте, см. модуль

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

_HERE = os.path.dirname(os.path.abspath(__file__))
for _path in (_HERE, os.path.dirname(_HERE), os.path.join(os.path.dirname(_HERE), "program-a")):
    if _path not in sys.path:
        sys.path.insert(0, _path)


def _write(path, payload):
    """Статус пишется через временный файл: страница читает его в любой
    момент, и недописанный JSON она прочитала бы как сбой."""
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False)
    os.replace(tmp, path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--status-file", required=True)
    parser.add_argument("--card-file", required=True)
    parser.add_argument("--nz", nargs="*", default=[])
    parser.add_argument("pdfs", nargs="+")
    args = parser.parse_args()

    started = int(time.time())
    base = {"state": "inventory", "stage": "читаю файлы…", "started": started}
    _write(args.status_file, dict(base, updated=started))

    def progress(name, page, total):
        _write(args.status_file, dict(
            base, updated=int(time.time()),
            stage=f"{name}: лист {page} из {total}"))

    try:
        from inventory import build_inventory
        card = build_inventory(args.pdfs, nz_paths=args.nz, progress=progress)
    except Exception as exc:                      # noqa: BLE001
        _write(args.status_file, {"state": "error", "ok": False,
                                 "started": started, "updated": int(time.time()),
                                 "error": startup_check.explain(exc)
                                 if isinstance(exc, (ImportError, SyntaxError))
                                 else str(exc)})
        print(f"инвентаризация не удалась: {exc}", file=sys.stderr)
        return 1

    with open(args.card_file, "w", encoding="utf-8") as handle:
        json.dump(card, handle, ensure_ascii=False)
    _write(args.status_file, {"state": "awaiting_confirm", "ok": True,
                             "started": started, "updated": int(time.time()),
                             "stage": "жду подтверждения ролей"})
    return 0


if __name__ == "__main__":
    sys.exit(main())
