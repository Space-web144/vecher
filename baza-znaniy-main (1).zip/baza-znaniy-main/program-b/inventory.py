# -*- coding: utf-8 -*-
"""
Инвентаризация загруженных файлов — карточка «Что я нашёл».

Роль редакции (исходная, изм.1, изм.2) определяется по имени файла, а имя
врёт: пакеты пересылают почтой, браузер дописывает «(1)», даты в именах
ставят от руки. Перепутанные роли дают отчёт, по которому закупят не то, —
и это не та ошибка, которую инженер заметит в готовом Excel, потому что
там всё выглядит стройно, только задом наперёд.

Поэтому разбор не начинается молча: сначала собирается карточка — что за
файлы, сколько листов, какая марка в штампе, где листы спецификации, какие
есть разрешения на внесение изменений и что написано в таблице изменений
штампа, — и инженер подтверждает роли (см. revisions.apply_roles). Это
единственная точка human-in-the-loop во всём конвейере, и документ
заказчика называет её критичной.

Ничего не сравнивает и не решает: только собирает факты для показа.
"""
import os
import re

import fitz

from revisions import parse_revision, revision_label
from spec_diff import _is_spec_marka
from permits import page_lines as _page_lines
from stamp import extract_stamp, page_words, pick_document_marka

# Лист разрешения на внесение изменений: заголовок печатается по-разному
# ("Разрешение на внесение изменений", "РАЗРЕШЕНИЕ № 1125-70-21"), но слово
# "разрешение" в начале строки есть всегда.
_PERMIT_RE = re.compile(r"\bразрешени\w*\b", re.IGNORECASE)
# Номер разрешения печатается без "№" и отдельной строкой: "1668/25",
# "1125-70-21". От обозначения комплекта отличается тем, что в нём нет букв.
_PERMIT_NUMBER_RE = re.compile(r"^\d{3,6}[-/]\d{2,6}(?:[-/]\d{1,4})?$")
_DATE_RE = re.compile(r"\b(\d{2}[.\-/]\d{2}[.\-/]\d{2,4})\b")
# Строка содержания изменения на листе разрешения: "1(Зам.) 1 Общие
# указания дополнены пунктом…", "1(Изм.) 12 На плане в системе К2…".
_CHANGE_ROW_RE = re.compile(r"^(\d{1,2})\s*\(\s*(Зам|Изм|Нов)\.?\s*\)\s*(.*)$",
                            re.IGNORECASE)
# Сколько строк содержания показывать на карточке: это предпросмотр, а не
# отчёт — полный разбор разрешений делается отдельно.
_CHANGE_ROWS_SHOWN = 4
# Строка таблицы изменений штампа считается содержательной, только если в
# ней есть и вид изменения, и цифра: иначе в неё попадают отметки уровней
# ("+82.350") и обрывки подписей ("27 этаж").
_STAMP_CHANGE_RE = re.compile(r"(Зам|Нов|Изм)\.?", re.IGNORECASE)
_CHANGE_LOG_SHOWN = 3


def _permit(lines, page_number):
    """Запись о разрешении на внесение изменений — или None."""
    if not any(_PERMIT_RE.search(line) for line in lines[:8]):
        return None
    number = ""
    for line in lines[:10]:
        for token in line.split():
            if _PERMIT_NUMBER_RE.match(token):
                number = token
                break
        if number:
            break
    changes = []
    for line in lines:
        match = _CHANGE_ROW_RE.match(line.strip())
        if match and match.group(3).strip():
            changes.append(f"изм. {match.group(1)} ({match.group(2).capitalize()}.) "
                           f"— {match.group(3).strip()}")
        if len(changes) >= _CHANGE_ROWS_SHOWN:
            break
    dates = _DATE_RE.findall(" ".join(lines[:10]))
    return {
        "page": page_number,
        "number": number,
        "dates": dates[:2],
        "changes": changes,
    }


def file_inventory(path, progress=None):
    """Карточка одного файла: что в нём нашлось."""
    doc = fitz.open(path)
    name = os.path.basename(path)
    _base, number = parse_revision(path)
    stamps = []
    spec_pages = []
    permits = []
    sizes = {}
    for index in range(len(doc)):
        page = doc[index]
        words = page_words(page)
        stamp = extract_stamp(page, words=words)
        stamps.append(stamp)
        if _is_spec_marka(stamp.get("marka")):
            spec_pages.append(index + 1)
        found = _permit(_page_lines(words), index + 1)
        if found:
            permits.append(found)
        key = f"{page.rect.width:.0f}x{page.rect.height:.0f}"
        sizes[key] = sizes.get(key, 0) + 1
        if progress:
            progress(name, index + 1, len(doc))

    change_log = []
    for stamp in stamps:
        for line in stamp.get("change_log") or ():
            if (line not in change_log and _STAMP_CHANGE_RE.search(line)
                    and any(ch.isdigit() for ch in line)):
                change_log.append(line)
    # Дата разрешения на самом листе обычно не напечатана — она стоит в
    # таблице изменений штампа рядом с его номером ("1 - Зам. 1668/25
    # 17.06.25"). Берём оттуда: инженеру на карточке нужна именно дата.
    for permit in permits:
        if permit["dates"] or not permit["number"]:
            continue
        for line in change_log:
            if permit["number"] in line:
                found = _DATE_RE.findall(line)
                if found:
                    permit["dates"] = found[:1]
                    break

    return {
        "file": name,
        "pages": len(doc),
        "formats": [f"{key} pt — {count} л." for key, count in
                    sorted(sizes.items(), key=lambda item: -item[1])],
        "marka": pick_document_marka(stamps) or "",
        "role_number": number,
        "role_label": revision_label(path),
        "spec_pages": ([spec_pages[0], spec_pages[-1]] if spec_pages else None),
        "spec_sheets": len(spec_pages),
        "permits": permits,
        "change_log": change_log[-_CHANGE_LOG_SHOWN:],
        "created": (doc.metadata or {}).get("creationDate") or "",
    }


def build_inventory(pdf_paths, nz_paths=(), progress=None):
    """Карточка задачи целиком: файлы редакций и наряд-заказы.

    Роли в карточке — предположение по именам файлов; подтверждает их
    инженер, и его выбор уходит в compare_files(roles=...).
    """
    revisions = [file_inventory(path, progress) for path in pdf_paths]
    orders = []
    for path in nz_paths:
        doc = fitz.open(path)
        orders.append({"file": os.path.basename(path), "pages": len(doc)})
    numbers = [item["role_number"] for item in revisions]
    return {
        "revisions": revisions,
        "nz": orders,
        # Чем карточка должна насторожить инженера: нет исходной редакции,
        # две редакции с одним номером, разные марки в штампах.
        "warnings": _warnings(revisions, numbers),
    }


def _warnings(revisions, numbers):
    out = []
    if revisions and 0 not in numbers:
        out.append("Ни один файл не распознан как исходная редакция — "
                   "у всех в имени есть пометка «изм.».")
    duplicates = sorted({n for n in numbers if numbers.count(n) > 1})
    for number in duplicates:
        what = ("исходной редакцией" if number == 0 else f"изм. {number}")
        names = ", ".join("«%s»" % item["file"] for item in revisions
                          if item["role_number"] == number)
        out.append(f"Несколько файлов считаются {what}: {names}.")
    markas = {item["marka"] for item in revisions if item["marka"]}
    if len(markas) > 1:
        out.append("В штампах разные марки: " + ", ".join(sorted(markas))
                   + ". Проверьте, что это редакции одного комплекта.")
    without_spec = [item["file"] for item in revisions if not item["spec_pages"]]
    if without_spec and len(without_spec) < len(revisions):
        out.append("Листы спецификации найдены не во всех файлах — нет в: "
                   + ", ".join("«%s»" % name for name in without_spec) + ".")
    return out
