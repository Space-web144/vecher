#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Вопрос инженера по одной строке отчёта Verrata — ответ агента.

Читается готовая книга, а не пересобранный разбор: инженер спрашивает про
то, что видит на экране, и ответ обязан опираться на те же числа. Модель
ничего не считает заново — количества и дельты уже посчитаны (см.
spec_excel.read_report_row), её работа только объяснить их словами.

Запуск (из web/verrata_ask.php):
    python3 web_verrata_ask.py --xlsx отчёт.xlsx --row 13 \\
        --credentials /путь/к/anthropic.json --question "почему стало 0?"

Печатает JSON: {"ok": true, "answer": "…"} или {"ok": false, "error": "…"}.
"""
import argparse
import json
import os
import sys

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")

_HERE = os.path.dirname(os.path.abspath(__file__))
for _path in (_HERE, os.path.dirname(_HERE)):
    if _path not in sys.path:
        sys.path.insert(0, _path)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--xlsx", required=True)
    parser.add_argument("--row", type=int, required=True)
    parser.add_argument("--question", required=True)
    parser.add_argument("--credentials", default=None,
                        help="файл с ключом Anthropic; читает его сам Python")
    parser.add_argument("--provider", default="claude")
    args = parser.parse_args()

    def out(payload):
        print(json.dumps(payload, ensure_ascii=False))
        return 0 if payload.get("ok") else 1

    from spec_excel import ReportRowError, read_report_row
    try:
        row = read_report_row(args.xlsx, args.row)
    except ReportRowError as exc:
        return out({"ok": False, "error": str(exc)})
    except Exception as exc:                      # noqa: BLE001
        return out({"ok": False, "error": f"Отчёт прочитать не удалось: {exc}"})

    from narrative import answer_row_question, try_make_client
    client = try_make_client(args.provider, credentials_file=args.credentials,
                             log=lambda *_a, **_k: None)
    if client is None:
        return out({"ok": False,
                    "error": "Агент недоступен: не настроен доступ к модели."})
    answer = answer_row_question(client, row, args.question)
    if not answer:
        return out({"ok": False, "error": "Агент не ответил — попробуйте ещё раз."})
    return out({"ok": True, "answer": answer, "row": row["row"],
                "name": row["name"]})


if __name__ == "__main__":
    sys.exit(main())
