# -*- coding: utf-8 -*-
"""Тесты program-b/narrative.py — без обращения к сети.

Проверяем ровно то, за что этот слой отвечает: модель НЕ должна иметь
возможности протащить в отчёт лист или находку, которых не было в
посчитанных фактах, а любой её сбой не должен ронять отчёт.
"""
import contextlib
import io
import json
import os
import sys
import unittest
from unittest import mock

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import narrative  # noqa: E402
from common.anthropic_client import AnthropicClient, AnthropicError, AnthropicRefusal  # noqa: E402
from common.gigachat_client import GigaChatError  # noqa: E402


def _sheet(label, status="changed", findings=("перемещён текст",)):
    return {
        "label": label,
        "status": status,
        "findings": [{"summary": f} for f in findings],
    }


def _facts(sheets=None, spec=None):
    sheets = sheets if sheets is not None else [_sheet("ОВ1-1.ОВ — лист 1")]
    return {
        "old_file": "ОВ1-1.pdf",
        "new_file": "ОВ1-1 изм.1.pdf",
        "sheets": sheets,
        "spec": spec or {"added": [], "removed": [], "qty_changed": []},
        "totals": {"sheets_total": len(sheets), "sheets_changed": len(sheets),
                   "sheets_unchanged": 0, "sheets_only_old": 0, "sheets_only_new": 0,
                   "spec_added": 0, "spec_removed": 0, "spec_qty_changed": 0},
    }


class _FakeGigaChat:
    """Клиент не-Claude: у него ожидается режим «один лист — один запрос»."""

    def __init__(self, answers=None, error=None):
        self.calls = []
        self._answers = list(answers or [])
        self._error = error

    def chat_completion(self, messages, max_tokens=None, **_kwargs):
        self.calls.append({"messages": messages, "max_tokens": max_tokens})
        if self._error:
            raise self._error
        return self._answers.pop(0) if self._answers else "текст"


def _claude(answers=None, error=None):
    """Настоящий AnthropicClient (чтобы работала проверка isinstance и
    пакетный режим), но с подменённым транспортом."""
    client = AnthropicClient(api_key="sk-ant-тест")
    replies = list(answers or [])

    def fake_post(_payload):
        if error:
            raise error
        text = replies.pop(0) if replies else "текст"
        return {"model": "claude-fable-5-1", "stop_reason": "end_turn",
                "content": [{"type": "text", "text": text}],
                "usage": {"input_tokens": 10, "output_tokens": 5}}

    client._post = fake_post
    return client


class BatchParsingTests(unittest.TestCase):

    def test_comments_are_matched_to_sheets_by_label(self):
        sheets = [_sheet("ОВ1-1.ОВ — лист 1"), _sheet("ОВ1-1.ОВ — лист 2")]
        answer = json.dumps({"ОВ1-1.ОВ — лист 1": "Добавлен воздуховод.",
                             "ОВ1-1.ОВ — лист 2": "Изменена привязка решётки."},
                            ensure_ascii=False)
        client = _claude([answer])
        comments, unknown = narrative.generate_sheet_comments_batch(client, sheets)
        self.assertEqual(comments["ОВ1-1.ОВ — лист 1"], "Добавлен воздуховод.")
        self.assertEqual(comments["ОВ1-1.ОВ — лист 2"], "Изменена привязка решётки.")
        self.assertEqual(unknown, [])

    def test_invented_sheet_is_dropped(self):
        # Ключевая проверка: лист, которого не было в фактах, в отчёт не попадает.
        sheets = [_sheet("ОВ1-1.ОВ — лист 1")]
        answer = json.dumps({"ОВ1-1.ОВ — лист 1": "Добавлен воздуховод.",
                             "ОВ1-1.ОВ — лист 99": "Полностью перечерчен."},
                            ensure_ascii=False)
        comments, unknown = narrative.generate_sheet_comments_batch(_claude([answer]), sheets)
        self.assertEqual(list(comments), ["ОВ1-1.ОВ — лист 1"])
        self.assertEqual(unknown, ["ОВ1-1.ОВ — лист 99"])

    def test_json_in_code_fence_is_understood(self):
        sheets = [_sheet("ВК1-1.ВК — лист 3")]
        answer = "```json\n" + json.dumps({"ВК1-1.ВК — лист 3": "Добавлен трап."},
                                          ensure_ascii=False) + "\n```"
        comments, _ = narrative.generate_sheet_comments_batch(_claude([answer]), sheets)
        self.assertEqual(comments["ВК1-1.ВК — лист 3"], "Добавлен трап.")

    def test_unparsable_answer_leaves_sheets_without_comments(self):
        sheets = [_sheet("ОВ1-1.ОВ — лист 1")]
        comments, unknown = narrative.generate_sheet_comments_batch(
            _claude(["Извините, не могу ответить структурой."]), sheets)
        self.assertEqual(comments, {})
        self.assertEqual(unknown, [])

    def test_empty_comment_is_not_recorded(self):
        sheets = [_sheet("ОВ1-1.ОВ — лист 1")]
        answer = json.dumps({"ОВ1-1.ОВ — лист 1": "   "}, ensure_ascii=False)
        comments, _ = narrative.generate_sheet_comments_batch(_claude([answer]), sheets)
        self.assertEqual(comments, {})


class PromptFactsTests(unittest.TestCase):

    def test_findings_are_trimmed_but_total_is_reported(self):
        sheet = _sheet("ОВ1-1.ОВ — лист 1",
                       findings=tuple(f"находка {i}" for i in range(40)))
        trimmed = narrative._sheet_prompt_facts(sheet)
        self.assertEqual(len(trimmed["findings"]), narrative._MAX_FINDINGS_PER_SHEET_PROMPT)
        self.assertEqual(trimmed["findings_total"], 40)

    def test_overview_skips_unchanged_sheets(self):
        facts = _facts([_sheet("лист 1"), _sheet("лист 2", status="unchanged", findings=())])
        overview = narrative._overview_facts(facts)
        self.assertEqual([s["label"] for s in overview["changed_sheets"]], ["лист 1"])

    def test_overview_sends_a_sample_of_findings_with_the_honest_total(self):
        sheet = _sheet("лист 1", findings=tuple(f"находка {i}" for i in range(30)))
        overview = narrative._overview_facts(_facts([sheet]))
        entry = overview["changed_sheets"][0]
        self.assertEqual(len(entry["findings_sample"]), narrative._OVERVIEW_FINDINGS_PER_SHEET)
        self.assertEqual(entry["findings_total"], 30)

    def test_overview_caps_the_number_of_sheets_but_reports_it(self):
        sheets = [_sheet(f"лист {i}") for i in range(60)]
        overview = narrative._overview_facts(_facts(sheets))
        self.assertEqual(len(overview["changed_sheets"]),
                         narrative._MAX_SHEETS_IN_OVERVIEW_PROMPT)
        self.assertEqual(overview["changed_sheets_total"], 60)

    def test_long_finding_text_is_trimmed_on_a_word_boundary(self):
        long_text = "Изменено: " + "очень длинная подпись находки " * 40
        sheet = {"label": "лист 1", "status": "changed",
                 "findings": [{"summary": long_text, "before": long_text, "after": long_text}]}
        trimmed = narrative._sheet_prompt_facts(sheet)["findings"][0]
        self.assertLessEqual(len(trimmed["summary"]), narrative._FINDING_SUMMARY_CHARS + 1)
        self.assertLessEqual(len(trimmed["before"]), narrative._FINDING_SIDE_CHARS + 1)
        self.assertTrue(trimmed["summary"].endswith("…"))
        self.assertFalse(trimmed["summary"].rstrip("…").endswith(" "))

    def test_spec_lists_are_capped_with_totals(self):
        spec = {"added": [{"name": f"позиция {i}", "type": "", "unit": "шт", "qty": 1}
                          for i in range(50)],
                "removed": [], "qty_changed": []}
        overview = narrative._overview_facts(_facts(spec=spec))
        self.assertEqual(len(overview["spec"]["added"]), narrative._SPEC_ITEMS_IN_PROMPT)
        self.assertEqual(overview["spec"]["added_total"], 50)


class BatchingModeTests(unittest.TestCase):

    def test_claude_asks_for_several_sheets_in_one_request(self):
        sheets = [_sheet(f"лист {i}") for i in range(1, 9)]
        answer = json.dumps({s["label"]: "комментарий" for s in sheets}, ensure_ascii=False)
        client = _claude([answer])
        calls = []
        client._post = lambda payload: (calls.append(payload) or {
            "model": "claude-fable-5-1", "stop_reason": "end_turn",
            "content": [{"type": "text", "text": answer}],
            "usage": {"input_tokens": 10, "output_tokens": 5}})
        comments, error = narrative.generate_sheet_comments(client, _facts(sheets), log=lambda _m: None)
        self.assertEqual(len(calls), 1)  # восемь листов — один запрос
        self.assertEqual(len(comments), 8)
        self.assertIsNone(error)

    def test_gigachat_asks_sheet_by_sheet(self):
        sheets = [_sheet("лист 1"), _sheet("лист 2")]
        client = _FakeGigaChat(["первый", "второй"])
        comments, _ = narrative.generate_sheet_comments(client, _facts(sheets), log=lambda _m: None)
        self.assertEqual(len(client.calls), 2)
        self.assertEqual(comments, {"лист 1": "первый", "лист 2": "второй"})

    def test_unchanged_sheets_are_never_sent(self):
        sheets = [_sheet("лист 1", status="unchanged", findings=()),
                  _sheet("лист 2", status="changed", findings=())]
        client = _FakeGigaChat(["не должно быть вызвано"])
        comments, _ = narrative.generate_sheet_comments(client, _facts(sheets), log=lambda _m: None)
        self.assertEqual(client.calls, [])
        self.assertEqual(comments, {})

    def test_number_of_commented_sheets_is_capped(self):
        sheets = [_sheet(f"лист {i}") for i in range(narrative.MAX_SHEETS_COMMENTED + 10)]
        client = _FakeGigaChat(["текст"] * 1000)
        logged = []
        narrative.generate_sheet_comments(client, _facts(sheets), log=logged.append)
        self.assertEqual(len(client.calls), narrative.MAX_SHEETS_COMMENTED)
        self.assertTrue(any("сводной таблице" in line for line in logged), logged)


class ModelRoutingTests(unittest.TestCase):
    """Комментарии по листам идут на более дешёвую модель, резюме и выводы
    — на основную: на замере комментарии это две трети входных токенов."""

    def _payloads(self, client):
        payloads = []
        client._post = lambda payload: (payloads.append(payload) or {
            "model": payload["model"], "stop_reason": "end_turn",
            "content": [{"type": "text", "text": json.dumps(
                {"лист 1": "комментарий"}, ensure_ascii=False)}],
            "usage": {"input_tokens": 100, "output_tokens": 10}})
        return payloads

    def test_sheet_comments_go_to_the_secondary_model(self):
        client = _claude()
        payloads = self._payloads(client)
        narrative.generate_sheet_comments_batch(client, [_sheet("лист 1")])
        self.assertEqual(payloads[0]["model"], narrative.SHEETS_MODEL)

    def test_summary_and_conclusions_stay_on_the_main_model(self):
        client = _claude()
        payloads = self._payloads(client)
        narrative.generate_summary(client, _facts())
        narrative.generate_conclusions(client, _facts())
        self.assertEqual([p["model"] for p in payloads], [client.model, client.model])

    def test_credentials_file_can_override_the_secondary_model(self):
        client = _claude()
        client.model_secondary = "claude-haiku-4-5-20251001"
        payloads = self._payloads(client)
        narrative.generate_sheet_comments_batch(client, [_sheet("лист 1")])
        self.assertEqual(payloads[0]["model"], "claude-haiku-4-5-20251001")

    def test_gigachat_is_not_given_a_model_it_does_not_have(self):
        client = _FakeGigaChat(["текст"])
        self.assertIsNone(narrative._sheets_model(client))


class BudgetTests(unittest.TestCase):

    def test_claude_gets_a_large_max_tokens_backstop(self):
        # У fable размышление включено всегда и его токены тоже входят в
        # max_tokens — занижать нельзя, иначе текста в ответе не будет.
        client = _claude()
        payloads = []
        client._post = lambda payload: (payloads.append(payload) or {
            "model": "claude-fable-5-1", "stop_reason": "end_turn",
            "content": [{"type": "text", "text": "резюме"}],
            "usage": {}})
        narrative.generate_summary(client, _facts())
        self.assertGreaterEqual(payloads[0]["max_tokens"], 4000)

    def test_gigachat_keeps_its_short_budget(self):
        client = _FakeGigaChat(["резюме"])
        narrative.generate_summary(client, _facts())
        self.assertEqual(client.calls[0]["max_tokens"],
                         narrative._BUDGET_GIGACHAT["summary"])


class FailureTests(unittest.TestCase):

    def test_no_key_does_not_break_the_report(self):
        with mock.patch.object(narrative, "make_client",
                               side_effect=AnthropicError("не найден файл с ключом")):
            result = narrative.generate_narrative(_facts(), log=lambda _m: None)
        self.assertIsNone(result["summary"])
        self.assertEqual(result["sheet_comments"], {})
        self.assertIn("ключ", result["error"])

    def test_client_error_is_recorded_but_other_parts_are_still_requested(self):
        client = _FakeGigaChat(error=GigaChatError("сеть недоступна"))
        result = narrative.generate_narrative(_facts(), client=client, log=lambda _m: None)
        self.assertIsNone(result["summary"])
        self.assertIsNone(result["conclusions"])
        self.assertIn("сеть недоступна", result["error"])
        # Резюме, комментарии, выводы — попытки по всем трём частям.
        self.assertEqual(len(client.calls), 3)

    def test_refusal_is_not_an_error(self):
        # Отказ классификатора — не поломка: отчёт выходит без чернового
        # текста, и в статусе задачи не должно быть слова об ошибке.
        client = _claude(error=AnthropicRefusal("отказ"))
        with contextlib.redirect_stderr(io.StringIO()):
            result = narrative.generate_narrative(_facts(), client=client, log=lambda _m: None)
        self.assertIsNone(result["summary"])
        self.assertIsNone(result["error"])

    def test_usage_goes_to_stderr_not_to_the_progress_line(self):
        client = _claude(["резюме", json.dumps({"ОВ1-1.ОВ — лист 1": "к"},
                                               ensure_ascii=False), "выводы"])
        logged = []
        stderr = io.StringIO()
        with contextlib.redirect_stderr(stderr):
            narrative.generate_narrative(_facts(), client=client, log=logged.append)
        self.assertIn("расход модели", stderr.getvalue())
        self.assertFalse(any("расход модели" in line for line in logged), logged)

    def test_unknown_provider_is_rejected(self):
        with self.assertRaises(ValueError):
            narrative.make_client("сберчат")


class WholeNarrativeTests(unittest.TestCase):

    def test_all_three_parts_are_collected(self):
        sheets = [_sheet("ОВ1-1.ОВ — лист 1")]
        client = _claude(["Резюме изменений.",
                          json.dumps({"ОВ1-1.ОВ — лист 1": "Добавлен воздуховод."},
                                     ensure_ascii=False),
                          "Выводы по комплекту."])
        with contextlib.redirect_stderr(io.StringIO()):
            result = narrative.generate_narrative(_facts(sheets), client=client,
                                                  log=lambda _m: None)
        self.assertEqual(result["summary"], "Резюме изменений.")
        self.assertEqual(result["sheet_comments"],
                         {"ОВ1-1.ОВ — лист 1": "Добавлен воздуховод."})
        self.assertEqual(result["conclusions"], "Выводы по комплекту.")
        self.assertIsNone(result["error"])

    def test_system_prompt_forbids_inventing_facts(self):
        client = _FakeGigaChat(["текст"])
        narrative.generate_summary(client, _facts())
        system = client.calls[0]["messages"][0]
        self.assertEqual(system["role"], "system")
        self.assertIn("не придумывай", system["content"].lower())


class NarrativePagesTests(unittest.TestCase):
    """Отрисовка черновых страниц в PDF. Проверяется отдельно, потому что
    этот путь однажды уже был сломан: report.build_narrative_pages
    ссылался на константы плашки «черновик», которых в модуле не было —
    падало бы NameError на первом же прогоне с моделью."""

    def setUp(self):
        import fitz
        from report import build_narrative_pages
        self.fitz = fitz
        self.build = build_narrative_pages

    def test_pages_are_drawn_and_marked_as_draft(self):
        doc = self.fitz.open()
        self.build(doc, {
            "summary": "Резюме изменений между редакциями. " * 20,
            "sheet_comments": {"ОВ1-1.ОВ — лист 1": "Добавлен воздуховод."},
            "conclusions": "Проверить листы 1 и 2.",
        }, "Черновой текст (Claude): ОВ1-1.pdf → ОВ1-1 изм.1.pdf")
        self.assertGreaterEqual(len(doc), 1)
        text = doc[0].get_text()
        self.assertIn("ЧЕРНОВИК", text)
        self.assertIn("Резюме изменений", text)
        self.assertIn("ОВ1-1.ОВ — лист 1", text)
        doc.close()

    def test_empty_narrative_draws_nothing(self):
        doc = self.fitz.open()
        self.build(doc, {"summary": None, "sheet_comments": {}, "conclusions": None}, "заголовок")
        self.assertEqual(len(doc), 0)
        self.build(doc, None, "заголовок")
        self.assertEqual(len(doc), 0)
        doc.close()


if __name__ == "__main__":
    unittest.main()
