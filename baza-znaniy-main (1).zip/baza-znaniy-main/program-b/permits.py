# -*- coding: utf-8 -*-
"""
Лист «Разрешение на внесение изменений»: разбор записей и сверка с тем,
что на самом деле изменилось в чертежах.

Это та часть отчёта, ради которой инженер ПТО его и открывает: лист,
изменённый без записи в разрешении, принимать нельзя, а запись о
листе, который на деле не менялся, — повод проверить, не потерялась ли
правка. В эталонном отчёте заказчика (пакет rdgraph, permits.py и
checks.py) это отдельный раздел, и строение разбора взято оттуда.

Разбор идёт по строкам текста листа — ничего не считает сам и ничего
не рисует: сверку делает compare.py, показывает report.py.
"""
import re

# Заголовок листа: печатается по-разному («Разрешение на внесение
# изменений», «РАЗРЕШЕНИЕ № 1125-70-21»), но слово «разрешение» в первых
# строках есть всегда.
PERMIT_RE = re.compile(r"\bразрешени\w*\b", re.IGNORECASE)

# Номер разрешения: «1668/25», «1125-70-21». От обозначения комплекта
# отличается тем, что в нём нет букв.
NUMBER_RE = re.compile(r"^\d{3,6}[-/]\d{2,6}(?:[-/]\d{1,4})?$")
# Тот же номер внутри строки — им подписаны графы изменений штампов.
DOC_NUMBER_RE = re.compile(r"\b(\d{3,5}\s*/\s*\d{2})\b")
DATE_RE = re.compile(r"\b(\d{2}[.\-/]\d{2}[.\-/]\d{2,4})\b")

# Строка записи: «2(Зам.) 26-27 Исправлены отводы 30°…», «1(Нов.) 11 …».
# Номера листов идут сразу за видом изменения: диапазон, перечисление
# или «СО»/«ОД» (спецификация и общие данные).
RECORD_RE = re.compile(
    r"^\s*(\d{1,2})\s*\(\s*(Зам|Изм|Нов|Аннул)\.?\s*\)\s+"
    r"((?:СО|ОД|\d{1,3}(?:\s*[-–,]\s*\d{1,3})*))\s*(.*)$",
    re.IGNORECASE)

# Второй формат записи — таблицей «Изм. | Лист | Содержание изменения |
# Код | Примечание», где примечание это «Изм.2» или «Изм.2(зам)», а
# содержание переносится на соседние строки (так оформлены присланные
# комплекты ОВ2). Колонка «Изм.» заполняется только в первой строке,
# дальше наследуется, поэтому номер листа — это либо первое число
# строки, либо второе, если первых чисел два.
TABLE_TAIL_RE = re.compile(
    r"\bИзм\.?\s*(\d{1,2})\s*(?:\(\s*(зам|нов|изм)\.?\s*\))?\s*$", re.IGNORECASE)
_CODE_TAIL_RE = re.compile(r"\s(\d{1,2})$")
# Шапка таблицы — всё, что стоит до неё, к содержанию записей не
# относится (обозначение комплекта, наименование объекта, адрес).
_TABLE_HEADER_RE = re.compile(r"Изм\.?\s+Лист\s+Содержание", re.IGNORECASE)

# Диапазон листов разворачиваем только в разумных пределах: «26-27» это
# два листа, а «1-500» — опечатка либо неверно прочитанная строка.
_MAX_RANGE = 60


def page_lines(words):
    """Строки страницы по словам (stamp.page_words) — разбор разрешения
    построчный, а слова приходят россыпью."""
    buckets = {}
    for word in words:
        buckets.setdefault(round((word[1] + word[3]) / 2.0 / 3.0), []).append(word)
    lines = []
    for key in sorted(buckets):
        row = sorted(buckets[key], key=lambda w: w[0])
        lines.append(" ".join(w[4] for w in row))
    return lines


def has_permit_words(words, limit=400):
    """Быстрая проверка «похоже на лист разрешения» по словам, без
    сборки строк: на комплекте в полторы сотни листов строки нужны
    только для одного-двух из них."""
    for word in list(words)[:limit]:
        if PERMIT_RE.search(word[4]):
            return True
    return False


def expand_sheets(raw):
    """«26-27» → ['26', '27'], «12, 15» → ['12', '15'], «СО» → ['СО']."""
    raw = str(raw).replace("–", "-").replace(" ", "")
    upper = raw.upper()
    if upper in ("СО", "ОД", "CO"):
        return [upper]
    out = []
    for part in raw.split(","):
        if "-" in part:
            left, _sep, right = part.partition("-")
            if left.isdigit() and right.isdigit() and int(left) <= int(right) <= int(left) + _MAX_RANGE:
                out.extend(str(n) for n in range(int(left), int(right) + 1))
        elif part.isdigit():
            out.append(part)
    return out


def looks_like_permit(lines):
    """Лист разрешения — по заголовку в первых строках."""
    return any(PERMIT_RE.search(line) for line in list(lines)[:8])


def parse_permit(lines, page=None):
    """Разрешение по строкам листа: номер, дата, номер изменения и
    записи «какие листы и как изменены»."""
    lines = [str(line) for line in lines]
    number = ""
    for line in lines[:15]:
        for token in line.split():
            if NUMBER_RE.match(token):
                number = token
                break
        if number:
            break

    records = []
    current = None
    pending = []          # строки содержания, стоящие ПЕРЕД строкой записи
    for line in lines:
        match = RECORD_RE.match(line)
        if match:
            current = {
                "change": int(match.group(1)),
                "kind": match.group(2).capitalize(),
                "sheets_raw": match.group(3).strip(),
                "sheets": expand_sheets(match.group(3)),
                "text": match.group(4).strip(),
            }
            records.append(current)
            pending = []
            continue

        table = _table_record(line)
        if table is not None:
            # В табличном формате содержание стоит и до строки с номером
            # листа, и после неё; точного соответствия строк записям тут
            # нет, поэтому содержание собирается приблизительно — чего
            # вполне хватает: какие листы заявлены, определяется точно.
            if pending:
                table["text"] = (" ".join(pending) + " " + table["text"]).strip()
            records.append(table)
            current = table
            pending = []
            continue

        if not line.strip():
            continue
        if _TABLE_HEADER_RE.search(line):
            pending = []
            current = None
            continue
        tail = re.sub(r"\s{3,}\d{1,2}\s*$", "", line).strip()
        if not tail or re.fullmatch(r"\d{1,2}", tail):
            continue
        # Продолжение записи: содержание изменения занимает несколько
        # строк. Номер страницы в конце строки к содержанию не относится.
        if current is not None:
            current["text"] = (current["text"] + " " + tail).strip()
        pending.append(tail)
        if len(pending) > 3:
            pending.pop(0)

    dates = DATE_RE.findall(" ".join(lines[:12]))
    changes = [r["change"] for r in records]
    return {
        "page": page,
        "number": number,
        "date": dates[0] if dates else "",
        "change": max(changes) if changes else None,
        "records": records,
    }


def _table_record(line):
    """Запись в табличном формате — или None."""
    match = TABLE_TAIL_RE.search(line)
    if not match:
        return None
    change = int(match.group(1))
    kind = (match.group(2) or "Изм").capitalize()
    body = line[:match.start()].strip()
    code = _CODE_TAIL_RE.search(body)
    if code:
        body = body[:code.start()].strip()
    tokens = body.split()
    if not tokens or not tokens[0].isdigit():
        return None
    if len(tokens) >= 2 and tokens[1].isdigit():
        sheet, text = tokens[1], " ".join(tokens[2:])
    else:
        sheet, text = tokens[0], " ".join(tokens[1:])
    return {"change": change, "kind": kind, "sheets_raw": sheet,
             "sheets": expand_sheets(sheet), "text": text.strip()}


def declared_sheets(permit):
    """{номер листа: [записи]} — какие листы разрешение объявляет
    изменёнными."""
    out = {}
    for record in (permit or {}).get("records") or ():
        for sheet in record["sheets"]:
            out.setdefault(sheet, []).append(record)
    return out


def declaration_note(records):
    """«да (Зам.)» — как лист объявлен в разрешении."""
    if not records:
        return "нет"
    kinds = []
    for record in records:
        kind = record.get("kind")
        if kind and kind not in kinds:
            kinds.append(kind)
    return "да (" + ", ".join(k + "." for k in kinds) + ")" if kinds else "да"


def stamp_permit_numbers(change_log):
    """Номера документов из графы изменений штампа."""
    out = []
    for line in change_log or ():
        for found in DOC_NUMBER_RE.findall(str(line)):
            found = found.replace(" ", "")
            if found not in out:
                out.append(found)
    return out


# Лист разрешения подшивается в начало альбома — за титулом и общими
# данными. Для легенды книги спецификации весь комплект ради него не
# разбирается: хватает первых страниц.
_PERMIT_SEARCH_PAGES = 20


def find_permits(doc, max_pages=_PERMIT_SEARCH_PAGES, words_of=None):
    """Разрешения в начале документа: [{номер, дата, …}].

    words_of — функция «страница → слова» (stamp.page_words); передаётся
    снаружи, чтобы этот модуль не тянул разбор штампа."""
    found = []
    for index in range(min(len(doc), max_pages)):
        words = words_of(doc[index]) if words_of else doc[index].get_text("words")
        if not has_permit_words(words):
            continue
        lines = page_lines(words)
        if looks_like_permit(lines):
            found.append(parse_permit(lines, page=index + 1))
    return found
