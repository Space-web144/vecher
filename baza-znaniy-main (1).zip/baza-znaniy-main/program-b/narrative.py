# -*- coding: utf-8 -*-
"""
Черновой связный текст отчёта сравнения ревизий — через языковую модель.

Важно: модель здесь ТОЛЬКО облекает в слова уже посчитанные факты
(program-b/facts.py) — резюме, комментарии по листам, выводы. Ей не
передаются ни исходные PDF, ни картинки, ни право что-либо досчитывать
самой — весь ввод это готовый JSON-пакет фактов. Так риск галлюцинации
смещается с "что произошло" (посчитано детерминированным кодом, модель
туда не допускается) на "как это описать словами" — это согласованная с
заказчиком архитектура.

Любой текст, полученный отсюда, ДОЛЖЕН попасть в PDF помеченным как
черновик, требующий проверки инженером (см. report.build_narrative_pages)
— никогда как проверенный факт.

Поставщик модели один — "claude", Anthropic Messages API
(common/anthropic_client.py). GigaChat из проекта исключён полностью.
"""
import json
import os
import re
import sys

# Тот же принцип, что в raster.py: модулю нужен common/, и он сам
# добавляет корень проекта в пути, а не надеется на порядок импортов.
_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
if _REPO_ROOT not in sys.path:
    sys.path.insert(0, _REPO_ROOT)

from common.anthropic_client import AnthropicClient, AnthropicError, AnthropicRefusal

PROVIDER_CLAUDE = "claude"
PROVIDERS = (PROVIDER_CLAUDE,)

# Ошибка клиента — не повод ронять отчёт: детерминированная часть
# самодостаточна и без черновых текстов (см. generate_narrative).
_CLIENT_ERRORS = (AnthropicError,)

_SYSTEM_PROMPT = (
    "Ты — технический писатель, помогающий инженеру-проектировщику готовить "
    "пояснительную записку к отчёту сравнения ревизий рабочей документации "
    "(разделы ОВ, ВК, ЭОМ, СС). Тебе присылают ТОЛЬКО уже посчитанный "
    "детерминированным кодом набор фактов в формате JSON — конкретные "
    "листы, находки, количества по спецификации. Ты не видел исходные "
    "чертежи и не можешь ничего досчитать или домыслить сверх присланных "
    "данных. Твоя задача — изложить эти факты связным, точным инженерным "
    "русским текстом, ничего не теряя и не добавляя: не придумывай листы, "
    "находки, количества или причины изменений, которых нет в JSON. Если "
    "фактов недостаточно для содержательной фразы — прямо напиши, что "
    "данных недостаточно, вместо того чтобы домысливать.\n\n"
    # Словарь заказчика. Инженер ПТО читает отчёт рядом с самими
    # документами, и расхождение в словах он читает как расхождение в
    # сути: "спецификация оборудования" вместо "СО" заставляет сверять,
    # о том же ли речь. Поэтому термины заданы, а не оставлены на выбор.
    "Пиши терминами заказчика и не заменяй их синонимами: спецификация "
    "оборудования, изделий и материалов — «СО»; редакция изменения — "
    "«изм. N»; лист, выпущенный заново, — «Зам.», выпущенный впервые — "
    "«Нов.»; лист разрешения на внесение изменений — «разрешение»; "
    "повторная выдача того же изменения — «выкладка»; наряд-заказ — «НЗ». "
    "Количество называй количеством, а не объёмом или расходом, если в "
    "фактах не сказано иначе.\n\n"
    # Графическая часть отчёта — только геометрия (см.
    # report.build_change_items). Без этой оговорки модель, увидев в
    # фактах counts с text_differences_excluded, начинает писать про
    # «изменённые надписи» — то есть ровно про то, что заказчик просил
    # из отчёта убрать.
    "По чертежам в фактах идут ТОЛЬКО изменения геометрии: трассировка "
    "(линии сетей, воздуховодов, трубопроводов) и оборудование/узлы. "
    "Изменения текстовых подписей в находки не входят намеренно, и поле "
    "text_differences_excluded — это число таких расхождений, а НЕ "
    "изменение чертежа: не описывай их как изменения и не делай из них "
    "выводов, максимум упомяни, что подписи в сравнение не включались.\n\n"
    # Приёмочный гейт сверяет каждое число отчёта с числами на листах
    # (program-b/verify_so.py). Пока он не пройден, числа отчёта — не
    # установленный факт, и писать о них как о факте нельзя: инженер
    # закупает по этим цифрам.
    "В фактах может быть verification — вердикт независимой проверки "
    "разбора по каждому файлу. Если reconciled там false, разбор с листами "
    "НЕ сведён: начни текст именно с этого, назови файл, вердикт и "
    "расхождения как они есть (страница, числа на листах против чисел в "
    "отчёте), и дальше пиши об изменениях с оговоркой, что они относятся к "
    "несведённому разбору. Не сглаживай и не прячь это в конце."
)

# ── Объём фактов, уходящих в один запрос ──
#
# Это не косметика, а прямая стоимость: вход оплачивается за каждый
# запрос ($10 за миллион токенов у fable). Замер на реальном комплекте
# (ПС, 51 изменённый лист): без ограничений ниже один запрос на резюме
# весил 132 тысячи символов (~44 тысячи токенов), а всё сравнение
# обходилось в $1.71 — при 20 сравнениях в день это около $1000 в месяц.
#
# Терять при этом нечего: полный перечень находок инженер видит в сводной
# таблице отчёта, которая считается детерминированно и без модели вовсе.
# Модели нужен ОБРАЗЕЦ находок, чтобы связно описать характер изменений,
# а не весь их список; сколько находок на листе всего, она видит числом
# (findings_total) и потому не примет образец за полную картину.
_MAX_SHEETS_IN_OVERVIEW_PROMPT = 25
_OVERVIEW_FINDINGS_PER_SHEET = 2
_OVERVIEW_FINDING_CHARS = 160
_SPEC_ITEMS_IN_PROMPT = 20

# Сколько листов комментируем поштучно. Комплект РД — это 150 листов, из
# них изменёнными могут оказаться десятки; комментарий к каждому это и
# деньги (вход+выход за каждый запрос), и время прогона. Самое важное
# инженер и так видит в сводной таблице находок, которая считается без
# модели вовсе.
MAX_SHEETS_COMMENTED = 24

# Листов в одном запросе на комментарии. Один запрос на лист — это два
# десятка запросов на пару ревизий: при 20 сравнениях в день выходит заметная
# сумма на одних только повторах системного промпта. Claude уверенно
# отдаёт JSON-объект сразу по нескольким листам.
SHEETS_PER_REQUEST = 8

# Модель для комментариев по листам. Резюме и выводы — это связный текст
# по всему комплекту, там нужна лучшая модель (fable 5.1). Комментарий в
# две строки по одному листу — работа формульная, и на ней вдвое более
# дешёвый Opus 5 неотличим: на замере пары ПС комментарии по листам это
# две трети всех входных токенов, так что выбор модели именно здесь и
# решает стоимость. Заменяется полем model_secondary в файле с ключом,
# без правки кода. С 01.11.2026 — Opus 5.5: новее и ещё на 20% дешевле
# Opus 5 ($4/$20 против $5/$25 за млн токенов); на нём же сопоставление
# листов и ответы на вопрос по строке отчёта.
SHEETS_MODEL = "claude-opus-5-5"

# Сколько находок по листу уходит в промпт на комментарий и насколько
# подробно. Больше полудюжины однотипных находок ("перемещён текст") не
# делают комментарий в две строки лучше, а вход оплачивается за каждую.
_MAX_FINDINGS_PER_SHEET_PROMPT = 6
_FINDING_SUMMARY_CHARS = 300
_FINDING_SIDE_CHARS = 200

# max_tokens у Claude — предохранитель, в него входят и токены
# размышления (оно у fable включено всегда), поэтому запас кратный.
# Краткость задаётся формулировкой промпта.
_BUDGET = {"summary": 6000, "sheets": 10000, "conclusions": 6000}


def _trim(value, limit):
    """Обрезает длинный текст по границе слова. Подписи находок бывают в
    несколько абзацев (в них целиком попадает изменённый текст чертежа) —
    для двух строк комментария столько не нужно."""
    text = str(value or "").strip()
    if len(text) <= limit:
        return text
    cut = text[:limit]
    space = cut.rfind(" ")
    if space > limit // 2:
        cut = cut[:space]
    return cut.rstrip() + "…"


_JSON_FENCE_RE = re.compile(r"^\s*```(?:json)?\s*|\s*```\s*$", re.IGNORECASE)


def make_client(provider=PROVIDER_CLAUDE, credentials_file=None, log=print, **kwargs):
    """Создаёт клиента Claude. Ключ клиент читает сам из файла выше корня
    сайта, здесь он не хранится и не логируется."""
    if provider == PROVIDER_CLAUDE:
        return AnthropicClient(credentials_file=credentials_file, log=log, **kwargs)
    raise ValueError(f"Неизвестный поставщик чернового текста: {provider!r}")


_MATCH_SYSTEM_PROMPT = (
    "Ты помогаешь инженеру-проектировщику сопоставить листы рабочей "
    "документации между двумя редакциями одного комплекта. Тебе присылают "
    "только короткие выжимки: номер страницы, формат листа и первые слова с "
    "листа. Самих чертежей ты не видишь. Твоя задача — сказать, какой лист "
    "старой редакции соответствует какому листу новой. Соответствие — это "
    "один и тот же лист комплекта, изменившийся между редакциями. Пары, в "
    "которой ты не уверен, лучше не называть вовсе: связать два разных листа "
    "хуже, чем оставить лист несопоставленным."
)


_ROW_SYSTEM_PROMPT = (
    "Ты помогаешь инженеру-проектировщику разобраться в ОДНОЙ строке отчёта "
    "сравнения спецификаций (СО) рабочей документации. Тебе присылают факты "
    "только по этой строке: раздел и система, наименование материала, "
    "единица измерения, тип и марка, количество по каждой редакции и "
    "посчитанные дельты, а также легенду отчёта. Ни чертежей, ни остальной "
    "таблицы ты не видишь и запросить не можешь. Отвечай коротко и по делу, "
    "строго по присланным фактам: называй числа как они есть и не "
    "пересчитывай их. Если ответа в фактах нет — скажи прямо, чего именно "
    "не хватает и где инженер это найдёт (лист спецификации, разрешение на "
    "внесение изменений), вместо того чтобы предполагать. Пиши терминами "
    "заказчика: СО, изм. N, Зам./Нов., разрешение, выкладка, НЗ.\n\n"
    # Легенда отчёта приходит вместе со строкой, и в ней стоит
    # предупреждение приёмочного гейта, если разбор не сведён с листами.
    # Отвечать про числа такой строки как про установленные нельзя.
    "Если в легенде сказано, что проверка спецификации не пройдена, скажи "
    "об этом в первой фразе: числа этой строки могут быть неверны, и по ним "
    "нельзя закупать, пока расхождение не разобрано."
)

# Ответ на вопрос по одной строке — это абзац, а не записка: потолок нужен
# только как предохранитель (у Claude в него входят и токены размышления).
_ROW_BUDGET = 4000


def answer_row_question(client, row, question):
    """Ответ агента на вопрос инженера об одной строке отчёта.

    Модель не считает ничего заново: количества и дельты уже посчитаны
    детерминированным кодом (см. spec_excel.read_report_row) — её работа
    только объяснить их словами. Сбой не должен ронять страницу: вместо
    ответа возвращается None, и страница скажет, что агент недоступен.
    """
    question = " ".join(str(question or "").split())
    if not question:
        return None
    prompt = ("Вопрос инженера по строке отчёта: " + question
              + "\n\nОтветь на него по фактам этой строки.")
    messages = [
        {"role": "system", "content": _ROW_SYSTEM_PROMPT},
        {"role": "user", "content": prompt + "\n\nФакты строки (JSON):\n" + _json_of(row)},
    ]
    try:
        text = client.chat_completion(messages, max_tokens=_ROW_BUDGET,
                                      model=_sheets_model(client)).strip()
    except _CLIENT_ERRORS:
        return None
    return text or None


def try_make_client(provider=PROVIDER_CLAUDE, credentials_file=None,
                     max_requests=None, log=print):
    """Клиент или None, если модель недоступна. Отчёт выпускается и без
    неё, поэтому отсутствие ключа или связи — не повод падать.

    max_requests — предохранитель от зацикливания. Его задаёт вызывающий
    код: он знает, сколько пар редакций в прогоне, а клиент — нет."""
    kwargs = {}
    if max_requests:
        kwargs["max_requests"] = max_requests
    try:
        return make_client(provider, credentials_file=credentials_file, log=log, **kwargs)
    except _CLIENT_ERRORS as exc:
        log(f"[narrative] модель недоступна: {exc}")
        return None


def make_sheet_ask(client):
    """Функция запроса для sheet_match.match_with_model.

    Сопоставление листов — работа формульная, идёт на той же дешёвой
    модели, что и комментарии по листам. Сбой запроса не должен ронять
    прогон: листы просто останутся несопоставленными, о чём и будет
    написано в сводке."""
    if client is None:
        return None

    def ask(prompt, facts_obj, max_tokens):
        messages = [
            {"role": "system", "content": _MATCH_SYSTEM_PROMPT},
            {"role": "user", "content": prompt + "\n\nДанные (JSON):\n" + _json_of(facts_obj)},
        ]
        try:
            return client.chat_completion(messages, max_tokens=max_tokens,
                                          model=_sheets_model(client)).strip()
        except _CLIENT_ERRORS:
            return ""

    return ask


def _json_of(obj):
    return json.dumps(obj, ensure_ascii=False)


def _ask(client, prompt, facts_obj, max_tokens, model=None):
    messages = [
        {"role": "system", "content": _SYSTEM_PROMPT},
        {"role": "user", "content": prompt + "\n\nФакты (JSON):\n" + _json_of(facts_obj)},
    ]
    text = client.chat_completion(messages, max_tokens=max_tokens, model=model).strip()
    return text or None


def _sheets_model(client):
    """Модель для комментариев по листам: model_secondary из файла с
    ключом, а без него — SHEETS_MODEL."""
    return getattr(client, "model_secondary", None) or SHEETS_MODEL


def _overview_facts(facts):
    """Компактная версия пакета для резюме/выводов — totals полностью,
    но по листам и спецификации только то, что нужно для связного текста
    (иначе на комплекте из полусотни листов промпт разрастается без
    пользы для качества текста)."""
    changed = [s for s in facts["sheets"] if s["status"] != "unchanged"]
    sheets = []
    for sheet in changed[:_MAX_SHEETS_IN_OVERVIEW_PROMPT]:
        findings = sheet.get("findings") or []
        sheets.append({
            "label": sheet["label"],
            "status": sheet["status"],
            "findings_sample": [_trim(f.get("summary"), _OVERVIEW_FINDING_CHARS)
                                for f in findings[:_OVERVIEW_FINDINGS_PER_SHEET]],
            "findings_total": len(findings),
        })
    return {
        "old_file": facts["old_file"],
        "new_file": facts["new_file"],
        # Ни вердикт проверки, ни допущения обрезать нельзя: их немного, а
        # вывод без них читается как установленный факт
        # (см. facts.build_pair_facts).
        "verification": facts.get("verification") or [],
        "assumptions": facts.get("assumptions") or [],
        "totals": facts["totals"],
        "changed_sheets": sheets,
        "changed_sheets_total": len(changed),
        "spec": _spec_prompt_facts(facts["spec"]),
        "note": ("По каждому листу показан только образец находок "
                 "(findings_sample), их полное число — в findings_total; "
                 "полный перечень находок есть в отчёте и в промпт не входит."),
    }


def _spec_prompt_facts(spec):
    """Спецификация для промпта: длинные перечни позиций обрезаны, но их
    полная длина названа числом (она же есть в totals)."""
    spec = spec or {}
    trimmed = {}
    for key in ("added", "removed", "qty_changed"):
        rows = spec.get(key) or []
        trimmed[key] = [{k: _trim(v, 120) if isinstance(v, str) else v
                         for k, v in row.items()}
                        for row in rows[:_SPEC_ITEMS_IN_PROMPT]]
        trimmed[key + "_total"] = len(rows)
    return trimmed


def _sheet_prompt_facts(sheet_fact):
    """Один лист для промпта: без картинок и без хвоста однотипных
    находок, но с честной пометкой, что показаны не все."""
    findings = sheet_fact.get("findings") or []
    trimmed = {
        "label": sheet_fact.get("label"),
        "status": sheet_fact.get("status"),
        "findings": [{
            "summary": _trim(f.get("summary"), _FINDING_SUMMARY_CHARS),
            "before": _trim(f.get("before"), _FINDING_SIDE_CHARS),
            "after": _trim(f.get("after"), _FINDING_SIDE_CHARS),
        } for f in findings[:_MAX_FINDINGS_PER_SHEET_PROMPT]],
        "findings_total": len(findings),
    }
    for key in ("stamp_change", "revision_note", "sheet_no", "marka"):
        if sheet_fact.get(key):
            trimmed[key] = sheet_fact[key]
    return trimmed


def generate_summary(client, facts):
    prompt = (
        "Напиши краткое связное резюме (2-4 абзаца) ключевых изменений между "
        "ревизиями на основе присланных фактов: сколько листов изменено, без "
        "изменений, есть только в одной из версий; какие изменения "
        "повторяются на нескольких листах; что изменилось в спецификации "
        "(что добавлено/убрано, где изменилось количество). Пиши связной "
        "инженерной прозой для пояснительной записки, не списком и не "
        "таблицей. Используй только то, что есть в присланных фактах.\n\n"
        "Если в фактах есть verification с reconciled = false — первым "
        "абзацем скажи, что разбор с листами не сведён, и назови вердикт и "
        "расхождения фактами (файл, страница, числа на листах против чисел "
        "в отчёте). Остальной текст пиши после этого.\n\n"
        "Если в фактах есть assumptions — решения, принятые разбором за "
        "инженера (основание хронологии, выброшенные служебные строки, "
        "принятые единицы), — назови их отдельным абзацем в конце, своими "
        "словами и без пропусков. Вывод без этой оговорки читается как "
        "установленный факт, которым он не является."
    )
    return _ask(client, prompt, _overview_facts(facts), max_tokens=_BUDGET["summary"])


def _commentable(sheet_fact):
    return sheet_fact.get("status") == "changed" and bool(sheet_fact.get("findings"))


def _strip_json_fence(text):
    text = _JSON_FENCE_RE.sub("", text.strip())
    start = text.find("{")
    end = text.rfind("}")
    if start == -1 or end == -1 or end < start:
        return None
    return text[start:end + 1]


def _parse_comment_map(text, expected_labels):
    """Разбирает ответ вида {"обозначение листа": "комментарий"}.

    Ключи, которых не было в запросе, отбрасываются: придуманный моделью
    лист не должен попасть в отчёт ни при каких обстоятельствах. Если
    ответ не разобрался как JSON — возвращает (None, ...), вызывающий код
    просто оставит эти листы без комментария."""
    payload = _strip_json_fence(text or "")
    if not payload:
        return None, []
    try:
        data = json.loads(payload)
    except ValueError:
        return None, []
    if not isinstance(data, dict):
        return None, []
    expected = set(expected_labels)
    good, unknown = {}, []
    for label, comment in data.items():
        if not isinstance(comment, str) or not comment.strip():
            continue
        if label in expected:
            good[label] = comment.strip()
        else:
            unknown.append(label)
    return good, unknown


def generate_sheet_comments_batch(client, sheet_facts):
    """Комментарии сразу по нескольким листам одним запросом.

    Возвращает (dict label -> комментарий, список лишних обозначений в
    ответе). Пустой dict — значит ответ не разобрался; это не ошибка,
    листы просто останутся без чернового комментария."""
    labels = [s.get("label") for s in sheet_facts]
    prompt = (
        "Ниже факты по нескольким листам одного комплекта. Для КАЖДОГО листа "
        "напиши краткий комментарий (1-2 предложения) о том, что на нём "
        "изменилось, опираясь только на присланные данные, без домыслов о "
        "причинах изменений.\n"
        "Ответь ОДНИМ объектом JSON без пояснений до и после: ключ — "
        "обозначение листа ровно в том виде, как оно дано в поле label, "
        "значение — строка с комментарием. Обозначения не изменяй и не "
        "добавляй листов, которых нет в присланных фактах.\n"
        "Ожидаемые ключи: " + _json_of(labels)
    )
    text = _ask(client, prompt, [_sheet_prompt_facts(s) for s in sheet_facts],
                max_tokens=_BUDGET["sheets"], model=_sheets_model(client))
    comments, unknown = _parse_comment_map(text, labels)
    return (comments or {}), unknown


def generate_conclusions(client, facts):
    prompt = (
        "На основе присланных фактов сформулируй краткие выводы (несколько "
        "коротких абзацев или пунктов): что изменилось системно между "
        "ревизиями, какие листы стоит проверить инженеру в первую очередь, "
        "есть ли в самих фактах видимые нестыковки между количеством находок "
        "на чертежах и изменениями в спецификации (totals и spec в JSON). "
        "Если каких-то данных для вывода не хватает — не делай этот вывод. "
        "Не утверждай ничего, чего нет во входных фактах.\n\n"
        "Если verification говорит, что разбор не сведён с листами "
        "(reconciled = false), первым выводом поставь именно это: по такому "
        "разбору нельзя закупать, пока расхождения не разобраны, — и назови "
        "их фактами."
    )
    return _ask(client, prompt, _overview_facts(facts), max_tokens=_BUDGET["conclusions"])


def _chunks(items, size):
    for start in range(0, len(items), size):
        yield items[start:start + size]


def generate_sheet_comments(client, facts, log=print, first_error=None):
    """Комментарии по всем листам, которые есть смысл комментировать.
    Возвращает (dict label -> текст, текст первой ошибки или None)."""
    commentable = [s for s in facts["sheets"] if _commentable(s)]
    if len(commentable) > MAX_SHEETS_COMMENTED:
        log(f"[narrative] изменённых листов {len(commentable)}, черновые комментарии "
            f"делаю по первым {MAX_SHEETS_COMMENTED} — остальные находки есть в сводной таблице")
        commentable = commentable[:MAX_SHEETS_COMMENTED]

    comments = {}
    error = first_error
    total = len(commentable)
    done = 0

    for group in _chunks(commentable, SHEETS_PER_REQUEST):
        # Отчёт о ходе работы на каждом запросе: они идут минутами, и без
        # этих строк страница ожидания считает задачу оборвавшейся (см.
        # VERRATA_STALL_SEC), а инженер — зависшей.
        log(f"черновой текст: комментарии по листам {done + 1}–{done + len(group)} из {total}…")
        done += len(group)
        try:
            part, unknown = generate_sheet_comments_batch(client, group)
            if unknown:
                log("[narrative] в ответе модели были обозначения листов, которых "
                    f"не было в запросе ({len(unknown)}) — отброшены")
            missing = [s["label"] for s in group if s["label"] not in part]
            if missing:
                log(f"[narrative] без чернового комментария остались листы: {', '.join(missing)}")
            comments.update(part)
        except AnthropicRefusal as exc:
            # Отказ — не сбой связи: повторять смысла нет, остальные
            # запросы делаем как обычно.
            log(f"[narrative] модель отказалась комментировать часть листов: {exc}")
        except _CLIENT_ERRORS as exc:
            log(f"[narrative] не удалось получить комментарии по листам: {exc}")
            error = error or str(exc)
    return comments, error


def generate_narrative(facts, client=None, provider=PROVIDER_CLAUDE, credentials_file=None,
                        log=print):
    """Собирает все черновые тексты отчёта: summary, sheet_comments (dict
    label -> текст, только для изменённых листов с находками),
    conclusions.

    Сбой модели (нет ключа, нет связи через прокси, лимиты, отказ
    классификатора) не должен ронять весь отчёт — детерминированная часть
    самодостаточна и без черновых текстов. При ошибке возвращает частично
    заполненный результат с описанием ошибки в "error", а не бросает
    исключение наружу."""
    if client is None:
        try:
            client = make_client(provider, credentials_file=credentials_file, log=log)
        except _CLIENT_ERRORS as exc:
            log(f"[narrative] модель недоступна, черновой текст пропущен: {exc}")
            return {"summary": None, "sheet_comments": {}, "conclusions": None,
                    "error": str(exc)}

    result = {"summary": None, "sheet_comments": {}, "conclusions": None, "error": None}

    log("черновой текст: пишу резюме…")
    try:
        result["summary"] = generate_summary(client, facts)
    except AnthropicRefusal as exc:
        log(f"[narrative] модель отказалась писать резюме: {exc}")
    except _CLIENT_ERRORS as exc:
        log(f"[narrative] не удалось получить резюме: {exc}")
        result["error"] = str(exc)

    result["sheet_comments"], result["error"] = generate_sheet_comments(
        client, facts, log=log, first_error=result["error"])

    log("черновой текст: пишу выводы…")
    try:
        result["conclusions"] = generate_conclusions(client, facts)
    except AnthropicRefusal as exc:
        log(f"[narrative] модель отказалась писать выводы: {exc}")
    except _CLIENT_ERRORS as exc:
        log(f"[narrative] не удалось получить выводы: {exc}")
        result["error"] = result["error"] or str(exc)

    usage = getattr(client, "usage_summary", None)
    if callable(usage):
        # В stderr, а не через log: строки log попадают в индикатор
        # прогресса на странице, и расход в долларах инженеру там не нужен
        # — он нужен администратору, в лог ошибок прогона.
        print(f"[narrative] расход модели: {usage()}", file=sys.stderr)

    return result
