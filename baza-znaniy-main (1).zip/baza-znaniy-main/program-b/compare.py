# -*- coding: utf-8 -*-
"""
Сравнение редакций рабочей документации — точка входа Verrata.

Принимает 2+ PDF (последовательные редакции РД — исходная, изм.1, изм.2…)
и собирает два отчёта: по чертежам (PDF) и по спецификации (Excel). При
3+ файлах редакции сравниваются последовательно (1→2, 2→3, …), как и в
графе изменений штампа.

Графическая часть — по образцу эталонного отчёта заказчика:
  • листы сопоставляются по штампу (марка и номер; при перенумерации —
    по наименованию), листы без штампа — по содержанию;
  • зоны изменений ищет rdiff.py по растру, по частям листов в дочерних
    процессах (rgraphics.py), картинки к ним рисует rfigures.py;
  • изменённые листы разбирает модель (sheet_agent.py) — по мере того,
    как готовы части, — и пишет сводку по каждому изменению;
  • отчёт собирает rreport.py.

Пример запуска:
  python3 compare.py изм1.pdf изм2.pdf [изм3.pdf ...] -o отчёт.pdf
С разбором листов моделью:
  python3 compare.py --narrative claude --section ВК изм1.pdf изм2.pdf -o отчёт.pdf

Ключ Anthropic при этом НЕ передаётся ни аргументом, ни через окружение:
клиент сам читает файл с правами 600 выше корня сайта (по умолчанию
/var/www/u2980659/data/secrets/anthropic.json, см. --narrative-credentials
и common/anthropic_client.py).
"""
import argparse
import gc
import os
import pickle
import re
import resource
import signal
import sys
import tempfile
import threading
from concurrent.futures import ThreadPoolExecutor

import fitz

# Корень проекта и program-a в путях — здесь, а не в одном из соседних
# модулей. Раньше это делал spec_diff.py, и всё держалось на том, что его
# импорт стоит выше остальных: стоило добавить модуль, которому нужен
# common/, строкой выше — и запуск падал ModuleNotFoundError ещё до первой
# строки работы. Порядок импортов не должен решать, заработает ли программа.
_REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
for _path in (_REPO_ROOT, os.path.join(_REPO_ROOT, "program-a"),
              os.path.dirname(os.path.abspath(__file__))):
    if _path not in sys.path:
        sys.path.insert(0, _path)

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from permits import (declaration_note, declared_sheets, has_permit_words,
                      looks_like_permit, page_lines as permit_lines,
                      parse_permit, stamp_permit_numbers, find_permits)
from stamp import extract_stamp, page_words, pick_document_marka, sheet_key
import raster as rastermod
import rgraphics
import rreport
import sheet_agent
import spec_rename
from sheet_match import (
    match_by_content,
    match_with_model,
    page_signature,
    page_title,
)
from diff_engine import DEFAULT_TOLERANCE_PT
from spec_diff import extract_spec_rows, diff_spec_rows, _is_spec_marka
from spec_excel import (CHRONOLOGY_CONFIRMED as _CHRONOLOGY_CONFIRMED,
                        build_spec_workbook)
from revisions import (MIN_REVISIONS, RevisionError, apply_roles,
                       order_revisions, parse_revision, revision_label)


def _index_sheets(doc):
    """Один проход по документу: листы со штампом (ключ -> индекс
    страницы) и листы без штампа, пригодные для сопоставления по
    содержанию. Разбирать страницу дважды незачем — на комплекте в
    полторы сотни листов это заметное время."""
    keys = {}
    stamps = {}
    stampless = []
    # Листы «Разрешение на внесение изменений» — ради сверки заявленного
    # с фактическим (см. permits.py). Строки собираются только для
    # страниц, где вообще встретилось слово «разрешение»: на комплекте в
    # полторы сотни листов это один-два листа.
    permits = []
    for i in range(len(doc)):
        page = doc[i]
        # Слова страницы разбираются один раз и отдаются штампу: это
        # самая дорогая операция сравнения, и платить за неё дважды на
        # каждой странице комплекта в полторы сотни листов незачем.
        words = page_words(page)
        stamp = extract_stamp(page, words=words)
        stamps[i] = stamp
        if has_permit_words(words):
            lines = permit_lines(words)
            if looks_like_permit(lines):
                permits.append(parse_permit(lines, page=i + 1))
        key = sheet_key(stamp)
        if key:
            if key in keys and _title_key(stamp) and _title_key(stamps[keys[key]]) \
                    and _title_key(stamp) != _title_key(stamps[keys[key]]):
                # Номер листа повторяется у разных чертежей (в ВК изм.2 два
                # листа «25»): второй не должен затереть первый — его
                # сопоставят по наименованию (см. _pair_stamped). Тот же
                # лист дважды (заменённый и заменяющий) — берётся последний.
                key = (key[0], f"{key[1]} (стр. {i + 1})")
            keys[key] = i
            continue
        texts = [w[4] for w in words]
        if not any(t.strip() for t in texts):
            # Растровая вставка: сравнивать нечем, о ней отдельная строка
            # в сводке (см. _skipped_rows).
            continue
        # Весь текст страницы не храним: от него нужны только подпись
        # для сравнения и заголовок для отчёта. На комплекте, где две
        # трети листов без штампа, разница в памяти десятки мегабайт, а
        # предел хостинга — 256 МБ.
        stampless.append({
            "page": i + 1,
            "index": i,
            "width": page.rect.width,
            "height": page.rect.height,
            "title": page_title(texts, limit=14),
            "signature": page_signature(texts),
        })
    return keys, stampless, stamps, permits


def _match_loose(old_pages, new_pages, ask=None, log=print):
    """Сопоставление листов без штампа: сначала кодом по содержанию,
    затем — если подключена модель — остаток отдаём ей.

    Возвращает (pairs, unmatched_old, unmatched_new), где pairs — список
    (old_page, new_page, score, how); how описывает, как лист сопоставлен,
    и попадает в отчёт: инженер должен видеть, что здесь сработал не
    штамп."""
    if not old_pages or not new_pages:
        return [], list(old_pages), list(new_pages)

    pairs, left_old, left_new = match_by_content(old_pages, new_pages)
    out = [(o, n, score, "по содержанию") for o, n, score in pairs]

    if ask is not None and left_old and left_new:
        log(f"[листы] без пары осталось {len(left_old)} старых и {len(left_new)} новых "
            "листов без штампа — спрашиваю модель")
        extra = match_with_model(None, left_old, left_new, ask, log=log)
        if extra:
            done_old = {o["page"] for o, _n, _s in extra}
            done_new = {n["page"] for _o, n, _s in extra}
            left_old = [p for p in left_old if p["page"] not in done_old]
            left_new = [p for p in left_new if p["page"] not in done_new]
            out.extend((o, n, score, "по содержанию, с помощью модели") for o, n, score in extra)

    return out, left_old, left_new


# Сколько листов разбирает одна часть (один дочерний процесс).
#
# Двадцать — из замера: на присланном комплекте ВК лист стоит около 16 с
# процессорного времени, то есть часть укладывается примерно в треть
# предела в 900 с. Меньше дробить смысла нет: каждая часть заново
# открывает оба файла, а это доли секунды на часть.
_SHEETS_PER_CHUNK = 20

# Предел процессорного времени на процесс у хостинга. Нужен только для
# того, чтобы в логе было видно, сколько его осталось.
CPU_LIMIT_SEC = 900


def _memory_mb():
    """Текущая и пиковая память процесса, МБ.

    Текущая — главное число: пик после освобождения памяти не падает, и
    по нему нельзя понять, помогло ли переоткрытие файлов. Пик при этом
    тоже нужен: именно по нему процесс убивают."""
    current = None
    try:
        with open("/proc/self/statm") as handle:
            pages = int(handle.read().split()[1])
        current = pages * os.sysconf("SC_PAGE_SIZE") / 1048576.0
    except (OSError, ValueError, IndexError):
        current = None
    try:
        peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss / 1024.0
    except (OSError, ValueError):
        peak = None
    return current, peak


def _cpu_seconds():
    """Израсходованное процессорное время процесса. У хостинга на него
    жёсткий предел (900 с), и по этому числу видно, сколько осталось:
    по часам судить нельзя, ожидание ответа модели в лимит не считается."""
    try:
        usage = resource.getrusage(resource.RUSAGE_SELF)
        return usage.ru_utime + usage.ru_stime
    except (OSError, ValueError):
        return None


def _virtual_mb():
    """Виртуальная память процесса и её пик, МБ.

    Хостинг ограничивает именно её (ulimit -v 1.5 ГБ), а не резидентную:
    PyMuPDF упирается в предел, когда резидентной ещё всего пара сотен
    мегабайт, и тогда падает прямо в C-коде. По резидентной памяти
    причину такого падения не увидеть."""
    size = peak = None
    try:
        with open("/proc/self/status") as handle:
            for line in handle:
                if line.startswith("VmSize:"):
                    size = int(line.split()[1]) / 1024.0
                elif line.startswith("VmPeak:"):
                    peak = int(line.split()[1]) / 1024.0
    except (OSError, ValueError, IndexError):
        pass
    return size, peak


def _address_limit_mb():
    """Предел виртуальной памяти процесса (ulimit -v), МБ, или None."""
    try:
        soft, _hard = resource.getrlimit(resource.RLIMIT_AS)
    except (OSError, ValueError, AttributeError):
        return None
    if soft in (resource.RLIM_INFINITY, -1) or soft <= 0:
        return None
    return soft / 1048576.0


def _memory_text():
    current, peak = _memory_mb()
    parts = []
    if current is not None and peak is not None:
        parts.append(f"память {current:.0f} МБ (пик {peak:.0f})")
    elif current is not None:
        parts.append(f"память {current:.0f} МБ")
    elif peak is not None:
        parts.append(f"память пик {peak:.0f} МБ")
    virtual, virtual_peak = _virtual_mb()
    if virtual is not None:
        limit = _address_limit_mb()
        parts.append(f"виртуальная {virtual:.0f} МБ"
                     + (f" (пик {virtual_peak:.0f})" if virtual_peak is not None else "")
                     + (f" из {limit:.0f}" if limit else ""))
    cpu = _cpu_seconds()
    if cpu is not None:
        parts.append(f"процессор {cpu:.0f} с из {CPU_LIMIT_SEC}")
    return (", " + ", ".join(parts)) if parts else ""


_PERMIT_IN_STAMP_RE = re.compile(r"\b(\d{3,5}\s*/\s*\d{2})\b")


def _file_meta(path, stamps):
    """Что показать про файл на первой странице: сколько листов, какой
    маркой подписан комплект, что стоит в графах изменений штампов и
    какой датой подписан сам PDF."""
    doc = fitz.open(path)
    try:
        created = (doc.metadata or {}).get("creationDate") or ""
        pages = len(doc)
    finally:
        doc.close()
    # Штампы приходят словарём «индекс страницы -> штамп» (см.
    # _index_sheets), порядок страниц тут и нужен.
    items = [stamps[i] for i in sorted(stamps)] if isinstance(stamps, dict) else list(stamps or ())
    change_log = []
    for stamp in items:
        for line in (stamp or {}).get("change_log") or ():
            if line not in change_log and any(ch.isdigit() for ch in line):
                change_log.append(line)
    marka = pick_document_marka(items) or ""
    return {"pages": pages, "created": created, "change_log": change_log,
             "marka": marka, "graphic": _graphic_range(items, marka)}


def _graphic_range(stamps, marka):
    """Графические листы комплекта для первой страницы: «л. 4–29 (стр.
    6–31)» — листы основной марки без спецификации."""
    found = []
    for page, stamp in enumerate(stamps, 1):
        stamp = stamp or {}
        number = str(stamp.get("sheet_no") or "")
        if stamp.get("marka") != marka or not number.isdigit() or stamp.get("text_sheet"):
            continue
        found.append((int(number), page))
    if not found:
        return "—"
    return "л. %d–%d (стр. %d–%d)" % (min(n for n, _p in found), max(n for n, _p in found),
                                      min(p for _n, p in found), max(p for _n, p in found))


def revision_rows(pdf_paths, file_meta, roles=None):
    """Строки таблицы редакций для первой страницы отчёта: что за файл,
    сколько листов, какой датой подписан PDF, какой номер разрешения
    стоит в графах изменений штампов и что в этих графах написано."""
    rows = []
    for path in pdf_paths:
        name = os.path.basename(path)
        meta = file_meta.get(name) or {}
        change_log = meta.get("change_log") or []
        marka = meta.get("marka") or ""
        permits = []
        for line in change_log:
            for found in _PERMIT_IN_STAMP_RE.findall(line):
                found = found.replace(" ", "")
                # В шифре комплекта («143/23-ГК-РД-2-ОВ2») тоже есть
                # «число/число» — это не номер разрешения.
                if found in marka or found in permits:
                    continue
                permits.append(found)
        rows.append([
            revision_label(path, roles).capitalize(),
            name,
            str(meta.get("pages") or "-"),
            _pdf_date(meta.get("created")),
            ", ".join("№ " + p for p in permits) or "—",
            "; ".join(change_log[-2:]) or "—",
        ])
    return rows


def _pdf_date(raw):
    """Дата из метаданных PDF («D:20250306120000+03'00'») — в вид
    06.03.2025. Метаданных может не быть вовсе."""
    digits = "".join(ch for ch in str(raw or "") if ch.isdigit())
    if len(digits) < 8:
        return "—"
    return f"{digits[6:8]}.{digits[4:6]}.{digits[0:4]}"


_STATUS_CHANGED = "Изменён"
_STATUS_UNCHANGED = "Без изменений"
_STATUS_ONLY_OLD = "Только в старой версии"
_STATUS_ONLY_NEW = "Только в новой версии"
_STATUS_FAILED = "Не проанализирован"


def _sheet_number(sheet_label):
    """Номер листа из его подписи — им разрешение и оперирует."""
    parts = str(sheet_label).rsplit(" — лист ", 1)
    # «25 (стр. 30)» — второй лист с тем же номером (см. _index_sheets).
    return parts[1].split(" (")[0].strip() if len(parts) == 2 else None


def pick_permit(permits, change_number):
    """Разрешение, относящееся к этой редакции: по номеру изменения, а
    если номера нет — последнее по порядку (в комплекте бывают подшиты
    разрешения всех прошлых изменений)."""
    permits = [p for p in (permits or ()) if p and p.get("records")]
    if not permits:
        return None
    if change_number:
        matching = [p for p in permits if p.get("change") == change_number]
        if matching:
            return matching[-1]
    return permits[-1]


def permit_findings(pair, permit, spec_label="спецификац"):
    """Сверка «что заявлено в разрешении» с «что изменилось на самом
    деле» — ради этого раздела отчёт и открывают.

    Возвращает список готовых строк для «Ключевых выводов»."""
    sheets = pair["sheets"]
    if permit is None:
        return ["Разрешение на внесение изменений в новой редакции не найдено: "
                "сверить заявленные изменения с фактическими нечем."]

    declared = declared_sheets(permit)
    head = "Разрешение"
    if permit.get("number"):
        head += " № " + permit["number"]
    if permit.get("date"):
        head += " от " + permit["date"]
    head += (f" (лист {permit['page']}) заявляет листов: {len(declared)}, "
             f"записей: {len(permit.get('records') or ())}.")
    out = [head]

    changed_undeclared, declared_unchanged, new_undeclared = [], [], []
    for row in sheets:
        label, status = row[0], row[1]
        number = _sheet_number(label)
        if number is None:
            continue
        # Номера листов в разрешении относятся к основному комплекту.
        # Лист спецификации с тем же номером — другой лист, и сверять
        # его с этой записью нельзя: содержание спецификации сверяет
        # книга Excel построчно.
        if _is_spec_marka(_marka_of(label)):
            continue
        is_declared = number in declared
        if status == _STATUS_CHANGED and not is_declared:
            changed_undeclared.append(label)
        elif status == _STATUS_ONLY_NEW and not is_declared:
            new_undeclared.append(label)
        elif status == _STATUS_UNCHANGED and is_declared:
            declared_unchanged.append(f"{label} — {declaration_note(declared[number])}")

    if changed_undeclared:
        out.append("Изменены, но в разрешении не заявлены (" + str(len(changed_undeclared))
                    + "): " + _listed(changed_undeclared)
                    + ". Принимать такие листы нельзя, пока запись не появится.")
    if new_undeclared:
        out.append("Новые листы, не заявленные в разрешении (" + str(len(new_undeclared))
                    + "): " + _listed(new_undeclared) + ".")
    if declared_unchanged:
        out.append("Заявлены в разрешении, но изменений не найдено ("
                    + str(len(declared_unchanged)) + "): " + _listed(declared_unchanged)
                    + ". Проверить, не потеряна ли правка.")
    if not (changed_undeclared or new_undeclared or declared_unchanged):
        out.append("Заявленное в разрешении и фактические изменения сходятся.")

    # Номер разрешения в графах изменений штампов: эталонный отчёт ловит
    # ровно этот случай — «2903/25 в штампах против 2309/25 на листе
    # разрешения».
    stamp_numbers = stamp_permit_numbers(pair.get("stamp_change_log"))
    number = (permit.get("number") or "").replace(" ", "")
    if number and stamp_numbers and number not in stamp_numbers:
        out.append("Номер разрешения в графах изменений штампов ("
                    + ", ".join(stamp_numbers) + ") не совпадает с номером на листе "
                      "разрешения (" + number + ").")
    return out


def _natural_key(sheet_label):
    """Порядок листов как в альбоме: «лист 2» раньше «листа 10».
    Посимвольная сортировка ставит их наоборот."""
    parts = re.split(r"(\d+)", str(sheet_label))
    return [int(p) if p.isdigit() else p for p in parts]


def _marka_of(sheet_label):
    """Марка листа из его подписи («143/23-ГК-РД-2-ОВ2.CO — лист 7»)."""
    return str(sheet_label).split(" — ")[0]


_LISTED_LIMIT = 12


_LABEL_SHOWN_CHARS = 48


def _listed(labels, limit=_LISTED_LIMIT):
    """Перечисление листов для выводов. Подпись листа без штампа — это
    его первые слова, и целиком она занимает полстраницы; для списка
    хватает начала."""
    short = []
    for label in labels[:limit]:
        label = str(label)
        short.append(label if len(label) <= _LABEL_SHOWN_CHARS
                      else label[:_LABEL_SHOWN_CHARS - 1].rstrip() + "…")
    shown = ", ".join(short)
    return shown + (f" и ещё {len(labels) - limit}" if len(labels) > limit else "")


# Модель разбирает листы в потоках, пока следующие части листов
# считаются в дочерних процессах (sheet_agent.Reviewer). fork при живых
# потоках безопасен, пока ни один из них не держит блокировку, нужную
# ребёнку, — а ребёнку из общего нужен только вывод: печать и файл
# статуса. Поэтому весь вывод прогона и сам fork идут под одной
# блокировкой.
_OUTPUT_LOCK = threading.Lock()


def _locked(log):
    """log, безопасный для потоков и для fork (см. _OUTPUT_LOCK)."""
    if getattr(log, "_locked", False):
        return log

    def locked_log(message):
        with _OUTPUT_LOCK:
            log(message)
    locked_log._locked = True
    return locked_log


def run_in_child(worker, *args, **options):
    """Выполняет worker(*args) в дочернем процессе и возвращает результат.

    Зачем вообще: у хостинга два предела на ОДИН процесс — 900 с
    процессорного времени и память, — а дочерний процесс получает свои
    собственные. Его память уходит вместе с ним (Python системе
    освобождённое не возвращает, аллокатор держит арены), а счётчик
    процессорного времени у него начинается с нуля.

    Результат возвращается через канал, поэтому он должен быть
    picklable — списки строк отчёта, числа, пути к файлам. Аргументы
    пересылать не нужно: ребёнок получает их вместе со всей памятью
    родителя, поэтому среди них могут быть и функции (например, запись в
    лог), и открытые документы.

    fallback=True: если fork недоступен или ребёнок не справился, worker
    выполняется здесь же — поведение остаётся прежним, просто без
    выигрыша. fallback=False: возвращается None. Так нужно там, где
    ребёнка убили по пределу ресурсов: повторять ту же работу в
    родителе — верный способ убить и его.
    """
    fallback = options.pop("fallback", True)
    report = options.pop("report", None)
    if options:
        raise TypeError(f"неизвестные параметры: {sorted(options)}")
    if not hasattr(os, "fork"):
        return worker(*args) if fallback else None

    read_fd, write_fd = os.pipe()
    _OUTPUT_LOCK.acquire()
    try:
        pid = os.fork()
    finally:
        # И в родителе, и в ребёнке: у ребёнка копия блокировки взята.
        _OUTPUT_LOCK.release()
    if pid == 0:  # дочерний процесс
        code = 1
        try:
            os.close(read_fd)
            try:
                payload = pickle.dumps(("ok", worker(*args)), protocol=2)
            except BaseException as exc:  # noqa: BLE001
                # Причину сообщаем родителю: без неё в логе видно только
                # «не завершился», и не понять, какой предел сработал.
                payload = pickle.dumps(
                    ("error", f"{type(exc).__name__}: {exc}"[:300]), protocol=2)
            with os.fdopen(write_fd, "wb") as handle:
                handle.write(payload)
            code = 0
        except BaseException:  # noqa: BLE001 — ребёнок обязан умереть тихо
            code = 1
        finally:
            os._exit(code)

    os.close(write_fd)
    chunks = []
    usage = None
    try:
        with os.fdopen(read_fd, "rb") as handle:
            while True:
                piece = handle.read(1 << 16)
                if not piece:
                    break
                chunks.append(piece)
    finally:
        # wait4, а не waitpid: он отдаёт расход ресурсов именно этого
        # ребёнка — процессорное время и пик памяти, — и по ним видно,
        # в какой предел хостинга тот упёрся.
        if hasattr(os, "wait4"):
            _, status, usage = os.wait4(pid, 0)
        else:
            _, status = os.waitpid(pid, 0)

    outcome = None
    if chunks:
        try:
            outcome = pickle.loads(b"".join(chunks))
        except Exception:  # noqa: BLE001
            outcome = None
    if report is not None:
        report.clear()
        report.update(_child_report(status, usage, outcome))
    if status == 0 and outcome and outcome[0] == "ok":
        return outcome[1]
    return worker(*args) if fallback else None


# Сигналы, которыми хостинг обычно завершает процесс, — и что они значат
# для инженера, читающего лог.
_SIGNAL_CAUSES = {
    getattr(signal, "SIGXCPU", 24): "превышен предел процессорного времени",
    getattr(signal, "SIGKILL", 9): "процесс снят системой — обычно за превышение памяти",
    getattr(signal, "SIGSEGV", 11): "аварийное падение внутри PyMuPDF — обычно нехватка памяти",
    getattr(signal, "SIGABRT", 6): "аварийное завершение внутри PyMuPDF — обычно нехватка памяти",
}


def _child_report(status, usage, outcome):
    """Почему ребёнок не вернул результат и сколько он успел израсходовать."""
    report = {"cpu": None, "peak_mb": None, "cause": None}
    if usage is not None:
        report["cpu"] = usage.ru_utime + usage.ru_stime
        report["peak_mb"] = usage.ru_maxrss / 1024.0
    if outcome and outcome[0] == "error":
        report["cause"] = f"ошибка: {outcome[1]}"
    elif os.WIFSIGNALED(status):
        number = os.WTERMSIG(status)
        try:
            name = signal.Signals(number).name
        except ValueError:
            name = f"сигнал {number}"
        report["cause"] = f"{_SIGNAL_CAUSES.get(number, 'процесс снят системой')} ({name})"
    elif status != 0:
        report["cause"] = f"процесс завершился с кодом {os.WEXITSTATUS(status)}"
    elif not outcome:
        report["cause"] = "процесс не вернул результат"
    return report


def _child_report_text(report):
    """Причина и расход ребёнка одной строкой для лога."""
    if not report:
        return "причина неизвестна"
    parts = [report.get("cause") or "причина неизвестна"]
    if report.get("cpu") is not None:
        parts.append(f"процессор {report['cpu']:.0f} с из {CPU_LIMIT_SEC}")
    if report.get("peak_mb") is not None:
        parts.append(f"пик памяти {report['peak_mb']:.0f} МБ")
    return ", ".join(parts)


def _index_sheets_of(path):
    with fitz.open(path) as doc:
        return _index_sheets(doc)


def index_sheets_in_child(path):
    """Индексация файла в отдельном процессе: проход по КАЖДОЙ странице
    набирает десятки мегабайт, которые потом не освобождаются, а нужен от
    него маленький результат — ключи листов, зоны штампов и подписи
    листов без штампа."""
    return run_in_child(_index_sheets_of, path)


def _title_key(stamp):
    title = re.sub(r"[^\w,.+()\-]+", " ", ((stamp or {}).get("title") or "").lower())
    return " ".join(title.split())


def _pair_stamped(old_keys, new_keys, old_stamps, new_stamps):
    """Пары листов со штампом: [(ключ новой, стр. старой, стр. новой,
    как сопоставлен)], ключи только старой, ключи только новой.

    Сначала — по номеру листа, если наименования совпадают (или его
    нет). Когда в альбом вставили листы, номера уезжают: в ВК изм.2
    после трёх новых планов «Схема В1.1» стала листом 20 вместо 17, и по
    номеру её сравнивали с планом этажа — выходил «переработанный целиком»
    лист. Такие листы сцепляются по наименованию, если оно в марке
    единственное в обеих редакциях. Оставшиеся с одинаковым номером —
    снова по номеру: наименование просто поправили."""
    def titles(keys, stamps):
        out = {}
        for key, index in keys.items():
            title = _title_key(stamps.get(index))
            if title:
                out.setdefault((key[0], title), []).append(key)
        return out

    old_titles, new_titles = titles(old_keys, old_stamps), titles(new_keys, new_stamps)
    common = sorted(set(old_keys) & set(new_keys), key=lambda k: _natural_key(_sheet_label(k)))
    pairs, used_old, used_new = [], set(), set()

    def take(old_key, new_key):
        pairs.append((old_key, new_key))
        used_old.add(old_key)
        used_new.add(new_key)

    for key in common:
        old_title = _title_key(old_stamps.get(old_keys[key]))
        new_title = _title_key(new_stamps.get(new_keys[key]))
        if not old_title or not new_title or old_title == new_title:
            take(key, key)
    for title_key, new_list in sorted(new_titles.items()):
        old_list = old_titles.get(title_key) or []
        if (len(new_list) == 1 and len(old_list) == 1
                and new_list[0] not in used_new and old_list[0] not in used_old):
            take(old_list[0], new_list[0])
    for key in common:
        if key not in used_old and key not in used_new:
            take(key, key)

    pairs.sort(key=lambda pair: _natural_key(_sheet_label(pair[1])))
    matched = [(new_key, old_keys[old_key], new_keys[new_key],
                "" if old_key == new_key else f"был лист {old_key[1]}")
               for old_key, new_key in pairs]
    only_old = sorted(set(old_keys) - used_old, key=lambda k: _natural_key(_sheet_label(k)))
    only_new = sorted(set(new_keys) - used_new, key=lambda k: _natural_key(_sheet_label(k)))
    return matched, only_old, only_new


def _stampless_key(old_page, new_page):
    """Ключ листа без штампа — марки у него нет, поэтому вместо неё
    None, а вместо номера листа номера страниц в обеих редакциях."""
    return (None, f"{old_page['page']}\u2192{new_page['page']}")


def _sheet_label(key):
    marka, sheet_no = key
    if not marka:
        return f"лист без штампа — стр. {sheet_no}"
    return f"{marka} — лист {sheet_no}"


MODE_FULL = "full"
MODE_GRAPHICS = "graphics"
MODE_SPEC = "spec"
MODES = (MODE_FULL, MODE_GRAPHICS, MODE_SPEC)

# Поставщик чернового текста (см. narrative.PROVIDERS). Дублируется здесь
# строками, чтобы обычный прогон без чернового текста не импортировал
# narrative.py и клиентов моделей вовсе.
NARRATIVE_PROVIDERS = ("claude",)


def _mark_spec_pages(stamps):
    """Листы без штампа внутри диапазона листов спецификации (от первого
    до последнего листа с маркой «.СО», как в spec_diff._spec_page_range)
    — тоже спецификация: продолжение таблицы, у которого штамп не
    прочитан. Сравнивать их как чертежи нельзя — их «зоны» были бы
    изменениями спецификации в графическом отчёте."""
    spec = [i for i, stamp in stamps.items() if _is_spec_marka((stamp or {}).get("marka"))]
    if not spec:
        return
    for i in range(min(spec), max(spec) + 1):
        stamp = stamps.get(i)
        if stamp is not None and not stamp.get("marka") and not stamp.get("text_sheet"):
            stamp["text_sheet"] = "спецификация (лист без штампа)"


def _without_drawing(key, stamp):
    """Лист без чертежа: спецификация, общие данные, ведомость.

    Изменился он или нет, считается как обычно — это нужно для сверки с
    разрешением и штампом. Но зон и карточек у такого листа нет: его
    правки — сдвинувшиеся строки таблиц и переписанный текст, а в
    графический отчёт идут изменения трассировки и оборудования.
    Спецификацию сверяет книга Excel."""
    return _is_spec_marka(key[0]) or bool((stamp or {}).get("text_sheet"))


def _permit_notes(permit):
    """Что разрешение говорит про каждый лист: {номер листа: текст}."""
    if permit is None:
        return {}
    out = {}
    for number, records in declared_sheets(permit).items():
        texts = "; ".join(r["text"][:300] for r in records if r.get("text"))
        note = declaration_note(records)
        if permit.get("number"):
            note += " — разрешение № " + permit["number"]
        out[number] = note + (": «" + texts + "»" if texts else "")
    return out


def compare_pair(old_path, new_path, tmp_dir, sheets_out, sheet_rows, spec_rows,
                  spec_notes=None, spec_verdicts=None, log=print,
                  old_spec=None, new_spec=None, with_graphics=True, with_spec=True,
                  sheet_ask=None, roles=None, file_meta=None, on_record=None):
    """on_record — вызывается для каждого разобранного листа сразу, как
    только готова его часть (так модель начинает разбор, не дожидаясь
    конца сравнения)."""
    old_doc = fitz.open(old_path)
    new_doc = fitz.open(new_path)
    label = f"{os.path.basename(old_path)} → {os.path.basename(new_path)}"

    if not with_graphics:
        # Режим "Обработать спецификацию": разбор чертежей — самая долгая часть
        # прогона (на комплекте в 147 листов это почти всё его время), и
        # ради одной таблицы её делать незачем.
        old_doc.close()
        new_doc.close()
        _compare_spec(old_path, new_path, tmp_dir, spec_rows, label, log,
                      old_spec, new_spec,
                      spec_notes=spec_notes, spec_verdicts=spec_verdicts,
                      ask=sheet_ask)
        return

    # Индексация — в дочерних процессах, по одному на файл: она набирает
    # десятки мегабайт, которые потом не освобождаются (см.
    # index_sheets_in_child). Здесь файлы на это время закрыты, чтобы
    # ребёнок не наследовал их разобранное содержимое.
    old_doc.close()
    new_doc.close()
    old_keys, old_loose, old_stamps, _old_permits = index_sheets_in_child(old_path)
    new_keys, new_loose, new_stamps, new_permits = index_sheets_in_child(new_path)
    _mark_spec_pages(old_stamps)
    _mark_spec_pages(new_stamps)
    if file_meta is not None:
        # Паспорт файла для первой страницы отчёта — из уже разобранных
        # штампов, второй раз комплект ради этого не читаем.
        for path, stamps, found in ((old_path, old_stamps, _old_permits),
                                     (new_path, new_stamps, new_permits)):
            meta = _file_meta(path, stamps)
            meta["permits"] = found
            file_meta.setdefault(os.path.basename(path), meta)
    old_doc = fitz.open(old_path)
    new_doc = fitz.open(new_path)
    gc.collect()
    stamped, only_old, only_new = _pair_stamped(old_keys, new_keys, old_stamps, new_stamps)

    # Листы без штампа (приложения, схемы, таблицы событий — на комплекте
    # ПС это почти четверть) сопоставляются по содержанию: у них есть и
    # текст, и вектор, им просто нечем сцепиться через штамп. Раньше они
    # исчезали из отчёта молча.
    loose_pairs, loose_old, loose_new = _match_loose(old_loose, new_loose, ask=sheet_ask, log=log)

    matched = list(stamped)
    renumbered = sum(1 for item in stamped if item[3])
    for old_page, new_page, score, how in loose_pairs:
        matched.append((_stampless_key(old_page, new_page),
                        old_page["index"], new_page["index"], how))

    log(f"[{label}] сопоставлено листов: {len(stamped)}"
        + (f" + {len(loose_pairs)} без штампа по содержанию" if loose_pairs else "")
        + (f" (из них {renumbered} — по наименованию: номер листа сменился)"
           if renumbered else "")
        + f", только в старой: {len(only_old) + len(loose_old)}, "
          f"только в новой: {len(only_new) + len(loose_new)}")

    # Запись разрешения по каждому листу — модели, вместе с картинками:
    # она сверяет заявленное с тем, что видит.
    number = (roles or {}).get(os.path.basename(new_path), parse_revision(new_path)[1])
    permit_notes = _permit_notes(pick_permit(new_permits, number))
    pair_label = (revision_label(old_path, roles).capitalize() + " → "
                  + revision_label(new_path, roles).capitalize())

    # Разбор листов идёт ЧАСТЯМИ, каждая в своём процессе. У хостинга
    # пределы стоят на один процесс — 900 с процессорного времени и
    # память, — а дочерний получает свои собственные: счётчик времени у
    # него с нуля, память уходит вместе с ним.
    chunks = [(index, matched[index:index + _SHEETS_PER_CHUNK])
              for index in range(0, len(matched), _SHEETS_PER_CHUNK)]

    # Картинки листов — в свою папку на каждую пару: имена файлов строятся
    # из номера части и листа в ней, и вторая пара иначе затирала бы
    # картинки первой.
    pair_dir = tempfile.mkdtemp(prefix="gfx_", dir=tmp_dir)

    def run_part(first_index, part, tag, report):
        return run_in_child(
            rgraphics.graphics_chunk, old_path, new_path, part, new_stamps, pair_dir,
            tag, first_index + 1, len(matched), label, pair_label, permit_notes,
            _without_drawing, log, _memory_text, fallback=False, report=report)

    def merge(result):
        sheet_rows.extend(result["rows"])
        sheets_out.extend(result["records"])
        if on_record is not None:
            for record in result["records"]:
                on_record(record)

    def lost(index, key, report):
        # Терять из-за этого листа остальные нельзя: он честно попадает
        # в сводку строкой, а причина — в лог, чтобы было видно, какой
        # предел мешает.
        log(f"[{label}] лист {index + 1} из {len(matched)} ({_sheet_label(key)}) "
            f"разобрать не удалось: {_child_report_text(report)}")
        cause = report.get("cause") or ""
        detail = (f"ошибка разбора листа: {cause[len('ошибка: '):][:80]}"
                  if cause.startswith("ошибка: ") else "разбор прерван: не хватило ресурсов")
        sheet_rows.append([_sheet_label(key), "Не проанализирован", "-", detail, "-"])

    def one_sheet(index, sheet, tag):
        """Лист в собственном процессе; не вышло и так — строкой в сводке."""
        report = {}
        result = run_part(index, [sheet], tag, report)
        if result is not None:
            merge(result)
            if not result.get("unfinished"):
                return
            report = {"cause": "ошибка: сбой внутри PyMuPDF"}
        lost(index, sheet[0], report)

    def run_sheets(first_index, part, tag):
        report = {}
        result = run_part(first_index, part, tag, report)
        if result is None:
            # Часть не справилась — её убили по пределу или она упала.
            # Терять из-за одного тяжёлого листа все двадцать нельзя:
            # листы части разбираются заново, каждый в своём процессе.
            log(f"[{label}] часть листов {first_index + 1}–{first_index + len(part)} "
                f"не завершилась ({_child_report_text(report)}); "
                "разбираю эти листы по одному")
            for offset, sheet in enumerate(part):
                one_sheet(first_index + offset, sheet, f"{tag}_{offset:02d}")
            return
        merge(result)
        rest = result.get("unfinished") or []
        if not rest:
            return
        # Часть остановилась на листе, который упал внутри PyMuPDF: он
        # идёт в свой процесс, а оставшиеся — новой частью.
        index = first_index + len(part) - len(rest)
        one_sheet(index, rest[0], f"{tag}_{len(part) - len(rest):02d}")
        if rest[1:]:
            run_sheets(index + 1, rest[1:], f"{tag}r")

    for chunk_no, (first_index, chunk) in enumerate(chunks):
        run_sheets(first_index, chunk, f"{chunk_no:03d}")

    # Листы без чертежа (спецификация, общие данные) помечаются и среди
    # появившихся и исключённых: в графический отчёт они не идут.
    for key in only_old:
        stamp = old_stamps.get(old_keys[key]) or {}
        sheet_rows.append([_sheet_label(key), "Только в старой версии", "-",
                           stamp.get("title") or "-",
                           "без чертежа" if _without_drawing(key, stamp) else "-"])
    for key in only_new:
        stamp = new_stamps.get(new_keys[key]) or {}
        sheet_rows.append([_sheet_label(key), "Только в новой версии", "-",
                           stamp.get("title") or "-",
                           "без чертежа" if _without_drawing(key, stamp) else "-"])

    # Листы без штампа, которым пары не нашлось, — тоже в сводку: иначе
    # они снова исчезнут молча, а именно с этого всё и начиналось.
    for page in loose_old:
        sheet_rows.append([f"лист без штампа — стр. {page['page']} ({page['title']})",
                           "Только в старой версии", "штампа нет", "-", "-"])
    for page in loose_new:
        sheet_rows.append([f"лист без штампа — стр. {page['page']} ({page['title']})",
                           "Только в новой версии", "штампа нет", "-", "-"])

    # В stderr, а не в строку прогресса: инженеру это не нужно, а в логе
    # прогона — первое, на что смотреть при сбое разбора.
    print(f"[{label}] по итогам пары{_memory_text()}", file=sys.stderr)

    if with_spec:
        _compare_spec(old_path, new_path, tmp_dir, spec_rows, label, log,
                      old_spec, new_spec,
                      spec_notes=spec_notes, spec_verdicts=spec_verdicts,
                      ask=sheet_ask)


def _compare_spec(old_path, new_path, tmp_dir, spec_rows, label, log,
                   old_spec, new_spec, spec_notes=None, spec_verdicts=None, ask=None):
    # Спецификации читаются один раз на файл в compare_files и передаются
    # сюда: при трёх-четырёх ревизиях один и тот же файл иначе разбирался
    # бы дважды — как новая версия в одной паре и как старая в следующей.
    if old_spec is None:
        old_spec = extract_spec_rows(old_path, tmp_dir)
    if new_spec is None:
        new_spec = extract_spec_rows(new_path, tmp_dir)
    sd = None
    if old_spec or new_spec:
        sd = diff_spec_rows(old_spec, new_spec)
        log(f"[{label}] спецификация: добавлено {len(sd['added'])}, "
            f"удалено {len(sd['removed'])}, изменилось кол-во {len(sd['qty_changed'])}")
        for r in sd["added"]:
            spec_rows.append(["Добавлено", r["name"][:70], str(r["type"])[:45], "", r["qty"]])
        for r in sd["removed"]:
            spec_rows.append(["Удалено", r["name"][:70], str(r["type"])[:45], r["qty"], ""])
        for o, n in sd["qty_changed"]:
            spec_rows.append(["Кол-во изменено", o["name"][:70], str(o["type"])[:45], o["qty"], n["qty"]])

        # Переименованные позиции: «Клапан КПС-1» → «Клапан противопожарный
        # КПС-1» иначе читается как «одну убрали, другую добавили». Это
        # ПРЕДПОЛОЖЕНИЕ: строки «Добавлено» и «Удалено» остаются на месте,
        # подтверждает инженер.
        if ask is not None:
            renames = spec_rename.find_renames(ask, sd["removed"], sd["added"], log=log)
            if renames:
                log(f"[{label}] возможных переименований позиций: {len(renames)}")
            for old_row, new_row, _score in renames:
                spec_rows.append([
                    "Переименовано?",
                    f"{old_row['name']} → {new_row['name']}"[:70],
                    str(new_row.get("type") or "")[:45],
                    old_row.get("qty", ""),
                    new_row.get("qty", ""),
                ])
            if spec_notes is not None:
                spec_notes.extend(spec_rename.rename_notes(renames))


def _order_columns(nz_paths, notes_out=None, log=print):
    """Наряды-заказы как дополнительные колонки таблицы.

    partial=True: наряд перечисляет не всю спецификацию, а только то, что
    заказывают сверх неё, поэтому отсутствие позиции в нём — пустая
    ячейка, а не ноль (см. spec_excel._is_partial). В сравнение идут
    только материалы: работы («Монтаж круглого дефлектора») количеством
    материала не являются.
    """
    if not nz_paths:
        return []
    import nz as nz_module
    columns = []
    for path in nz_paths:
        order = nz_module.parse_order(path)
        materials = nz_module.materials(order)
        rows = [{"name": row["name"], "type": "", "unit": row["unit"],
                 "qty": row["qty"], "system": row["place"]} for row in materials]
        note = order.get("theme")
        columns.append({"label": order["label"], "rows": rows, "partial": True,
                        "note": (f"{order['file']}" + (f" — {note}" if note else ""))})
        log(f"{order['label']}: материалов {len(rows)} из {len(order['rows'])} строк")
        if notes_out is not None:
            notes_out.extend(order.get("notes") or ())
    return columns


def _spec_revisions(pdf_paths, specs, roles=None):
    """Редакции для Excel-отчёта: колонка подписывается изменением
    («исходная редакция», «изм. 1»), а имя файла уходит в шапку отчёта.
    Инженер сравнивает редакции комплекта, и в шапке колонки ему нужен
    номер изменения, а не имя присланного файла."""
    return [{"label": revision_label(path, roles), "rows": rows,
             "note": os.path.basename(path),
             "document": os.path.splitext(os.path.basename(path))[0]}
            for path, rows in zip(pdf_paths, specs)]


def spec_legend(pdf_paths, specs, spec_verdicts, section=None):
    """Что известно о комплекте — для листа «Легенда» книги (формат
    эталона ОВ, spec_excel_ov.py): число страниц файла, разрешение,
    вердикт приёмочной проверки разбора."""
    revisions = []
    for path in pdf_paths:
        info = {}
        try:
            with fitz.open(path) as doc:
                info["pages"] = len(doc)
                found = [p for p in find_permits(doc, words_of=page_words)
                         if p.get("number")]
                if found:
                    permit = found[-1]
                    info["permit"] = permit["number"] + (f" ({permit['date']})"
                                                         if permit.get("date") else "")
        except Exception:  # noqa: BLE001 — легенда не стоит книги
            pass
        revisions.append(info)

    verification = []
    for path in pdf_paths:
        verdict = (spec_verdicts or {}).get(os.path.basename(path))
        if not verdict:
            continue
        line = (f"{os.path.basename(path)}: {verdict.get('verdict')}"
                f" ({verdict.get('positions_in_report')} позиций в отчёте, "
                f"{verdict.get('numbers_on_sheets')} чисел графы «Кол.» на листах)")
        if not verdict.get("reconciled"):
            line += " — НЕ СВЕДЕНО, количествам этой редакции верить нельзя"
        verification.append(line)
    if verification:
        verification.insert(0, "тройная (сумма/счёт графы «Кол.», порядок, близость "
                               "наименования) по каждому листу СО:")
        verification = [" ".join(verification[:1]) + " " + "; ".join(verification[1:])]

    base = parse_revision(pdf_paths[0])[0] if pdf_paths else ""
    return {
        "section": " — ".join(p for p in (section, os.path.basename(str(base))) if p),
        "revisions": revisions,
        "verification": verification,
    }


def _skipped_pages(path):
    """Страницы, не попавшие в сопоставление листов, двух видов.

    "raster" — без текстового слоя, вставленные растровые сканы.
    Сравнивать их нечем: разбор опирается на текст и вектор из
    CAD-экспорта, а у картинки нет ни того, ни другого.

    "no_stamp" — текст есть, но штамп не прочитан: не нашлось ни марки,
    ни номера листа, а по ним и идёт сопоставление между редакциями.

    И те и другие иначе исчезают из отчёта молча — инженер прочтёт
    отсутствие листа как "изменений нет". Это ровно то, чего допустить
    нельзя: отсутствие строки неотличимо от отсутствия изменений.
    """
    doc = fitz.open(path)
    try:
        raster, no_stamp = [], []
        for i in range(len(doc)):
            page = doc[i]
            if not page.get_text().strip():
                raster.append(i + 1)
            elif sheet_key(extract_stamp(page)) is None:
                no_stamp.append(i + 1)
        return {"raster": raster, "no_stamp": no_stamp}
    finally:
        doc.close()


def _pages_list(pages, limit=12):
    shown = ", ".join(str(p) for p in pages[:limit])
    if len(pages) > limit:
        shown += f" … всего {len(pages)}"
    return shown


def _skipped_rows(pdf_paths, client=None, log=print):
    rows = []
    for path in pdf_paths:
        skipped = _skipped_pages(path)
        name = os.path.basename(path)
        if skipped["raster"]:
            # Сравнить растровый лист не с чем, но назвать его можно:
            # «стр. 52 — Рисунок 12, схема подключения ШУН» полезнее, чем
            # голый номер страницы. Единственное место разбора, куда
            # уходит картинка, и потому с жёстким потолком.
            described = {}
            if client is not None:
                doc = fitz.open(path)
                try:
                    described = rastermod.describe_pages(
                        client, doc, skipped["raster"], log=log)
                finally:
                    doc.close()
            for number in skipped["raster"]:
                if number in described:
                    rows.append([
                        f"{name} — стр. {number}: {described[number]}",
                        "Не проанализирован",
                        "-",
                        "растровое изображение, лист опознан моделью",
                        "-",
                    ])
            rest = [n for n in skipped["raster"] if n not in described]
            if rest:
                rows.append([
                    f"{name} — стр. {_pages_list(rest)}",
                    "Не проанализирован",
                    "-",
                    "растровое изображение без текстового слоя",
                    "-",
                ])
        if skipped["no_stamp"]:
            rows.append([
                f"{name} — стр. {_pages_list(skipped['no_stamp'])}",
                "Не проанализирован",
                "-",
                "штамп не прочитан: лист не с чем сопоставить",
                "-",
            ])
    return rows


def compare_files(pdf_paths, output_path=None, tmp_dir=None, tolerance=DEFAULT_TOLERANCE_PT,
                   narrative=None, narrative_credentials=None,
                   narrative_notes_out=None, log=print, spec_xlsx=None, mode=MODE_FULL,
                   roles=None, section=None,
                   nz_paths=()):
    """mode — что именно считать, под три кнопки на сайте:

      full      — отчёт по чертежам (PDF) и по спецификации (Excel);
      graphics  — только чертежи, спецификация не разбирается вовсе;
      spec      — только спецификация, чертежи не разбираются.

    Разделение не косметическое: разбор чертежей занимает почти всё время
    прогона, и гонять его ради одной таблицы (или наоборот) — впустую
    жечь лимит процессорного времени на хостинге.

    tolerance и narrative_notes_out остались от прежнего, векторного
    сравнения и не используются: их передают прежние вызовы.
    """
    if mode not in MODES:
        raise ValueError(f"Неизвестный режим обработки: {mode!r}")
    log = _locked(log)
    with_graphics = mode in (MODE_FULL, MODE_GRAPHICS)
    with_spec = mode in (MODE_FULL, MODE_SPEC)
    if with_graphics and not output_path:
        raise ValueError("Для отчёта по чертежам нужен путь к выходному PDF.")
    if mode == MODE_SPEC and not spec_xlsx:
        raise ValueError("Для отчёта по спецификации нужен путь к выходному .xlsx.")
    # Порядок редакций — по именам файлов (см. revisions.py), а не по
    # порядку, в котором их выбрали в окне загрузки.
    # Одной редакции хватает, если загружены наряды-заказы: сравнивать
    # есть с чем — проект против дополнительных объёмов. Без нарядов одна
    # редакция по-прежнему бессмысленна, сравнивать не с чем.
    # Подтверждённые инженером роли побеждают имена файлов (см. карточку
    # «Что я нашёл» и revisions.apply_roles).
    pdf_paths = (apply_roles(pdf_paths, roles) if roles
                 else order_revisions(pdf_paths,
                                      minimum=1 if nz_paths else MIN_REVISIONS))
    log("Порядок редакций: " + " → ".join(
        f"{os.path.basename(p)} ({revision_label(p, roles)})" for p in pdf_paths))

    if tmp_dir is None:
        tmp_dir = tempfile.mkdtemp(prefix="revdiff_")

    sheet_rows = []
    spec_rows = []
    spec_notes = []

    # Клиент модели создаётся один раз на прогон: сопоставление листов без
    # штампа, разбор изменённых листов графики, сводки по изменениям,
    # переименования в спецификации. Импорт здесь, а не в шапке файла —
    # без модели обычный прогон не должен тянуть её клиентов вовсе.
    # Модель недоступна — графика всё равно сравнивается, просто зоны
    # остаются без описаний.
    model_client = None
    sheet_ask = None
    if narrative:
        from narrative import make_sheet_ask, try_make_client
        pairs_count = max(len(pdf_paths) - 1, 1)
        # Предохранитель от зацикливания: изменённых листов не больше, чем
        # страниц в новых редакциях.
        pages = 0
        for path in pdf_paths[1:]:
            with fitz.open(path) as doc:
                pages += len(doc)
        model_client = try_make_client(narrative, credentials_file=narrative_credentials,
                                       log=log,
                                       max_requests=sheet_agent.requests_needed(pages, pairs_count))
        sheet_ask = make_sheet_ask(model_client)

    # Спецификация каждого файла разбирается один раз: в цепочке ревизий
    # средние файлы участвуют в двух парах подряд.
    # notes_out: предупреждение, если таблица спецификации прочитана не
    # целиком. Оно попадает в шапку Excel-отчёта — молча выдавать таблицу,
    # где непрочитанные позиции неотличимы от исключённых, нельзя.
    # Вердикт гейта по каждому файлу — отдельно от примечаний: примечания
    # идут в шапку книги человеку, вердикт — в пакет фактов агенту.
    spec_verdicts = {}
    specs = []
    if with_spec:
        for path in pdf_paths:
            verdicts = []
            specs.append(extract_spec_rows(path, tmp_dir, notes_out=spec_notes,
                                           verdicts_out=verdicts))
            if verdicts:
                spec_verdicts[os.path.basename(path)] = verdicts[0]
    else:
        specs = [None] * len(pdf_paths)
    # Предупреждения приёмочного гейта — сразу в лог, а не только в шапку
    # книги: при запуске из командной строки книгу могут и не открыть.
    for note in spec_notes:
        log(note)

    # Сравнение пар — самая тяжёлая часть прогона, и падает она первой.
    # Таблица спецификации к этому моменту уже разобрана и стоит дёшево,
    # поэтому её книга собирается в любом случае: сбой на чертежах не
    # должен уносить с собой готовый Excel. Ошибку поднимаем ПОСЛЕ сборки
    # книги — чтобы и отчёт сохранился, и о сбое было сказано.
    pair_failure = None
    # Границы пар в общих списках строк: по ним потом строятся «Ключевые
    # выводы».
    pairs = []
    file_meta = {}
    reviewer = None
    if model_client is not None and with_graphics:
        reviewer = sheet_agent.Reviewer(model_client, section, log=log)
        log(f"[графика] изменённые листы модель разбирает по мере сравнения, "
            f"по {sheet_agent.PARALLEL_REQUESTS} одновременно")
    for i in range(len(pdf_paths) - 1):
        sheet_start = len(sheet_rows)
        records = []
        try:
            compare_pair(pdf_paths[i], pdf_paths[i + 1], tmp_dir, records,
                         sheet_rows, spec_rows,
                         spec_notes=spec_notes, spec_verdicts=spec_verdicts,
                         log=log,
                         old_spec=specs[i], new_spec=specs[i + 1],
                         with_graphics=with_graphics, with_spec=with_spec,
                         sheet_ask=sheet_ask, roles=roles, file_meta=file_meta,
                         on_record=reviewer.submit if reviewer is not None else None)
        except Exception as exc:                  # noqa: BLE001
            pair_failure = exc
            log(f"[{os.path.basename(pdf_paths[i])} → "
                f"{os.path.basename(pdf_paths[i + 1])}] сравнение прервалось: {exc}")
            break
        finally:
            new_meta = file_meta.get(os.path.basename(pdf_paths[i + 1])) or {}
            number = (roles or {}).get(os.path.basename(pdf_paths[i + 1]),
                                       parse_revision(pdf_paths[i + 1])[1])
            pairs.append({
                "label": (revision_label(pdf_paths[i], roles).capitalize() + " → "
                           + revision_label(pdf_paths[i + 1], roles).capitalize()),
                "sheets": sheet_rows[sheet_start:],
                "records": records,
                "stamp_change_log": new_meta.get("change_log") or [],
                "permits": new_meta.get("permits") or [],
                "change_number": number,
                "new_path": pdf_paths[i + 1],
            })
    if spec_xlsx and with_spec:
        if any(specs):
            # Наряды идут ПОСЛЕ редакций: их строки подшиваются к уже
            # найденным позициям спецификации (см. spec_excel).
            order_columns = _order_columns(nz_paths, notes_out=spec_notes, log=log)
            build_spec_workbook(
                _spec_revisions(pdf_paths, specs, roles) + order_columns, spec_xlsx,
                title="Сравнение спецификаций оборудования, изделий и материалов",
                notes=spec_notes,
                chronology=(_CHRONOLOGY_CONFIRMED if roles else None),
                section=section,
                legend=spec_legend(pdf_paths, specs, spec_verdicts, section))
            log("Отчёт по спецификации собран.")
            print(f"Отчёт по спецификации: {spec_xlsx}", file=sys.stderr)
        else:
            log("Листы спецификации не найдены ни в одной редакции — "
                "отчёт по спецификации не собран.")

    if pair_failure is not None:
        if reviewer is not None:
            reviewer.finish()
        # Книга уже на диске — теперь можно и упасть.
        raise pair_failure

    if not with_graphics:
        # Режим "Обработать спецификацию" — PDF-отчёта в нём нет по определению.
        return spec_xlsx

    sheet_rows.extend(_skipped_rows(pdf_paths, client=model_client, log=log))
    graphics_report(output_path, pdf_paths, pairs, file_meta, roles, section,
                    model_client, log, reviewer=reviewer)
    print(f"Отчёт сохранён: {output_path}", file=sys.stderr)
    return output_path


def graphics_report(output_path, pdf_paths, pairs, file_meta, roles, section,
                    model_client, log=print, reviewer=None):
    """Разбор изменённых листов моделью и отчёт по образцу эталона.
    reviewer — sheet_agent.Reviewer, которому листы отдавались по ходу
    сравнения; без него (и с моделью) листы разбираются здесь."""
    changed = [r for pair in pairs for r in pair["records"]
               if r["zones"] and not r.get("reworked")]
    if reviewer is None and model_client is not None:
        reviewer = sheet_agent.Reviewer(model_client, section, log=log)
        for record in changed:
            reviewer.submit(record)
    if reviewer is not None:
        log("[графика] жду разбора листов моделью")
        reviewer.finish()
    else:
        for record in changed:
            sheet_agent.apply_review(record, None)

    report_pairs = []
    summaries = {}
    for index, pair in enumerate(pairs):
        permit = pick_permit(pair.get("permits"), pair.get("change_number"))
        permit_lines = permit_findings(pair, permit)
        change = revision_label(pair["new_path"], roles).capitalize()
        if permit and permit.get("number"):
            change += " (%s)" % permit["number"]
        item = {"label": pair["label"], "change": change, "permit_lines": permit_lines,
                "sheets": [_loaded(r) for r in pair["records"]]}
        item["by_label"] = {r["label"]: r for r in item["sheets"]}
        # Сводка по листам — все графические листы, не только изменённые.
        # moves — куда уехал номер листа старой редакции (None — лист
        # исключён): по ним строка сводки ведёт один и тот же чертёж через
        # все редакции (см. _sheet_order).
        item["removed"] = {}
        item["moves"] = {}
        item["old_edition"] = revision_label(pdf_paths[index], roles)
        for row in pair["sheets"]:
            name = row[0]
            how = row[5] if len(row) > 5 else ""
            if how.startswith("был лист "):
                item["moves"][_marka_of(name) + " — лист " + how[len("был лист "):]] = name
            # Листы без штампа — обложки, титулы, вставки: в сводке они
            # только если на них нашлись зоны (тогда они уже в by_label).
            if name.startswith("лист без штампа") or (len(row) > 4 and row[4] == "без чертежа"):
                continue
            title = row[3] if row[3] not in ("-", None) else ""
            if row[1] == _STATUS_ONLY_OLD:
                item["moves"][name] = None
                item["removed"][name] = {"status_text": "Исключён", "zones": [], "title": title}
                continue
            if name in item["by_label"]:
                continue
            if row[1] == _STATUS_FAILED:
                title = ""
            item["by_label"][name] = {
                "status_text": {_STATUS_ONLY_NEW: "Новый лист",
                                _STATUS_FAILED: "Не проанализирован"}.get(row[1]),
                "zones": [], "title": title, "how": how}
        if model_client is not None and any(r["zones"] or r.get("reworked")
                                            for r in pair["records"]):
            summaries[len(report_pairs)] = {
                "label": change,
                "permit": {"номер": (permit or {}).get("number"),
                           "дата": (permit or {}).get("date"),
                           "записи": [r.get("text") for r in (permit or {}).get("records") or []]},
                "permit_check": permit_lines,
                "sheets": [r for r in pair["records"] if r["zones"] or r.get("reworked")],
            }
        report_pairs.append(item)
    if summaries:
        # Сводки по изменениям независимы — тоже одновременно.
        log(f"[графика] модель пишет ключевые изменения и сверку: {len(summaries)}")
        with ThreadPoolExecutor(max_workers=len(summaries)) as pool:
            futures = {index: pool.submit(sheet_agent.summarize_pair, model_client, facts,
                                          section, log)
                       for index, facts in summaries.items()}
        for index, future in futures.items():
            try:
                report_pairs[index]["summary"] = future.result()
            except Exception as exc:  # noqa: BLE001 — сводка из сверки кода
                log(f"[{summaries[index]['label']}] сводку по изменению модель не написала: {exc}")

    marka = next((m.get("marka") for m in file_meta.values() if m.get("marka")), "")
    info = {
        "marka": marka,
        "model": sheet_agent.SHEET_MODEL if model_client is not None else None,
        "editions": _edition_rows(pdf_paths, file_meta, pairs, roles),
        "compared": _compared_text(pairs),
        "footer": "%s · графическое сравнение: %s" % (
            marka, " / ".join(r["label"].lower() for r in _edition_rows(
                pdf_paths, file_meta, pairs, roles))),
    }
    order = _sheet_order(report_pairs)
    rreport.build(output_path, info, report_pairs, order, log=log)
    if model_client is not None:
        log("[модель] " + model_client.usage_summary())


def _loaded(record):
    """Описание листа с картинками, прочитанными из временных файлов."""
    def read(path):
        with open(path, "rb") as handle:
            return handle.read()
    out = dict(record)
    if record.get("overview"):
        out["overview"] = dict(record["overview"], data=read(record["overview"]["file"]))
    for side in ("old", "new"):
        full = record.get("%s_full" % side)
        if full:
            out["%s_full" % side] = (read(full["file"]), full["w"], full["h"])
    zones = []
    for zone in record["zones"]:
        zone = dict(zone)
        if zone.get("frag_old"):
            zone["frag_old"] = read(zone["frag_old"])
            zone["frag_new"] = read(zone["frag_new"])
        zones.append(zone)
    out["zones"] = zones
    return out


def _edition_rows(pdf_paths, file_meta, pairs, roles):
    rows = []
    for index, path in enumerate(pdf_paths):
        meta = file_meta.get(os.path.basename(path)) or {}
        permit_text = "—"
        if index > 0:
            pair = pairs[index - 1] if index - 1 < len(pairs) else {}
            permit = pick_permit(pair.get("permits"), pair.get("change_number"))
            if permit and permit.get("number"):
                permit_text = permit["number"] + (" от " + permit["date"] if permit.get("date") else "")
        rows.append({"label": revision_label(path, roles).capitalize(),
                     "file": os.path.basename(path), "permit": permit_text,
                     "pages": meta.get("pages") or "—", "graphic": meta.get("graphic") or "—"})
    return rows


def _compared_text(pairs):
    sheets = set()
    for pair in pairs:
        for row in pair["sheets"]:
            if row[1] in (_STATUS_CHANGED, _STATUS_UNCHANGED) and row[4] != "без чертежа":
                sheets.add(row[0])
    return ("%d графических листов в %d %s: %s. Общие данные, ведомости и спецификация "
            "в графическое сравнение не входят — спецификация сравнена отдельной "
            "таблицей Excel." % (len(sheets), len(pairs), "паре" if len(pairs) == 1 else "парах",
                                 "; ".join(p["label"] for p in pairs)))


def _sheet_order(report_pairs):
    """Строки сводки по листам в порядке альбома: [(лист, наименование,
    [лист в каждой паре или None])].

    Строка — один и тот же чертёж во всех редакциях. Когда в альбом
    вставили листы, номер «лист 15» в изм. 1 и в изм. 2 — разные чертежи
    (в ВК план «+154,320» стал листом 18), и строка по номеру смешала бы
    их. Номер ведётся по moves пар до последней редакции; лист, исключённый
    в какой-то редакции, — отдельной строкой с номером по прежней
    нумерации."""
    count = len(report_pairs)

    def follow(start, label):
        for later in range(start + 1, count):
            moves = report_pairs[later]["moves"]
            if label in moves:
                if moves[label] is None:
                    return ("removed", later, label)
                label = moves[label]
        return ("sheet", label)

    rows = {}
    for index, pair in enumerate(report_pairs):
        entries = [(follow(index, label), sheet) for label, sheet in pair["by_label"].items()]
        entries += [(("removed", index, label), sheet)
                    for label, sheet in pair.get("removed", {}).items()]
        for key, sheet in entries:
            row = rows.setdefault(key, {"cells": [None] * count, "title": "", "was": ""})
            row["cells"][index] = sheet
            if sheet.get("title"):
                row["title"] = sheet["title"]
            if (sheet.get("how") or "").startswith("был лист "):
                row["was"] = sheet["how"]
    out = []
    for key, row in rows.items():
        if key[0] == "sheet":
            label = key[1] + (" (%s)" % row["was"] if row["was"] else "")
        else:
            label = "%s (нумерация %s)" % (key[2], report_pairs[key[1]]["old_edition"])
        out.append((label, row["title"], row["cells"]))
    out.sort(key=lambda item: _natural_key(item[0]))
    return out


def main():
    parser = argparse.ArgumentParser(description="Сравнение ревизий РД по вентиляции")
    parser.add_argument("pdfs", nargs="+", help="PDF-файлы ревизий по порядку (старая → новая → …)")
    parser.add_argument("-o", "--output", default=None,
                        help="путь к итоговому PDF-отчёту (не нужен при --mode spec)")
    parser.add_argument("--mode", default=MODE_FULL, choices=list(MODES),
                        help="что считать: full — чертежи и спецификация, "
                             "graphics — только чертежи, spec — только спецификация")
    parser.add_argument("--spec-xlsx", default=None,
                        help="путь к Excel-отчёту сравнения спецификаций (.xlsx)")
    parser.add_argument("--nz", nargs="*", default=[],
                        help="наряды-заказы (PDF): их материалы идут в отчёт "
                             "отдельными колонками рядом с редакциями")
    parser.add_argument("--section", default=None,
                         help="раздел проекта (ОВ, ВК, ЭОМ, СС) — по нему "
                              "подбирается промт и эталон отчёта для агента")
    parser.add_argument("--tmp-dir", default=None, help="папка для временных файлов (по умолчанию — своя, временная)")
    parser.add_argument("--tolerance", type=float, default=DEFAULT_TOLERANCE_PT,
                         help="не используется: оставлен для совместимости запуска")
    parser.add_argument("--narrative", default=None, choices=list(NARRATIVE_PROVIDERS),
                         help="подключить модель: разбор изменённых листов, ключевые "
                              "изменения и сверка с разрешениями (claude — Anthropic API, "
                              "так работает Verrata на сайте)")
    parser.add_argument("--narrative-credentials", default=None,
                         help="путь к JSON с ключом Anthropic и адресом прокси "
                              "(по умолчанию — путь из common/anthropic_client.py); "
                              "сам ключ аргументом командной строки не передаётся никогда")
    args = parser.parse_args()

    if args.tmp_dir:
        os.makedirs(args.tmp_dir, exist_ok=True)

    try:
        compare_files(args.pdfs, args.output, tmp_dir=args.tmp_dir, tolerance=args.tolerance,
                  section=args.section,
                      spec_xlsx=args.spec_xlsx, mode=args.mode,
                      nz_paths=args.nz,
                      narrative=args.narrative,
                      narrative_credentials=args.narrative_credentials)
    except RevisionError as exc:
        # Ошибка имён — это сообщение инженеру, а не сбой программы:
        # печатаем текст как есть, без трассировки.
        print(str(exc), file=sys.stderr)
        raise SystemExit(2)


if __name__ == "__main__":
    main()
