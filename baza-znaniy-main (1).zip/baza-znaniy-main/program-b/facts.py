# -*- coding: utf-8 -*-
"""
Сборка структурированного пакета ФАКТОВ отчёта сравнения ревизий — в
JSON-совместимом виде, без каких-либо оценок или интерпретаций.

Ничего не считает заново: берёт уже готовые результаты extract_stamp
(stamp.py), diff_elements (diff_engine.py), diff_spec_rows (spec_diff.py)
и build_change_items/cluster_changes/cluster_caption (report.py — те же
кластеры и подписи, что идут в карточки "было/стало" отчёта), и
раскладывает их в компактный словарь.

Этот пакет — и только он — передаётся в Claude (narrative.py):
сырые PDF/картинки туда не идут, чтобы риск галлюцинации сместился с
"что произошло" (это уже посчитано детерминированным кодом) на "как
это описать словами" — см. согласованную с заказчиком архитектуру.
"""
import os

from report import build_change_items, cluster_changes, cluster_caption

# Верхняя граница находок на лист внутри пакета фактов — не для
# отображения человеку (в самом PDF-отчёте показываются все находки),
# а чтобы не раздувать промпт модели садовым числом мелких находок на
# перегруженном чертеже: сути резюме это не меняет, а токены бережёт.
_MAX_FINDINGS_PER_SHEET = 12


def sheet_label(key):
    marka, sheet_no = key
    return f"{marka} — лист {sheet_no}"


def sheet_facts(key, status, diff=None, stamp_new=None):
    """key — (marka, sheet_no). status — "changed"/"unchanged"/
    "only_old"/"only_new". diff — результат diff_elements (только для
    listed-в-обеих-версиях листов, иначе None). stamp_new — результат
    extract_stamp(...) новой версии листа (для штатной таблицы
    изменений штампа), может быть None (лист есть только в старой
    версии)."""
    marka, sheet_no = key
    fact = {
        "marka": marka,
        "sheet_no": sheet_no,
        "label": sheet_label(key),
        "status": status,
        "stamp_change_log": list((stamp_new or {}).get("change_log") or []),
    }
    if diff is None:
        return fact

    t, p = diff["texts"], diff["paths"]
    items = build_change_items(diff)
    fact["counts"] = {
        "route_added": sum(1 for i in items
                            if i["kind"] == "path_added" and i["shape"] == "route"),
        "route_removed": sum(1 for i in items
                              if i["kind"] == "path_removed" and i["shape"] == "route"),
        "unit_added": sum(1 for i in items
                           if i["kind"] == "path_added" and i["shape"] == "unit"),
        "unit_removed": sum(1 for i in items
                             if i["kind"] == "path_removed" and i["shape"] == "unit"),
        # Текстовые расхождения в отчёт не идут (см.
        # report.build_change_items) — число приводим только затем,
        # чтобы модель не выдавала за изменение чертежа то, чего в
        # находках нет.
        "text_differences_excluded": len(t["added"]) + len(t["removed"]) + len(t["changed"]),
    }

    clusters = cluster_changes(items)
    findings = []
    for cluster in clusters[:_MAX_FINDINGS_PER_SHEET]:
        caption, before_text, after_text = cluster_caption(cluster)
        findings.append({"summary": caption, "before": before_text, "after": after_text})
    fact["findings"] = findings
    fact["findings_truncated"] = len(clusters) > _MAX_FINDINGS_PER_SHEET
    return fact


def spec_facts(spec_diff):
    """spec_diff — результат diff_spec_rows(...)."""
    return {
        "added": [
            {"name": r["name"], "type": r["type"], "unit": r["unit"], "qty": r["qty"]}
            for r in spec_diff["added"]
        ],
        "removed": [
            {"name": r["name"], "type": r["type"], "unit": r["unit"], "qty": r["qty"]}
            for r in spec_diff["removed"]
        ],
        "qty_changed": [
            {"name": o["name"], "type": o["type"], "unit": o["unit"], "qty_old": o["qty"], "qty_new": n["qty"]}
            for o, n in spec_diff["qty_changed"]
        ],
    }


def build_pair_facts(old_path, new_path, sheets, spec, assumptions=(),
                     verification=()):
    """Итоговый пакет фактов для одной пары ревизий (old_path -> new_path).

    sheets — список словарей sheet_facts(...) в порядке общий/только-
    старые/только-новые (как их собирает compare.compare_pair). spec —
    результат spec_facts(...) (может быть None, если в файлах нет
    листов спецификации).

    verification — вердикт приёмочного гейта по каждому файлу пары (см.
    verify_so.gate_verdict). Без него резюме пишется так, будто разбор
    сведён с листами, и фраза «количество выросло на 27» читается как
    факт, даже когда числа не сошлись.

    assumptions — решения, принятые разбором за инженера: основание
    хронологии, выброшенные служебные строки, принятые единицы. Они идут в
    пакет наравне с числами, потому что резюме обязано их называть: вывод
    "количество выросло на 27" без оговорки "строка разобрана с допущением"
    читается как факт, которым он не является."""
    changed = [s for s in sheets if s["status"] == "changed"]
    unchanged = [s for s in sheets if s["status"] == "unchanged"]
    only_old = [s for s in sheets if s["status"] == "only_old"]
    only_new = [s for s in sheets if s["status"] == "only_new"]
    spec = spec or {"added": [], "removed": [], "qty_changed": []}

    return {
        "old_file": os.path.basename(old_path),
        "new_file": os.path.basename(new_path),
        "verification": list(verification),
        "assumptions": list(assumptions),
        "sheets": sheets,
        "spec": spec,
        "totals": {
            "sheets_total": len(sheets),
            "sheets_changed": len(changed),
            "sheets_unchanged": len(unchanged),
            "sheets_only_old": len(only_old),
            "sheets_only_new": len(only_new),
            "spec_added": len(spec["added"]),
            "spec_removed": len(spec["removed"]),
            "spec_qty_changed": len(spec["qty_changed"]),
        },
    }
