# -*- coding: utf-8 -*-
"""
Сборка итогового PDF-отчёта сравнения ревизий РД.

Раньше подсветка рисовалась поверх всего листа целиком — при плотном
чертеже с десятками отметок на листе это превращалось в "цветную кашу"
(отзыв заказчика). Вместо этого теперь: для каждой находки — маленькая
"было/стало" карточка (вырезка старой и новой версии рядом, только
вокруг места изменения) с подписью, что именно изменилось. Плюс сводная
таблица по всем находкам графической части.

Близкие друг к другу находки на одном листе объединяются в одну
карточку (см. cluster_changes) — иначе десяток близких мелких правок
дал бы десяток мельчайших вырезок вместо одной читаемой.
"""
import os
import re
from collections import defaultdict

import fitz

from diff_engine import old_offset_at

_COLOR_ADDED = (0.05, 0.55, 0.05)
_COLOR_REMOVED = (0.75, 0.05, 0.05)
_COLOR_CHANGED = (0.85, 0.55, 0.0)
# Рамка зоны на вырезке — оранжевая, как в эталонном отчёте: она
# ограничивает место правки, а что именно изменилось, показывает
# подложка по пикселям (см. _change_masks).
_ZONE_FRAME_COLOR = (0.95, 0.55, 0.05)
# Отступ рамки зоны наружу от самой правки: рамка должна стоять ВОЗЛЕ
# изменения, а не поверх него.
_HIGHLIGHT_PAD = 5.0

# Встроенные в PyMuPDF базовые PDF-шрифты ("helv"/"hebo") — это Base-14
# Helvetica без кириллицы: русский текст на них просто не отрисовывается
# (молча, без ошибки). Поэтому текст отчёта — на своём шрифте с полной
# поддержкой кириллицы, а не на builtin. Файлы шрифта лежат рядом в
# репозитории (program-b/fonts/), а не берутся из системных путей — на
# сервере хостинга их может не быть.
_FONTS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "fonts")
_FONT = "revdiff-regular"
_FONT_BOLD = "revdiff-bold"
_FONT_FILE = os.path.join(_FONTS_DIR, "DejaVuSans.ttf")
_FONT_BOLD_FILE = os.path.join(_FONTS_DIR, "DejaVuSans-Bold.ttf")
_FONT_OBJ = fitz.Font(fontfile=_FONT_FILE)
_FONT_BOLD_OBJ = fitz.Font(fontfile=_FONT_BOLD_FILE)

# Плашка над каждым блоком чернового текста: любой текст, полученный от
# языковой модели, попадает в отчёт только помеченным как черновик (см.
# narrative.py) — инженер подписывает пояснительную записку, а не модель.
_DRAFT_BANNER_TEXT = ("ЧЕРНОВИК: текст ниже составлен языковой моделью по уже "
                      "посчитанным фактам и требует проверки инженером.")
_DRAFT_COLOR = (0.55, 0.30, 0.0)
_DRAFT_FILL = (1.0, 0.96, 0.87)

_CLUSTER_RADIUS = 150.0
_CROP_MARGIN = 40.0
_CARD_IMG_WIDTH = 380.0
_CARD_IMG_MAX_HEIGHT = 190.0


# --------------------------------------------------------------------------
# Плоский список находок из diff_engine.diff_elements(...) + группировка
# --------------------------------------------------------------------------

def _pad(bbox, pad=_HIGHLIGHT_PAD):
    return (bbox[0] - pad, bbox[1] - pad, bbox[2] + pad, bbox[3] + pad)


# Классификация геометрической находки по форме её bbox.
#
# "Трассировка" — вытянутый путь: воздуховод, трубопровод, ось, выноска.
# "Оборудование/узел" — компактный: условное обозначение аппарата,
# решётки, клапана, рамка узла. Пороги подобраны по замеру на реальной
# паре ОВ2 (740 геометрических находок на десяти листах: медианная длина
# пути 45.7 pt, медианная толщина 10 pt).
#
# Деление приблизительное и честно называется в отчёте «по форме»: по
# одному bbox нельзя отличить условное обозначение вентилятора от куска
# короба наверняка. Инженеру оно нужно не как классификация, а как
# подсказка, куда смотреть на карточке.
_ROUTE_MIN_LENGTH_PT = 30.0
_ROUTE_MAX_THICKNESS_PT = 6.0
_ROUTE_MIN_RATIO = 6.0


def classify_path(bbox):
    """"route" (трассировка) или "unit" (оборудование/узел)."""
    length = max(bbox[2] - bbox[0], bbox[3] - bbox[1])
    thickness = max(min(bbox[2] - bbox[0], bbox[3] - bbox[1]), 0.01)
    if length >= _ROUTE_MIN_LENGTH_PT and (thickness <= _ROUTE_MAX_THICKNESS_PT
                                            or length / thickness >= _ROUTE_MIN_RATIO):
        return "route"
    return "unit"


def build_change_items(diff):
    """Приводит diff к плоскому списку находок с единой структурой —
    bbox всегда в системе координат НОВОЙ версии листа (для удалённых
    элементов — старый bbox, перенесённый по найденному сдвигу), чтобы
    группировать/раскладывать по площади листа однородно.

    В отчёт идёт ТОЛЬКО геометрия — трассировка и оборудование
    (требование заказчика). Изменения текстовых подписей сюда не
    попадают: экспортёр PDF режет строку на фрагменты по-разному от
    редакции к редакции, и отчёт забивался карточками вида
    «НЕвАВТОМАТИЧЕСКОМрежимедвигательПДлифта» → «НЕ в АВТОМАТИЧЕСКОМ
    режиме двигатель ПД лифта», где проект не менялся вовсе. Замер на
    паре ОВ2: 584 текстовые находки на десять листов против 740
    геометрических, и почти каждая карточка была смешанной.

    Текст при этом не выброшен: по совпадающим подписям считается сдвиг
    листа (diff_engine.estimate_offset), а соседние подписи подставляются
    в подпись карточки как привязка (см. attach_labels)."""
    items = []

    # Подоснова (светло-серый архитектурный план, см. geometry._is_light)
    # в находки не идёт: её меняет архитектор, а отчёт — про трассировку и
    # оборудование. На ВК 89_21 подоснова в изм. 2 перерисована целиком,
    # и без этого правила план выходил сплошной зоной изменений.
    for p in diff["paths"]["added"]:
        if p.get("light"):
            continue
        items.append({"kind": "path_added", "new_bbox": p["bbox"], "old_bbox": None,
                       "shape": classify_path(p["bbox"])})
    for p in diff["paths"]["removed"]:
        if p.get("light"):
            continue
        dx, dy = old_offset_at(diff, p["bbox"])
        moved = (p["bbox"][0] + dx, p["bbox"][1] + dy, p["bbox"][2] + dx, p["bbox"][3] + dy)
        items.append({"kind": "path_removed", "new_bbox": moved, "old_bbox": p["bbox"],
                       "shape": classify_path(p["bbox"])})

    return items


_CLUSTER_MAX_SIZE = 420.0


def cluster_changes(items, radius=_CLUSTER_RADIUS, max_size=_CLUSTER_MAX_SIZE):
    """Группирует находки одного листа по близости (new_bbox) — жадно,
    без претензии на оптимальность, этого достаточно для сборки читаемых
    карточек "было/стало" вместо одной подсветки на весь чертёж.

    max_size — обязательный потолок на размер получившегося кластера:
    без него "рядом с рядом" по цепочке из близко идущих находок
    стягивает в один кластер весь лист целиком (проверено на реальном
    файле — один кластер вобрал 174 находки почти на всю страницу),
    что воспроизводит ту же "цветную кашу", только в виде одной большой
    вырезки вместо подсветки на полном листе."""
    clusters = []
    for it in items:
        nb = it["new_bbox"]
        cx = (nb[0] + nb[2]) / 2.0
        cy = (nb[1] + nb[3]) / 2.0
        placed = None
        for c in clusters:
            bx0, by0, bx1, by1 = c["bbox"]
            near = bx0 - radius <= cx <= bx1 + radius and by0 - radius <= cy <= by1 + radius
            if not near:
                continue
            merged_w = max(bx1, nb[2]) - min(bx0, nb[0])
            merged_h = max(by1, nb[3]) - min(by0, nb[1])
            if merged_w > max_size or merged_h > max_size:
                continue
            placed = c
            break
        if placed is None:
            clusters.append({"items": [it], "bbox": list(nb)})
        else:
            placed["items"].append(it)
            b = placed["bbox"]
            placed["bbox"] = [min(b[0], nb[0]), min(b[1], nb[1]), max(b[2], nb[2]), max(b[3], nb[3])]
    return clusters


# --------------------------------------------------------------------------
# Категории находок и описание «было → стало»
#
# Взято из эталонного отчёта заказчика (пакет rdgraph, zones.py): каждая
# зона изменения пронумерована, отнесена к категории и описана словами —
# «Надписи: было «Пр. Dn150» → стало «Пр. Dn250»», «Размеры/отметки:
# +155,623 → +155,766». Инженер по такому описанию понимает правку, не
# раскрывая картинку.
#
# Разница с эталоном: там сравнение растровое, и одинаковый текст с
# разной нарезкой на фрагменты даёт одинаковые пиксели. У нас сравнение
# векторное, поэтому текст НЕ создаёт находку сам по себе — он только
# описывает зону, найденную по геометрии (требование заказчика: «не
# нужно брать текстовые изменения»).
# --------------------------------------------------------------------------

CATEGORY_NETWORKS = "Сети"
CATEGORY_MARKS = "Маркировка сетей"
CATEGORY_DIMENSIONS = "Размеры"
CATEGORY_BASE = "Подоснова/графика"
# Лист, не совпадающий с прошлой редакцией большей частью: перекомпонован
# или перевыгружен (см. compare._REWORKED_SHARE).
CATEGORY_REWORKED = "Лист переработан"

CATEGORY_HINTS = {
    CATEGORY_NETWORKS: "трубопроводы/воздуховоды и элементы сетей (цветная графика)",
    CATEGORY_MARKS: "марки стояков и систем, диаметры, выноски",
    CATEGORY_DIMENSIONS: "размеры, привязки, отметки",
    CATEGORY_BASE: "линии, условные обозначения, подоснова",
}

# Число/отметка: «+6,051», «155.470», «2)».
_NUMERIC_RE = re.compile(r"^[+\-]?\d+(?:[.,]\d+)*\)?[.,;]?$")
# Марка сети или её диаметр: стояки и системы (К1, В1.10, Вж2.19, ДВ2.2),
# диаметры (∅150, Dn100, Ду50, ф100), приставки стояков и выпусков.
_NET_RE = re.compile(
    r"(?:^|\s)(?:Ст\.|Оп\.|Пр\.|Под\.|Вып\.)|[∅⌀Øø]|\bD[nN]?\s*\d|\bДу\s*\d|\bф\d"
    r"|^[А-ЯA-Z]{1,3}[жЖ]?\d+(?:[.\-]\d+)*$",
    re.IGNORECASE)

# Сколько изменившихся подписей показывать в описании зоны: длинный
# список в подписи под карточкой нечитаем, а в сводной таблице он
# обрезается по ширине колонки.
_DESCRIBED_TEXTS = 4
# Насколько далеко от зоны подпись ещё считается относящейся к ней.
_TEXT_ATTACH_PT = 30.0


def _is_numeric(text):
    return bool(_NUMERIC_RE.match(text.strip()))


def _is_net_mark(text):
    return bool(_NET_RE.search(text.strip()))


def _text_entries(diff):
    """Изменившиеся подписи листа в координатах НОВОЙ версии:
    [(вид, bbox_новый, bbox_старый, текст_до, текст_после)]."""
    entries = []
    for span in diff["texts"]["added"]:
        entries.append(("text_added", span["bbox"], None,
                         " ".join(span["text"].split()), None))
    for span in diff["texts"]["removed"]:
        b = span["bbox"]
        dx, dy = old_offset_at(diff, b)
        entries.append(("text_removed", (b[0] + dx, b[1] + dy, b[2] + dx, b[3] + dy),
                         b, " ".join(span["text"].split()), None))
    for old_span, new_span in diff["texts"]["changed"]:
        entries.append(("text_changed", new_span["bbox"], old_span["bbox"],
                         " ".join(old_span["text"].split()),
                         " ".join(new_span["text"].split())))
    return [e for e in entries if e[3] or e[4]]


def _record_text(cluster, kind, before, after):
    changes = cluster.setdefault("text_changes", {"added": [], "removed": [], "changed": []})
    if kind == "text_changed":
        changes["changed"].append((before, after))
    elif kind == "text_added":
        changes["added"].append(before)
    else:
        changes["removed"].append(before)


# Доля изменившихся подписей, выше которой тексту листа верить нельзя.
# На табличном листе (спецификация оборудования, ведомость) удаление
# одной строки сдвигает все строки ниже, и построчное сравнение видит
# изменение в каждой: «2.25 → 2.22», «ГОСТ 14918-2020 → Дефлектор D100».
# Это не правки проекта, а сдвиг таблицы. Содержание таких листов и так
# сверяется отдельно и построчно — в книге спецификации.
_TEXT_NOISE_SHARE = 0.25


def text_is_reliable(diff, share=_TEXT_NOISE_SHARE):
    """Можно ли описывать зоны словами по тексту этого листа."""
    texts = diff["texts"]
    changed = len(texts["added"]) + len(texts["removed"]) + len(texts["changed"])
    total = changed + len(texts.get("unchanged") or ())
    if total <= 0:
        return True
    return changed <= share * total


def attach_text_changes(clusters, diff, max_dist=_TEXT_ATTACH_PT):
    """Раскладывает изменившиеся подписи по зонам изменения геометрии.

    Возвращает подписи, которым зоны не нашлось: рядом с ними геометрия
    не менялась. Сами по себе такие подписи находкой не становятся — что
    из них всё-таки идёт в отчёт, решает text_only_clusters."""
    for c in clusters:
        c.setdefault("text_changes", {"added": [], "removed": [], "changed": []})

    leftovers = []
    for entry in _text_entries(diff):
        kind, bbox, _old_bbox, before, after = entry
        best, best_d = None, None
        for c in clusters:
            d = _rect_gap(c["bbox"], bbox)
            if d <= max_dist and (best_d is None or d < best_d):
                best, best_d = c, d
        if best is None:
            leftovers.append(entry)
        else:
            _record_text(best, kind, before, after)
    return leftovers


def _worth_reporting(before, after):
    """Стоит ли показывать изменение подписи, рядом с которой геометрия
    не менялась.

    Берём только марки сетей и числа — диаметры, отметки, размеры:
    «Дефлектор D125» → «Дефлектор D100», «Пр. Dn150» → «Пр. Dn250»,
    «+6,016» → «+6,020». Это значения, которые инженер проверяет, и
    именно они показаны в эталонном отчёте.

    Прозаические надписи (примечания, названия узлов) не берём: в них
    настоящих правок почти не бывает, зато там живёт мусор от нарезки
    строки экспортёром PDF, на который и жаловался заказчик."""
    for text in (before, after):
        if text and (_is_net_mark(text) or _is_numeric(text)):
            return True
    return False


def text_only_clusters(leftovers, radius=_CLUSTER_RADIUS):
    """Зоны из одних подписей — для марок и размеров, см.
    _worth_reporting. Геометрия в таких зонах не менялась, поэтому
    находками в счёте трассировки и оборудования они не становятся."""
    items = []
    for kind, bbox, old_bbox, before, after in leftovers:
        if not _worth_reporting(before, after):
            continue
        items.append({"kind": kind, "new_bbox": bbox,
                       "old_bbox": old_bbox if kind != "text_added" else None,
                       "before": before, "after": after})
    clusters = cluster_changes(items, radius=radius)
    for c in clusters:
        for item in c["items"]:
            _record_text(c, item["kind"], item["before"], item["after"])
    return clusters


def cluster_category(cluster):
    """Категория зоны — тем же словарём, что в эталонном отчёте."""
    changes = cluster.get("text_changes") or {}
    words = list(changes.get("added") or []) + list(changes.get("removed") or [])
    for before, after in changes.get("changed") or []:
        words += [before, after]

    if any(_is_net_mark(w) for w in words):
        return CATEGORY_MARKS

    paths = [i for i in cluster["items"] if i["kind"].startswith("path")]
    colored = sum(1 for i in paths if i.get("colored"))
    if paths and colored >= 0.25 * len(paths):
        return CATEGORY_NETWORKS

    if words and all(_is_numeric(w) for w in words) and len(paths) <= 3:
        return CATEGORY_DIMENSIONS
    return CATEGORY_BASE


def number_zones(clusters):
    """Сквозные номера зон на листе — сверху вниз, слева направо, как в
    эталонном отчёте (полосами по высоте, иначе соседние по вертикали
    зоны нумеруются вперемешку)."""
    ordered = sorted(clusters, key=lambda c: (int(c["bbox"][1] // 300), c["bbox"][0]))
    for i, c in enumerate(ordered, 1):
        c["zone"] = i
    return clusters


def _short_list(values, limit=_DESCRIBED_TEXTS):
    shown = ", ".join(values[:limit])
    return shown + (" …" if len(values) > limit else "")


def _text_sentences(cluster):
    """Описание изменившихся подписей зоны: отдельно числа (размеры и
    отметки) и отдельно остальные надписи — как в эталоне."""
    changes = cluster.get("text_changes") or {}
    added = list(changes.get("added") or [])
    removed = list(changes.get("removed") or [])
    changed = list(changes.get("changed") or [])

    nums_add = [w for w in added if _is_numeric(w)]
    nums_rm = [w for w in removed if _is_numeric(w)]
    nums_ch = [(a, b) for a, b in changed if _is_numeric(a) or _is_numeric(b)]
    text_add = [w for w in added if not _is_numeric(w)]
    text_rm = [w for w in removed if not _is_numeric(w)]
    text_ch = [(a, b) for a, b in changed if not (_is_numeric(a) or _is_numeric(b))]

    out = []
    if nums_ch:
        out.append("Размеры/отметки: " + _short_list(
            ["%s → %s" % (a, b) for a, b in nums_ch]))
    if nums_add:
        out.append("Добавлены размеры/отметки: " + _short_list(nums_add))
    if nums_rm:
        out.append("Удалены размеры/отметки: " + _short_list(nums_rm))
    if text_ch:
        out.append("Надписи: " + _short_list(
            ["было «%s» → стало «%s»" % (a, b) for a, b in text_ch]))
    if text_add:
        out.append("Добавлены надписи: " + _short_list(["«%s»" % w for w in text_add]))
    if text_rm:
        out.append("Удалены надписи: " + _short_list(["«%s»" % w for w in text_rm]))
    return out


# Привязка находки к чертежу: ближайшие НЕИЗМЕНИВШИЕСЯ подписи рядом с
# местом правки. Сами подписи в находки не идут (см. build_change_items),
# но без них «перечерчено здесь» нечем привязать к системе: инженеру
# нужно «рядом с В1.10», а не координаты в пунктах.
_LABEL_MAX_DIST_PT = 70.0
_LABEL_MAX_LEN = 28
_LABELS_PER_CLUSTER = 3
# Потолок на перебор "каждый кластер против каждой подписи": на листе с
# тысячами подписей и сотней кластеров это сотни тысяч сравнений на лист,
# а процессорное время на хостинге ограничено. Выше потолка привязку
# получают только кластеры, которые пойдут на карточки.
_LABEL_BUDGET = 400000


def _rect_gap(a, b):
    """Расстояние между прямоугольниками (0, если пересекаются)."""
    dx = max(a[0] - b[2], b[0] - a[2], 0.0)
    dy = max(a[1] - b[3], b[1] - a[3], 0.0)
    return (dx * dx + dy * dy) ** 0.5


def label_candidates(lines):
    """Подписи-привязки из строк листа (geometry.extract_elements(...)
    ["lines"]), а не из отдельных фрагментов: экспортёр режет «ДВ 2.2» на
    «ДВ» и «2.2», и привязка выходила обрывками вроде «2 .1» и «) 28»."""
    out = []
    for line in lines or ():
        text = "".join(s["text"] for s in line.get("spans", ())).strip()
        if len(text) < 2 or len(text) > _LABEL_MAX_LEN:
            continue
        if not any(ch.isalnum() for ch in text):
            continue
        out.append({"text": text, "bbox": line["bbox"]})
    return out


def attach_labels(clusters, texts, max_dist=_LABEL_MAX_DIST_PT):
    """Проставляет каждому кластеру cluster["labels"] — до трёх ближайших
    подписей новой версии листа (см. label_candidates)."""
    if not texts:
        for c in clusters:
            c.setdefault("labels", [])
        return clusters
    short = [t for t in texts if t.get("text") and 2 <= len(t["text"].strip()) <= _LABEL_MAX_LEN]
    for c in clusters:
        near = []
        for t in short:
            d = _rect_gap(c["bbox"], t["bbox"])
            if d <= max_dist:
                text = t["text"].strip()
                near.append((d, text, any(ch.isalpha() for ch in text)))
        # Марка системы («Вж2.12») привязывает находку к проекту, размер
        # («820») — почти нет, а на чертеже размеров больше. Поэтому
        # сначала подписи с буквами, и уже между ними — по близости.
        near.sort(key=lambda pair: (not pair[2], pair[0]))
        labels, seen = [], set()
        for _d, text, _has_letters in near:
            if text in seen:
                continue
            seen.add(text)
            labels.append(text)
            if len(labels) >= _LABELS_PER_CLUSTER:
                break
        c["labels"] = labels
    return clusters


def label_budget_allows(clusters, texts):
    """Хватит ли бюджета на привязку всех кластеров листа (иначе её
    получат только те, что идут на карточки)."""
    return len(clusters) * max(len(texts), 1) <= _LABEL_BUDGET


def _counts(cluster):
    route_add = route_rm = unit_add = unit_rm = 0
    for it in cluster["items"]:
        shape = it.get("shape") or classify_path(it["new_bbox"])
        if it["kind"] == "path_added":
            if shape == "route":
                route_add += 1
            else:
                unit_add += 1
        elif it["kind"] == "path_removed":
            if shape == "route":
                route_rm += 1
            else:
                unit_rm += 1
    return route_add, route_rm, unit_add, unit_rm


def _labels_suffix(cluster):
    labels = cluster.get("labels") or []
    if not labels:
        return ""
    return " Рядом: " + ", ".join("«%s»" % s for s in labels) + "."


def cluster_caption(cluster):
    """Подпись под карточкой и две ячейки сводной таблицы (было/стало).

    Формат — как в эталонном отчёте заказчика: «Зона N · Категория —
    что изменилось». Про чертёж говорится на языке чертежа (трассировка
    и оборудование), а изменившиеся рядом подписи и отметки названы
    поимённо: «было «Пр. Dn150» → стало «Пр. Dn250»»."""
    if cluster.get("raster"):
        return _raster_caption(cluster)
    route_add, route_rm, unit_add, unit_rm = _counts(cluster)

    parts = []
    if route_add or route_rm:
        bits = []
        if route_add:
            bits.append("добавлено %d" % route_add)
        if route_rm:
            bits.append("удалено %d" % route_rm)
        parts.append("Трассировка: " + ", ".join(bits) + " лин.")
    if unit_add or unit_rm:
        bits = []
        if unit_add:
            bits.append("добавлено %d" % unit_add)
        if unit_rm:
            bits.append("удалено %d" % unit_rm)
        parts.append("Оборудование/узлы: " + ", ".join(bits) + " элем.")

    text_sentences = ["%s." % t.rstrip(".") for t in _text_sentences(cluster)]
    if parts:
        sentences = ["; ".join(parts).rstrip(".") + "."] + text_sentences
    elif text_sentences:
        # Зона из одних подписей: геометрия не менялась, и писать про неё
        # нечего — описание целиком про марки и размеры.
        sentences = text_sentences
    else:
        sentences = ["Изменение геометрии."]
    caption = _zone_prefix(cluster) + " ".join(sentences) + _labels_suffix(cluster)

    def _side(route_n, unit_n):
        bits = []
        if route_n:
            bits.append("трассировка %d лин." % route_n)
        if unit_n:
            bits.append("оборудование/узлы %d элем." % unit_n)
        return ", ".join(bits) if bits else "—"

    before_text = _side(route_rm, unit_rm)
    after_text = _side(route_add, unit_add)
    labels = cluster.get("labels") or []
    if labels:
        where = " (рядом: " + ", ".join(labels) + ")"
        if before_text != "—":
            before_text += where
        if after_text != "—":
            after_text += where
    return caption, before_text, after_text


def _raster_caption(cluster):
    """Подпись зоны, найденной сравнением по изображению (raster_diff):
    линию от надписи там не отличить, поэтому без подсчёта элементов."""
    removed = cluster["raster"].get("removed", 0)
    added = cluster["raster"].get("added", 0)
    if removed and added:
        what = "перечерчено: часть изображения удалена, часть добавлена"
    elif added:
        what = "добавлены линии или надписи"
    else:
        what = "удалены линии или надписи"
    sentence = ("Сравнение по изображению (лист слишком тяжёлый для разбора "
                "по элементам): %s." % what)
    caption = _zone_prefix(cluster) + sentence
    before_text = "удалено" if removed else "—"
    after_text = "добавлено" if added else "—"
    return caption, before_text, after_text


def _zone_prefix(cluster):
    zone = cluster.get("zone")
    if not zone:
        return ""
    return "Зона %d · %s — " % (zone, cluster_category(cluster))


def cluster_description(cluster):
    """Одна строка сводной таблицы: что изменилось в зоне, словами."""
    caption, _before, _after = cluster_caption(cluster)
    prefix = _zone_prefix(cluster)
    return caption[len(prefix):] if prefix and caption.startswith(prefix) else caption


# --------------------------------------------------------------------------
# Отрисовка страниц
# --------------------------------------------------------------------------

def _new_a4_page(report_doc, landscape=True):
    w, h = (841.89, 595.32) if landscape else (595.32, 841.89)
    page = report_doc.new_page(width=w, height=h)
    page.insert_font(fontname=_FONT, fontfile=_FONT_FILE)
    page.insert_font(fontname=_FONT_BOLD, fontfile=_FONT_BOLD_FILE)
    return page


def _truncate(text, max_width, font_obj, fontsize):
    """Обрезает текст с многоточием под ширину колонки — insert_text (в
    отличие от insert_textbox) сам не переносит и не обрезает строку."""
    text = str(text)
    if font_obj.text_length(text, fontsize=fontsize) <= max_width:
        return text
    ellipsis = "…"
    lo, hi = 0, len(text)
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if font_obj.text_length(text[:mid] + ellipsis, fontsize=fontsize) <= max_width:
            lo = mid
        else:
            hi = mid - 1
    return text[:lo] + ellipsis if lo < len(text) else text


def _wrap_lines(text, max_width, font_obj, fontsize, max_lines=3):
    words = str(text).split(" ")
    lines = []
    cur = ""
    for w in words:
        cand = (cur + " " + w).strip()
        if font_obj.text_length(cand, fontsize=fontsize) <= max_width or not cur:
            cur = cand
        else:
            lines.append(cur)
            cur = w
        if len(lines) >= max_lines - 1:
            break
    if cur:
        lines.append(cur)
    if len(lines) == max_lines and font_obj.text_length(lines[-1], fontsize=fontsize) > max_width:
        lines[-1] = _truncate(lines[-1], max_width, font_obj, fontsize)
    return lines[:max_lines]


def _draw_table(page, origin, col_widths, rows, header=True, fontsize=8.5, row_height=14.0):
    """Простая таблица — сетка линиями + текст по ячейкам через
    insert_text (не insert_textbox — на практике недодавала часть строк
    без ошибки при интенсивной построчной вставке в узкие колонки).
    rows[0] — заголовок, если header=True (рисуется жирным)."""
    x0, y0 = origin
    total_w = sum(col_widths)
    y = y0
    baseline_offset = row_height * 0.7

    for r_i, row in enumerate(rows):
        is_header = header and r_i == 0
        font_obj = _FONT_BOLD_OBJ if is_header else _FONT_OBJ
        fontname = _FONT_BOLD if is_header else _FONT
        x = x0
        for c_i, text in enumerate(row):
            w = col_widths[c_i]
            shown = _truncate(text, w - 4, font_obj, fontsize)
            page.insert_text((x + 2, y + baseline_offset), shown,
                              fontsize=fontsize, fontname=fontname)
            x += w
        y_line = y + row_height
        page.draw_line((x0, y_line), (x0 + total_w, y_line), color=(0.7, 0.7, 0.7), width=0.6)
        y = y_line
        if y > page.rect.height - 30:
            return y, r_i + 1
    return y, len(rows)


# --------------------------------------------------------------------------
# Первые страницы отчёта: паспорт комплекта, метод, обозначения, выводы
#
# Строение взято из эталонного отчёта заказчика: читающий сначала должен
# понять, ЧТО сравнивали, КАК сравнивали и ЧТО из этого следует, и лишь
# потом получить таблицы. Прежде отчёт начинался сразу с перечисления
# всех листов — «не просто огромная таблица с перечислениями» (отзыв).
# --------------------------------------------------------------------------

_METHOD_TEXT = (
    "Сравнивались попарно соседние редакции. Листы сопоставлены по марке и номеру "
    "в штампе; листы без штампа (приложения, схемы, таблицы) — по содержанию. "
    "Из сравнения исключены зоны штампа: его заполнение не является изменением "
    "чертежа, а запись об изменении показана отдельной колонкой.\n"
    "Сравнение векторное, по содержимому PDF, а не по картинке: из каждого листа "
    "берутся векторные пути (линии, условные обозначения) и текстовые подписи с "
    "координатами. Редакции выравниваются по совпадающим подписям (технический "
    "сдвиг листа между экспортами изменением не считается), после чего находятся "
    "добавленные и удалённые элементы. Объект, который только переместился в "
    "пределах листа, изменением не считается.\n"
    "Находка — зона изменения геометрии: трассировка (линии сетей, воздуховодов, "
    "трубопроводов) и оборудование/узлы. Изменившиеся рядом подписи описывают "
    "зону словами. Отдельной зоной подпись становится, только если это марка сети "
    "или число — диаметр, отметка, размер.\n"
    "Листы без чертежа — спецификация, общие данные, ведомости — зон не дают: "
    "их правки это строки таблиц и текст, а не трассировка и оборудование. "
    "Содержание спецификации сверяется построчно в книге Excel. Лист, слишком "
    "тяжёлый для разбора по элементам, сравнивается по изображению — его зоны "
    "так и подписаны."
)

_LEGEND_ROWS = [
    ["зелёная подложка", "добавлено: появилось в новой редакции (на правой вырезке)"],
    ["розовая подложка", "удалено: было в предыдущей редакции (на левой вырезке)"],
    ["оранжевая рамка", "граница зоны изменения; слева предыдущая редакция, справа новая"],
    ["", "подкрашивается только фон вокруг правки — линии и подписи чертежа видны"],
    ["Зона N", "номер зоны на листе, сверху вниз; тем же номером зона названа в таблице"],
]

_LEGEND_COLORS = {
    "зелёная подложка": _COLOR_ADDED,
    "розовая подложка": _COLOR_REMOVED,
    "оранжевая рамка": _ZONE_FRAME_COLOR,
}


def build_front_page(report_doc, marka, revision_rows, title=None):
    """Паспорт комплекта: что сравнивали, чем, и что значат цвета.

    revision_rows: [Редакция, Файл, Листов, Дата PDF, Разрешение (по
    штампам), Графа изм. в штампах]."""
    page = _new_a4_page(report_doc, landscape=True)
    margin = 30
    page.insert_text((margin, 42), title or "Сравнение графических частей рабочей документации",
                      fontsize=17, fontname=_FONT_BOLD)
    y = 64
    if marka:
        page.insert_text((margin, y), marka, fontsize=11, fontname=_FONT_BOLD)
        y += 18

    page.insert_text((margin, y + 8), "Редакции", fontsize=11, fontname=_FONT_BOLD)
    headers = ["Редакция", "Файл", "Листов", "Дата PDF", "Разрешение (по штампам)",
                "Графа изм. в штампах"]
    widths = [95, 215, 50, 75, 150, 190]
    y, _consumed = _draw_table(page, (margin, y + 14), widths, [headers] + revision_rows,
                               fontsize=8.5)

    y += 22
    page.insert_text((margin, y), "Метод", fontsize=11, fontname=_FONT_BOLD)
    y += 14
    for paragraph in _METHOD_TEXT.split("\n"):
        for line in _wrap_paragraph(paragraph, page.rect.width - 2 * margin, _FONT_OBJ, 8.5):
            page.insert_text((margin, y), line, fontsize=8.5, fontname=_FONT)
            y += 11
        y += 3

    y += 12
    page.insert_text((margin, y), "Обозначения на иллюстрациях", fontsize=11, fontname=_FONT_BOLD)
    y += 14
    for name, meaning in _LEGEND_ROWS:
        color = _LEGEND_COLORS.get(name)
        if color:
            page.draw_rect(fitz.Rect(margin, y - 7, margin + 8, y + 1),
                            color=color, fill=color, width=0.5)
        page.insert_text((margin + 14, y), name, fontsize=8.5, fontname=_FONT_BOLD)
        page.insert_text((margin + 90, y), meaning, fontsize=8.5, fontname=_FONT)
        y += 13


def build_key_findings(report_doc, findings):
    """«Ключевые выводы» — то, ради чего отчёт читают: что изменилось,
    что изменилось БЕЗ записи в штампе и что заявлено, но не найдено.

    findings: список строк (уже посчитанных, см. compare.key_findings)."""
    page = _new_a4_page(report_doc, landscape=True)
    margin = 30
    page.insert_text((margin, 42), "Ключевые выводы", fontsize=15, fontname=_FONT_BOLD)
    y = 66
    for text in findings:
        lines = _wrap_paragraph(text, page.rect.width - 2 * margin - 14, _FONT_OBJ, 9.5)
        if y + len(lines) * 13 > page.rect.height - margin:
            page = _new_a4_page(report_doc, landscape=True)
            y = 42
        page.insert_text((margin, y), "•", fontsize=9.5, fontname=_FONT_BOLD)
        for line in lines:
            page.insert_text((margin + 14, y), line, fontsize=9.5, fontname=_FONT)
            y += 13
        y += 6


def build_graphical_changes_table(report_doc, change_rows):
    """change_rows: [Лист, Зона, Категория, Что изменилось, Замечание] —
    по строке на зону изменения, для быстрого просмотра без раскрытия
    каждой картинки «было/стало». Колонки «Зона» и «Категория» — как в
    эталонном отчёте заказчика."""
    page = _new_a4_page(report_doc, landscape=True)
    page.insert_text((30, 38), "Сводная таблица изменений (графическая часть)",
                      fontsize=13, fontname=_FONT_BOLD)
    headers = ["Лист", "Зона", "Категория", "Что изменилось", "Замечание"]
    # Сумма ширин должна укладываться в лист: при 820 последняя колонка
    # уезжала за правый край страницы.
    col_widths = [175, 35, 115, 390, 65]
    rows = [headers] + change_rows
    y, consumed = _draw_table(page, (30, 55), col_widths, rows, fontsize=8, row_height=16.0)
    remaining = rows[consumed:]
    while remaining:
        page = _new_a4_page(report_doc, landscape=True)
        y, consumed = _draw_table(page, (30, 30), col_widths, [headers] + remaining,
                                   fontsize=8, row_height=16.0)
        remaining = remaining[consumed - 1:] if consumed > 1 else []


_ZONE_FRAME_WIDTH = 1.2
_ZONE_FRAME_PAD = 6.0


def _zone_frame(bbox, clip):
    """Рамка зоны в долях от вырезки: (x0, y0, x1, y1) от 0 до 1.
    None, если зона в эту вырезку не попала."""
    width = clip.width or 1.0
    height = clip.height or 1.0
    x0, y0, x1, y1 = _pad(bbox, _ZONE_FRAME_PAD)
    box = ((x0 - clip.x0) / width, (y0 - clip.y0) / height,
            (x1 - clip.x0) / width, (y1 - clip.y0) / height)
    if box[2] < 0 or box[0] > 1 or box[3] < 0 or box[1] > 1:
        return None
    return box


class SheetPair(object):
    """Пара сопоставленных листов, подготовленная к отрисовке карточек.

    Копии листов делаются один раз на пару и переиспользуются всеми
    карточками этой пары. Копия, а не исходный документ, — чтобы отрисовка
    гарантированно не трогала исходный PDF."""

    def __init__(self, old_doc, new_doc, old_page_idx, new_page_idx):
        self._old_scratch = fitz.open()
        self._old_scratch.insert_pdf(old_doc, from_page=old_page_idx, to_page=old_page_idx)
        self._new_scratch = fitz.open()
        self._new_scratch.insert_pdf(new_doc, from_page=new_page_idx, to_page=new_page_idx)
        self.old_page = self._old_scratch[0]
        self.new_page = self._new_scratch[0]
        self._lists = {}

    def pixmap(self, side, clip, dpi, colorspace):
        """Вырезка листа ("old"/"new"). Страница разбирается в список
        отрисовки один раз, а не на каждую вырезку: проверка зон рисует
        их десятками, и на листе в миллион элементов повторный разбор
        стоил бы секунд на каждую."""
        if side not in self._lists:
            page = self.old_page if side == "old" else self.new_page
            self._lists[side] = page.get_displaylist()
        zoom = dpi / 72.0
        return self._lists[side].get_pixmap(matrix=fitz.Matrix(zoom, zoom),
                                            colorspace=colorspace, alpha=False, clip=clip)

    def close(self):
        self._lists = {}
        self._old_scratch.close()
        self._new_scratch.close()

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()
        return False


# Минимальный размер вырезки: рендер области, от которой после обрезки по
# листу ничего не осталось, падает внутри MuPDF ("Invalid bandwriter
# header dimensions"), а не отдаёт пустую картинку.
_MIN_CROP_PT = 2.0

# Вырезка без подложки (нет numpy) рендерится в оттенках серого: чертёж
# и так почти монохромный. Объём здесь — вопрос не эстетики: отчёты
# хранятся три месяца на диске в 13 ГБ.
_CROP_COLORSPACE = fitz.csGRAY

# Формат вырезок — JPEG: подложка делает картинку цветной, а цветной PNG
# того же разрешения весит в 1.7 раза больше (замер на листе 12 ОВ2:
# 163 КБ против 97 КБ при 765 px). Качество 72 на чертеже визуально
# неотличимо, а в бюджет хранения отчёт укладывается: ~120 КБ на
# карточку, 60 карточек — около 7 МБ.
_CROP_JPEG_QUALITY = 68

# Подложка под местом правки. Подкрашивается ТОЛЬКО бумага — штрихи
# чертежа остаются нетронутыми (приём из присланной заказчиком
# реализации rdgraph, render._halo).
#
# Где именно красить, считается ПО ПИКСЕЛЯМ двух вырезок, а не по
# габаритам векторных путей. Габарит ломаной — это прямоугольник в
# пол-листа, и заливка по нему закрашивала область, в которой на самом
# деле поменялась одна линия: «очень большие обозначения красным, не
# понятно где именно производились изменения» (отзыв заказчика).
_WASH_REMOVED = (255, 190, 190)
_WASH_ADDED = (175, 235, 175)

# Пиксель считается штрихом, если темнее этого (как ink_gray в rdgraph).
_INK_MAX = 215
# Запасы задаются в ПУНКТАХ, а не в пикселях: вырезки рендерятся с
# разным dpi (он подбирается под размер вырезки), и фиксированный запас
# в пикселях на мелкой вырезке оказывался втрое шире, чем на крупной.
#
# _MATCH_PT — на сколько «размазать» штрих другой редакции, прежде чем
# вычитать: выравнивание идёт с точностью до доли пункта, и без запаса
# каждый контур светился бы по краю от субпиксельного сдвига и
# сглаживания. _HALO_PT — на сколько расширить найденную правку, чтобы
# подложка была заметна рядом со штрихом.
_MATCH_PT = 1.2
_HALO_PT = 2.5

try:  # numpy есть и на хостинге (common/semantic_matcher.py), но подложка
    import numpy as _np  # без него просто не рисуется — карточка остаётся
except ImportError:  # pragma: no cover - на хостинге numpy стоит
    _np = None


def _pix_array(pix):
    return _np.frombuffer(pix.samples, dtype=_np.uint8).reshape(
        pix.height, pix.width, pix.n)[:, :, :3].copy()


def _channel_min(arr):
    """Минимум по каналам цвета. Поканально, а не arr.min(axis=2): свёртка
    по последней оси на картинке в мегапиксели в разы медленнее."""
    return _np.minimum(_np.minimum(arr[:, :, 0], arr[:, :, 1]), arr[:, :, 2])


def _channel_spread(arr):
    """Разброс каналов: у цветного штриха большой, у серого — ноль."""
    high = _np.maximum(_np.maximum(arr[:, :, 0], arr[:, :, 1]), arr[:, :, 2])
    return high - _channel_min(arr)


def _dilate(mask, radius):
    """Расширение маски на radius пикселей, по осям раздельно: так это
    2*(2r+1) операций над массивом вместо (2r+1)²."""
    out = mask
    for axis in (0, 1):
        grown = out.copy()
        for step in range(1, radius + 1):
            head = tuple(slice(None, -step) if a == axis else slice(None) for a in (0, 1))
            tail = tuple(slice(step, None) if a == axis else slice(None) for a in (0, 1))
            grown[head] |= out[tail]
            grown[tail] |= out[head]
        out = grown
    return out


def _px(points, dpi, minimum=2):
    return max(minimum, int(round(points * dpi / 72.0)))


def _change_masks(old_arr, new_arr, dpi):
    """Маски «что исчезло» и «что появилось» по пикселям двух вырезок.

    Берётся минимум по каналам: цветная линия сети — такой же штрих, как
    чёрная. Прежде чем вычитать, штрихи другой редакции расширяются на
    несколько пикселей — иначе от субпиксельного сдвига светился бы
    каждый контур (тот же приём, что шумовой гейт в rdgraph)."""
    h = min(old_arr.shape[0], new_arr.shape[0])
    w = min(old_arr.shape[1], new_arr.shape[1])
    if h <= 0 or w <= 0:
        return None, None
    ink_old = _channel_min(old_arr[:h, :w]) < _INK_MAX
    ink_new = _channel_min(new_arr[:h, :w]) < _INK_MAX
    match = _px(_MATCH_PT, dpi)
    removed = ink_old & ~_dilate(ink_new, match)
    added = ink_new & ~_dilate(ink_old, match)
    return removed, added


def _apply_halo(arr, mask, color, dpi):
    """Подкрашивает фон вокруг правки, не трогая штрихи.

    «Не штрих» — всё, что светлее порога чернил: так подложка ложится и
    на сглаженный ореол вокруг линии, и правка видна, а сама линия
    остаётся как была."""
    if mask is None or not mask.any():
        return arr
    h, w = mask.shape
    window = arr[:h, :w]
    background = _channel_min(window) >= _INK_MAX
    window[_dilate(mask, _px(_HALO_PT, dpi)) & background] = color
    return arr


def _png(arr):
    out = fitz.Pixmap(fitz.csRGB, arr.shape[1], arr.shape[0], arr.tobytes(), False)
    try:
        data = out.tobytes("jpg", jpg_quality=_CROP_JPEG_QUALITY)
    except (TypeError, ValueError):  # старая сборка PyMuPDF без jpg_quality
        data = out.tobytes("png")
    return data


# Вырезка рендерится с ДВУКРАТНЫМ запасом к своему размеру на листе
# отчёта (картинка шириной ~380 pt -> ~760 px): на экране при
# увеличении и на бумаге мелкие выноски и номера на чертеже должны
# читаться. Прежние 260 px на ту же ширину давали меньше пикселя на
# пункт — заказчик справедливо написал «качество должно быть выше».
# Размер файла при этом держит оттенок серого, обрезка по месту правки
# (а не по листу) и потолок в 60 карточек на отчёт.
_TARGET_PX_WIDTH = 700.0
_MIN_DPI = 72.0
_MAX_DPI = 220.0


# Потолок на число карточек "было/стало" в отчёте на один лист. На
# реальном комплекте один лист давал до 216 кластеров (а лист целиком —
# под семьсот находок): отчёт на тысячи вырезок инженер не откроет, да и
# рисуется он дольше, чем живёт процесс на хостинге. Все находки
# остаются в сводной таблице текстом, картинками показываем только
# самые заметные — решение согласовано с заказчиком.
MAX_CARDS_PER_SHEET = 12

# Потолок на весь отчёт. Потолка на лист мало: комплект из полусотни
# изменённых листов давал 600 карточек и отчёт на 56 МБ, а при 20
# сравнениях в день и хранении три месяца это сотня гигабайт на диске в
# 13 ГБ. Бюджет делится между листами поровну, неизрасходованное
# достаётся следующим листам.
#
# Потолок пересчитан дважды: когда подняли качество вырезок (карточка
# стоит около 200 КБ против прежних 85) и когда к зонам по геометрии
# добавились зоны по маркам и размерам. Отчёт держится около 8,5 МБ —
# при хранении три месяца на диске в 13 ГБ это предел, за который
# выходить нельзя. Все находки до единой остаются в сводной таблице.
MAX_CARDS_PER_REPORT = 40


class CardBudget(object):
    """Сколько карточек ещё можно нарисовать в этом отчёте.

    Делит общий потолок сначала между парами ревизий, потом между
    листами пары — иначе первый же лист с сотней находок выбрал бы весь
    бюджет, и до остальных картинки бы не дошли. Лист, которому хватило
    меньше своей доли, оставляет остаток следующим."""

    def __init__(self, pairs=1, total=MAX_CARDS_PER_REPORT, per_sheet=MAX_CARDS_PER_SHEET):
        self.remaining = total
        self.per_sheet = per_sheet
        self.pairs_left = max(pairs, 1)
        self.pair_remaining = 0
        self.sheets_left = 0

    def open_pair(self, sheets):
        """Начало очередной пары ревизий: выделяем ей долю бюджета."""
        self.pair_remaining = self.remaining // max(self.pairs_left, 1)
        self.pairs_left = max(self.pairs_left - 1, 0)
        self.sheets_left = max(sheets, 0)

    def take(self):
        """Сколько карточек отдать очередному листу пары. Вызывается на
        каждом сопоставленном листе, в том числе не изменившемся: иначе
        доля неизменившихся листов пропадала бы впустую."""
        if self.sheets_left <= 0:
            return 0
        share = max(1, self.pair_remaining // self.sheets_left)
        self.sheets_left -= 1
        return max(min(self.per_sheet, share, self.pair_remaining, self.remaining), 0)

    def spend(self, count):
        self.remaining = max(self.remaining - count, 0)
        self.pair_remaining = max(self.pair_remaining - count, 0)


def cluster_weight(cluster):
    """Насколько находка заметна: сколько элементов затронуто и какую
    площадь листа занимает. Правка одной отметки и переделанный узел на
    полстраницы — разного веса, и в отчёт должен попасть второй."""
    bx0, by0, bx1, by1 = cluster["bbox"]
    area = max(bx1 - bx0, 1.0) * max(by1 - by0, 1.0)
    return (len(cluster["items"]), area)


def rank_clusters(clusters, limit=MAX_CARDS_PER_SHEET):
    """Кластеры под карточки — самые заметные первыми, не больше limit.
    Порядок на листе сохраняем исходный: читателю удобнее идти по листу
    сверху вниз, а не по убыванию веса."""
    if limit is None or len(clusters) <= limit:
        return list(clusters)
    chosen = sorted(clusters, key=cluster_weight, reverse=True)[:limit]
    chosen_ids = {id(c) for c in chosen}
    return [c for c in clusters if id(c) in chosen_ids]


# Во что вписывается вырезка на странице отчёта: картинка шириной
# _CARD_IMG_WIDTH и высотой не больше _CARD_IMG_MAX_HEIGHT. Вырезка
# другой пропорции заняла бы четверть этого места: правка вдоль стояка
# даёт узкий высокий прямоугольник, и карточка выходила шириной в палец
# на пустой странице. Поэтому вырезку расширяют до пропорций места —
# заодно в кадр попадает окружение правки, по которому её и опознают.
_CROP_MAX_ASPECT = _CARD_IMG_MAX_HEIGHT / _CARD_IMG_WIDTH
_CROP_MIN_ASPECT = 0.25


def _framed(clip):
    """Вырезка, растянутая до пропорций места на странице. Только
    расширяет — находка остаётся внутри."""
    width = max(clip.width, _MIN_CROP_PT)
    height = max(clip.height, _MIN_CROP_PT)
    if height > _CROP_MAX_ASPECT * width:
        width = height / _CROP_MAX_ASPECT
    elif height < _CROP_MIN_ASPECT * width:
        height = width * _CROP_MIN_ASPECT
    cx = (clip.x0 + clip.x1) / 2.0
    cy = (clip.y0 + clip.y1) / 2.0
    return fitz.Rect(cx - width / 2.0, cy - height / 2.0, cx + width / 2.0, cy + height / 2.0)


def _clamped_clip(clip, page_rect):
    """Вырезка, обрезанная по границам листа, или None, если от неё
    ничего не осталось. Находка у самого края листа даёт вырезку,
    частично выходящую за лист (к bbox добавляются поля), а при сдвиге
    между ревизиями за лист может уйти и вся вырезка целиком."""
    box = fitz.Rect(clip) & page_rect
    if box.is_empty or box.width < _MIN_CROP_PT or box.height < _MIN_CROP_PT:
        return None
    return box


# Проверка зоны по картинке (см. visible_change). Разрешение — чтобы
# линия в 0.25 мм была уже штрихом, а не серой дымкой: при 150 dpi чёрная
# линия толщиной 0.24 pt темнее 150, а светло-серая подоснова (0.7) —
# нет, и одно от другого отличается по яркости.
_VERIFY_DPI = 150
_VERIFY_PAD_PT = 4.0
_VERIFY_MIN_PX = 6
_SIGNIFICANT_DARK = 150
_SIGNIFICANT_SPREAD = 40


def _significant(arr):
    """Пиксели, которые несут трассировку и оборудование: тёмные или
    цветные. Светло-серая подоснова и сглаживание вокруг штрихов — нет."""
    return (_channel_min(arr) < _SIGNIFICANT_DARK) | (_channel_spread(arr) > _SIGNIFICANT_SPREAD)


# Сторона плитки, которой лист рисуется для проверки зон, pt. Одна
# отрисовка на плитку, а не на зону: на листе в 70 зон отдельные вырезки
# стоили 16 с одной только отрисовки — каждая проходит весь список
# отрисовки листа. Плитка в 1200 pt при 150 dpi — 2500 px, 19 МБ на
# редакцию.
_VERIFY_TILE_PT = 1200.0


def _tiles(boxes, tile):
    """Плитки сетки с шагом tile, которые задевают хотя бы один из boxes."""
    keys = set()
    for x0, y0, x1, y1 in boxes:
        for tx in range(int(x0 // tile), int(x1 // tile) + 1):
            for ty in range(int(y0 // tile), int(y1 // tile) + 1):
                keys.add((tx, ty))
    return sorted(keys)


def visible_changes(pair, zones, offsets):
    """Видно ли изменение каждой зоны на самом чертеже: список (исчезло,
    появилось) — число пикселей значимых штрихов, — либо None для зоны,
    которую проверить нечем. offsets — сдвиг старой редакции для каждой
    зоны (у сдвинутого фрагмента листа он свой).

    Нужна потому, что векторное сравнение видит не только правки. Лист,
    перевыгруженный из CAD заново, рисует то же самое другими путями, и
    каждый путь выходит «удалённым и добавленным». На картинке такой зоны
    нет, и в отчёт она не идёт."""
    result = [None] * len(zones)
    if _np is None or not zones:
        return result
    scale = _VERIFY_DPI / 72.0
    pad = _VERIFY_PAD_PT
    by_offset = {}
    for index, (zone, offset) in enumerate(zip(zones, offsets)):
        by_offset.setdefault(tuple(offset), []).append(index)
    counts = [[0, 0] for _ in zones]
    for (dx, dy), indexes in by_offset.items():
        boxes = [_pad(zones[i]["bbox"], pad) for i in indexes]
        for tx, ty in _tiles(boxes, _VERIFY_TILE_PT):
            tile = fitz.Rect(tx * _VERIFY_TILE_PT, ty * _VERIFY_TILE_PT,
                             (tx + 1) * _VERIFY_TILE_PT, (ty + 1) * _VERIFY_TILE_PT)
            clip_new = _clamped_clip(tile, pair.new_page.rect)
            if clip_new is None:
                continue
            old_rect = fitz.Rect(clip_new.x0 - dx, clip_new.y0 - dy,
                                 clip_new.x1 - dx, clip_new.y1 - dy)
            # Старая редакция рисуется той же областью, сдвинутой назад;
            # вне её листа — белое поле (там на старой редакции ничего нет).
            old_arr = _np.full((int(round(clip_new.height * scale)),
                                int(round(clip_new.width * scale)), 3), 255, dtype=_np.uint8)
            clip_old = _clamped_clip(old_rect, pair.old_page.rect)
            if clip_old is not None:
                part = _pix_array(pair.pixmap("old", clip_old, _VERIFY_DPI, fitz.csRGB))
                oy = int(round((clip_old.y0 - old_rect.y0) * scale))
                ox = int(round((clip_old.x0 - old_rect.x0) * scale))
                h = min(part.shape[0], old_arr.shape[0] - oy)
                w = min(part.shape[1], old_arr.shape[1] - ox)
                if h > 0 and w > 0:
                    old_arr[oy:oy + h, ox:ox + w] = part[:h, :w]
            new_arr = _pix_array(pair.pixmap("new", clip_new, _VERIFY_DPI, fitz.csRGB))
            removed, added = _change_masks(old_arr, new_arr, _VERIFY_DPI)
            if removed is None:
                continue
            mh, mw = removed.shape
            removed &= _significant(old_arr[:mh, :mw])
            added &= _significant(new_arr[:mh, :mw])
            del old_arr, new_arr
            for i in indexes:
                x0, y0, x1, y1 = _pad(zones[i]["bbox"], pad)
                cx0 = max(0, int((x0 - clip_new.x0) * scale))
                cy0 = max(0, int((y0 - clip_new.y0) * scale))
                cx1 = min(mw, int((x1 - clip_new.x0) * scale) + 1)
                cy1 = min(mh, int((y1 - clip_new.y0) * scale) + 1)
                if cx1 <= cx0 or cy1 <= cy0:
                    continue
                counts[i][0] += int(removed[cy0:cy1, cx0:cx1].sum())
                counts[i][1] += int(added[cy0:cy1, cx0:cx1].sum())
                result[i] = (counts[i][0], counts[i][1])
    return result


def visible_zones(pair, zones, offsets):
    """Зоны, изменение которых видно на чертеже (или проверить нечем —
    тогда верим векторному сравнению)."""
    checked = visible_changes(pair, zones, offsets)
    return [zone for zone, counts in zip(zones, checked)
            if counts is None or sum(counts) >= _VERIFY_MIN_PX]


# Ширина обзора листа целиком, пикселей: лист А0 на странице отчёта —
# это уже мелко, но планировку и трассы видно.
_OVERVIEW_PX_WIDTH = 1100


def render_sheet_overview(pair, caption):
    """Обе редакции листа целиком, без подложки: лист переработан, и
    подкрашивать на нём пришлось бы всё."""
    def _side(side, page):
        dpi = max(20, min(_MAX_DPI, 72.0 * _OVERVIEW_PX_WIDTH / max(page.rect.width, 1.0)))
        pix = pair.pixmap(side, page.rect, dpi, fitz.csRGB)
        if _np is None:
            return pix.tobytes("png")
        return _png(_pix_array(pix))

    rect = pair.new_page.rect
    return {
        "png_old": _side("old", pair.old_page),
        "png_new": _side("new", pair.new_page),
        "caption": caption,
        "before_text": "—",
        "after_text": "—",
        "aspect": rect.height / rect.width if rect.width else 1.0,
        "frame_old": None,
        "frame_new": None,
    }


def render_change_card(pair, cluster, offset):
    """Рендерит зону изменения как пару вырезок «было/стало» — только
    вокруг места правки, не весь лист.

    Возвращает словарь карточки либо None, если вырезка вышла за пределы
    листа и рисовать нечего — зона при этом остаётся в сводной таблице,
    теряется только картинка.

    Где именно изменился чертёж, считается по пикселям обеих вырезок
    (см. _change_masks): на «было» розовым подкрашено исчезнувшее, на
    «стало» зелёным — появившееся, и красится при этом только бумага.
    По габаритам векторных путей так не сделать — габарит ломаной это
    прямоугольник в пол-листа.

    DPI не фиксированный, а подобранный под физический размер вырезки:
    у некоторых зон (например, воздуховод через половину листа) вырезка
    сама по себе — тысячи pt в ширину. При фиксированных 110-200 DPI
    такая вырезка рендерилась в многие мегапиксели ни за чем — на экране
    она всё равно шириной в ~380 pt. Верхний потолок DPI — чтобы у
    маленьких вырезок качество не проседало ниже разумного."""
    dx, dy = offset
    bx0, by0, bx1, by1 = cluster["bbox"]
    new_clip = _framed(fitz.Rect(bx0 - _CROP_MARGIN, by0 - _CROP_MARGIN,
                                  bx1 + _CROP_MARGIN, by1 + _CROP_MARGIN))
    old_clip = fitz.Rect(new_clip.x0 - dx, new_clip.y0 - dy, new_clip.x1 - dx, new_clip.y1 - dy)

    crop_width_pt = max(new_clip.width, 1.0)
    dpi = int(max(_MIN_DPI, min(_MAX_DPI, 72.0 * _TARGET_PX_WIDTH / crop_width_pt)))

    clip_new = _clamped_clip(new_clip, pair.new_page.rect)
    clip_old = _clamped_clip(old_clip, pair.old_page.rect)
    if clip_new is None or clip_old is None:
        return None

    if _np is None:
        # Без numpy подложку не посчитать: вырезки идут как есть, место
        # правки показывает только рамка зоны.
        png_old = pair.pixmap("old", clip_old, dpi, _CROP_COLORSPACE).tobytes("png")
        png_new = pair.pixmap("new", clip_new, dpi, _CROP_COLORSPACE).tobytes("png")
    else:
        old_arr = _pix_array(pair.pixmap("old", clip_old, dpi, fitz.csRGB))
        new_arr = _pix_array(pair.pixmap("new", clip_new, dpi, fitz.csRGB))
        removed, added = _change_masks(old_arr, new_arr, dpi)
        png_old = _png(_apply_halo(old_arr, removed, _WASH_REMOVED, dpi))
        png_new = _png(_apply_halo(new_arr, added, _WASH_ADDED, dpi))

    caption, before_text, after_text = cluster_caption(cluster)
    return {
        "png_old": png_old,
        "png_new": png_new,
        "caption": caption,
        "before_text": before_text,
        "after_text": after_text,
        "aspect": clip_new.height / clip_new.width if clip_new.width else 1.0,
        # Рамка зоны на «было» — та же зона, перенесённая назад найденным
        # сдвигом листа: координаты зоны считаются в системе новой версии.
        "frame_old": _zone_frame((bx0 - dx, by0 - dy, bx1 - dx, by1 - dy), clip_old),
        "frame_new": _zone_frame(cluster["bbox"], clip_new),
    }


def _draw_draft_banner(page, y, margin, width):
    page.draw_rect(fitz.Rect(margin, y, margin + width, y + 16),
                    color=_DRAFT_COLOR, fill=_DRAFT_FILL, width=0.8)
    page.insert_text((margin + 6, y + 11), _DRAFT_BANNER_TEXT,
                      fontsize=8.5, fontname=_FONT_BOLD, color=_DRAFT_COLOR)
    return y + 24


def _wrap_paragraph(text, max_width, font_obj, fontsize):
    """Как _wrap_lines, но без ограничения на число строк — для связных
    абзацев чернового текста, которые не обязаны укладываться в 2-3
    строки колонки таблицы."""
    lines = []
    cur = ""
    for w in str(text).split():
        cand = (cur + " " + w).strip()
        if font_obj.text_length(cand, fontsize=fontsize) <= max_width or not cur:
            cur = cand
        else:
            lines.append(cur)
            cur = w
    if cur:
        lines.append(cur)
    return lines


def build_narrative_pages(report_doc, narrative, title):
    """narrative — результат narrative.generate_narrative(...): summary
    (str|None), sheet_comments (dict label -> str), conclusions
    (str|None). Ничего не рисует, если черновой текст пуст (модель не
    настроена/недоступна — детерминированный отчёт самодостаточен и без
    него, см. narrative.generate_narrative)."""
    if not narrative:
        return
    if not narrative.get("summary") and not narrative.get("sheet_comments") and not narrative.get("conclusions"):
        return

    margin = 40
    fontsize = 10
    line_h = 14
    max_w = 841.89 - 2 * margin

    def _start_page():
        p = _new_a4_page(report_doc, landscape=True)
        p.insert_text((margin, 34), title, fontsize=13, fontname=_FONT_BOLD)
        y2 = _draw_draft_banner(p, 42, margin, p.rect.width - 2 * margin)
        return p, y2 + 6

    page, y = _start_page()

    def _ensure_space(needed):
        nonlocal page, y
        if y + needed > page.rect.height - margin:
            page, y = _start_page()

    def _paragraph(text, indent=0):
        nonlocal y
        for line in _wrap_paragraph(text, max_w - indent, _FONT_OBJ, fontsize):
            _ensure_space(line_h)
            page.insert_text((margin + indent, y), line, fontsize=fontsize, fontname=_FONT)
            y += line_h

    if narrative.get("summary"):
        _ensure_space(18)
        page.insert_text((margin, y), "Резюме изменений (черновик)", fontsize=11, fontname=_FONT_BOLD)
        y += 18
        _paragraph(narrative["summary"])
        y += 12

    if narrative.get("sheet_comments"):
        _ensure_space(18)
        page.insert_text((margin, y), "Комментарии по листам (черновик)", fontsize=11, fontname=_FONT_BOLD)
        y += 18
        for label, comment in narrative["sheet_comments"].items():
            _ensure_space(line_h * 2)
            page.insert_text((margin, y), f"{label}:", fontsize=fontsize, fontname=_FONT_BOLD)
            y += line_h
            _paragraph(comment, indent=10)
            y += 6
        y += 6

    if narrative.get("conclusions"):
        _ensure_space(18)
        page.insert_text((margin, y), "Выводы (черновик)", fontsize=11, fontname=_FONT_BOLD)
        y += 18
        _paragraph(narrative["conclusions"])


def build_change_cards(report_doc, sheet_label, cards, cards_per_page=2, total_found=None,
                        side_labels=None):
    """cards: список словарей карточек (см. render_change_card).

    total_found — сколько находок на листе было всего. Если карточек
    показано меньше, это честно написано в заголовке: инженер должен
    видеть, что картинками показана только часть, а полный список — в
    сводной таблице."""
    if not cards:
        return

    page = None
    y = 0
    margin = 30
    img_w = _CARD_IMG_WIDTH
    gap = 20
    caption_h = 34

    # Подписи панелей — названия редакций («Исходная редакция» → «Изм. 1»),
    # как в эталонном отчёте; без них остаётся прежнее «было/стало».
    left_label, right_label = side_labels or ("БЫЛО", "СТАЛО")
    title = f"Изменения на листе: {sheet_label}"
    if total_found is not None and total_found > len(cards):
        title += (f"  —  показаны {len(cards)} наиболее заметных из {total_found}, "
                  f"полный список в сводной таблице")

    def _start_page():
        p = _new_a4_page(report_doc, landscape=True)
        p.insert_text((margin, 30),
                      _truncate(title, p.rect.width - 2 * margin, _FONT_BOLD_OBJ, 12),
                      fontsize=12, fontname=_FONT_BOLD)
        # Что означают цвета и рамка на картинках.
        p.insert_text((margin, 42), "Подложкой показано изменение:",
                      fontsize=7.5, fontname=_FONT)
        x = margin + _FONT_OBJ.text_length("Подложкой показано изменение:", fontsize=7.5) + 6
        p.insert_text((x, 42), "зелёная — добавлено", fontsize=7.5,
                      fontname=_FONT, color=_COLOR_ADDED)
        x += _FONT_OBJ.text_length("зелёная — добавлено", fontsize=7.5) + 6
        p.insert_text((x, 42), "розовая — удалено", fontsize=7.5,
                      fontname=_FONT, color=_COLOR_REMOVED)
        x += _FONT_OBJ.text_length("розовая — удалено", fontsize=7.5) + 6
        p.insert_text((x, 42), "оранжевая рамка — граница зоны", fontsize=7.5,
                      fontname=_FONT, color=_ZONE_FRAME_COLOR)
        return p, 52

    def _draw_card(target, image_rect, png, frame):
        """Картинка вырезки и тонкая рамка зоны поверх неё.

        Рамка только ограничивает место правки; что именно изменилось,
        показывает подложка, посчитанная по пикселям (см.
        render_change_card). Рисуется здесь, а не на самом чертеже: так
        лист не приходится копировать ради каждой зоны."""
        target.insert_image(image_rect, stream=png)
        if not frame:
            return
        fx0, fy0, fx1, fy1 = frame
        rect = fitz.Rect(
            image_rect.x0 + fx0 * image_rect.width,
            image_rect.y0 + fy0 * image_rect.height,
            image_rect.x0 + fx1 * image_rect.width,
            image_rect.y0 + fy1 * image_rect.height,
        ).normalize() & image_rect
        if not rect.is_empty:
            target.draw_rect(rect, color=_ZONE_FRAME_COLOR, width=_ZONE_FRAME_WIDTH)

    page, y = _start_page()
    for card in cards:
        # Прямоугольник под картинку считаем ТОЧНО по пропорциям вырезки.
        # insert_image вписывает картинку в рамку с сохранением пропорций
        # и центрует её, то есть при несовпадении пропорций реальная
        # картинка меньше рамки — а метки мест правки рисуются в долях от
        # рамки и тогда уезжают мимо.
        aspect = max(card["aspect"], 0.01)
        img_h = img_w * aspect
        w_used = img_w
        if img_h > _CARD_IMG_MAX_HEIGHT:
            img_h = _CARD_IMG_MAX_HEIGHT
            w_used = img_h / aspect
        card_h = img_h + caption_h + 16

        if y + card_h > page.rect.height - margin:
            page, y = _start_page()

        page.insert_text((margin, y + 10), left_label, fontsize=8, fontname=_FONT_BOLD)
        _draw_card(page, fitz.Rect(margin, y + 14, margin + w_used, y + 14 + img_h),
                   card["png_old"], card.get("frame_old"))

        x2 = margin + img_w + gap
        page.insert_text((x2, y + 10), right_label, fontsize=8, fontname=_FONT_BOLD)
        _draw_card(page, fitz.Rect(x2, y + 14, x2 + w_used, y + 14 + img_h),
                   card["png_new"], card.get("frame_new"))

        cap_y = y + 14 + img_h + 12
        cap_lines = _wrap_lines(card["caption"], page.rect.width - 2 * margin, _FONT_OBJ, 8.5, max_lines=2)
        for i, line in enumerate(cap_lines):
            page.insert_text((margin, cap_y + i * 10), line, fontsize=8.5, fontname=_FONT)

        y += card_h + gap
        page.draw_line((margin, y - gap / 2), (page.rect.width - margin, y - gap / 2),
                        color=(0.85, 0.85, 0.85), width=0.5)
