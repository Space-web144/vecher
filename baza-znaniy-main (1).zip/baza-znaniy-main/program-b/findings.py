# -*- coding: utf-8 -*-
"""
Оценка находок графической части: что здесь одно изменение, а что шум.

Зачем. Сводная таблица на комплекте — это сотни строк (замер на реальной
паре редакций: 49 находок на лист, до 206 на самом плотном). Половина
находок состоит из одного элемента: перенесённая подпись, одна линия.
Инженеру нужно видеть не список атомов, а перечень изменений: «узел
переделан», «добавлен шлейф», — и понимать, какие строки можно
пропустить.

Что делает модель. Получает ТОЛЬКО подписи находок, их положение на листе
в процентах и число затронутых элементов — ни чертежей, ни картинок. И
говорит две вещи: какие находки относятся к одному изменению и какие из
них не стоят внимания инженера.

Чего модель не делает. Не решает, что попадёт в отчёт: все находки
остаются в таблице до единой, меняется только пометка рядом с ними.
Поэтому ошибка модели стоит инженеру лишней или недостающей пометки, а
не потерянной правки.
"""
import json
import re

# Сколько находок уходит в один запрос. Больше — дешевле по числу
# запросов, но длиннее промпт и выше шанс, что модель начнёт «срезать
# углы» на длинном списке.
FINDINGS_PER_REQUEST = 40

# Сколько находок вообще имеет смысл оценивать. Замер на реальной паре
# редакций: 830 находок с подписями, это 21 запрос и $0.45 за одну пару —
# дороже всего остального чернового текста вместе взятого. При этом
# инженер смотрит не все находки подряд, а самые заметные: мелкая правка
# подписи в пометке не нуждается. Берём самые весомые, остальные строки
# остаются как есть, без пометки.
MAX_FINDINGS_CLASSIFIED = 120

# Подпись находки в промпте: две-три строки текста достаточно, чтобы
# понять суть правки, а платится за каждый символ.
_CAPTION_CHARS = 180

_JSON_FENCE_RE = re.compile(r"^\s*```(?:json)?\s*|\s*```\s*$", re.IGNORECASE)


def digest(number, sheet_label, caption, bbox, page_rect, items):
    """Компактное описание находки для промпта. Положение — в процентах
    от листа: модель не видит чертежа, но по координатам понимает, что
    находки рядом."""
    width = max(page_rect[2] - page_rect[0], 1.0)
    height = max(page_rect[3] - page_rect[1], 1.0)
    cx = ((bbox[0] + bbox[2]) / 2.0 - page_rect[0]) / width
    cy = ((bbox[1] + bbox[3]) / 2.0 - page_rect[1]) / height
    text = " ".join(str(caption or "").split())
    if len(text) > _CAPTION_CHARS:
        text = text[:_CAPTION_CHARS].rsplit(" ", 1)[0] + "…"
    return {
        "№": number,
        "лист": sheet_label,
        "находка": text,
        "положение": f"{cx * 100:.0f}% по ширине, {cy * 100:.0f}% по высоте",
        "элементов": items,
    }


def _parse(text):
    payload = _JSON_FENCE_RE.sub("", (text or "").strip())
    start, end = payload.find("["), payload.rfind("]")
    if start == -1 or end == -1 or end < start:
        return []
    try:
        data = json.loads(payload[start:end + 1])
    except ValueError:
        return []
    return data if isinstance(data, list) else []


def pick_for_classification(digests, weights, limit=MAX_FINDINGS_CLASSIFIED):
    """Самые весомые находки — по числу затронутых элементов и площади.
    Порядок сохраняем исходный: в запросе находки идут по листам, как в
    отчёте, и модели проще увидеть соседние среди них."""
    if len(digests) <= limit:
        return list(digests)
    heaviest = sorted(range(len(digests)), key=lambda i: weights[i], reverse=True)[:limit]
    keep = set(heaviest)
    return [d for i, d in enumerate(digests) if i in keep]


def classify(ask, digests, log=print):
    """Возвращает {номер находки: {"группа": int|None, "шум": bool}}.

    Всё, что не разобралось или не сошлось с запросом, молча
    отбрасывается: пометок просто не будет, таблица останется как есть."""
    known = {d["№"] for d in digests}
    verdicts = {}
    if not digests:
        return verdicts

    prompt = (
        "Ниже находки сравнения двух редакций чертежей: что именно изменилось, "
        "в каком месте листа и сколько элементов затронуто. Сделай две вещи.\n"
        "1) Объедини находки, которые вместе составляют ОДНО изменение проекта "
        "(один переделанный узел, одна перетрассированная магистраль, одна "
        "добавленная система). Находки одного изменения обычно рядом по "
        "положению или повторяются на разных листах. Каждой такой находке "
        "поставь одинаковый номер группы, начиная с 1. Находке, которая сама по "
        "себе отдельное изменение, поставь группу null.\n"
        "2) Отметь находки, не стоящие внимания инженера: правки, ничего не "
        "меняющие в проекте, — сдвиг подписи, переоформление, изменение "
        "начертания. Сомневаешься — не отмечай: пропустить шум безопаснее, чем "
        "спрятать правку.\n"
        "Ответь массивом JSON без пояснений, по объекту на каждую находку: "
        "[{\"№\": номер, \"группа\": число или null, \"шум\": true или false}, …]. "
        "Номера бери только из присланных, новых не придумывай."
    )

    for start in range(0, len(digests), FINDINGS_PER_REQUEST):
        chunk = digests[start:start + FINDINGS_PER_REQUEST]
        text = ask(prompt, chunk, 8000)
        group_offset = start  # номера групп не должны склеиваться между запросами
        for item in _parse(text):
            if not isinstance(item, dict):
                continue
            number = item.get("№")
            if number not in known:
                continue
            group = item.get("группа")
            noise = item.get("шум")
            verdicts[number] = {
                "группа": (group + group_offset) if isinstance(group, int) else None,
                "шум": bool(noise) if isinstance(noise, bool) else False,
            }
    missing = len(digests) - len(verdicts)
    if missing:
        log(f"[находки] модель не оценила {missing} находок из {len(digests)} — "
            "они останутся без пометки")
    return verdicts


def annotate(rows, row_numbers, verdicts):
    """Проставляет пометки в сводной таблице.

    rows — строки таблицы (их четвёртый столбец и заполняется),
    row_numbers — {номер находки: индекс строки}."""
    groups = {}
    for number, verdict in verdicts.items():
        group = verdict.get("группа")
        if group is not None:
            groups.setdefault(group, []).append(number)

    labels = {}
    for order, (group, numbers) in enumerate(sorted(groups.items()), start=1):
        if len(numbers) < 2:
            continue  # группа из одной находки — это не группа
        sheets = {rows[row_numbers[n]][0] for n in numbers if n in row_numbers}
        if len(sheets) > 1:
            label = f"изменение {order} (на {len(sheets)} листах)"
        else:
            label = f"изменение {order}"
        for number in numbers:
            labels[number] = label

    for number, verdict in verdicts.items():
        index = row_numbers.get(number)
        if index is None:
            continue
        marks = []
        if number in labels:
            marks.append(labels[number])
        if verdict.get("шум"):
            marks.append("не влияет на проект")
        if marks:
            rows[index][3] = "; ".join(marks)
    return rows
