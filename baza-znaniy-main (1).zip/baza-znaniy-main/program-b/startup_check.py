# -*- coding: utf-8 -*-
"""
Понятная причина, если фоновый процесс упал ещё на импорте.

Файлы на сервер заливаются руками, по одному, и при очередном обновлении
какой-нибудь не долетает или остаётся старым. Тогда процесс падает на
первой же строке — раньше, чем успевает записать статус, — и сайт через
90 секунд показывает только «процесс не подал признаков жизни, смотрите
журнал на сервере». Журнал инженеру недоступен.

Этот модуль — только стандартная библиотека, чтобы импортироваться
всегда, — переводит ошибку импорта в фразу, по которой ясно, какой файл
залить: «на сервере нет файла program-b/permits.py».
"""
import json
import os
import time

_PROGRAM_B = os.path.dirname(os.path.abspath(__file__))
_ROOT = os.path.dirname(_PROGRAM_B)

# Модули, которые program-b берёт из других папок. Остальные модули без
# пакета — свои, из program-b.
_FOREIGN_MODULES = {"pdf_to_spec": "program-a"}
_PACKAGES = ("common", "program-a", "program-b")


def status_file_from_argv(argv):
    """Путь к файлу статуса — до разбора аргументов: сам разбор зависит
    от модулей, которые могли не загрузиться."""
    argv = list(argv)
    for index, item in enumerate(argv):
        if item == "--status-file" and index + 1 < len(argv):
            return argv[index + 1]
        if item.startswith("--status-file="):
            return item.split("=", 1)[1]
    return None


def module_file(name):
    """Где на сервере должен лежать модуль: «common.anthropic_client» →
    common/anthropic_client.py, «permits» → program-b/permits.py."""
    parts = str(name or "").split(".")
    if not parts or not parts[0]:
        return None
    if parts[0] in _PACKAGES and len(parts) > 1:
        return "/".join(parts) + ".py"
    folder = _FOREIGN_MODULES.get(parts[0], "program-b")
    return f"{folder}/{parts[0]}.py"


def _relative(path):
    try:
        return os.path.relpath(path, _ROOT).replace(os.sep, "/")
    except ValueError:
        return path


def explain(exc):
    """Ошибка запуска — фразой для страницы статуса."""
    if isinstance(exc, ModuleNotFoundError):
        where = module_file(exc.name)
        return ("Обработка не запустилась: на сервере нет файла "
                f"{where or exc.name}. Залейте его из репозитория и повторите "
                f"сравнение. (Python: {exc})")
    if isinstance(exc, ImportError):
        # «cannot import name 'X' from 'common.anthropic_client'» — файл
        # есть, но старой версии: в нём нет того, что ждёт новый код.
        where = _relative(exc.path) if getattr(exc, "path", None) else module_file(exc.name)
        return ("Обработка не запустилась: файл "
                f"{where or exc.name} на сервере старой версии — в нём нет того, "
                "что нужно остальным файлам. Залейте его актуальную версию и "
                f"повторите сравнение. (Python: {exc})")
    if isinstance(exc, SyntaxError):
        where = _relative(exc.filename) if exc.filename else "один из файлов обработки"
        return ("Обработка не запустилась: файл "
                f"{where} на сервере повреждён или залит не полностью "
                f"(строка {exc.lineno}). Залейте его заново и повторите сравнение.")
    return f"Обработка не запустилась: {type(exc).__name__}: {exc}"


def report(status_file, exc, base=None):
    """Пишет причину в файл статуса — страница её покажет вместо «смотрите
    журнал на сервере». Ошибка записи не должна заслонить исходную."""
    if not status_file:
        return
    payload = dict(base or {})
    payload.update({"state": "error", "ok": False, "error": explain(exc),
                    "updated": int(time.time())})
    try:
        tmp = status_file + ".tmp"
        with open(tmp, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False)
        os.replace(tmp, status_file)
    except OSError:
        pass
