# -*- coding: utf-8 -*-
"""
Разбор наряда-заказа на дополнительные работы (НЗ).

НЗ — печатная форма из таблицы, поэтому текст в PDF лежит в порядке
отрисовки, а не чтения: наименование, единица, количество и система
оказываются в разных местах потока. Таблица восстанавливается
геометрически, как и спецификация в program-a/pdf_to_spec.py, но проще:
колонок шесть и они подписаны.

    №  |  Наименование работ  |  Ед. изм.  |  Объем в РД  |  Объем ДР  |  Место проведения работ

Границы колонок берутся из самой шапки, а не зашиваются: на девяти
присланных бланках они разъезжаются на десятки пунктов (колонка "Ед.
изм." встречается и на x=274, и на x=329), хотя состав колонок один и
тот же.

Строки таблицы нумерованы, и номер — самый надёжный якорь: наименование
переносится на несколько строк, а номер всегда один и стоит по центру
своей строки.

В НЗ вперемешку идут работы ("Монтаж круглого дефлектора") и материалы
("Дефлектор, профиль: круглый ..."). В сравнение количеств идут только
материалы, поэтому работы помечаются — но по принципу "не уверен, значит
материал": лишняя строка в таблице видна инженеру сразу, а потерянная
позиция не видна никак.
"""
import collections
import os
import re

import fitz

# Слова шапки, по которым колонка получает смысл. "Объем" встречается
# дважды ("Объем в РД" и "Объем ДР") — и в части бланков только один раз.
_HEADER_NAME = "Наименование"
_HEADER_UNIT = "Ед."
_HEADER_VOLUME = "Объем"
_HEADER_PLACE = "Место"

# Шапка разнесена по двум строкам (часть слов на 3 пункта выше), поэтому
# собираем её в окне по вертикали, а не по точному совпадению y.
_HEADER_BAND_PT = 8.0

# Граница колонки начинается от строки шапки и тянется вниз. Оба условия
# нужны: по одной длине не отличить разлиновку блоков под таблицей (она
# тоже длинная), а по одному началу — случайную короткую черту в шапке.
# Порог длины низкий: в наряде на четыре позиции вся таблица — 36 пунктов.
_RULE_BELOW_PT = 18.0
_RULE_START_PT = 25.0
# Соседние линии ближе этого считаем одной (в бланках попадаются сдвоенные).
_RULE_MERGE_PT = 6.0

# Наименование работы начинается с отглагольного существительного. Список
# закрытый и проверяемый; всё, что в него не попало, считается материалом.
_WORK_PREFIXES = (
    "монтаж", "демонтаж", "устройство", "прокладка", "установка", "сборка",
    "разборка", "перенос", "замена", "изготовление", "окраска", "окрашивание",
    "испытание", "пусконаладка", "погрузка", "разгрузка", "транспортировка",
    "вывоз", "подключение", "наладка", "очистка", "резка", "сверление",
)

_NUMBER_RE = re.compile(r"^\d{1,3}$")
_QTY_RE = re.compile(r"^-?\d[\d\s\u00a0]*(?:[.,]\d+)?$")
# Обозначение комплекта РД в теле наряда: "09-БД-ПИР/2023-Р-16.1-ОВ2.3".
_RD_RE = re.compile(r"[0-9]{2,}-[А-ЯA-Z]{2,}[-/.][^\s,;]{4,}", re.UNICODE)


def _words(page):
    return page.get_text("words")


def _vertical_segments(page):
    """Вертикальные отрезки страницы как (x, y0, y1) — и линии, и тонкие
    прямоугольники: в этих бланках встречается и то, и другое."""
    out = []
    for drawing in page.get_cdrawings():
        for item in drawing.get("items", ()):
            if item[0] == "l":
                p1, p2 = item[1], item[2]
                x1, y1 = (p1[0], p1[1]) if isinstance(p1, (tuple, list)) else (p1.x, p1.y)
                x2, y2 = (p2[0], p2[1]) if isinstance(p2, (tuple, list)) else (p2.x, p2.y)
            elif item[0] == "re":
                r = item[1]
                x1, y1, x2, y2 = (r[0], r[1], r[2], r[3]) \
                    if isinstance(r, (tuple, list)) else (r.x0, r.y0, r.x1, r.y1)
            else:
                continue
            if abs(x2 - x1) < 1.0 and abs(y2 - y1) >= 2.0:
                out.append(((x1 + x2) / 2, min(y1, y2), max(y1, y2)))
    return out


def _column_edges(page, header_y):
    """Границы колонок — по разлиновке таблицы.

    Подписи шапки для этого не годятся: в части бланков они выровнены по
    центру колонки, и "Наименование" стоит на x=135, тогда как сам текст
    позиции начинается на x=38. Линии же идут ровно по краям ячеек.
    """
    # Разлиновка разрезана по строкам: граница колонки это не один длинный
    # отрезок, а цепочка коротких — по одному на ячейку. Поэтому считаем
    # суммарную длину вертикальных отрезков под шапкой для каждого x.
    covered = collections.defaultdict(float)
    starts = set()
    for x, y0, y1 in _vertical_segments(page):
        key = round(x / _RULE_MERGE_PT)
        low, high = max(y0, header_y), min(y1, page.rect.height)
        if high > low:
            covered[key] += high - low
        if header_y - _RULE_START_PT <= y0 <= header_y + _RULE_START_PT:
            starts.add(key)
    xs = sorted(key * _RULE_MERGE_PT for key, length in covered.items()
                if length >= _RULE_BELOW_PT and key in starts)
    if len(xs) < 4:
        return []
    merged = [xs[0]]
    for x in xs[1:]:
        if x - merged[-1] > _RULE_MERGE_PT:
            merged.append(x)
    return merged


def _header_bounds(page):
    """[(ключ, левая граница, правая граница)] и низ шапки — или None."""
    words = _words(page)
    place = [w for w in words if w[4] == _HEADER_PLACE]
    names = [w for w in words if w[4] == _HEADER_NAME]
    if not place or not names:
        return None
    anchor = min(place, key=lambda w: w[1])
    center = (anchor[1] + anchor[3]) / 2
    header = [w for w in words
              if abs((w[1] + w[3]) / 2 - center) <= _HEADER_BAND_PT]
    if not any(w[4] == _HEADER_NAME for w in header):
        return None

    edges = _column_edges(page, center)
    if len(edges) < 4:
        return None

    # Колонки собираем по подписям шапки, а края берём из разлиновки:
    # подписи задают состав и порядок колонок, линии — точные границы.
    # Левый край колонки — ближайшая линия левее середины подписи. По
    # самим подписям границы не построить (в части бланков они выровнены
    # по центру), по одним линиям тоже (в части бланков есть лишние).
    anchors = []
    for word in sorted(header, key=lambda w: w[0]):
        if word[4] == _HEADER_NAME:
            key = "name"
        elif word[4] == _HEADER_UNIT:
            key = "unit"
        elif word[4] == _HEADER_PLACE:
            key = "place"
        elif word[4] == _HEADER_VOLUME:
            key = "volume"
        elif word[4] == "№" and not anchors:
            key = "no"
        else:
            continue
        if anchors and anchors[-1][0] == key and key != "volume":
            continue
        anchors.append((key, (word[0] + word[2]) / 2))

    volumes = [index for index, (key, _x) in enumerate(anchors) if key == "volume"]
    if not volumes:
        return None
    # Две колонки объёма — "в РД" и "ДР"; одна — только "ДР" (бланки
    # встречаются и без колонки "Объем в РД").
    anchors[volumes[-1]] = ("qty", anchors[volumes[-1]][1])
    for index in volumes[:-1]:
        anchors[index] = ("qty_rd", anchors[index][1])

    def edge_before(x, fallback):
        """Ближайшая линия левее x — или середина между подписями, если
        линии там нет. Так бывает на коротких бланках, где граница между
        колонками нарисована только в пределах шапки."""
        candidates = [e for e in edges if e < x]
        return max(candidates) if candidates else fallback

    bounds = []
    for index, (key, x) in enumerate(anchors):
        previous = anchors[index - 1][1] if index else 0.0
        left = edge_before(x, (previous + x) / 2 if index else 0.0)
        if index + 1 < len(anchors):
            following = anchors[index + 1][1]
            right = edge_before(following, (x + following) / 2)
            if right <= left:
                right = (x + following) / 2
        else:
            right = min((e for e in edges if e > x), default=page.rect.width)
        if right <= left:
            return None
        bounds.append((key, left, right))

    keys = [key for key, _l, _r in bounds]
    if "name" not in keys or "qty" not in keys or "unit" not in keys:
        return None
    return bounds, max(w[3] for w in header)


def _column_of(bounds, x):
    for key, left, right in bounds:
        if left <= x < right:
            return key
    return None


# Строки текста ближе этого по вертикали считаем одной строкой таблицы:
# номер, единица и количество печатаются с разбросом в доли пункта.
_LINE_MERGE_PT = 2.5


def _text_lines(page, top, bottom):
    """Строки текста в полосе таблицы: (верх, низ, середина)."""
    centers = []
    for w in page.get_text("words"):
        y = (w[1] + w[3]) / 2
        if top <= y <= bottom:
            centers.append((y, w[1], w[3]))
    centers.sort()
    lines = []
    for y, y0, y1 in centers:
        if lines and y - lines[-1][2] <= _LINE_MERGE_PT:
            low, high, _c, items = lines[-1]
            lines[-1] = (min(low, y0), max(high, y1), y, items + [y])
        else:
            lines.append((y0, y1, y, [y]))
    return [(low, high, sum(items) / len(items)) for low, high, _c, items in lines]


def _assign_lines(lines, anchors):
    """Раскладывает строки текста по номерам строк таблицы.

    Наименование переносится на несколько строк и печатается ПО ЦЕНТРУ
    своей строки таблицы — там же, где стоит номер. Поэтому делить по
    середине между номерами нельзя: у короткой строки середина заезжает
    в текст длинной соседки (так наименование строки 8 забирало первую
    строку наименования девятой).

    Делим последовательность строк текста на столько подряд идущих
    групп, сколько в таблице номеров, так чтобы середина каждой группы
    совпала со своим номером. Это обычная задача о разбиении на отрезки,
    и решается она точно, а не подбором порогов.
    """
    count, rows = len(lines), len(anchors)
    if not count or not rows or count < rows:
        return []
    best = [[None] * (rows + 1) for _ in range(count + 1)]
    best[0][0] = (0.0, 0)
    for taken in range(1, count + 1):
        for row in range(1, min(rows, taken) + 1):
            for start in range(row - 1, taken):
                previous = best[start][row - 1]
                if previous is None:
                    continue
                group = lines[start:taken]
                middle = sum(line[2] for line in group) / len(group)
                cost = previous[0] + abs(middle - anchors[row - 1])
                if best[taken][row] is None or cost < best[taken][row][0]:
                    best[taken][row] = (cost, start)
    if best[count][rows] is None:
        return []
    bounds, taken = [], count
    for row in range(rows, 0, -1):
        start = best[taken][row][1]
        bounds.append((lines[start][0], lines[taken - 1][1]))
        taken = start
    bounds.reverse()
    return bounds


def _row_bands(page, bounds, top):
    """Полосы строк таблицы: номер в первой колонке — якорь строки."""
    _key, left, right = bounds[0]
    numbers = [w for w in page.get_text("words")
               if left <= w[0] < right and (w[1] + w[3]) / 2 > top
               and _NUMBER_RE.match(w[4])]
    numbers.sort(key=lambda w: (w[1] + w[3]) / 2)
    if not numbers:
        return []
    anchors = [(w[1] + w[3]) / 2 for w in numbers]
    values = [int(w[4]) for w in numbers]
    # Нижняя граница таблицы: за последним номером текст идёт уже не её —
    # обоснование, перечень документов, подписи. Берём с запасом в три
    # средних шага между номерами.
    step = ((anchors[-1] - anchors[0]) / (len(anchors) - 1)) if len(anchors) > 1 else 20.0
    # Полоса таблицы — вокруг номеров. На второй странице шапки нет, и без
    # этой границы в раскладку попадал колонтитул ("00+NaNШаблон …"), из-за
    # чего строки съезжали и одна терялась.
    upper = max(top, anchors[0] - 1.5 * step)
    bottom = anchors[-1] + 2 * step
    lines = _text_lines(page, upper, bottom)
    spans = _assign_lines(lines, anchors)
    if len(spans) != len(anchors):
        # Разложить не удалось — делим по серединам между номерами. Хуже,
        # но лучше, чем потерять таблицу целиком.
        spans = []
        for index, y in enumerate(anchors):
            top_edge = upper if index == 0 else (anchors[index - 1] + y) / 2
            lower = (anchors[index + 1] + y) / 2 if index + 1 < len(anchors) \
                else y + (y - top_edge)
            spans.append((top_edge, lower))
    return [(values[i], low, high) for i, (low, high) in enumerate(spans)]


def _cell_text(cells, key):
    items = sorted(cells.get(key, ()), key=lambda item: (round(item[0] / 3), item[1]))
    return " ".join(text for _y, _x, text in items).strip()


def parse_qty(text):
    """Количество числом: "4,35" -> 4.35. Не число — None."""
    text = (text or "").strip().replace(" ", "").replace(" ", "")
    if not _QTY_RE.match(text):
        return None
    value = float(text.replace(",", "."))
    return int(value) if value == int(value) else value


def split_qty(text):
    """(количество, остаток строки).

    Текст соседней колонки заходит за линию: в ячейке количества
    оказывается "3,00 Кровля." — число и начало графы "Место проведения
    работ". Ничего, кроме числа, в колонке количества быть не может,
    поэтому первый числовой токен забираем как количество, а остальное
    возвращаем — оно принадлежит колонке правее.
    """
    tokens = (text or "").split()
    for index, token in enumerate(tokens):
        value = parse_qty(token)
        if value is not None:
            return value, " ".join(tokens[:index] + tokens[index + 1:])
    return None, " ".join(tokens)


def is_work(name):
    """Строка описывает работу, а не материал."""
    first = (name or "").strip().split(" ")[0].strip(",.;:()").lower()
    return first in _WORK_PREFIXES


def parse_order(pdf_path):
    """Разбирает наряд-заказ.

    Возвращает {"file", "number", "theme", "rd", "rows"}, где rows —
    список {"no", "name", "unit", "qty_rd", "qty", "place", "work"}.
    """
    doc = fitz.open(pdf_path)
    try:
        rows = []
        bounds = None
        for page in doc:
            found = _header_bounds(page)
            if found is not None:
                bounds, top = found
            elif bounds is None:
                continue
            else:
                top = 0.0
            for number, upper, lower in _row_bands(page, bounds, top):
                cells = collections.defaultdict(list)
                for w in _words(page):
                    y = (w[1] + w[3]) / 2
                    if not (upper <= y < lower):
                        continue
                    key = _column_of(bounds, w[0])
                    if key:
                        cells[key].append((y, w[0], w[4]))
                # Числовые колонки разбираем слева направо: остаток, не
                # попавший в число, принадлежит колонке правее.
                qty_rd, spill = split_qty(_cell_text(cells, "qty_rd"))
                qty, tail = split_qty((spill + " " + _cell_text(cells, "qty")).strip())
                place = " ".join((tail + " " + _cell_text(cells, "place")).split())
                name = " ".join(_cell_text(cells, "name").split())
                unit = _cell_text(cells, "unit")
                if not name or qty is None or not unit:
                    continue
                rows.append({
                    "no": number,
                    "name": name,
                    "unit": unit,
                    "qty_rd": qty_rd,
                    "qty": qty,
                    "place": place,
                    "work": is_work(name),
                })
        text = " ".join(page.get_text() for page in doc)
    finally:
        doc.close()

    # Номер обязан начинаться с цифры: в потоке текста сразу за заголовком
    # попадается "№" из других граф, и без этого условия номером наряда
    # становилось "г." из "г. Москва".
    number = re.search(r"НАРЯД-ЗАКАЗ.{0,120}?№\s?(\d[^\s]*)", text, re.S)
    theme = re.search(r"Тема:\s*(.{0,80})", text)
    rd = _RD_RE.search(text.split("Новая версия документации", 1)[-1]) \
        if "Новая версия документации" in text else None
    name = os.path.basename(pdf_path)
    return {
        "file": name,
        "label": ("НЗ №" + number.group(1)) if number else os.path.splitext(name)[0],
        "number": number.group(1) if number else "",
        "theme": " ".join(theme.group(1).split()) if theme else "",
        "rd": rd.group(0) if rd else "",
        "rows": rows,
        "notes": missing_rows_note(name, rows),
    }


def missing_rows_note(file_name, rows):
    """Предупреждения о строках наряда, которые разобрать не удалось.

    Строки наряда пронумерованы подряд, поэтому их точное число известно
    из самого документа — и потерянную строку видно без всяких порогов.
    Потерянный материал в отчёте не виден никак, поэтому молчать нельзя.
    """
    numbers = {row["no"] for row in rows}
    if not numbers:
        return [f"В наряде «{file_name}» не разобрана ни одна строка."]
    missing = sorted(set(range(1, max(numbers) + 1)) - numbers)
    if not missing:
        return []
    listed = ", ".join(str(n) for n in missing[:10])
    if len(missing) > 10:
        listed += " и другие"
    return [f"В наряде «{file_name}» не разобраны строки: {listed}. "
            "Проверьте их по исходному PDF — в сравнение они не попадут."]


def materials(order):
    """Только материалы — работы в сравнение количеств не идут."""
    return [row for row in order["rows"] if not row["work"]]
