# -*- coding: utf-8 -*-
"""
Фоновый запуск сравнения ревизий для сайта (вкладка Verrata).

Запускается из web/verrata_process.php через nohup и живёт дольше, чем
HTTP-запрос браузера: комплект в полторы сотни листов считается минутами.
Поэтому единственный способ сообщить результат — файл статуса на диске,
его опрашивает web/verrata_status.php.

Статус пишется с самого начала (state=running) и обновляется по ходу
работы: инженер должен видеть, что процесс жив и на каком он шаге, а не
гадать перед крутящимся индикатором.
"""
import os

# Обязательно ДО импорта compare (тот тянет numpy через openpyxl в
# spec_diff.py). На shared-хостинге лимит процессов на аккаунт —
# RLIMIT_NPROC 36, а OpenBLAS по умолчанию заводит поток на каждое из 40
# ядер: получается "pthread_create failed for thread 35 of 40" и следом
# MemoryError прямо на импорте, до первой строки работы. Ровно это
# положило первый прогон Verrata на сервере. Та же защита стоит в
# program-a/web_run.py — см. историю переписки по деплою на reg.ru Host-0.
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import argparse
import json
import sys
import time
import traceback

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Импорт обработки — под защитой: если на сервер не долетел или остался
# старым какой-то из файлов, процесс падал здесь, раньше первой записи
# статуса, и сайт через 90 секунд говорил только «смотрите журнал на
# сервере». Теперь причина с именем файла уходит в статус и видна на
# странице (см. startup_check.py).
import startup_check  # noqa: E402

try:
    from compare import MODE_FULL, MODES, NARRATIVE_PROVIDERS, compare_files  # noqa: E402
    from revisions import RevisionError  # noqa: E402
except Exception as _startup_error:  # noqa: BLE001 — любая ошибка импорта
    startup_check.report(startup_check.status_file_from_argv(sys.argv[1:]), _startup_error)
    print(startup_check.explain(_startup_error), file=sys.stderr)
    traceback.print_exc()
    sys.exit(1)


def _read_started(status_file):
    """Время постановки задачи берём из файла, который создал PHP до
    запуска процесса: страница ожидания показывает по нему «прошло
    секунд», а время изменения файла для этого не годится — статус
    обновляется на каждом шаге, и счётчик обнулялся бы на каждом."""
    if not status_file or not os.path.isfile(status_file):
        return None
    try:
        with open(status_file, "r", encoding="utf-8") as handle:
            started = json.load(handle).get("started")
    except (OSError, ValueError):
        return None
    return started if isinstance(started, int) and started > 0 else None


def _write_status(status_file, payload):
    """Атомарная запись статуса — страница опроса не должна увидеть
    наполовину записанный файл."""
    if not status_file:
        return
    payload = dict(payload, updated=int(time.time()))
    tmp_path = status_file + ".tmp"
    with open(tmp_path, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False)
    os.replace(tmp_path, status_file)


def _progress_logger(status_file, base_payload):
    """Строки, которые compare_files печатает по ходу работы, кладём в
    статус как текущий шаг — и дублируем в stderr, он уходит в общий лог
    ошибок (см. verrata_process.php)."""
    def log(message):
        print(message, file=sys.stderr)
        _write_status(status_file, dict(base_payload, state="running", stage=str(message)))
    return log


def main():
    parser = argparse.ArgumentParser(description="Веб-запуск сравнения ревизий (Verrata)")
    parser.add_argument("pdfs", nargs="+", help="загруженные PDF редакций (порядок определяется по именам)")
    parser.add_argument("--mode", default=MODE_FULL, choices=list(MODES))
    parser.add_argument("--section", default=None,
                        help="раздел проекта (ОВ, ВК, ЭОМ, СС): по нему агент "
                             "берёт свой промт и эталон отчёта")
    parser.add_argument("--output", default=None, help="путь к PDF-отчёту")
    parser.add_argument("--spec-xlsx", default=None, help="путь к Excel-отчёту по спецификации")
    parser.add_argument("--nz", nargs="*", default=[],
                        help="наряд-заказы (PDF): их материалы идут в Excel "
                             "отдельными колонками рядом с редакциями")
    parser.add_argument("--tmp-dir", default=None, help="папка для временных файлов")
    parser.add_argument("--status-file", default=None, help="куда писать JSON-статус")
    parser.add_argument("--narrative", default=None, choices=list(NARRATIVE_PROVIDERS),
                        help="добавить в PDF черновой связный текст от модели поверх "
                             "посчитанных фактов")
    parser.add_argument("--narrative-credentials", default=None,
                        help="путь к JSON с ключом Anthropic (сам ключ читает Python, "
                             "аргументом он не передаётся)")
    parser.add_argument("--role", action="append", default=[], metavar="ФАЙЛ=НОМЕР",
                        help="подтверждённая инженером роль редакции: имя файла и "
                             "номер изменения (0 — исходная). Переданные роли "
                             "побеждают разбор имён файлов (см. карточку "
                             "«Что я нашёл» и revisions.apply_roles)")
    parser.add_argument("--display-base", default=None,
                        help="обозначение комплекта для имени файла при скачивании — "
                             "на диске отчёт всё равно лежит под токеном")
    args = parser.parse_args()

    roles = {}
    for item in args.role:
        name, _sep, number = str(item).rpartition("=")
        if not name or not number.strip().lstrip("-").isdigit():
            print(f"роль «{item}» непонятна: нужно ИМЯ=НОМЕР", file=sys.stderr)
            return 2
        roles[name] = int(number)

    base = {"mode": args.mode}
    started = _read_started(args.status_file)
    if started:
        base["started"] = started
    if args.display_base:
        base["display_base"] = args.display_base
    _write_status(args.status_file, dict(base, state="running", stage="начинаю обработку…"))

    narrative_notes = []

    try:
        compare_files(
            args.pdfs,
            output_path=args.output,
            tmp_dir=args.tmp_dir,
            spec_xlsx=args.spec_xlsx,
            nz_paths=args.nz,
            mode=args.mode,
            narrative=args.narrative,
            narrative_credentials=args.narrative_credentials,
            narrative_notes_out=narrative_notes,
            roles=roles or None,
            section=args.section,
            log=_progress_logger(args.status_file, base),
        )
        # Заявляем только те отчёты, которые реально легли на диск.
        # Спецификации может не оказаться ни в одной редакции (пакет
        # изменений — это часто одни чертежи), и обещать пользователю файл,
        # которого нет, нельзя: он решит, что тот потерялся.
        pdf = args.output if args.mode != "spec" and args.output and os.path.isfile(args.output) else None
        xlsx = (args.spec_xlsx if args.mode != "graphics" and args.spec_xlsx
                and os.path.isfile(args.spec_xlsx) else None)
        notes = []
        if args.mode != "graphics" and xlsx is None:
            notes.append("Листы спецификации не найдены ни в одной редакции — "
                         "отчёт по спецификации не собран.")
        if args.mode != "spec" and pdf is None:
            notes.append("Отчёт по чертежам не собран.")
        # Одинаковые пояснения по разным парам редакций схлопываем: при трёх
        # редакциях одна и та же причина («не установлен пакет») выводилась
        # дважды подряд, и страница результата превращалась в повтор.
        for note in narrative_notes:
            if note not in notes:
                notes.append(note)
        result = dict(base, state="done", ok=True,
                      report_pdf=pdf, report_xlsx=xlsx, notes=notes)
        _write_status(args.status_file, result)
        print(json.dumps(result, ensure_ascii=False))
    except RevisionError as exc:
        # Ошибка имён файлов — это сообщение инженеру, а не сбой: показываем
        # текст как есть, без трассировки.
        _write_status(args.status_file, dict(base, state="error", ok=False, error=str(exc)))
        print(str(exc), file=sys.stderr)
        sys.exit(2)
    except Exception as exc:  # noqa: BLE001 — статус нужен при любой ошибке
        # Сравнение чертежей падает первым, а таблица спецификации к тому
        # моменту уже собрана и лежит на диске (см. compare_files). Молчать
        # о ней нельзя: инженер проделал загрузку и ждал, а готовый отчёт
        # остался бы недостижимым из-за сбоя в другой части работы.
        salvaged = (args.spec_xlsx if args.spec_xlsx
                    and os.path.isfile(args.spec_xlsx) else None)
        _write_status(args.status_file, dict(
            base, state="error", ok=False, report_xlsx=salvaged,
            error="Не удалось обработать файлы: " + str(exc)))
        print(traceback.format_exc(), file=sys.stderr)
        sys.exit(1)
    finally:
        # Исходные PDF на сайте не хранятся (требование заказчика) —
        # удаляем сразу после обработки, удачной или нет.
        for path in args.pdfs:
            try:
                os.remove(path)
            except OSError:
                pass


if __name__ == "__main__":
    main()
