#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Справочник КЦ для агента проверки ТКП: из выгрузки «справочник_КЦ_ВЕСЬ.xlsx»
в компактный skill/tkp-spec-check/assets/kc_ref.json.gz.

Выгрузка — листы «Работы» (код, наименование, пакет, путь разделов, цена,
guid) и «Материалы» (код работы, работа, группа, материал, ед., коэф.
расхода, «Основной», «Объём редакт.», цена, guid). Агенту нужны разделы,
которые он проверяет (ВК, ОВ1, ОВ2, ИТП, кондиционирование) — коды работ,
их наименования и допустимые материалы. Цены не переносятся.

    python tools/kc_ref_build.py справочник_КЦ_ВЕСЬ.xlsx [--out skill/tkp-spec-check/assets/kc_ref.json.gz]

Печатает сверку с прежним справочником: закрытые и новые работы.
"""
import argparse
import collections
import datetime
import gzip
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_OUT = os.path.join(HERE, '..', 'skill', 'tkp-spec-check', 'assets', 'kc_ref.json.gz')

# Разделы, которые проверяет агент (+ кондиционирование: в ТКП встречается, статус «вне ТКП»).
PREFIXES = {
    '6.2.3.1.': 'ВК',
    '6.2.3.2.': 'ОВ1',
    '6.2.3.3.': 'ОВ2',
    '6.2.3.6.': 'ИТП',
    '6.2.3.7.': 'Кондиционирование',
    '6.2.3.8.': 'Кондиционеры',
}


def _s(v):
    return '' if v is None else str(v).strip()


def _f(v, default=None):
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def section_of(code):
    return next((name for prefix, name in PREFIXES.items() if code.startswith(prefix)), None)


def _columns(header, wanted):
    cells = [_s(c).lower() for c in header]
    found = {}
    for key, starts in wanted.items():
        for i, c in enumerate(cells):
            if any(c.startswith(s) for s in starts):
                found[key] = i
                break
    missing = [k for k in wanted if k not in found]
    if missing:
        raise ValueError('нет колонок: ' + ', '.join(missing))
    return found


def read_catalog(path):
    import openpyxl
    book = openpyxl.load_workbook(path, read_only=True, data_only=True)
    sheets = {s.title.strip().lower(): s for s in book.worksheets}
    if 'работы' not in sheets or 'материалы' not in sheets:
        raise ValueError('нет листов «Работы» и «Материалы» — это не выгрузка справочника КЦ')
    works = collections.OrderedDict()
    rows = sheets['работы'].iter_rows(values_only=True)
    col = _columns(next(rows), {'code': ('код',), 'name': ('наимен',), 'package': ('пакет',), 'path': ('путь',)})
    for row in rows:
        code = _s(row[col['code']])
        if code and section_of(code):
            works[code] = [_s(row[col['name']]), _s(row[col['package']]), _s(row[col['path']])]
    mats = collections.defaultdict(list)
    seen = collections.defaultdict(set)
    rows = sheets['материалы'].iter_rows(values_only=True)
    col = _columns(next(rows), {'code': ('код работы',), 'group': ('группа',), 'material': ('материал',),
                                'unit': ('ед',), 'coef': ('коэф',), 'main': ('основн',)})
    for row in rows:
        code = _s(row[col['code']])
        if code not in works:
            continue
        item = [_s(row[col['group']]), _s(row[col['material']]), _s(row[col['unit']]),
                _f(row[col['coef']], 1.0), 1 if _s(row[col['main']]).lower() == 'да' else 0]
        key = tuple(item)
        if key not in seen[code]:
            seen[code].add(key)
            mats[code].append(item)
    book.close()
    return works, mats


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument('catalog')
    parser.add_argument('--out', default=DEFAULT_OUT)
    args = parser.parse_args()
    out = os.path.abspath(args.out)
    old = None
    if os.path.exists(out):
        with gzip.open(out, 'rt', encoding='utf-8') as fh:
            old = json.load(fh)
    works, mats = read_catalog(args.catalog)
    data = {
        'source': os.path.basename(args.catalog),
        'built': datetime.date.today().isoformat(),
        'sections': PREFIXES,
        'works': works,
        'mats': mats,
    }
    by_sec = collections.Counter(section_of(c) for c in works)
    for prefix, name in PREFIXES.items():
        n_m = sum(len(mats[c]) for c in works if c.startswith(prefix))
        print('%-18s работ %5d, позиций материалов %6d' % (name, by_sec[name], n_m))
    if old:
        gone = sorted(set(old['works']) - set(works))
        new = sorted(set(works) - set(old['works']))
        print('по сравнению с прежним (%s): закрыто работ %d, новых %d' % (old.get('built'), len(gone), len(new)))
        for code in gone[:30]:
            print('  закрыта:', code, old['works'][code][0][:80])
    os.makedirs(os.path.dirname(out), exist_ok=True)
    tmp = out + '.tmp'
    with gzip.open(tmp, 'wt', encoding='utf-8', compresslevel=9) as fh:
        json.dump(data, fh, ensure_ascii=False, separators=(',', ':'))
    os.replace(tmp, out)
    print('записан %s (%.1f МБ)' % (out, os.path.getsize(out) / 1024 / 1024))
    return 0


if __name__ == '__main__':
    sys.exit(main())
