#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Сборка двух отдельных агентов из одного комплекта — для двух проектов claude.ai
(или двух навыков на исполнителе):

    python tools/pack_skills.py [папка_вывода]      # по умолчанию tkp-agent/dist/

Получается:
  tkp-spec-check.zip  + Инструкции_проекта_по_спецификации.md   — проверка ТКП основного договора по РД
  tkp-nz-audit.zip    + Инструкции_проекта_по_НЗ.md             — проверка ТКП по нарядам-заказам, счетам, УПД

Общий код хранится в репозитории в одном экземпляре: справочник КЦ (= ВИС 2026) лежит в
навыке tkp-spec-check и при сборке копируется в архив tkp-nz-audit (scripts/kc_ref.py,
assets/kc_ref.json.gz), чтобы каждый архив работал сам по себе.
"""
import os
import sys
import zipfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SKILLS = os.path.join(ROOT, "skill")
SHARED = [("tkp-spec-check/scripts/kc_ref.py", "scripts/kc_ref.py"),
          ("tkp-spec-check/assets/kc_ref.json.gz", "assets/kc_ref.json.gz")]
PROMPTS = {"tkp-spec-check": ("agent/system_prompt.md", "Инструкции_проекта_по_спецификации.md"),
           "tkp-nz-audit": ("agent/system_prompt_nz.md", "Инструкции_проекта_по_НЗ.md")}
SKIP_DIRS = {"__pycache__"}


def pack(name, out_dir):
    src = os.path.join(SKILLS, name)
    path = os.path.join(out_dir, name + ".zip")
    count = 0
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as zf:
        for base, dirs, files in os.walk(src):
            dirs[:] = sorted(d for d in dirs if d not in SKIP_DIRS)
            for f in sorted(files):
                full = os.path.join(base, f)
                zf.write(full, os.path.join(name, os.path.relpath(full, src)))
                count += 1
        if name == "tkp-nz-audit":
            for rel_src, rel_dst in SHARED:
                zf.write(os.path.join(SKILLS, rel_src), os.path.join(name, rel_dst))
                count += 1
    prompt_src, prompt_name = PROMPTS[name]
    with open(os.path.join(ROOT, prompt_src), encoding="utf-8") as fh, \
            open(os.path.join(out_dir, prompt_name), "w", encoding="utf-8") as out:
        out.write(fh.read())
    return path, count, os.path.getsize(path)


def main():
    out_dir = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, "dist")
    os.makedirs(out_dir, exist_ok=True)
    for name in ("tkp-spec-check", "tkp-nz-audit"):
        path, count, size = pack(name, out_dir)
        print("%s: %d файлов, %.1f МБ" % (path, count, size / 1024 / 1024))
    return 0


if __name__ == "__main__":
    sys.exit(main())
