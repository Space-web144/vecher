#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
qa_nz.py — машинная приёмка результата проверки ТКП по НЗ (лист «ДР_Аудит» / «РВР_Аудит» / «Аудит_НЗ»).

    python qa_nz.py РЕЗУЛЬТАТ.xlsx [--orig ИСХОДНЫЙ_ТКП.xlsx] [--positions N] [--expect "✅=10,⚠️=20,❌=0"] [--json]

Проверки (error — результат не принимается, warn — показать проверяющему):
  not_libreoffice_saved   книгу не пересохраняли LibreOffice                                   error
  audit_sheet             есть лист аудита                                                     error
  orig_parts_bytes        части исходной книги в результате байт-в-байт (кроме тех, что
                          меняет xlsx_add_sheet.py: workbook.xml, его .rels, [Content_Types],
                          styles.xml, docProps/app.xml)                                         warn
  orig_values             значения исходных листов не изменились (сравнение численно)          error
  statuses                в колонке «Статус» только утверждённые статусы                        error
  positions               строк со статусом, кроме «Позиция ТКП без основания в НЗ», = числу позиций НЗ  error
  status_counts           распределение статусов совпадает с --expect                          error
  verdict                 вердикт есть и это одна из утверждённых фраз (решение 31.10.2026)     error
  font                    только Times New Roman                                               error
  status_fill             заливка ячейки статуса соответствует статусу (✅ / ⚠️ / ❌)          warn
  empty_cells             пустых ячеек в строках таблицы нет (должно быть «—»)                 warn
  formula_cache           у формул листа аудита есть кэш значений                              warn
Код выхода 0 — ошибок нет (предупреждения допускаются).
"""
import argparse
import json
import re
import sys
import zipfile
from collections import Counter

AUDIT_SHEETS = ("ДР_Аудит", "РВР_Аудит", "Аудит_НЗ")

# Статусы: SKILL.md (ДР — инструкция заказчика + расширение практики; РВР) и принятые проверки 30.09–31.10.2026.
STATUSES = [
    # ДР
    "✅ Добавлено верно (зелёный, смысл совпадает)",
    "❌ Отсутствует смысловой аналог в ТКП",
    "⚠️ Добавлено, но не выделено зелёным",
    "⚠️ Название сильно отличается — проверь вручную",
    "⚠️ Объём не совпадает с НЗ — проверь вручную",
    # РВР
    "✅ Учтено верно",
    "⚠️ Расхождение по номенклатуре / объёму",
    "❌ Отсутствует в ТКП",
    "⚠️ Позиция ТКП без основания в НЗ",
    # сверка цен (лист «Сверка_цен», режим НЗ + счета)
    "✅ Цена подтверждена счётом",
    "⚠️ Подтверждена с оговоркой",
    "❌ Счёт в архиве не найден",
    "❌ Цена счетами не подтверждена",
    "⚠️ Цена ниже счёта",
    "⚠️ Цена выше счёта",
]
# Вердикт — строго одна из фраз (решение 31.10.2026); пояснения — отдельным текстом ниже.
VERDICTS = ("Все новые позиции учтены в листе «Изменения» (с учётом синонимов)",
            "Все новые позиции учтены в листе \"Изменения\" (с учётом синонимов)",
            "Все позиции НЗ учтены в ТКП (с учётом синонимов)",                      # РВР
            "Обнаружены пропуски или смысловые несоответствия. Список в таблице")
EXTRA_STATUS = "⚠️ Позиция ТКП без основания в НЗ"   # строка ТКП сверх НЗ (обратная проверка) — не позиция НЗ
FILL_OF = {"✅": "C6EFCE", "⚠": "FFEB9C", "❌": "FFC7CE"}
CHANGED_PARTS = {"xl/workbook.xml", "xl/_rels/workbook.xml.rels", "[Content_Types].xml", "xl/styles.xml",
                 "docProps/app.xml", "docProps/core.xml"}


def norm_status(text):
    """Варианты написания одного статуса: «проверь/проверить», «объёму / номенклатуре», пробелы, хвосты в скобках."""
    s = re.sub(r"\s+", " ", str(text or "")).strip()
    s = s.replace("проверить вручную", "проверь вручную").replace("⚠ ", "⚠️ ")
    s = s.replace("Расхождение по объёму / номенклатуре", "Расхождение по номенклатуре / объёму")
    s = s.replace("Объём не совпадает — проверь вручную", "Объём не совпадает с НЗ — проверь вручную")
    if s == "⚠️ Объём не совпадает":
        s = "⚠️ Объём не совпадает с НЗ — проверь вручную"
    return s


def base_status(text):
    """Статус без уточнения в скобках: «⚠️ Цена ниже счёта (применена цена …)» → для подсчёта — как есть, для
    сверки со списком — по началу."""
    s = norm_status(text)
    for st in STATUSES:
        if s == st or s.startswith(st):
            return st
    return None


def kind(status):
    return "✅" if status.startswith("✅") else "❌" if status.startswith("❌") else "⚠"


def add(checks, cid, ok, detail, level="error"):
    checks.append({"id": cid, "ok": bool(ok), "level": level, "detail": detail})


def same(a, b):
    if isinstance(a, (int, float)) and isinstance(b, (int, float)) and not isinstance(a, bool) and not isinstance(b, bool):
        return abs(a - b) <= 1e-9 * max(1.0, abs(a))
    return str(a) == str(b)


def find_header(ws):
    """(строка шапки, номер колонки «Статус»)."""
    for r in range(1, min(ws.max_row, 40) + 1):
        for c in range(1, min(ws.max_column, 30) + 1):
            v = ws.cell(r, c).value
            if isinstance(v, str) and v.strip() == "Статус":
                return r, c
    return None, None


def check_sheet(ws, wv, checks, stats, args, main=True):
    hdr, col = find_header(ws)
    title = ws.title
    if not hdr:
        add(checks, f"statuses:{title}", False, f"«{title}»: нет колонки «Статус» в шапке")
        return
    ncol = max(c for c in range(1, ws.max_column + 1) if ws.cell(hdr, c).value not in (None, ""))
    rows, bad, unknown, fills, empties = [], [], [], [], []
    for r in range(hdr + 1, ws.max_row + 1):
        v = ws.cell(r, col).value
        if not (isinstance(v, str) and v.strip()[:1] in "✅⚠❌"):
            continue
        st = base_status(v)
        rows.append((r, st or norm_status(v)))
        if not st:
            unknown.append(f"стр. {r}: «{str(v)[:60]}»")
        cell = ws.cell(r, col)
        rgb = (cell.fill.fgColor.rgb or "") if cell.fill is not None and cell.fill.fill_type == "solid" else ""
        want = FILL_OF[kind(st or norm_status(v))]
        if not str(rgb).upper().endswith(want):
            fills.append(f"стр. {r}: {rgb or 'без заливки'} при {kind(st or norm_status(v))}")
        for c in range(1, ncol + 1):
            if ws.cell(r, c).value in (None, ""):
                empties.append(f"{ws.cell(r, c).coordinate}")
    counts = Counter(st for _, st in rows)
    stats[title] = {"rows": len(rows), "statuses": dict(counts)}
    add(checks, f"statuses:{title}", not unknown,
        f"«{title}»: {len(rows)} строк со статусом; неутверждённые: {unknown[:8]}" if unknown else f"«{title}»: {len(rows)} строк, {dict(counts)}")
    add(checks, f"status_fill:{title}", not fills, f"заливка не по статусу: {fills[:6]}" if fills else "заливка по статусу", "warn")
    add(checks, f"empty_cells:{title}", not empties,
        f"пустые ячейки в строках таблицы ({len(empties)}): {empties[:10]} — по инструкции TNR должно быть «—»" if empties else "пустых ячеек нет", "warn")
    if main and args.positions is not None:
        extra = sum(1 for _, st in rows if st == EXTRA_STATUS)
        add(checks, "positions", len(rows) - extra == args.positions,
            f"строк позиций НЗ {len(rows) - extra} (+ {extra} строк ТКП без основания в НЗ), позиций НЗ {args.positions}")
    if main and args.expect:
        want = {}
        for part in args.expect.split(","):
            k, _, n = part.partition("=")
            want[k.strip()[:1]] = int(n)
        got = Counter(kind(st)[:1] for _, st in rows)
        diff = {k: (got.get(k, 0), n) for k, n in want.items() if got.get(k, 0) != n}
        add(checks, "status_counts", not diff, f"по виду статуса (есть, ожидалось): {diff}" if diff else f"совпадает: {dict(got)}")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("path")
    ap.add_argument("--orig")
    ap.add_argument("--positions", type=int)
    ap.add_argument("--expect", help="ожидаемое число строк по виду статуса: «✅=10,⚠️=20,❌=0»")
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()
    from openpyxl import load_workbook

    checks, stats = [], {}
    with zipfile.ZipFile(args.path) as z:
        app = z.read("docProps/app.xml").decode("utf-8", "ignore") if "docProps/app.xml" in z.namelist() else ""
    add(checks, "not_libreoffice_saved", "LibreOffice" not in app, "книга сохранена LibreOffice — так отдавать нельзя"
        if "LibreOffice" in app else "не пересохранялась LibreOffice")

    wb = load_workbook(args.path)
    wv = load_workbook(args.path, data_only=True)
    audit = [n for n in wb.sheetnames if n in AUDIT_SHEETS]
    add(checks, "audit_sheet", bool(audit), f"лист аудита: {audit[0]}" if audit else f"нет листа {AUDIT_SHEETS}; листы: {wb.sheetnames}")

    if args.orig:
        with zipfile.ZipFile(args.orig) as zo, zipfile.ZipFile(args.path) as zr:
            names = set(zr.namelist())
            diff = [n for n in zo.namelist() if n not in CHANGED_PARTS and (n not in names or zo.read(n) != zr.read(n))]
        add(checks, "orig_parts_bytes", not diff, f"изменены части исходной книги: {diff[:8]}" if diff else "исходные части байт-в-байт", "warn")
        ow = load_workbook(args.orig)
        changed = []
        for name in ow.sheetnames:
            if name not in wb.sheetnames:
                changed.append(f"нет листа «{name}»")
                continue
            so, sn = ow[name], wb[name]
            for r in range(1, max(so.max_row, sn.max_row) + 1):
                for c in range(1, max(so.max_column, sn.max_column) + 1):
                    if not same(so.cell(r, c).value, sn.cell(r, c).value):
                        changed.append(f"{name}!{so.cell(r, c).coordinate}")
        add(checks, "orig_values", not changed, f"изменены ячейки исходной книги: {changed[:10]}" if changed else "исходные листы не изменены")

    for i, name in enumerate(audit[:1] + [n for n in wb.sheetnames if n == "Сверка_цен"]):
        check_sheet(wb[name], wv[name], checks, stats, args, main=(i == 0))

    if audit:
        ws = wb[audit[0]]
        verdict = None
        for row in ws.iter_rows():
            for cell in row:
                v = cell.value
                if isinstance(v, str) and (re.match(r"\s*(ИТОГОВЫЙ\s+)?ВЕРДИКТ", v, re.I)
                                           or any(v.strip().rstrip(".") == p.rstrip(".") for p in VERDICTS)):
                    verdict = v
        if verdict is None:
            add(checks, "verdict", False, "вердикта нет")
        else:
            phrase = re.sub(r"^\s*(ИТОГОВЫЙ\s+)?ВЕРДИКТ\s*:?\s*", "", verdict, flags=re.I).strip().rstrip(".")
            std = any(phrase == p.rstrip(".") for p in VERDICTS)
            add(checks, "verdict", std, ("вердикт: " if std else "вердикт не одной из утверждённых фраз (пояснения — отдельным текстом): ")
                + verdict[:160])
        fonts = Counter()
        for row in ws.iter_rows():
            for cell in row:
                if cell.value not in (None, "") and cell.font is not None:
                    fonts[cell.font.name] += 1
        other = {k: v for k, v in fonts.items() if k != "Times New Roman"}
        add(checks, "font", not other, f"не Times New Roman: {other}" if other else "Times New Roman")
        wsv = wv[audit[0]]
        nocache = [c.coordinate for row in ws.iter_rows() for c in row
                   if isinstance(c.value, str) and c.value.startswith("=") and wsv[c.coordinate].value is None]
        add(checks, "formula_cache", not nocache,
            f"формулы без кэша значений ({len(nocache)}), напр. {nocache[:5]} — значения появятся только после пересчёта в Excel" if nocache
            else "формулы с кэшем или их нет", "warn")

    passed = all(c["ok"] for c in checks if c["level"] == "error")
    out = {"file": args.path, "passed": passed, "checks": checks, "stats": stats}
    if args.json:
        print(json.dumps(out, ensure_ascii=False, indent=1))
    else:
        for c in checks:
            mark = "OK  " if c["ok"] else ("FAIL" if c["level"] == "error" else "WARN")
            print(f"{mark} {c['id']}: {c['detail']}")
        print("ПРИНЯТО" if passed else "НЕ ПРИНЯТО")
    return 0 if passed else 1


if __name__ == "__main__":
    sys.exit(main())
