#!/usr/bin/env python3
"""
xlsx_set_cells.py — записать значения в ячейки существующего листа .xlsx БЕЗ пересохранения книги.

Для режима «сверка со счетами»: заполнить колонки AN (цена по счёту), AO (наименование
по счёту), AP (№ счёта и пункт) на листе «Счета», не трогая остальное.

Меняется только XML одного листа (и только затронутые строки); все прочие части пакета
копируются байт-в-байт. Стиль ячейки (атрибут s) сохраняется, если ячейка уже была.
Ячейки с формулами не перезаписываются (иначе ломается calcChain) — скрипт остановится.

Использование:
  python xlsx_set_cells.py ИСХОДНЫЙ.xlsx cells.json РЕЗУЛЬТАТ.xlsx

cells.json:
{
  "sheet": "Счета",
  "cells": {
    "AN16": 850.0,
    "AO16": "Воздуховоды прямоугольного сечения / 0,8 мм / ...",
    "AP16": "Уведомление о результатах тендера от 08.09.2026 (ЗАВОД ГИПЕРВЕНТ, ТУ), п.7"
  }
}
Числа записываются числами, строки — inline-строками.
"""
import json
import posixpath
import re
import sys
import zipfile
from xml.sax.saxutils import escape

_ILLEGAL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")
REF = re.compile(r"^([A-Z]{1,3})(\d+)$")


def col_index(letters):
    n = 0
    for ch in letters:
        n = n * 26 + (ord(ch) - 64)
    return n


def col_letter(n):
    s = ""
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


def unescape_attr(s):
    return (s.replace("&quot;", '"').replace("&apos;", "'").replace("&lt;", "<")
            .replace("&gt;", ">").replace("&amp;", "&"))


def cell_xml(ref, value, style):
    s = f' s="{style}"' if style is not None else ""
    if isinstance(value, bool):
        value = "Да" if value else "Нет"
    if isinstance(value, (int, float)):
        v = int(value) if float(value).is_integer() else repr(float(value))
        return f'<c r="{ref}"{s}><v>{v}</v></c>'
    t = escape(_ILLEGAL.sub("", str(value)))
    return f'<c r="{ref}"{s} t="inlineStr"><is><t xml:space="preserve">{t}</t></is></c>'


def find_sheet_path(data, sheet_name):
    root_rels = data["_rels/.rels"].decode("utf-8")
    m = re.search(r'<Relationship\b[^>]*Type="[^"]*/officeDocument"[^>]*>', root_rels)
    wb_path = re.search(r'Target="([^"]+)"', m.group(0)).group(1).lstrip("/")
    wb_dir = posixpath.dirname(wb_path)
    wb_xml = data[wb_path].decode("utf-8")
    rels_xml = data[posixpath.join(wb_dir, "_rels", posixpath.basename(wb_path) + ".rels")].decode("utf-8")
    rid = None
    for tag in re.findall(r"<sheet\b[^>]*>", wb_xml):
        name = re.search(r'\bname="([^"]*)"', tag)
        if name and unescape_attr(name.group(1)) == sheet_name:
            rid = re.search(r'\b\w+:id="([^"]+)"', tag).group(1)
    if rid is None:
        names = [unescape_attr(x) for x in re.findall(r'<sheet\b[^>]*\bname="([^"]*)"', wb_xml)]
        raise ValueError(f"Нет листа «{sheet_name}». Есть: {names}")
    for rel in re.findall(r"<Relationship\b[^>]*>", rels_xml):
        if re.search(rf'\bId="{re.escape(rid)}"', rel):
            target = re.search(r'Target="([^"]+)"', rel).group(1)
            return target.lstrip("/") if target.startswith("/") else posixpath.normpath(posixpath.join(wb_dir, target))
    raise ValueError("Не найдена связь листа в workbook.xml.rels")


def set_cells(src, dst, sheet_name, cells):
    zin = zipfile.ZipFile(src)
    names = zin.namelist()
    data = {n: zin.read(n) for n in names}
    infos = {i.filename: i for i in zin.infolist()}
    sheet_path = find_sheet_path(data, sheet_name)
    xml = data[sheet_path].decode("utf-8")

    # нормализуем вход: {(row, col): (ref, value)}
    targets = {}
    for ref, val in cells.items():
        m = REF.match(ref.upper())
        if not m:
            raise ValueError(f"Некорректная ссылка: {ref}")
        targets[(int(m.group(2)), col_index(m.group(1)))] = (ref.upper(), val)
    by_row = {}
    for (r, c), (ref, val) in targets.items():
        by_row.setdefault(r, {})[c] = (ref, val)

    sd = re.search(r"<sheetData\b[^>]*>(.*)</sheetData>", xml, re.S)
    if sd is None:
        if re.search(r"<sheetData\b[^>]*/>", xml):
            xml = re.sub(r"<sheetData\b[^>]*/>", "<sheetData></sheetData>", xml, 1)
            sd = re.search(r"<sheetData\b[^>]*>(.*)</sheetData>", xml, re.S)
        else:
            raise ValueError("В листе нет sheetData")
    body = sd.group(1)
    rows = []
    for m in re.finditer(r"<row\b[^>]*?(?:/>|>.*?</row>)", body, re.S):
        rnum = int(re.search(r'\br="(\d+)"', m.group(0)).group(1))
        rows.append([rnum, m.group(0)])
    existing = {r for r, _ in rows}

    def rebuild_row(row_xml, rnum, updates):
        open_tag = re.match(r"<row\b[^>]*?(?=/?>)", row_xml).group(0)
        open_tag = re.sub(r'\s+spans="[^"]*"', "", open_tag)
        inner = "" if row_xml.rstrip().endswith("/>") and "</row>" not in row_xml else \
            re.search(r"<row\b[^>]*>(.*)</row>", row_xml, re.S).group(1)
        cells_found = []
        for cm in re.finditer(r"<c\b[^>]*?(?:/>|>.*?</c>)", inner, re.S):
            cx = cm.group(0)
            rm = re.search(r'\br="([A-Z]+)(\d+)"', cx)
            if not rm:
                raise ValueError(f"Строка {rnum}: ячейка без адреса — запись небезопасна")
            cells_found.append([col_index(rm.group(1)), cx])
        index = {c: i for i, (c, _) in enumerate(cells_found)}
        for c, (ref, val) in updates.items():
            style = None
            if c in index:
                old = cells_found[index[c]][1]
                if "<f" in old:
                    raise ValueError(f"{ref}: в ячейке формула — не перезаписываю")
                sm = re.search(r'\bs="(\d+)"', old)
                style = sm.group(1) if sm else None
                cells_found[index[c]][1] = cell_xml(ref, val, style)
            else:
                cells_found.append([c, cell_xml(ref, val, style)])
        cells_found.sort(key=lambda x: x[0])
        return f"{open_tag}>{''.join(x for _, x in cells_found)}</row>"

    for item in rows:
        if item[0] in by_row:
            item[1] = rebuild_row(item[1], item[0], by_row[item[0]])
    for rnum in sorted(set(by_row) - existing):
        rows.append([rnum, rebuild_row(f'<row r="{rnum}"/>', rnum, by_row[rnum])])
    rows.sort(key=lambda x: x[0])
    new_body = "".join(x for _, x in rows)
    xml = xml[: sd.start(1)] + new_body + xml[sd.end(1):]

    # размер листа
    dm = re.search(r'<dimension ref="([A-Z]+)(\d+)(?::([A-Z]+)(\d+))?"\s*/>', xml)
    if dm:
        c2 = col_index(dm.group(3) or dm.group(1))
        r2 = int(dm.group(4) or dm.group(2))
        c2 = max(c2, max(c for _, c in targets))
        r2 = max(r2, max(r for r, _ in targets))
        xml = xml[: dm.start()] + f'<dimension ref="{dm.group(1)}{dm.group(2)}:{col_letter(c2)}{r2}"/>' + xml[dm.end():]

    with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as zout:
        for n in names:
            zout.writestr(infos[n], xml.encode("utf-8") if n == sheet_path else data[n])

    # проверка
    a, b = zipfile.ZipFile(src), zipfile.ZipFile(dst)
    for n in a.namelist():
        if n != sheet_path and a.read(n) != b.read(n):
            raise RuntimeError(f"Часть {n} изменилась — так быть не должно")
    try:
        import openpyxl
        wb = openpyxl.load_workbook(dst, read_only=False, data_only=True)
        ws = wb[sheet_name]
        for (r, c), (ref, val) in targets.items():
            got = ws[ref].value
            if isinstance(val, (int, float)):
                assert got is not None and abs(float(got) - float(val)) < 1e-9, f"{ref}: {got!r} ≠ {val!r}"
            else:
                assert str(got) == _ILLEGAL.sub("", str(val)), f"{ref}: значение не совпало"
    except ImportError:
        print("openpyxl не установлен — пропущена проверка открытия книги")
    return sheet_path, len(targets)


def main():
    if len(sys.argv) != 4:
        print(__doc__)
        sys.exit(1)
    src, spec_path, dst = sys.argv[1:]
    with open(spec_path, encoding="utf-8") as fh:
        spec = json.load(fh)
    path, n = set_cells(src, dst, spec["sheet"], spec["cells"])
    print(f"Готово: {dst}\n  лист «{spec['sheet']}» ({path}): записано ячеек {n}; остальные части книги не изменены")


if __name__ == "__main__":
    main()
