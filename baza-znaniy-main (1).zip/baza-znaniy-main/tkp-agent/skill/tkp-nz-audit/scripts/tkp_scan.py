#!/usr/bin/env python3
"""
tkp_scan.py — инвентаризация Excel-файла ТКП.

Что делает:
  * без параметров — обзор книги: листы, размеры, распределение заливок
    в колонках A и C, число строк с упоминанием НЗ в колонке E;
  * --sheet ИМЯ — подробный разбор листа: заливка строки (по большинству
    ячеек A:U), заливка колонки C, тексты C и E;
  * --fill EBF1DE — только строки с такой заливкой строки (ARGB или RGB);
  * --grep РЕГВЫР — только строки, где колонка E (или --grep-cols) совпадает;
  * --compare ДРУГОЙ_ЛИСТ — строки, где заливка строки или текст C отличаются
    от другого листа (для поиска добавленного на «Изменениях» против «ТКП»);
  * --out файл.csv — выгрузка выбранных строк (все колонки диапазона).

Файл открывается только на чтение (data_only=True — кэшированные значения
формул). Исходник не изменяется.

Примеры:
  python tkp_scan.py ТКП.xlsx
  python tkp_scan.py ТКП.xlsx --sheet Изменения --fill EBF1DE --out added.csv
  python tkp_scan.py ТКП.xlsx --sheet Изменения --compare ТКП --out diff.csv
  python tkp_scan.py ТКП.xlsx --sheet Изменения --grep "НЗ\\s*№?\\s*21"
"""
import argparse
import csv
import re
import sys
from collections import Counter

try:
    import openpyxl
    from openpyxl.utils import column_index_from_string, get_column_letter
except ImportError:  # pragma: no cover
    sys.exit("Нужен openpyxl: pip install openpyxl")

# «НЗ» как наряд-заказ: заглавными и с номером («НЗ №21», «НЗ 46») — без регистра совпадало с «-нз-» в кодах клапанов
DEFAULT_GREP = r"(?<![А-Яа-яЁёA-Za-z-])Н\s?З\s*№?\s*\d|[Нн]аряд[-\s]?заказ"


def fill_code(cell):
    """Код заливки ячейки: 'EBF1DE' для RGB, 'theme4+0.40', 'indexed43' или ''."""
    f = cell.fill
    if f is None or f.fill_type in (None, "none"):
        return ""
    c = f.fgColor
    if c is None:
        return ""
    if c.type == "rgb" and isinstance(c.rgb, str):
        rgb = c.rgb.upper()
        if rgb in ("00000000",):
            return ""
        return rgb[-6:]
    if c.type == "theme":
        tint = f"{c.tint:+.2f}" if c.tint else ""
        return f"theme{c.theme}{tint}"
    if c.type == "indexed":
        return f"indexed{c.indexed}"
    return ""


def norm_hex(s):
    s = (s or "").strip().upper().lstrip("#")
    return s[-6:] if len(s) >= 6 else s


def row_fill(ws, r, c1, c2):
    """Заливка строки — самый частый код среди ячеек c1..c2 (если он покрывает ≥ половины)."""
    codes = [fill_code(ws.cell(row=r, column=c)) for c in range(c1, c2 + 1)]
    cnt = Counter(codes)
    code, n = cnt.most_common(1)[0]
    return code if n * 2 >= len(codes) else "смешанная"


def text(v):
    if v is None:
        return ""
    if isinstance(v, float):
        return f"{v:.6g}"
    return str(v).replace("\n", " ").strip()


def parse_range(rng):
    a, b = rng.upper().split(":")
    return column_index_from_string(a), column_index_from_string(b)


def overview(wb, c1, c2, grep_re):
    print(f"Листов: {len(wb.sheetnames)}")
    for ws in wb.worksheets:
        print(f"\n=== Лист «{ws.title}»: строк {ws.max_row}, колонок {ws.max_column}")
        fa, fc = Counter(), Counter()
        nz_rows = 0
        for r in range(1, ws.max_row + 1):
            fa[fill_code(ws.cell(row=r, column=1))] += 1
            fc[fill_code(ws.cell(row=r, column=3))] += 1
            e = text(ws.cell(row=r, column=5).value)
            if e and grep_re.search(e):
                nz_rows += 1
        show = lambda cnt: ", ".join(f"{k or 'нет'}: {v}" for k, v in cnt.most_common(6))
        print(f"  заливка кол. A: {show(fa)}")
        print(f"  заливка кол. C: {show(fc)}")
        print(f"  строк с упоминанием НЗ в кол. E: {nz_rows}")
        # первые непустые строки — чтобы увидеть шапку
        shown = 0
        for r in range(1, min(ws.max_row, 40) + 1):
            vals = [text(ws.cell(row=r, column=c).value) for c in range(1, min(ws.max_column, 21) + 1)]
            if sum(1 for v in vals if v) >= 3:
                print(f"  стр. {r}: " + " | ".join(v[:30] for v in vals if v)[:300])
                shown += 1
                if shown >= 4:
                    break


def main():
    ap = argparse.ArgumentParser(description="Инвентаризация файла ТКП (только чтение).")
    ap.add_argument("xlsx")
    ap.add_argument("--sheet", help="лист для подробного разбора")
    ap.add_argument("--cols", default="A:U", help="диапазон колонок строки (по умолчанию A:U)")
    ap.add_argument("--fill", help="показать только строки с этой заливкой строки, напр. EBF1DE")
    ap.add_argument("--grep", nargs="?", const=DEFAULT_GREP,
                    help="показать только строки, где текст совпадает с регулярным выражением "
                         "(без значения — поиск упоминаний НЗ)")
    ap.add_argument("--grep-cols", default="E", help="колонки для --grep через запятую (по умолчанию E)")
    ap.add_argument("--compare", help="другой лист для построчного сравнения заливки и текста C")
    ap.add_argument("--start", type=int, default=1, help="первая строка (по умолчанию 1)")
    ap.add_argument("--out", help="CSV для выгрузки выбранных строк (UTF-8 с BOM, разделитель ;)")
    ap.add_argument("--limit", type=int, default=200, help="сколько строк печатать в консоль")
    args = ap.parse_args()

    wb = openpyxl.load_workbook(args.xlsx, data_only=True)
    c1, c2 = parse_range(args.cols)
    grep_re = re.compile(args.grep, re.I) if args.grep else re.compile(DEFAULT_GREP)

    if not args.sheet:
        overview(wb, c1, c2, grep_re)
        return

    if args.sheet not in wb.sheetnames:
        sys.exit(f"Нет листа «{args.sheet}». Есть: {wb.sheetnames}")
    ws = wb[args.sheet]
    ws2 = None
    if args.compare:
        if args.compare not in wb.sheetnames:
            sys.exit(f"Нет листа «{args.compare}». Есть: {wb.sheetnames}")
        ws2 = wb[args.compare]
        if ws2.max_row != ws.max_row:
            print(f"ВНИМАНИЕ: листы разной длины — «{ws.title}» {ws.max_row} строк, «{ws2.title}» {ws2.max_row}. "
                  "Сравнение построчное: после первой вставленной или удалённой строки пары сдвинуты, "
                  "поэтому добавленные строки ищите по заливке (--fill EBF1DE), а не по отличию текста.")

    want_fill = norm_hex(args.fill) if args.fill else None
    grep_cols = [column_index_from_string(x.strip().upper()) for x in args.grep_cols.split(",")]

    selected = []
    for r in range(args.start, ws.max_row + 1):
        vals = [ws.cell(row=r, column=c).value for c in range(c1, c2 + 1)]
        if not any(v not in (None, "") for v in vals):
            continue
        rf = row_fill(ws, r, c1, c2)
        fc = fill_code(ws.cell(row=r, column=3))
        rec = {"row": r, "row_fill": rf, "fill_C": fc,
               "C": text(ws.cell(row=r, column=3).value),
               "E": text(ws.cell(row=r, column=5).value)}
        if want_fill and rf != want_fill:
            continue
        if args.grep is not None:
            hay = " ".join(text(ws.cell(row=r, column=g).value) for g in grep_cols)
            if not grep_re.search(hay):
                continue
        if ws2 is not None:
            rf2 = row_fill(ws2, r, c1, c2)
            c_other = text(ws2.cell(row=r, column=3).value)
            diffs = []
            if rf2 != rf:
                diffs.append(f"заливка {rf2 or 'нет'} → {rf or 'нет'}")
            if c_other != rec["C"]:
                diffs.append("текст C отличается")
            if not diffs:
                continue
            rec["diff"] = "; ".join(diffs)
        for i, c in enumerate(range(c1, c2 + 1)):
            rec[get_column_letter(c)] = text(vals[i])
        selected.append(rec)

    print(f"Лист «{ws.title}»: выбрано строк {len(selected)}"
          + (f" (заливка {want_fill})" if want_fill else "")
          + (f", сравнение с «{ws2.title}»" if ws2 is not None else ""))
    print("Заливки строк среди выбранных:",
          ", ".join(f"{k or 'нет'}: {v}" for k, v in Counter(x['row_fill'] for x in selected).most_common()))
    for rec in selected[: args.limit]:
        extra = f" [{rec['diff']}]" if "diff" in rec else ""
        print(f"стр. {rec['row']:>5} | строка {rec['row_fill'] or 'нет':>10} | C {rec['fill_C'] or 'нет':>8} | "
              f"{rec['C'][:70]} || E: {rec['E'][:60]}{extra}")
    if len(selected) > args.limit:
        print(f"... ещё {len(selected) - args.limit} строк (полностью — в --out)")

    if args.out:
        letters = [get_column_letter(c) for c in range(c1, c2 + 1)]
        fields = ["row", "row_fill", "fill_C"] + (["diff"] if ws2 is not None else []) + letters
        with open(args.out, "w", newline="", encoding="utf-8-sig") as fh:
            w = csv.DictWriter(fh, fieldnames=fields, delimiter=";", extrasaction="ignore")
            w.writeheader()
            for rec in selected:
                w.writerow(rec)
        print(f"Записано: {args.out}")


if __name__ == "__main__":
    main()
