#!/usr/bin/env python3
"""
xlsx_add_sheet.py — добавить лист аудита в существующий .xlsx БЕЗ пересохранения книги.

Почему так: сохранение ТКП через openpyxl/LibreOffice теряет кэш формул,
условное форматирование, calcChain и часть оформления. Скрипт дописывает
новый лист прямо в XML-пакет: меняются только workbook.xml, его .rels,
[Content_Types].xml и styles.xml (добавляются шрифты/заливки/стили в конец),
все остальные части копируются байт-в-байт. После записи скрипт сам
проверяет, что исходные части не изменились и книга открывается.

Оформление — по инструкции «Times New Roman, строгий режим»:
  шапка 12 pt жирный, текст 12 pt, итоги/вердикт 14 pt жирный, примечания 10 pt;
  пустые ячейки → «—»; числа с разделителем разрядов (#,##0 / #,##0.00).
Строки основной таблицы окрашиваются по колонке статуса:
  ✅ → зелёный, ⚠ → жёлтый, ❌ → красный.

Использование:
  python xlsx_add_sheet.py ИСХОДНЫЙ.xlsx spec.json РЕЗУЛЬТАТ.xlsx

spec.json:
{
  "sheet_name": "ДР_Аудит",
  "title": "Аудит ДР: <объект> — смета <N>, версия <M>",        (необязательно)
  "subtitle": ["Дата проверки: ...", "Эталон: НЗ №..."],          (необязательно)
  "columns": [{"header": "Что требуется по НЗ", "width": 55}, ...],
  "rows": [["...", "...", "Да", "Зелёный", "✅ Добавлено верно", "Оставить", "стр. 45"], ...],
  "status_column": 5,                       (номер колонки статуса, с 1; необязательно)
  "summary": [["Статус", "Кол-во", "Доля, %"], ["✅ Добавлено верно", 129, 46.7], ...],
  "verdict": "Обнаружены пропуски или смысловые несоответствия. Список в таблице",
  "notes": ["Примечание 1", "..."]
}
Можно импортировать: from xlsx_add_sheet import add_sheet; add_sheet(src, dst, spec)
"""
import json
import math
import posixpath
import re
import sys
import zipfile
from xml.sax.saxutils import escape

NS_REL_WS = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet"
CT_WS = "application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"
FONT = "Times New Roman"
FILLS = {"header": "FFD9D9D9", "ok": "FFC6EFCE", "warn": "FFFFEB9C", "bad": "FFFFC7CE"}
_ILLEGAL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f]")


# ---------- утилиты ----------
def col_letter(n):
    s = ""
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


def xml_text(s):
    return escape(_ILLEGAL.sub("", str(s)))


def xml_attr(s):
    return escape(_ILLEGAL.sub("", str(s)), {'"': "&quot;"})


def unescape_attr(s):
    return (s.replace("&quot;", '"').replace("&apos;", "'").replace("&lt;", "<")
            .replace("&gt;", ">").replace("&amp;", "&"))


def count_children(block, tag):
    return len(re.findall(r"<%s[\s>/]" % tag, block))


def append_to_block(xml, tag, items_xml):
    """Дописать элементы в конец <tag>…</tag>, обновить count. Вернуть (xml, индекс первого нового)."""
    m = re.search(r"<%s\b([^>]*)/>" % tag, xml)
    if m:  # пустой самозакрытый блок
        start = 0
        new = "<%s count=\"%d\">%s</%s>" % (tag, len(items_xml), "".join(items_xml), tag)
        return xml[: m.start()] + new + xml[m.end():], start
    m = re.search(r"<%s\b([^>]*)>(.*?)</%s>" % (tag, tag), xml, re.S)
    if not m:
        raise ValueError(f"в styles.xml нет блока <{tag}>")
    attrs, body = m.group(1), m.group(2)
    child = tag[:-1] if tag != "cellXfs" else "xf"
    start = count_children(body, child)
    total = start + len(items_xml)
    if re.search(r'\bcount="\d+"', attrs):
        attrs = re.sub(r'\bcount="\d+"', f'count="{total}"', attrs)
    else:
        attrs = attrs + f' count="{total}"'
    new = "<%s%s>%s%s</%s>" % (tag, attrs, body, "".join(items_xml), tag)
    return xml[: m.start()] + new + xml[m.end():], start


# ---------- стили ----------
class Styles:
    FONT_DEF = {
        "r12": '<font><sz val="12"/><name val="%s"/><family val="1"/><charset val="204"/></font>' % FONT,
        "b12": '<font><b/><sz val="12"/><name val="%s"/><family val="1"/><charset val="204"/></font>' % FONT,
        "b14": '<font><b/><sz val="14"/><name val="%s"/><family val="1"/><charset val="204"/></font>' % FONT,
        "r10": '<font><sz val="10"/><name val="%s"/><family val="1"/><charset val="204"/></font>' % FONT,
    }
    BORDER = ('<border><left style="thin"><color indexed="64"/></left><right style="thin"><color indexed="64"/></right>'
              '<top style="thin"><color indexed="64"/></top><bottom style="thin"><color indexed="64"/></bottom>'
              '<diagonal/></border>')

    def __init__(self):
        self.xfs = []      # ключи стилей в порядке добавления
        self.index = {}

    def get(self, font="r12", fill=None, num=0, border=True, h="left", v="top", wrap=True):
        key = (font, fill, num, border, h, v, wrap)
        if key not in self.index:
            self.index[key] = len(self.xfs)
            self.xfs.append(key)
        return key

    def inject(self, styles_xml):
        fonts = list(self.FONT_DEF)
        styles_xml, f0 = append_to_block(styles_xml, "fonts", [self.FONT_DEF[k] for k in fonts])
        fills = list(FILLS)
        fill_xml = ['<fill><patternFill patternType="solid"><fgColor rgb="%s"/><bgColor indexed="64"/>'
                    '</patternFill></fill>' % FILLS[k] for k in fills]
        styles_xml, fl0 = append_to_block(styles_xml, "fills", fill_xml)
        styles_xml, b0 = append_to_block(styles_xml, "borders", [self.BORDER])
        xf_xml = []
        for (font, fill, num, border, h, v, wrap) in self.xfs:
            font_id = f0 + fonts.index(font)
            fill_id = fl0 + fills.index(fill) if fill else 0
            border_id = b0 if border else 0
            xf_xml.append(
                '<xf numFmtId="%d" fontId="%d" fillId="%d" borderId="%d" xfId="0" applyNumberFormat="1" '
                'applyFont="1" applyFill="1" applyBorder="1" applyAlignment="1">'
                '<alignment horizontal="%s" vertical="%s"%s/></xf>'
                % (num, font_id, fill_id, border_id, h, v, ' wrapText="1"' if wrap else ""))
        styles_xml, x0 = append_to_block(styles_xml, "cellXfs", xf_xml)
        return styles_xml, {k: x0 + i for i, k in enumerate(self.xfs)}


def status_kind(s):
    s = str(s or "").strip()
    if s.startswith("✅"):
        return "ok"
    if s.startswith("⚠"):
        return "warn"
    if s.startswith("❌"):
        return "bad"
    return None


# ---------- лист ----------
def build_sheet_xml(spec, st):
    cols = spec["columns"]
    ncol = len(cols)
    widths = [float(c.get("width", 18)) for c in cols]
    status_col = spec.get("status_column")
    rows_xml = []
    r = 0
    cells_meta = []  # (row, [(col, value, stylekey)], height)

    def est_height(values, wlist, pt=12.0):
        lines = 1
        for val, w in zip(values, wlist):
            t = str(val) if val is not None else ""
            chars_per_line = max(4.0, w * 0.95)
            n = sum(max(1, math.ceil(len(part) * 1.1 / chars_per_line)) for part in t.split("\n"))
            lines = max(lines, n)
        return min(409.0, round(lines * pt * 1.32 + 3, 1))

    def add_row(cells, height=None):
        nonlocal r
        r += 1
        cells_meta.append((r, cells, height))

    if spec.get("title"):
        add_row([(1, spec["title"], st.get("b14", border=False, wrap=False))], 21)
    for line in spec.get("subtitle", []) or []:
        add_row([(1, line, st.get("r12", border=False, wrap=False))], 16)
    if spec.get("title") or spec.get("subtitle"):
        add_row([], None)

    header_row = r + 1
    add_row([(i + 1, c["header"], st.get("b12", fill="header", h="center", v="center")) for i, c in enumerate(cols)],
            est_height([c["header"] for c in cols], widths))

    for row in spec["rows"]:
        row = list(row) + [None] * (ncol - len(row))
        kind = status_kind(row[status_col - 1]) if status_col else None
        cells = []
        for i, val in enumerate(row[:ncol]):
            if val is None or (isinstance(val, str) and not val.strip()):
                val = "—"
            if isinstance(val, bool):
                val = "Да" if val else "Нет"
            if isinstance(val, (int, float)):
                num = 3 if isinstance(val, int) else 4
                key = st.get("r12", fill=kind, num=num, h="right")
            else:
                key = st.get("r12", fill=kind)
            cells.append((i + 1, val, key))
        add_row(cells, est_height([c[1] for c in cells], widths))
    last_table_row = r

    if spec.get("summary"):
        add_row([], None)
        summ = spec["summary"]
        for j, srow in enumerate(summ):
            # строка итога («Итого …», «Всего …») — 14 pt жирный (инструкция TNR: итоговые строки)
            total = j > 0 and bool(srow) and isinstance(srow[0], str) and re.match(r"\s*(итого|всего)", srow[0], re.I)
            font = "b14" if total else "r12"
            cells = []
            for i, val in enumerate(srow):
                if val is None or (isinstance(val, str) and not val.strip()):
                    val = "—"
                if j == 0:
                    key = st.get("b12", fill="header", h="center", v="center")
                elif isinstance(val, (int, float)):
                    key = st.get(font, num=3 if isinstance(val, int) else 4, h="right")
                else:
                    key = st.get(font)
                cells.append((i + 1, val, key))
            add_row(cells, est_height([c[1] for c in cells], widths[: len(cells)], 14.0 if total else 12.0))
    if spec.get("verdict"):
        add_row([], None)
        verdict = str(spec["verdict"]).strip()
        if not re.match(r"ВЕРДИКТ", verdict, re.I):
            verdict = "ВЕРДИКТ: " + verdict          # как в принятых проверках; qa_nz.py ищет вердикт по этой метке
        add_row([(1, verdict, st.get("b14", border=False, wrap=False))], 21)
    if spec.get("notes"):
        add_row([], None)
        for n in spec["notes"]:
            add_row([(1, n, st.get("r10", border=False, wrap=False))], 14)

    return header_row, last_table_row, ncol, widths, cells_meta


def render_sheet_xml(header_row, ncol, widths, cells_meta, xf_index):
    out = []
    for rnum, cells, height in cells_meta:
        attrs = f' r="{rnum}"'
        if height:
            attrs += f' ht="{height}" customHeight="1"'
        cx = []
        for c, val, key in cells:
            ref = f"{col_letter(c)}{rnum}"
            s = xf_index[key]
            if isinstance(val, (int, float)) and not isinstance(val, bool):
                cx.append(f'<c r="{ref}" s="{s}"><v>{val if isinstance(val, int) else repr(float(val))}</v></c>')
            else:
                cx.append(f'<c r="{ref}" s="{s}" t="inlineStr"><is><t xml:space="preserve">{xml_text(val)}</t></is></c>')
        out.append(f"<row{attrs}>{''.join(cx)}</row>")
    last_row = cells_meta[-1][0] if cells_meta else 1
    cols_xml = "".join(f'<col min="{i + 1}" max="{i + 1}" width="{w}" customWidth="1"/>' for i, w in enumerate(widths))
    pane = (f'<pane ySplit="{header_row}" topLeftCell="A{header_row + 1}" activePane="bottomLeft" state="frozen"/>'
            f'<selection pane="bottomLeft" activeCell="A{header_row + 1}" sqref="A{header_row + 1}"/>')
    return ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'
            '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
            'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            '<sheetPr><pageSetUpPr fitToPage="1"/></sheetPr>'
            f'<dimension ref="A1:{col_letter(ncol)}{last_row}"/>'
            f'<sheetViews><sheetView workbookViewId="0">{pane}</sheetView></sheetViews>'
            '<sheetFormatPr defaultRowHeight="15.75"/>'
            f'<cols>{cols_xml}</cols>'
            f'<sheetData>{"".join(out)}</sheetData>'
            '<pageMargins left="0.4" right="0.4" top="0.6" bottom="0.6" header="0.3" footer="0.3"/>'
            '<pageSetup paperSize="9" orientation="landscape" fitToWidth="1" fitToHeight="0"/>'
            '</worksheet>')


# ---------- пакет ----------
def add_sheet(src, dst, spec):
    name = spec["sheet_name"]
    if len(name) > 31 or re.search(r"[\[\]:*?/\\]", name):
        raise ValueError("Имя листа: не длиннее 31 символа и без []:*?/\\")

    zin = zipfile.ZipFile(src)
    names = zin.namelist()
    data = {n: zin.read(n) for n in names}
    infos = {i.filename: i for i in zin.infolist()}

    root_rels = data["_rels/.rels"].decode("utf-8")
    m = re.search(r'<Relationship\b[^>]*Type="[^"]*/officeDocument"[^>]*>', root_rels)
    wb_path = re.search(r'Target="([^"]+)"', m.group(0)).group(1).lstrip("/")
    wb_dir = posixpath.dirname(wb_path)
    wb_rels_path = posixpath.join(wb_dir, "_rels", posixpath.basename(wb_path) + ".rels")

    wb_xml = data[wb_path].decode("utf-8")
    rels_xml = data[wb_rels_path].decode("utf-8")
    ct_xml = data["[Content_Types].xml"].decode("utf-8")

    if "purl.oclc.org/ooxml" in wb_xml:
        raise ValueError("Strict OOXML не поддерживается — пересохраните исходник как обычный .xlsx")

    existing = [unescape_attr(x) for x in re.findall(r'<(?:\w+:)?sheet\b[^>]*\bname="([^"]*)"', wb_xml)]
    if name.lower() in (x.lower() for x in existing):
        raise ValueError(f"Лист «{name}» уже есть. Листы: {existing}")

    sm = re.search(r'Type="[^"]*/styles"[^>]*Target="([^"]+)"|Target="([^"]+)"[^>]*Type="[^"]*/styles"', rels_xml)
    styles_target = sm.group(1) or sm.group(2)
    styles_path = (styles_target.lstrip("/") if styles_target.startswith("/")
                   else posixpath.normpath(posixpath.join(wb_dir, styles_target)))
    styles_xml = data[styles_path].decode("utf-8")

    # номер нового листа и rId
    k = 1
    while posixpath.join(wb_dir, "worksheets", f"sheet{k}.xml") in data:
        k += 1
    sheet_path = posixpath.join(wb_dir, "worksheets", f"sheet{k}.xml")
    ids = [int(x) for x in re.findall(r'Id="rId(\d+)"', rels_xml)]
    rid = f"rId{max(ids, default=0) + 1}"
    while f'Id="{rid}"' in rels_xml:
        rid = f"rId{int(rid[3:]) + 1}"
    sheet_ids = [int(x) for x in re.findall(r'<(?:\w+:)?sheet\b[^>]*\bsheetId="(\d+)"', wb_xml)]
    sheet_id = max(sheet_ids, default=0) + 1

    # префикс пространства имён связей: берём из корневого <workbook>, иначе объявляем локально у нового <sheet>
    root_tag = re.search(r"<(?:\w+:)?workbook\b[^>]*>", wb_xml).group(0)
    rm = re.search(r'xmlns:(\w+)="http://schemas\.openxmlformats\.org/officeDocument/2006/relationships"', root_tag)
    if rm:
        rprefix, local_ns = rm.group(1), ""
    else:
        rprefix, local_ns = "r", ' xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"'

    # стили и XML листа
    st = Styles()
    header_row, last_table_row, ncol, widths, cells_meta = build_sheet_xml(spec, st)
    styles_xml, xf_index = st.inject(styles_xml)
    sheet_xml = render_sheet_xml(header_row, ncol, widths, cells_meta, xf_index)

    sheets_close = re.search(r"</(?:\w+:)?sheets>", wb_xml)
    sheet_prefix = re.match(r"</(\w+:)?", sheets_close.group(0)).group(1) or ""
    new_sheet = f'<{sheet_prefix}sheet{local_ns} name="{xml_attr(name)}" sheetId="{sheet_id}" {rprefix}:id="{rid}"/>'
    wb_xml = wb_xml[: sheets_close.start()] + new_sheet + wb_xml[sheets_close.start():]
    rel_target = posixpath.relpath(sheet_path, wb_dir)
    rels_xml = rels_xml.replace("</Relationships>", f'<Relationship Id="{rid}" Type="{NS_REL_WS}" Target="{rel_target}"/></Relationships>', 1)
    ct_xml = ct_xml.replace("</Types>", f'<Override PartName="/{sheet_path}" ContentType="{CT_WS}"/></Types>', 1)

    changed = {wb_path: wb_xml, wb_rels_path: rels_xml, "[Content_Types].xml": ct_xml, styles_path: styles_xml}
    with zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as zout:
        for n in names:
            payload = changed[n].encode("utf-8") if n in changed else data[n]
            zout.writestr(infos[n], payload)
        zout.writestr(sheet_path, sheet_xml.encode("utf-8"))

    verify(src, dst, set(changed), sheet_path, name, spec)
    return {"sheet_path": sheet_path, "rows": len(spec["rows"]), "header_row": header_row,
            "last_table_row": last_table_row}


def verify(src, dst, changed, sheet_path, name, spec):
    a, b = zipfile.ZipFile(src), zipfile.ZipFile(dst)
    for n in a.namelist():
        if n not in changed and a.read(n) != b.read(n):
            raise RuntimeError(f"Часть {n} изменилась — так быть не должно")
    assert sheet_path in b.namelist()
    try:
        import openpyxl
        wb = openpyxl.load_workbook(dst, read_only=True)
        assert name in wb.sheetnames, "новый лист не виден"
        ws = wb[name]
        want = spec["columns"][0]["header"]
        found = any(row and row[0] == want for row in ws.iter_rows(max_row=10, max_col=1, values_only=True))
        assert found, "шапка нового листа не найдена"
        wb.close()
    except ImportError:
        print("openpyxl не установлен — пропущена проверка открытия книги")


def main():
    if len(sys.argv) != 4:
        print(__doc__)
        sys.exit(1)
    src, spec_path, dst = sys.argv[1:]
    with open(spec_path, encoding="utf-8") as fh:
        spec = json.load(fh)
    info = add_sheet(src, dst, spec)
    print(f"Готово: {dst}\n  лист «{spec['sheet_name']}» → {info['sheet_path']}, строк таблицы {info['rows']}, "
          f"шапка в строке {info['header_row']}\n  исходные части книги не изменены, книга открывается")


if __name__ == "__main__":
    main()
