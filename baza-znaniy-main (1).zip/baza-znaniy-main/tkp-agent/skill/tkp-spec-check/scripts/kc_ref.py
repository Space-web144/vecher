# -*- coding: utf-8 -*-
"""
kc_ref.py — справочник КЦ (расценки и материалы) для проверки ТКП.

Данные — assets/kc_ref.json.gz, собирается из выгрузки «справочник_КЦ_ВЕСЬ.xlsx»
скриптом tools/kc_ref_build.py: разделы ВК (6.2.3.1), ОВ1 (6.2.3.2), ОВ2 (6.2.3.3),
ИТП (6.2.3.6), кондиционирование (6.2.3.7–8) — код работы, наименование, пакет,
путь разделов и допустимые материалы работы (группа, материал, ед., коэф. расхода,
основной). Цен нет.

    import kc_ref as kc
    kc.load()                                   # рядом со скриптом ../assets/kc_ref.json.gz или $TKP_KC_REF
    kc.work('6.2.3.3.1.1.1.2')                  # {'code', 'name', 'family', 'variant', 'package', 'path'}
    kc.family('6.2.3.3.1.1.1.2')                # все варианты семьи: толщины, периметры, массы…
    kc.materials('6.2.3.3.1.1.1.2', main=True)  # материалы, которые формируют объём
    kc.find_works('шумоглушитель прямоугольный', section='ОВ2')
    kc.find_materials('K-flex AL CLAD 10', code='6.2.3.3.2.1.4.1')
    issues = kc.check_tkp(t)                    # t = tkp_toolkit.Tkp(path)

Зачем: ТКП — выгрузка КЦ, поэтому каждая работа и каждый материал в нём должны
быть из справочника. check_tkp находит строки, которых в КЦ нет (закрытая
расценка, материал не из этой работы, ручной текст подрядчика), а find_* и
family дают точную номенклатуру для замечания «заменить на …» вместо
описания своими словами. Справочник не решает, что верно по спецификации —
это по-прежнему сопоставление (шаг 4).
"""
import gzip
import json
import os
import re

HERE = os.path.dirname(os.path.abspath(__file__))
_DATA = None


def _default_path():
    for path in (os.environ.get('TKP_KC_REF'),
                 os.path.join(HERE, '..', 'assets', 'kc_ref.json.gz'),
                 os.path.join(HERE, 'kc_ref.json.gz')):
        if path and os.path.exists(path):
            return path
    raise FileNotFoundError('Нет справочника КЦ kc_ref.json.gz: положите его в assets/ навыка или задайте TKP_KC_REF')


def load(path=None):
    """Загружает справочник (один раз). Возвращает сводку: источник, дата, число работ."""
    global _DATA
    if _DATA is not None and path is None:
        return info()
    with gzip.open(path or _default_path(), 'rt', encoding='utf-8') as fh:
        data = json.load(fh)
    data['_norm_mats'] = {}
    data['_tok_mats'] = {}
    for code, items in data['mats'].items():
        data['_norm_mats'][code] = {norm(m[1]): m for m in items}
        data['_tok_mats'][code] = [tokens(m[1]) for m in items]
    data['_tok_works'] = {code: tokens(w[0]) for code, w in data['works'].items()}
    _DATA = data
    return info()


def _data():
    if _DATA is None:
        load()
    return _DATA


def info():
    d = _data()
    return {'source': d.get('source'), 'built': d.get('built'), 'works': len(d['works']),
            'materials': sum(len(v) for v in d['mats'].values()), 'sections': d.get('sections')}


# ----------------------------------------------------------------------------- нормализация
def norm(s):
    s = str(s or '').lower().replace('ё', 'е')
    s = re.sub(r'[x×*]', 'х', s)
    s = s.replace('ø', 'ф').replace('⌀', 'ф').replace('Ø'.lower(), 'ф')
    s = re.sub(r'\s*/\s*', ' / ', s)
    s = re.sub(r'(?<=\d),(?=\d)', '.', s)
    s = re.sub(r'\s+', ' ', s).strip(' _')
    return s


_STOP = {'и', 'в', 'на', 'с', 'со', 'по', 'для', 'из', 'до', 'от', 'мм', 'шт', 'м', 'м2', 'кг', 'тип', 'гост', 'ту', '/'}


def tokens(s):
    """Слова и числа наименования: «900х300х0.8» → {'900','300','0.8'}; слова — по первым 6 буквам."""
    s = norm(s)
    out = set()
    for t in re.findall(r'\d+(?:\.\d+)?|[a-zа-я][a-zа-я0-9]*', s):
        if t in _STOP:
            continue
        out.add(t if t[0].isdigit() else t[:6])
    return out


def _score(q, t):
    if not q or not t:
        return 0.0
    common = q & t
    nums_q = {x for x in q if x[0].isdigit()}
    # числа (размеры, толщины) важнее слов: несовпавшее число из запроса — штраф
    miss_num = len(nums_q - t)
    return (len(common) + 0.5 * len(common & nums_q)) / (len(q | t) ** 0.5 * len(q) ** 0.5) - 0.15 * miss_num


# ----------------------------------------------------------------------------- работы
def section_of(code):
    for prefix, name in (_data().get('sections') or {}).items():
        if str(code).startswith(prefix):
            return name
    return None


def covered(code):
    """Код из разделов справочника (иначе о нём справочник ничего сказать не может)."""
    return section_of(code) is not None


def work(code):
    w = _data()['works'].get(str(code or '').strip())
    if not w:
        return None
    name, package, path = w
    fam, _, var = name.partition(' / ')
    return {'code': str(code).strip(), 'name': name, 'family': fam.strip(), 'variant': var.strip(),
            'package': package, 'path': path, 'section': section_of(code)}


def is_closed(code):
    """Расценки нет в КЦ, хотя код из проверяемых разделов: закрыта или ошибочна."""
    code = str(code or '').strip()
    return covered(code) and code not in _data()['works']


def family(code):
    """Все работы той же семьи (наименование до « / ») в той же ветке кода — варианты по толщине,
    периметру, диаметру, массе. Для замечания «заменить на расценку …»."""
    w = work(code)
    if not w:
        return []
    branch = '.'.join(str(code).split('.')[:5]) + '.'
    out = []
    for c, (name, _p, _path) in _data()['works'].items():
        if c.startswith(branch) and name.partition(' / ')[0].strip() == w['family']:
            out.append(work(c))
    return sorted(out, key=lambda x: [int(p) if p.isdigit() else p for p in x['code'].split('.')])


def find_works(text, section=None, prefix=None, limit=10):
    """Расценки по словам и числам наименования; section — 'ВК'|'ОВ1'|'ОВ2'|…, prefix — начало кода."""
    q = tokens(text)
    res = []
    for code, toks in _data()['_tok_works'].items():
        if prefix and not code.startswith(prefix):
            continue
        if section and section_of(code) != section:
            continue
        s = _score(q, toks)
        if s > 0:
            res.append((s, code))
    res.sort(key=lambda x: -x[0])
    return [dict(work(c), score=round(s, 3)) for s, c in res[:limit]]


# ----------------------------------------------------------------------------- материалы
def materials(code, main=None):
    """Допустимые материалы работы: [{'group','material','unit','coef','main'}]; main=True — только формирующие объём."""
    out = []
    for g, m, u, k, is_main in _data()['mats'].get(str(code or '').strip(), []):
        if main is None or bool(is_main) == bool(main):
            out.append({'group': g, 'material': m, 'unit': u, 'coef': k, 'main': bool(is_main)})
    return out


def material_in_work(code, name):
    """Материал с таким наименованием есть у этой работы в КЦ (с точностью до регистра, пробелов, х/x)."""
    m = _data()['_norm_mats'].get(str(code or '').strip(), {}).get(norm(name))
    return None if m is None else {'group': m[0], 'material': m[1], 'unit': m[2], 'coef': m[3], 'main': bool(m[4])}


def find_materials(text, code=None, section=None, limit=10, min_score=0.0):
    """Материалы КЦ по словам и числам: в одной работе (code) или по разделу (section)."""
    q = tokens(text)
    res = []
    d = _data()
    codes = [code] if code else [c for c in d['mats'] if not section or section_of(c) == section]
    for c in codes:
        for (g, m, u, k, is_main), toks in zip(d['mats'].get(c, []), d['_tok_mats'].get(c, [])):
            s = _score(q, toks)
            if s > min_score:
                res.append((s, c, g, m, u, is_main))
    res.sort(key=lambda x: -x[0])
    seen = set()
    out = []
    for s, c, g, m, u, is_main in res:
        if (c, m) in seen:
            continue
        seen.add((c, m))
        out.append({'code': c, 'work': d['works'][c][0], 'group': g, 'material': m, 'unit': u,
                    'main': bool(is_main), 'score': round(s, 3)})
        if len(out) >= limit:
            break
    return out


# ----------------------------------------------------------------------------- сверка ТКП со справочником
def check_tkp(t, suggest=3):
    """Каждая работа и каждый материал листа «ТКП» — против справочника КЦ.

    t — tkp_toolkit.Tkp. Возвращает список замечаний:
      {'row', 'kind', 'code', 'name', 'text', 'suggest': [...]}
    kind:
      work_closed      — расценки нет в КЦ (закрыта/ошибочна): замечание «заменить на действующую»;
      work_renamed     — наименование расценки в ТКП не совпадает с КЦ (выгрузка устарела) — для «Пояснений»;
      material_foreign — материала нет среди материалов этой расценки в КЦ: ручной текст или чужая работа;
      unit_differs     — единица материала в ТКП не та, что в КЦ.
    Работы вне разделов справочника (ЭОМ, СС, общестрой) не проверяются.
    Это контроль номенклатуры, не соответствия спецификации: статус строки решает сопоставление."""
    issues = []
    for w in t.works():
        code = str(t.code(w) or '').strip()
        if not covered(code):
            continue
        kc_work = work(code)
        if kc_work is None:
            sug = find_works(t.name(w), prefix='.'.join(code.split('.')[:5]) + '.', limit=suggest)
            issues.append({'row': w, 'kind': 'work_closed', 'code': code, 'name': t.name(w),
                           'text': 'Расценки %s нет в справочнике КЦ — заменить на действующую' % code,
                           'suggest': [(s['code'], s['name']) for s in sug]})
            continue
        if norm(t.name(w)) != norm(kc_work['name']):
            issues.append({'row': w, 'kind': 'work_renamed', 'code': code, 'name': t.name(w),
                           'text': 'Наименование расценки в КЦ: «%s»' % kc_work['name'], 'suggest': []})
        for r in t.children(w):
            name = t.name(r)
            m = material_in_work(code, name)
            if m is None:
                sug = find_materials(name, code=code, limit=suggest, min_score=0.25)
                elsewhere = find_materials(name, section=kc_work['section'], limit=1)
                text = 'Материала нет среди материалов расценки %s в КЦ' % code
                if elsewhere and elsewhere[0]['score'] >= 0.9 and elsewhere[0]['code'] != code:
                    text += '; в КЦ он у расценки %s «%s»' % (elsewhere[0]['code'], elsewhere[0]['work'][:60])
                issues.append({'row': r, 'kind': 'material_foreign', 'code': code, 'name': name, 'text': text,
                               'suggest': [(s['material'], s['unit']) for s in sug]})
                continue
            unit = str(t.unit(r) or '').strip()
            if unit and m['unit'] and norm(unit).replace('.', '') != norm(m['unit']).replace('.', ''):
                issues.append({'row': r, 'kind': 'unit_differs', 'code': code, 'name': name,
                               'text': 'Ед. в ТКП «%s», в КЦ «%s»' % (unit, m['unit']), 'suggest': []})
    return issues


def summary(issues):
    """Счётчики по видам замечаний — для «Пояснений» и ответа."""
    out = {}
    for i in issues:
        out[i['kind']] = out.get(i['kind'], 0) + 1
    return out
