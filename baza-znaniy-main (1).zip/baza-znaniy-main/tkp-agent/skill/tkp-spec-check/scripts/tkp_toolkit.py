# -*- coding: utf-8 -*-
"""
tkp_toolkit.py — инструменты проверки ТКП (вентиляция) на соответствие спецификации проекта.
Версия 2.0 (10.09.2026). Использовать вместе с ТЗ «ТЗ_проверка_ТКП_вентиляция_по_спецификации.md».

Зависимости: pdfplumber, openpyxl>=3.1, lxml. LibreOffice — только для пересчёта копии (recalc).

Основной сценарий (см. ТЗ, раздел 10):
    from tkp_toolkit import *
    files = unzip_decoded('archive.zip', 'work')
    pages = find_spec_pages(pdf)                       # страницы спецификации
    rows  = extract_spec(pdf, pages)                   # строки таблицы спецификации
    tr    = extract_spec(tr_pdf, find_spec_pages(tr_pdf), tag='ТР1-')
    rows  = apply_tr(rows, {19: [...], 20: [...]})     # замена листов
    items = structure_items(rows)                      # позиции с разделом/системой
    agg   = aggregate(items)                           # агрегация по подсистемам (id)
    tkp   = Tkp('tkp.xlsx')                            # разбор листа ТКП
    rep   = Report(tkp, agg, items)                    # сборка отчёта
    rep.map(row, ids, ...)  ...  rep.build(...)  rep.save(out)
    finalize(out)                                      # пересчёт копии + кэш значений + проверка
"""
import json, re, math, copy, os, zipfile, shutil, subprocess, sys
from collections import OrderedDict

import pdfplumber
from openpyxl import load_workbook, Workbook
from openpyxl.utils import get_column_letter, column_index_from_string
from openpyxl.styles import Font, PatternFill, Alignment, Border, Side
from openpyxl.worksheet.properties import Outline
from openpyxl.cell.rich_text import CellRichText, TextBlock
from openpyxl.cell.text import InlineFont

# =====================================================================================
# 0. Общие константы и оформление
# =====================================================================================
COLORS = dict(ok='FFC6EFCE', unsure='FFFFEB9C', error='FFFFC7CE', hdr='FFDDEBF7', block='FFFFF2CC',
              extra='FFF7F7F7', remark='FF99FF33', redfont='FFC00000')
FILLS = {k: PatternFill('solid', fgColor=v) for k, v in COLORS.items()}
THIN = Side(style='thin', color='FF000000')
BORDER = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
F_DATA = Font(name='Times New Roman', size=12)
F_BOLD = Font(name='Times New Roman', size=12, bold=True)
F_NOTE = Font(name='Times New Roman', size=11, italic=True, color='FF595959')
F_REMARK = Font(name='Times New Roman', size=14)
AL_WRAP = Alignment(wrap_text=True, vertical='center', horizontal='left')
AL_CENTER = Alignment(wrap_text=True, vertical='center', horizontal='center')
RED_FONT = InlineFont(rFont='Times New Roman', sz=12, b=True, color=COLORS['redfont'])
TOL = 0.05
SUB_NAME = {'ОВ': 'Общеобменная вентиляция', 'ПД': 'Противодымная вентиляция', 'КОНД': 'Кондиционирование (вне ТКП)'}
NONSTD_SHARE = {'ОВ': 0.10, 'ПД': 0.30}           # доля некратных изделий (≠1250/1500)
NONSTD_MIN_M2 = 10.0                              # позиции меньше 10 м² не делим
FITTING_SMALL_SHARE = {'ОВ': 0.915, 'ПД': 0.906}  # доля фасонных «до 0,3 м²» (прямоуг.) / «до 0,18 м²» (круглые)
CAT_NAME = {'A': 'до 0,78м2 включительно', 'B': 'от 0,78м2 до 4,25м2 включительно', 'C': 'изделия свыше 4,25м2'}
CAT_SHORT = {'A': 'до 0,78 м²', 'B': 'от 0,78 до 4,25 м²', 'C': 'свыше 4,25 м²'}
STD_NAME = {'std': '1250мм, 1500мм', 'nonstd': 'не равно 1250мм, 1500мм'}


def fmt(v, dec=2):
    return f'{v:,.{dec}f}'.replace(',', ' ').replace('.', ',')


def pct(v):
    return f'{round(v * 100)} %'


def short_list(lst, n=8):
    lst = [str(x) for x in lst]
    return ', '.join(lst) if len(lst) <= n else ', '.join(lst[:n]) + f' … (+{len(lst) - n})'


def unzip_decoded(zip_path, dest):
    """Распаковка zip с декодированием имён вида #U0433 → 'г'. Возвращает список путей."""
    os.makedirs(dest, exist_ok=True)
    out = []
    z = zipfile.ZipFile(zip_path)
    for info in z.infolist():
        name = re.sub(r'#U([0-9a-fA-F]{4})', lambda m: chr(int(m.group(1), 16)), info.filename)
        p = os.path.join(dest, os.path.basename(name))
        if info.is_dir():
            continue
        with open(p, 'wb') as f:
            f.write(z.read(info))
        out.append(p)
    return out


# =====================================================================================
# 1. Спецификация из PDF
# =====================================================================================
STAMP_PATTERNS = [r'Архивный №', r'ООО "[^"]+"', r'ЛП\d{5}-\d{2}']
HEADER_KEYS = [('pos', r'^Поз\.?$'), ('name', r'^Наименование'), ('type', r'^Тип,?$'), ('code', r'^Код$'),
               ('supplier', r'^Поставщик'), ('unit', r'^Ед\.?$'), ('qty', r'^Коли'), ('mass', r'^Масса'), ('note', r'^Примечание')]


def find_spec_pages(pdf_path, must=('Поз.', 'Наименование и техническая характеристика')):
    """Номера страниц (1-based), содержащих таблицу спецификации (через pdftotext — экономно по памяти)."""
    res = subprocess.run(['pdftotext', '-layout', pdf_path, '-'], capture_output=True, text=True)
    pages = []
    for i, t in enumerate(res.stdout.split('\f'), start=1):
        t = t.replace('​', '')
        if all(m in t for m in must):
            pages.append(i)
    return pages


def pdf_page_texts(pdf_path):
    """Текст всех страниц (список, индекс 0 = страница 1) через pdftotext -layout."""
    res = subprocess.run(['pdftotext', '-layout', pdf_path, '-'], capture_output=True, text=True)
    return res.stdout.split('\f')


def detect_columns(page):
    """Границы столбцов по вертикальным линиям таблицы и словам шапки. -> [(x0,x1,key), ...]"""
    words = page.extract_words(x_tolerance=1.5)
    top_words = [w for w in words if w['top'] < page.height * 0.2]
    centers, hy = {}, []
    for key, pat in HEADER_KEYS:
        for w in top_words:
            if re.match(pat, w['text'].replace('​', '')):
                centers.setdefault(key, (w['x0'] + w['x1']) / 2); hy.append((w['top'] + w['bottom']) / 2)
                break
    header_y = sum(hy) / len(hy) if hy else page.height * 0.1
    # только вертикальные линии, пересекающие полосу шапки (линии штампа/рамки ниже — не учитываем)
    xs = sorted(set(round(e['x0']) for e in page.edges if e['orientation'] == 'v' and e['top'] <= header_y + 15 and e['bottom'] >= header_y - 15))
    keys = [k for k, _ in HEADER_KEYS if k in centers]
    if len(keys) < 7:
        raise RuntimeError(f'Не удалось распознать шапку спецификации: найдено {keys}')
    cols = []
    for i, k in enumerate(keys):
        c = centers[k]
        left = max([x for x in xs if x < c], default=None)
        right = min([x for x in xs if x > c], default=None)
        # граница между соседними заголовками — ближайшая линия между их центрами
        if i > 0:
            prev_c = centers[keys[i - 1]]
            between = [x for x in xs if prev_c < x < c]
            left = between[-1] if between else left
        if i < len(keys) - 1:
            next_c = centers[keys[i + 1]]
            between = [x for x in xs if c < x < next_c]
            right = between[0] if between else right
        cols.append([left, right, k])
    # сшивка соседних границ
    for i in range(1, len(cols)):
        if cols[i][0] is None or cols[i - 1][1] is None or cols[i][0] != cols[i - 1][1]:
            b = cols[i][0] if cols[i][0] is not None else cols[i - 1][1]
            cols[i][0] = cols[i - 1][1] = b
    return [tuple(c) for c in cols]


def join_lines(lines, mark=False):
    """Склейка перенесённых строк ячейки; для столбца марки — без пробела внутри токена."""
    if not lines:
        return ''
    out = lines[0]
    for nxt in lines[1:]:
        if mark and out and nxt:
            last_tok = out.split(' ')[-1]
            nospace = (out[-1] in '-,.' or nxt[0].isdigit() or nxt[0] == ',' or (len(last_tok) == 1 and last_tok.isalpha())
                       or (len(out) > 1 and out[-2] in '.-' and out[-1].isalpha()))
            out = out + nxt if nospace else out + ' ' + nxt
        else:
            out = out + ' ' + nxt
    return out


def extract_spec_page(page, cols, pageno, stamp_patterns=STAMP_PATTERNS):
    name_col = next(c for c in cols if c[2] == 'name')
    ys = set()
    for e in page.edges:
        if e['orientation'] == 'h' and e['x0'] <= name_col[0] + 5 and e['x1'] >= name_col[1] - 5 and 60 < e['top'] < page.height * 0.93:
            ys.add(round(e['top']))
    ys = sorted(ys)
    merged = []
    for y in ys:
        if merged and y - merged[-1] <= 3:
            continue
        merged.append(y)
    words = [w for w in page.extract_words(x_tolerance=1.5) if cols[0][0] < w['x0'] < cols[-1][1]]
    rows = []
    for i in range(len(merged) - 1):
        y0, y1 = merged[i], merged[i + 1]
        cell = {c[2]: [] for c in cols}
        for w in words:
            yc = (w['top'] + w['bottom']) / 2
            if y0 < yc < y1:
                xc = (w['x0'] + w['x1']) / 2
                for x0, x1, k in cols:
                    if x0 <= xc < x1:
                        cell[k].append(w)
                        break
        out = {}
        for k, v in cell.items():
            v = sorted(v, key=lambda w: w['top'])
            lines, cur, ct = [], [], None
            for w in v:
                if ct is None or abs(w['top'] - ct) <= 3:
                    cur.append(w); ct = w['top'] if ct is None else ct
                else:
                    lines.append(cur); cur = [w]; ct = w['top']
            if cur:
                lines.append(cur)
            lines = [' '.join(x['text'] for x in sorted(l, key=lambda w: w['x0'])) for l in lines]
            txt = join_lines(lines, mark=(k == 'type')).replace('​', '')
            for sp in stamp_patterns:
                txt = re.sub(r'\s*' + sp + r'\s*', ' ', txt)
            out[k] = re.sub(r'\s+', ' ', txt).strip()
        out['page'] = pageno
        if any(out[c[2]] for c in cols):
            rows.append(out)
    return rows


def extract_spec(pdf_path, pages, tag='С-'):
    """Строки таблицы спецификации. 'sheet' — порядковый номер листа спецификации (1 = первая страница)."""
    rows = []
    cols = None
    with pdfplumber.open(pdf_path) as pdf:
        for n, pn in enumerate(pages, start=1):
            p = pdf.pages[pn - 1]
            if cols is None:
                cols = detect_columns(p)
            rr = extract_spec_page(p, cols, pn)
            for r in rr:
                r['src'] = f'{tag}{pn}'; r['sheet'] = n
            rows += rr
            p.flush_cache()
    return rows


def apply_tr(main_rows, replacements):
    """replacements: {номер_листа_спецификации: [строки из ТР для этого листа]}. Возвращает объединённый список."""
    out = [r for r in main_rows if r['sheet'] not in replacements]
    for sheet, rr in replacements.items():
        for r in rr:
            r = dict(r); r['sheet'] = sheet
            out.append(r)
    out.sort(key=lambda r: r['sheet'])   # стабильная сортировка сохраняет порядок внутри листа
    return out


def structure_items(rows):
    """Разметка раздел/система. Строки без ед.изм. и кол-ва — заголовки."""
    section, system, items = None, None, []
    for r in rows:
        if r['qty'] and not re.match(r'^[\d\s.,]+$', r['qty']):
            print('SKIP (не строка спецификации):', r['src'], r['name'][:40], '|', r['qty'][:40])
            continue
        if not r['unit'] and not r['qty']:
            if r['pos'] and not r['name']:
                system = r['pos']; continue
            hdr = (r['pos'] + ' ' + r['name']).strip()
            hdr = re.sub(r'^С истемы', 'Системы', hdr)
            section, system = hdr, None
            continue
        r['section'] = section; r['system'] = system
        items.append(r)
    return items


def subsystem(section):
    s = section or ''
    if 'противодымн' in s:
        return 'ПД'
    if 'кондицион' in s or 'Рамы' in s or 'холодоснабж' in s:
        return 'КОНД'
    return 'ОВ'


DUCT_RE = re.compile(r'класса В, ([\dx]+), с толщиной стенки ([\d,]+)\s*мм')


def duct_info(name):
    m = DUCT_RE.search(name)
    if not m:
        return None
    size, t = m.group(1), m.group(2)
    if 'круглый' in name:
        return {'kind': 'кругл', 'size': size, 't': t, 'per': math.pi * int(size) / 1000}   # точный периметр (как PI() в Excel)
    w, h = map(int, size.split('x'))
    return {'kind': 'прям', 'size': size, 't': t, 'per': 2 * (w + h) / 1000}


def qty_float(s):
    return float(str(s).replace(',', '.').replace(' ', ''))


def aggregate(items):
    """Агрегация по (подсистема, наименование, марка, код, поставщик, ед.изм.). Возвращает список dict с id."""
    agg = OrderedDict()
    for r in items:
        ss = subsystem(r['section'])
        k = (ss, r['name'], r['type'], r['code'], r['supplier'], r['unit'])
        a = agg.setdefault(k, {'ss': ss, 'name': r['name'], 'type': r['type'], 'code': r['code'], 'supplier': r['supplier'],
                               'unit': r['unit'], 'qty': 0.0, 'n': 0, 'systems': [], 'mass': r['mass'], 'note': r['note'],
                               'sections': [], 'sheets': []})
        a['qty'] = round(a['qty'] + qty_float(r['qty']), 4); a['n'] += 1
        for key, val in (('systems', r['system']), ('sections', r['section']), ('sheets', r['sheet'])):
            if val not in a[key]:
                a[key].append(val)
    out = []
    for i, a in enumerate(agg.values()):
        a['id'] = i
        d = duct_info(a['name'])
        if d:
            a['duct'] = d
        out.append(a)
    return out


def spec_display(x, extra=''):
    parts = [x['name']] + [x[k] for k in ('type', 'code', 'supplier') if x[k]]
    return ' / '.join(parts) + extra + f"  [системы: {short_list(x['systems'])}; л. спец.: {short_list(x['sheets'], 10)}]"


# =====================================================================================
# 2. Правила по воздуховодам и фасонным
# =====================================================================================
def rect_cat(per, length=1.25):
    p = per * length
    return 'A' if p <= 0.78 + 1e-9 else ('B' if p <= 4.25 + 1e-9 else 'C')


def duct_area(x, share=1.0):
    d = x['duct']
    return x['qty'] * d['per'] * share


def duct_formula(x, share=1.0):
    d = x['duct']
    sh = '' if abs(share - 1) < 1e-9 else f'*{share:g}'
    if d['kind'] == 'кругл':
        return f"={x['qty']}*PI()*{int(d['size'])}/1000{sh}"
    w, h = map(int, d['size'].split('x'))
    return f"={x['qty']}*2*({w}+{h})/1000{sh}"


def rect_slots(agg, ss, shares=NONSTD_SHARE, min_m2=NONSTD_MIN_M2):
    """-> {(толщина, категория, 'std'|'nonstd'): [(id, доля), ...]}. Позиции < min_m2 не делятся."""
    k = shares[ss]
    res = {}
    for x in agg:
        d = x.get('duct')
        if x['ss'] != ss or not d or d['kind'] != 'прям':
            continue
        cat = rect_cat(d['per'])
        if duct_area(x) < min_m2:
            res.setdefault((d['t'], cat, 'std'), []).append((x['id'], 1.0))
        else:
            res.setdefault((d['t'], cat, 'std'), []).append((x['id'], 1 - k))
            res.setdefault((d['t'], cat, 'nonstd'), []).append((x['id'], k))
    return res


def round_slots(agg, ss, flange_over=315):
    """-> {'ниппель'|'фланец': [(id, 1.0), ...]} по правилу d ≤ 315 ниппель, d > 315 фланец."""
    res = {}
    for x in agg:
        d = x.get('duct')
        if x['ss'] != ss or not d or d['kind'] != 'кругл':
            continue
        conn = 'фланец' if int(d['size']) > flange_over else 'ниппель'
        res.setdefault(conn, []).append((x['id'], 1.0))
    return res


def fitting_split(total, ss, shares=FITTING_SMALL_SHARE):
    """Фасонные: (до 0,3/0,18 м², от 0,3/0,18 м²)."""
    small = round(total * shares[ss], 3)
    return small, round(total - small, 3)


def slot_material_name(kind, slot, t='0,8'):
    if kind == 'прям':
        th, cat, std = slot
        return f'Воздуховоды прямоугольного сечения / {th}мм / {STD_NAME[std]} / {CAT_NAME[cat]} / класс B'
    return f'Воздуховоды круглого сечения / {t}мм / {slot} / спирально-навивной / класс B'


# =====================================================================================
# 3. ТКП: разбор листа
# =====================================================================================
SYS_RE = re.compile(r'(?<![А-Яа-яA-Za-z0-9])(ДПЕ|ДП|ДВ|ПЕ|ВЕ|П|В)(\d+(?:\.\d+)?(?:\(\d+\))?)(?![А-Яа-яA-Za-z0-9])')


def find_systems(text):
    return sorted(set(a + b for a, b in SYS_RE.findall(text or '')))


class Tkp:
    """Лист «ТКП» выгрузки КЦ. Столбцы: A №, B код ИСР, C наименование, D комм. ИСР, E примечание подрядчика, F ед., I объём."""

    def __init__(self, path, sheet='ТКП'):
        self.path = path
        self.wb = load_workbook(path)
        self.ws = self.wb[sheet]
        ws = self.ws
        self.max_col = max(c for c in range(1, ws.max_column + 1) if ws.cell(6, c).value or ws.cell(5, c).value)
        self.header_rows = (5, 7)
        self.data_start = 8
        self.max_row = ws.max_row
        while self.max_row > 8 and all(ws.cell(self.max_row, c).value is None for c in range(1, self.max_col + 1)):
            self.max_row -= 1

    def val(self, r, c):
        return self.ws.cell(r, c).value

    def pos(self, r): return str(self.val(r, 1) or '')
    def code(self, r): return self.val(r, 2)
    def name(self, r): return str(self.val(r, 3) or '')
    def comment(self, r): return str(self.val(r, 5) or '')
    def unit(self, r): return self.val(r, 6)

    def qty(self, r):
        v = self.val(r, 9)
        return float(v) if isinstance(v, (int, float)) else 0.0

    def is_section(self, r): return bool(self.code(r)) and not self.unit(r)
    def is_work(self, r): return bool(self.code(r)) and bool(self.unit(r))
    def is_material(self, r): return not self.code(r) and bool(self.unit(r)) and self.val(r, 9) is not None

    def works(self):
        return [r for r in range(self.data_start, self.max_row + 1) if self.is_work(r)]

    def children(self, work_row):
        out = []
        for r in range(work_row + 1, self.max_row + 1):
            if self.code(r):
                break
            if self.is_material(r):
                out.append(r)
        return out

    def zero_rate_rows(self):
        """Работы с нулевым объёмом и их материалы (п. 1 ТЗ)."""
        rows = []
        for w in self.works():
            if self.qty(w) == 0 and self.children(w):
                rows.append(w); rows += self.children(w)
        return rows

    def section_rows(self, title_contains):
        return [r for r in range(self.data_start, self.max_row + 1) if self.is_section(r) and title_contains in self.name(r)]

    def dump(self, rows=None):
        for r in rows or range(self.data_start, self.max_row + 1):
            print(r, '|', self.pos(r), '|', self.code(r) or '', '|', self.name(r)[:90], '|', self.unit(r), '|', self.val(r, 9), '|', self.comment(r)[:60])


# =====================================================================================
# 4. Сборка отчёта
# =====================================================================================
REF_RE = re.compile(r'(?<![A-Za-z_\d\.])(\$?)([A-Z]{1,3})(\$?)(\d+)(?![\d\(])')
SUM_RE = re.compile(r'SUM\(([^()]*)\)')


def rich(text, patterns):
    """CellRichText: совпадения регулярных выражений выделены красным жирным."""
    if not patterns:
        return text
    spans = []
    for p in patterns:
        for mm in re.finditer(p, text):
            spans.append((mm.start(), mm.end()))
    if not spans:
        return text
    spans.sort()
    merged = []
    for s, e in spans:
        if merged and s <= merged[-1][1]:
            merged[-1] = (merged[-1][0], max(e, merged[-1][1]))
        else:
            merged.append((s, e))
    parts, pos = [], 0
    for s, e in merged:
        if s > pos:
            parts.append(text[pos:s])
        parts.append(TextBlock(RED_FONT, text[s:e])); pos = e
    if pos < len(text):
        parts.append(text[pos:])
    return CellRichText(parts)


class Report:
    """Собирает новый лист «ТКП» с колонками проверки, замечаниями, группировкой и добавочными строками."""

    def __init__(self, tkp: Tkp, agg, items):
        self.t = tkp; self.agg = agg; self.A = {x['id']: x for x in agg}; self.items = items
        self.MAP = {}            # kc_row -> dict(ids, note, st, hl, st_ids, eq, kind)
        self.DUCT = {}           # kc_row -> dict(kind, slot, items[(id, share)])
        self.VIRTUAL = []        # dict(after, kind, slot, items, title)
        self.REMARKS = {}        # row-key -> text
        self.BLOCKS = []         # (after_row, title, [ids])
        self.INCLUDED = {}       # id -> статус «учтено в составе …»
        self.deleted = set()
        self.STATUS = {}
        self.RESULTS = []
        self.slot_notes = {}

    # ---- описание сопоставления
    def map(self, row, ids=None, note='', st='ok', hl=None, st_ids=None, eq=False, kind='match'):
        self.MAP[row] = dict(ids=list(ids or []), note=note, st=st, hl=hl or {}, st_ids=st_ids or {}, eq=eq, kind=kind)

    def duct_group(self, row, kind, slot, items, work=None):
        self.DUCT[row] = dict(kind=kind, slot=slot, items=items, work=work)

    def virtual_group(self, after_row, kind, slot, items, title):
        self.VIRTUAL.append(dict(after=after_row, kind=kind, slot=slot, items=items, title=title))

    def unmatched_block(self, after_row, title, ids):
        self.BLOCKS.append((after_row, title, list(ids)))

    def remark(self, key, text):
        """key: номер исходной строки ТКП, ('extra', row, id), ('virtual', 'V1'), ('bitem', id)."""
        self.REMARKS[key] = text

    def delete_rows(self, rows):
        self.deleted |= set(rows)

    # ---- вспомогательное
    def item_unit_val(self, x):
        if x.get('duct'):
            return 'м2', duct_formula(x), duct_area(x)
        return x['unit'].rstrip('.'), x['qty'], x['qty']

    def system_check(self, r, ids, sys_re=SYS_RE):
        spec_sys = sorted(set(s for i in ids for s in self.A[i]['systems']))
        com = find_systems(self.t.comment(r)); nam = find_systems(self.t.name(r))
        if not com:
            t = f'ОШИБКА: система оборудования в примечании подрядчика не указана (по спецификации: {short_list(spec_sys, 10)})'
            if nam and set(nam) != set(spec_sys):
                t += f'; в наименовании КЦ указана система {", ".join(nam)} — не соответствует спецификации'
            return 'error', t
        if set(com) == set(spec_sys):
            return 'ok', f'Система по примечанию ({", ".join(com)}) соответствует спецификации'
        return 'error', f'ОШИБКА: система в примечании ({", ".join(com)}) не соответствует спецификации ({short_list(spec_sys, 10)})'

    def add_status(self, i, txt):
        self.STATUS[i] = (self.STATUS[i] + '; ' + txt) if (i in self.STATUS and txt not in self.STATUS[i]) else txt if i not in self.STATUS else self.STATUS[i]

    # ---- сборка
    def build(self, sheet_title='ТКП', name_col_width=80, chk_col_width=55, remark_col_width=85,
              m2_format='#,##0.000', qty_tol=TOL):
        t = self.t; old = t.ws; wb = t.wb; A = self.A
        LASTC = t.max_col
        C_NAME, C_UNIT, C_QTY, C_CHK = [get_column_letter(LASTC + i) for i in range(1, 5)]
        C_SP, C_REM = get_column_letter(LASTC + 5), get_column_letter(LASTC + 6)
        NEWCOLS = [C_NAME, C_UNIT, C_QTY, C_CHK]
        self.cols = dict(name=C_NAME, unit=C_UNIT, qty=C_QTY, chk=C_CHK, rem=C_REM)
        deleted = self.deleted

        # ---------- план строк
        plan = []
        for v in self.VIRTUAL:
            v['key'] = f'V{self.VIRTUAL.index(v) + 1}'
        for r in range(1, t.max_row + 1):
            if r in deleted:
                continue
            plan.append(('orig', r))
            d = self.MAP.get(r)
            if d and len(d['ids']) > 1:
                for i in d['ids'][1:]:
                    plan.append(('extra', r, i))
            for v in self.VIRTUAL:
                if v['after'] == r:
                    plan.append(('virtual', v['key']))
            for after, title, ids in self.BLOCKS:
                if after == r:
                    plan.append(('bhdr', title))
                    if not ids:
                        plan.append(('bnone',))
                    for i in ids:
                        plan.append(('bitem', i))
        old2new = {e[1]: idx for idx, e in enumerate(plan, start=1) if e[0] == 'orig'}
        row_of = {e: idx for idx, e in enumerate(plan, start=1)}
        self.plan, self.old2new, self.row_of = plan, old2new, row_of
        NEW_MAX = len(plan)

        def remap_formula(f):
            def fix_sum(mm):
                keep = []
                for a in [a.strip() for a in mm.group(1).split(',')]:
                    rm = REF_RE.fullmatch(a)
                    if rm and int(rm.group(4)) in deleted:
                        continue
                    keep.append(a)
                return 'SUM(' + (','.join(keep) if keep else '0') + ')'
            f = SUM_RE.sub(fix_sum, f)
            return REF_RE.sub(lambda mm: f'{mm.group(1)}{mm.group(2)}{mm.group(3)}{old2new.get(int(mm.group(4)), int(mm.group(4)))}', f)

        # ---------- копия листа
        ws = wb.create_sheet(sheet_title + '_new')
        for k, cd in old.column_dimensions.items():
            ws.column_dimensions[k].width = cd.width; ws.column_dimensions[k].hidden = cd.hidden
        style_src = next((r for r in range(t.data_start, t.max_row + 1) if t.is_material(r) and r not in deleted), t.data_start)
        for idx, e in enumerate(plan, start=1):
            if e[0] == 'orig':
                r = e[1]
                rd = old.row_dimensions.get(r)
                if rd is not None and rd.height is not None:
                    ws.row_dimensions[idx].height = rd.height
                for c in range(1, LASTC + 1):
                    oc = old.cell(r, c); nc = ws.cell(idx, c); v = oc.value
                    if isinstance(v, str) and v.startswith('='):
                        v = remap_formula(v)
                    nc.value = v
                    if oc.has_style:
                        nc._style = copy.copy(oc._style)
            elif e[0] in ('extra', 'virtual'):
                src = e[1] if e[0] == 'extra' else style_src
                for c in range(1, LASTC + 1):
                    oc = old.cell(src, c); nc = ws.cell(idx, c)
                    if oc.has_style:
                        nc._style = copy.copy(oc._style)
                    nc.fill = FILLS['extra']
        for mr in old.merged_cells.ranges:
            if mr.min_row in deleted:
                continue
            ws.merge_cells(start_row=old2new[mr.min_row], start_column=mr.min_col, end_row=old2new[mr.max_row], end_column=mr.max_col)
        ws.freeze_panes = old.freeze_panes
        ws.sheet_view.zoomScale = old.sheet_view.zoomScale
        ws.sheet_properties.outlinePr = Outline(summaryBelow=True, summaryRight=True)
        ws.page_setup.orientation = old.page_setup.orientation
        ws.page_setup.paperSize = old.page_setup.paperSize
        ws.sheet_properties.pageSetUpPr = old.sheet_properties.pageSetUpPr

        # ---------- заголовки новых столбцов
        hdr_style_src = old.cell(t.header_rows[0], 9)
        widths = {C_NAME: name_col_width, C_UNIT: 9, C_QTY: 14, C_CHK: chk_col_width, C_SP: 13, C_REM: remark_col_width}
        for col, w in widths.items():
            ws.column_dimensions[col].width = w
        hdr_texts = {C_NAME: 'Спецификация (с учётом ТР): наименование / тип, марка / код продукции / поставщик. Красным шрифтом — элемент, не соответствующий КЦ',
                     C_UNIT: 'Ед. изм. по спец.', C_QTY: 'Кол-во по спец.',
                     C_CHK: 'Результат проверки (объём, номенклатура, система). Зелёный — соответствие, жёлтый — уточнить, красный — ошибка',
                     C_REM: 'Замечания'}
        h0, h1 = t.header_rows
        for col, txt in hdr_texts.items():
            ci = column_index_from_string(col)
            ws.merge_cells(start_row=h0, start_column=ci, end_row=h1, end_column=ci)
            for rr in range(h0, h1 + 1):
                cell = ws.cell(rr, ci); cell._style = copy.copy(hdr_style_src._style)
                cell.fill = FILLS['remark'] if col == C_REM else FILLS['hdr']
                cell.font = F_REMARK if col == C_REM else F_BOLD
            ws.cell(h0, ci).value = txt

        def style_spec(row, fill=None, bold=False):
            for col in NEWCOLS:
                c = ws[f'{col}{row}']; c.border = BORDER; c.font = F_BOLD if bold else F_DATA
                c.alignment = AL_CENTER if col in (C_UNIT, C_QTY) else AL_WRAP
                if col == C_QTY:
                    c.number_format = m2_format if ws[f'{C_UNIT}{row}'].value in ('м2', 'м²') else '#,##0.00'
                if fill is not None:
                    c.fill = fill

        def write_item(row, x, chk, status, patterns=None, extra='', unit=None, val=None):
            u, v, _ = self.item_unit_val(x)
            ws[f'{C_NAME}{row}'] = rich(spec_display(x, extra), patterns)
            ws[f'{C_UNIT}{row}'] = unit or u
            ws[f'{C_QTY}{row}'] = val if val is not None else v
            ws[f'{C_CHK}{row}'] = chk
            style_spec(row, FILLS[status])

        # ---------- материалы
        for r, d in self.MAP.items():
            if r in deleted:
                continue
            nr = old2new[r]
            if d['kind'] == 'krep':
                style_spec(nr); ws[f'{C_CHK}{nr}'] = d['note']; ws[f'{C_CHK}{nr}'].font = F_NOTE
                continue
            ids = d['ids']
            if not ids:
                style_spec(nr, FILLS['error'])
                ws[f'{C_NAME}{nr}'] = '— в спецификации отсутствует —'; ws[f'{C_UNIT}{nr}'] = t.unit(r); ws[f'{C_QTY}{nr}'] = 0
                ws[f'{C_CHK}{nr}'] = f'ОШИБКА: спец. 0 / КЦ {fmt(t.qty(r))}. ' + d['note']
                self.RESULTS.append((nr, t.pos(r), t.name(r), t.qty(r), 0.0, 'error')); continue
            spec_sum = round(sum(self.item_unit_val(A[i])[2] for i in ids), 3)
            kq = round(t.qty(r), 3)
            qty_ok = abs(spec_sum - kq) <= qty_tol
            base = 'error' if not qty_ok else d['st']
            sys_txt = ''
            if d['eq']:
                st_s, sys_txt = self.system_check(r, ids)
                if st_s == 'error':
                    base = 'error'
            if qty_ok:
                chk = 'Соответствует' if len(ids) == 1 else f'Количество соответствует: Σ по спец. {fmt(spec_sum)} = КЦ {fmt(kq)} ({len(ids)} поз. спец.)'
                if d['st'] == 'error' and not d['note']:
                    chk = 'ОШИБКА номенклатуры. ' + chk
            else:
                chk = f'РАСХОЖДЕНИЕ ПО ОБЪЁМУ: Σ по спец. {fmt(spec_sum)} / КЦ {fmt(kq)} (Δ = {fmt(spec_sum - kq)})'
            if d['note']:
                pre = 'ОШИБКА номенклатуры: ' if (d['st'] == 'error' and qty_ok and not d['note'].upper().startswith('ОШИБКА')) else ''
                chk = chk.rstrip('.') + '. ' + pre + d['note']
            if sys_txt:
                chk = chk.rstrip('.') + '. ' + sys_txt
            first = ids[0]
            st_first = d['st_ids'].get(first, base)
            if not qty_ok or (d['eq'] and sys_txt.startswith('ОШИБКА')):
                st_first = 'error'
            write_item(nr, A[first], chk, st_first, d['hl'].get(first))
            for i in ids[1:]:
                er = row_of[('extra', r, i)]
                st_i = d['st_ids'].get(i, d['st'] if qty_ok else 'error')
                if d['st_ids'].get(i) is None and (not qty_ok or (d['eq'] and sys_txt.startswith('ОШИБКА'))):
                    st_i = 'error'
                write_item(er, A[i], '↑ входит в позицию КЦ выше', st_i, d['hl'].get(i)); ws[f'{C_CHK}{er}'].font = F_NOTE
            lbl = {'ok': 'соответствует', 'unsure': 'требует уточнения', 'error': 'ОШИБКА'}[st_first if len(ids) == 1 else base]
            for i in ids:
                self.add_status(i, f'Разнесено → поз. КЦ {t.pos(r)} (стр. {nr}) — {lbl}')
            self.RESULTS.append((nr, t.pos(r), t.name(r), kq, spec_sum, base))

        # ---------- воздуховоды: только итоги по группам (п. 12 ТЗ)
        def write_duct_group(row, info, kq, is_virtual):
            items = info['items']
            tot = round(sum(duct_area(A[i], sh) for i, sh in items), 3)
            sizes = ', '.join(f"{A[i]['duct']['size'].replace('x', '×') if A[i]['duct']['kind']=='прям' else 'Ø'+A[i]['duct']['size']}"
                              + ('' if abs(sh - 1) < 1e-9 else f' ({pct(sh)})') for i, sh in items)
            desc = (f"{info['slot'][0]} мм / {STD_NAME[info['slot'][2]]} / {CAT_NAME[info['slot'][1]]} (площадь 1 изделия при L = 1,25 м)"
                    if info['kind'] == 'прям' else f"0,8 мм / {info['slot']} (по правилу: d ≤ 315 — ниппель, d > 315 — фланец)")
            ws[f'{C_NAME}{row}'] = f'ИТОГО по группе воздуховодов: {desc} — {len(items)} поз. спецификации: {sizes}. Расшифровка — лист «Воздуховоды м2»'
            ws[f'{C_UNIT}{row}'] = 'м2'
            ws[f'{C_QTY}{row}'] = '=' + '+'.join(duct_formula(A[i], sh)[1:] for i, sh in items) if items else 0
            if is_virtual:
                st = 'error'; chk = f'ОШИБКА: позиция в КЦ отсутствует. По правилу расчёта объём {fmt(tot, 3)} м² должен быть выделен отдельной позицией.'
            else:
                ok = abs(tot - kq) <= qty_tol; st = 'ok' if ok else 'error'
                chk = (f'Соответствует: Σ по спец. {fmt(tot, 3)} = КЦ {fmt(kq, 3)}' if ok else f'РАСХОЖДЕНИЕ: Σ по спец. {fmt(tot, 3)} / КЦ {fmt(kq, 3)} (Δ = {fmt(tot - kq, 3)})')
                if row in ORIG_OF and ORIG_OF[row] in self.slot_notes:
                    chk += '. ' + self.slot_notes[ORIG_OF[row]]
            ws[f'{C_CHK}{row}'] = chk
            style_spec(row, FILLS[st], bold=True)
            for i, sh in items:
                self.add_status(i, f'Разнесено → {"ОТСУТСТВУЮЩАЯ в КЦ позиция" if is_virtual else "поз. КЦ " + t.pos(ORIG_OF[row])} (стр. {row}, доля {pct(sh)})')
            return tot, st

        ORIG_OF = {v: k for k, v in old2new.items()}
        for r, info in self.DUCT.items():
            if r in deleted:
                continue
            nr = old2new[r]
            tot, st = write_duct_group(nr, info, round(t.qty(r), 3), False)
            self.RESULTS.append((nr, t.pos(r), t.name(r), round(t.qty(r), 3), tot, st))
        for v in self.VIRTUAL:
            nr = row_of[('virtual', v['key'])]
            c = ws.cell(nr, 3); c.value = 'ОТСУТСТВУЕТ В КЦ: ' + v['title']
            c.font = Font(name='Times New Roman', size=13, bold=True, italic=True, color=COLORS['redfont']); c.alignment = AL_WRAP
            ws.cell(nr, 6).value = 'м2'; ws.cell(nr, 6).font = F_DATA
            for cc in range(1, LASTC + 1):
                ws.cell(nr, cc).fill = FILLS['error']
            tot, st = write_duct_group(nr, v, 0.0, True)
            self.RESULTS.append((nr, '—', 'ОТСУТСТВУЕТ В КЦ: ' + v['title'], 0.0, tot, 'error'))

        # ---------- работы: объём = Σ основных материалов (п. 2 ТЗ)
        for w_ in t.works():
            if w_ in deleted:
                continue
            nw = old2new[w_]; cells = []
            for idx in range(nw + 1, NEW_MAX + 1):
                e = plan[idx - 1]
                if e[0] == 'orig':
                    r = e[1]
                    if t.code(r):
                        break
                    if r in self.DUCT or (r in self.MAP and self.MAP[r]['kind'] == 'match' and self.MAP[r]['ids']):
                        cells.append(f'{C_QTY}{idx}')
                elif e[0] in ('extra', 'virtual'):
                    cells.append(f'{C_QTY}{idx}')
                elif e[0] in ('bhdr', 'bitem', 'bnone'):
                    break
            if not cells:
                continue
            tot = 0.0
            for cref in cells:
                idx = int(re.search(r'\d+', cref).group()); e = plan[idx - 1]
                if e[0] == 'orig' and e[1] in self.DUCT:
                    tot += sum(duct_area(A[i], sh) for i, sh in self.DUCT[e[1]]['items'])
                elif e[0] == 'virtual':
                    v = next(v for v in self.VIRTUAL if v['key'] == e[1]); tot += sum(duct_area(A[i], sh) for i, sh in v['items'])
                elif e[0] == 'extra':
                    tot += self.item_unit_val(A[e[2]])[2]
                else:
                    tot += self.item_unit_val(A[self.MAP[e[1]]['ids'][0]])[2]
            tot = round(tot, 3); kq = round(t.qty(w_), 3); ok = abs(tot - kq) <= qty_tol
            ws[f'{C_NAME}{nw}'] = f'ОБЪЁМ РАБОТЫ по спецификации = Σ основных материалов ({len(cells)} поз. КЦ, без сопутствующих)'
            ws[f'{C_UNIT}{nw}'] = t.unit(w_); ws[f'{C_QTY}{nw}'] = '=SUM(' + ','.join(cells) + ')'
            ws[f'{C_CHK}{nw}'] = (f'Объём работы соответствует: {fmt(tot, 3)} = КЦ {fmt(kq, 3)}' if ok else f'РАСХОЖДЕНИЕ объёма работы: по спец. {fmt(tot, 3)} / КЦ {fmt(kq, 3)} (Δ = {fmt(tot - kq, 3)})')
            style_spec(nw, FILLS['ok'] if ok else FILLS['error'], bold=True)
            self.RESULTS.append((nw, t.pos(w_), t.name(w_), kq, tot, 'ok' if ok else 'error'))

        # ---------- блоки неразнесённых
        for idx, e in enumerate(plan, start=1):
            if e[0] == 'bhdr':
                ws.row_dimensions[idx].height = 30
                ws.merge_cells(start_row=idx, start_column=3, end_row=idx, end_column=9)
                c = ws.cell(idx, 3); c.value = e[1]; c.font = Font(name='Times New Roman', size=14, bold=True); c.alignment = AL_WRAP
                for cc in range(1, LASTC + 1):
                    ws.cell(idx, cc).fill = FILLS['block']; ws.cell(idx, cc).border = BORDER
                ws.merge_cells(start_row=idx, start_column=column_index_from_string(C_NAME), end_row=idx, end_column=column_index_from_string(C_CHK))
                ws[f'{C_NAME}{idx}'] = e[1]; style_spec(idx, FILLS['block'], bold=True); ws[f'{C_NAME}{idx}'].alignment = AL_WRAP
            elif e[0] == 'bnone':
                for cc in range(1, LASTC + 1):
                    ws.cell(idx, cc).border = BORDER
                style_spec(idx, FILLS['ok']); ws[f'{C_NAME}{idx}'] = '— неразнесённых материалов нет —'
            elif e[0] == 'bitem':
                x = A[e[1]]
                for cc in range(1, LASTC + 1):
                    ws.cell(idx, cc).border = BORDER; ws.cell(idx, cc).fill = FILLS['extra']
                ws.cell(idx, 3).value = 'не разнесено в ТКП'; ws.cell(idx, 3).font = Font(name='Times New Roman', size=12, italic=True, color='FF7F7F7F')
                write_item(idx, x, 'ОШИБКА: отсутствует в ТКП — добавить в соответствующую расценку.', 'error')
                self.add_status(e[1], f'НЕ разнесено (см. ТКП, стр. {idx})')
        for i, txt in self.INCLUDED.items():
            self.STATUS[i] = txt

        # ---------- замечания (п. 13 ТЗ)
        for key, text in self.REMARKS.items():
            if isinstance(key, int):
                if key in deleted:
                    continue
                rr = old2new[key]
            else:
                rr = row_of.get(tuple(key))
                if rr is None:
                    continue
            c = ws[f'{C_REM}{rr}']; c.value = text; c.font = F_REMARK; c.fill = FILLS['remark']
            c.alignment = Alignment(wrap_text=True, vertical='top'); c.border = BORDER

        for idx, e in enumerate(plan, start=1):
            if idx >= t.data_start and e[0] == 'orig':
                for col in NEWCOLS:
                    c = ws[f'{col}{idx}']
                    if c.border.left.style is None:
                        c.border = BORDER; c.font = F_DATA

        # ---------- группировка ценовых столбцов J..LASTC
        for ci in range(10, LASTC + 1):
            cd = ws.column_dimensions[get_column_letter(ci)]; cd.outlineLevel = 1; cd.hidden = True
        ws.column_dimensions[C_NAME].collapsed = True
        ws.auto_filter.ref = f'A{h1}:{C_REM}{h1}'

        pos = wb.sheetnames.index(sheet_title); wb.remove(old); ws.title = sheet_title
        wb.move_sheet(ws, offset=pos - wb.sheetnames.index(sheet_title))
        self.ws = ws          # t.ws по-прежнему указывает на исходный лист (для чтения объёмов КЦ)
        return ws

    def save(self, out_path):
        wb = self.t.wb
        wb.active = wb.sheetnames.index(self.ws.title)
        for w_ in wb.worksheets:
            w_.sheet_view.tabSelected = (w_.title == self.ws.title)
        wb.calculation.fullCalcOnLoad = True
        wb.save(out_path)
        return out_path


# =====================================================================================
# 5. Дополнительные листы
# =====================================================================================
def write_table(ws, header_row, headers, rows, widths=None, wrap_cols=(), num_formats=None, freeze=True, autofilter=True):
    """Универсальная таблица: headers — список, rows — список списков (формулы как строки '=...')."""
    for j, h in enumerate(headers, start=1):
        c = ws.cell(header_row, j, h); c.font = F_BOLD; c.fill = FILLS['hdr']; c.border = BORDER; c.alignment = AL_CENTER
    r = header_row + 1
    for row in rows:
        for j, v in enumerate(row, start=1):
            c = ws.cell(r, j, v); c.font = F_DATA; c.border = BORDER
            c.alignment = AL_WRAP if j in wrap_cols else AL_CENTER
            if num_formats and j in num_formats:
                c.number_format = num_formats[j]
        r += 1
    if widths:
        for j, w in enumerate(widths, start=1):
            ws.column_dimensions[get_column_letter(j)].width = w
    if freeze:
        ws.freeze_panes = f'A{header_row + 1}'
    if autofilter and rows:
        ws.auto_filter.ref = f'A{header_row}:{get_column_letter(len(headers))}{r - 1}'
    return r


def build_summary_sheet(wb, agg, status, title='Сводная по спецификации', note=''):
    sv = wb.create_sheet(title)
    sv['A1'] = 'Сводная спецификация в разрезе подсистем (с учётом ТР). Позиции агрегированы по наименованию/марке внутри подсистемы.'
    sv['A1'].font = Font(name='Times New Roman', size=14, bold=True)
    sv['A2'] = note; sv['A2'].font = F_NOTE
    for c, h in zip('ABCDE', ['Подсистема', 'Позиций (агрегир.)', 'Разнесено в ТКП', 'Не разнесено / вне ТКП', 'Из них с ошибкой']):
        sv[f'{c}4'] = h; sv[f'{c}4'].font = F_BOLD; sv[f'{c}4'].fill = FILLS['hdr']; sv[f'{c}4'].border = BORDER; sv[f'{c}4'].alignment = AL_CENTER
    HDR = 10
    heads = ['№', 'Подсистема', 'Раздел спецификации', 'Системы', 'Наименование и техническая характеристика', 'Тип, марка', 'Код продукции',
             'Поставщик', 'Ед. изм.', 'Кол-во', 'Масса 1 ед., кг', 'Масса всего, кг', 'Листы спец.', 'Статус в ТКП']
    for j, h in enumerate(heads, start=1):
        c = sv.cell(HDR, j, h); c.font = F_BOLD; c.fill = FILLS['hdr']; c.border = BORDER; c.alignment = AL_CENTER
    row, n = HDR + 1, 0
    for ss in ('ОВ', 'ПД', 'КОНД'):
        if not any(x['ss'] == ss for x in agg):
            continue
        c = sv.cell(row, 1, SUB_NAME[ss]); c.font = Font(name='Times New Roman', size=13, bold=True)
        sv.merge_cells(start_row=row, start_column=1, end_row=row, end_column=14)
        for j in range(1, 15):
            sv.cell(row, j).fill = FILLS['block']; sv.cell(row, j).border = BORDER
        row += 1
        for x in agg:
            if x['ss'] != ss:
                continue
            n += 1
            st = status.get(x['id'], 'Вне ТКП (раздел не входит в состав ТКП)' if ss == 'КОНД' else 'НЕ разнесено')
            try:
                mass = float(x['mass'].replace(',', '.')) if x['mass'] else None
            except ValueError:
                mass = None
            vals = [n, SUB_NAME[ss], ', '.join(x['sections']), short_list(x['systems'], 12), x['name'], x['type'], x['code'], x['supplier'],
                    x['unit'], x['qty'], mass, f'=IF(K{row}="","",ROUND(J{row}*K{row},2))', short_list(x['sheets'], 15), st]
            for j, v in enumerate(vals, start=1):
                c = sv.cell(row, j, v); c.font = F_DATA; c.border = BORDER
                c.alignment = AL_WRAP if j in (3, 4, 5, 6, 14) else AL_CENTER
                if j in (10, 11, 12):
                    c.number_format = '#,##0.000' if j == 10 else '#,##0.00'
            if 'НЕ разнесено' in st or 'ОШИБКА' in st or 'ОТСУТСТВУЮЩ' in st:
                sv.cell(row, 14).fill = FILLS['error']
            elif 'уточнения' in st:
                sv.cell(row, 14).fill = FILLS['unsure']
            elif st.startswith('Разнесено') or st.startswith('Учтено'):
                sv.cell(row, 14).fill = FILLS['ok']
            row += 1
    LAST = row - 1
    for i, ss in enumerate(('ОВ', 'ПД', 'КОНД')):
        rr = 5 + i
        sv[f'A{rr}'] = SUB_NAME[ss]
        sv[f'B{rr}'] = f'=COUNTIFS($B${HDR+1}:$B${LAST},A{rr})'
        sv[f'C{rr}'] = f'=COUNTIFS($B${HDR+1}:$B${LAST},A{rr},$N${HDR+1}:$N${LAST},"Разнесено*")+COUNTIFS($B${HDR+1}:$B${LAST},A{rr},$N${HDR+1}:$N${LAST},"Учтено*")'
        sv[f'D{rr}'] = f'=B{rr}-C{rr}'
        sv[f'E{rr}'] = f'=COUNTIFS($B${HDR+1}:$B${LAST},A{rr},$N${HDR+1}:$N${LAST},"*ОШИБКА*")+COUNTIFS($B${HDR+1}:$B${LAST},A{rr},$N${HDR+1}:$N${LAST},"*ОТСУТСТВУЮЩ*")'
        for c in 'ABCDE':
            sv[f'{c}{rr}'].font = F_DATA; sv[f'{c}{rr}'].border = BORDER; sv[f'{c}{rr}'].alignment = AL_CENTER
    sv['A8'] = 'Итого'
    for c in 'BCDE':
        sv[f'{c}8'] = f'=SUM({c}5:{c}7)'
    for c in 'ABCDE':
        sv[f'{c}8'].font = F_BOLD; sv[f'{c}8'].border = BORDER; sv[f'{c}8'].alignment = AL_CENTER
    for col, w in zip('ABCDEFGHIJKLMN', [24, 22, 26, 30, 70, 30, 14, 12, 8, 12, 12, 13, 22, 44]):
        sv.column_dimensions[col].width = w
    sv.freeze_panes = f'A{HDR+1}'; sv.auto_filter.ref = f'A{HDR}:N{LAST}'
    return sv


def build_duct_sheet(wb, items, agg, kc_rect, kc_round, kc_fit, title='Воздуховоды м2',
                     shares=NONSTD_SHARE, min_m2=NONSTD_MIN_M2, fit_shares=FITTING_SMALL_SHARE):
    """Лист «Воздуховоды м2»: построчно по спецификации, по подсистемам → группа → толщина, с итогами по группам КЦ.
    kc_rect: {(ss, t, cat, 'std'|'nonstd'): объём КЦ}; kc_round: {(ss, conn): объём}; kc_fit: {(ss, 'прям'|'кругл'): (общий объём КЦ, {'small': v, 'big': v} или None)}"""
    dv = wb.create_sheet(title)
    dv['A1'] = 'Воздуховоды и фасонные части по спецификации (с учётом ТР): расчёт м², разбивка по подсистемам, наименованию и толщине, распределение по группам КЦ'
    dv['A1'].font = Font(name='Times New Roman', size=14, bold=True)
    dv['A2'] = ('Правила: площадь прямоугольных — L × 2·(a+b)/1000, круглых — L × π·d/1000. Длина изделия 1,25 м: площадь 1 изделия = периметр × 1,25 → категория КЦ '
                '(до 0,78 / 0,78–4,25 / свыше 4,25 м²). Доля изделий некратного размера (≠1250/1500): общеобменная 10 %, противодымная 30 %; позиции < 10 м² не делятся. '
                'Круглые: d ≤ 315 — ниппель, d > 315 — фланец. Фасонные «до 0,3 м² (прямоуг.) / до 0,18 м² (круглые)»: 91,5 % (общеобменная) / 90,6 % (противодымная).')
    dv['A2'].font = F_NOTE; dv['A2'].alignment = Alignment(wrap_text=True, vertical='top'); dv.merge_cells('A2:R2'); dv.row_dimensions[2].height = 60
    heads = ['№', 'Подсистема', 'Наименование группы', 'Система', 'Лист спец.', 'Наименование по спецификации', 'Сечение / Ø, мм', 'Толщина, мм', 'Ед. изм.',
             'Кол-во по спец.', 'Периметр, м', 'Площадь всего, м²', 'Площадь 1 изделия (L=1,25 м), м²', 'Категория КЦ', 'Доля некратных', 'м² кратные (1250/1500)', 'м² некратные (≠1250/1500)', 'Соединение (круглые, по правилу)']
    DH = 4
    for j, h in enumerate(heads, start=1):
        c = dv.cell(DH, j, h); c.font = F_BOLD; c.fill = FILLS['hdr']; c.border = BORDER; c.alignment = AL_CENTER

    def hdr_line(row, text, fill, size=12):
        c = dv.cell(row, 1, text); c.font = Font(name='Times New Roman', size=size, bold=True)
        dv.merge_cells(start_row=row, start_column=1, end_row=row, end_column=18)
        for j in range(1, 19):
            dv.cell(row, j).fill = fill; dv.cell(row, j).border = BORDER

    def sum_line(row, label, formula, kc, expected=None, note=''):
        dv.cell(row, 6, label).font = F_BOLD
        dv.cell(row, 12, formula).font = F_BOLD; dv.cell(row, 12).number_format = '#,##0.000'
        dv.cell(row, 13, 'КЦ:').font = F_BOLD
        if kc is None:
            dv.cell(row, 14, 'позиция в КЦ отсутствует' if (expected is None or expected > 0.0005) else '—').font = F_BOLD
            dv.cell(row, 16, f'=L{row}').font = F_BOLD; dv.cell(row, 16).number_format = '#,##0.000;[Red]-#,##0.000'
            dv.cell(row, 17, f'=IF(ABS(L{row})<=0.0005,"не требуется","ОШИБКА: нет позиции в КЦ")').font = F_BOLD
        else:
            dv.cell(row, 14, kc).font = F_BOLD; dv.cell(row, 14).number_format = '#,##0.000'
            dv.cell(row, 15, 'Δ:').font = F_BOLD
            dv.cell(row, 16, f'=ROUND(L{row}-N{row},3)').font = F_BOLD; dv.cell(row, 16).number_format = '#,##0.000;[Red]-#,##0.000'
            dv.cell(row, 17, f'=IF(ABS(P{row})<=0.05,"Соответствует","РАСХОЖДЕНИЕ")').font = F_BOLD
        dv.cell(row, 18, note if (expected is None or expected > 0.0005) else '').font = F_NOTE
        for j in range(1, 19):
            dv.cell(row, j).border = BORDER; dv.cell(row, j).fill = FILLS['extra']

    def agg_item(it):
        di = duct_info(it['name'])
        return next(x for x in agg if x['ss'] == subsystem(it['section']) and x['name'] == it['name'] and x['type'] == it['type'] and x['unit'] == it['unit'])

    row, n = DH + 1, 0
    for ss in ('ОВ', 'ПД'):
        k = shares[ss]
        lines = [it for it in items if subsystem(it['section']) == ss]
        if not lines:
            continue
        hdr_line(row, SUB_NAME[ss], FILLS['block'], 13); row += 1
        ducts = [(it, duct_info(it['name'])) for it in lines if duct_info(it['name'])]
        rslots = rect_slots(agg, ss, shares, min_m2)
        for tt in sorted(set(di['t'] for it, di in ducts if di['kind'] == 'прям'), key=lambda s: float(s.replace(',', '.'))):
            hdr_line(row, f'Воздуховоды прямоугольные, толщина стенки {tt} мм — {SUB_NAME[ss]}', FILLS['hdr']); row += 1
            first = row
            for it, di in ducts:
                if di['kind'] != 'прям' or di['t'] != tt:
                    continue
                n += 1; qty = qty_float(it['qty']); w_, h_ = map(int, di['size'].split('x'))
                share = 0 if duct_area(agg_item(it)) < min_m2 else k
                vals = [n, SUB_NAME[ss], 'Воздуховод прямоугольный', it['system'], it['sheet'], it['name'], di['size'].replace('x', '×'), tt, 'м', qty,
                        f'=2*({w_}+{h_})/1000', f'=J{row}*K{row}', f'=K{row}*1.25',
                        f'=IF(M{row}<=0.78,"{CAT_SHORT["A"]}",IF(M{row}<=4.25,"{CAT_SHORT["B"]}","{CAT_SHORT["C"]}"))', share, f'=L{row}*(1-O{row})', f'=L{row}*O{row}', '—']
                for j, v in enumerate(vals, start=1):
                    c = dv.cell(row, j, v); c.font = F_DATA; c.border = BORDER; c.alignment = AL_WRAP if j == 6 else AL_CENTER
                    if j in (10, 12, 13, 16, 17):
                        c.number_format = '#,##0.000'
                    if j == 11:
                        c.number_format = '0.0000'
                    if j == 15:
                        c.number_format = '0%'
                row += 1
            last = row - 1
            hdr_line(row, f'Итоги по группам КЦ — прямоугольные {tt} мм ({SUB_NAME[ss]}; некратные {pct(k)}, позиции < {min_m2:g} м² не делятся)', FILLS['extra'], 11); row += 1
            for cat in ('A', 'B', 'C'):
                for std in ('std', 'nonstd'):
                    col = 'P' if std == 'std' else 'Q'
                    kc = kc_rect.get((ss, tt, cat, std))
                    exp_ = round(sum(duct_area(next(x for x in agg if x['id'] == i), sh) for i, sh in rslots.get((tt, cat, std), [])), 3)
                    sum_line(row, f'{CAT_SHORT[cat]} — {STD_NAME[std]}', f'=ROUND(SUMIFS({col}{first}:{col}{last},N{first}:N{last},"{CAT_SHORT[cat]}"),3)', kc, exp_,
                             '' if kc is not None else 'по правилу расчёта требуется отдельная позиция КЦ'); row += 1
            sum_line(row, f'ВСЕГО прямоугольные {tt} мм', f'=ROUND(SUM(L{first}:L{last}),3)', round(sum(v for kk, v in kc_rect.items() if kk[0] == ss and kk[1] == tt), 3)); row += 2
        if any(di['kind'] == 'кругл' for it, di in ducts):
            hdr_line(row, f'Воздуховоды круглые — {SUB_NAME[ss]}', FILLS['hdr']); row += 1
            first = row
            for it, di in ducts:
                if di['kind'] != 'кругл':
                    continue
                n += 1; qty = qty_float(it['qty']); dd = int(di['size'])
                vals = [n, SUB_NAME[ss], 'Воздуховод круглый', it['system'], it['sheet'], it['name'], f'Ø{dd}', di['t'], 'м', qty,
                        f'=PI()*{dd}/1000', f'=J{row}*K{row}', '—', '—', '—', '—', '—', f'=IF({dd}>315,"фланец","ниппель")']
                for j, v in enumerate(vals, start=1):
                    c = dv.cell(row, j, v); c.font = F_DATA; c.border = BORDER; c.alignment = AL_WRAP if j == 6 else AL_CENTER
                    if j in (10, 12):
                        c.number_format = '#,##0.000'
                    if j == 11:
                        c.number_format = '0.0000'
                row += 1
            last = row - 1
            hdr_line(row, f'Итоги по группам КЦ — круглые ({SUB_NAME[ss]})', FILLS['extra'], 11); row += 1
            rsl = round_slots(agg, ss)
            for conn in ('ниппель', 'фланец'):
                exp_ = round(sum(duct_area(next(x for x in agg if x['id'] == i)) for i, sh in rsl.get(conn, [])), 3)
                sum_line(row, f'Круглые — {conn} (по правилу d {"≤" if conn == "ниппель" else ">"} 315)', f'=ROUND(SUMIFS(L{first}:L{last},R{first}:R{last},"{conn}"),3)',
                         kc_round.get((ss, conn)), exp_, '' if kc_round.get((ss, conn)) is not None else f'позиция «{conn}» в КЦ отсутствует'); row += 1
            sum_line(row, 'ВСЕГО круглые', f'=ROUND(SUM(L{first}:L{last}),3)', round(sum(v for kk, v in kc_round.items() if kk[0] == ss), 3)); row += 2
        for kind, nm, lim in (('прям', 'Соединительные детали воздуховодов прямоугольного сечения', '0,3'), ('кругл', 'Соединительные детали воздуховодов круглого и смешанного сечения', '0,18')):
            fl = [it for it in lines if it['name'] == nm]
            if not fl:
                continue
            hdr_line(row, f'Фасонные части — {"прямоугольные" if kind == "прям" else "круглые и смешанного сечения"} — {SUB_NAME[ss]}', FILLS['hdr']); row += 1
            first = row
            for it in fl:
                n += 1; qty = qty_float(it['qty'])
                vals = [n, SUB_NAME[ss], f'Фасонные части {"прямоуг." if kind == "прям" else "круглые"}', it['system'], it['sheet'], it['name'], '—', '—', 'м²', qty, '—', f'=J{row}', '—', '—', '—', '—', '—', '—']
                for j, v in enumerate(vals, start=1):
                    c = dv.cell(row, j, v); c.font = F_DATA; c.border = BORDER; c.alignment = AL_WRAP if j == 6 else AL_CENTER
                    if j in (10, 12):
                        c.number_format = '#,##0.000'
                row += 1
            last = row - 1
            total_kc, parts = kc_fit.get((ss, kind), (None, None))
            hdr_line(row, f'Итоги по группам КЦ — фасонные {"прямоугольные" if kind == "прям" else "круглые"} ({SUB_NAME[ss]}; «до {lim} м²» = {pct(fit_shares[ss])})', FILLS['extra'], 11); row += 1
            sum_line(row, f'до {lim} м² (включительно)', f'=ROUND(SUM(L{first}:L{last})*{fit_shares[ss]},3)', (parts or {}).get('small'), 1); row += 1
            sum_line(row, f'от {lim} м²', f'=ROUND(SUM(L{first}:L{last})*(1-{fit_shares[ss]}),3)', (parts or {}).get('big'), 1); row += 1
            sum_line(row, f'ВСЕГО фасонные части {"прямоугольные" if kind == "прям" else "круглые"}', f'=ROUND(SUM(L{first}:L{last}),3)', total_kc); row += 2
    for col, w in zip('ABCDEFGHIJKLMNOPQR', [6, 20, 20, 11, 8, 60, 13, 9, 8, 12, 11, 13, 14, 20, 10, 14, 14, 16]):
        dv.column_dimensions[col].width = w
    dv.freeze_panes = f'A{DH+1}'
    return dv


def build_notes_sheet(wb, lines, title='Пояснения'):
    px = wb.create_sheet(title)
    for i, (txt, bold) in enumerate(lines, start=1):
        c = px.cell(i, 1, txt); c.font = Font(name='Times New Roman', size=12, bold=bold); c.alignment = Alignment(wrap_text=True, vertical='top')
    px.column_dimensions['A'].width = 160
    return px


# =====================================================================================
# 6. Финализация: пересчёт, кэш значений, проверка
# =====================================================================================
def recalc_copy(path, recalc_script='/mnt/skills/public/xlsx/scripts/recalc.py', timeout=180):
    """Пересчитывает КОПИЮ файла через LibreOffice, возвращает (путь к копии, json-результат)."""
    lo = os.path.splitext(path)[0] + '__lo.xlsx'
    shutil.copy(path, lo)
    res = subprocess.run([sys.executable, recalc_script, lo, str(timeout)], capture_output=True, text=True)
    try:
        js = json.loads(res.stdout[res.stdout.index('{'):])
    except Exception:
        js = {'status': 'unknown', 'raw': res.stdout[-500:], 'err': res.stderr[-500:]}
    return lo, js


def inject_cached_values(opx_path, lo_path, out_path):
    """Вписывает кэшированные значения формул (из пересчитанной копии) в файл openpyxl, сохраняя его оформление."""
    from lxml import etree
    NS = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main'
    lo = load_workbook(lo_path, data_only=True)
    z = zipfile.ZipFile(opx_path)
    wbxml = etree.fromstring(z.read('xl/workbook.xml'))
    rels = etree.fromstring(z.read('xl/_rels/workbook.xml.rels'))
    rid2target = {r.get('Id'): r.get('Target') for r in rels}
    sheetfiles = {}
    for s in wbxml.find(f'{{{NS}}}sheets'):
        rid = s.get('{http://schemas.openxmlformats.org/officeDocument/2006/relationships}id')
        tg = rid2target[rid]
        sheetfiles[s.get('name')] = 'xl/' + tg if not tg.startswith('/') else tg[1:]
    tmp = out_path + '.tmp'
    out = zipfile.ZipFile(tmp, 'w', zipfile.ZIP_DEFLATED)
    stats = {}
    for item in z.infolist():
        data = z.read(item.filename)
        name = next((n for n, p in sheetfiles.items() if p == item.filename), None)
        if name and name in lo.sheetnames:
            ws = lo[name]; root = etree.fromstring(data); cnt = 0
            for c in root.iter(f'{{{NS}}}c'):
                f = c.find(f'{{{NS}}}f')
                if f is None:
                    continue
                v = ws[c.get('r')].value
                old_v = c.find(f'{{{NS}}}v')
                if old_v is not None:
                    c.remove(old_v)
                if v is None:
                    continue
                ve = etree.SubElement(c, f'{{{NS}}}v')
                if isinstance(v, bool):
                    c.set('t', 'b'); ve.text = '1' if v else '0'
                elif isinstance(v, (int, float)):
                    if 't' in c.attrib:
                        del c.attrib['t']
                    ve.text = repr(float(v)) if isinstance(v, float) else str(v)
                elif isinstance(v, str) and v.startswith('#'):
                    c.set('t', 'e'); ve.text = v
                else:
                    c.set('t', 'str'); ve.text = str(v)
                cnt += 1
            stats[name] = cnt
            data = etree.tostring(root, xml_declaration=True, encoding='UTF-8', standalone=True)
        out.writestr(item, data)
    out.close(); z.close()
    shutil.move(tmp, out_path)
    return stats


def verify_preserved(orig_path, new_path, old2new, deleted, sheet='ТКП', max_col=42):
    """Все значения исходных (не удалённых) ячеек ТКП должны совпасть с новым файлом (после пересчёта)."""
    orig = load_workbook(orig_path, data_only=True)[sheet]
    new = load_workbook(new_path, data_only=True)[sheet]
    bad, checked = [], 0
    for r in range(1, orig.max_row + 1):
        if r in deleted or r not in old2new:
            continue
        for c in range(1, max_col + 1):
            ov, nv = orig.cell(r, c).value, new.cell(old2new[r], c).value
            if isinstance(ov, str) and ov.startswith('#'):
                continue
            if isinstance(ov, (int, float)) or isinstance(nv, (int, float)):
                checked += 1
                if (ov is None) != (nv is None) or (ov is not None and abs(float(ov) - float(nv)) > 0.005):
                    bad.append((r, c, ov, nv))
            elif ov != nv:
                bad.append((r, c, ov, nv))
    return checked, bad


def finalize(out_path, orig_path=None, old2new=None, deleted=()):
    """Пересчёт копии → кэш значений в файл → проверка целостности. Возвращает dict с результатами."""
    opx = os.path.splitext(out_path)[0] + '__opx.xlsx'
    shutil.copy(out_path, opx)
    lo, js = recalc_copy(out_path)
    stats = inject_cached_values(opx, lo, out_path)
    res = {'recalc': js, 'cached_cells': stats}
    if orig_path and old2new is not None:
        checked, bad = verify_preserved(orig_path, out_path, old2new, set(deleted))
        res['verify'] = {'checked': checked, 'bad': bad[:20], 'n_bad': len(bad)}
    for p in (opx, lo):
        try:
            os.remove(p)
        except OSError:
            pass
    return res
