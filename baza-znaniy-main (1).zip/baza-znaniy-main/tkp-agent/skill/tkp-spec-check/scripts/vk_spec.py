# -*- coding: utf-8 -*-
"""Структурирование спецификации ВК (система → группа → позиции) и агрегация по подсистемам ТКП."""
import json, re
from collections import OrderedDict

SYS_RE = re.compile(r'^(В1|В2|В21|К1Н|К11|К1|К2|К4Н|К4|Т3|Т4)(\(\d\))?$')

def subsystem_vk(system):
    s = system or ''
    base = re.sub(r'\(\d\)$', '', s)
    if base in ('К1', 'К1Н', 'К11'): return 'К1'
    if base == 'К2': return 'К2'
    if base in ('К4', 'К4Н'): return 'К4'
    if base in ('В1', 'Т3', 'Т4'): return 'В1'
    if base in ('В2', 'В21'): return 'В2'
    return 'ОБЩ'

SUB_NAME_VK = {'К1': 'Система хозяйственно-бытовой канализации (К1, К1Н, К11)',
               'К2': 'Система ливневой канализации (К2)',
               'К4': 'Система дренажной канализации (К4, К4Н)',
               'В1': 'Система хозяйственно-питьевого водоснабжения (В1, Т3, Т4)',
               'В2': 'Система внутреннего противопожарного водопровода и АУПТ (В2, В21)',
               'ОБЩ': 'Общие позиции (шахт-пакеты, сантехнические приборы)'}

def structure_vk(rows):
    system, group, items = None, None, []
    for r in rows:
        if r['qty'] and not re.match(r'^[\d\s.,]+$', r['qty']):
            print('SKIP:', r['src'], r['name'][:40], '|', r['qty'][:40]); continue
        if not r['unit'] and not r['qty']:
            hdr = (r['pos'] + ' ' + r['name']).strip()
            if not hdr:
                system = 'Общие'; group = None; continue
            if SYS_RE.match(hdr):
                system = hdr; group = None; continue
            group = hdr.rstrip(':'); continue
        r['system'] = system; r['group'] = group; r['ss'] = subsystem_vk(system)
        items.append(r)
    return items

def qty_float(s): return float(str(s).replace(',', '.').replace(' ', ''))

def aggregate_vk(items):
    agg = OrderedDict()
    for r in items:
        k = (r['ss'], r['name'], r['type'], r['unit'])
        a = agg.setdefault(k, {'ss': r['ss'], 'name': r['name'], 'type': r['type'], 'code': r['code'], 'supplier': r['supplier'],
                               'unit': r['unit'], 'qty': 0.0, 'n': 0, 'systems': [], 'mass': r['mass'], 'note': r['note'],
                               'sections': [], 'sheets': [], 'groups': []})
        a['qty'] = round(a['qty'] + qty_float(r['qty']), 4); a['n'] += 1
        for key, val in (('systems', r['system']), ('sections', r['group']), ('sheets', f"{r['vol']}-{r['sheet']}"), ('groups', r['group'])):
            if val not in a[key]: a[key].append(val)
    out = []
    for i, a in enumerate(agg.values()):
        a['id'] = i; out.append(a)
    return out
