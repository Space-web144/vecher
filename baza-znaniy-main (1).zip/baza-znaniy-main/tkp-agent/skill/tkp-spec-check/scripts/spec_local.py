# -*- coding: utf-8 -*-
"""
Локальное дополнение к tkp_toolkit для спецификации формата ООО «Перспектива» (111-1123-ОК-1/Н-3.1-1-1..4-ОВ2.СО):
- шапка «Позиция | Наименование… | Тип, марка… | Код оборудования… | Завод-изготовитель | Единица измерения | Коли-чество | Масса единицы, кг | Примечание»;
- каждая строка текста отчёркнута горизонтальной линией → строки-продолжения склеиваются с позицией;
- заголовки (жирный шрифт): раздел римской цифрой, «КОРПУС N. Система … <система> (<помещение>)», подзаголовки «a. Оборудование» / «б. Материалы» (курсив).
"""
import re, math
import pdfplumber
from tkp_toolkit import join_lines

KEYS = ['pos', 'name', 'type', 'code', 'supplier', 'unit', 'qty', 'mass', 'note']
STAMPS = [r'В производство работ', r'Капшук Роман Игоревич', r'\d{1,2} Апрель 2026 г\.', r'ООО "ГП МФС"', r'Архивный №', r'Р19508-\w+',
          r'Или аналог\.?', r'601116', r'655977', r'Страница \d+ из \d+']


def page_columns(page):
    """Границы столбцов по вертикальным линиям, пересекающим шапку (двойные линии → берём внутренние)."""
    words = page.extract_words(x_tolerance=1.5)
    hdr = [w for w in words if w['text'].startswith('Наименование') and w['top'] < page.height * 0.2]
    if not hdr:
        raise RuntimeError('нет шапки')
    hy = hdr[0]['top']
    xs = sorted(set(round(e['x0']) for e in page.edges if e['orientation'] == 'v' and e['top'] <= hy + 10 and e['bottom'] >= hy - 10 and e['x0'] < page.width * 0.995))
    # схлопываем двойные линии (расстояние ≤ 3 pt) в одну границу (среднее)
    groups = []
    for x in xs:
        if groups and x - groups[-1][-1] <= 3:
            groups[-1].append(x)
        else:
            groups.append([x])
    b = [sum(g) / len(g) for g in groups]
    if len(b) < 10:
        raise RuntimeError(f'границ столбцов {len(b)}: {b}')
    b = b[:10]
    return [(b[i], b[i + 1], KEYS[i]) for i in range(9)]


def raw_rows(page, cols):
    """Строки таблицы по линиям столбца «Наименование» (каждая текстовая строка — отдельная строка таблицы)."""
    name_col = next(c for c in cols if c[2] == 'name')
    ys = set()
    for e in page.edges:
        if e['orientation'] == 'h' and e['x0'] <= name_col[0] + 6 and e['x1'] >= name_col[1] - 6 and 40 < e['top'] < page.height * 0.93:
            ys.add(round(e['top']))
    ys = sorted(ys)
    merged = []
    for y in ys:
        if merged and y - merged[-1] <= 3:
            continue
        merged.append(y)
    words = [w for w in page.extract_words(x_tolerance=1.5, extra_attrs=['fontname'])
             if cols[0][0] < (w['x0'] + w['x1']) / 2 < cols[-1][1] and 'Narrow' in w['fontname']]   # штампы (ArialMT) отбрасываем
    rows = []
    for i in range(len(merged) - 1):
        y0, y1 = merged[i], merged[i + 1]
        cell = {k: [] for k in KEYS}
        for w in words:
            yc = (w['top'] + w['bottom']) / 2
            if y0 < yc < y1:
                xc = (w['x0'] + w['x1']) / 2
                for x0, x1, k in cols:
                    if x0 <= xc < x1:
                        cell[k].append(w); break
        out = {'y0': y0, 'y1': y1}
        nm = cell['name']
        out['bold'] = bool(nm) and sum('Bold' in w['fontname'] for w in nm) * 2 >= len(nm)
        out['italic'] = bool(nm) and sum('Italic' in w['fontname'] for w in nm) * 2 >= len(nm)
        for k, v in cell.items():
            v = sorted(v, key=lambda w: w['top'])
            lines, cur, ct = [], [], None
            for w in v:
                if ct is None or abs(w['top'] - ct) <= 3:
                    cur.append(w); ct = w['top'] if ct is None else ct
                else:
                    lines.append(cur); cur = [w]; ct = w['top']
            if cur:
                lines.append(cur)
            lines = [' '.join(x['text'] for x in sorted(l, key=lambda w: w['x0'])) for l in lines]
            txt = join_lines(lines, mark=(k == 'type')).replace('​', '')
            if k == 'note':
                for sp in STAMPS:
                    txt = re.sub(r'\s*' + sp + r'\s*', ' ', txt)
            out[k] = re.sub(r'\s+', ' ', txt).strip()
        if any(out[k] for k in KEYS):
            rows.append(out)
    return rows


def merge_rows(rows):
    """Склейка строк-продолжений с позициями / заголовками. Возвращает список записей:
    {'kind': 'item'|'header'|'sub', ...}"""
    out = []
    for r in rows:
        is_header_text = r['bold'] and not re.match(r'^\d+$', r['pos'])
        if re.match(r'^\d+$', r['pos']):
            rec = {k: r[k] for k in KEYS}; rec['kind'] = 'item'; rec['lines'] = 1
            out.append(rec)
        elif re.match(r'^[aаб]\.\s*(Оборудование|Материалы)\s*$', r['name']) or (r['italic'] and re.match(r'^[aаб]\.', r['name'])):
            out.append({'kind': 'sub', 'name': r['name']})
        elif r['italic'] and not r['pos'] and not r['unit'] and not r['qty']:
            # курсивный подзаголовок (вентмодули «Одиночный вентиляционный модуль … марки ВМ.ОЦ.1 (380 шт.), в составе:»)
            if out and out[-1]['kind'] == 'modhdr':
                out[-1]['name'] += ' ' + r['name']
            else:
                out.append({'kind': 'modhdr', 'name': r['name']})
        elif is_header_text or (not r['pos'] and not r['unit'] and not r['qty'] and out and out[-1]['kind'] == 'header' and not r['type'] and not r['mass']):
            if out and out[-1]['kind'] == 'header' and r['bold'] and not (ROMAN_RE.match(out[-1]['name'].strip()) and r['name'].startswith('КОРПУС')):
                out[-1]['name'] += ' ' + r['name']
            elif r['bold']:
                out.append({'kind': 'header', 'name': r['name']})
            else:
                # не жирная строка без позиции после заголовка — считаем продолжением заголовка (редко)
                out[-1]['name'] += ' ' + r['name']
        else:
            # продолжение предыдущей позиции
            if not out or out[-1]['kind'] != 'item':
                # продолжение с предыдущей страницы: вернём как 'cont'
                out.append({'kind': 'cont', **{k: r[k] for k in KEYS}})
                continue
            it = out[-1]
            for k in ('name', 'code', 'supplier', 'note'):
                if r[k]:
                    it[k] = (it[k] + ' ' + r[k]).strip()
            if r['type']:
                it['type'] = join_lines([it['type'], r['type']], mark=True) if it['type'] else r['type']
            for k in ('unit', 'qty', 'mass'):
                if r[k] and not it[k]:
                    it[k] = r[k]
            it['lines'] += 1
    return out


def extract_pages(pdf_path, pages, tag='С-', cols=None):
    """Извлечение всех страниц спецификации → список записей (item/header/sub) с 'page' и 'sheet'."""
    recs = []
    with pdfplumber.open(pdf_path) as pdf:
        for n, pn in enumerate(pages, start=1):
            p = pdf.pages[pn - 1]
            c = cols or page_columns(p)
            rr = merge_rows(raw_rows(p, c))
            for r in rr:
                r['page'] = pn; r['sheet'] = n; r['src'] = f'{tag}{pn}'
            # перенос продолжения на предыдущую позицию (разрыв страницы)
            for r in rr:
                if r['kind'] == 'cont':
                    prev = next((x for x in reversed(recs) if x['kind'] == 'item'), None)
                    if prev is not None:
                        for k in ('name', 'code', 'supplier', 'note'):
                            if r[k]:
                                prev[k] = (prev[k] + ' ' + r[k]).strip()
                        if r['type']:
                            prev['type'] = join_lines([prev['type'], r['type']], mark=True) if prev['type'] else r['type']
                        for k in ('unit', 'qty', 'mass'):
                            if r[k] and not prev[k]:
                                prev[k] = r[k]
                        prev.setdefault('sheets_extra', []).append(n)
                else:
                    recs.append(r)
            p.flush_cache()
    return recs


ROMAN_RE = re.compile(r'^(I|II|III|IV|V|VI|VII|VIII|IX|X)\.\s*(.+)$')
KORP_RE = re.compile(r'^КОРПУС\s*(\d)\.\s*(.*)$')
SYS_RE2 = re.compile(r'(?<![А-Яа-яA-Za-z0-9])((?:ДПЕ|ДП|ДВ|ПЕ|ВЕ|ПУ|П|В|У|К|ВМ|СК)\d+(?:\.\d+)*)')


def structure(recs):
    """Разметка: section (римский раздел), korpus, system, sys_desc, sub (a/б). Возвращает список позиций."""
    section = korpus = system = sys_desc = sub = None
    items = []
    for r in recs:
        if r['kind'] == 'header':
            nm = r['name'].strip()
            m = ROMAN_RE.match(nm)
            if m:
                section = nm; continue
            m = KORP_RE.match(nm)
            if m:
                korpus = int(m.group(1)); rest = m.group(2)
                found = SYS_RE2.findall(rest)
                system = ', '.join(found) if found else ('ВЕ (квартиры)' if 'квартир' in rest else None)
                sys_desc = rest
                continue
            # продолжение заголовка «КОРПУС N. …» с новой страницы: дописываем описание и систему
            sys_desc = ((sys_desc or '') + ' ' + nm).strip()
            found = SYS_RE2.findall(nm)
            if found:
                system = ', '.join(found) if not system else system + ', ' + ', '.join(found)
            continue
        if r['kind'] == 'sub':
            sub = 'a' if r['name'].lower().startswith('a') else 'б'; continue
        if r['kind'] == 'modhdr':
            nm = r['name'].strip()
            mm = re.search(r'марки\s+(\S+?)\s*\((\d+)\s*шт', nm)
            system = f'{mm.group(1)} ({mm.group(2)} шт.)' if mm else nm[:40]
            sys_desc = nm
            continue
        if r['kind'] != 'item':
            continue
        if not r['unit'] and not r['qty']:
            # псевдозаголовок, оформленный как позиция (например «Системы ПУ …», «Кондиционирование»)
            nm = r['name'].strip()
            found = SYS_RE2.findall(nm)
            if nm.startswith('Системы ПУ'):
                korpus = None; system = ', '.join(found) or 'ПУ'; sys_desc = nm
            elif section and 'КОНДИЦИОН' in section.upper():
                korpus = None; system = 'Кондиционирование'; sys_desc = nm
            else:
                print('INFO: позиция без ед.изм./кол-ва (пропущена):', r['src'], nm[:80])
            continue
        if r['qty'] and not re.match(r'^[\d\s.,]+$', r['qty']):
            print('SKIP (нечисловое количество):', r['src'], r['name'][:50], '|', r['qty'])
            continue
        r = dict(r)
        r['section'] = section; r['korpus'] = korpus; r['system'] = system; r['sys_desc'] = sys_desc; r['sub'] = sub
        items.append(r)
    return items


def subsystem2(section):
    s = (section or '').upper()
    if 'ПРОТИВОДЫМН' in s:
        return 'ПД'
    if 'КОНДИЦИОН' in s:
        return 'КОНД'
    return 'ОВ'


DUCT_KIND_RE = re.compile(r'Воздуховод[ыа]?\s+(?:оцинкованн\w+\s+)?(прямоугольного|круглого) сечения')
DUCT_T_RE = re.compile(r'толщин\w*\s*(?:стенки\s*)?([\d.,]+)\s*мм')
DUCT_SIZE_RE = re.compile(r'(?:Ø\s*(\d+)|(\d+)\s*[xх]\s*(\d+))\s*$')


def norm_t(t):
    t = t.replace('.', ',').rstrip(',')
    if t in ('1,0', '1,00'):
        return '1'
    return t


def duct_info2(name):
    """Воздуховоды спецификации (м): вид по сечению в конце наименования, толщина → как в КЦ ('0,8', '1')."""
    if not DUCT_KIND_RE.search(name) or 'Полужестк' in name:
        return None
    mt = DUCT_T_RE.search(name); ms = DUCT_SIZE_RE.search(name.strip())
    if not mt or not ms:
        return None
    t = norm_t(mt.group(1))
    if ms.group(1):
        d = int(ms.group(1))
        return {'kind': 'кругл', 'size': str(d), 't': t, 'per': math.pi * d / 1000}
    w, h = int(ms.group(2)), int(ms.group(3))
    return {'kind': 'прям', 'size': f'{w}x{h}', 't': t, 'per': 2 * (w + h) / 1000}
