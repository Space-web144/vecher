# -*- coding: utf-8 -*-
"""
qa_check.py — машинная приёмка готового файла проверки ТКП (контроли 3–4 конвейера).

    python qa_check.py <Проверка_ТКП_….xlsx> [--orig <исходный ТКП.xlsx>] [--section ОВ2|ВК|ОВ1|НС]

Печатает JSON: {"passed": bool, "checks": [{"id", "ok", "detail"}...], "stats": {...}}; код выхода 1 при провале.
Проверяет форму результата, а не правильность инженерных выводов — их проверяет субагент по чек-листу.
"""
import argparse
import json
import sys
import zipfile

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter, column_index_from_string

OK_FILLS = {'FFC6EFCE', 'FFFFEB9C', 'FFFFC7CE', 'FFF2F2F2', 'FFF7F7F7', 'FFFFF2CC', 'FFDDEBF7', '00000000'}
REQUIRED = ['Пояснения', 'ТКП', 'Сводная по спецификации']
BY_SECTION = {'ОВ2': ['Воздуховоды м2', 'Анализ вент. оборудования'],
              'ВК': [],                       # «Чугун SML», «Комплексные трубопроводы» — только если в ТКП есть SML / комплексные ПП
              'ОВ1': ['Окраска и объёмы работ', 'Отопительные приборы'],
              'НС': ['Анализ насосного оборудования']}
ERRORS = ('#VALUE!', '#DIV/0!', '#REF!', '#NAME?', '#NULL!', '#NUM!', '#N/A')


def add(checks, cid, ok, detail=''):
    checks.append({'id': cid, 'ok': bool(ok), 'detail': detail})


def find_header(ws, text, rows=(5, 6, 7)):
    for r in rows:
        for c in range(1, ws.max_column + 1):
            v = ws.cell(r, c).value
            if isinstance(v, str) and text in v:
                return c
    return None


def _same(a, b):
    """Значение ячейки не изменилось: 1.0 и 1 (openpyxl пересохраняет числа «1.0» как «1») — одно и то же."""
    if isinstance(a, (int, float)) and isinstance(b, (int, float)) and not isinstance(a, bool) and not isinstance(b, bool):
        return abs(a - b) <= 1e-9 * max(1.0, abs(a))
    return str(a) == str(b)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('path')
    ap.add_argument('--orig')
    ap.add_argument('--section', choices=list(BY_SECTION))
    a = ap.parse_args()
    checks, stats = [], {}

    with zipfile.ZipFile(a.path) as z:
        app = z.read('docProps/app.xml').decode('utf-8', 'ignore') if 'docProps/app.xml' in z.namelist() else ''
    add(checks, 'not_libreoffice_saved', 'LibreOffice' not in app, 'файл, сохранённый LibreOffice, не отгружается')

    wb = load_workbook(a.path, rich_text=True)
    wv = load_workbook(a.path, data_only=True)
    names = wb.sheetnames
    need = REQUIRED + BY_SECTION.get(a.section, [])
    miss = [n for n in need if n not in names]
    add(checks, 'sheets_present', not miss, f'нет листов: {miss}' if miss else ', '.join(names))
    if 'Пояснения' in names and 'ТКП' in names:
        add(checks, 'notes_before_tkp', names.index('Пояснения') < names.index('ТКП'), 'лист «Пояснения» — перед «ТКП»')
    if a.orig:
        ow = load_workbook(a.orig)
        for n in ('Изменения', 'ТКП с формулами'):
            if n not in ow.sheetnames:
                continue
            if n not in names:
                add(checks, f'orig_sheet_{n}', False, f'исходный лист «{n}» отсутствует')
                continue
            so, sn = ow[n], wb[n]
            diff = [f'{get_column_letter(c)}{r}' for r in range(1, max(so.max_row, sn.max_row) + 1)
                    for c in range(1, max(so.max_column, sn.max_column) + 1)
                    if not _same(so.cell(r, c).value, sn.cell(r, c).value)]
            add(checks, f'orig_sheet_{n}', not diff, f'лист «{n}» не изменён' if not diff else f'изменены ячейки: {diff[:10]}')
    if 'ТКП' not in names:
        print(json.dumps({'passed': False, 'checks': checks}, ensure_ascii=False, indent=1))
        sys.exit(1)

    ws, wsv = wb['ТКП'], wv['ТКП']
    c_name = find_header(ws, 'Спецификация')
    c_chk = find_header(ws, 'Результат проверки')
    c_rem = find_header(ws, 'Замечания')
    add(checks, 'added_columns', all([c_name, c_chk, c_rem]),
        f'спецификация={get_column_letter(c_name) if c_name else None}, результат={get_column_letter(c_chk) if c_chk else None}, '
        f'замечания={get_column_letter(c_rem) if c_rem else None}')
    add(checks, 'freeze_panes', ws.freeze_panes == 'J8', f'закрепление: {ws.freeze_panes}')
    add(checks, 'autofilter', bool(ws.auto_filter.ref), f'автофильтр: {ws.auto_filter.ref}')
    if c_name:
        price_cols = [get_column_letter(i) for i in range(10, c_name)]
        not_grouped = [c for c in price_cols if not (ws.column_dimensions[c].outlineLevel == 1 and ws.column_dimensions[c].hidden)]
        add(checks, 'price_columns_collapsed', not not_grouped, f'не свёрнуты: {not_grouped[:10]}' if not_grouped else f'J–{price_cols[-1]} свёрнуты')

    # строки работ / материалов: у каждой должен быть результат проверки
    no_result, works, mats, colors = [], 0, 0, {}
    if c_chk:
        chk_letter = get_column_letter(c_chk)
        for r in range(8, ws.max_row + 1):
            b, f, i = ws.cell(r, 2).value, ws.cell(r, 6).value, ws.cell(r, 9).value
            is_work = bool(b) and bool(f)
            is_mat = not b and bool(f) and i is not None
            if not (is_work or is_mat):
                continue
            works += is_work
            mats += is_mat
            cell = ws[f'{chk_letter}{r}']
            if cell.value in (None, ''):
                no_result.append(r)
            rgb = cell.fill.fgColor.rgb if cell.fill and cell.fill.fill_type == 'solid' else '00000000'
            colors[rgb] = colors.get(rgb, 0) + 1
        add(checks, 'every_row_has_result', not no_result, f'строки без результата: {no_result[:30]}' if no_result else f'работ {works}, материалов {mats}')
        bad_colors = {k: v for k, v in colors.items() if isinstance(k, str) and k not in OK_FILLS}
        add(checks, 'pastel_colors_only', not bad_colors, f'посторонние заливки в «Результате»: {bad_colors}' if bad_colors else str(colors))
        stats.update(work_rows=works, material_rows=mats,
                     red=colors.get('FFFFC7CE', 0), yellow=colors.get('FFFFEB9C', 0), green=colors.get('FFC6EFCE', 0))

    # ошибки и кэш значений формул по всей книге
    err_cells, no_cache, n_formulas = [], [], 0
    for sh in wb.worksheets:
        shv = wv[sh.title]
        for row in sh.iter_rows():
            for c in row:
                v = c.value
                if isinstance(v, str) and v.startswith('='):
                    n_formulas += 1
                    cv = shv[c.coordinate].value
                    if cv is None:
                        no_cache.append(f'{sh.title}!{c.coordinate}')
                    elif isinstance(cv, str) and cv.startswith(ERRORS):
                        err_cells.append(f'{sh.title}!{c.coordinate}={cv}')
    add(checks, 'no_formula_errors', not err_cells, f'{len(err_cells)}: {err_cells[:15]}' if err_cells else f'формул {n_formulas}')
    share = 1 - len(no_cache) / n_formulas if n_formulas else 1
    add(checks, 'cached_values', share >= 0.98, f'с кэш-значением {share:.1%} формул; без значения напр.: {no_cache[:8]}')
    stats['formulas'] = n_formulas

    # сводная: у каждой позиции спецификации есть статус
    if 'Сводная по спецификации' in names:
        sv = wb['Сводная по спецификации']
        c_st = hdr_row = None
        for r in range(1, 30):
            for c in range(1, sv.max_column + 1):
                if sv.cell(r, c).value == 'Статус в ТКП':
                    c_st, hdr_row = c, r
                    break
            if c_st:
                break
        if c_st:
            empty, n, unm = [], 0, 0
            for r in range(hdr_row + 1, sv.max_row + 1):
                first = sv.cell(r, 1).value
                if isinstance(first, (int, float)):           # строка позиции (№), не заголовок блока
                    n += 1
                    st = sv.cell(r, c_st).value
                    if not st:
                        empty.append(r)
                    elif str(st).startswith('НЕ разнесено'):
                        unm += 1
            add(checks, 'summary_status_filled', not empty, f'позиций {n}, без статуса: {empty[:20]}')
            stats.update(spec_positions=n, not_distributed=unm)
        else:
            add(checks, 'summary_status_filled', False, 'столбец «Статус в ТКП» не найден')

    passed = all(c['ok'] for c in checks)
    print(json.dumps({'passed': passed, 'checks': checks, 'stats': stats}, ensure_ascii=False, indent=1))
    sys.exit(0 if passed else 1)


if __name__ == '__main__':
    main()
