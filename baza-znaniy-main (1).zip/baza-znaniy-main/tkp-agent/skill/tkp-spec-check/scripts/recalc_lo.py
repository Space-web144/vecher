# -*- coding: utf-8 -*-
"""
recalc_lo.py — пересчёт формул КОПИИ книги Excel через LibreOffice (headless) и отчёт об ошибках формул.

Замена пути /mnt/skills/public/xlsx/scripts/recalc.py, который есть только в claude.ai.
Интерфейс совместим с tkp_toolkit.recalc_copy(): вызов
    python recalc_lo.py <file.xlsx> [timeout_seconds]
печатает в stdout JSON:
    {"status": "success" | "errors_found", "total_errors": N, "total_formulas": M,
     "error_summary": {"#REF!": {"count": k, "locations": [...]}, ...}}
либо {"error": "..."} и код выхода 1.

Файл ПЕРЕЗАПИСЫВАЕТСЯ на месте — передавайте только копию (tkp_toolkit так и делает).
Зависимости: LibreOffice (soffice в PATH), openpyxl.
"""
import json
import os
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

ERRORS = ('#VALUE!', '#DIV/0!', '#REF!', '#NAME?', '#NULL!', '#NUM!', '#N/A')
MAX_LOC = 100

MACRO = """<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE script:module PUBLIC "-//OpenOffice.org//DTD OfficeDocument 1.0//EN" "module.dtd">
<script:module xmlns:script="http://openoffice.org/2000/script" script:name="Module1" script:language="StarBasic">
Sub RecalcAndStore()
  ThisComponent.calculateAll()
  ThisComponent.store()
  ThisComponent.close(True)
End Sub
</script:module>"""


def _soffice():
    for name in ('soffice', 'libreoffice'):
        p = shutil.which(name)
        if p:
            return p
    return None


def _make_profile(soffice, profile: Path, timeout):
    """Создаёт временный профиль LibreOffice и кладёт в него макрос пересчёта."""
    url = profile.as_uri()
    subprocess.run([soffice, '--headless', '--terminate_after_init', f'-env:UserInstallation={url}'],
                   capture_output=True, timeout=timeout)
    std = profile / 'user' / 'basic' / 'Standard'
    if not std.exists():
        raise RuntimeError('LibreOffice не создал профиль пользователя')
    (std / 'Module1.xba').write_text(MACRO, encoding='utf-8')
    return url


def _scan(path):
    """Ошибки формул в кэшированных значениях + число формул."""
    from openpyxl import load_workbook
    found = {e: [] for e in ERRORS}
    wb_v = load_workbook(path, data_only=True)
    for ws in wb_v.worksheets:
        for row in ws.iter_rows():
            for c in row:
                v = c.value
                if isinstance(v, str) and v.startswith('#'):
                    for e in ERRORS:
                        if v.startswith(e):
                            found[e].append(f'{ws.title}!{c.coordinate}')
                            break
    wb_v.close()
    wb_f = load_workbook(path, data_only=False)
    n_f = sum(1 for ws in wb_f.worksheets for row in ws.iter_rows() for c in row
              if isinstance(c.value, str) and c.value.startswith('='))
    wb_f.close()
    total = sum(len(v) for v in found.values())
    summary = {e: {'count': len(v), 'locations': v[:MAX_LOC]} for e, v in found.items() if v}
    return {'status': 'success' if total == 0 else 'errors_found', 'total_errors': total,
            'total_formulas': n_f, 'error_summary': summary}


def recalc(path, timeout=180):
    path = str(Path(path).resolve())
    if not os.path.exists(path):
        return {'error': f'файл не найден: {path}'}
    soffice = _soffice()
    if not soffice:
        return {'error': 'LibreOffice (soffice) не найден в PATH'}
    before = os.stat(path).st_mtime_ns
    with tempfile.TemporaryDirectory(prefix='recalc-lo-') as tmp:
        try:
            url = _make_profile(soffice, Path(tmp), min(timeout, 60))
        except subprocess.TimeoutExpired:
            return {'error': 'LibreOffice: таймаут при создании профиля'}
        except Exception as e:  # noqa: BLE001
            return {'error': f'LibreOffice: {e}'}
        cmd = [soffice, '--headless', '--norestore', f'-env:UserInstallation={url}',
               'vnd.sun.star.script:Standard.Module1.RecalcAndStore?language=Basic&location=application', path]
        try:
            res = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        except subprocess.TimeoutExpired:
            return {'error': f'LibreOffice: пересчёт не уложился в {timeout} с'}
        if res.returncode != 0:
            return {'error': f'LibreOffice завершился с кодом {res.returncode}: {(res.stderr or "").strip()[:500]}'}
    if os.stat(path).st_mtime_ns == before:
        return {'error': 'LibreOffice не перезаписал файл — пересчёт не выполнен (проверьте, что не запущен другой экземпляр)'}
    return _scan(path)


def main():
    if len(sys.argv) < 2:
        print(json.dumps({'error': 'использование: python recalc_lo.py <file.xlsx> [timeout]'}, ensure_ascii=False))
        sys.exit(1)
    timeout = int(sys.argv[2]) if len(sys.argv) > 2 else 180
    out = recalc(sys.argv[1], timeout)
    print(json.dumps(out, ensure_ascii=False, indent=1))
    sys.exit(1 if 'error' in out else 0)


if __name__ == '__main__':
    main()
