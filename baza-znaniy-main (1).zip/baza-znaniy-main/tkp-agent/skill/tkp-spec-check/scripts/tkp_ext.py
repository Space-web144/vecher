# -*- coding: utf-8 -*-
"""
tkp_ext.py — локальные доработки к tkp_toolkit.py для работы вне claude.ai (библиотеку не изменяем).

    import tkp_toolkit as tk
    from tkp_toolkit import *
    import tkp_ext as ext
    ext.configure()                       # пути, скрипт пересчёта (env или аргументы)
    ext.add_stamps([r'АШ\\d{5}-\\d{2}'])    # штампы проектировщика поверх таблицы
    ext.set_header('supplier', r'^(Поставщик|Завод)')
    ...
    rep.delete_rows(ext.zero_rate_rows_full(t))
    ext.assert_complete(rep, agg, t)      # полнота сопоставления (контроль 2)
    ws = rep.build(...)
    ext.shorten_results(ws, rep.cols['chk'], t.data_start)
    ext.autofit_heights(ws, rep.cols, t.data_start)
    ...
    res = finalize(OUT, orig_path=..., old2new=rep.old2new, deleted=rep.deleted)
    ext.assert_finalized(res, OUT)        # контроль 3 (OUT — отгружаемый файл: проверка «не сохранён LibreOffice»)

Закрывает доработки 1, 2, 4, 6, 9 из ТЗ на агента; остальные (5, 7, 8) — по месту в сценарии.
"""
import os
import re
import math
import zipfile

import tkp_toolkit as tk

HERE = os.path.dirname(os.path.abspath(__file__))
WORK = os.environ.get('TKP_WORK', '/home/claude/work')
OUT_DIR = os.environ.get('TKP_OUT_DIR', '/mnt/user-data/outputs')


# ----------------------------------------------------------------------------- 1, 2. пути и пересчёт
def configure(recalc_script=None, work=None, out_dir=None, timeout=180):
    """Подменяет путь к скрипту пересчёта (по умолчанию в tkp_toolkit — путь claude.ai) и рабочие каталоги.
    Порядок поиска скрипта: аргумент → $TKP_RECALC_SCRIPT → scripts/recalc_lo.py рядом с этим модулем → путь claude.ai."""
    global WORK, OUT_DIR
    cands = [recalc_script, os.environ.get('TKP_RECALC_SCRIPT'), os.path.join(HERE, 'recalc_lo.py'),
             '/mnt/skills/public/xlsx/scripts/recalc.py']
    script = next((c for c in cands if c and os.path.exists(c)), None)
    if script is None:
        raise RuntimeError('Не найден скрипт пересчёта: положите recalc_lo.py рядом с tkp_ext.py или задайте TKP_RECALC_SCRIPT')
    tk.recalc_copy.__defaults__ = (script, timeout)      # finalize() вызывает recalc_copy(path) с умолчаниями
    WORK = work or WORK
    OUT_DIR = out_dir or OUT_DIR
    os.makedirs(WORK, exist_ok=True)
    os.makedirs(OUT_DIR, exist_ok=True)
    return {'recalc_script': script, 'work': WORK, 'out_dir': OUT_DIR}


def out_path(name):
    return os.path.join(OUT_DIR, name)


# ----------------------------------------------------------------------------- 6. настройка извлечения
def add_stamps(patterns):
    """Дополнить STAMP_PATTERNS НА МЕСТЕ (список — значение по умолчанию extract_spec_page, переприсваивать нельзя)."""
    for p in patterns:
        if p not in tk.STAMP_PATTERNS:
            tk.STAMP_PATTERNS.append(p)
    return list(tk.STAMP_PATTERNS)


def set_header(key, regex):
    """Переопределить распознавание заголовка столбца: key ∈ pos, name, type, code, supplier, unit, qty, mass, note."""
    for i, (k, _) in enumerate(tk.HEADER_KEYS):
        if k == key:
            tk.HEADER_KEYS[i] = (key, regex)
            return
    raise KeyError(key)


def split_unit_qty(rows):
    """Спецификации с заголовком «Кол.»: ед. изм. и количество распознаются одним столбцом — разделить."""
    out = []
    for r in rows:
        r = dict(r)
        if not r.get('qty'):
            m = re.match(r'^(\D+?)\s+([\d\s.,]+)$', r.get('unit') or '')
            if m:
                r['unit'], r['qty'] = m.group(1).strip(), m.group(2).strip()
            else:
                r.setdefault('qty', '')
        out.append(r)
    return out


def drop_column_numbering(rows):
    """Строка нумерации граф «1 | 2 | 3 …» под шапкой таблицы."""
    return [r for r in rows if not (r.get('pos') == '1' and r.get('name') == '2')]


INVISIBLE = dict.fromkeys(map(ord, '​ㅤ­'), None)


def clean_text(s):
    return re.sub(r'\s+', ' ', (s or '').translate(INVISIBLE)).strip()


# ----------------------------------------------------------------------------- 4. нулевые расценки
def zero_rate_rows_full(t):
    """Как Tkp.zero_rate_rows(), но также работы с нулевым объёмом БЕЗ материалов (пропускаются библиотекой)."""
    rows = []
    for w in t.works():
        if t.qty(w) == 0:
            rows.append(w)
            rows += t.children(w)
    return rows


# ----------------------------------------------------------------------------- контроль 2: полнота
def default_out_of_scope(x):
    """Позиции вне области ТКП (не считаются потерянными): КОНД/ТМ/отопление в проверке ОВ2, явная пометка."""
    return x.get('ss') == 'КОНД' or bool(x.get('out_of_scope'))


def assert_complete(rep, agg, t, out_of_scope=default_out_of_scope, share_tol=1e-6):
    """КОНТРОЛЬ 2 (полнота).
    • каждая неудалённая строка материала ТКП — в rep.MAP (match / pcs / krep);
    • каждая позиция спецификации учтена ровно один раз: MAP ∪ DUCT ∪ VIRTUAL ∪ BLOCKS ∪ INCLUDED;
      воздуховод, разнесённый по слотам (std/nonstd), допускается в нескольких группах, если Σ долей = 1;
    • родители производных позиций (x['derived_from']) и позиции вне области (out_of_scope) не считаются потерянными
      (вне области — должны быть в «Сводной» со статусом «вне ТКП»)."""
    mats = [r for r in range(t.data_start, t.max_row + 1) if t.is_material(r) and r not in rep.deleted]
    missing = [r for r in mats if r not in rep.MAP]
    used, shares = {}, {}
    for r, d in rep.MAP.items():
        if r in rep.deleted:
            continue
        for i in d['ids']:
            used.setdefault(i, []).append(r)
    for r, info in getattr(rep, 'DUCT', {}).items():
        for i, sh in info['items']:
            shares.setdefault(i, []).append((f'duct:{r}', sh))
    for v in getattr(rep, 'VIRTUAL', []):
        for i, sh in v['items']:
            shares.setdefault(i, []).append((f'virtual:{v["after"]}', sh))
    for _, _, ids in rep.BLOCKS:
        for i in ids:
            used.setdefault(i, []).append('block')
    for i in rep.INCLUDED:
        used.setdefault(i, []).append('incl')
    bad_share = {}
    for i, lst in shares.items():
        tot = sum(sh for _, sh in lst)
        if abs(tot - 1.0) > share_tol:
            bad_share[i] = (round(tot, 4), [w for w, _ in lst])
        used.setdefault(i, []).append('duct')          # одна запись на позицию независимо от числа слотов
    parents = {p for x in agg if x.get('derived_from') for p in x['derived_from']}
    oos = {x['id'] for x in agg if out_of_scope and out_of_scope(x)}
    dup = {i: v for i, v in used.items() if len(v) > 1}
    lost = [x['id'] for x in agg if x['id'] not in used and x['id'] not in parents and x['id'] not in oos]
    problems = []
    if missing:
        problems.append(f'строки ТКП без сопоставления: {missing[:30]}')
    if dup:
        problems.append(f'задвоение позиций спецификации: {list(dup.items())[:15]}')
    if bad_share:
        problems.append(f'воздуховоды: Σ долей по слотам ≠ 1: {list(bad_share.items())[:10]}')
    if lost:
        A = {x['id']: x for x in agg}
        problems.append('потеряны позиции спецификации: ' + str([(i, A[i]['name'][:50]) for i in lost[:20]]))
    assert not problems, 'КОНТРОЛЬ 2 (полнота) не пройден:\n' + '\n'.join(problems)
    return {'tkp_material_rows': len(mats), 'spec_positions': len(agg), 'duct_positions': len(shares),
            'derived_parents': len(parents), 'out_of_scope': len(oos)}


# ----------------------------------------------------------------------------- 9. короткие тексты и высоты строк
SHORT_RULES = [
    (re.compile(r'Количество соответствует: Σ по спец\. ([\d\s,]+?) = КЦ [\d\s,]+ \((\d+) поз\. спец\.\)'), r'Кол-во \1 ✓ (\2 поз.)'),
    (re.compile(r'Кол-во (\d+),00 ✓'), r'Кол-во \1 ✓'),
]


def shorten_results(ws, chk_col, data_start=8):
    """Сокращение текстов столбца «Результат проверки» до итогов (правила ВК, п. 4)."""
    for r in range(data_start, ws.max_row + 1):
        c = ws[f'{chk_col}{r}']
        if isinstance(c.value, str) and not c.value.startswith('='):
            v = c.value
            for rx, rep_ in SHORT_RULES:
                v = rx.sub(rep_, v)
            v = v.replace('Соответствует. ОШИБКА номенклатуры: ', 'ОШИБКА номенклатуры: ').replace('Соответствует. ', '✓ ')
            c.value = re.sub(r'\s{2,}', ' ', v)


def _plain(v):
    if v is None:
        return ''
    if isinstance(v, str):
        return v
    try:                                   # CellRichText
        return ''.join(getattr(p, 'text', p) for p in v)
    except TypeError:
        return str(v)


def autofit_heights(ws, cols, data_start=8, widths=None, max_height=300):
    """Высота строк под длинные тексты в AQ / AT / AV (+ C, E исходника). Исходные высоты только увеличиваются.
    cols — rep.cols; widths — {буква: (ширина, коэф. символа, высота строки, pt)}."""
    widths = widths or {cols['name']: (80, 1.05, 15.5), cols['chk']: (52, 1.05, 15.5), cols['rem']: (75, 1.25, 18.5),
                        'C': (55, 1.2, 18.5), 'E': (38, 1.25, 18.5)}
    for r in range(data_start, ws.max_row + 1):
        if all(ws[f'{cols[k]}{r}'].value in (None, '') for k in ('name', 'chk', 'rem')):
            continue
        need = 19.5
        for col, (w, k, lh) in widths.items():
            txt = _plain(ws[f'{col}{r}'].value)
            if not txt or txt.startswith('='):
                continue
            lines = sum(max(1, math.ceil(len(part) * k / w)) for part in txt.split('\n'))
            need = max(need, lines * lh + 4)
        need = min(need, max_height)
        cur = ws.row_dimensions[r].height
        if cur is None or cur < need:
            ws.row_dimensions[r].height = need


def retag_spec_column(ws, col, old='[системы: ', new='[раздел спец.: ', data_start=8):
    """Подпись источника в AQ: для ОВ1 «[раздел спец.: …]», для НС «[система: …]». Сохраняет rich-text."""
    from openpyxl.cell.rich_text import CellRichText, TextBlock
    for r in range(data_start, ws.max_row + 1):
        c = ws[f'{col}{r}']
        if isinstance(c.value, str):
            c.value = c.value.replace(old, new)
        elif isinstance(c.value, CellRichText):
            parts = []
            for p in c.value:
                parts.append(TextBlock(p.font, p.text.replace(old, new)) if isinstance(p, TextBlock) else p.replace(old, new))
            c.value = CellRichText(parts)


# ----------------------------------------------------------------------------- контроль 3: целостность
def is_libreoffice_saved(path):
    """True, если файл последним сохранял LibreOffice (такой файл НЕ отгружать)."""
    with zipfile.ZipFile(path) as z:
        try:
            app = z.read('docProps/app.xml').decode('utf-8', 'ignore')
        except KeyError:
            return False
    return 'LibreOffice' in app


def assert_finalized(res, out=None):
    """Результат tk.finalize(): пересчёт без ошибок формул, verify без расхождений, файл не из LibreOffice."""
    problems = []
    rc = res.get('recalc', {})
    if rc.get('status') != 'success':
        problems.append(f'пересчёт: {rc}')
    v = res.get('verify')
    if v is None:
        problems.append('verify не выполнялся (передайте orig_path, old2new, deleted в finalize)')
    elif v.get('n_bad'):
        problems.append(f'verify: {v["n_bad"]} расхождений, напр. {v["bad"][:5]}')
    if out and is_libreoffice_saved(out):
        problems.append('отгружаемый файл сохранён LibreOffice')
    assert not problems, 'КОНТРОЛЬ 3 (целостность) не пройден:\n' + '\n'.join(problems)
    return True
