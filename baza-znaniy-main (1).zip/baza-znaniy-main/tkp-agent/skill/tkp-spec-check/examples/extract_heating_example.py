# -*- coding: utf-8 -*-
"""Извлечение спецификации ДВЛ-БСН-300-Р-ОВ1 (отопление и теплоснабжение) — локальные дополнения к tkp_toolkit."""
import json, re, sys
sys.path.insert(0, '/home/claude/work')
import tkp_toolkit as tk
from tkp_toolkit import *

PDF = '/home/claude/inputs/DVL-BSN-300-R-OV1.pdf'
# локально: столбец «Завод изготовитель» вместо «Поставщик»; штамп «ИК00566-00»
tk.HEADER_KEYS[4] = ('supplier', r'^(Поставщик|Завод)')
tk.HEADER_KEYS[5] = ('unit', r'^Ед(\.|ини)?$')
tk.STAMP_PATTERNS.append(r'ИК\d{5}-\d{2}')

pages = find_spec_pages(PDF)
print('spec pages', pages)
rows = extract_spec(PDF, pages)
print('rows', len(rows))
for r in rows:
    print(r['sheet'], '|', r['pos'][:20], '|', r['name'][:70], '|', r['type'][:35], '|', r['code'][:14], '|', r['supplier'][:18], '|', r['unit'], '|', r['qty'], '|', r['mass'], '|', r['note'][:30])
json.dump(rows, open('/home/claude/work/spec_rows.json', 'w'), ensure_ascii=False, indent=0)
