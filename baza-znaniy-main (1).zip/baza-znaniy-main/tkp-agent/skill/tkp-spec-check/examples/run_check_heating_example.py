# -*- coding: utf-8 -*-
"""ПРИМЕР (раздел ОВ1 — отопление и теплоснабжение, объект ДВЛ-БСН-300, ТКП 7869889). Структуру копировать; объектные данные (строки ТКП, номера позиций, замечания, тексты пояснений) писать заново. Запуск: extract → spec → run_check."""
"""Проверка ТКП 7869889 (АЛЬФАСТРОЙ ООО) — раздел ОВ1 «Отопление и теплоснабжение», наземный паркинг на 300 м/м, ул. Ижорская, 6/2.
Спецификация: ДВЛ-БСН-300-Р-ОВ1.СО (13 листов, стр. 21–33 PDF). ТР отсутствуют."""
import json, re, sys, math
sys.path.insert(0, '/home/claude/work')
import tkp_toolkit as tk
from tkp_toolkit import *
from spec_ov1 import SUB_NAME as SUB_NAME_OV1
from openpyxl.formatting.rule import FormulaRule
from openpyxl.utils import get_column_letter, column_index_from_string

WORK = '/home/claude/work'
TKP_XLSX = '/home/claude/inputs/tkp_7869889.xlsx'
OUT = '/mnt/user-data/outputs/Проверка_ТКП_7869889_ОВ1_отопление_по_спецификации.xlsx'

agg = json.load(open(f'{WORK}/spec_agg.json'))
items = json.load(open(f'{WORK}/spec_items.json'))
A = {x['id']: x for x in agg}


def P(*posnos):
    """id агрегированной позиции по номерам позиций спецификации (все указанные номера должны входить)."""
    res = [x for x in agg if all(p in x['posnos'] for p in posnos)]
    assert len(res) == 1, f'поз. {posnos}: найдено {len(res)}: {[(x["id"], x["name"][:40], x["type"]) for x in res]}'
    return res[0]['id']


def PT(posno, type_needle):
    res = [x for x in agg if posno in x['posnos'] and type_needle in x['type']]
    assert len(res) == 1, f'поз. {posno} {type_needle}: {len(res)}'
    return res[0]['id']


def PN(posno, name_needle):
    res = [x for x in agg if posno in x['posnos'] and name_needle in x['name']]
    assert len(res) == 1, f'поз. {posno} {name_needle}: {len(res)}'
    return res[0]['id']


def derived(i, parents, name, unit, qty, note='', typ='состав комплекта / производная позиция'):
    Pp = [A[p] for p in parents]
    x = {'id': i, 'ss': Pp[0]['ss'], 'name': name, 'type': typ, 'code': '', 'supplier': '', 'unit': unit, 'qty': qty, 'n': 1,
         'systems': sorted(set(s for p in Pp for s in p['systems'])), 'mass': '', 'note': note, 'notes': [],
         'sections': sorted(set(g for p in Pp for g in p['sections'] if g)), 'sheets': sorted(set(s for p in Pp for s in p['sheets'])),
         'posnos': sorted(set(pn for p in Pp for pn in p['posnos'])), 'rooms': [], 'derived_from': parents}
    agg.append(x); A[i] = x


# ---------- производные позиции (комплекты / пересчёт единиц)
REG = [P(7) if False else i for i in (6, 7, 8, 9)]
derived(1000, REG, 'Регистры гладкотрубные 4-рядные D=89x2,8 с краном Маевского и сливным краном (поз. 7): Σ длин (1×1,0 + 3×1,5 + 3×2,0 + 1×2,5) м × 4 ряда = 56 м (8 шт по спец.)',
        'м', 56.0, typ='пересчёт шт → м')
derived(1001, [43], 'Защитная гильза — в составе «Защитный комплект для подключения отопительного прибора» (поз. 37, 90 компл.)', 'шт.', 90.0)
derived(1002, [43], 'Фиксатор колена — в составе «Защитный комплект для подключения отопительного прибора» (поз. 37, 90 компл.)', 'шт.', 90.0)
derived(1003, [20, 105, 99], 'Металл сортовой для крепления (поз. 20, 130, 164: 5,1 + 245,4 + 0,9 кг) + крепёжный материал для узла смешения (поз. 159: 50 кг) = 301,4 кг → т',
        'т', round(301.4 / 1000, 4), typ='Σ кг → т')

# ---------- ТКП
t = Tkp(TKP_XLSX)
rep = Report(t, agg, items)
rep.delete_rows(t.zero_rate_rows())
rep.delete_rows([14])                     # нулевая расценка без материалов (от 131 до 200 мм, объём 0)

KREP = 'Сопутствующий нормативный материал КЦ (объём = длина трубопровода); в объём работы не входит, в спецификации не выделен.'
REZ = 'Сопутствующий материал КЦ (резьба под приварку к арматуре); в спецификации не выделен, не проверяется.'
M = rep.map
BYNOTE = 'По примечанию — соответствует'

# ===== Отопление (паркинг + НПКИ) =====
# работа 15: стальные трубы на сварке 15–60 мм
M(16, [P(128)], kind='match')
M(17, kind='krep', note=KREP)
M(18, [P(142)], kind='pcs', note='Гильза Ø89х3,0 по примечанию. Гильзы — сопутствующий материал расценки (в объём работы не входят).')
M(19, [P(141)], kind='pcs', note='Гильза Ø76х3,0 по примечанию (сопутствующий, в объём работы не входит).')
M(20, [P(27, 140)], kind='pcs', note='По примечанию: гильзы Ø57х3,0 — 1 м (паркинг) + 22,8 м (НПКИ) = 23,8 м (сопутствующий, в объём работы не входит).')
M(21, [P(18, 124)], kind='match', note='Σ паркинг 158 + НПКИ 175')
M(22, [P(19, 125)], kind='match', note='Σ паркинг 125 + НПКИ 720')
M(23, [P(126)], kind='match')
M(24, [P(127)], kind='match')
# работа 25: сшитый полиэтилен
M(26, [P(10), P(56)], kind='pcs', st='error', hl={P(10): [r'ВР-НР1/2"'], P(56): [r"1/2''ВР//2''ВР"]},
  note='ОШИБКА номенклатуры: в одной позиции муфта ВР-НР 1/2" (8 шт, обвязка регистров) и муфта ВР-ВР 1/2" (1 шт, узел перехода НПКИ№16) — разные типы изделий; в КЦ «удлинитель ВР/НР» (оговорено в примечании).')
M(27, [P(35)], kind='pcs', note=f'{BYNOTE}: соединитель американка 3/4"ВР (евроконус)/1/2"ВР (в КЦ ниппель 3/4"х1/2" евроконус, применительно).')
M(28, [P(36, 55, 58)], kind='pcs', note='Σ поз. 36 (90) + 55 (42) + 58 (1) = 133; Ростерм по примечанию.')
M(29, [1001], kind='pcs', note='Защитная гильза — по составу «Защитного комплекта» (поз. 37, 90 компл.).')
M(30, kind='krep', note=KREP)
M(31, [1002], kind='pcs', note='Фиксатор колена — по составу «Защитного комплекта» (поз. 37, 90 компл.).')
M(32, [P(129)], kind='match')
# работа 33: неподвижные опоры
M(34, [P(17, 123)], kind='match', note='Σ паркинг 4 + НПКИ 12 = 16 (серия 4.903-10, Ду20).')
M(35, [PN(123, 'Ду32')], kind='match')
M(36, [PN(123, 'Ду40')], kind='match')
M(37, [PN(123, 'Ду50')], kind='match', note='По примечанию: Ду50 (в КЦ D57).')
# работа 39: окраска — материалы по норме КЦ
M(40, kind='krep', note='Сопутствующий материал по норме КЦ (не проверяется). По спецификации: покрытие краской МА-15 за 2 раза по грунту ГФ-031 — 37 кг (поз. 22, 132); в КЦ эмаль ПФ-115 — тип краски отличается, уточнить.')
M(41, kind='krep', note='Сопутствующий материал по норме КЦ (не проверяется). По спецификации: грунтовка ГФ-031 в 2 слоя — 20,05 кг (поз. 21, 131).')
# работа 42: изоляция минвата
M(43, [P(136)], kind='match', note='32х40 мм по спец. ↔ цилиндр Ø42 (DN32) толщ. 40 мм.')
M(44, [P(138)], kind='match', note='50х40 мм по спец. ↔ цилиндр Ø57 (DN50) толщ. 40 мм.')
M(45, [P(137)], kind='match', note='40х40 мм по спец. ↔ цилиндр 48х40 (DN40).')
M(46, [P(25, 135)], kind='match', note='20х40 мм по спец. (паркинг 125 + НПКИ 720) ↔ цилиндр 28х40 (DN20).')
M(47, [P(24, 134)], kind='match', note='15х30 мм по спец. (паркинг 142 + НПКИ 175) ↔ цилиндр Ø21 (DN15) толщ. 30 мм.')
# работа 48: изоляция вспененный ПЭ
M(49, [P(139)], kind='match', note=f'{BYNOTE}: 16х9 мм по спец. (в КЦ 18х9).')
# работа 51: воздухоотводчики
M(52, [P(14, 120)], kind='match', note=f'{BYNOTE}: Aquasfera 5003-01 (в КЦ 5001-01). Σ паркинг 14 + НПКИ 50 = 64.')
M(53, kind='krep', note=REZ)
# работа 54: арматура муфтовая 15–20 мм
M(55, [P(52, 95)], kind='match', note=f'{BYNOTE}: кран с отводом под термодатчик Aquasfera 1226-01 Ду15 (4 + 1).')
M(56, [P(53, 116)], kind='match', note=f'{BYNOTE}: кран с отводом под термодатчик Aquasfera 1226-02 Ду20 (13 + 1).')
M(57, [P(70, 89, 110)], kind='match', note=f'{BYNOTE}: кран трёхходовой для манометра Росма е0062 (9 + 12 + 11).')
M(58, [P(16, 68, 86, 107, 122)], kind='pcs', note=f'{BYNOTE}: штуцер латунный НР для шланга 20 мм (20х1/2) Valtec (8 + 15 + 20 + 15 + 65). Фитинг — в объём работы не входит.')
M(59, [P(11), P(51, 94, 115), P(54, 57)], kind='pcs', st='error',
  hl={P(11): [r'Сгон ВР-ВР1/2"'], P(51, 94, 115): [r'Американка прямая 1/2\'\''], P(54, 57): [r'Соединитель латунь американка никель 1/2\'\'НР/1/2\'\'НР']},
  note='ОШИБКА номенклатуры: в одной позиции три разных изделия — сгон ВР-ВР 1/2" (8), американка прямая 1/2" к теплосчётчикам (36), соединитель американка 1/2"НР/1/2"НР евроконус (43); в КЦ «муфта-американка 1/2"» ×87 (оговорено в примечании).')
M(60, [P(12)], kind='pcs', note=f'{BYNOTE}: сгон ВР1/2"–ВР3/4" (обвязка регистров) — в КЦ муфта-американка 3/4" применительно.')
M(61, [P(63, 80, 101)], kind='match', note='Σ УУТ1 3 + УУТ2 1 + УУТ3 1.')
M(62, [P(64, 81, 102)], kind='match', note='Σ УУТ1 3 + УУТ2 6 + УУТ3 5.')
M(63, [P(9, 13, 15)], kind='match', note='Σ по 15 позициям спецификации (обвязка регистров, арматура, НПКИ, УУТ1–3, сливные, для воздухоотводчиков).')
M(64, [P(47, 61, 76, 98, 118)], kind='match', note='Σ 26 + 6 + 12 + 10 + 26.')
M(65, [P(66, 83, 104)], kind='match', note='Σ УУТ1 6 + УУТ2 7 + УУТ3 6.')
M(66, kind='krep', note=REZ)
M(67, kind='krep', note=REZ)
# работа 68: арматура 25–40
M(69, [P(65, 82, 103)], kind='match', note='Σ УУТ1 1 + УУТ2 1 + УУТ3 1.')
M(70, kind='krep', note=REZ)
# работа 71: фланцевые краны
M(72, [P(59, 74, 96)], kind='match', note='LD КШ.Ц.Ф.032.16.Н/П.02 по примечанию; Σ УУТ1–3 по 3 шт.')
M(73, kind='krep', note='Ответные фланцы — сопутствующий материал расценки (2 шт на кран = 18); в спецификации не выделены; по примечанию PN16.')
# работа 74: фильтры
M(75, [P(49)], kind='match')
M(76, [P(48)], kind='match')
M(77, [P(62, 77, 99)], kind='match', note='Σ УУТ1–3 по 1 шт.')
for r in (78, 79, 80):
    M(r, kind='krep', note=REZ)
# работа 82: термостатические клапаны
M(83, [P(38)], kind='match', note='Ридан TR-N 013G7013R (угловой) — аналог Danfoss 013G7013.')
M(84, [P(8)], kind='match', note='Ридан TR-N 013G7014R (прямой) — аналог Danfoss 013G7014.')
# работа 85: КИП
M(86, [P(71, 90, 111), P(73, 92, 113)], kind='pcs', note='Σ бобышки под манометр 32 + под термометр 6 = 38 (Росма №2 БП-БТ-55-G½).')
M(87, [P(69, 87, 108)], kind='match', note=f'{BYNOTE}: Росма ТМ-610Р.05 (0–1,6 МПа) ø150 (в КЦ ТМ-510Р Дк100). Σ 9 + 12 + 11.')
M(88, [P(72, 91, 112)], kind='match', note=f'{BYNOTE}: Росма БТ-51.211 (0–100 °C) G1/2. Σ 2 + 2 + 2.')
M(89, [], kind='pcs', note='в спецификации не предусмотрена')
# работы 90, 93: коллекторы
M(91, [P(40), P(41)], kind='match', st='error', hl={P(40): [r'левое подключение', r'\(Л\)'], P(41): [r'правое подключение', r'\(П\)']},
  note='ОШИБКА номенклатуры: левое (6) и правое (5) подключение — разные исполнения в одной позиции КЦ без примечания.')
M(92, [P(42), P(43)], kind='match', st='error', hl={P(42): [r'левое подключение', r'\(Л\)'], P(43): [r'правое подключение', r'\(П\)']},
  note='ОШИБКА номенклатуры: левое (1) и правое (1) подключение — разные исполнения в одной позиции КЦ без примечания.')
M(94, [P(44)], kind='match')
M(95, [P(45)], kind='match')
# работа 96: теплосчётчики
M(97, [P(50, 93, 114)], kind='match', note='Σ НПКИ 17 + УУТ2 1 + УУТ3 1.')
# работа 99: конвекторы TEPLA (в КЦ — на сварке)
TH = r'НР 3/4" резьбовое'
M(100, [PT(33, '3.909'), PT(34, '3.909')], kind='match', st='error', hl={PT(33, '3.909'): [TH], PT(34, '3.909'): [TH, r'\(НП К Прав\.\)']},
  note='ОШИБКА номенклатуры: по спец. подключение НР 3/4" резьбовое (в КЦ — «сварка», расценка «на сварке»); левое (7) и правое (1) исполнение в одной позиции (оговорено).')
M(101, [PT(33, '2.703'), PT(34, '2.703')], kind='match', st='error', hl={PT(33, '2.703'): [TH], PT(34, '2.703'): [TH, r'\(НП К Прав\.\)']},
  note='ОШИБКА номенклатуры: по спец. подключение НР 3/4" резьбовое (в КЦ — «сварка»); левое (1) и правое (5) исполнение в одной позиции (оговорено).')
M(102, [PT(33, '2.237')], kind='match', st='error', hl={PT(33, '2.237'): [TH]},
  note='ОШИБКА номенклатуры: по спец. подключение НР 3/4" резьбовое (в КЦ — «сварка», расценка «на сварке»).')
# работы 103, 106: конвекторы SPL
M(104, [PT(30, 'BFM-100/15')], kind='match', note='Qном 1698 Вт — категория 1001–2000 Вт ✓.')
M(105, [PT(29, 'BFM-110/9')], kind='match', note=f'{BYNOTE}: SPL BFM-110/9/24-4/1-E15, Qном 1836 Вт — категория 1001–2000 Вт ✓.')
M(107, [PT(30, 'BFM-140/15')], kind='match', note='Qном 2486 Вт — категория от 2001 Вт ✓.')
M(108, [PT(29, 'BFM-190/9')], kind='match', note=f'{BYNOTE}: SPL BFM-190/9/24-4/1-E15, Qном 3363 Вт ✓.')
M(109, [PT(30, 'BFM-160/15')], kind='match', note='Qном 2879 Вт ✓.')
M(110, [PT(29, 'BFM-230/9')], kind='match', note=f'{BYNOTE}: SPL BFM-230/9/24-4/1-E15, Qном 4217 Вт (наименование КЦ «230/09/14-2/1» не соответствует — определяет примечание).')
M(111, [PT(31, 'BFM-120/15')], kind='match', note='Qном 2824 Вт ✓.')
M(112, [PT(32, 'BFM-190/25')], kind='match', note=f'{BYNOTE}: BFM-190/25/24-8/2-E15-TP, Qном 4685 Вт (наименование КЦ «190/25/19-6/2» не соответствует — определяет примечание).')
M(113, [PT(31, 'BFM-180/15')], kind='match', note='Qном 4418 Вт ✓.')
# работа 114: регистры
M(115, [1000], kind='match', note='Регистры по спец. — 8 шт (1,0 м — 1; 1,5 м — 3; 2,0 м — 3; 2,5 м — 1), 4 ряда D89х2,8: 14 м × 4 = 56 м — соответствует примечанию.')
# работа 116: электроконвекторы
M(117, [P(5), P(2)], kind='match', st='error', hl={P(5): [r'ЭВУБ-1,5д'], P(2): [r'ЭВПБ - 1,5']},
  note='ОШИБКА номенклатуры: в одной позиции два типа приборов — ЭВУБ-1,5д (7 шт) и ЭВПБ-1,5 (1 шт), Делсот (оговорено в примечании; в КЦ Engy EN-1500).')
M(118, [P(6)], kind='match', note=f'{BYNOTE}: Делсот ЭВУБ-2,0д, 2,0 кВт (в КЦ ZILON ZHC-2000A).')
M(119, [P(3)], kind='match', st='unsure', hl={P(3): [r'ЭВУБ-0,5д']}, note='Марка по спец. ЭВУБ-0,5д, в КЦ ЭВУБ-0,5 — уточнить исполнение «д» в примечании.')
M(120, [P(4)], kind='match', st='unsure', hl={P(4): [r'ЭВУБ-1,0д']}, note='Марка по спец. ЭВУБ-1,0д, в КЦ ЭВУБ-1,0 — уточнить исполнение «д» в примечании.')
M(121, [P(1)], kind='match', note=f'{BYNOTE}: Делсот ЭВПБ-1,2, 1,2 кВт (в КЦ «настенный 1,5 кВт»).')
# работа 122: термоголовки
M(123, [P(39)], kind='match')

# ===== Теплоснабжение приточных установок =====
M(127, kind='krep', note=KREP)
M(128, [P(171)], kind='pcs', note='Гильза Ø76х3,0 по примечанию (сопутствующий).')
M(129, [P(170)], kind='pcs', note='Гильза Ø57х3,0 по примечанию (сопутствующий).')
M(130, [P(161)], kind='match', st='error',
  note='ОШИБКА: по примечанию в объём трубы DN15 включён нержавеющий присоединительный шланг Ду15 L=1000 мм — 4 шт (4 м) — другой тип материала; труба по спец. 190 м.')
M(131, [P(162)], kind='match')
M(132, [P(163)], kind='match')
M(134, [PN(160, 'Ду25')], kind='match')
M(135, [PN(160, 'Ду15')], kind='match')
M(138, kind='krep', note='Сопутствующий материал по норме КЦ (не проверяется). По спецификации: краска МА-15 — 1,4 кг (поз. 166); в КЦ эмаль ПФ-115 — тип краски отличается, уточнить.')
M(139, kind='krep', note='Сопутствующий материал по норме КЦ (не проверяется). По спецификации: грунтовка ГФ-031 — 0,8 кг (поз. 165).')
M(141, [P(169)], kind='match', note='25х40 мм по спец. ↔ цилиндр Ø35 (DN25) толщ. 40 мм.')
M(142, [P(168)], kind='match', note='20х40 мм по спец. ↔ цилиндр 28х40 (DN20).')
M(143, [P(167)], kind='match', note='15х30 мм по спец. ↔ цилиндр Ø21 (DN15) толщ. 30 мм.')
M(146, [P(156)], kind='match', note=f'{BYNOTE}: кран трёхходовой для манометра Росма е0062.')
M(147, [P(154)], kind='pcs', note=f'{BYNOTE}: штуцер для шланга 20х1/2 Valtec (фитинг — в объём работы не входит).')
M(148, [P(150)], kind='match')
M(149, [P(148, 151, 153)], kind='match', note='Σ 4 + 16 (для воздухоотводчиков) + 7 (сливные) = 27.')
M(150, [P(149)], kind='match')
M(151, kind='krep', note=REZ)
M(152, kind='krep', note=REZ)
M(154, [P(152)], kind='match', note=f'{BYNOTE}: Aquasfera 5003-01 (в КЦ 5001-01).')
M(155, kind='krep', note=REZ)
M(158, [P(158)], kind='pcs', note='По спецификации бобышки только под термометры — 8 шт (поз. 158); бобышки под манометры (12 шт) в спецификации теплоснабжения отсутствуют.')
M(159, [P(155)], kind='match', note=f'{BYNOTE}: Росма ТМ-610Р.05 (0–1,6 МПа) ø150.')
M(160, [P(157)], kind='match', note=f'{BYNOTE}: Росма БТ-51.211 (0–100 °C) G1/2.')
M(161, [], kind='pcs', note='в спецификации не предусмотрена')
M(163, [P(145), P(146)], kind='match', st='error', hl={P(146): [r'УС-\(Б\)-1-0\.6 24В \(0-10В\)'], P(145): [r'Ноиззлесс']},
  note='ОШИБКА номенклатуры: два разных типоразмера в одной позиции — УС-(Б)-1-1.0 24В (П1.1) и УС-(Б)-1-0.6 24В (П1.2), Ноиззлесс (в КЦ УС-С-1-1,0 ВентАрт ×2; оговорено в примечании).')
# ===== Прочие работы =====
M(168, [1003], kind='match', note='Σ металл сортовой для крепления 251,4 кг + крепёжный материал узла смешения 50 кг = 301,4 кг = 0,3014 т; профиль в спецификации не задан (в КЦ швеллер 12П).')

# ---------- не разнесено / учтено в составе
rep.unmatched_block(123, 'Материалы спецификации, НЕ разнесённые в ТКП — Отопление (паркинг + НПКИ)', [P(28, 143), P(144)])
rep.unmatched_block(163, 'Материалы спецификации, НЕ разнесённые в ТКП — Теплоснабжение приточных установок', [P(147), P(172)])
rep.INCLUDED[P(133)] = 'Учтено в составе сопутствующего материала КЦ «Крепежные элементы для трубопроводов / Сшитого полиэтилена» (ТКП стр. 30) — отдельно не выделяется'
for i, kr in ((P(21, 131), 41), (P(22, 132), 40), (P(165), 139), (P(166), 138)):
    rep.INCLUDED[i] = f'Учтено в составе окраски (расход по норме КЦ) → поз. КЦ {t.pos(kr)} — требует уточнения: спец. {fmt(A[i]["qty"])} кг / КЦ {fmt(t.qty(kr), 3)} кг ({t.name(kr)[:30]}…)'

# ---------- замечания (директивы подрядчику)
R = rep.remark
R(26, 'Добавить разными позициями: муфта ВР-НР 1/2" — 8 шт (обвязка регистров); муфта ВР-ВР 1/2" — 1 шт (узел перехода НПКИ№16)')
R(40, 'Уточнить тип краски: по спецификации покрытие краской МА-15 за 2 раза по грунту ГФ-031 (в КЦ эмаль ПФ-115)')
R(59, 'Добавить разными позициями: сгон ВР-ВР 1/2" — 8 шт; американка прямая 1/2" (к теплосчётчикам) — 36 шт; соединитель американка 1/2"НР/1/2"НР (евроконус) — 43 шт')
R(89, 'Уточнить: трубка демпферная в спецификации не предусмотрена (32 шт)')
R(91, 'Добавить разными позициями: коллекторная группа на 2 отв. левое подключение — 6 шт; правое — 5 шт (либо указать в примечании)')
R(92, 'Добавить разными позициями: коллекторная группа на 3 отв. левое подключение — 1 шт; правое — 1 шт (либо указать в примечании)')
R(99, 'Заменить расценку на 6.2.3.2.5.1.5 Установка конвекторов / на резьбе / от 2001 Вт — по спецификации подключение НР 3/4" резьбовое (поз. 33, 34)')
R(100, 'Добавить разными позициями: TEPLA Classic Mini Plus 3.909 НП К Лев. (TPLCMIPL3909L) — 7 шт; Прав. — 1 шт; исполнение резьбовое НР 3/4" (не сварка)')
R(101, 'Добавить разными позициями: TEPLA Classic Mini Plus 2.703 НП К Лев. — 1 шт; Прав. — 5 шт; исполнение резьбовое НР 3/4" (не сварка)')
R(102, 'Изменить материал: TEPLA Classic Mini Plus 2.237 НП К Лев. — исполнение резьбовое НР 3/4" (в КЦ — сварка)')
R(117, 'Добавить разными позициями: Делсот ЭВУБ-1,5д — 7 шт (А1.2, А1.3, А1.10, А2.1, А3.1, А4.1, А5.1); Делсот ЭВПБ-1,5 — 1 шт (А1.7)')
R(119, 'Добавить примечание: Делсот ЭВУБ-0,5д')
R(120, 'Добавить примечание: Делсот ЭВУБ-1,0д')
R(126, 'Объём работы принять 246 м (трубы по спецификации: DN15 — 190, DN20 — 24, DN25 — 32); шланг нержавеющий Ду15 L=1000 мм — 4 шт добавить отдельной позицией')
R(130, 'Объём принять 190 м; нержавеющий присоединительный шланг Ду15 L=1000 мм — 4 шт добавить отдельной позицией')
R(158, 'Уточнить: по спецификации бобышки под термометр — 8 шт; бобышки под манометры (12 шт) в спецификации теплоснабжения отсутствуют')
R(161, 'Уточнить: трубка демпферная в спецификации не предусмотрена (12 шт)')
R(163, 'Добавить разными позициями: смесительный узел Ноиззлесс УС-(Б)-1-1.0 24В (0-10В) — 1 шт (П1.1); УС-(Б)-1-0.6 24В (0-10В) — 1 шт (П1.2)')
R(('bitem', P(28, 143)), 'Добавить: теплоогнезащитное покрытие Огневент-Базальт-50 (EI150), S=50 мм — 0,502 м² (заделка гильз, поз. 28, 143)')
R(('bitem', P(144)), 'Добавить: пена монтажная огнестойкая Технониколь 240 — 1 шт (поз. 144)')
R(('bitem', P(147)), 'Добавить отдельной позицией: нержавеющий присоединительный шланг Ду15 L=1000 мм — 4 шт (в КЦ учтён в составе трубы DN15, стр. 130)')
R(('bitem', P(172)), 'Добавить: теплоогнезащитное покрытие Огневент-Базальт-50 (EI150) — 0,006 м² (поз. 172)')

# ---------- проверка полноты
mats = [r for r in range(t.data_start, t.max_row + 1) if t.is_material(r) and r not in rep.deleted]
missing = [r for r in mats if r not in rep.MAP]
assert not missing, f'Не сопоставлены строки ТКП: {missing}'
used = {}
for r, d in rep.MAP.items():
    for i in d['ids']:
        used.setdefault(i, []).append(r)
for _, _, ids in rep.BLOCKS:
    for i in ids:
        used.setdefault(i, []).append('block')
for i in rep.INCLUDED:
    used.setdefault(i, []).append('incl')
DERIVED_PARENTS = {p for x in agg if x.get('derived_from') for p in x['derived_from']}
dup = {i: v for i, v in used.items() if len(v) > 1}
assert not dup, f'Задвоение: {dup}'
lost = [x['id'] for x in agg if x['id'] not in used and x['id'] not in DERIVED_PARENTS]
assert not lost, f'Потеряны позиции спецификации: {[(i, A[i]["name"][:50]) for i in lost]}'
print('Строк материалов ТКП:', len(mats), '| позиций спец. (агрегир.):', len([x for x in agg if x["id"] < 1000]), '| производных:', len([x for x in agg if x["id"] >= 1000]), '| удалено строк:', sorted(rep.deleted))

# =====================================================================================
# Сборка листа ТКП
# =====================================================================================
ws = rep.build(name_col_width=78, chk_col_width=50, remark_col_width=72)
C = rep.cols
old2new, plan, row_of = rep.old2new, rep.plan, rep.row_of
NEW = lambda r: old2new[r]
for p in DERIVED_PARENTS:
    kids = [x for x in agg if p in (x.get('derived_from') or [])]
    rows = sorted(set(NEW(r) for r, d in rep.MAP.items() for i in d['ids'] if i in [k['id'] for k in kids]))
    rep.STATUS[p] = 'Разнесено по составу комплекта / пересчёту → поз. КЦ стр. ' + short_list(rows, 8) + ' — соответствует'

# формулы вместо констант для производных позиций
ws[f"{C['qty']}{NEW(115)}"] = '=(1*1+3*1.5+3*2+1*2.5)*4'
ws[f"{C['qty']}{NEW(168)}"] = '=ROUND((5.1+245.4+0.9+50)/1000,4)'
ws[f"{C['qty']}{NEW(168)}"].number_format = '0.0000'

# строки «в спецификации отсутствует» → жёлтые (уточнить)
for r, n in ((89, 32), (161, 12)):
    nr = NEW(r)
    for col in (C['name'], C['unit'], C['qty'], C['chk']):
        ws[f'{col}{nr}'].fill = FILLS['unsure']
    ws[f"{C['name']}{nr}"] = '— в спецификации не предусмотрена —'
    ws[f"{C['chk']}{nr}"] = f'Уточнить: трубка демпферная в спецификации отсутствует (КЦ {n} шт); сопутствующий материал к манометру по норме КЦ'
    rep.RESULTS = [x for x in rep.RESULTS if x[0] != nr]


def style_work(row, fill):
    for col in (C['name'], C['unit'], C['qty'], C['chk']):
        c = ws[f'{col}{row}']; c.border = BORDER; c.font = F_BOLD; c.fill = fill
        c.alignment = AL_CENTER if col in (C['unit'], C['qty']) else AL_WRAP


def qty_cells(w_, kinds=('match',)):
    cells = []
    nw = NEW(w_)
    for idx in range(nw + 1, len(plan) + 1):
        e = plan[idx - 1]
        if e[0] == 'orig':
            rr = e[1]
            if t.code(rr):
                break
            d = rep.MAP.get(rr)
            if d and d['ids'] and d['kind'] in kinds:
                cells.append(f"{C['qty']}{idx}")
        elif e[0] == 'extra':
            d = rep.MAP.get(e[1])
            if d and d['kind'] in kinds:
                cells.append(f"{C['qty']}{idx}")
        elif e[0] in ('bhdr', 'bitem', 'bnone', 'virtual'):
            break
    return cells


# площадь окраски: только чёрные стальные трубы на сварном соединении (Σ L × π·Dнар) + регистры из труб D89 (изготовление на объекте)
DN = {15: 0.0213, 20: 0.0268, 25: 0.0335, 32: 0.0423, 40: 0.048}
AREA = {39: ('=ROUND({r21}*PI()*0.0213+{r22}*PI()*0.0268+{r23}*PI()*0.0423+{r24}*PI()*0.048+{r16}*PI()*0.057+{r115}*PI()*0.089,2)',
             'Σ L×π·Dнар чёрных сварных труб DN15/20/32/40, Ø57 + регистры D89 (56 м)'),
        137: ('=ROUND({r130}*PI()*0.0213+{r131}*PI()*0.0268+{r132}*PI()*0.0335,2)', 'Σ L×π·Dнар чёрных сварных труб DN15/20/25 (без шлангов)')}
TESTS = {165: [15, 25, 126]}
WORK_RES = {}
WORK_EXP = {}
for w_ in t.works():
    if w_ in rep.deleted:
        continue
    nw = NEW(w_); unit = t.unit(w_); kq = round(t.qty(w_), 3)
    label, formula, expl = 'Объём работы по спецификации', None, ''
    if w_ in AREA:
        f, expl = AREA[w_]
        formula = f.format(**{'r' + str(k): f"{C['qty']}{NEW(k)}" for k in (16, 21, 22, 23, 24, 115, 130, 131, 132)})
    elif w_ in TESTS:
        formula = '=ROUND(' + '+'.join(f"{C['qty']}{NEW(k)}" for k in TESTS[w_]) + ',3)'; expl = 'Σ объёмов работ прокладки трубопроводов по спец. (стр. ' + ', '.join(str(NEW(k)) for k in TESTS[w_]) + ')'
    else:
        cells = qty_cells(w_, kinds=('match',))
        if not cells:
            continue
        expl = 'Σ основных материалов по спец., без сопутствующих' if unit in ('шт', 'шт.', 'т') else 'Σ труб / изоляции по спец.'
        formula = '=ROUND(SUM(' + ','.join(cells) + '),4)'
    ws[f"{C['name']}{nw}"] = f'{label} ({expl})'
    ws[f"{C['unit']}{nw}"] = unit
    ws[f"{C['qty']}{nw}"] = formula
    ws[f"{C['qty']}{nw}"].number_format = '#,##0.000' if unit in ('м', 'пог. м', 'м2', 'т') else '#,##0'
    tol = max(0.05, 0.005 * kq) if w_ in AREA else 0.05
    q = f'{C["qty"]}{nw}'
    ws[f"{C['chk']}{nw}"] = f'=IF(ABS({q}-{kq})<={tol},"Соответствует: спец. "&ROUND({q},3)&" / КЦ {kq:g}","РАСХОЖДЕНИЕ: спец. "&ROUND({q},3)&" / КЦ {kq:g}, Δ "&ROUND({q}-{kq},3))'
    # статическая заливка по расчёту в Python (условное форматирование — дублирует)
    if w_ in AREA:
        exp_ = {39: 138.63, 137: 18.10}[w_]
    elif w_ in TESTS:
        exp_ = sum(WORK_EXP[k] for k in TESTS[w_])
    else:
        exp_ = 0.0
        for cref in cells:
            idx = int(re.search(r'\d+', cref).group()); e = plan[idx - 1]
            exp_ += rep.item_unit_val(A[rep.MAP[e[1]]['ids'][0]])[2] if e[0] == 'orig' else rep.item_unit_val(A[e[2]])[2]
    WORK_EXP[w_] = round(exp_, 4)
    style_work(nw, FILLS['ok'] if abs(exp_ - kq) <= tol else FILLS['error'])
    WORK_RES[w_] = (nw, formula)
    print(f'работа {w_} → стр. {nw}: КЦ {kq} / спец. {round(exp_, 4)} {"OK" if abs(exp_ - kq) <= tol else "РАСХОЖДЕНИЕ"}')
for w_, (nw, _) in WORK_RES.items():
    ws.conditional_formatting.add(f"{C['name']}{nw}:{C['chk']}{nw}", FormulaRule(formula=[f'LEFT(${C["chk"]}{nw},4)="РАСХ"'], fill=FILLS['error']))
# раздел «Испытание и наладка» и «Прочие работы»: строки работ без материалов уже обработаны (TESTS);

# подпись блока источника в AQ: «системы» → «раздел спец.»
from openpyxl.cell.rich_text import CellRichText, TextBlock
for rr in range(t.data_start, ws.max_row + 1):
    c = ws[f"{C['name']}{rr}"]
    if isinstance(c.value, str):
        c.value = c.value.replace('[системы: ', '[раздел спец.: ')
    elif isinstance(c.value, CellRichText):
        parts = []
        for pt in c.value:
            if isinstance(pt, TextBlock):
                parts.append(TextBlock(pt.font, pt.text.replace('[системы: ', '[раздел спец.: ')))
            else:
                parts.append(pt.replace('[системы: ', '[раздел спец.: '))
        c.value = CellRichText(parts)
# сокращение текстов проверки материалов
for rr in range(t.data_start, ws.max_row + 1):
    c = ws[f"{C['chk']}{rr}"]
    if isinstance(c.value, str) and not c.value.startswith('='):
        v = re.sub(r'Количество соответствует: Σ по спец\. ([\d\s,]+?) = КЦ [\d\s,]+ \((\d+) поз\. спец\.\)', r'Кол-во \1 ✓ (\2 поз.)', c.value)
        v = v.replace('Соответствует. ОШИБКА номенклатуры: ', 'ОШИБКА номенклатуры: ').replace('Соответствует. ', '✓ ')
        v = re.sub(r'Кол-во (\d+),00 ✓', r'Кол-во \1 ✓', v)
        v = re.sub(r'\s{2,}', ' ', v)
        c.value = v

# форматы количеств по единицам измерения (шт — целые, м/кг — 2 знака, м² — 3, т — 4) и высоты строк под длинные тексты
import math as _m
for rr in range(t.data_start, ws.max_row + 1):
    u = ws[f"{C['unit']}{rr}"].value; cq = ws[f"{C['qty']}{rr}"]
    if u in ('шт', 'шт.'):
        cq.number_format = '#,##0'
    elif u in ('м2', 'м²'):
        cq.number_format = '#,##0.000'
    elif u == 'т':
        cq.number_format = '0.0000'
    elif u:
        cq.number_format = '#,##0.00'
    texts = [(ws[f"{C['name']}{rr}"].value, 78, 1.05), (ws[f"{C['chk']}{rr}"].value, 50, 1.05), (ws[f"{C['rem']}{rr}"].value, 72, 1.3), (ws.cell(rr, 3).value, 55, 1.0), (ws.cell(rr, 5).value, 38, 1.0)]
    lines = 1
    for v, w, k in texts:
        if v is None: continue
        txt = str(v) if not hasattr(v, '__iter__') or isinstance(v, str) else ''.join(getattr(pt, 'text', pt) for pt in v)
        if txt.startswith('='): continue
        lines = max(lines, sum(max(1, _m.ceil(len(part) * k / w)) for part in txt.split('\n')))
    need = min(15.5 * lines + 2, 220)
    cur = ws.row_dimensions[rr].height
    if cur is None or cur < need:
        ws.row_dimensions[rr].height = need

# =====================================================================================
# Лист «Окраска и объёмы работ»
# =====================================================================================
ox = t.wb.create_sheet('Окраска и объёмы работ')
ox['A1'] = 'Антикоррозийная окраска трубопроводов: площадь = Σ L × π · Dнар только по чёрным стальным трубам на сварном соединении (правило 12) + регистры из труб D89 (изготовление на объекте)'
ox['A1'].font = Font(name='Times New Roman', size=14, bold=True)
ox['A2'] = ('Наружные диаметры труб ГОСТ 3262-75: DN15 — 21,3; DN20 — 26,8; DN25 — 33,5; DN32 — 42,3; DN40 — 48,0 мм; электросварная Ø57; регистры D89. '
            'Гильзы, арматура, трубы PE-Xa, нержавеющие шланги в окраску не включаются. Расход краски/грунтовки — по норме КЦ (не проверяется).')
ox['A2'].font = F_NOTE; ox['A2'].alignment = Alignment(wrap_text=True, vertical='top'); ox.merge_cells('A2:H2'); ox.row_dimensions[2].height = 45
HEAD = ['№', 'Раздел ТКП', 'Позиция спецификации', 'Поз. спец.', 'Dнар, м', 'L по спец., м', 'Площадь, м²', 'Примечание']
for col, w in zip('ABCDEFGH', [5, 30, 70, 14, 10, 14, 18, 50]):
    ox.column_dimensions[col].width = w
r = 4; n = 0
PAINT = {39: ('Отопление (паркинг + НПКИ)', [(P(18, 124), 0.0213, ''), (P(19, 125), 0.0268, ''), (P(126), 0.0423, ''), (P(127), 0.048, ''), (P(128), 0.057, ''),
                                               (1000, 0.089, 'регистры из труб D89х2,8 — изготовление на объекте, окраска')]),
         137: ('Теплоснабжение приточных установок', [(P(161), 0.0213, 'без нержавеющих шлангов (4 шт)'), (P(162), 0.0268, ''), (P(163), 0.0335, '')])}
AREA_CELLS = {}
for w_, (sect, lst) in PAINT.items():
    c = ox.cell(r, 1, f'Работа: {t.name(w_)} — {sect} (ТКП стр. {NEW(w_)}, объём КЦ {fmt(t.qty(w_))} м²)'); c.font = Font(name='Times New Roman', size=13, bold=True)
    ox.merge_cells(start_row=r, start_column=1, end_row=r, end_column=8)
    for j in range(1, 9):
        ox.cell(r, j).fill = FILLS['block']; ox.cell(r, j).border = BORDER
    r += 1
    for j, h in enumerate(HEAD, start=1):
        c = ox.cell(r, j, h); c.font = F_BOLD; c.fill = FILLS['hdr']; c.border = BORDER; c.alignment = AL_CENTER
    r += 1; first = r
    for i, d, note in lst:
        n += 1; x = A[i]
        vals = [n, sect, x['name'] if i < 1000 else 'Регистры гладкотрубные D89х2,8 (поз. 7) — 56 м', ', '.join(map(str, x['posnos'])), d, x['qty'], f'=ROUND(F{r}*PI()*E{r},3)', note]
        for j, v in enumerate(vals, start=1):
            c = ox.cell(r, j, v); c.font = F_DATA; c.border = BORDER; c.alignment = AL_WRAP if j in (3, 8) else AL_CENTER
        ox.cell(r, 7).number_format = '#,##0.000'; ox.cell(r, 5).number_format = '0.0000'
        r += 1
    last = r - 1
    def line(label, formula, bold=True, fill=None, fmt_='#,##0.00', note=''):
        global r
        ox.cell(r, 3, label).font = F_BOLD if bold else F_DATA
        c = ox.cell(r, 7, formula); c.font = F_BOLD if bold else F_DATA; c.number_format = fmt_; c.alignment = AL_CENTER
        ox.cell(r, 8, note).font = F_NOTE
        for j in range(1, 9):
            ox.cell(r, j).border = BORDER
            if fill: ox.cell(r, j).fill = fill
        cell = f'G{r}'; r += 1; return cell
    c_tot = line('ПЛОЩАДЬ ОКРАСКИ по спецификации, м²', f'=ROUND(SUM(G{first}:G{last}),2)', fill=FILLS['hdr'])
    c_kc = line('Объём работы в ТКП, м²', t.qty(w_), bold=False)
    c_d = line('Δ (спец. − ТКП), м²', f'=ROUND({c_tot}-{c_kc},2)', bold=False)
    line('Вывод', f'=IF(ABS({c_d})<={max(0.05, 0.005 * t.qty(w_)):.3f},"Соответствует","РАСХОЖДЕНИЕ: принять "&{c_tot}&" м²")', fmt_='@', fill=FILLS['unsure'])
    AREA_CELLS[w_] = c_tot
    r += 2
# объёмы работ
c = ox.cell(r, 1, 'Объёмы работ ТКП и по спецификации (ссылки на лист «ТКП», столбец «Кол-во по спец.»)'); c.font = Font(name='Times New Roman', size=13, bold=True)
ox.merge_cells(start_row=r, start_column=1, end_row=r, end_column=8)
for j in range(1, 9):
    ox.cell(r, j).fill = FILLS['block']; ox.cell(r, j).border = BORDER
r += 1
for j, h in enumerate(['№', 'ТКП стр.', 'Работа', 'Ед.', 'Объём КЦ', 'Объём по спец.', 'Δ', 'Вывод'], start=1):
    c = ox.cell(r, j, h); c.font = F_BOLD; c.fill = FILLS['hdr']; c.border = BORDER; c.alignment = AL_CENTER
r += 1; n = 0
for w_, (nw, _) in WORK_RES.items():
    n += 1
    vals = [n, nw, f'{t.pos(w_)} {t.name(w_)}', t.unit(w_), t.qty(w_), f"='ТКП'!{C['qty']}{nw}", f'=ROUND(F{r}-E{r},3)', f'=IF(ABS(G{r})<={max(0.05, 0.005 * t.qty(w_)) if w_ in AREA else 0.05},"Соответствует","РАСХОЖДЕНИЕ")']
    for j, v in enumerate(vals, start=1):
        c = ox.cell(r, j, v); c.font = F_DATA; c.border = BORDER; c.alignment = AL_WRAP if j == 3 else AL_CENTER
        if j in (5, 6, 7): c.number_format = '#,##0.000'
    ox.conditional_formatting.add(f'H{r}', FormulaRule(formula=[f'LEFT(H{r},4)="РАСХ"'], fill=FILLS['error']))
    ox.conditional_formatting.add(f'H{r}', FormulaRule(formula=[f'LEFT(H{r},4)="Соот"'], fill=FILLS['ok']))
    r += 1
ox.freeze_panes = 'A4'

# =====================================================================================
# Лист «Отопительные приборы»
# =====================================================================================
op = t.wb.create_sheet('Отопительные приборы')
op['A1'] = 'Отопительные приборы по спецификации ↔ ТКП: марка, Qном, количество, масса, тип подключения, категория расценки КЦ'
op['A1'].font = Font(name='Times New Roman', size=14, bold=True)
HEAD = ['№', 'Поз. спец.', 'Помещения / подраздел', 'Наименование по спецификации', 'Марка по спец.', 'Qном, Вт', 'Кол-во по спец.', 'Масса 1 ед., кг', 'Подключение по спец.',
        'ТКП стр.', 'Материал КЦ', 'Расценка КЦ', 'Диапазон расценки, Вт', 'Кол-во КЦ', 'Qном в диапазоне расценки', 'Примечание подрядчика', 'Результат']
for col, w in zip('ABCDEFGHIJKLMNOPQ', [5, 9, 24, 50, 30, 10, 10, 10, 22, 8, 45, 40, 16, 9, 16, 45, 50]):
    op.column_dimensions[col].width = w
for j, h in enumerate(HEAD, start=1):
    c = op.cell(3, j, h); c.font = F_BOLD; c.fill = FILLS['hdr']; c.border = BORDER; c.alignment = AL_CENTER


def qnom(x):
    for nt in x.get('notes', []) + [x.get('note', '')]:
        m = re.search(r'Qном=(\d+)Вт', nt or '')
        if m: return int(m.group(1))
    return None


def rate_range(name):
    m = re.search(r'от (\d+) до (\d+) Вт', name)
    if m: return int(m.group(1)), int(m.group(2))
    m = re.search(r'от (\d+) Вт', name)
    if m: return int(m.group(1)), 10 ** 6
    return None


DEV = []   # (id, kc_row, work_row, connection по спец., результат)
for i, kr, w_ in ((P(1), 121, 116), (P(2), 117, 116), (P(3), 119, 116), (P(4), 120, 116), (P(5), 117, 116), (P(6), 118, 116)):
    DEV.append((i, kr, w_, 'электрический (сеть 220 В)', ''))
for i in (6, 7, 8, 9):
    DEV.append((i, 115, 114, 'сварное, из труб D89х2,8 (изготовление на объекте)', ''))
for i, kr in ((PT(29, 'BFM-110/9'), 105), (PT(29, 'BFM-190/9'), 108), (PT(29, 'BFM-230/9'), 110), (PT(30, 'BFM-100/15'), 104), (PT(30, 'BFM-140/15'), 107), (PT(30, 'BFM-160/15'), 109),
              (PT(31, 'BFM-120/15'), 111), (PT(31, 'BFM-180/15'), 113), (PT(32, 'BFM-190/25'), 112)):
    w_ = 103 if kr in (104, 105) else 106
    DEV.append((i, kr, w_, 'нижнее, резьбовое', ''))
for i, kr in ((PT(33, '2.237'), 102), (PT(33, '2.703'), 101), (PT(33, '3.909'), 100), (PT(34, '2.703'), 101), (PT(34, '3.909'), 100)):
    DEV.append((i, kr, 99, 'нижнее, НР 3/4" резьбовое', 'ОШИБКА: расценка и материал КЦ «на сварке» — по спец. резьбовое НР 3/4"'))
r = 4; n = 0
for i, kr, w_, conn, res in DEV:
    n += 1; x = A[i]; q = qnom(x); rng = rate_range(t.name(w_))
    if i in (6, 7, 8, 9):
        q = {6: 805, 7: 1207, 8: 1610, 9: 2010}[i]
    nr = NEW(kr)
    res_txt = res or ('Соответствует' if rep.MAP[kr]['st'] == 'ok' else ('Уточнить: ' + rep.MAP[kr]['note'] if rep.MAP[kr]['st'] == 'unsure' else rep.MAP[kr]['note']))
    try:
        mass = float(x['mass'].replace(',', '.')) if x['mass'] else None
    except ValueError:
        mass = None
    vals = [n, ', '.join(map(str, x['posnos'])), '; '.join(x['systems']), x['name'][:160], x['type'], q, x['qty'], mass, conn, nr, t.name(kr), t.name(w_),
            (f'{rng[0]}–{rng[1]}' if rng and rng[1] < 10 ** 6 else (f'от {rng[0]}' if rng else '—')), t.qty(kr),
            (f'=IF(AND(F{r}>={rng[0]},F{r}<={rng[1]}),"да","НЕТ")' if rng and q else '—'), t.comment(kr), res_txt]
    for j, v in enumerate(vals, start=1):
        c = op.cell(r, j, v); c.font = F_DATA; c.border = BORDER; c.alignment = AL_WRAP if j in (3, 4, 5, 9, 11, 12, 16, 17) else AL_CENTER
    fill = FILLS['error'] if res_txt.startswith('ОШИБКА') else (FILLS['unsure'] if res_txt.startswith('Уточнить') else FILLS['ok'])
    op.cell(r, 17).fill = fill
    if rng and q:
        op.conditional_formatting.add(f'O{r}', FormulaRule(formula=[f'O{r}="НЕТ"'], fill=FILLS['error']))
        op.conditional_formatting.add(f'O{r}', FormulaRule(formula=[f'O{r}="да"'], fill=FILLS['ok']))
    r += 1
op.freeze_panes = 'A4'; op.auto_filter.ref = f'A3:Q{r - 1}'

# =====================================================================================
# Сводная по спецификации (ОТ / ТС)
# =====================================================================================
def build_summary_ov1(wb, agg, status, title='Сводная по спецификации'):
    sv = wb.create_sheet(title)
    sv['A1'] = 'Сводная спецификация ДВЛ-БСН-300-Р-ОВ1.СО в разрезе разделов ТКП (отопление / теплоснабжение). Позиции агрегированы по наименованию/марке; строки «состав комплекта / пересчёт» — производные.'
    sv['A1'].font = Font(name='Times New Roman', size=14, bold=True)
    for c, h in zip('ABCDE', ['Раздел ТКП', 'Позиций', 'Разнесено / учтено', 'Не разнесено', 'С ошибкой']):
        sv[f'{c}3'] = h; sv[f'{c}3'].font = F_BOLD; sv[f'{c}3'].fill = FILLS['hdr']; sv[f'{c}3'].border = BORDER; sv[f'{c}3'].alignment = AL_CENTER
    HDR = 8
    heads = ['№', 'Раздел ТКП', 'Подраздел / группа спецификации', 'Поз. спец.', 'Наименование и техническая характеристика', 'Тип, марка', 'Завод-изготовитель', 'Ед. изм.', 'Кол-во', 'Масса 1 ед., кг', 'Масса всего, кг', 'Листы спец.', 'Примечание спец.', 'Статус в ТКП']
    for j, h in enumerate(heads, start=1):
        c = sv.cell(HDR, j, h); c.font = F_BOLD; c.fill = FILLS['hdr']; c.border = BORDER; c.alignment = AL_CENTER
    row, n = HDR + 1, 0
    SS = ['ОТ', 'ТС']
    for ss in SS:
        c = sv.cell(row, 1, SUB_NAME_OV1[ss]); c.font = Font(name='Times New Roman', size=13, bold=True)
        sv.merge_cells(start_row=row, start_column=1, end_row=row, end_column=14)
        for j in range(1, 15):
            sv.cell(row, j).fill = FILLS['block']; sv.cell(row, j).border = BORDER
        row += 1
        for x in sorted([x for x in agg if x['ss'] == ss], key=lambda x: (x['id'] >= 1000, x['posnos'][0], x['id'])):
            n += 1
            st = status.get(x['id'], 'НЕ разнесено')
            try: mass = float(x['mass'].replace(',', '.')) if x['mass'] else None
            except ValueError: mass = None
            vals = [n, SUB_NAME_OV1[ss], '; '.join(x['systems']), ', '.join(map(str, x['posnos'])), x['name'], x['type'], x['supplier'], x['unit'], x['qty'], mass,
                    f'=IF(J{row}="","",ROUND(I{row}*J{row},2))', short_list(x['sheets'], 12), '; '.join(x.get('notes', [])), st]
            for j, v in enumerate(vals, start=1):
                c = sv.cell(row, j, v); c.font = F_DATA; c.border = BORDER
                c.alignment = AL_WRAP if j in (3, 5, 6, 13, 14) else AL_CENTER
                if j in (9, 10, 11): c.number_format = '#,##0.000' if j == 9 else '#,##0.00'
            if 'НЕ разнесено' in st or 'ОШИБКА' in st: sv.cell(row, 14).fill = FILLS['error']
            elif 'уточнения' in st: sv.cell(row, 14).fill = FILLS['unsure']
            elif st.startswith('Разнесено') or st.startswith('Учтено'): sv.cell(row, 14).fill = FILLS['ok']
            row += 1
    LAST = row - 1
    for i, ss in enumerate(SS):
        rr = 4 + i
        sv[f'A{rr}'] = SUB_NAME_OV1[ss]
        sv[f'B{rr}'] = f'=COUNTIFS($B${HDR+1}:$B${LAST},A{rr})'
        sv[f'C{rr}'] = f'=COUNTIFS($B${HDR+1}:$B${LAST},A{rr},$N${HDR+1}:$N${LAST},"Разнесено*")+COUNTIFS($B${HDR+1}:$B${LAST},A{rr},$N${HDR+1}:$N${LAST},"Учтено*")'
        sv[f'D{rr}'] = f'=B{rr}-C{rr}'
        sv[f'E{rr}'] = f'=COUNTIFS($B${HDR+1}:$B${LAST},A{rr},$N${HDR+1}:$N${LAST},"*ОШИБКА*")+COUNTIFS($B${HDR+1}:$B${LAST},A{rr},$N${HDR+1}:$N${LAST},"НЕ разнесено*")'
        for c in 'ABCDE':
            sv[f'{c}{rr}'].font = F_DATA; sv[f'{c}{rr}'].border = BORDER; sv[f'{c}{rr}'].alignment = AL_CENTER
    sv['A6'] = 'Итого'
    for c in 'BCDE': sv[f'{c}6'] = f'=SUM({c}4:{c}5)'
    for c in 'ABCDE': sv[f'{c}6'].font = F_BOLD; sv[f'{c}6'].border = BORDER; sv[f'{c}6'].alignment = AL_CENTER
    for col, w in zip('ABCDEFGHIJKLMN', [36, 28, 34, 16, 70, 30, 18, 8, 12, 10, 12, 12, 24, 50]):
        sv.column_dimensions[col].width = w
    sv.freeze_panes = f'A{HDR+1}'; sv.auto_filter.ref = f'A{HDR}:N{LAST}'
    return sv


build_summary_ov1(t.wb, agg, rep.STATUS)

# =====================================================================================
# Пояснения
# =====================================================================================
notes = [
 ('Проверка ТКП 7869889 (АЛЬФАСТРОЙ ООО) — раздел ОВ1 «Отопление и теплоснабжение», наземный паркинг на 300 м/м, г. Москва, ул. Ижорская, з/у 6/2 — по спецификации ДВЛ-БСН-300-Р-ОВ1.СО', True),
 ('Исходные данные', True),
 ('• ТКП 7869889 (лист «ТКП», 188 строк; в файле только лист «ТКП», листы «Изменения» и «ТКП с формулами» в выгрузке отсутствуют). Структура стандартная: код ИСР в B, примечание подрядчика в E, ед. изм. в F, объём в I; ценовые столбцы J–AP, служебные V–AI скрыты.', False),
 ('• РД: ДВЛ-БСН-300-Р-ОВ1 (33 стр., РНК Девелопмент, 2026): общие данные (стр. 4), характеристика отопительно-вентиляционных систем (стр. 5), планы/разрезы/узлы (стр. 6–20), спецификация оборудования, изделий и материалов ДВЛ-БСН-300-Р-ОВ1.СО — стр. 21–33 (листы 1–13): '
  'разделы «Отопление.Паркинг.» (поз. 1–28), «Отопление. НПКИ» (поз. 29–144), «Теплоснабжение» (поз. 145–172). Листов подбора оборудования нет; технические решения (ТР) не приложены. Файл «…ОВ1 с почты.pdf» по локальной ссылке недоступен — проверка выполнена по приложенному PDF.', False),
 ('• Раздел ТКП «Отопление» ↔ спецификация «Отопление.Паркинг.» + «Отопление. НПКИ»; раздел «Теплоснабжение приточной установки и воздушно-тепловых завес» ↔ «Теплоснабжение»; «Испытание и наладка» и «Прочие работы» — по обоим разделам.', False),
 ('Методика', True),
 ('• Раздел — отопление/теплоснабжение, поэтому применены общие требования ТЗ (структура отчёта, столбцы AQ–AT/AV, цвета) и правила проверки трубопроводных разделов (правила ВК 1–5, 9, 11, 12): нулевые расценки удалены; объём работы — Σ формирующих материалов (трубы, изоляция, арматура, приборы), сопутствующие (крепёж, гильзы, резьбы, фланцы, ниппели/муфты, краска/грунтовка) в объём не входят; '
  'гидроиспытания = Σ объёмов работ прокладки трубопроводов; окраска = Σ L × π·Dнар только чёрных стальных труб на сварном соединении (+ регистры из труб D89, изготавливаемые на объекте); примечание подрядчика — приоритет (замена всей позиции применительно — соответствие; разные типоразмеры/типы в одной позиции — ошибка «Добавить разными позициями», даже если оговорено).', False),
 ('• Спецификация извлечена по геометрии таблиц (pdfplumber), структурирована: раздел → подраздел (Паркинг / НПКИ / Теплоснабжение) → группа (Арматура, Материалы, Изоляция, Гильзы, УУТ1–3, коллекторная группа и т.д.) → позиция; подстроки позиций (марки конвекторов, длины регистров, Ду опор) приняты отдельными позициями. 180 строк → 114 агрегированных позиций (по наименованию/марке/ед. изм. внутри раздела ТКП) + 4 производные (регистры шт→м; состав защитного комплекта; Σ металла крепления кг→т).', False),
 ('• Каждая строка материала ТКП сопоставлена явно (столбцы AQ–AT): позиции спецификации (несколько — дополнительными серыми строками ниже), ед. изм., количество, результат. Объём работы — формулой по столбцу «Кол-во по спец.»; окраска — формулой Σ L×π·D (лист «Окраска и объёмы работ»); гидроиспытания — Σ объёмов работ прокладки.', False),
 ('• Нулевая расценка «Прокладка трубопроводов из стальных труб на сварном соединении / от 131 мм до 200 мм» (объём 0, без материалов) удалена; итоги ТКП сохранены (проверено построчно).', False),
 ('Допущения', True),
 ('• Регистры (поз. 7, шт) пересчитаны в метры трубы: (1×1,0 + 3×1,5 + 3×2,0 + 1×2,5) × 4 ряда = 56 м — совпадает с примечанием подрядчика. Площадь окраски регистров (56 м × π × 0,089 = 15,66 м²) включена в объём окраски — так же, как в ТКП.', False),
 ('• «Защитный комплект для подключения отопительного прибора» (поз. 37, 90 шт) разложен на гильзу защитную (90) и фиксатор колена (90) — по строкам КЦ 29 и 31.', False),
 ('• «Металл сортовой для крепления» (5,1 + 245,4 + 0,9 кг) и «Крепёжный материал для узла смешения» (50 кг) отнесены к расценке «Монтаж опорных конструкций» (швеллер 12П, 0,301 т) — так, как это сделано в ТКП.', False),
 ('• «Лента перфорированная» (254 м) — учтена в составе сопутствующего материала КЦ «Крепежные элементы для трубопроводов»; краска МА-15 и грунтовка ГФ-031 — в составе окраски (расход по норме КЦ, тип краски в КЦ — эмаль ПФ-115 — уточнить).', False),
 ('• Наружные диаметры для окраски: DN15 — 21,3; DN20 — 26,8; DN25 — 33,5; DN32 — 42,3; DN40 — 48,0; Ø57; D89 мм. Допуск по окраске — 0,5 % объёма (но не менее 0,05 м²); по остальным объёмам — 0,05.', False),
 ('• Гильзы (трубы Ø57/76/89), неподвижные опоры — проверены по количеству, в объём работы прокладки не включены (по описанию расценки КЦ гильзы и крепления входят в состав работы).', False),
 ('• Трубка демпферная для манометра (32 + 12 шт) в спецификации не предусмотрена — отмечена жёлтым (уточнить), не как ошибка: сопутствующий элемент к манометру по норме КЦ.', False),
 ('Легенда', True),
 ('• Зелёный — соответствует (в т.ч. «по примечанию»); жёлтый — уточнить; красный — ошибка (номенклатура, объём, отсутствие позиции). Красным шрифтом в AQ выделен несоответствующий элемент спецификации. Столбец AV «Замечания» — директивы подрядчику. Ценовые столбцы J–AP свёрнуты (кнопка «+»), служебные V–AI скрыты.', False),
 ('• Внизу раздела «Отопление» (после «Установка термоголовок») и раздела «Теплоснабжение» (после «Установка смесительного узла») — блоки позиций спецификации, не разнесённых в ТКП.', False),
 ('• Листы: «Окраска и объёмы работ» (расчёт площади окраски и сводка объёмов работ КЦ ↔ спец.), «Отопительные приборы» (марки, Qном, категории расценок, тип подключения), «Сводная по спецификации» (статус каждой позиции).', False),
 ('Ключевые выводы', True),
 ('1. Объёмы труб (сталь 1384 м, PE-Xa 1241 м), изоляции (1368 + 1241 + 246 м), опор (26 + 14), арматуры (400 + 3 + 9 + 20 + 47), КИП, коллекторов (13 + 3), теплосчётчиков (19), конвекторов SPL (6 + 20), регистров (56 м), электроконвекторов (21), окраски (138,63 и 18,10 м²), опорных конструкций (0,301 т) и гидроиспытаний (2871 м) сходятся со спецификацией.', False),
 ('2. Расхождения объёма: трубопровод DN15 теплоснабжения — 194 м в КЦ против 190 м по спец. (4 шт нержавеющих шлангов учтены как труба; объём работы 250 → 246 м); бобышки теплоснабжения — 20 в КЦ против 8 по спец. (бобышек под манометры в спецификации нет — уточнить).', False),
 ('3. Ошибки номенклатуры (разные типы/типоразмеры в одной позиции): муфта-американка 1/2" ×87 (сгон ВР-ВР 8 + американка 36 + соединитель евроконус 43); удлинитель DN15 ×9 (муфта ВР-НР 8 + муфта ВР-ВР 1); электроконвектор EN-1500 ×8 (ЭВУБ-1,5д 7 + ЭВПБ-1,5 1); смесительный узел ×2 (УС-(Б)-1-1.0 и УС-(Б)-1-0.6); конвекторы TEPLA 3.909 ×8 и 2.703 ×6 (левое + правое исполнение); коллекторные группы (левое + правое без примечания).', False),
 ('4. Конвекторы TEPLA Classic Mini Plus (19 шт): в ТКП расценка и материалы «на сварке», по спецификации (поз. 33, 34) подключение НР 3/4" резьбовое — заменить расценку на «на резьбе / от 2001 Вт» и исполнение материалов.', False),
 ('5. Не разнесены: теплоогнезащитное покрытие Огневент-Базальт-50 (EI150) — 0,502 + 0,006 м²; пена монтажная огнестойкая Технониколь 240 — 1 шт; нержавеющий присоединительный шланг Ду15 L=1000 мм — 4 шт (отдельной позицией).', False),
 ('6. Уточнить: исполнение «д» электроконвекторов ЭВУБ-0,5д/1,0д (в КЦ без «д»); тип краски (МА-15 по спец. / ПФ-115 в КЦ); трубки демпферные (44 шт) — в спецификации отсутствуют.', False),
]
px = build_notes_sheet(t.wb, notes)
t.wb.move_sheet(px, offset=t.wb.sheetnames.index('ТКП') - t.wb.sheetnames.index('Пояснения'))
rep.save(OUT)
print('saved', OUT, t.wb.sheetnames)
res = finalize(OUT, orig_path=TKP_XLSX, old2new=rep.old2new, deleted=rep.deleted)
print(json.dumps({k: v for k, v in res.items() if k != 'verify'}, ensure_ascii=False)[:600])
print('verify:', res['verify']['checked'], 'n_bad', res['verify']['n_bad'], res['verify']['bad'][:5])
json.dump({'old2new': rep.old2new, 'deleted': sorted(rep.deleted), 'cols': C}, open(f'{WORK}/build_meta.json', 'w'))
