# -*- coding: utf-8 -*-
"""Пример: ТКП 7883279, Гольяново зона 3.1, корпуса 1–4, ОВ2 (ПИК-формат спецификации ООО «Перспектива», ТР2). Многокорпусный сценарий: 4 блока ТКП ↔ спецификация по корпусам; вентмодули квартир; производные позиции (UTR, УС-1вп, фильтр+бокс, краска кг); фасонные по классам толщины. Требует spec_local_perspektiva.py и automatch_marks.py (в базе знаний)."""
# -*- coding: utf-8 -*-
"""
Проверка ТКП 7883279 (Гольяново, мкр. 1-2, зона 3.1, корпуса 1–4, ОВ2) по спецификации 111-1123-ОК-1/Н-3.1-1-1..4-ОВ2.СО с учётом ТР2.
Объектный сценарий: 4 блока ТКП (корпуса/секции 1–4), в каждом — общеобменная и противодымная вентиляция.
"""
import json, re, sys, math, copy
sys.path.insert(0, '/home/claude/work')
from tkp_toolkit import *
from automatch import propose, comment_parts, norm, sizes_in, by_mark
from openpyxl.styles import Font, Alignment, PatternFill

TKP_XLSX = '/home/claude/in/tkp.xlsx'
OUT = '/mnt/user-data/outputs/Проверка_ТКП_7883279_Гольяново_зона3.1_К1-4_ОВ2_по_спецификации_с_ТР2.xlsx'

AGG = json.load(open('/home/claude/work/spec_agg.json'))
ITEMS = json.load(open('/home/claude/work/spec_items.json'))
SEL = json.load(open('/home/claude/work/selection.json'))
A = {x['id']: x for x in AGG}
BLOCKS = {1: (36, 268), 2: (269, 494), 3: (495, 724), 4: (725, 955)}
UC_SHARE = {1: 2, 2: 4, 3: 6, 4: 2}          # УС-1вп по корпусам (по числу систем ПУ: К1 — ПУ1.1; К2 — ПУ1.2, ПУ2.2; К3 — ПУ1.3, ПУ3.3, ПУ2.3; К4 — ПУ1.4)

t = Tkp(TKP_XLSX)
rep = Report(t, AGG, ITEMS)
rep.delete_rows(t.zero_rate_rows())
NEXT_ID = [max(A) + 1]
covered = {}          # id -> как учтена (для контроля полноты)
EQ_ROWS = []          # данные для листа «Анализ вент. оборудования»
POSTFIX = {}          # orig row -> текст AQ (замена описания группы воздуховодов)
WORK_POST = {}        # orig work row -> (text, unit, formula/value, chk, status) — ручное заполнение строки работы
FIT_INFO = {}         # (k, ss) -> данные по фасонным для листа «Воздуховоды м2»
DUCT_KC = {}          # (k, ss) -> {'rect': {(t,cat,std): qty}, 'round': {(t,conn): qty}}
NOTES_EXTRA = []      # пояснения


def pct1(v):
    return (f'{v * 100:.1f}'.rstrip('0').rstrip('.') + ' %').replace('.', ',')


def cover(i, how):
    covered.setdefault(i, []).append(how)


def derive(base_ids, name, qty, unit=None, note='', systems=None, mass=None, type_=None, korpus=None, ss=None):
    b = A[base_ids[0]]
    x = {k: v for k, v in b.items() if k != 'duct'}
    x.update(id=NEXT_ID[0], name=name, qty=qty, derived_from=list(base_ids), unit=unit or b['unit'], type=b['type'] if type_ is None else type_,
             systems=systems or sorted(set(s for i in base_ids for s in A[i]['systems'])), mass=b['mass'] if mass is None else mass,
             sheets=sorted(set(s for i in base_ids for s in A[i]['sheets']), key=str), note=note, korpus=b['korpus'] if korpus is None else korpus, ss=ss or b['ss'])
    NEXT_ID[0] += 1
    A[x['id']] = x; AGG.append(x); rep.A[x['id']] = x
    return x['id']


def split_status(base_ids, txt):
    for i in base_ids:
        rep.INCLUDED[i] = txt; cover(i, 'derived')


def mass_limit(work_name):
    m = re.search(r'до (\d+) кг', work_name)
    return int(m.group(1)) if m else None


def sel_mass(mark, systems=()):
    """Масса по листу подбора: Korf — по системе; остальные — по марке."""
    nm = norm(mark).replace(',', '.')
    for s in SEL:
        if s['vendor'] == 'Korf':
            continue
        if norm(s['model']).replace(',', '.') == nm or (len(nm) > 6 and nm in norm(s['model']).replace(',', '.')):
            return s['mass'], s['page'], s
    return None, None, None


def korf_sheet(systems):
    for s in SEL:
        if s['vendor'] == 'Korf' and any(sy in s['system'].replace(',', '.').split('/') for sy in systems):
            return s
    return None


# =====================================================================================
# 1. Воздуховоды: слоты по правилам (толщина × категория × кратность; круглые — толщина × соединение)
# =====================================================================================
def round_slots_t(agg_k, ss, flange_over=315):
    res = {}
    for x in agg_k:
        d = x.get('duct')
        if x['ss'] != ss or not d or d['kind'] != 'кругл':
            continue
        conn = 'фланец' if int(d['size']) > flange_over else 'ниппель'
        res.setdefault((d['t'], conn), []).append((x['id'], 1.0))
    return res


def parse_kc_duct(name):
    if not name.startswith('Воздуховод') or 'гибк' in name:
        return None
    m = re.search(r'/\s*([\d,]+)\s*мм', name)
    tt = m.group(1) if m else None
    if 'круглого' in name:
        return ('кругл', tt, 'фланец' if 'фланец' in name else 'ниппель')
    std = 'nonstd' if 'не равно' in name else 'std'
    if '(БИМ)' in name:
        return ('прям', tt, '*', std)
    cat = 'A' if 'до 0,78' in name else ('B' if 'от 0,78' in name else 'C')
    return ('прям', tt, cat, std)


def parse_kc_fit(name):
    if not name.startswith('Фасонные'):
        return None
    m = re.search(r'/\s*([\d,]+)\s*мм', name)
    tt = m.group(1)
    shape = 'прям' if 'прямоугольного' in name else 'кругл'
    part = 'small' if re.search(r'до 0,(3|18)', name) else 'big'
    return (shape, tt, part)


TCLASS = lambda tt: '1' if tt in ('1', '1,0') else ('0,8' if tt in ('0,7', '0,8') else tt)


def thick_work(tt):
    """К какой расценке по толщине относится слот."""
    v = float(tt.replace(',', '.'))
    return 'до 0,7' if v <= 0.7 else ('0,71' if v <= 0.9 else '0,91')


# =====================================================================================
# 2. Обход блоков ТКП
# =====================================================================================
blocks_rows = {}   # (k, ss) -> list rows
INCLUDED_UNIT = ('Секция бактерицидная', 'Крыша', 'Межсекционная стяжка', 'Секция смешения', 'Секция промежуточная', 'Корпус фильтра', 'Пустая секция', 'Привод PDF')
HARDWARE = ('Траверса', 'Шпилька', 'Болт', 'Гайка', 'Шайба', 'Анкер', 'Саморез', 'Дюбель', 'Уголок креп', 'Хомут')
CONSUMABLE = ('Шнур базальтовый', 'Скотч алюминиевый', 'Пена противопожарная', 'Проволока вязальная')
FIT_PARTS = ('Оцинкованная сталь для соединительных', 'Ниппель вентиляционный', 'Пластина П3', 'Отвод сегментный', 'Тройник 500', 'Заглушка воздуховода')
ROUND_PARTS = ('Ниппель вентиляционный', 'Отвод сегментный')

KREP = 'Сопутствующий нормативный материал КЦ (объём = площадь воздуховода); в объём работы не входит.'
remark_rows = {}
FIT_REM = {}

for k, (ra, rb) in BLOCKS.items():
    agg_k = [x for x in AGG if x['korpus'] == k]
    ss = None; work = None; work_row = None
    rows_by_ss = {'ОВ': [], 'ПД': []}
    works_by_ss = {'ОВ': {}, 'ПД': {}}
    for r in range(ra, rb + 1):
        if t.is_section(r) and t.name(r) in ('Общеобменная вентиляция', 'Противодымная вентиляция'):
            ss = 'ОВ' if 'Общеоб' in t.name(r) else 'ПД'
        if ss is None:
            continue
        if t.is_work(r):
            work = t.name(r); work_row = r; works_by_ss[ss][r] = work
        if t.is_material(r):
            rows_by_ss[ss].append((r, work_row))
    for ss in ('ОВ', 'ПД'):
        rows = rows_by_ss[ss]
        if not rows:
            continue
        blocks_rows[(k, ss)] = rows
        # ---------------- воздуховоды
        rslots = rect_slots(agg_k, ss)
        roslots = round_slots_t(agg_k, ss)
        kc_rect, kc_round = {}, {}
        duct_rows = [(r, w, parse_kc_duct(t.name(r))) for r, w in rows if parse_kc_duct(t.name(r))]
        last_duct_row_by_work = {}
        for r, w, p in duct_rows:
            last_duct_row_by_work[w] = r
        used_slots = set()
        for r, w, p in duct_rows:
            if p[0] == 'прям':
                _, tt, cat, std = p
                if cat == '*':
                    # (БИМ)-позиция: для толщин ≤ 0,7 — вся толщина одной группой; для 0,9 — некратные всех категорий
                    if float(tt.replace(',', '.')) <= 0.7:
                        keys = [key for key in rslots if key[0] == tt]
                        its = []
                        for key in keys:
                            its += rslots[key]
                        # объединяем доли одного id (std+nonstd → 1,0)
                        agg_sh = {}
                        for i, sh in its:
                            agg_sh[i] = agg_sh.get(i, 0) + sh
                        its = [(i, round(sh, 6)) for i, sh in agg_sh.items()]
                        slot = (tt, 'B', 'std'); used_slots |= set(keys)
                        POSTFIX[r] = f'ИТОГО по группе воздуховодов: прямоугольные {tt} мм (все сечения; в справочнике КЦ нет номенклатуры класса B для толщины {tt} мм — принята позиция (БИМ) без разбивки по категориям/кратности)'
                    else:
                        keys = [key for key in rslots if key[0] == tt and key[2] == 'nonstd']
                        its = []
                        for key in keys:
                            its += rslots[key]
                        slot = (tt, 'B', 'nonstd'); used_slots |= set(keys)
                        POSTFIX[r] = f'ИТОГО по группе воздуховодов: прямоугольные {tt} мм / не равно 1250мм, 1500мм (все категории) — позиция (БИМ) принята как «некратные {tt} мм»'
                        rep.slot_notes[r] = f'По правилу позиции площадью < 10 м² на кратные/некратные не делятся; для толщины {tt} мм некратные в КЦ оформлять как «0,8мм / не равно 1250мм, 1500мм» с примечанием о толщине {tt} мм'
                else:
                    slot = (tt, cat, std); its = rslots.get(slot, []); used_slots.add(slot)
                    if not its and cat == 'A':
                        mins = [x for x in agg_k if x['ss'] == ss and x.get('duct') and x['duct']['kind'] == 'прям' and x['duct']['t'] == tt]
                        if mins:
                            mn = min(mins, key=lambda x: x['duct']['per'])
                            rep.slot_notes[r] = (f'По правилу (площадь 1 изделия при L = 1,25 м) в категорию «до 0,78 м²» не попадает ни одно сечение {tt} мм: наименьшее {mn["duct"]["size"].replace("x", "×")} — '
                                                 f'{mn["duct"]["per"]:.2f} × 1,25 = {mn["duct"]["per"] * 1.25:.2f} м² > 0,78 → категория «от 0,78 до 4,25 м²»'.replace('.', ','))
                rep.duct_group(r, 'прям', slot, its)
                kc_rect[(tt, slot[1], slot[2])] = kc_rect.get((tt, slot[1], slot[2]), 0) + t.qty(r)
                for i, sh in its:
                    cover(i, f'duct row {r}')
            else:
                _, tt, conn = p
                slot = (tt, conn); its = roslots.get(slot, []); used_slots.add(slot)
                rep.duct_group(r, 'кругл', conn, its)
                kc_round[slot] = t.qty(r)
                if tt != '0,8':
                    POSTFIX[r] = f'ИТОГО по группе воздуховодов: круглые {tt} мм / {conn} (по правилу: d ≤ 315 — ниппель, d > 315 — фланец)'
                for i, sh in its:
                    cover(i, f'duct row {r}')
        # недостающие слоты → виртуальные строки
        virtual_list = []
        for slot, its in sorted(rslots.items()):
            if slot in used_slots or not its:
                continue
            tt = slot[0]
            if float(tt.replace(',', '.')) <= 0.7 and any(key[0] == tt for key in used_slots):
                continue
            wk = thick_work(tt)
            after = None
            for w, lr in last_duct_row_by_work.items():
                if 'прямоугольного' in t.name(w) and wk in t.name(w):
                    after = max(after or 0, lr)
            if after is None:   # расценки по этой толщине нет — ставим после последнего прямоугольного
                after = max(lr for w, lr in last_duct_row_by_work.items() if 'прямоугольного' in t.name(w))
            title = slot_material_name('прям', slot)
            if tt == '0,9' and slot[2] == 'nonstd':
                title += ' (в справочнике КЦ нет — применить «0,8мм / не равно …» с примечанием «толщина 0,9 мм»)'
            rep.virtual_group(after, 'прям', slot, its, title)
            virtual_list.append((slot, its))
            for i, sh in its:
                cover(i, f'virtual {slot}')
        for slot, its in sorted(roslots.items()):
            if slot in used_slots or not its:
                continue
            tt, conn = slot
            wk = thick_work(tt)
            after = None
            for w, lr in last_duct_row_by_work.items():
                if 'круглого' in t.name(w) and wk in t.name(w) and 'соединительные' not in t.name(w):
                    after = max(after or 0, lr)
            if after is None:
                after = max(lr for w, lr in last_duct_row_by_work.items() if 'круглого' in t.name(w))
            rep.virtual_group(after, 'кругл', conn, its, slot_material_name('кругл', conn, t=tt))
            virtual_list.append((slot, its))
            for i, sh in its:
                cover(i, f'virtual {slot}')
        DUCT_KC[(k, ss)] = {'rect': kc_rect, 'round': kc_round, 'virtual': virtual_list}
        # ---------------- фасонные части
        fit_ids = [x['id'] for x in agg_k if x['ss'] == ss and x['name'].startswith(FIT_PARTS)]
        by_class = {}
        for i in fit_ids:
            x = A[i]
            m = re.search(r'толщиной ([\d,]+)мм', x['name'])
            tc = TCLASS(m.group(1)) if m else '0,8'
            by_class.setdefault(tc, []).append(i)
        kc_fit_rows = [(r, w, parse_kc_fit(t.name(r))) for r, w in rows if parse_kc_fit(t.name(r))]
        fit_info = {}
        for tc, ids in by_class.items():
            spec_total = round(sum(A[i]['qty'] for i in ids), 3)
            kc_rows_tc = [(r, w, p) for r, w, p in kc_fit_rows if TCLASS(p[1]) == tc]
            kc_total = round(sum(t.qty(r) for r, w, p in kc_rows_tc), 3)
            kc_shape = {}
            for r, w, p in kc_rows_tc:
                kc_shape[p[0]] = kc_shape.get(p[0], 0) + t.qty(r)
            # распределение прям./кругл.: спецификация не разделяет → при совпадении итога по классу принимаем долю КЦ, иначе пропорционально площади воздуховодов
            total_ok = abs(spec_total - kc_total) <= TOL
            if total_ok and kc_total > 0:
                share_rect = kc_shape.get('прям', 0) / kc_total
                method = 'распределение прям./кругл. принято по КЦ (спецификация не разделяет фасонные по форме сечения)'
            else:
                ar = sum(duct_area(x) for x in agg_k if x['ss'] == ss and x.get('duct') and x['duct']['kind'] == 'прям' and TCLASS(x['duct']['t']) == tc)
                ac = sum(duct_area(x) for x in agg_k if x['ss'] == ss and x.get('duct') and x['duct']['kind'] == 'кругл' and TCLASS(x['duct']['t']) == tc)
                share_rect = ar / (ar + ac) if (ar + ac) else 1.0
                method = f'распределение прям./кругл. пропорционально площади воздуховодов толщины {tc} мм ({ar:.1f}/{ac:.1f} м²)'
            fit_info[tc] = dict(ids=ids, spec_total=spec_total, kc_total=kc_total, share_rect=share_rect, method=method, rows={})
            small_sh = FITTING_SMALL_SHARE[ss]
            for shape in ('прям', 'кругл'):
                part_total = round(spec_total * (share_rect if shape == 'прям' else 1 - share_rect), 3)
                if part_total <= 0.0005:
                    continue
                lim = '0,3' if shape == 'прям' else '0,18'
                d_small = derive(ids, f'Фасонные части воздуховодов {"прямоугольного" if shape == "прям" else "круглого"} сечения {tc} мм — доля изделий «до {lim} м²» ({pct1(small_sh)} от {fmt(part_total, 3)} м²; расчётная позиция)',
                                 round(part_total * small_sh, 3), unit='м2', type_='')
                d_big = derive(ids, f'Фасонные части воздуховодов {"прямоугольного" if shape == "прям" else "круглого"} сечения {tc} мм — доля изделий «от {lim} м²» ({pct1(1 - small_sh)} от {fmt(part_total, 3)} м²; расчётная позиция)',
                               round(part_total - round(part_total * small_sh, 3), 3), unit='м2', type_='')
                fit_info[tc]['rows'][shape] = dict(total=part_total, small=d_small, big=d_big)
                rws = [(r, w, p) for r, w, p in kc_rows_tc if p[0] == shape]
                if not rws:
                    continue
                # строка «до» (или единственная) получает обе производные позиции
                main = next((rw for rw in rws if rw[2][2] == 'small'), rws[0])
                others = [rw for rw in rws if rw is not main]
                r, w, p = main
                note = (f'По правилу п. 10 ТЗ доля «до {lim} м²» = {pct1(small_sh)}: требуется {fmt(round(part_total * small_sh, 3), 3)} м² «до {lim} м²» и {fmt(round(part_total - round(part_total * small_sh, 3), 3), 3)} м² «от {lim} м²» '
                        f'(позиция «от {lim} м²» в КЦ отсутствует). Итого фасонных {tc} мм по спец. {fmt(spec_total, 3)} м² / КЦ {fmt(kc_total, 3)} м²; {method}')
                extra_parts = 'в т.ч. тройники 500х300/Ø125, заглушки, пластины П3 вентмодулей (отнесены к фасонным — уточнить)' if ss == 'ОВ' and shape == 'прям' else ''
                note = note.replace(f'(позиция «от {lim} м²» в КЦ отсутствует)', f'(в КЦ одна позиция «{"до" if p[2] == "small" else "от"} {lim} м²» — требуется две)')
                rep.map(r, [d_small, d_big], st='error', st_ids={d_small: 'error', d_big: 'error'}, note=note + ('. ' + extra_parts if extra_parts else ''))
                FIT_REM.setdefault(w, []).append((tc, shape, lim, round(part_total * small_sh, 3), round(part_total - round(part_total * small_sh, 3), 3)))
                for r2, w2, p2 in others:
                    rep.map(r2, [], st='error', note=f'Строка «{t.name(r2)[:60]}»: по правилу объём «{"от" if p2[2] == "big" else "до"} {lim} м²» учтён в расчёте по строке «{t.name(r)[:50]}» выше (расчётное разделение {pct1(small_sh)}/{pct1(1 - small_sh)}); отдельная КЦ-позиция с таким объёмом правилу не соответствует')
            for i in ids:
                cover(i, f'fit {tc}')
            split_status(ids, f'Учтено через расчётные позиции фасонных частей ({tc} мм): {fmt(spec_total, 3)} м² (см. ТКП, расценки «соединительные элементы»)')
        FIT_INFO[(k, ss)] = fit_info
        # ---------------- крепёж
        for r, w in rows:
            if t.name(r).startswith('Крепежные элементы'):
                rep.map(r, kind='krep', note=KREP)
        # ---------------- прочие материалы
        for r, w in rows:
            nm = t.name(r); com = t.comment(r)
            if parse_kc_duct(nm) or parse_kc_fit(nm) or nm.startswith('Крепежные элементы'):
                continue
            props = propose(t, k, r, ss)
            ids = []; parts_cnt = []
            for ptxt, cnt, pids in props:
                ids += [i for i in pids if i not in ids]; parts_cnt.append((ptxt, cnt, pids))
            note = ''; st = 'ok'; hl = {}; st_ids = {}; eq = False; kind = 'match'; extra_ids = []
            wname = t.name(w)
            # --- специальные случаи
            if 'Приточная установка' in nm and 'UTR' in com or 'Вытяжная установка' in nm and 'UTR' in com:
                eq = True
                units = [x for x in agg_k if x['ss'] == ss and x['name'].startswith('Установка приточно-вытяжная')]
                mark = re.match(r'(UTR [\d-]+ V[\d.]+-[\d.]+x30\.R)', com).group(1)
                sel_units = [u for u in units if norm(mark) in norm(u['type'])]
                blk = 'приточный' if 'Приточная' in nm else 'вытяжной'
                ids = []
                for u in sel_units:
                    key = ('utr', u['id'], blk)
                    if key not in remark_rows:
                        ks = korf_sheet(u['systems'])
                        mass = (ks['mass_supply'] if blk == 'приточный' else ks['mass_exhaust']) if ks else None
                        remark_rows[key] = derive([u['id']], f'{u["name"]} — {blk} блок (производная позиция; масса блока по подбору Korf {fmt(mass, 1) if mass else "—"} кг, установки в сборе {fmt(ks["mass"], 1) if ks else "—"} кг)', 1.0, mass=str(mass) if mass else '',
                                                   systems=[s for s in u['systems'] if s.startswith('П' if blk == 'приточный' else 'В')])
                    ids.append(remark_rows[key])
                for u in sel_units:
                    split_status([u['id']], 'Учтено через производные позиции (приточный + вытяжной блоки) → установки в ТКП')
                note = ('Установка по спецификации — одна приточно-вытяжная с рециркуляцией (1 шт, по подбору Korf в сборе ' + ', '.join(fmt(korf_sheet(u['systems'])['mass'], 1) + ' кг' for u in sel_units if korf_sheet(u['systems'])) +
                        '); в КЦ разделена на приточный и вытяжной блоки по массе секций. Вентиляторные секции, шумоглушители SGK, фильтры WFUM, гибкие вставки WG и заслонки ZUT/ZR учтены в КЦ отдельными позициями — проверить на задвоение с расценкой установки «в комплекте с … шумоглушителем»')
                st = 'unsure'
                rep.remark(r, 'Прописать системы по всему оборудованию\nУточнить состав расценки установки: вентиляторные секции, шумоглушители, фильтры, гибкие вставки и заслонки учтены отдельными позициями (задвоение)')
            elif nm.startswith('Узел прохода_ / указать марку') and 'УС-1вп' in com:
                base = next(x['id'] for x in AGG if x['name'] == 'Узел стыковочный')
                key = ('uc', k)
                if key not in remark_rows:
                    remark_rows[key] = derive([base], f'Узел стыковочный УС-1вп — доля корпуса {k} ({UC_SHARE[k]} из 14 шт по числу систем ПУ корпуса)', float(UC_SHARE[k]),
                                               systems=[s for s in A[base]['systems'] if s.endswith(f'.{k}')], korpus=k, ss='ПД')
                ids = [remark_rows[key]]
                split_status([base], 'Учтено через производные позиции по корпусам (К1 — 2, К2 — 4, К3 — 6, К4 — 2 шт по числу систем ПУ)')
                note = 'Расценка «узел прохода» применена к узлу стыковочному УС-1вп (применительно — по примечанию)'
                st = 'unsure'
            elif nm.startswith('Фильтр для воздуховода кассетный') and 'FRKr' in com:
                frk = [x for x in agg_k if x['ss'] == ss and x['type'].startswith('FRKr')]
                fbx = [x for x in agg_k if x['ss'] == ss and x['type'].startswith('FBRr')]
                ids = []
                for f in frk:
                    bx = next((b for b in fbx if set(b['systems']) & set(f['systems'])), None)
                    base = [f['id']] + ([bx['id']] if bx else [])
                    ids.append(derive(base, f'Фильтр кассетный FRKr (G3) 300x150 + фильтр-бокс FBRr-K 300х150 (комплект на систему {", ".join(f["systems"])}; производная позиция)', 1.0, type_='FRKr (G3) 300х150 + FBRr-K 300х150'))
                    split_status(base, 'Учтено через производную позицию «фильтр + фильтр-бокс (комплект)»')
                note = 'По примечанию: фильтр FRKr (G3) 300x150 + фильтр-бокс FBRr-K 300х150 одной позицией (в наименовании КЦ — кассетный 400х200 G3, сечение по примечанию 300x150)'
                st = 'unsure'
                rep.remark(r, 'Добавить разными позициями (фильтр FRKr и фильтр-бокс FBRr-K)')
            elif nm.startswith('Огнезащитное покрытие'):
                kr = [x for x in agg_k if x['ss'] == ss and x['name'].startswith('Краска огнезащитная')]
                gr = [x for x in agg_k if x['ss'] == ss and x['name'].startswith('Грунт по металлу')]
                ids = []
                for x in kr:
                    ids.append(derive([x['id']], f'Краска огнезащитная EI60 EXPERT FIRE-OM — расход по спецификации 5 кг/м² × {fmt(x["qty"], 0)} м² (расчётная позиция, кг)', round(x['qty'] * 5, 1), unit='кг'))
                    split_status([x['id']], 'Учтено через расчётную позицию (кг по расходу 5 кг/м²)')
                for x in gr:
                    ids.append(derive([x['id']], f'Грунт ГФ-021 — расход по спецификации 0,1 кг/м² × {fmt(x["qty"], 0)} м² (расчётная позиция, кг)', round(x['qty'] * 0.1, 1), unit='кг'))
                    split_status([x['id']], 'Учтено через расчётную позицию (кг по расходу 0,1 кг/м²)')
                m2 = sum(x['qty'] for x in kr)
                note = f'Объём работы {fmt(m2, 0)} м² соответствует спецификации (краска EXPERT FIRE-OM {fmt(m2, 0)} м² + грунт ГФ-021 {fmt(m2, 0)} м²). Масса состава по расходу спецификации (5 кг/м² + грунт 0,1 кг/м²) не совпадает с КЦ ({fmt(t.qty(r), 1)} кг = {fmt(t.qty(r) / m2, 2)} кг/м²)'
                st = 'error'; kind = 'match_nw'
                WORK_POST[w] = (f'ОБЪЁМ РАБОТЫ по спецификации = площадь огнезащитного покрытия вентмодулей (краска EXPERT FIRE-OM, EI60)', 'м2', m2, t.qty(w))
                rep.remark(r, 'Объём состава принять по расходу проекта: EXPERT FIRE-OM 5 кг/м² (' + fmt(m2 * 5, 1) + ' кг) + грунт ГФ-021 0,1 кг/м² (' + fmt(m2 * 0.1, 1) + ' кг); в примечании указать марку и расход')
            elif 'K-flex' in nm:
                note = 'ОШИБКА номенклатуры: по спецификации — самоклеящийся покрывной материал (покрывной слой матов ОБМ-ТЕХВЕНТ), не изоляция K-flex AL CLAD 13 мм'
                st = 'error'; hl = {i: ['Самоклеящийся покрывной материал'] for i in ids}
                rep.remark(r, 'Изменить материал: самоклеящийся покрывной материал (покрывной слой изоляции), не K-flex 13 мм')
            elif nm.startswith('Мат прошивной'):
                names = sorted(set(A[i]['type'] or 'без марки' for i in ids))
                thick = sorted(set(re.search(r'толщиной (\d+) мм', A[i]['name']).group(1) for i in ids if re.search(r'толщиной (\d+) мм', A[i]['name'])))
                note = f'Марка по спецификации {", ".join(names)} (ВЗТМ), толщина {", ".join(thick)} мм; в КЦ — БИЗОН. ' + ('Две разные позиции спецификации (мат кашированный фольгой и без) в одной позиции КЦ' if len(ids) > 1 else '')
                st = 'unsure' if len(ids) == 1 else 'error'
                hl = {i: [re.escape(A[i]['type'])] for i in ids if A[i]['type']}
                rep.remark(r, ('Добавить разными позициями\n' if len(ids) > 1 else '') + 'Добавить примечание с маркой по проекту (ОБМ-ТЕХВЕНТ' + (' 60' if len(ids) > 1 else '') + ', ВЗТМ)')
            elif nm.startswith('Материал базальтовый огнезащитный'):
                ei = re.search(r'EI\s*(\d+)', nm).group(1)
                if k == 3 and ei == '60' and ss == 'ОВ':
                    ids.append(84); note = 'В т.ч. позиция л. 23 (В1.3.1) ОБМ-5Ф 1 м² без указания EI — принята как EI60. '
                    st = 'unsure'
                marks = sorted(set(A[i]['type'] for i in ids if A[i]['type']))
                note += f'Марка по спецификации: {", ".join(marks) if marks else "ОБМ/ПМБОР без марки (вентмодули)"}; эквивалент ОБМ-ВЕНТ EI {ei} принят по пределу огнестойкости'
                if ss == 'ОВ' and ei == '60':
                    note += '. Включает огнезащиту вентмодулей квартир (ВМ.ОЦ.1)'
            elif nm.startswith('Лист стальной оцинкованный'):
                note = 'По примечанию — фартук узла прохода из оцинкованной стали 0,8 мм (в наименовании КЦ 0,5 мм)'
                st = 'ok'
            elif nm.startswith('Уголок стальной'):
                note = 'Детали крепления воздуховодов по спецификации (кг)' + (' + средства для крепления (Серия 5.904-1)' if len(ids) > 1 else '') + '. Материал КЦ должен называться «Металлическая рама для воздуховодов (с огрунтовкой и огнезащитной окраской за 2 раза)»'
                st = 'unsure'
                rep.remark(r, 'Материал взять, как\n"Металлическая рама для воздуховодов (с огрунтовкой и огнезащитной окраской за 2 раза)"')
            elif nm.startswith('Воздуховод гибкий'):
                note = 'По примечанию: полужёсткий неизолированный воздуховод ПВ Ø127 (Арктика) — соответствует спецификации; в наименовании КЦ «алюминиевый гофрированный Алювент d125»'
                st = 'ok'
            elif nm.startswith('Сетка в рамке') and 'D900' in nm:
                note = 'ОШИБКА номенклатуры: по спецификации ячейка 20x20 мм (в КЦ 50х50)'
                st = 'error'; hl = {i: [r'ячейкой 20x20'] for i in ids}
                rep.remark(r, 'Изменить материал: ячейка 20х20 мм по проекту')
            elif nm.startswith('Сетка в рамке') and any(A[i]['name'].startswith('Металлическая сетка') for i in ids):
                note = 'В т.ч. 1 шт — металлическая сетка в рамке БСР 350x350 (Арктос, ПЕ6) — иная номенклатура'
                st = 'unsure'; st_ids = {i: 'unsure' for i in ids if A[i]['name'].startswith('Металлическая сетка')}
                hl = {i: [r'БСР 350x350'] for i in ids if A[i]['name'].startswith('Металлическая сетка')}
                rep.remark(r, 'Добавить разными позициями (1 шт — БСР 350x350 Арктос)')
            elif nm.startswith('Решетка декоративная') and any('RAL 7016' in A[i]['name'] for i in ids):
                note = 'В т.ч. 1 шт в исполнении RAL 7016 (по спецификации); в КЦ все RAL 9016'
                st = 'unsure'; st_ids = {i: 'unsure' for i in ids if 'RAL 7016' in A[i]['name']}
                hl = {i: [r'RAL 7016'] for i in ids if 'RAL 7016' in A[i]['name']}
                rep.remark(r, 'Добавить разными позициями (1 шт — RAL 7016)')
            # --- оборудование (eq) по семействам
            if any(key in nm for key in ('Вентилятор канальный', 'Вентилятор радиальный', 'Установка подпора', 'Стакан монтажный', 'Вентилятор крышный')) or (nm.startswith('Приточная установка') and 'УПОР' in com) or (nm.startswith('Вентилятор осевой') and 'ERA' not in com):
                eq = True
            if nm.startswith('Вентилятор осевой') and 'ERA' in com:
                note = (note + '. ' if note else '') + 'Вентиляторы вентмодулей квартир (ERA 5C, ЭРА) — системы в проекте не обозначены (раздел «Вытяжная вентиляция квартир»)'
            # --- обобщённые позиции: несколько марок в одном примечании
            multi = [p for p in parts_cnt if p[2]]
            if len(multi) > 1:
                st = 'error' if st != 'error' else st
                for i in ids:
                    if A[i]['type']:
                        hl.setdefault(i, []).append(re.escape(A[i]['type']))
                note = (note + '. ' if note else '') + f'Несколько типоразмеров/марок в одной позиции КЦ ({len(multi)}): ' + '; '.join(p[0][:40] for p in multi)
                rep.remark(r, (rep.REMARKS.get(r, '') + '\n' if r in rep.REMARKS else '') + 'Добавить разными позициями')
            elif len(ids) > 1 and len(set(A[i]['type'] for i in ids)) > 1 and not nm.startswith(('Сетка', 'Материал базальтовый', 'Фильтр для воздуховода', 'Огнезащитное')) and not ('UTR' in com):
                # разные марки спецификации под одной маркой примечания (например RSK-100 / RSK 100)
                pass
            # --- проверка марки примечания на соответствие (наименование спец. ≠ марка)
            for i in ids:
                x = A[i]
                if x['type'] and x['type'] == 'УПОР-ВО-7,1-Б-2' and '7,1-В-2' in x['name']:
                    note = (note + '. ' if note else '') + 'В спецификации (ДП8.1.2) наименование «УПОР-ВО-7,1-В-2», марка «УПОР-ВО-7,1-Б-2» — противоречие спецификации, уточнить у проектировщика'
                    st = 'unsure' if st == 'ok' else st
            if not ids:
                note = note or 'Позиция в спецификации не найдена'
                rep.map(r, [], note=note, st='error')
                rep.remark(r, 'удалить ' + fmt(t.qty(r), 0) + ' ' + str(t.unit(r)))
                continue
            rep.map(r, ids, note=note, st=st, hl=hl, st_ids=st_ids, eq=eq, kind=kind)
            if eq:
                rep.remark(r, (rep.REMARKS[r] if r in rep.REMARKS and 'Прописать системы' not in rep.REMARKS[r] else '') + ('\n' if r in rep.REMARKS and 'Прописать системы' not in rep.REMARKS[r] else '') + 'Прописать системы по всему оборудованию' if 'Прописать системы' not in rep.REMARKS.get(r, '') else rep.REMARKS[r])
                for i in ids:
                    x = A[i]
                    mark = x['type'] or (re.search(r'(UTR \S+ V\S+)', x['name']).group(1) if 'UTR' in x['name'] else x['name'][:40])
                    if 'UTR' in x['name'] and x.get('derived_from'):
                        ks = korf_sheet(x['systems'] or A[x['derived_from'][0]]['systems'])
                        sm, sp = (float(x['mass']) if x['mass'] else None), (ks['page'] if ks else None)
                    elif 'UTR' in x['name']:
                        ks = korf_sheet(x['systems']); sm, sp = (None, None)
                        if ks:
                            fan = [m for n_, m in ks['sections_supply'] if 'Вентилятор' in n_]
                            sm = fan[0] if fan else None; sp = ks['page']
                    elif 'TUBE' in mark:
                        ks = next((s for s in SEL if s['vendor'] == 'Русклимат' and s['system'] in x['systems']), None)
                        sm, sp = (ks['mass'], ks['page']) if ks else (None, None)
                    else:
                        sm, sp, _ = sel_mass(mark, x['systems'])
                    EQ_ROWS.append(dict(k=k, ss=ss, systems=', '.join(x['systems']), name=x['name'], mark=mark, qty=x['qty'], spec_mass=x['mass'], sel_mass=sm, sel_page=sp,
                                        row=r, work=wname, limit=mass_limit(wname), comment=com, kc_name=nm))
            for i in ids:
                cover(i, f'row {r}')
        # ---------------- учтено в составе / не разнесено
        incl = []
        for x in agg_k:
            if x['ss'] != ss or x['id'] in covered or x.get('duct') or x.get('derived_from'):
                continue
            n_ = x['name']
            if n_.startswith(INCLUDED_UNIT):
                rep.INCLUDED[x['id']] = 'Учтено в составе установки UTR (приточный/вытяжной блок) — состав расценки установки требует уточнения'; cover(x['id'], 'incl-unit')
            elif n_.startswith(HARDWARE) or n_.startswith('Средства для крепления'):
                rep.INCLUDED[x['id']] = 'Учтено в составе сопутствующего материала КЦ «Крепежные элементы для воздуховодов» (крепёж вентмодулей квартир) — требует уточнения/подтверждения'; cover(x['id'], 'incl-hw')
            elif n_.startswith(CONSUMABLE):
                rep.INCLUDED[x['id']] = 'Учтено в составе изоляции/заделки (расходный материал: шнур, скотч, пена, проволока) — в расчёт не заносим'; cover(x['id'], 'incl-cons')
        unmatched = [x['id'] for x in agg_k if x['ss'] == ss and x['id'] not in covered and not x.get('duct') and not x.get('derived_from')]
        test_row = next(r for r in works_by_ss[ss] if 'Испытание' in works_by_ss[ss][r])
        rep.unmatched_block(test_row, f'Материалы спецификации, НЕ разнесённые в ТКП — Корпус {k}, {SUB_NAME[ss]}', unmatched)
        for i in unmatched:
            cover(i, 'unmatched')
            x = A[i]
            if x['name'].startswith('Короб под вентилятор'):
                rep.remark(('bitem', i), f'Добавить в вентиляторы канальные: короб {x["type"]} — {fmt(x["qty"], 0)} шт')
            else:
                rep.remark(('bitem', i), f'Добавить {x["type"] or x["name"][:40]} — {fmt(x["qty"], 0)} {x["unit"]}')
        # ---------------- замечания по воздуховодам (строки работ)
        for w in works_by_ss[ss]:
            wn = works_by_ss[ss][w]
            if 'Прокладка воздуховодов прямоугольного' in wn and 'соединительные' not in wn:
                wk = 'до 0,7' if 'до 0,7' in wn else ('0,71' if '0,71' in wn else '0,91')
                lines = []
                for tt in sorted(set(key[0] for key in rslots), key=lambda s: float(s.replace(',', '.'))):
                    if thick_work(tt) != wk:
                        continue
                    if float(tt.replace(',', '.')) <= 0.7:
                        continue
                    lines.append(f'Прямоугольные воздуховоды {tt} мм' + (' - вынести отдельной расценкой, с указанием в примечании толщины' if tt == '0,9' else ''))
                    lines.append('Заменить расценки на материалы:' if tt == '0,8' else 'Расценки на материалы:')
                    n_ = 1
                    for cat in ('A', 'B', 'C'):
                        for std in ('std', 'nonstd'):
                            its = rslots.get((tt, cat, std), [])
                            if not its:
                                continue
                            v = round(sum(duct_area(A[i], sh) for i, sh in its), 3)
                            mat = slot_material_name('прям', (tt, cat, std))
                            if tt == '0,9' and std == 'nonstd':
                                mat = slot_material_name('прям', ('0,8', cat, std)) + ' (применительно, в примечании указать, что толщина 0,9 мм)'
                            lines.append(f'{n_}. {mat} - {fmt(v, 3)} м2'); n_ += 1
                    lines.append('')
                if lines:
                    lines.append(f'Не равно - {pct(NONSTD_SHARE[ss])} от общей площади воздуховодов каждой позиции. Разделение по расценкам посчитать условно, что каждая позиция (каждый размер) равна 1250 мм, далее разделить на "равно" и "не равно". Не учитывать разделение, если м2 по позиции меньше 10 м2. '
                                 f'Категория — по площади одного изделия при длине 1,25 м (периметр × 1,25): до 0,78 / от 0,78 до 4,25 / свыше 4,25 м2.')
                    rep.remark(w, '\n'.join(lines))
            if 'Прокладка воздуховодов круглого' in wn and 'соединительные' not in wn:
                wk = 'до 0,7' if 'до 0,7' in wn else ('0,71' if '0,71' in wn else '0,91')
                errs = []
                for (tt, conn), its in sorted(roslots.items()):
                    if thick_work(tt) != wk:
                        continue
                    v = round(sum(duct_area(A[i]) for i, _ in its), 3)
                    kcv = kc_round.get((tt, conn))
                    if kcv is None or abs(kcv - v) > TOL:
                        errs.append(f'{conn.capitalize()} ({tt} мм) - {"до" if conn == "ниппель" else "от"} D315 - {fmt(v, 3)} м2')
                if errs:
                    rep.remark(w, 'Изменить\n' + '\n'.join(errs))

for w, lst in FIT_REM.items():
    lines = ['Заменить расценки на материалы:']
    n_ = 1
    for tc, shape, lim, sm, bg in lst:
        sh_name = 'прямоугольного сечения' if shape == 'прям' else 'круглого сечения, ниппельное соединение'
        lines.append(f'{n_}. Фасонные изделия воздуховодов / {sh_name} / {tc}мм / до {lim}м2 (включительно) / класс B - {fmt(sm, 3)} м2'); n_ += 1
        lines.append(f'{n_}. Фасонные изделия воздуховодов / {sh_name} / {tc}мм / от {lim}м2 / класс B - {fmt(bg, 3)} м2'); n_ += 1
    lines.append(f'Доля «до 0,3 (0,18) м2» — {pct1(FITTING_SMALL_SHARE["ОВ"])} для общеобменной и {pct1(FITTING_SMALL_SHARE["ПД"])} для противодымной вентиляции (правило заказчика от 10.09.2026).')
    rep.remark(w, '\n'.join(lines))

# ---- категория расценки по массе (оборудование)
for e in EQ_ROWS:
    lim = e['limit']
    masses = []
    for m in (e['spec_mass'], e['sel_mass']):
        try:
            if m not in (None, ''):
                masses.append(float(str(m).replace(',', '.')))
        except ValueError:
            pass
    if lim and masses and max(masses) > lim + 1e-9:
        d = rep.MAP[e['row']]
        txt = f'ОШИБКА категории расценки: масса {e["mark"]} {fmt(max(masses), 1)} кг (по {"листу подбора" if e["sel_mass"] and float(e["sel_mass"]) == max(masses) else "спецификации"}) превышает предел расценки «до {lim} кг»'
        if txt not in d['note']:
            d['note'] = (d['note'] + '. ' if d['note'] else '') + txt
        d['st'] = 'error'
        rep.remark(e['row'], (rep.REMARKS.get(e['row'], '') + '\n' if e['row'] in rep.REMARKS else '') + f'Заменить расценку: масса {fmt(max(masses), 0)} кг — применить расценку «{e["work"].split(" / до")[0]} / до {int(math.ceil(max(masses) / 100.0) * 100)} кг»')

# =====================================================================================
# 3. Контроль полноты
# =====================================================================================
missing = [x for x in AGG if x['korpus'] in (1, 2, 3, 4) and x['ss'] in ('ОВ', 'ПД') and x['id'] not in covered and not x.get('derived_from')]
missing += [x for x in AGG if x['korpus'] is None and x['ss'] == 'ПД' and x['id'] not in covered]
print('НЕ охвачено позиций:', len(missing))
for x in missing[:30]:
    print('   ', x['id'], x['korpus'], x['ss'], x['name'][:70], x['qty'])
dbl = {i: h for i, h in covered.items() if len([hh for hh in h if not hh.startswith('virtual') and not hh.startswith('duct') and not hh.startswith('fit')]) > 1}
print('Охвачено дважды:', len(dbl), list(dbl.items())[:10])
print('derived positions:', NEXT_ID[0] - 981)


# =====================================================================================
# 4. Сборка листа ТКП и пост-обработка
# =====================================================================================
ws = rep.build()
C = rep.cols
for orig_row, text in POSTFIX.items():
    if orig_row in rep.deleted:
        continue
    nr = rep.old2new[orig_row]
    cell = ws[f'{C["name"]}{nr}']
    old = str(cell.value)
    tail = old[old.index(' — '):] if ' — ' in old else ''
    cell.value = text + tail
for r_ in range(t.data_start, ws.max_row + 1):
    v = ws[f'{C["name"]}{r_}'].value
    if isinstance(v, str) and ' — 0 поз. спецификации: .' in v:
        ws[f'{C["name"]}{r_}'] = v.replace(' — 0 поз. спецификации: .', ' — по правилу позиций спецификации в этой группе нет.')
for w, (txt, unit, val, kq) in WORK_POST.items():
    nw = rep.old2new[w]
    ws[f'{C["name"]}{nw}'] = txt; ws[f'{C["unit"]}{nw}'] = unit; ws[f'{C["qty"]}{nw}'] = val
    ok = abs(val - kq) <= TOL
    ws[f'{C["chk"]}{nw}'] = (f'Объём работы соответствует: {fmt(val, 3)} = КЦ {fmt(kq, 3)}' if ok else f'РАСХОЖДЕНИЕ объёма работы: по спец. {fmt(val, 3)} / КЦ {fmt(kq, 3)}')
    for col in (C['name'], C['unit'], C['qty'], C['chk']):
        c = ws[f'{col}{nw}']; c.fill = FILLS['ok' if ok else 'error']; c.font = F_BOLD; c.border = BORDER
        c.alignment = AL_CENTER if col in (C['unit'], C['qty']) else AL_WRAP
    ws[f'{C["qty"]}{nw}'].number_format = '#,##0.000'
ws[f'{C["name"]}{rep.old2new[8]}'] = 'Блок «1. Жилое здание»: все расценки имели нулевой объём и удалены (п. 1 ТЗ); оставлены только заголовки разделов (итоги = 0)'
ws[f'{C["name"]}{rep.old2new[8]}'].font = F_NOTE; ws[f'{C["name"]}{rep.old2new[8]}'].alignment = AL_WRAP
# заголовок столбца спецификации — уточнение про корпуса
ws[f'{C["name"]}{t.header_rows[0]}'] = 'Спецификация 111-1123-ОК-1/Н-3.1-1-1..4-ОВ2.СО (с учётом ТР2), по корпусам: наименование / тип, марка / код / поставщик [системы; листы спец.]. Красным шрифтом — элемент, не соответствующий КЦ'

# =====================================================================================
# 5. Лист «Сводная по спецификации» (по корпусам и подсистемам)
# =====================================================================================
def build_summary_local(wb, agg, status, title='Сводная по спецификации', note=''):
    sv = wb.create_sheet(title)
    sv['A1'] = 'Сводная спецификация по корпусам и подсистемам (с учётом ТР2). Позиции агрегированы по наименованию/марке внутри корпуса и подсистемы; расчётные (производные) позиции помечены.'
    sv['A1'].font = Font(name='Times New Roman', size=14, bold=True)
    sv['A2'] = note; sv['A2'].font = F_NOTE
    heads_top = ['Корпус / подсистема', 'Позиций (агрегир.)', 'Разнесено / учтено', 'Не разнесено / вне ТКП', 'Из них с ошибкой', 'Требует уточнения']
    for j, h in enumerate(heads_top, start=1):
        c = sv.cell(4, j, h); c.font = F_BOLD; c.fill = FILLS['hdr']; c.border = BORDER; c.alignment = AL_CENTER
    HDR = 16
    heads = ['№', 'Корпус', 'Подсистема', 'Раздел спецификации', 'Системы', 'Наименование и техническая характеристика', 'Тип, марка', 'Код', 'Поставщик', 'Ед. изм.', 'Кол-во', 'Масса 1 ед., кг', 'Масса всего, кг', 'Листы спец.', 'Статус в ТКП']
    for j, h in enumerate(heads, start=1):
        c = sv.cell(HDR, j, h); c.font = F_BOLD; c.fill = FILLS['hdr']; c.border = BORDER; c.alignment = AL_CENTER
    row, n = HDR + 1, 0
    groups = [(k, ss) for k in (1, 2, 3, 4) for ss in ('ОВ', 'ПД')] + [(None, 'ПД'), (None, 'КОНД')]
    for k, ss in groups:
        sub = [x for x in agg if x['korpus'] == k and x['ss'] == ss]
        if not sub:
            continue
        label = (f'Корпус {k} — {SUB_NAME[ss]}' if k else ('Общие позиции (ПУ — передвижные установки, все корпуса)' if ss == 'ПД' else SUB_NAME['КОНД']))
        c = sv.cell(row, 1, label); c.font = Font(name='Times New Roman', size=13, bold=True)
        sv.merge_cells(start_row=row, start_column=1, end_row=row, end_column=15)
        for j in range(1, 16):
            sv.cell(row, j).fill = FILLS['block']; sv.cell(row, j).border = BORDER
        row += 1
        for x in sub:
            n += 1
            st = status.get(x['id'], 'Вне ТКП (раздел не входит в состав ТКП)' if ss == 'КОНД' else 'НЕ разнесено')
            try:
                mass = float(str(x['mass']).replace(',', '.')) if x['mass'] else None
            except ValueError:
                mass = None
            nm = x['name'] + (' [РАСЧЁТНАЯ/ПРОИЗВОДНАЯ ПОЗИЦИЯ]' if x.get('derived_from') else '')
            vals = [n, f'К{k}' if k else '—', SUB_NAME[ss], ', '.join(x['sections']), short_list(x['systems'], 12), nm, x['type'], x['code'], x['supplier'],
                    x['unit'], x['qty'], mass, f'=IF(L{row}="","",ROUND(K{row}*L{row},2))', short_list([str(s) for s in x['sheets']], 15), st]
            for j, v in enumerate(vals, start=1):
                c = sv.cell(row, j, v); c.font = F_DATA; c.border = BORDER
                c.alignment = AL_WRAP if j in (4, 5, 6, 7, 15) else AL_CENTER
                if j in (11, 12, 13):
                    c.number_format = '#,##0.000' if j == 11 else '#,##0.00'
            if 'НЕ разнесено' in st or 'ОШИБКА' in st or 'ОТСУТСТВУЮЩ' in st:
                sv.cell(row, 15).fill = FILLS['error']
            elif 'уточнени' in st:
                sv.cell(row, 15).fill = FILLS['unsure']
            elif st.startswith('Разнесено') or st.startswith('Учтено'):
                sv.cell(row, 15).fill = FILLS['ok']
            row += 1
    LAST = row - 1
    rr = 5
    for k, ss in groups:
        if not any(x['korpus'] == k and x['ss'] == ss for x in agg):
            continue
        lab = (f'Корпус {k} — {SUB_NAME[ss]}' if k else ('Общие позиции (ПУ)' if ss == 'ПД' else SUB_NAME['КОНД']))
        kcode = f'К{k}' if k else '—'
        sv[f'A{rr}'] = lab
        base = f'$B${HDR+1}:$B${LAST},"{kcode}",$C${HDR+1}:$C${LAST},"{SUB_NAME[ss]}"'
        sv[f'B{rr}'] = f'=COUNTIFS({base})'
        sv[f'C{rr}'] = f'=COUNTIFS({base},$O${HDR+1}:$O${LAST},"Разнесено*")+COUNTIFS({base},$O${HDR+1}:$O${LAST},"Учтено*")'
        sv[f'D{rr}'] = f'=B{rr}-C{rr}'
        sv[f'E{rr}'] = f'=COUNTIFS({base},$O${HDR+1}:$O${LAST},"*ОШИБКА*")+COUNTIFS({base},$O${HDR+1}:$O${LAST},"*ОТСУТСТВУЮЩ*")+COUNTIFS({base},$O${HDR+1}:$O${LAST},"НЕ разнесено*")'
        sv[f'F{rr}'] = f'=COUNTIFS({base},$O${HDR+1}:$O${LAST},"*уточнени*")'
        for c in 'ABCDEF':
            sv[f'{c}{rr}'].font = F_DATA; sv[f'{c}{rr}'].border = BORDER; sv[f'{c}{rr}'].alignment = AL_CENTER
        rr += 1
    sv[f'A{rr}'] = 'Итого'
    for c in 'BCDEF':
        sv[f'{c}{rr}'] = f'=SUM({c}5:{c}{rr-1})'
    for c in 'ABCDEF':
        sv[f'{c}{rr}'].font = F_BOLD; sv[f'{c}{rr}'].border = BORDER; sv[f'{c}{rr}'].alignment = AL_CENTER
    for col, w in zip('ABCDEFGHIJKLMNO', [34, 8, 22, 26, 28, 70, 30, 10, 12, 8, 12, 12, 13, 18, 48]):
        sv.column_dimensions[col].width = w
    sv.freeze_panes = f'A{HDR+1}'; sv.auto_filter.ref = f'A{HDR}:O{LAST}'
    return sv


# =====================================================================================
# 6. Лист «Воздуховоды м2» (по корпусам; толщина-зависимые группы)
# =====================================================================================
from spec_local import duct_info2


def build_duct_sheet_local(wb, items, agg, title='Воздуховоды м2'):
    dv = wb.create_sheet(title)
    dv['A1'] = 'Воздуховоды и фасонные части по спецификации (с учётом ТР2): расчёт м² построчно по системам, по корпусам → подсистема → группа → толщина, с итогами по группам КЦ'
    dv['A1'].font = Font(name='Times New Roman', size=14, bold=True)
    dv['A2'] = ('Правила: площадь прямоугольных — L × 2·(a+b)/1000, круглых — L × π·d/1000. Длина изделия 1,25 м: площадь 1 изделия = периметр × 1,25 → категория КЦ '
                '(до 0,78 / 0,78–4,25 / свыше 4,25 м²). Доля некратных (≠1250/1500): общеобменная 10 %, противодымная 30 %; позиции < 10 м² не делятся. '
                'Круглые: d ≤ 315 — ниппель, d > 315 — фланец; группы — по толщине стенки. Фасонные: спецификация даёт м² по системам без разделения прям./кругл.; '
                'доля «до 0,3 м² (прямоуг.) / до 0,18 м² (круглые)» — 91,5 % (общеобменная) / 90,6 % (противодымная). Вентмодули квартир (ВМ.ОЦ.1): воздуховоды 500х300 и Ø125, тройники/заглушки/пластины — в составе фасонных.')
    dv['A2'].font = F_NOTE; dv['A2'].alignment = Alignment(wrap_text=True, vertical='top'); dv.merge_cells('A2:S2'); dv.row_dimensions[2].height = 75
    heads = ['№', 'Корпус', 'Подсистема', 'Группа', 'Система', 'Лист спец.', 'Наименование по спецификации', 'Сечение / Ø, мм', 'Толщина, мм', 'Ед. изм.',
             'Кол-во по спец.', 'Периметр, м', 'Площадь всего, м²', 'Площадь 1 изделия (L=1,25 м), м²', 'Категория КЦ', 'Доля некратных', 'м² кратные (1250/1500)', 'м² некратные (≠1250/1500)', 'Соединение (круглые, по правилу)']
    DH = 4
    for j, h in enumerate(heads, start=1):
        c = dv.cell(DH, j, h); c.font = F_BOLD; c.fill = FILLS['hdr']; c.border = BORDER; c.alignment = AL_CENTER
    NC = len(heads)

    def hdr_line(row, text, fill, size=12):
        c = dv.cell(row, 1, text); c.font = Font(name='Times New Roman', size=size, bold=True)
        dv.merge_cells(start_row=row, start_column=1, end_row=row, end_column=NC)
        for j in range(1, NC + 1):
            dv.cell(row, j).fill = fill; dv.cell(row, j).border = BORDER

    def sum_line(row, label, formula, kc, note=''):
        dv.cell(row, 7, label).font = F_BOLD
        dv.cell(row, 13, formula).font = F_BOLD; dv.cell(row, 13).number_format = '#,##0.000'
        dv.cell(row, 14, 'КЦ:').font = F_BOLD
        if kc is None:
            dv.cell(row, 15, 'позиция в КЦ отсутствует').font = F_BOLD
            dv.cell(row, 17, f'=M{row}').font = F_BOLD; dv.cell(row, 17).number_format = '#,##0.000;[Red]-#,##0.000'
            dv.cell(row, 18, f'=IF(ABS(M{row})<=0.0005,"не требуется","ОШИБКА: нет позиции в КЦ")').font = F_BOLD
        else:
            dv.cell(row, 15, kc).font = F_BOLD; dv.cell(row, 15).number_format = '#,##0.000'
            dv.cell(row, 16, 'Δ:').font = F_BOLD
            dv.cell(row, 17, f'=ROUND(M{row}-O{row},3)').font = F_BOLD; dv.cell(row, 17).number_format = '#,##0.000;[Red]-#,##0.000'
            dv.cell(row, 18, f'=IF(ABS(Q{row})<=0.05,"Соответствует","РАСХОЖДЕНИЕ")').font = F_BOLD
        dv.cell(row, 19, note).font = F_NOTE
        for j in range(1, NC + 1):
            dv.cell(row, j).border = BORDER; dv.cell(row, j).fill = FILLS['extra']

    row, n = DH + 1, 0
    for k in (1, 2, 3, 4):
        agg_k = [x for x in agg if x['korpus'] == k]
        for ss in ('ОВ', 'ПД'):
            lines = [it for it in items if it['korpus'] == k and it['ss'] == ss]
            if not lines:
                continue
            kc_rect = DUCT_KC[(k, ss)]['rect']; kc_round = DUCT_KC[(k, ss)]['round']
            hdr_line(row, f'КОРПУС {k} — {SUB_NAME[ss]}', FILLS['block'], 13); row += 1
            ducts = [(it, duct_info2(it['name'])) for it in lines if duct_info2(it['name']) and it['unit_n'] in ('м', 'п.м')]
            rslots = rect_slots(agg_k, ss)
            kk = NONSTD_SHARE[ss]
            for tt in sorted(set(di['t'] for it, di in ducts if di['kind'] == 'прям'), key=lambda s: float(s.replace(',', '.'))):
                hdr_line(row, f'Воздуховоды прямоугольные, толщина стенки {tt} мм — корпус {k}, {SUB_NAME[ss]}', FILLS['hdr']); row += 1
                first = row
                for it, di in ducts:
                    if di['kind'] != 'прям' or di['t'] != tt:
                        continue
                    n += 1; qty = it['qtyf']; w_, h_ = map(int, di['size'].split('x'))
                    ax = next(x for x in agg_k if x['ss'] == ss and x['name'] == it['name'] and x['type'] == it['type'] and x['unit'] == it['unit_n'])
                    share = 0 if duct_area(ax) < NONSTD_MIN_M2 else kk
                    vals = [n, f'К{k}', SUB_NAME[ss], 'Воздуховод прямоугольный', it['system'], it['sheet'], it['name'], di['size'].replace('x', '×'), tt, 'м', qty,
                            f'=2*({w_}+{h_})/1000', f'=K{row}*L{row}', f'=L{row}*1.25',
                            f'=IF(N{row}<=0.78,"{CAT_SHORT["A"]}",IF(N{row}<=4.25,"{CAT_SHORT["B"]}","{CAT_SHORT["C"]}"))', share, f'=M{row}*(1-P{row})', f'=M{row}*P{row}', '—']
                    for j, v in enumerate(vals, start=1):
                        c = dv.cell(row, j, v); c.font = F_DATA; c.border = BORDER; c.alignment = AL_WRAP if j == 7 else AL_CENTER
                        if j in (11, 13, 14, 17, 18):
                            c.number_format = '#,##0.000'
                        if j == 12:
                            c.number_format = '0.0000'
                        if j == 16:
                            c.number_format = '0%'
                    row += 1
                last = row - 1
                hdr_line(row, f'Итоги по группам КЦ — прямоугольные {tt} мм (некратные {pct(kk)}, позиции < 10 м² не делятся)', FILLS['extra'], 11); row += 1
                if float(tt.replace(',', '.')) <= 0.7:
                    kc_sum = round(sum(v for key, v in kc_rect.items() if key[0] == tt), 3)
                    sum_line(row, f'ВСЕГО прямоугольные {tt} мм (в КЦ — одна позиция (БИМ) без категорий)', f'=ROUND(SUM(M{first}:M{last}),3)', kc_sum if kc_sum else None,
                             'номенклатура класса B для толщины ≤ 0,7 мм в справочнике КЦ отсутствует'); row += 2
                    continue
                for cat in ('A', 'B', 'C'):
                    for std in ('std', 'nonstd'):
                        col = 'Q' if std == 'std' else 'R'
                        exp_ = round(sum(duct_area(A[i], sh) for i, sh in rslots.get((tt, cat, std), [])), 3)
                        kc = kc_rect.get((tt, cat, std))
                        if kc is None and exp_ <= 0.0005:
                            continue
                        sum_line(row, f'{CAT_SHORT[cat]} — {STD_NAME[std]}', f'=ROUND(SUMIFS({col}{first}:{col}{last},O{first}:O{last},"{CAT_SHORT[cat]}"),3)', kc,
                                 '' if kc is not None else 'по правилу расчёта требуется отдельная позиция КЦ'); row += 1
                sum_line(row, f'ВСЕГО прямоугольные {tt} мм', f'=ROUND(SUM(M{first}:M{last}),3)', round(sum(v for key, v in kc_rect.items() if key[0] == tt), 3)); row += 2
            if any(di['kind'] == 'кругл' for it, di in ducts):
                hdr_line(row, f'Воздуховоды круглые — корпус {k}, {SUB_NAME[ss]}', FILLS['hdr']); row += 1
                first = row
                for it, di in ducts:
                    if di['kind'] != 'кругл':
                        continue
                    n += 1; qty = it['qtyf']; dd = int(di['size'])
                    vals = [n, f'К{k}', SUB_NAME[ss], 'Воздуховод круглый', it['system'], it['sheet'], it['name'], f'Ø{dd}', di['t'], 'м', qty,
                            f'=PI()*{dd}/1000', f'=K{row}*L{row}', '—', '—', '—', '—', '—', f'=IF({dd}>315,"фланец","ниппель")']
                    for j, v in enumerate(vals, start=1):
                        c = dv.cell(row, j, v); c.font = F_DATA; c.border = BORDER; c.alignment = AL_WRAP if j == 7 else AL_CENTER
                        if j in (11, 13):
                            c.number_format = '#,##0.000'
                        if j == 12:
                            c.number_format = '0.0000'
                    row += 1
                last = row - 1
                hdr_line(row, f'Итоги по группам КЦ — круглые (толщина × соединение)', FILLS['extra'], 11); row += 1
                rsl = round_slots_t(agg_k, ss)
                for (tt, conn) in sorted(set(list(rsl.keys()) + list(kc_round.keys()))):
                    sum_line(row, f'Круглые {tt} мм — {conn} (по правилу d {"≤" if conn == "ниппель" else ">"} 315)',
                             f'=ROUND(SUMIFS(M{first}:M{last},I{first}:I{last},"{tt}",S{first}:S{last},"{conn}"),3)', kc_round.get((tt, conn)),
                             '' if kc_round.get((tt, conn)) is not None else f'позиция «{tt} мм / {conn}» в КЦ отсутствует'); row += 1
                sum_line(row, 'ВСЕГО круглые', f'=ROUND(SUM(M{first}:M{last}),3)', round(sum(kc_round.values()), 3)); row += 2
            # фасонные
            fl = [it for it in lines if it['name'].startswith(FIT_PARTS)]
            if fl:
                hdr_line(row, f'Фасонные части (соединительные детали, тройники/заглушки/пластины вентмодулей) — корпус {k}, {SUB_NAME[ss]}', FILLS['hdr']); row += 1
                first = row
                for it in fl:
                    n += 1
                    m = re.search(r'толщиной ([\d,]+)мм', it['name'])
                    tc = TCLASS(m.group(1)) if m else '0,8'
                    vals = [n, f'К{k}', SUB_NAME[ss], f'Фасонные части {tc} мм', it['system'], it['sheet'], it['name'], '—', tc, 'м²', it['qtyf'], '—', f'=K{row}', '—', '—', '—', '—', '—', 'кругл.' if it['name'].startswith(ROUND_PARTS) else '—']
                    for j, v in enumerate(vals, start=1):
                        c = dv.cell(row, j, v); c.font = F_DATA; c.border = BORDER; c.alignment = AL_WRAP if j == 7 else AL_CENTER
                        if j in (11, 13):
                            c.number_format = '#,##0.000'
                    row += 1
                last = row - 1
                fi = FIT_INFO.get((k, ss), {})
                hdr_line(row, f'Итоги по группам КЦ — фасонные ({SUB_NAME[ss]}; «до 0,3 / 0,18 м²» = {pct1(FITTING_SMALL_SHARE[ss])})', FILLS['extra'], 11); row += 1
                for tc, info in sorted(fi.items()):
                    sum_line(row, f'ВСЕГО фасонные {tc} мм по спецификации', f'=ROUND(SUMIFS(M{first}:M{last},I{first}:I{last},"{tc}"),3)', info['kc_total'], info['method']); row += 1
                    for shape, d in info['rows'].items():
                        lim = '0,3' if shape == 'прям' else '0,18'
                        sh = info['share_rect'] if shape == 'прям' else 1 - info['share_rect']
                        sum_line(row, f'   {tc} мм {"прямоугольные" if shape == "прям" else "круглые"} — до {lim} м² ({pct1(FITTING_SMALL_SHARE[ss])})',
                                 f'=ROUND(SUMIFS(M{first}:M{last},I{first}:I{last},"{tc}")*{sh:.6f}*{FITTING_SMALL_SHARE[ss]},3)',
                                 next((t.qty(r) for r, w in blocks_rows[(k, ss)] if parse_kc_fit(t.name(r)) == (shape, tc if tc != '1' else '1', 'small') or parse_kc_fit(t.name(r)) == (shape, '0,8' if tc == '0,8' else tc, 'small')), None)); row += 1
                        sum_line(row, f'   {tc} мм {"прямоугольные" if shape == "прям" else "круглые"} — от {lim} м² ({pct1(1 - FITTING_SMALL_SHARE[ss])})',
                                 f'=ROUND(SUMIFS(M{first}:M{last},I{first}:I{last},"{tc}")*{sh:.6f}*(1-{FITTING_SMALL_SHARE[ss]}),3)',
                                 next((t.qty(r) for r, w in blocks_rows[(k, ss)] if parse_kc_fit(t.name(r)) == (shape, tc, 'big')), None)); row += 1
                row += 1
    for col, w in zip('ABCDEFGHIJKLMNOPQRS', [6, 7, 20, 20, 13, 8, 60, 13, 9, 8, 12, 11, 13, 14, 20, 10, 14, 14, 16]):
        dv.column_dimensions[col].width = w
    dv.freeze_panes = f'A{DH+1}'
    return dv


# =====================================================================================
# 7. Лист «Анализ вент. оборудования»
# =====================================================================================
def build_equipment_sheet(wb, title='Анализ вент. оборудования'):
    es = wb.create_sheet(title)
    es['A1'] = 'Вентиляционное оборудование: спецификация ↔ листы подбора ↔ ТКП (масса, категория расценки, системы в примечании)'
    es['A1'].font = Font(name='Times New Roman', size=14, bold=True)
    heads = ['№', 'Корпус', 'Подсистема', 'Система(ы) по спец.', 'Наименование по спецификации', 'Марка', 'Кол-во', 'Масса 1 ед. по спец., кг', 'Масса по листу подбора, кг', 'Лист подбора (стр. PDF)',
             'Δ массы (подбор − спец.)', 'Расценка КЦ (стр. ТКП)', 'Предел массы по расценке, кг', 'Соответствие расценке по массе', 'Примечание подрядчика', 'Проверка системы по примечанию']
    rows = []
    for i, e in enumerate(EQ_ROWS, start=1):
        spec_m = None
        try:
            spec_m = float(str(e['spec_mass']).replace(',', '.')) if e['spec_mass'] else None
        except ValueError:
            spec_m = None
        com_sys = find_systems(e['comment'])
        spec_sys = [s for s in e['systems'].split(', ') if s]
        if not com_sys:
            syschk = 'ОШИБКА: система в примечании не указана'
        elif set(com_sys) == set(spec_sys):
            syschk = 'Соответствует'
        else:
            syschk = f'ОШИБКА: в примечании {", ".join(com_sys)} / по спец. {", ".join(spec_sys)}'
        r = len(rows) + 4
        rows.append([i, f'К{e["k"]}', SUB_NAME[e['ss']], e['systems'], e['name'], e['mark'], e['qty'], spec_m, e['sel_mass'], e['sel_page'] or 'лист подбора отсутствует',
                     f'=IF(OR(H{r}="",I{r}=""),"",ROUND(I{r}-H{r},1))', f'{e["work"]} (стр. {rep.old2new[e["row"]]})', e['limit'],
                     f'=IF(M{r}="","—",IF(MAX(IF(H{r}="",0,H{r}),IF(I{r}="",0,I{r}))<=M{r},"Соответствует","ОШИБКА: масса превышает предел расценки"))', e['comment'], syschk])
    write_table(es, 3, heads, rows, widths=[5, 7, 18, 16, 60, 30, 7, 11, 11, 12, 11, 44, 10, 22, 50, 34], wrap_cols=(4, 5, 6, 12, 15, 16), num_formats={8: '0.0', 9: '0.0', 11: '0.0'})
    for r in range(4, 4 + len(rows)):
        v = es.cell(r, 16).value
        es.cell(r, 16).fill = FILLS['error'] if str(v).startswith('ОШИБКА') else FILLS['ok']
    return es


# =====================================================================================
# 8. Пояснения, сохранение, финализация
# =====================================================================================
build_summary_local(t.wb, AGG, rep.STATUS, note='ТР2 заменяет листы спецификации по системам ДП8.4.2 и ДП9.4 корпуса 4 (вентиляторы УВОП-6,3 и опоры МОВ-630 вместо УПОР-ВО/ОВО). ТР1 (спецификация на 53 л.) в комплекте не приложено.')
build_duct_sheet_local(t.wb, ITEMS, AGG)
build_equipment_sheet(t.wb)

# ---- ключевые выводы (числа из расчёта)
def _sum_slots(k, ss, pred):
    agg_k = [x for x in AGG if x['korpus'] == k]
    rs = rect_slots(agg_k, ss)
    return round(sum(duct_area(A[i], sh) for key, its in rs.items() if pred(key) for i, sh in its), 3)
lines_ducts = []
for k in (1, 2, 3, 4):
    for ss in ('ОВ', 'ПД'):
        a08 = _sum_slots(k, ss, lambda key: key[0] == '0,8')
        kcA = sum(v for key, v in DUCT_KC[(k, ss)]['rect'].items() if key[0] == '0,8' and key[1] == 'A')
        need = {key: v for key in [('B', 'std'), ('B', 'nonstd'), ('C', 'std'), ('C', 'nonstd')] for v in [_sum_slots(k, ss, lambda kk, key=key: kk[0] == '0,8' and kk[1] == key[0] and kk[2] == key[1])] if v > 0.0005}
        lines_ducts.append(f'К{k} {ss}: прямоугольные 0,8 мм — {fmt(a08, 3)} м² (в КЦ {fmt(kcA, 3)} м² в категории «до 0,78 м²»); по правилу: ' +
                           ', '.join(f'{CAT_SHORT[c]} / {STD_NAME[sd]} — {fmt(v, 3)} м²' for (c, sd), v in need.items()))
unm = {}
for k in (1, 2, 3, 4):
    for ss in ('ОВ', 'ПД'):
        ids = [i for i, h in covered.items() if 'unmatched' in h and A[i]['korpus'] == k and A[i]['ss'] == ss]
        if ids:
            unm[(k, ss)] = ids
fit_lines = []
for (k, ss), fi in sorted(FIT_INFO.items()):
    for tc, info in sorted(fi.items()):
        fit_lines.append(f'К{k} {ss} {tc} мм: спец. {fmt(info["spec_total"], 3)} / КЦ {fmt(info["kc_total"], 3)} м²' + (' ✓' if abs(info['spec_total'] - info['kc_total']) <= TOL else ' — РАСХОЖДЕНИЕ'))
eq_err_sys = sum(1 for e in EQ_ROWS if not find_systems(e['comment']))
NOTES_EXTRA += [
    '• Объёмы воздуховодов, фасонных частей, изоляции, клапанов, решёток, сеток и оборудования по всем четырём корпусам в целом совпадают со спецификацией (ТКП сформировано по тем же длинам/количествам, что и спецификация; итоги по толщинам совпадают до 0,01 м²). Основные замечания — категории воздуховодов и фасонных, номенклатура, системы в примечаниях.',
    '• КАТЕГОРИИ ПРЯМОУГОЛЬНЫХ ВОЗДУХОВОДОВ 0,8 мм: во всех корпусах весь объём 0,8 мм поставлен в категорию «до 0,78 м2» (кратные/некратные 10/30 %), тогда как по правилу (площадь одного изделия при L = 1,25 м) наименьшее сечение 0,8 мм — 500х300 (1,6 × 1,25 = 2,0 м2) — и все остальные сечения относятся к категории «от 0,78 до 4,25 м2» (сечения 900х900 и крупнее — «свыше 4,25 м2»). Требуемые позиции по корпусам:',
] + ['   – ' + l for l in lines_ducts] + [
    '• Воздуховоды 0,9 мм: подрядчик разделил объёмы 10/30 % на позицию «(БИМ) / 0,9 мм» (некратные) и «0,9мм / от 0,78 до 4,25 м2», тогда как позиции < 10 м² не делятся, а сечения 1300х500 (К2), 1500х500 и 1500х850 (ПД всех корпусов), 1450х450/1400х450 (К4 ПД) относятся к категории «свыше 4,25 м2» (позиция в КЦ отсутствует). К4 ПД: 1200х450 (13,2 м²) — «от 0,78 до 4,25» 9,24 / 3,96 м² (30 % некратные).',
    '• Толщины ≤ 0,7 мм (0,5/0,6/0,7) — позиции подрядчика «(БИМ)» без категорий приняты как соответствующие по объёму (номенклатуры класса B в КЦ нет); круглые воздуховоды — ниппель/фланец по правилу d ≤/> 315 во всех корпусах соответствуют (ОВ: Ø100–Ø315 — ниппель; ПД: Ø560–Ø1000 — фланец).',
    '• ФАСОННЫЕ ЧАСТИ: итоги по классам толщины совпадают (' + '; '.join(fit_lines) + '), но весь объём в КЦ поставлен в «до 0,3 м2» / «до 0,18 м2» (1 мм круглые — в «от 0,18 м2»); по правилу требуется разделение 91,5 % / 8,5 % (ОВ) и 90,6 % / 9,4 % (ПД) — расчётные позиции и объёмы даны в строках ТКП и замечаниях к расценкам «соединительные элементы». В состав фасонных ОВ включены тройники 500х300/Ø125, отводы Ø125, ниппели, заглушки и пластины П3 вентмодулей (пластины П3 — подтвердить отнесение к фасонным).',
    '• ОБОРУДОВАНИЕ: системы в примечаниях подрядчика не указаны ни по одной позиции оборудования (' + str(eq_err_sys) + ' строк оборудования по 4 корпусам) — «Прописать системы по всему оборудованию». Массы по листам подбора (Вентзащита, Korf, Русклимат, Аэрдин) и спецификации соответствуют категориям расценок, кроме К4 ДВ2.4: УДАЛ-КРФ-8-Г-6-400 (310 кг по подбору, стр. 396 PDF) поставлен в «Монтаж крышных вентиляторов / до 300 кг» — требуется «до 400 кг» (как в К2/К3). Расхождения масс спец./подбор: УПОР-ВО-8-А-2 — 79 (спец. К2/К3) / 91 кг (подбор); УПОР-КОИ-8-А-2 — 296 / 271 кг; УДАЛ-КРФ (К4) — 207,5 (спец.) / 231,5–310 кг (подбор); К3 ДВ2.3 — в спецификации марка 7.1-В-4-400 при массе 310 кг (вероятно, 8-Г — противоречие спецификации). К1 ДП8.1.2: в спецификации наименование УПОР-ВО-7,1-В-2, марка УПОР-ВО-7,1-Б-2 — противоречие спецификации.',
    '• Установки UTR (Korf): по спецификации одна приточно-вытяжная установка на систему П7/В7 (1 шт, 381–538 кг в сборе), в КЦ разделена на приточный и вытяжной блоки (2 расценки по массе секций) и дополнительно отдельными позициями учтены вентиляторные секции, шумоглушители SGK, фильтры WFUM, гибкие вставки WG и заслонки ZUT/ZR, входящие в состав установки, — проверить на задвоение (расценка установки «в комплекте с … шумоглушителем»). Комплектующие установок без отдельных позиций в КЦ (бактерицидные секции, крыши, стяжки, секции смешения/промежуточные, корпуса фильтров, пустые секции, приводы) отнесены в состав расценок установок.',
    '• НОМЕНКЛАТУРА: «Самоклеящая тепло-звуко изоляция K-flex AL CLAD 13мм» (ОВ, все корпуса) — по спецификации это самоклеящийся покрывной материал (покрывной слой матов ОБМ-ТЕХВЕНТ), не изоляция; маты прошивные — в спецификации ОБМ-ТЕХВЕНТ (ВЗТМ) 20/50 мм, в КЦ БИЗОН 20-1Ф/60-1Ф без примечания, причём мат кашированный фольгой и мат без каширования объединены в одной позиции; сетки D900 — в КЦ ячейка 50х50, по спецификации 20x20; решётки РКДВ 900x500 и 800x450 — по 1 шт в исполнении RAL 7016 (К1); сетка 350х350 — 1 шт БСР 350x350 Арктос (К1, К3).',
    '• Огнезащитный состав вентмодулей (расценка «Покрытие воздуховодов огнезащитным составом / 60 мин»): площадь соответствует спецификации, но масса материала в КЦ (Стабитерм 209, 1,8 кг/м²) не соответствует расходу по проекту: EXPERT FIRE-OM 5 кг/м² + грунт ГФ-021 0,1 кг/м² (К1: 1 341,3 кг против 473,4; К2: 1 111,8 против 392,4; К3: 1 045,5 против 369,0; К4: 1 468,8 против 518,4).',
    '• Обобщённые позиции (разные марки/типоразмеры в одной строке КЦ, количество сходится) — «Добавить разными позициями»: клапаны приточные КИВ (12,5SAV050-01 / 12.5KP KIV060-01 / KIV070-01), заслонки ZUT/ZR, комплекты опор ОВО-5.6/6.3/7.1/8 (+ МОВ-630 в К4), решётки Рс-1500x500 + АМН 800х900, фильтр FRKr + бокс FBRr-K, сетки «свыше 3000 до 5000» двух размеров (К4 ПД).',
    '• НЕ РАЗНЕСЕНО в ТКП: короба под вентилятор SIB 100 S / SIB 125 S (К1 — 4, К2 — 5, К3 — 6, К4 — 4 шт) — добавить. Позиции КЦ, отсутствующие в спецификации: нет. Узел стыковочный УС-1вп (14 шт на объект) — в ТКП 2/4/6/2 шт по корпусам под расценкой «узел прохода» (применительно) — соответствует.',
    '• ТРЕБУЕТ ПОДТВЕРЖДЕНИЯ: крепёж вентмодулей квартир (траверсы 38х40х2, шпильки, болты, гайки, шайбы, анкеры, саморезы, дюбели, хомуты — ' + fmt(sum(A[i]['qty'] for i, h in covered.items() if 'incl-hw' in h and A[i]['unit'] == 'кг'), 0) + ' кг по 4 корпусам) в ТКП отдельно не учтён; принято, что он входит в сопутствующий материал КЦ «Крепежные элементы для воздуховодов». «Детали крепления воздуховодов» (кг) разнесены в расценку «Монтаж металлической рамы» с материалом «Уголок стальной…» — материал заменить на «Металлическая рама для воздуховодов (с огрунтовкой и огнезащитной окраской за 2 раза)».',
    '• ТР1 (спецификация 53 л., подборы 80 л.) не приложено — проверить актуальность спецификации; при получении ТР1 проверку актуализировать.',
]

notes = [
    ('Проверка ТКП № 7883279 (АЛЬФАСТРОЙ ООО) — г. Москва, р-н Гольяново, мкр. 1-2 (Дом, зона 3.1), корпуса 1–4, раздел ОВ2 (вентиляция) — на соответствие спецификации проекта с учётом ТР2', True),
    ('', False),
    ('1. Исходные данные', True),
    ('• ТКП — выгрузка КЦ 7883279 (лист «ТКП»), 5 блоков: «1. Жилое здание» (все расценки нулевые — удалены по п. 1 ТЗ, остались только заголовки разделов), «2–5. Жилой корпус/секция 1–4» (общеобменная и противодымная вентиляция в каждом).', False),
    ('• РД 111-1123-ОК-1/Н-3.1-1-1..4-ОВ2 (429 стр.): спецификация оборудования, изделий и материалов …-ОВ2.СО — 163 листа (стр. 68–230 PDF), разделы IV «Общеобменная вентиляция нежилой части», V «Общеобменная вентиляция жилой части», VI «Противодымная вентиляция», VII «Кондиционирование» (вне ТКП); листы подбора оборудования — стр. 231–429 (Русклимат TUBE/фильтры, Korf UTR, Вентзащита УПОР/УДАЛ, Аэрдин АЭРБЭК).', False),
    ('• ТР2 (111-1123-ОК-1/Н-3.1-1-1..4-ОВ2.ТР2, 13 стр.): спецификация 3 л. — замена вентиляторов и монтажных опор систем ДП8.4.2 и ДП9.4 корпуса 4 (УПОР-ВО-7,1-В-2 + ОВО-7.1 и УПОР-ВО-8-В-2 + ОВО-8 → УВОП-6,3-В-05,50/2-У1/НС1215 (НПП «АЭРВАН», 57 кг) + опора МОВ-630/НС1215); остальные позиции этих систем без изменений. Листы подбора УВОП — стр. 10–13 ТР2. В ТКП ТР2 учтено (УВОП-6,3 — 2 шт, МОВ-630 — 2 шт в блоке корпуса 4).', False),
    ('• ТР1 в комплекте НЕ ПРИЛОЖЕНО. По ведомости ТР2 ТР1 заменяет листы 4, 6, 8, 10 основного комплекта (характеристики систем), спецификацию (53 листа) и листы подбора (80 листов). Проверка выполнена по спецификации основного комплекта (ред. 23.03.2026) + ТР2; расхождения ТКП со спецификацией могут частично объясняться ТР1 — при получении ТР1 проверку необходимо актуализировать.', False),
    ('', False),
    ('2. Методика', True),
    ('• Спецификация извлечена постранично по геометрии таблицы (pdfplumber): столбцы по вертикальным линиям, строки — по линиям столбца «Наименование» (каждая текстовая строка отчёркнута, строки-продолжения склеены с позицией); заголовки (жирный шрифт) «КОРПУС N. Система … <система>» задают корпус и систему; курсивные подзаголовки вентмодулей (ВМ.ОЦ.1.бв / ВМ.ОЦ.1.н / ВМ.ОЦ.1) приняты как «системы» раздела «Вытяжная вентиляция квартир». Позиции агрегированы по (корпус, подсистема, наименование, марка, код, поставщик, ед. изм.).', False),
    ('• Каждый блок ТКП (корпус) сверен со спецификацией своего корпуса. Сопоставление материалов — по маркам в примечании подрядчика (приоритет), по размерам в наименовании (сетки, дефлекторы), по пределу огнестойкости (огнезащита); воздуховоды и фасонные — по правилам раздела 4 ТЗ. Полнота проверена программно: каждая позиция спецификации корпусов 1–4 (ОВ/ПД) либо разнесена в строку ТКП, либо учтена через расчётную/производную позицию, либо учтена в составе, либо вынесена в блок «НЕ разнесённые» внизу раздела.', False),
    ('• Воздуховоды: площадь прямоугольных L×2(a+b), круглых L×πd; категория — по площади одного изделия при L = 1,25 м; некратные 10 % (ОВ) / 30 % (ПД), позиции < 10 м² не делятся; круглые d ≤ 315 — ниппель, d > 315 — фланец, группы по толщине стенки. Для толщин ≤ 0,7 мм (0,5/0,6/0,7) в справочнике КЦ нет номенклатуры класса B — позиции подрядчика «(БИМ) / 0,7 мм» и т.п. приняты как единые группы по толщине (без категорий). Воздуховоды вентмодулей квартир («Воздуховод оцинкованный … 0.8 мм Ø125 / 500х300», п.м.) учтены как воздуховоды 0,8 мм.', False),
    ('• Фасонные части: в спецификации — «Оцинкованная сталь для соединительных деталей воздуховодов» (м², по системам, по толщине 0,7/0,8/1,0 мм; 0,7 отнесена к классу 0,8) без разделения на прямоугольные/круглые; дополнительно для вентмодулей — тройники 500х300/Ø125, отводы Ø125, ниппели, заглушки, пластины П3 (м²) — учтены как фасонные (пластины П3 — требует подтверждения). Распределение прямоугольные/круглые при совпадении итога по классу толщины принято по КЦ; разделение «до/от 0,3 (0,18) м²» — 91,5 % / 90,6 % (правило заказчика от 10.09.2026) — выполнено расчётными позициями.', False),
    ('• Комплекты раскладывались на производные позиции: установки UTR (Korf) — на приточный и вытяжной блоки (масса по подбору Korf KR26-001038/2); фильтр FRKr + фильтр-бокс FBRr-K — комплект; узел стыковочный УС-1вп (14 шт на объект, системы ПУ) — по корпусам 2/4/6/2 шт по числу систем ПУ; огнезащитный состав — пересчёт м² → кг по расходу спецификации (EXPERT FIRE-OM 5 кг/м² + грунт ГФ-021 0,1 кг/м²).', False),
    ('• «Учтено в составе»: комплектующие установок UTR (секции бактерицидные, крыши, стяжки, секции смешения/промежуточные, корпуса фильтров, пустые секции, приводы) — в составе расценок установок (состав требует уточнения); крепёж вентмодулей квартир (траверсы, шпильки, болты, гайки, шайбы, анкеры, саморезы, дюбели, хомуты) — в составе сопутствующего материала КЦ «Крепежные элементы для воздуховодов» (ТРЕБУЕТ ПОДТВЕРЖДЕНИЯ, см. сводную — суммы по кг); шнур базальтовый, скотч алюминиевый, пена противопожарная, проволока вязальная — расходные, в расчёт не заносятся.', False),
    ('• Оборудование: системы должны быть указаны в примечании (иначе ошибка «Прописать системы»); массы — спецификация ↔ листы подбора ↔ категория расценки «до N кг» (лист «Анализ вент. оборудования»). Для вентиляторов квартир ERA 5C системы в проекте не обозначены — проверка систем не применялась.', False),
    ('• Цвета: зелёный — соответствие, жёлтый — требует уточнения, красный — ошибка; несоответствующий элемент выделен красным шрифтом в наименовании спецификации. Столбцы цен J–AP свёрнуты (раскрываются «+»). Нулевые расценки удалены; итоги ТКП сверены с исходником (finalize/verify).', False),
    ('', False),
    ('3. Ключевые выводы', True),
]
for line in NOTES_EXTRA:
    notes.append((line, False))
px = build_notes_sheet(t.wb, notes)
t.wb.move_sheet(px, offset=t.wb.sheetnames.index('ТКП') - t.wb.sheetnames.index('Пояснения'))
rep.save(OUT)
print('saved', OUT)

res = finalize(OUT, orig_path=TKP_XLSX, old2new=rep.old2new, deleted=rep.deleted)
print(json.dumps({'recalc': res['recalc'], 'cached': res['cached_cells'], 'verify': {'checked': res['verify']['checked'], 'n_bad': res['verify']['n_bad'], 'bad': res['verify']['bad'][:5]}}, ensure_ascii=False)[:1500])
