# -*- coding: utf-8 -*-
"""ПРИМЕР (раздел ВК — насосная станция НС, только оборудование с листами подбора; объект Гольяново зона 2.2, ТКП 7878665). Структуру копировать; объектные данные писать заново.
Проверка ТКП 7878665 (АЛЬФАСТРОЙ ООО) — насосные установки ХВС и ВПВ (раздел ВК, насосная станция НС),
г. Москва, Гольяново, мкр. 1-2, зона 2.2 — по спецификации 111-1123-ОК-1/Н-2.2-1-1..4-НС.СО и листам подбора Antarus.
Запуск: python3 spec_ns.py → python3 run_check_ns.py"""
import json, re, sys, math
sys.path.insert(0, '/home/claude/work')
from tkp_toolkit import *
from openpyxl.formatting.rule import FormulaRule
from openpyxl.utils import get_column_letter, column_index_from_string
from openpyxl.cell.rich_text import CellRichText, TextBlock

WORK = '/home/claude/work'
TKP_XLSX = f'{WORK}/in/tkp.xlsx'
OUT = '/mnt/user-data/outputs/Проверка_ТКП_7878665_НС_насосные_установки_Гольяново_зона_2.2_по_спецификации.xlsx'

agg = json.load(open(f'{WORK}/spec_agg.json'))
items = json.load(open(f'{WORK}/spec_items.json'))
DS = json.load(open(f'{WORK}/datasheets.json'))
A = {x['id']: x for x in agg}
SUB_NAME_NS = {'В1': 'Система хозяйственно-питьевого водоснабжения — насосные установки ХВС (В1(1), В1(2))',
               'В2': 'Система внутреннего противопожарного водопровода — насосные установки пожаротушения (ВПВ, запитаны от В1(1), В1(2))'}
BY = {x['posno']: x['id'] for x in agg}          # поз. спец. → id
P = lambda posno: BY[posno]

# ---------- ТКП
t = Tkp(TKP_XLSX)
rep = Report(t, agg, items)
zero = t.zero_rate_rows()
rep.delete_rows(zero)
print('нулевые расценки:', zero)
assert t.works() == [15, 19], t.works()

M = rep.map
# работа 15 «Монтаж насосной установки» (ХВС) — материал стр. 16: две разные установки в одной позиции
M(16, [P('2.7'), P('2.8')], kind='match', st='error',
  hl={P('2.7'): [r'ANTARUS 3 MLV8-5/01'], P('2.8'): [r'ANTARUS 3 MLV8-7/01']},
  note='Разные типоразмеры в одной позиции: ANTARUS 3 MLV8-5/01 (ХВС 1 зоны, 3,0 кВт, арт. 300856) — 1; ANTARUS 3 MLV8-7/01 (ХВС 2 зоны, 4,0 кВт, арт. 378334) — 1. '
       'Марки, зоны, G/H/N, схема 2 раб + 1 рез и поставщик по примечанию соответствуют поз. 2.7, 2.8; ед. изм. КЦ «комплект» = «шт.» спец. (установка в сборе со шкафом управления).')
# работа 19 «Монтаж насосной установки» (ВПВ) — материал стр. 20
M(20, [P('2.5'), P('2.6')], kind='match', st='error',
  hl={P('2.5'): [r'ANTARUS 2 MLV32-4/01/D'], P('2.6'): [r'ANTARUS 2 MLV32-6/01/D']},
  note='Разные типоразмеры в одной позиции: ANTARUS 2 MLV32-4/01/D (пожаротушение 1 зоны, 11,0 кВт, арт. 275500) — 1; ANTARUS 2 MLV32-6/01/D (пожаротушение 2 зоны, 15,0 кВт, арт. 372227) — 1. '
       'Марки, зоны, G/H/N, схема 1 раб + 1 рез и поставщик по примечанию соответствуют поз. 2.5, 2.6; ед. изм. КЦ «комплект» = «шт.» спец. (установка в сборе со шкафом управления Амперус).')

# блоки неразнесённых — внизу каждого раздела (неразнесённых нет: все 4 позиции НС.СО сопоставлены)
rep.unmatched_block(16, 'Материалы спецификации НС.СО, НЕ разнесённые в ТКП — Система хозяйственно-питьевого водоснабжения (насосные установки ХВС)', [])
rep.unmatched_block(20, 'Материалы спецификации НС.СО, НЕ разнесённые в ТКП — Система внутреннего противопожарного водопровода (насосные установки пожаротушения)', [])

# замечания (директивы подрядчику)
R = rep.remark
R(16, 'Добавить разными позициями: Насосная установка ХВС 1 зоны ANTARUS 3 MLV8-5/01 (поз. 2.7, арт. 300856, 2 раб + 1 рез, 3×3,0 кВт) — 1 компл.; '
      'Насосная установка ХВС 2 зоны ANTARUS 3 MLV8-7/01 (поз. 2.8, арт. 378334, 2 раб + 1 рез, 3×4,0 кВт) — 1 компл. '
      'В примечании указать артикул и исполнение по листу подбора (ОПЦ ПИК25 Реновация, DN65, бак 24/16; тех. запрос №42 405 от 20.10.2025)')
R(20, 'Добавить разными позициями: Насосная установка пожаротушения 1 зоны ANTARUS 2 MLV32-4/01/D (поз. 2.5, арт. 275500, 1 раб + 1 рез, 2×11,0 кВт) — 1 компл.; '
      'Насосная установка пожаротушения 2 зоны ANTARUS 2 MLV32-6/01/D (поз. 2.6, арт. 372227, 1 раб + 1 рез, 2×15,0 кВт) — 1 компл. '
      'В примечании указать артикул и исполнение по листу подбора (ОПЦ ПИК25 Реновация; тех. запросы №42 405 от 20.10.2025 и №43 050 от 22.10.2025)')

# ---------- проверка полноты сопоставления (каждая строка ТКП обработана, каждая позиция спец. — ровно один раз)
mats = [r for r in range(t.data_start, t.max_row + 1) if t.is_material(r) and r not in rep.deleted]
missing = [r for r in mats if r not in rep.MAP]
assert not missing, f'Не сопоставлены строки ТКП: {missing}'
used = {}
for r, d in rep.MAP.items():
    for i in d['ids']:
        used.setdefault(i, []).append(r)
for _, _, ids in rep.BLOCKS:
    for i in ids:
        used.setdefault(i, []).append('block')
for i in rep.INCLUDED:
    used.setdefault(i, []).append('incl')
dup = {i: v for i, v in used.items() if len(v) > 1}
assert not dup, f'Задвоение: {dup}'
lost = [x['id'] for x in agg if x['id'] not in used]
assert not lost, f'Потеряны позиции спецификации: {lost}'
print('Строк материалов ТКП:', len(mats), '| позиций спец.:', len(agg), '| сопоставлено:', len(used))

# =====================================================================================
# Сборка листа ТКП
# =====================================================================================
ws = rep.build(name_col_width=80, chk_col_width=52, remark_col_width=75)
C = rep.cols
old2new, plan, row_of = rep.old2new, rep.plan, rep.row_of
NEW = lambda r: old2new[r]


def style_work(row, fill):
    for col in (C['name'], C['unit'], C['qty'], C['chk']):
        c = ws[f'{col}{row}']; c.border = BORDER; c.font = F_BOLD; c.fill = fill
        c.alignment = AL_CENTER if col in (C['unit'], C['qty']) else AL_WRAP


def qty_cells(w_, kinds=('match',)):
    cells = []
    nw = NEW(w_)
    for idx in range(nw + 1, len(plan) + 1):
        e = plan[idx - 1]
        if e[0] == 'orig':
            rr = e[1]
            if t.code(rr):
                break
            d = rep.MAP.get(rr)
            if d and d['ids'] and d['kind'] in kinds:
                cells.append(f"{C['qty']}{idx}")
        elif e[0] == 'extra':
            d = rep.MAP.get(e[1])
            if d and d['kind'] in kinds:
                cells.append(f"{C['qty']}{idx}")
        elif e[0] in ('bhdr', 'bitem', 'bnone', 'virtual'):
            break
    return cells


# строки работ: объём работы = Σ насосных установок по спецификации (формулой), результат — формулой
WORK_RES = {}
for w_ in t.works():
    if w_ in rep.deleted:
        continue
    nw = NEW(w_); unit = t.unit(w_); kq = round(t.qty(w_), 3)
    cells = qty_cells(w_)
    assert cells, w_
    formula = '=ROUND(SUM(' + ','.join(cells) + '),3)'
    ws[f"{C['name']}{nw}"] = 'Объём работы по спецификации (Σ насосных установок по спец. — поз. ' + ', '.join(A[i]['posno'] for rr in t.children(w_) for i in rep.MAP[rr]['ids']) + ')'
    ws[f"{C['unit']}{nw}"] = unit
    ws[f"{C['qty']}{nw}"] = formula
    ws[f"{C['qty']}{nw}"].number_format = '#,##0'
    q = f'{C["qty"]}{nw}'
    ws[f"{C['chk']}{nw}"] = f'=IF(ABS({q}-{kq})<=0.05,"Соответствует: спец. "&ROUND({q},2)&" / КЦ {kq:g}","РАСХОЖДЕНИЕ: спец. "&ROUND({q},2)&" / КЦ {kq:g}, Δ "&ROUND({q}-{kq},2))'
    exp_ = sum(A[i]['qty'] for rr in t.children(w_) for i in rep.MAP[rr]['ids'])
    style_work(nw, FILLS['ok'] if abs(exp_ - kq) <= 0.05 else FILLS['error'])
    ws.conditional_formatting.add(f"{C['name']}{nw}:{C['chk']}{nw}", FormulaRule(formula=[f'LEFT(${C["chk"]}{nw},4)="РАСХ"'], fill=FILLS['error']))
    WORK_RES[w_] = (nw, exp_, kq)
    print(f'работа {w_} → стр. {nw}: КЦ {kq} / спец. {exp_}')

# краткие тексты результатов (правила ВК, п. 4)
for rr in range(t.data_start, ws.max_row + 1):
    c = ws[f"{C['chk']}{rr}"]
    if isinstance(c.value, str) and not c.value.startswith('='):
        v = re.sub(r'Количество соответствует: Σ по спец\. ([\d\s,]+?) = КЦ [\d\s,]+ \((\d+) поз\. спец\.\)', r'Кол-во \1 ✓ (\2 поз.)', c.value)
        v = v.replace('Соответствует. ОШИБКА номенклатуры: ', 'ОШИБКА номенклатуры: ').replace('Соответствует. ', '✓ ')
        v = re.sub(r'Кол-во (\d+),00 ✓', r'Кол-во \1 ✓', v)
        v = re.sub(r'\s{2,}', ' ', v)
        c.value = v
# подпись блока источника в AQ: «системы» → «система»; ед. изм. спец. «шт»
for rr in range(t.data_start, ws.max_row + 1):
    c = ws[f"{C['name']}{rr}"]
    if isinstance(c.value, str):
        c.value = c.value.replace('[системы: ', '[система: ')
    elif isinstance(c.value, CellRichText):
        parts = []
        for pt in c.value:
            if isinstance(pt, TextBlock):
                parts.append(TextBlock(pt.font, pt.text.replace('[системы: ', '[система: ')))
            else:
                parts.append(pt.replace('[системы: ', '[система: '))
        c.value = CellRichText(parts)
    u = ws[f"{C['unit']}{rr}"].value; cq = ws[f"{C['qty']}{rr}"]
    if u in ('шт', 'шт.', 'комплект'):
        cq.number_format = '#,##0'

# заголовок столбца AQ — под данный объект (ТР нет)
ws[f"{C['name']}{t.header_rows[0]}"].value = 'Спецификация 111-1123-ОК-1/Н-2.2-1-1..4-НС.СО: наименование и характеристика / тип, марка / поставщик. Красным шрифтом — элемент, не соответствующий КЦ'
# высоты строк под длинные тексты — только строки с данными проверки (исходные высоты остальных строк не меняем)
for rr in range(t.data_start, ws.max_row + 1):
    if all(ws[f"{C[k]}{rr}"].value in (None, '') for k in ('name', 'chk', 'rem')):
        continue
    # (текст, ширина столбца, коэффициент ширины символа, высота строки текста, pt): столбцы C/E исходника — Times New Roman 14
    texts = [(ws[f"{C['name']}{rr}"].value, 80, 1.05, 15.5), (ws[f"{C['chk']}{rr}"].value, 52, 1.05, 15.5), (ws[f"{C['rem']}{rr}"].value, 75, 1.25, 18.5),
             (ws.cell(rr, 3).value, 55, 1.2, 18.5), (ws.cell(rr, 5).value, 38, 1.25, 18.5)]
    need = 19.5
    for v, w, k, lh in texts:
        if v is None:
            continue
        txt = v if isinstance(v, str) else ''.join(getattr(pt, 'text', pt) for pt in v) if isinstance(v, CellRichText) else str(v)
        if txt.startswith('='):
            continue
        lines = sum(max(1, math.ceil(len(part) * k / w)) for part in txt.split('\n'))
        need = max(need, lines * lh + 4)
    need = min(need, 300)
    cur = ws.row_dimensions[rr].height
    if cur is None or cur < need:
        ws.row_dimensions[rr].height = need

# =====================================================================================
# Лист «Анализ насосного оборудования»: спецификация ↔ лист подбора ↔ ТКП
# =====================================================================================
eq = t.wb.create_sheet('Анализ насосного оборудования')
eq['A1'] = 'Насосные установки по спецификации НС.СО ↔ листы подбора Antarus (ЭЛИТА-Центр) ↔ ТКП: марки, параметры, состав, масса, примечание подрядчика'
eq['A1'].font = Font(name='Times New Roman', size=14, bold=True)
eq['A2'] = ('Листы подбора — стр. 8–73 PDF (66 л.): параметры установки (запрошенные/фактические), данные электродвигателя, вес и подключение, состав поставки, '
            'техническая документация на шкаф управления АМПЕРУС. Δ — формулами (лист подбора − спецификация). Шкаф управления входит в состав установки (п. 10 состава поставки) — отдельной позиции в ТКП не требуется.')
eq['A2'].font = F_NOTE; eq['A2'].alignment = Alignment(wrap_text=True, vertical='top'); eq.merge_cells('A2:AB2'); eq.row_dimensions[2].height = 48
HEAD = ['№', 'Поз. спец.', 'Система (зона)', 'Наименование по спецификации', 'Марка по спец.', 'Схема по спец. (раб + рез)', 'G спец., м³/ч', 'H спец., м', 'N эл.дв. спец., кВт', 'Кол-во спец., шт',
        'Лист подбора: артикул', 'G запрош. / факт., м³/ч', 'H запрош. / факт., м', 'N эл.дв. (одного), кВт', 'Насосов в составе (осн. + рез.)', 'Вес установки по листу подбора, кг', 'Подключение',
        'Шкаф управления (серия; вводной автомат; масса)', 'Стр. PDF (параметры / состав / шкаф)',
        'ТКП стр.', 'Материал КЦ', 'Кол-во в позиции КЦ', 'Примечание подрядчика',
        'ΔG (запрош. − спец.)', 'ΔH (запрош. − спец.)', 'ΔN (подбор − спец.)', 'Марка указана в примечании', 'Результат']
for col, w in zip([get_column_letter(i) for i in range(1, 29)], [5, 8, 12, 34, 24, 12, 10, 10, 10, 9, 12, 14, 14, 11, 13, 14, 11, 34, 14, 8, 30, 10, 60, 10, 10, 10, 12, 60]):
    eq.column_dimensions[col].width = w
for j, h in enumerate(HEAD, start=1):
    c = eq.cell(3, j, h); c.font = F_BOLD; c.fill = FILLS['hdr']; c.border = BORDER; c.alignment = AL_CENTER
eq.row_dimensions[3].height = 62
r = 4; n = 0
EQ_ROWS = {}
for posno, kr in (('2.7', 16), ('2.8', 16), ('2.5', 20), ('2.6', 20)):
    x = A[P(posno)]; d = DS[x['type']]; n += 1
    other = [A[i] for i in rep.MAP[kr]['ids'] if i != x['id']][0]
    comp_pumps = sum(q for _, nm, q in d['composition'] if 'насос' in nm.lower())
    res = (f'Марка, зона, G/H/N, схема {x["n_work"]} раб + {x["n_res"]} рез и кол-во по примечанию соответствуют спецификации и листу подбора. '
           f'ОШИБКА: объединена в одну позицию КЦ (стр. {NEW(kr)}, 2 компл.) с {other["type"]} — добавить разными позициями')
    weight_note = '' if d['weight'] > 10 else ' (в листе подбора указано 2 кг — опечатка; масса в документации не приведена, уточнить у поставщика)'
    cab = d['cabinet']
    vals = [n, posno, x['systems'][0] + f' ({x["kind"]} {x["zone"]} зона)', x['short'] + '; ' + x['char'], x['type'], f'{x["n_work"]} + {x["n_res"]}', x['G'], x['H'], x['N'], x['qty'],
            d['article'] + ' (' + d['title'].split(d['mark'])[-1].strip(' ()') + ')', f'{fmt(d["G_req"])} / {fmt(d["G_act"])}', f'{fmt(d["H_req"])} / {fmt(d["H_act"])}', d['P_motor'],
            f'{comp_pumps} ({[q for _, nm, q in d["composition"] if "Основной" in nm][0]} + {[q for _, nm, q in d["composition"] if "Резервный" in nm][0]})',
            (d['weight'] if d['weight'] > 10 else None), d['DN'], f'{cab["series"]}; вводной автомат {cab["I_in"]}; {cab["n_pumps"]} насоса; масса до {cab["mass"]}; {cab["ip"]}',
            f'{d["page_params"]} / {d["page_composition"]} / {cab["page"]}',
            NEW(kr), t.name(kr), t.qty(kr), t.comment(kr),
            f'=ROUND({d["G_req"]}-G{r},2)', f'=ROUND({d["H_req"]}-H{r},2)', f'=ROUND(N{r}-I{r},2)', f'=IF(ISNUMBER(SEARCH(E{r},W{r})),"да","НЕТ")', res + weight_note]
    for j, v in enumerate(vals, start=1):
        c = eq.cell(r, j, v); c.font = F_DATA; c.border = BORDER; c.alignment = AL_WRAP if j in (4, 5, 11, 18, 21, 23, 28) else AL_CENTER
        if j in (7, 8, 9, 14, 24, 25, 26):
            c.number_format = '0.00'
    if d['weight'] <= 10:
        eq.cell(r, 16, 'опечатка в листе подбора (2 кг)').fill = FILLS['unsure']
    eq.cell(r, 28).fill = FILLS['error']
    for col in ('X', 'Y', 'Z'):
        eq.conditional_formatting.add(f'{col}{r}', FormulaRule(formula=[f'ABS({col}{r})<=0.05'], fill=FILLS['ok']))
        eq.conditional_formatting.add(f'{col}{r}', FormulaRule(formula=[f'ABS({col}{r})>0.05'], fill=FILLS['error']))
    eq.conditional_formatting.add(f'AA{r}', FormulaRule(formula=[f'AA{r}="да"'], fill=FILLS['ok']))
    eq.conditional_formatting.add(f'AA{r}', FormulaRule(formula=[f'AA{r}="НЕТ"'], fill=FILLS['error']))
    eq.row_dimensions[r].height = 120
    EQ_ROWS[posno] = r
    r += 1
eq.freeze_panes = 'E4'; eq.auto_filter.ref = f'A3:AB{r - 1}'
# состав поставки по листам подбора
r += 1
c = eq.cell(r, 1, 'Состав поставки насосных установок по листам подбора (шкаф управления, арматура, коллекторы — в комплекте установки; в ТКП отдельно не выделяются)')
c.font = Font(name='Times New Roman', size=13, bold=True); eq.merge_cells(start_row=r, start_column=1, end_row=r, end_column=12)
for j in range(1, 13):
    eq.cell(r, j).fill = FILLS['block']; eq.cell(r, j).border = BORDER
r += 1
# раскладка по столбцам основной таблицы: A №, B поз., C артикул, D марка, E № п/п, F:I наименование (объединение), J кол-во, K ед., L стр. PDF
COMP_COLS = [1, 2, 3, 4, 5, 6, 10, 11, 12]
heads2 = ['№', 'Поз. спец.', 'Артикул', 'Марка', '№ п/п', 'Наименование по листу подбора', 'Кол-во', 'Ед. изм.', 'Стр. PDF']
for j, h in zip(COMP_COLS, heads2):
    c = eq.cell(r, j, h); c.font = F_BOLD; c.fill = FILLS['hdr']; c.border = BORDER; c.alignment = AL_CENTER
eq.merge_cells(start_row=r, start_column=6, end_row=r, end_column=9)
for j in range(7, 10):
    eq.cell(r, j).fill = FILLS['hdr']; eq.cell(r, j).border = BORDER
r += 1; k = 0
for posno in ('2.7', '2.8', '2.5', '2.6'):
    x = A[P(posno)]; d = DS[x['type']]
    for n_, nm, q in d['composition']:
        k += 1
        vals = [k, posno, d['article'], x['type'], n_, nm, q, 'шт.', d['page_composition']]
        for j, v in zip(COMP_COLS, vals):
            c = eq.cell(r, j, v); c.font = F_DATA; c.border = BORDER; c.alignment = AL_WRAP if j == 6 else AL_CENTER
        eq.merge_cells(start_row=r, start_column=6, end_row=r, end_column=9)
        for j in range(7, 10):
            eq.cell(r, j).border = BORDER
        if 'Шкаф' in nm:
            eq.cell(r, 6).fill = FILLS['ok']
        r += 1

# =====================================================================================
# Сводная по спецификации (НС.СО)
# =====================================================================================
def build_summary_ns(wb, agg, status, title='Сводная по спецификации'):
    sv = wb.create_sheet(title)
    sv['A1'] = 'Сводная спецификация 111-1123-ОК-1/Н-2.2-1-1..4-НС.СО (лист 1 из 1, стр. 7 PDF) в разрезе разделов ТКП. Все позиции — насосные установки; трубопроводы и арматура обвязки — в томе …-ТМ (не приложен).'
    sv['A1'].font = Font(name='Times New Roman', size=14, bold=True)
    for c, h in zip('ABCDE', ['Раздел ТКП', 'Позиций', 'Разнесено / учтено', 'Не разнесено', 'С ошибкой']):
        sv[f'{c}3'] = h; sv[f'{c}3'].font = F_BOLD; sv[f'{c}3'].fill = FILLS['hdr']; sv[f'{c}3'].border = BORDER; sv[f'{c}3'].alignment = AL_CENTER
    HDR = 8
    heads = ['№', 'Раздел ТКП', 'Поз. спец.', 'Система', 'Наименование и техническая характеристика', 'Тип, марка', 'Поставщик', 'Ед. изм.', 'Кол-во', 'Масса 1 ед. по спец., кг',
             'Масса по листу подбора, кг', 'Лист спец.', 'Примечание спец.', 'Статус в ТКП']
    for j, h in enumerate(heads, start=1):
        c = sv.cell(HDR, j, h); c.font = F_BOLD; c.fill = FILLS['hdr']; c.border = BORDER; c.alignment = AL_CENTER
    row, n = HDR + 1, 0
    SS = ['В1', 'В2']
    for ss in SS:
        c = sv.cell(row, 1, SUB_NAME_NS[ss]); c.font = Font(name='Times New Roman', size=13, bold=True)
        sv.merge_cells(start_row=row, start_column=1, end_row=row, end_column=14)
        for j in range(1, 15):
            sv.cell(row, j).fill = FILLS['block']; sv.cell(row, j).border = BORDER
        row += 1
        for x in sorted([x for x in agg if x['ss'] == ss], key=lambda x: x['posno']):
            n += 1
            st = status.get(x['id'], 'НЕ разнесено')
            d = DS[x['type']]
            vals = [n, SUB_NAME_NS[ss], x['posno'], x['systems'][0], x['name'], x['type'], x['supplier'], x['unit'], x['qty'], None,
                    (d['weight'] if d['weight'] > 10 else 'опечатка в листе подбора (2 кг)'), x['sheets'][0], x['note'], st]
            for j, v in enumerate(vals, start=1):
                c = sv.cell(row, j, v); c.font = F_DATA; c.border = BORDER
                c.alignment = AL_WRAP if j in (2, 5, 6, 13, 14) else AL_CENTER
                if j == 9:
                    c.number_format = '#,##0'
            if 'НЕ разнесено' in st or 'ОШИБКА' in st:
                sv.cell(row, 14).fill = FILLS['error']
            elif 'уточнения' in st:
                sv.cell(row, 14).fill = FILLS['unsure']
            elif st.startswith('Разнесено') or st.startswith('Учтено'):
                sv.cell(row, 14).fill = FILLS['ok']
            row += 1
    LAST = row - 1
    for i, ss in enumerate(SS):
        rr = 4 + i
        sv[f'A{rr}'] = SUB_NAME_NS[ss]
        sv[f'B{rr}'] = f'=COUNTIFS($B${HDR+1}:$B${LAST},A{rr})'
        sv[f'C{rr}'] = f'=COUNTIFS($B${HDR+1}:$B${LAST},A{rr},$N${HDR+1}:$N${LAST},"Разнесено*")+COUNTIFS($B${HDR+1}:$B${LAST},A{rr},$N${HDR+1}:$N${LAST},"Учтено*")'
        sv[f'D{rr}'] = f'=B{rr}-C{rr}'
        sv[f'E{rr}'] = f'=COUNTIFS($B${HDR+1}:$B${LAST},A{rr},$N${HDR+1}:$N${LAST},"*ОШИБКА*")+COUNTIFS($B${HDR+1}:$B${LAST},A{rr},$N${HDR+1}:$N${LAST},"НЕ разнесено*")'
        for c in 'ABCDE':
            sv[f'{c}{rr}'].font = F_DATA; sv[f'{c}{rr}'].border = BORDER; sv[f'{c}{rr}'].alignment = AL_WRAP if c == 'A' else AL_CENTER
    sv['A6'] = 'Итого'
    for c in 'BCDE':
        sv[f'{c}6'] = f'=SUM({c}4:{c}5)'
    for c in 'ABCDE':
        sv[f'{c}6'].font = F_BOLD; sv[f'{c}6'].border = BORDER; sv[f'{c}6'].alignment = AL_CENTER
    for col, w in zip('ABCDEFGHIJKLMN', [44, 34, 9, 10, 62, 26, 12, 8, 9, 12, 14, 9, 14, 52]):
        sv.column_dimensions[col].width = w
    sv.freeze_panes = f'A{HDR+1}'; sv.auto_filter.ref = f'A{HDR}:N{LAST}'
    return sv


build_summary_ns(t.wb, agg, rep.STATUS)

# =====================================================================================
# Пояснения
# =====================================================================================
w15, w19 = NEW(15), NEW(19)
notes = [
 ('Проверка ТКП 7878665 (АЛЬФАСТРОЙ ООО) — насосные установки хозяйственно-питьевого и противопожарного водоснабжения (раздел ВК, насосная станция), '
  'г. Москва, р-н Гольяново, мкр. 1-2, зона 2.2 — по спецификации 111-1123-ОК-1/Н-2.2-1-1..4-НС.СО и листам подбора', True),
 ('Исходные данные', True),
 ('• ТКП 7878665 (выгрузка КЦ, estimateVersionId 7878665): в файле только лист «ТКП» (листов «Изменения» и «ТКП с формулами» в выгрузке нет); структура стандартная (код ИСР в B, примечание подрядчика в E, ед. изм. в F, объём в I; ценовые столбцы J–AP, служебные V–AI скрыты). '
  'Состав: раздел «Водоснабжение и канализация» → «Система хозяйственно-питьевого водоснабжения» (расценка 6.2.3.1.5.3.3.1 «Монтаж насосной установки (стоимость СМР 10% от стоимости оборудования)» — 2 шт, материал «Насосная установка (по счету от поставщика) / Другое» — 2 компл.) '
  'и «Система внутреннего противопожарного водопровода и система автоматического пожаротушения» (расценка 6.2.3.1.6.4.2.1 — 2 шт, материал — 2 компл.). Цены ПСПР и подрядчика в выгрузке не заполнены (0), стоимость СМР — 10 % от стоимости оборудования; проверка выполнена по объёмам и номенклатуре.', False),
 ('• РД 111-1123-ОК-1/Н-2.2-1-1..4-НС «Насосная станция хозяйственно-питьевого и противопожарного водоснабжения» (ООО «Перспектива», 22.12.2025; 73 стр.): общие данные и характеристики установок систем ВК — стр. 4; принципиальная схема насосных станций — стр. 5; план расстановки в ИТП — стр. 6; '
  'спецификация оборудования, изделий и материалов НС.СО — стр. 7 (лист 1 из 1, раздел «2. Насосы», поз. 2.5–2.8; поз. 2.1–2.4 в данном томе отсутствуют — нумерация общая с томом …-ТМ); листы подбора насосных станций (ЭЛИТА-Центр / Antarus) — стр. 8–73 (66 л.). '
  'Примечание спецификации: схемы обвязки, аксонометрические схемы, разрезы и объём материалов насосных станций учтены в томе 111-1123-ОК-1/Н-2.2-1-1..4-ТМ — том не приложен, обвязка в данной проверке не проверялась (в ТКП подрядчик также ссылается на том ТМ).', False),
 ('• Технические решения (ТР) не приложены. Каталог Halifax (база знаний) для данного раздела не требуется — чугунных трубопроводов в спецификации нет.', False),
 ('Методика', True),
 ('• Раздел — оборудование ВК (насосные установки), поэтому применены общие требования ТЗ (структура отчёта, столбцы AQ–AT/AV, цвета) и правила ВК в части оборудования: нулевые расценки — удалить (нулевых расценок нет: объёмы работ 2 и 2); объём работы «Монтаж насосной установки» = Σ установок по спецификации (формулой); '
  'примечание подрядчика — приоритет (марки, зоны, параметры); объединение разных типоразмеров в одной позиции — ошибка «Добавить разными позициями», даже если оговорено в примечании и количество сходится. Листы «Чугун SML» и «Комплексные трубопроводы» не формируются — трубопроводов в спецификации НС.СО нет.', False),
 ('• Спецификация извлечена по геометрии таблицы (pdfplumber): 4 позиции (2.5–2.8), у каждой — строка характеристики (G, H, N, 380 V) и примечание о схеме (1 раб + 1 рез / 2 раб + 1 рез). Системы приняты по таблице «Характеристики установок систем ВК» общих данных: 1 зона — В1(1), 2 зона — В1(2); '
  'В1 — объединённый хозяйственно-питьевой/противопожарный водопровод (установки пожаротушения запитаны от В1(1)/В1(2)); в ТКП установки пожаротушения отнесены к разделу противопожарного водопровода — соответствует назначению.', False),
 ('• Каждая строка материала ТКП сопоставлена явно (столбцы AQ–AT): позиции спецификации (вторая позиция под одной строкой КЦ — дополнительной серой строкой ниже), ед. изм., кол-во, результат. Несоответствующий элемент выделен красным шрифтом в AQ. Столбец AV — замечания подрядчику. Ценовые столбцы J–AP свёрнуты в группу (кнопка «+»), служебные V–AI скрыты, закрепление J8 и автофильтр сохранены.', False),
 ('• Листы подбора сверены со спецификацией и примечанием подрядчика (лист «Анализ насосного оборудования»): марка, артикул, запрошенные/фактические G и H, мощность электродвигателя, количество насосов (основные + резервный), вес, подключение DN, шкаф управления АМПЕРУС (в составе поставки, п. 10). Δ — формулами.', False),
 ('Результаты сверки с листами подбора', True),
 ('• Поз. 2.7 ХВС 1 зоны ANTARUS 3 MLV8-5/01 (арт. 300856, ОПЦ ПИК25 Реновация, DN65, бак 24/16): G 20,92 м³/ч, H 69,2 м, 3 насоса (2+1) × 3 кВт, вес 369 кг, DN65, шкаф АМПЕРУС НГР-КПЧ (ПЧ на каждый насос, вводной автомат 40 А) — соответствует спецификации и примечанию подрядчика (стр. 10–23 PDF).', False),
 ('• Поз. 2.8 ХВС 2 зоны ANTARUS 3 MLV8-7/01 (арт. 378334, DN65, бак 24/16): G 18,97 м³/ч, H 110,69 м, 3 насоса (2+1) × 4 кВт, DN65, шкаф НГР-КПЧ (63 А) — соответствует. В листе подбора указан вес «2 кг» — явная опечатка; масса установки в документации фактически не приведена (уточнить у поставщика; ориентир — установка MLV8-5/01 тех же габаритов 369 кг).', False),
 ('• Поз. 2.5 пожаротушение 1 зоны ANTARUS 2 MLV32-4/01/D (арт. 275500): запрошено G 31,39 / H 71,48, фактически 32,4 / 76,3; 2 насоса (1+1) × 11 кВт, вес 681 кг, DN65, шкаф АМПЕРУС НГР-ПЖ (32 А) — соответствует. Поз. 2.6 пожаротушение 2 зоны ANTARUS 2 MLV32-6/01/D (арт. 372227, тех. запрос №43 050 от 22.10.2025): запрошено 30,38 / 112,97, фактически 30,9 / 116,8; 2 насоса × 15 кВт, вес 822 кг, шкаф НГР-ПЖ (40 А) — соответствует.', False),
 ('• В общих данных (стр. 4) расход установки ХВС 1 зоны указан 20,91 м³/ч против 20,92 в спецификации и листе подбора — расхождение в округлении, на проверку не влияет.', False),
 ('Легенда', True),
 ('• Зелёный — соответствует; жёлтый — уточнить; красный — ошибка (номенклатура, объём, отсутствие позиции). Красным шрифтом в столбце AQ выделен элемент спецификации, из-за которого позиция КЦ ошибочна (здесь — разные марки установок под одной строкой КЦ). '
  'Внизу каждого раздела — блок позиций спецификации, не разнесённых в ТКП (неразнесённых нет).', False),
 ('• Листы: «ТКП» (проверка построчно), «Анализ насосного оборудования» (спецификация ↔ листы подбора ↔ ТКП, состав поставки), «Сводная по спецификации» (статус каждой позиции).', False),
 ('Ключевые выводы', True),
 (f'1. Все 4 позиции спецификации НС.СО разнесены в ТКП; количество сходится: ХВС — 2 установки (поз. 2.7, 2.8) = КЦ 2 (стр. {w15}–{NEW(16)}); пожаротушение — 2 установки (поз. 2.5, 2.6) = КЦ 2 (стр. {w19}–{NEW(20)}). Объёмы работ «Монтаж насосной установки» (2 + 2 шт) соответствуют. Марки, зоны, G/H/N, схемы резервирования и поставщик Antarus в примечаниях подрядчика соответствуют спецификации и листам подбора.', False),
 (f'2. ОШИБКА номенклатуры (2 позиции): в каждой строке материала КЦ объединены две разные установки — стр. {NEW(16)}: ANTARUS 3 MLV8-5/01 (3 кВт) + ANTARUS 3 MLV8-7/01 (4 кВт); стр. {NEW(20)}: ANTARUS 2 MLV32-4/01/D (11 кВт) + ANTARUS 2 MLV32-6/01/D (15 кВт). '
  'Разные типоразмеры с разной стоимостью нельзя объединять в одну позицию «по счёту от поставщика» — добавить разными позициями (по 1 компл.), в примечании указать артикул и исполнение по листу подбора (ОПЦ ПИК25 Реновация; тех. запросы №42 405 / №43 050).', False),
 ('3. Расхождений по объёму нет; позиций КЦ, отсутствующих в спецификации, нет; неразнесённых позиций спецификации нет. Нулевые расценки отсутствуют; структура и итоги исходного ТКП сохранены (итоговые суммы равны 0 — цены в выгрузке не заполнены).', False),
 ('4. Вне проверки: обвязка насосных станций (трубопроводы, арматура, КИП, опоры) — том 111-1123-ОК-1/Н-2.2-1-1..4-ТМ не приложен; при его получении требуется отдельная проверка соответствующих расценок ТКП (в данном ТКП позиций обвязки нет).', False),
 ('5. Уточнить у проектировщика/поставщика: массу установки ANTARUS 3 MLV8-7/01 (в листе подбора опечатка «2 кг»).', False),
]
px = build_notes_sheet(t.wb, notes)
t.wb.move_sheet(px, offset=t.wb.sheetnames.index('ТКП') - t.wb.sheetnames.index('Пояснения'))
rep.save(OUT)
print('saved', OUT, t.wb.sheetnames)
res = finalize(OUT, orig_path=TKP_XLSX, old2new=rep.old2new, deleted=rep.deleted)
print(json.dumps({k: v for k, v in res.items() if k != 'verify'}, ensure_ascii=False)[:800])
print('verify:', res['verify']['checked'], 'n_bad', res['verify']['n_bad'], res['verify']['bad'][:5])
json.dump({'old2new': rep.old2new, 'deleted': sorted(rep.deleted), 'cols': C, 'work_res': {str(k): v for k, v in WORK_RES.items()}}, open(f'{WORK}/build_meta.json', 'w'))
