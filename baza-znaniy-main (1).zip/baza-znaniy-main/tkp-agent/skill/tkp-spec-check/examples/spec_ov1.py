# -*- coding: utf-8 -*-
"""Структурирование спецификации ОВ1 (отопление/теплоснабжение): раздел → подраздел → группа → позиция (с подстроками)."""
import json, re, sys
sys.path.insert(0, '/home/claude/work')
from tkp_toolkit import qty_float, duct_info
from collections import OrderedDict

SECTIONS = {'Отопление': ('ОТ', None), 'Отопление.Паркинг.': ('ОТ', 'Паркинг'), 'Отопление. НПКИ': ('ОТ', 'НПКИ'), 'Теплоснабжение': ('ТС', 'Теплоснабжение')}
SUB_NAME = {'ОТ': 'Отопление (паркинг + НПКИ)', 'ТС': 'Теплоснабжение приточных установок'}
NUM_RE = re.compile(r'^(\d{1,3})\.\s*(.*)$', re.S)


def clean_rows(rows):
    out = []
    for r in rows:
        if r['pos'] == '1' and r['name'] == '2':            # строка нумерации граф
            continue
        r = dict(r)
        # мусор от штампа архива
        m = re.match(r'^(\d+(?:[.,]\d+)?)\b', r['qty'])
        if r['qty'] and m and m.group(1) != r['qty']:
            r['qty'] = m.group(1)
        if r['mass'] and not re.match(r'^[\d.,]+$', r['mass']):
            r['mass'] = ''
        if 'ИнКом' in r['note'] or 'ИК00' in r['note']:
            r['note'] = re.sub(r'\s*ИК00\s*566-00\s*', '', r['note'])
            if 'ИнКом' in r['note']:
                r['note'] = 'Qном=3909Вт'
        if r['supplier'] in (')', '( )'):
            r['supplier'] = 'ООО "ВЕЗЕР-КОМПЛЕКТ"' if 'Коллекторная' in r['name'] else ''
        if r['name'].startswith('50.') or r['name'].startswith('93.') or r['name'].startswith('114.'):
            r['supplier'] = 'Rubetek (ООО "Рубетек Рус")'
        if re.match(r'^(29|30|31|32)\.Конвектор', r['name']):
            r['supplier'] = 'ООО "Водокомфорт"'
        r['note'] = re.sub(r'\s*ООО\s*$', '', r['note']).strip()
        r['note'] = re.sub(r'(Qном=\d+Вт)\s+\d+$', r'\1', r['note'])
        # сбой нумерации внутри ячейки («…муфтовый, 78.PN16 Ду 32», «…измерения 88.0-1,6МПа», «…Ду15 84.Диапазон…»)
        r['name'] = re.sub(r'(?<=\s)\d{2,3}\.(?=[A-ZА-Яa-zа-я0-9])', '', r['name'])
        out.append(r)
    return out


def structure(rows):
    rows = clean_rows(rows)
    items, section, sub, group, parent = [], None, None, None, None
    ss = None
    for idx, r in enumerate(rows):
        nm = r['name'].strip()
        has_qty = bool(r['unit']) or bool(r['qty'])
        nxt = rows[idx + 1] if idx + 1 < len(rows) else None
        j = idx + 1
        while nxt and not (nxt['unit'] or nxt['qty']) and nxt['name'].strip() and nxt['name'].strip()[0].islower():   # строки-продолжения
            j += 1; nxt = rows[j] if j < len(rows) else None
        if not has_qty:
            if nm in SECTIONS:
                ss, sub = SECTIONS[nm]
                if sub: section = nm
                group, parent = None, None
                continue
            m = NUM_RE.match(nm)
            if m and nxt and (nxt['unit'] or nxt['qty']) and not NUM_RE.match(nxt['name'].strip()):
                parent = dict(posno=int(m.group(1)), name=m.group(2).strip(), type=r['type'], supplier=r['supplier'], code=r['code'], sheet=r['sheet'], page=r['page'])
                continue
            if m:
                group = m.group(2).strip(); parent = None; continue
            if parent and nm and nm[0].islower():          # продолжение наименования родительской позиции на следующем листе
                parent['name'] = parent['name'] + ' ' + nm
                continue
            if nm:
                group = nm; parent = None
            continue
        m = NUM_RE.match(nm)
        if m:
            posno, name = int(m.group(1)), m.group(2).strip()
            parent = None
            it = dict(posno=posno, name=name, type=r['type'], code=r['code'], supplier=r['supplier'], unit=r['unit'], qty=r['qty'], mass=r['mass'], note=r['note'],
                      sheet=r['sheet'], page=r['page'], src=r['src'])
        else:
            assert parent, f'подстрока без родителя: {r}'
            name = parent['name'] + ((', ' + nm) if nm else '')
            it = dict(posno=parent['posno'], name=name, type=r['type'] or parent['type'], code=r['code'] or parent['code'], supplier=r['supplier'] or parent['supplier'],
                      unit=r['unit'], qty=r['qty'], mass=r['mass'], note=r['note'], sheet=r['sheet'], page=r['page'], src=r['src'], sub_of=parent['posno'])
        it['ss'] = ss; it['section'] = section; it['sub'] = sub; it['group'] = group or ''
        it['system'] = sub + (' / ' + group if group else '')
        it['pos'] = r['pos']
        items.append(it)
    return items


def aggregate_ov1(items):
    agg = OrderedDict()
    for r in items:
        k = (r['ss'], r['name'], r['type'], r['code'], r['supplier'], r['unit'])
        a = agg.setdefault(k, {'ss': r['ss'], 'name': r['name'], 'type': r['type'], 'code': r['code'], 'supplier': r['supplier'], 'unit': r['unit'],
                               'qty': 0.0, 'n': 0, 'systems': [], 'mass': r['mass'], 'note': r['note'], 'sections': [], 'sheets': [], 'posnos': [], 'notes': [], 'rooms': []})
        a['qty'] = round(a['qty'] + qty_float(r['qty']), 4); a['n'] += 1
        for key, val in (('systems', r['system']), ('sections', r['section']), ('sheets', r['sheet']), ('posnos', r['posno'])):
            if val not in a[key]:
                a[key].append(val)
        if r['note'] and r['note'] not in a['notes']:
            a['notes'].append(r['note'])
        if r['pos']:
            a['rooms'] += r['pos'].split()
    out = []
    for i, a in enumerate(agg.values()):
        a['id'] = i
        if a['rooms']:
            a['systems'] = a['systems'] + ['пом. ' + ', '.join(a['rooms'])]
        out.append(a)
    return out


if __name__ == '__main__':
    rows = json.load(open('/home/claude/work/spec_rows.json'))
    items = structure(rows)
    agg = aggregate_ov1(items)
    print('items', len(items), 'agg', len(agg))
    for x in agg:
        print(x['id'], '|', x['ss'], '|', '/'.join(x['systems'])[:40], '|', 'поз.', ','.join(map(str, x['posnos'])), '|', x['name'][:75], '|', x['type'][:30], '|', x['supplier'][:14], '|', x['unit'], '|', x['qty'], '|', x['mass'], '|', '; '.join(x['notes'])[:40], '|', ' '.join(x['rooms'])[:30])
    json.dump(items, open('/home/claude/work/spec_items.json', 'w'), ensure_ascii=False, indent=0)
    json.dump(agg, open('/home/claude/work/spec_agg.json', 'w'), ensure_ascii=False, indent=0)
    # контроль: сумма по позициям
    print('Σ позиций спецификации:', len(set(it['posno'] for it in items)), 'уникальных номеров; макс', max(it['posno'] for it in items))
    missing = sorted(set(range(1, 173)) - set(it['posno'] for it in items))
    print('номера без строк количества (заголовки групп):', missing)
