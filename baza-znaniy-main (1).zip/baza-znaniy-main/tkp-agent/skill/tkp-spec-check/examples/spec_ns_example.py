# -*- coding: utf-8 -*-
"""Спецификация НС.СО (насосная станция) → spec_items.json / spec_agg.json; листы подбора → datasheets.json.
Объект: г. Москва, Гольяново, мкр. 1-2, зона 2.2; РД 111-1123-ОК-1/Н-2.2-1-1..4-НС (73 стр.), спецификация — стр. 7 (лист 1 из 1)."""
import json, re, sys
sys.path.insert(0, '/home/claude/work')
from tkp_toolkit import *

PDF = '/home/claude/work/in/rd.pdf'
STAMP_PATTERNS.append(r'Р\d{5}-\d{2}')
STAMP_PATTERNS.append(r'ООО "ГП-МФС"')

# ---------- 1. Спецификация (таблица по геометрии; в этой спецификации заголовок «Кол.» вместо «Количество» —
#              столбцы «Ед. изм.» и «Кол.» распознаны одним столбцом, разделяем локально)
pages = find_spec_pages(PDF)
assert pages == [7], pages
rows = extract_spec(PDF, pages)
fixed = []
for r in rows:
    r = dict(r)
    if 'qty' not in r:
        m = re.match(r'^(\D+?)\s+([\d\s.,]+)$', r['unit'])
        if m:
            r['unit'], r['qty'] = m.group(1).strip(), m.group(2).strip()
        else:
            r['qty'] = ''
    fixed.append(r)
rows = [r for r in fixed if not (r['pos'] == '1' and r['name'] == '2')]      # строка нумерации граф

# подстроки с характеристикой (G=…, Н=…, N=…) присоединяем к предыдущей позиции
items, section = [], None
for r in rows:
    if not r['unit'] and not r['qty']:
        if r['pos'] == '' and r['name'] and not r['name'].startswith('G='):
            section = r['name']; continue
        if r['name'].startswith('G=') and items:
            items[-1]['char'] = r['name']; continue
        continue
    r['section'] = section
    r['posno'] = r['pos']
    items.append(r)

# системы по «Общим данным» (стр. 4, таблица «Характеристики установок систем ВК»): зона 1 → В1(1), зона 2 → В1(2);
# В1 — объединённый хозяйственно-питьевой/противопожарный водопровод (ВПВ запитан от В1).
ZONE_SYS = {'1 зоны': 'В1(1)', '2 зоны': 'В1(2)'}
for it in items:
    z = next(k for k in ZONE_SYS if k in it['name'])
    it['system'] = ZONE_SYS[z]
    it['ss'] = 'В2' if 'пожаротуш' in it['name'] else 'В1'
    it['kind'] = 'ВПВ' if it['ss'] == 'В2' else 'ХВС'
    it['zone'] = z[0]
    m = re.match(r'G=([\d,]+) м\.куб/ч, Н=([\d,]+) м\.вод\.ст\., N=([\d,]+) кВт, (\d+) V', it['char'])
    it['G'], it['H'], it['N'], it['U'] = (float(m.group(i).replace(',', '.')) for i in (1, 2, 3, 4))
    mm = re.match(r'(\d) раб, (\d) рез', it['note'])
    it['n_work'], it['n_res'] = int(mm.group(1)), int(mm.group(2))
assert len(items) == 4, items

SUB_NAME_NS = {'В1': 'Система хозяйственно-питьевого водоснабжения (насосные установки ХВС, В1)',
               'В2': 'Система внутреннего противопожарного водопровода (насосные установки пожаротушения, В1/ВПВ)'}

# ---------- 2. Агрегация (по позициям: каждая позиция уникальна) — формат tkp_toolkit + доп. поля
agg = []
for i, it in enumerate(items):
    agg.append({'id': i, 'ss': it['ss'], 'name': f"{it['name']}; {it['char']}", 'type': it['type'], 'code': it['code'], 'supplier': it['supplier'],
                'unit': it['unit'], 'qty': qty_float(it['qty']), 'n': 1, 'systems': [it['system']], 'mass': it['mass'], 'note': it['note'],
                'sections': [it['section']], 'sheets': [it['sheet']], 'posno': it['posno'], 'short': it['name'], 'char': it['char'],
                'G': it['G'], 'H': it['H'], 'N': it['N'], 'U': it['U'], 'n_work': it['n_work'], 'n_res': it['n_res'], 'zone': it['zone'], 'kind': it['kind']})

# ---------- 3. Листы подбора (ЭЛИТА-Центр / Antarus): параметры установок и шкафов управления
texts = pdf_page_texts(PDF)


def clean(s):
    out = []
    for l in s.splitlines():
        ls = l.strip()
        if ls in ('US', 'R', 'TA', 'N', 'A', 'L', ''):
            continue
        out.append(re.sub(r'[ \t]{2,}', '  ', l.rstrip()))
    return '\n'.join(out)


def num(s):
    return float(s.replace(' ', '').replace(' ', '').replace(' ', '').replace(',', '.'))


DS = {}
for pn, txt in enumerate(texts, start=1):
    t = clean(txt)
    m = re.search(r'Артикул: (\d+)', t)
    if not m or 'Запрашиваемые параметры' not in t:
        continue
    title = ' '.join(l.strip() for l in t.splitlines()[:2])
    mark = re.search(r'ANTARUS \d MLV\d+-\d/01(?:/D)?', title).group()
    d = {'mark': mark, 'title': re.sub(r'\s+', ' ', title), 'article': m.group(1), 'page_params': pn}
    req = re.search(r'Запрашиваемые параметры:(.*?)Фактические параметры:(.*?)Данные электродвигателя', t, re.S)
    d['G_req'] = num(re.search(r'Расход\s+([\d,]+)', req.group(1)).group(1)); d['H_req'] = num(re.search(r'Напор\s+([\d,]+)', req.group(1)).group(1))
    d['G_act'] = num(re.search(r'Расход\s+([\d,]+)', req.group(2)).group(1)); d['H_act'] = num(re.search(r'Напор\s+([\d,]+)', req.group(2)).group(1))
    d['P_shaft'] = num(re.search(r'Мощность на валу\s+([\d,]+)', t).group(1))
    d['P_motor'] = num(re.search(r'Ном\. мощность\s+([\d,]+)', t).group(1))
    d['I_motor'] = num(re.search(r'Ном\. ток\s+([\d,]+)', t).group(1))
    d['rpm'] = num(re.search(r'Частота вращения э/д\s+([\d\s]+) об', t).group(1))
    d['weight'] = num(re.search(r'Вес\s+([\d\s]+?) кг', t).group(1))
    d['DN'] = re.search(r'Подключение\s+(DN ?\d+)', t).group(1)
    d['pmax'] = re.search(r'Макс\. раб\. давление\s+(\S+(?: бар)?)', t).group(1)
    d['dims'] = {k: int(re.search(k + r'\s+([\d\s]+?) мм', t).group(1).replace(' ', '')) for k in ('L1', 'H', 'Hp', 'B', 'B1') if re.search(k + r'\s+([\d\s]+?) мм', t)}
    mL = re.search(r'TA\s+([\d\s]+?) мм', t) or re.search(r'\bL\s+([\d\s]+?) мм', t)
    if mL:
        d['dims']['L'] = int(mL.group(1).replace(' ', ''))
    mt = re.search(r'Тех\. запрос №([\d\s]+?)\s+Дата: ([\d.]+)', t)
    d['request'], d['request_date'] = mt.group(1).replace(' ', ' ').replace(' ', ' '), mt.group(2)
    # состав поставки — следующая страница
    t2 = clean(texts[pn])
    comp = re.findall(r'^\s*(\d+)\s+(.+?)\s+(\d+)\s+(шт\.)\s*$', t2, re.M)
    d['composition'] = [(int(n_), nm.strip(), int(q)) for n_, nm, q, _ in comp]
    d['page_composition'] = pn + 1
    # шкаф управления — страница «Технические характеристики шкафа управления» до следующего листа подбора
    for p2 in range(pn + 1, min(pn + 20, len(texts))):
        t3 = clean(texts[p2])
        if 'Технические характеристики шкафа управления' in t3:
            cab = {'page': p2 + 1}
            cab['I_in'] = re.search(r'Номинальный ток вводного выключателя\s+(\d+) А', t3).group(1) + ' А'
            cab['n_pumps'] = int(re.search(r'Количество насосов\s+(\d+) шт', t3).group(1))
            cab['mass'] = re.search(r'Масса шкафа, не более\s+(\d+) кг', t3).group(1) + ' кг'
            cab['size'] = re.search(r'Габаритные размеры корпуса \(ШхВхГ\), не более\s+(\S+) мм', t3).group(1) + ' мм'
            cab['ip'] = re.search(r'Степень защиты корпуса\s+(IP-?\d+)', t3).group(1)
            mp = re.search(r'Мощность одного насоса\s+([\d,]+) кВт', t3)
            cab['P_pump'] = num(mp.group(1)) if mp else None
            cab['I_pump'] = re.search(r'Номинальный ток одного насоса\s+До ([\d,]+) ?А', t3).group(1) + ' А'
            cab['series'] = 'АМПЕРУС НГР-КПЧ (ПЧ на каждый насос)' if 'повышения давления' in t3.splitlines()[0] else 'АМПЕРУС НГР-ПЖ (пожаротушение)'
            d['cabinet'] = cab
            break
    DS[mark] = d

assert set(DS) == {x['type'] for x in agg}, (set(DS), {x['type'] for x in agg})
json.dump(items, open('/home/claude/work/spec_items.json', 'w'), ensure_ascii=False, indent=1)
json.dump(agg, open('/home/claude/work/spec_agg.json', 'w'), ensure_ascii=False, indent=1)
json.dump(DS, open('/home/claude/work/datasheets.json', 'w'), ensure_ascii=False, indent=1)
if __name__ == '__main__':
    for x in agg:
        print(x['id'], x['posno'], x['ss'], x['systems'], x['short'], '|', x['type'], '|', x['unit'], x['qty'], '|', x['note'], '|', x['char'])
    for k, d in DS.items():
        print('\n', k, json.dumps(d, ensure_ascii=False, indent=1))
