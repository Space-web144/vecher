# -*- coding: utf-8 -*-
"""Автоматическое предложение сопоставления строк ТКП ↔ позиции спецификации (по корпусам). Правила по семействам."""
import json, re, sys
sys.path.insert(0, '/home/claude/work')
from tkp_toolkit import Tkp

AGG = json.load(open('/home/claude/work/spec_agg.json'))
A = {x['id']: x for x in AGG}
BLOCKS = {1: (36, 268), 2: (269, 494), 3: (495, 724), 4: (725, 955)}

CYR2LAT = str.maketrans({'А': 'A', 'В': 'B', 'Е': 'E', 'К': 'K', 'М': 'M', 'Н': 'H', 'О': 'O', 'Р': 'P', 'С': 'C', 'Т': 'T', 'Х': 'X', 'У': 'Y',
                         'а': 'a', 'в': 'b', 'е': 'e', 'к': 'k', 'м': 'm', 'н': 'h', 'о': 'o', 'р': 'p', 'с': 'c', 'т': 't', 'х': 'x', 'у': 'y'})
VENDORS = ['Русклимат', 'Вент-Арт', 'Вентарт', 'Арктос', 'АРКТОС', 'Виктория', 'ЭРА', 'ERA', 'Korf', 'ГАЛВЕНТ', 'Галвент', 'Сигмавент', 'АЭРДИН',
           'ООО "ВЕНТЗАЩИТА"', 'ООО "АСС"', 'НПП "АЭРВАН"', 'ВЗТМ']


def norm(s):
    s = (s or '').translate(CYR2LAT).lower().replace('ё', 'е')
    return re.sub(r'[\s\-–—]+', '', s)


def sizes_in(s):
    out = set()
    for m in re.finditer(r'(\d{2,4})\s*[xх×]\s*(\d{2,4})', s or ''):
        out.add(f'{m.group(1)}x{m.group(2)}')
    for m in re.finditer(r'(?:Ø|ø|[DdФф])\s*(\d{2,4})', s or ''):
        out.add(f'd{m.group(1)}')
    return out


def comment_parts(comment):
    parts = []
    for p in re.split(r';', comment or ''):
        p = p.strip()
        if not p:
            continue
        m = re.search(r'\s*[—–-]\s*(\d+)\s*шт\.?\s*$', p)
        cnt = int(m.group(1)) if m else None
        if m:
            p = p[:m.start()].strip()
        parts.append((p, cnt))
    return parts


def mark_prefix(text):
    """Марка из текста примечания: до первой запятой/тире и до первого строчного кириллического слова; без слов-производителей."""
    t = text
    for v in VENDORS:
        t = t.replace(v, ' ')
    t = re.split(r',|\s[—–]\s|\(', t)[0]
    m = re.search(r'\s[а-яё]{3,}', t)
    if m:
        t = t[:m.start()]
    return t.strip()


def pool(k, ss):
    return [x for x in AGG if x['korpus'] in (k, None) and x['ss'] == ss and not x.get('duct')]


def by_mark(k, ss, text):
    nt = norm(text)
    hits = []
    for x in pool(k, ss):
        tp = norm(x['type'])
        if tp and len(tp) >= 4 and tp in nt:
            hits.append((len(tp), x['id']))
    if hits:
        best = max(h[0] for h in hits)
        return [i for s, i in hits if s == best]
    pref = norm(mark_prefix(text))
    if len(pref) >= 4:
        hits = [x['id'] for x in pool(k, ss) if pref in norm(x['name'])]
        if hits:
            return hits
    return []


def refine_by_size(ids, *texts):
    sz = set()
    for t in texts:
        sz |= sizes_in(t)
    if len(ids) > 1 and sz:
        ids2 = [i for i in ids if not sizes_in(A[i]['name']) or (sizes_in(A[i]['name']) & sz)]
        if ids2:
            return ids2
    return ids


def by_family(k, ss, name, com=''):
    """Строки ТКП без примечания: сетки, дефлекторы, изоляция, крепёж и т.п."""
    P = pool(k, ss)
    if name.startswith('Сетка в рамке'):
        sz = sizes_in(re.sub(r'ячейк\w*\s*\d+\s*[xх]\s*\d+\s*мм', '', name)) | sizes_in(com or '')
        return [x['id'] for x in P if x['name'].startswith(('Сетка', 'Металлическая сетка')) and sizes_in(re.sub(r'ячейк\w*\s*\d+\s*[xх]\s*\d+', '', x['name'])) & sz]
    if name.startswith('Воздуховод гибкий'):
        return [x['id'] for x in P if x['name'].startswith('Полужесткий неизолированный воздуховод')]
    if name.startswith('Дефлектор'):
        sz = sizes_in(name)
        return [x['id'] for x in P if x['name'].startswith('Дефлектор') and sizes_in(x['name']) & sz]
    m = re.search(r'ОБМ-ВЕНТ.*EI\s*(\d+)', name)
    if m:
        ei = m.group(1)
        return [x['id'] for x in P if x['name'].startswith('Двухкомпонентная система огнезащиты') and re.search(r'EI\s*' + ei + r'\b', x['name'])]
    m = re.search(r'Мат прошивной.*EI(\d+)', name)
    if m:
        ei = m.group(1)
        return [x['id'] for x in P if x['name'].startswith('Теплоогнезащитное покрытие') and re.search(r'EI\s*' + ei + r'\b', x['name'])]
    if 'K-flex' in name or 'Самоклеящ' in name:
        return [x['id'] for x in P if x['name'].startswith('Самоклеящийся покрывной')]
    if name.startswith('Уголок стальной'):
        return [x['id'] for x in P if x['name'] in ('Детали крепления воздуховодов', 'Средства для крепления воздуховодов')]
    if name.startswith('Лист стальной оцинкованный'):
        return [x['id'] for x in P if x['name'].startswith('Оцинкованная сталь для фартука')]
    if name.startswith('Огнезащитное покрытие'):
        return [x['id'] for x in P if x['name'].startswith('Краска огнезащитная') or x['name'].startswith('Грунт по металлу')]
    return []


def propose(t, k, r, ss):
    name, com = t.name(r), t.comment(r)
    fam = by_family(k, ss, name, com)
    if fam:
        return [(name, None, fam)]
    out = []
    if com.strip():
        for ptxt, cnt in comment_parts(com):
            ids = refine_by_size(by_mark(k, ss, ptxt), ptxt, name)
            out.append((ptxt, cnt, ids))
    else:
        out.append((name, None, refine_by_size(by_mark(k, ss, name), name)))
    return out


SKIP_PREFIX = ('Крепежные элементы', 'Воздуховод', 'Фасонные')

if __name__ == '__main__':
    t = Tkp('/home/claude/in/tkp.xlsx')
    kk = int(sys.argv[1]) if len(sys.argv) > 1 else 1
    a, b = BLOCKS[kk]
    ss = None
    used = {}
    for r in range(a, b + 1):
        if t.is_section(r) and t.name(r) in ('Общеобменная вентиляция', 'Противодымная вентиляция'):
            ss = 'ОВ' if 'Общеоб' in t.name(r) else 'ПД'
        if t.is_work(r):
            print(f'\n[{r}] W {t.name(r)[:90]} | {t.unit(r)} {t.qty(r)}')
        if t.is_material(r):
            if t.name(r).startswith(SKIP_PREFIX):
                print(f'   [{r}] m {t.name(r)[:70]} | {t.qty(r)}  (по правилам)')
                continue
            props = propose(t, kk, r, ss)
            print(f'   [{r}] m {t.name(r)[:70]} | {t.unit(r)} {t.qty(r)} | «{t.comment(r)[:80]}»')
            tot = 0
            for ptxt, cnt, ids in props:
                for i in ids:
                    x = A[i]; used.setdefault(i, []).append(r); tot += x['qty']
                    print(f'        -> {i} {x["name"][:62]} | {x["type"][:38]} | {x["unit"]} {x["qty"]} | {", ".join(map(str, x["systems"]))[:40]}')
                if not ids:
                    print(f'        -> ??? нет кандидатов для «{ptxt[:60]}»')
            flag = 'OK' if abs(tot - t.qty(r)) < 1e-6 else f'Σспец={tot} ≠ КЦ={t.qty(r)}'
            print(f'        == {flag}')
    print('\n==== НЕ использованные позиции спецификации корпуса', kk)
    for x in AGG:
        if x['korpus'] in (kk, None) and x['ss'] in ('ОВ', 'ПД') and x['id'] not in used and not x.get('duct'):
            print(f'   {x["id"]} {x["ss"]} | {x["name"][:85]} | {x["type"][:30]} | {x["unit"]} {x["qty"]} | {", ".join(map(str, x["systems"]))[:40]}')
    print('\n==== Позиции, использованные более одного раза')
    for i, rows in used.items():
        if len(rows) > 1:
            print('  ', i, A[i]['name'][:60], A[i]['type'], rows)
