# -*- coding: utf-8 -*-
"""
check_kit.py — проверка, что комплект агента цел: все файлы по MANIFEST.md на месте,
SKILL.md соответствует требованиям Agent Skills, окружение готово (pdftotext, LibreOffice, Python-пакеты),
все .py компилируются, модули scripts/ импортируются.

    python check_kit.py            # из корня комплекта
Код выхода 0 — комплект готов; 1 — есть проблемы (перечислены).
"""
import importlib
import os
import re
import shutil
import sys

ROOT = os.path.dirname(os.path.abspath(__file__))
SKILL = os.path.join(ROOT, 'skill', 'tkp-spec-check')
SKILL_NZ = os.path.join(ROOT, 'skill', 'tkp-nz-audit')

# (путь в комплекте, источник, обязательный)
FILES = [
    ('skill/tkp-spec-check/SKILL.md', 'комплект', True),
    ('skill/tkp-spec-check/references/rules_common.md', 'комплект', True),
    ('skill/tkp-spec-check/references/rules_ov1_heating.md', 'комплект', True),
    ('skill/tkp-spec-check/references/rules_ns_equipment.md', 'комплект', True),
    ('skill/tkp-spec-check/references/rules_multikorpus.md', 'комплект', True),
    ('skill/tkp-spec-check/references/lessons_learned.md', 'комплект', True),
    ('skill/tkp-spec-check/references/error_catalog.md', 'комплект', True),
    ('skill/tkp-spec-check/references/qa_checklist.md', 'комплект', True),
    ('skill/tkp-spec-check/references/verifier_prompt.md', 'комплект', True),
    ('skill/tkp-spec-check/references/ТЗ_проверка_ТКП_вентиляция_по_спецификации.md', 'проект: ТЗ_проверка_ТКП_вентиляция_по_спецификации.md', True),
    ('skill/tkp-spec-check/references/Правила_проверки_ТКП_ВК_по_спецификации.md', 'проект: Правила_проверки_ТКП_ВК_по_спецификации.md', True),
    ('skill/tkp-spec-check/scripts/tkp_ext.py', 'комплект', True),
    ('skill/tkp-spec-check/scripts/recalc_lo.py', 'комплект', True),
    ('skill/tkp-spec-check/scripts/qa_check.py', 'комплект', True),
    ('skill/tkp-spec-check/scripts/kc_ref.py', 'комплект', True),
    ('skill/tkp-spec-check/assets/kc_ref.json.gz', 'tools/kc_ref_build.py из выгрузки «справочник_КЦ_ВЕСЬ.xlsx»', True),
    ('tools/kc_ref_build.py', 'комплект', True),
    ('skill/tkp-spec-check/scripts/tkp_toolkit.py', 'проект: tkp_toolkit.py', True),
    ('skill/tkp-spec-check/scripts/vk_spec.py', 'проект: vk_spec.py', True),
    ('skill/tkp-spec-check/scripts/halifax.py', 'проект: halifax.py', True),
    ('skill/tkp-spec-check/scripts/spec_local.py', 'проект: claude/spec_local_perspektiva.py (переименован)', True),
    ('skill/tkp-spec-check/examples/automatch.py', 'проект: claude/automatch_marks.py (переименован)', True),
    ('skill/tkp-spec-check/examples/run_check_example.py', 'проект: run_check_example.py', True),
    ('skill/tkp-spec-check/examples/run_check_vk_example.py', 'проект: run_check_vk_example.py', True),
    ('skill/tkp-spec-check/examples/mapping_vk_example.py', 'проект: mapping_vk_example.py', True),
    ('skill/tkp-spec-check/examples/extract_heating_example.py', 'проект: claude/extract_heating_example.py', True),
    ('skill/tkp-spec-check/examples/spec_ov1.py', 'проект: claude/spec_heating_example.py (переименован)', True),
    ('skill/tkp-spec-check/examples/run_check_heating_example.py', 'проект: claude/run_check_heating_example.py', True),
    ('skill/tkp-spec-check/examples/spec_ns_example.py', 'проект: claude/spec_ns_example.py', True),
    ('skill/tkp-spec-check/examples/run_check_ns_example.py', 'проект: claude/run_check_ns_example.py', True),
    ('skill/tkp-spec-check/examples/run_check_multikorpus_example.py', 'проект: claude/run_check_multikorpus_example.py', True),
    ('skill/tkp-spec-check/assets/КАТАЛОГ ПРОДУКЦИИ HALIFAX 10.pdf', 'проект (файл)', True),
    ('agent/system_prompt.md', 'комплект', True),
    ('docs/ТЗ_на_ИИ-агента_проверки_ТКП.md', 'комплект', True),
    ('env/requirements.txt', 'комплект', True),
    ('env/Dockerfile', 'комплект', True),
    ('evals/golden_objects.yaml', 'комплект', True),
    # навык «Проверка ТКП по нарядам-заказам» (комплект «Агент проверки ТКП по НЗ», 31.10.2026)
    ('skill/tkp-nz-audit/SKILL.md', 'комплект НЗ', True),
    ('agent/system_prompt_nz.md', 'комплект НЗ: Системный_промпт.md', True),
    ('skill/tkp-nz-audit/references/Термины_и_структура_ТКП.md', 'комплект НЗ: знания/', True),
    ('skill/tkp-nz-audit/references/Методики_проверок.md', 'комплект НЗ: знания/', True),
    ('skill/tkp-nz-audit/references/Каталог_типовых_ошибок.md', 'комплект НЗ: знания/', True),
    ('skill/tkp-nz-audit/references/Шаблоны_отчётов.md', 'комплект НЗ: знания/', True),
    ('skill/tkp-nz-audit/references/Справочные_данные.md', 'комплект НЗ: знания/', True),
    ('skill/tkp-nz-audit/references/Журнал_проверок.md', 'комплект НЗ: знания/', True),
    ('skill/tkp-nz-audit/references/исходные_инструкции/Инструкция_РВР_ДР.md', 'комплект НЗ: инструкция заказчика', True),
    ('skill/tkp-nz-audit/references/исходные_инструкции/instrukciya_times_new_roman.md', 'комплект НЗ: инструкция заказчика', True),
    ('skill/tkp-nz-audit/scripts/tkp_scan.py', 'комплект НЗ', True),
    ('skill/tkp-nz-audit/scripts/xlsx_add_sheet.py', 'комплект НЗ', True),
    ('skill/tkp-nz-audit/scripts/xlsx_set_cells.py', 'комплект НЗ', True),
    ('skill/tkp-nz-audit/scripts/qa_nz.py', 'комплект', True),
    ('skill/tkp-nz-audit/scripts/примеры/spec_ДР_Аудит.json', 'комплект НЗ', True),
    ('evals/golden_objects_nz.yaml', 'комплект', True),
    ('tools/pack_skills.py', 'комплект', True),
]


def check_skill_md(problems, skill=SKILL):
    p = os.path.join(skill, 'SKILL.md')
    if not os.path.exists(p):
        return
    txt = open(p, encoding='utf-8').read()
    m = re.match(r'^---\n(.*?)\n---\n', txt, re.S)
    if not m:
        problems.append(f'{os.path.basename(skill)}/SKILL.md: нет YAML-заголовка')
        return
    head = m.group(1)
    name = re.search(r'^name:\s*(.+)$', head, re.M)
    desc = re.search(r'^description:\s*(.+)$', head, re.M)
    if not name or not re.fullmatch(r'[a-z0-9-]{1,64}', name.group(1).strip()) or re.search(r'anthropic|claude', name.group(1)):
        problems.append('SKILL.md: name — до 64 символов, только a-z, 0-9, «-», без «anthropic»/«claude»')
    if not desc or not (0 < len(desc.group(1).strip()) <= 1024) or '<' in desc.group(1):
        problems.append(f'SKILL.md: description — 1…1024 символа без XML-тегов (сейчас {len(desc.group(1)) if desc else 0})')


def main():
    problems = []
    for rel, src, req in FILES:
        if not os.path.exists(os.path.join(ROOT, rel)):
            problems.append(f'нет файла {rel}  ← {src}')
    check_skill_md(problems)
    check_skill_md(problems, SKILL_NZ)
    for tool in ('pdftotext',):
        if not shutil.which(tool):
            problems.append(f'нет {tool} (poppler-utils)')
    if not (shutil.which('soffice') or shutil.which('libreoffice')):
        problems.append('нет LibreOffice (soffice) — пересчёт и контроль 3 невозможны')
    for mod in ('openpyxl', 'pdfplumber', 'lxml'):
        try:
            importlib.import_module(mod)
        except ImportError:
            problems.append(f'нет Python-пакета {mod}')
    for skill, d in ((SKILL, 'scripts'), (SKILL, 'examples'), (SKILL_NZ, 'scripts')):
        for f in sorted(os.listdir(os.path.join(skill, d))):
            if f.endswith('.py'):
                try:
                    compile(open(os.path.join(skill, d, f), encoding='utf-8').read(), f, 'exec')
                except SyntaxError as e:
                    problems.append(f'{os.path.basename(skill)}/{d}/{f}: синтаксическая ошибка, строка {e.lineno}: {e.msg}')
    nz_spec = os.path.join(SKILL_NZ, 'scripts', 'примеры', 'spec_ДР_Аудит.json')
    if os.path.exists(nz_spec):
        import json
        try:
            spec = json.load(open(nz_spec, encoding='utf-8'))
            sys.path.insert(0, os.path.join(SKILL_NZ, 'scripts'))
            import qa_nz  # noqa: F401
            bad = [r[spec['status_column'] - 1] for r in spec.get('rows', []) if qa_nz.base_status(r[spec['status_column'] - 1]) is None]
            if bad:
                problems.append(f'tkp-nz-audit: статусы образца spec_ДР_Аудит.json не принимает qa_nz.py: {bad[:3]}')
        except Exception as e:  # noqa: BLE001
            problems.append(f'tkp-nz-audit: образец spec_ДР_Аудит.json / qa_nz.py: {e}')
    sys.path.insert(0, os.path.join(SKILL, 'scripts'))
    for mod in ('tkp_toolkit', 'vk_spec', 'halifax', 'spec_local', 'qa_check', 'recalc_lo'):
        try:
            importlib.import_module(mod)
        except Exception as e:  # noqa: BLE001
            problems.append(f'scripts/{mod}.py не импортируется: {e}')
    try:
        import kc_ref
        ref = kc_ref.load()
        if ref['works'] < 500:
            problems.append(f'справочник КЦ подозрительно мал: {ref["works"]} работ')
        else:
            print(f'справочник КЦ: {ref["works"]} работ, {ref["materials"]} материалов ({ref["source"]}, {ref["built"]})')
    except Exception as e:  # noqa: BLE001
        problems.append(f'справочник КЦ (scripts/kc_ref.py, assets/kc_ref.json.gz) не загружается: {e}')
    if os.path.exists(os.path.join(SKILL, 'scripts', 'tkp_toolkit.py')):
        try:
            import tkp_ext  # noqa: F401
            import tempfile
            tmp = tempfile.mkdtemp(prefix='tkp_check_')
            info = tkp_ext.configure(work=os.path.join(tmp, 'work'), out_dir=os.path.join(tmp, 'out'))
            print('tkp_ext.configure:', info)
        except Exception as e:  # noqa: BLE001
            problems.append(f'tkp_ext/tkp_toolkit не импортируются: {e}')
    if problems:
        print('КОМПЛЕКТ НЕ ГОТОВ:')
        for p in problems:
            print('  -', p)
        sys.exit(1)
    print('Комплект готов.')


if __name__ == '__main__':
    main()
