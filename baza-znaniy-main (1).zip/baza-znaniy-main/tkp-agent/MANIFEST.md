# MANIFEST — состав комплекта

Комплект самодостаточен: внутри и новые материалы (системный промпт, навык, правила ОВ1/НС/многокорпусных, опыт, каталог ошибок, чек-лист, эталоны, окружение, скрипты пересчёта и приёмки), и код и документы проекта «Проверка осн. дог.». Докопировать ничего не нужно.

## 1. Файлы проекта в комплекте

Перенесены из базы знаний проекта 31.10.2026 без изменения логики. Три файла переименованы — под эти имена написаны импорты в примерах. Файлы переносились вручную (текстом), поэтому при расхождении главнее оригинал в проекте: если в проекте файл обновится, замените его копию в комплекте.

| Документ проекта | Где лежит в комплекте | Примечание |
| --- | --- | --- |
| ТЗ_проверка_ТКП_вентиляция_по_спецификации.md | skill/tkp-spec-check/references/ТЗ_проверка_ТКП_вентиляция_по_спецификации.md | |
| Правила_проверки_ТКП_ВК_по_спецификации.md | skill/tkp-spec-check/references/Правила_проверки_ТКП_ВК_по_спецификации.md | |
| tkp_toolkit.py | skill/tkp-spec-check/scripts/tkp_toolkit.py | не изменять; доработки — в tkp_ext.py |
| vk_spec.py | skill/tkp-spec-check/scripts/vk_spec.py | |
| halifax.py | skill/tkp-spec-check/scripts/halifax.py | |
| claude/spec_local_perspektiva.py | skill/tkp-spec-check/scripts/**spec_local.py** | переименован: `from spec_local import duct_info2` |
| claude/automatch_marks.py | skill/tkp-spec-check/examples/**automatch.py** | переименован: `from automatch import …`; читает `/home/claude/work/spec_agg.json` |
| claude/spec_heating_example.py | skill/tkp-spec-check/examples/**spec_ov1.py** | переименован: `from spec_ov1 import SUB_NAME` |
| run_check_example.py | skill/tkp-spec-check/examples/run_check_example.py | часть строк сопоставления опущена ещё в оригинале |
| run_check_vk_example.py | skill/tkp-spec-check/examples/run_check_vk_example.py | |
| mapping_vk_example.py | skill/tkp-spec-check/examples/mapping_vk_example.py | |
| claude/extract_heating_example.py | skill/tkp-spec-check/examples/extract_heating_example.py | |
| claude/run_check_heating_example.py | skill/tkp-spec-check/examples/run_check_heating_example.py | |
| claude/spec_ns_example.py | skill/tkp-spec-check/examples/spec_ns_example.py | |
| claude/run_check_ns_example.py | skill/tkp-spec-check/examples/run_check_ns_example.py | |
| claude/run_check_multikorpus_example.py | skill/tkp-spec-check/examples/run_check_multikorpus_example.py | |
| КАТАЛОГ ПРОДУКЦИИ HALIFAX 10.pdf (файл проекта) | skill/tkp-spec-check/assets/КАТАЛОГ ПРОДУКЦИИ HALIFAX 10.pdf | |

## 2. Новые материалы

| Файл | Назначение |
| --- | --- |
| README.md | как развернуть агента и прогнать эталоны |
| docs/ТЗ_на_ИИ-агента_проверки_ТКП.md | полное ТЗ на агента (экспорт документа; схемы в нём — заглушки, оригинал — в документе Claude) |
| agent/system_prompt.md | системный промпт агента (или новый текст поля Instructions проекта) |
| skill/tkp-spec-check/SKILL.md | навык: порядок работы, маршрутизация по разделам, 4 машинных контроля |
| references/rules_common.md | общие правила и контракт выходного файла |
| references/rules_ov1_heating.md | правила ОВ1 (из проверки ТКП 7869889) |
| references/rules_ns_equipment.md | правила НС и оборудования с листами подбора (ТКП 7878665) |
| references/rules_multikorpus.md | многокорпусные объекты и формат «Перспектива» (ТКП 7883279) |
| references/lessons_learned.md | ловушки извлечения PDF, Excel, сопоставления |
| references/error_catalog.md | типовые ошибки ТКП и дословные замечания |
| references/qa_checklist.md | единый чек-лист приёмки |
| references/verifier_prompt.md | задание субагенту-проверяющему |
| scripts/tkp_ext.py | доработки tkp_toolkit без его изменения: пути, пересчёт, нулевые расценки, контроль полноты (с воздуховодами и позициями вне ТКП), короткие тексты, высоты строк |
| scripts/recalc_lo.py | пересчёт копии через LibreOffice — замена recalc.py из claude.ai |
| scripts/qa_check.py | машинная приёмка готового файла (с `--orig` сравнивает и исходные листы) |
| evals/golden_objects.yaml | 5 эталонных объектов: контрольные числа и ошибки, которые агент обязан найти |
| env/requirements.txt, env/Dockerfile | окружение песочницы |
| check_kit.py | проверка комплекта: файлы, SKILL.md, окружение, компиляция и импорт модулей, справочник КЦ |
| scripts/kc_ref.py, assets/kc_ref.json.gz | справочник КЦ из выгрузки «справочник_КЦ_ВЕСЬ.xlsx» (31.10.2026): 1 016 расценок ВК, ОВ1, ОВ2, ИТП, кондиционирования и 47 920 материалов; поиск номенклатуры, `check_tkp` — сверка ТКП со справочником (добавлено в репозитории сайта) |
| tools/kc_ref_build.py | сборка assets/kc_ref.json.gz из новой выгрузки КЦ, сверка с прежней |

## 2а. Навык «Проверка ТКП по НЗ»

Из комплекта «Агент проверки ТКП по НЗ» (31.10.2026), без изменения логики; главнее — эта копия в репозитории (журнал проверок ведётся здесь же, `references/Журнал_проверок.md`).

| В комплекте НЗ | Где лежит | Изменения |
| --- | --- | --- |
| SKILL.md | skill/tkp-nz-audit/SKILL.md | пути `знания/` → `references/`; убрано «создай скрипты из базы знаний»; шаг 7 — `qa_nz.py`; статусы РВР и сверки цен из практики |
| Системный_промпт.md | agent/system_prompt_nz.md | те же правки |
| README.md | docs/НЗ_комплект_README.md | без изменений |
| знания/* (6 файлов, исходные_инструкции/, примеры_отчётов/) | skill/tkp-nz-audit/references/ | без изменений |
| scripts/tkp_scan.py, xlsx_add_sheet.py, xlsx_set_cells.py, примеры/ | skill/tkp-nz-audit/scripts/ | без изменений |
| — | skill/tkp-nz-audit/scripts/qa_nz.py | новый: машинная приёмка листа аудита |
| — | evals/golden_objects_nz.yaml | новый: 3 эталона с ожидаемыми числами и must_find |

## 3. Чего в комплекте нет

Исходных файлов эталонных объектов (PDF РД, xlsx ТКП, ТР) — в проекте они не сохранены. Для оценки агента их нужно приложить (README, раздел «Оценка»).

Справочник материалов и расценок КЦ, которого не хватало в исходном комплекте, добавлен 31.10.2026 (scripts/kc_ref.py). Цен в нём нет — агент проверяет номенклатуру и объёмы, не стоимость.
