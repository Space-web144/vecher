<?php
declare(strict_types=1);

// Отдача файла из библиотеки документов (см. docs_lib.php). PDF и картинки
// открываются прямо в браузере, остальное — скачивается; ?dl=1 — всегда
// скачать. Имя при сохранении — исходное имя загруженного файла.
// По умолчанию отдаётся текущая редакция; &v=<id файла> — одна из прежних.

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require __DIR__ . '/docs_lib.php';

$id = (string) ($_GET['id'] ?? '');
if (!doc_id_valid($id)) {
    http_response_code(400);
    exit('Некорректный идентификатор документа.');
}

$doc = find_doc(load_docs(), $id);
$file = $doc;
$version = (string) ($_GET['v'] ?? '');
if ($doc !== null && $version !== '') {
    // Только редакция ЭТОГО документа — id файла сверяется по его versions.
    $file = null;
    foreach ($doc['versions'] as $v) {
        if (hash_equals($v['file'], $version)) {
            $file = $v;
            break;
        }
    }
}
$path = $file !== null ? doc_file_path($file['file'], $file['ext']) : '';
if ($file === null || !is_file($path)) {
    http_response_code(404);
    exit('Документ не найден.');
}

$type = DOC_TYPES[$file['ext']];
$inline = $type['inline'] && empty($_GET['dl']);

$name = $file['original_name'] !== '' ? $file['original_name'] : ($file['file'] . '.' . $file['ext']);
$name = preg_replace('/[\x00-\x1F\x7F"\\\\\/]/u', '_', $name) ?? 'document';
$asciiName = preg_replace('/[^A-Za-z0-9 ._()\-]/', '_', $name) ?? 'document';

header('Content-Type: ' . $type['mime']);
header('Content-Disposition: ' . ($inline ? 'inline' : 'attachment')
    . '; filename="' . $asciiName . '"; filename*=UTF-8\'\'' . rawurlencode($name));
header('Content-Length: ' . filesize($path));
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, max-age=3600');
readfile($path);
