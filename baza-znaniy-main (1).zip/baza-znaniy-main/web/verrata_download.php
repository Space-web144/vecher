<?php
declare(strict_types=1);

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require __DIR__ . '/lib.php';

$token = $_GET['token'] ?? '';
$kind = $_GET['kind'] ?? '';

// Токен — строго наш формат, вид отчёта — из двух известных. Никаких
// путей из запроса: имя файла на диске собирается здесь, а не приходит
// снаружи.
if (!is_string($token) || !preg_match('/^[a-f0-9]{16}$/', $token)
    || !in_array($kind, ['pdf', 'xlsx'], true)) {
    http_response_code(400);
    exit('Некорректный запрос.');
}

$path = VERRATA_OUTPUT_DIR . '/' . $token . '_verrata.' . $kind;
$realDir = realpath(VERRATA_OUTPUT_DIR);
$realPath = realpath($path);
if ($realPath === false || $realDir === false
    || strpos($realPath, $realDir) !== 0 || !is_file($realPath)) {
    http_response_code(404);
    exit('Файл не найден.');
}

// Имя в диалоге "Сохранить как" — по комплекту и разделу из карточки
// задачи, а не безликий токен: у инженера таких отчётов десятки.
$downloadName = 'Сравнение ревизий';
$jobPath = VERRATA_OUTPUT_DIR . '/' . $token . '_job.json';
if (is_file($jobPath)) {
    $job = json_decode((string) file_get_contents($jobPath), true);
    if (is_array($job)) {
        $first = is_array($job['files'] ?? null) ? (string) ($job['files'][0] ?? '') : '';
        $base = sanitize_display_base(pathinfo($first, PATHINFO_FILENAME));
        $section = sanitize_display_base((string) ($job['section'] ?? ''));
        $suffix = $kind === 'pdf' ? 'чертежи' : 'спецификация';
        $downloadName = trim($base . ' ' . $section . ' — сравнение, ' . $suffix);
    }
}

$mime = $kind === 'pdf'
    ? 'application/pdf'
    : 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet';

header('Content-Type: ' . $mime);
header('Content-Length: ' . (string) filesize($realPath));
header('Content-Disposition: attachment; filename="report.' . $kind . '"; '
    . "filename*=UTF-8''" . rawurlencode($downloadName . '.' . $kind));
header('X-Content-Type-Options: nosniff');
readfile($realPath);
