<?php
declare(strict_types=1);

// Проверка РВ инженером (страница rv_status.php, состояние done): JSON
// {token, corrections: [{id, code?, role?, coef?}], confirm_rest: true, work_notes: {код ИСР: текст}}.
// work_notes — примечания сметчика к работам (пустой текст — убрать своё примечание); уходят в 1С полем
// «Примечание» сметной позиции (web_rv_run.work_notes). splits: {id: [{code, qty}, …]} — строка ЛРВ на несколько
// работ с количеством под каждой (пустой список — убрать разбиение); агент делит строку на части с тем же
// ИдентификаторСтроки (web_rv_run.apply_splits), в 1С — доли через «ВесовойКоэф».
// Согласование только целиком разнесённой РВ: каждой строке без работы нужно исправление с кодом
// работы, иначе 422 со списком строк (rv_unbound_rows).
// Исправления — строки, где агент ошибся: верная работа, роль и/или
// коэффициент (объём работы на единицу материала); остальные строки
// считаются подобранными верно. Решения сохраняются в файл задачи и агент
// запускается заново: записывает их в память (RV_LEARNING_FILE), привязывает
// строки с их учётом и пересобирает книгу; проверка моделью не повторяется.

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require_once __DIR__ . '/users.php';
require_once __DIR__ . '/lib.php';
require_once __DIR__ . '/rv_lib.php';

rv_guard();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    rv_json(['ok' => false, 'error' => 'Ожидался POST-запрос.'], 405);
}
$raw = (string) file_get_contents('php://input');
$data = json_decode($raw, true);
if (!is_array($data)) {
    rv_json(['ok' => false, 'error' => 'Не разобран JSON запроса.'], 400);
}
$token = (string) ($data['token'] ?? '');
if (!rv_token_valid($token)) {
    rv_json(['ok' => false, 'error' => 'Неверный номер задачи.'], 400);
}
$paths = rv_paths($token);
$job = rv_read_json($paths['job']);
if ($job === null) {
    rv_json(['ok' => false, 'error' => 'Задача не найдена или устарела.'], 404);
}
if (!rv_can_access($job)) {
    rv_json(['ok' => false, 'error' => 'Эта задача принадлежит другому пользователю.'], 403);
}
[$state] = rv_state($token, $job);
if ($state !== 'done') {
    rv_json(['ok' => false, 'error' => 'РВ ещё строится или не построена — проверять пока нечего.'], 409);
}
if (!is_file($paths['json'])) {
    rv_json(['ok' => false, 'error' => 'Результат задачи не найден на сервере.'], 404);
}

const RV_FEEDBACK_MAX = 5000;
const RV_ROLES = ['В', 'С-В', 'С-С', 'Р', 'Кр'];

$corrections = [];
foreach ((array) ($data['corrections'] ?? []) as $fix) {
    if (!is_array($fix)) {
        continue;
    }
    $id = (int) ($fix['id'] ?? 0);
    $code = trim((string) ($fix['code'] ?? ''));
    $role = trim((string) ($fix['role'] ?? ''));
    if ($role === '?' || $role === '—') {
        $role = '';     // агент не определил роль строки — исправление роль не меняет, память решений подставит «В»
    }
    $coefRaw = $fix['coef'] ?? null;
    $coef = null;
    if ($coefRaw !== null && $coefRaw !== '') {
        $coefText = str_replace([',', ' '], ['.', ''], (string) $coefRaw);
        if (!is_numeric($coefText) || (float) $coefText < 0 || (float) $coefText > 1e6) {
            rv_json(['ok' => false, 'error' => 'Строка ' . $id . ': коэффициент «' . $coefRaw . '» — нужно число от 0.'], 400);
        }
        $coef = (float) $coefText;
    }
    if ($id <= 0 || ($code === '' && $coef === null && $role === '')) {
        rv_json(['ok' => false, 'error' => 'Строка ' . $id . ': нужны работа, роль или коэффициент.'], 400);
    }
    if ($code !== '' && !preg_match('/^\d{1,3}(\.\d{1,3}){3,9}$/', $code)) {
        rv_json(['ok' => false, 'error' => 'Строка ' . $id . ': код работы «' . $code . '» не похож на код ИСР.'], 400);
    }
    if ($role !== '' && !in_array($role, RV_ROLES, true)) {
        rv_json(['ok' => false, 'error' => 'Строка ' . $id . ': неизвестная роль «' . $role . '».'], 400);
    }
    $corrections[$id] = ['id' => $id, 'code' => $code, 'role' => $role, 'coef' => $coef];
    if (($fix['via'] ?? '') === 'model') {
        // принято из предложений модели кнопкой «Принять предложения модели»: в РВ с указаниями только для неё
        // такое в общую память агента не идёт (web_rv_run, rv_learning.decisions_from_feedback)
        $corrections[$id]['via'] = 'model';
    }
    if (count($corrections) > RV_FEEDBACK_MAX) {
        rv_json(['ok' => false, 'error' => 'Слишком много исправлений за раз (предел ' . RV_FEEDBACK_MAX . ').'], 400);
    }
}
$confirmRest = !empty($data['confirm_rest']);
$workNotes = [];
foreach ((array) ($data['work_notes'] ?? []) as $code => $text) {
    $code = (string) $code;
    if (!preg_match('/^[0-9][0-9.]{0,39}$/', $code) || !is_scalar($text)) {
        continue;
    }
    $workNotes[$code] = mb_substr(trim(preg_replace('/\s+/u', ' ', (string) $text) ?? ''), 0, 500);
    if (count($workNotes) > 300) {
        rv_json(['ok' => false, 'error' => 'Слишком много примечаний к работам.'], 400);
    }
}
$splits = [];
foreach ((array) ($data['splits'] ?? []) as $id => $parts) {
    if (!is_numeric($id) || !is_array($parts)) {
        continue;
    }
    $clean = [];
    foreach ($parts as $part) {
        $code = (string) ($part['code'] ?? '');
        $qty = $part['qty'] ?? null;
        if (!preg_match('/^[0-9][0-9.]{0,39}$/', $code) || !is_numeric($qty) || (float) $qty <= 0 || count($clean) >= 10) {
            continue;
        }
        $clean[] = ['code' => $code, 'qty' => round((float) $qty, 4)];
    }
    $splits[(string) (int) $id] = $clean;
    if (count($splits) > 300) {
        rv_json(['ok' => false, 'error' => 'Слишком много разбиений строк.'], 400);
    }
}
// added_works: {код ИСР: объём} — работы без материалов, добавленные сметчиком («Добавить работу»), и объём вручную
// у работ «добавлено агентом»; 0 или пусто — убрать (web_rv_run.engineer_works).
$addedWorks = [];
foreach ((array) ($data['added_works'] ?? []) as $code => $qty) {
    $code = (string) $code;
    if (!preg_match('/^\d{1,3}(\.\d{1,3}){3,9}$/', $code)) {
        rv_json(['ok' => false, 'error' => 'Добавленная работа «' . mb_substr($code, 0, 40) . '» — не код ИСР.'], 400);
    }
    $qtyText = str_replace([',', ' '], ['.', ''], (string) ($qty ?? ''));
    if ($qtyText !== '' && (!is_numeric($qtyText) || (float) $qtyText < 0 || (float) $qtyText > 1e9)) {
        rv_json(['ok' => false, 'error' => 'Работа ' . $code . ': объём «' . mb_substr((string) $qty, 0, 20) . '» — нужно число от 0.'], 400);
    }
    $addedWorks[$code] = $qtyText === '' ? 0 : round((float) $qtyText, 4);
    if (count($addedWorks) > 200) {
        rv_json(['ok' => false, 'error' => 'Слишком много добавленных работ.'], 400);
    }
}
if (!$corrections && !$confirmRest) {
    rv_json(['ok' => false, 'error' => 'Нет ни исправлений, ни подтверждения — сохранять нечего.'], 400);
}

// Согласовать РВ можно только целиком разнесённую: у каждой строки ЛРВ — работа. Строки без работы
// закрываются исправлением с кодом работы; без этого в 1С материал остался бы вне работ.
$left = [];
foreach (rv_unbound_rows($token) as $id => $name) {
    if (($corrections[$id]['code'] ?? '') === '' && empty($splits[(string) $id])) {
        $left[$id] = $name;
    }
}
if ($left) {
    $names = array_slice(array_map(static fn($id, $name) => $name . ' (id ' . $id . ')', array_keys($left), $left), 0, 8);
    rv_json(['ok' => false, 'unbound' => array_keys($left),
             'error' => 'Согласовать нельзя: не разнесено строк — ' . count($left) . '. Назначьте каждой работу («Исправить»): '
                        . implode('; ', $names) . (count($left) > 8 ? '; …' : '') . '.'], 422);
}

$now = time();
$feedback = [
    'token' => $token,
    'user' => (string) ($_SESSION['kb_user'] ?? ''),
    'when' => $now,
    'corrections' => array_values($corrections),
    'confirm_rest' => $confirmRest,
    'work_notes' => $workNotes,
    'splits' => $splits,
    'added_works' => $addedWorks,
];
if (file_put_contents($paths['feedback'], json_encode($feedback, JSON_UNESCAPED_UNICODE)) === false) {
    rv_json(['ok' => false, 'error' => 'Не удалось сохранить проверку на сервере.'], 500);
}
file_put_contents($paths['status'], json_encode([
    'state' => 'running',
    'stage' => 'записываю решения инженера и строю РВ заново…',
    'started' => $now,
    'updated' => $now,
    'launched' => false,
], JSON_UNESCAPED_UNICODE));
$job['feedback'] = $now;
$job['feedback_rounds'] = (int) ($job['feedback_rounds'] ?? 0) + 1;
file_put_contents($paths['job'], json_encode($job, JSON_UNESCAPED_UNICODE));

rv_launch(['--phase', 'bind', '--status-file', $paths['status'], '--work-file', $paths['work'],
           '--out-xlsx', $paths['xlsx'], '--out-json', $paths['json'],
           '--credentials', ANTHROPIC_CREDENTIALS_FILE, '--learning-file', RV_LEARNING_FILE,
           '--feedback-file', $paths['feedback'], '--no-review', '--user', $feedback['user'],
           '--source-name', (string) ($job['source_name'] ?? '')]);

rv_json(['ok' => true, 'corrections' => count($corrections), 'confirm_rest' => $confirmRest,
         'redirect' => 'rv_status.php?token=' . urlencode($token)]);
