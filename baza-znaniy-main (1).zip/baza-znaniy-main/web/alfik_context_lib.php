<?php
declare(strict_types=1);

require_once __DIR__ . '/structure_lib.php';

/**
 * Контекст Альфика строится только на сервере из текущей сессии.
 * Это данные интерфейса, а не разрешение выполнять действия: обработчики
 * инструментов продолжают проверять доступ через auth_guard.php.
 */
function alfik_session_context(): ?array
{
    $login = (string) ($_SESSION['kb_user'] ?? '');
    if ($login === '') {
        return null;
    }

    $role = (string) ($_SESSION['kb_role'] ?? ROLE_USER);
    if (!in_array($role, VALID_ROLES, true)) {
        $role = ROLE_USER;
    }
    $department = current_department();
    $roleNames = [
        ROLE_USER => 'Сотрудник',
        ROLE_ADMIN => 'Администратор',
        ROLE_MAINADMIN => 'Главный администратор',
    ];
    $modules = [];
    $tools = [];
    foreach (kb_structure_all() as $module) {
        if (!kb_can_open_module($module)) {
            continue;
        }
        $moduleId = (string) $module['id'];
        $modules[] = [
            'id' => $moduleId,
            'name' => (string) ($module['nav'] ?? $module['title'] ?? $moduleId),
        ];
        foreach ((array) ($module['tools'] ?? []) as $tool) {
            $href = (string) ($tool['href'] ?? '');
            $path = parse_url($href, PHP_URL_PATH);
            // Только локальные страницы инструментов; параметры режима сохраняем.
            if (!is_string($path) || !preg_match('/^[a-zA-Z0-9_]+\\.php$/D', $path)
                || strpos($href, '//') !== false || !kb_can_open_page($path)) {
                continue;
            }
            if (!isset($tools[$href])) {
                $tools[$href] = [
                    'name' => (string) ($tool['name'] ?? ''),
                    'href' => $href,
                    'description' => (string) ($tool['text'] ?? ''),
                    'moduleIds' => [],
                ];
            }
            if (!in_array($moduleId, $tools[$href]['moduleIds'], true)) {
                $tools[$href]['moduleIds'][] = $moduleId;
            }
        }
    }

    return [
        'version' => 1,
        'department' => [
            'code' => $department,
            'name' => department_label($department),
        ],
        'role' => ['code' => $role, 'name' => $roleNames[$role]],
        'permissions' => [
            'manageUsers' => is_admin_tier_role($role),
            'viewPlans' => kb_can_see_plans($login),
        ],
        'modules' => $modules,
        'tools' => array_values($tools),
    ];
}


/** Подсказки ПТО доступны ПТО и Дирекции; mainadmin — независимо от отдела. */
function alfik_pto_hints(?array $context, string $page, string $mode = ''): ?array
{
    if ($context === null || (!in_array($context['department']['code'] ?? null, ['PTO', 'DR'], true)
        && ($context['role']['code'] ?? null) !== ROLE_MAINADMIN)) {
        return null;
    }
    $guides = [
        'ventspec.php' => [
            'title' => 'Как работать с VentSpec',
            'text' => 'Обработка спецификации ОВ и сравнение позиций с 1С.',
            'steps' => [
                'Загрузите Excel-спецификацию в верхнюю форму.',
                'Выберите режим: полная обработка, сравнение с 1С или расчёт площади фасонных изделий.',
                'Если исходник в PDF, сначала получите Excel в нижней форме, проверьте его и загрузите в верхнюю.',
            ],
        ],
        'verrata.php' => [
            'title' => 'Как сравнить ревизии в Verrata',
            'text' => 'Найдите изменения между редакциями одного комплекта РД.',
            'steps' => [
                'Выберите раздел проекта и приложите PDF-редакции одного комплекта.',
                'Проверьте имена файлов: исходная редакция без «изм.», изменения — с их номерами.',
                'При необходимости приложите наряд-заказы и выберите доступный режим обработки.',
            ],
        ],
        'equipment.php' => [
            'title' => 'Как сверить марки вентиляторов',
            'text' => 'Сопоставьте ХСОВ, спецификацию и листы подбора.',
            'steps' => [
                'Загрузите полный PDF-альбом проекта: программа сама найдёт нужные листы.',
                'Нажмите «Сверить марки вентиляторов».',
                'Проверьте Excel-отчёт: красным отмечены расхождения, жёлтым — неполные данные.',
            ],
        ],
        'area' => [
            'title' => 'Как рассчитать площадь',
            'text' => 'Расчёт площади воздуховодов и фасонных изделий без базы 1С.',
            'steps' => [
                'Подготовьте Excel со столбцами «Наименование» и «Площадь».',
                'Если исходник в PDF, получите Excel через конвертер и проверьте распознанные позиции.',
                'Загрузите Excel в верхнюю форму и нажмите «Рассчитать площадь»: конвертация PDF сама по себе расчёт не выполняет.',
            ],
        ],
        'wasser' => [
            'title' => 'Как работать с WasserSpec',
            'text' => 'Перенос PDF-спецификации ВК в Excel. Поддержка частичная.',
            'steps' => [
                'Загрузите PDF-спецификацию ВК в форму «Конвертер спецификаций».',
                'Нажмите «Получить Excel из PDF».',
                'Проверьте полученные позиции и числа по исходному PDF перед дальнейшей работой.',
            ],
        ],
    ];
    $tools = [];
    $current = null;
    $currentHref = null;
    foreach ($context['tools'] as $tool) {
        if (!in_array('pto', $tool['moduleIds'], true)) {
            continue;
        }
        $path = (string) parse_url($tool['href'], PHP_URL_PATH);
        $query = [];
        parse_str((string) parse_url($tool['href'], PHP_URL_QUERY), $query);
        $key = $path === 'area.php' ? (($query['tool'] ?? '') === 'wasser' ? 'wasser' : 'area') : $path;
        if (!isset($guides[$key])) {
            continue;
        }
        $guide = $guides[$key];
        $tools[] = ['name' => $tool['name'], 'href' => $tool['href'], 'text' => $guide['text'], 'title' => $guide['title'], 'steps' => $guide['steps']];
        $pageKey = $page === 'area.php' ? ($mode === 'wasser' ? 'wasser' : 'area') : $page;
        if ($key === $pageKey) {
            $current = $guide;
            $currentHref = $tool['href'];
        }
    }
    if (!$tools) {
        return null;
    }
    return [
        'title' => $current['title'] ?? 'Подсказки для ПТО',
        'text' => $current['text'] ?? 'Выберите задачу — я помогу найти подходящий инструмент.',
        'steps' => $current['steps'] ?? [],
        'tools' => $tools,
        'selectedHref' => $currentHref,
    ];
}
