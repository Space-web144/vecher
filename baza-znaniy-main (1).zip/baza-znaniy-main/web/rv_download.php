<?php
declare(strict_types=1);

// Отдаёт готовую РВ (xlsx), результат агента в JSON (json), РВ для 1С (onec) — ровно тот JSON, который 1С
// забирает по API (1c_rv.php?file=json) — или пакет, как его прислала 1С (in): для проверки и для программиста 1С.
// Задачу своей видит автор, ЛРВ из 1С — все, у кого есть доступ к РВ (rv_can_access).

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require_once __DIR__ . '/users.php';
require_once __DIR__ . '/lib.php';
require_once __DIR__ . '/rv_lib.php';

rv_guard();

$token = (string) ($_GET['token'] ?? '');
$kind = (string) ($_GET['kind'] ?? 'xlsx');
if (!rv_token_valid($token) || !in_array($kind, ['xlsx', 'json', 'onec', 'in'], true)) {
    rv_fail('Неверный запрос.');
}
$paths = rv_paths($token);
$job = rv_read_json($paths['job']);
if ($job === null) {
    rv_fail('Задача не найдена или устарела.', 404);
}
if (!rv_can_access($job)) {
    rv_fail('Эта задача принадлежит другому пользователю.', 403);
}
$path = $paths[$kind];
if (!is_file($path)) {
    rv_fail('Файл ещё не готов или удалён.', 404);
}
$base = sanitize_display_base(pathinfo((string) ($job['source_name'] ?? 'ЛРВ'), PATHINFO_FILENAME));
$ext = $kind === 'xlsx' ? 'xlsx' : 'json';
$prefix = ['onec' => 'РВ для 1С ', 'in' => 'Пакет из 1С '][$kind] ?? 'РВ ';
$name = trim($prefix . (string) ($job['section'] ?? '') . ' ' . $base) . '.' . $ext;
header('Content-Type: ' . ($kind === 'xlsx'
    ? 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    : 'application/json; charset=utf-8'));
header('Content-Disposition: attachment; filename="' . (['onec' => 'rv_1c', 'in' => 'packet_1c'][$kind] ?? 'rv') . '.' . $ext . '"; filename*=UTF-8\'\'' . rawurlencode($name));
header('X-Content-Type-Options: nosniff');
if ($kind === 'onec') {
    $enriched = rv_onec_json_enriched($path, $job);     // как отдаёт 1С: старый файл — с полями связи из задачи
    if ($enriched !== null) {
        header('Content-Length: ' . (string) strlen($enriched));
        echo $enriched;
        exit;
    }
}
if (substr($path, -3) === '.gz') {
    readgzfile($path);     // на сервере результат хранится сжатым — отдаём обычный JSON
    exit;
}
header('Content-Length: ' . (string) filesize($path));
readfile($path);
