<?php
declare(strict_types=1);

require __DIR__ . '/auth_guard.php';
require_once __DIR__ . '/design.php';
require_once __DIR__ . '/developer_feedback_lib.php';

if (!kb_can_open_page('admin_developer_feedback.php')) {
    http_response_code(403);
    exit('Доступ запрещён.');
}

header('Cache-Control: no-store');
$entries = developer_feedback_entries();
$moscow = new DateTimeZone('Europe/Moscow');
?>
<!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Обращения — База знаний</title>
  <link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
  <link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
  <?= design_refresh_css() ?>
  <script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
</head>
<body>
<div class="shell">
  <?php require __DIR__ . '/sidebar.php'; ?>
  <main class="dashboard-main">
    <div class="page">
      <div class="card">
        <h1>Обращения</h1>
        <?php if (!$entries->valid()): ?>
          <p>Обращений пока нет.</p>
        <?php endif; ?>
      </div>
      <?php foreach ($entries as $entry): ?>
        <?php $received = (new DateTimeImmutable('@' . $entry['time']))->setTimezone($moscow); ?>
        <article class="card">
          <h2><?= kb_e($entry['user']) ?></h2>
          <p class="hint">Отдел: <?= kb_e($entry['department']) ?> · <time datetime="<?= $received->format(DATE_ATOM) ?>"><?= $received->format('d.m.Y H:i') ?> МСК</time></p>
          <p style="white-space: pre-wrap; overflow-wrap: anywhere;"><?= kb_e($entry['message']) ?></p>
        </article>
      <?php endforeach; ?>
    </div>
  </main>
</div>
</body>
</html>
