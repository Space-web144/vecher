<?php
declare(strict_types=1);

require __DIR__ . '/auth_guard.php';
require_once __DIR__ . '/users.php';
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Area — База знаний</title>
<link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
<script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
<script src="assets/dropzone.js?v=<?= filemtime(__DIR__ . '/assets/dropzone.js') ?>" defer></script>
</head>
<body>
<div class="shell">
  <?php require __DIR__ . '/sidebar.php'; ?>

  <div class="dashboard-main">
  <div class="page">

  <div class="card">
    <h1>Расчёт площади</h1>
    <p class="subtitle">Загрузите файл со списком позиций (столбцы «Наименование» и «Площадь») — площадь воздуховодов и фасонных изделий будет посчитана и проставлена в столбец «Площадь». База 1С не требуется.</p>

    <form action="process.php" method="post" enctype="multipart/form-data">
      <div class="field">
        <label class="field-label" for="spec_file">Файл со списком позиций (.xlsx)</label>
        <input type="file" id="spec_file" name="spec_file" accept=".xlsx,.xls" required>
      </div>
      <input type="hidden" name="mode" value="area">

      <button type="submit">Рассчитать площадь</button>
    </form>
  </div>

  <div class="card">
    <h2>Конвертер спецификаций</h2>
    <p class="subtitle">Загрузите PDF-спецификацию («Спецификация оборудования и материалов») — позиции из таблицы соберутся в Excel со столбцами «Наименование» и «Площадь», то есть в том виде, который понимает расчёт выше. Шаблон альбома определяется автоматически: поддерживаются все четыре, что умеют конвертеры сайта, — три вентиляционных (ОВ) и спецификация ВК. Сам расчёт в этот шаг не входит: проверьте распознанные позиции и загрузите полученный файл в форму расчёта.</p>

    <form action="process_pdf.php" method="post" enctype="multipart/form-data">
      <div class="field">
        <label class="field-label" for="pdf_file">Файл спецификации (.pdf)</label>
        <input type="file" id="pdf_file" name="pdf_file" accept=".pdf" required>
      </div>
      <input type="hidden" name="format" value="area">

      <button type="submit" class="secondary">Получить Excel из PDF</button>
    </form>
  </div>

  </div>
  </div>
</div>
</body>
</html>
