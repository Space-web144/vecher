<?php
declare(strict_types=1);

// Подтверждение разметки ЛРВ: инженер проверил, какие заголовки групп
// задают систему и элемент (страница rv_status.php в состоянии
// awaiting_confirm), — сохраняем его разметку в файл работы и запускаем
// вторую фазу агента (привязка, проверка, книга Excel).

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require_once __DIR__ . '/users.php';
require_once __DIR__ . '/lib.php';
require_once __DIR__ . '/rv_lib.php';

rv_guard();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    rv_fail('Ожидался POST-запрос.', 405);
}
$token = (string) ($_POST['token'] ?? '');
if (!rv_token_valid($token)) {
    rv_fail('Неверный номер задачи.');
}
$paths = rv_paths($token);
$job = rv_read_json($paths['job']);
if ($job === null) {
    rv_fail('Задача не найдена или устарела.', 404);
}
if (!rv_can_access($job)) {
    rv_fail('Эта задача принадлежит другому пользователю.', 403);
}
[$state] = rv_state($token, $job);
if ($state !== 'awaiting_confirm') {
    header('Location: rv_status.php?token=' . urlencode($token));
    exit;
}
$work = rv_read_json($paths['work']);
if ($work === null) {
    rv_fail('Прочитанная ЛРВ не найдена — загрузите файл заново.', 404);
}

$headers = (array) ($work['headers'] ?? []);
$kinds = (array) ($_POST['kind'] ?? []);
$systemsPost = (array) ($_POST['system'] ?? []);
$elementsPost = (array) ($_POST['element'] ?? []);

$marks = [];
foreach ($headers as $index => $header) {
    $kind = (string) ($kinds[$index] ?? 'other');
    if ($kind === 'system') {
        $pair = rv_system_split(trim((string) ($systemsPost[$index] ?? '')));
        if ($pair === null) {
            rv_fail('Для заголовка «' . (string) ($header['text'] ?? '') . '» выбрана неизвестная система.');
        }
        $marks[(string) $index] = ['kind' => 'system', 'section' => $pair[0], 'system' => $pair[1], 'confidence' => 1.0,
                                   'by' => 'инженер'];
    } elseif ($kind === 'element') {
        $element = trim((string) ($elementsPost[$index] ?? ''));
        if ($element === '') {
            $element = (string) ($header['text'] ?? '');
        }
        $marks[(string) $index] = ['kind' => 'element', 'element' => mb_substr($element, 0, 80)];
    } elseif ($kind === 'skip') {
        $marks[(string) $index] = ['kind' => 'skip', 'reason' => mb_substr((string) ($header['text'] ?? ''), 0, 80)];
    } else {
        $marks[(string) $index] = ['kind' => 'other'];
    }
}
$default = trim((string) ($_POST['default_system'] ?? ''));
if ($default !== '' && rv_system_split($default) === null) {
    rv_fail('Система по умолчанию выбрана неверно.');
}

// Заказ-наряд: сметчик выбирает, по какому коду работ собирать РВ — ДР (код 6) или РВР (код 12).
if (!empty($work['ask_code_root'])) {
    $codeRoot = rv_code_root_of($_POST['code_root'] ?? '');
    if ($codeRoot === '') {
        rv_fail('Выберите вид заказ-наряда: ДР (работы кода 6) или РВР (работы кода 12).');
    }
    $job['code_root'] = $codeRoot;
    $job['code_root_by'] = (string) ($_SESSION['kb_user'] ?? '');
    $job['code_root_at'] = time();
}

$work['marks'] = (object) $marks;   // объект, не список: ключи — индексы заголовков
$work['default_system'] = $default !== '' ? $default : null;
$work['confirmed'] = time();
file_put_contents($paths['work'], json_encode($work, JSON_UNESCAPED_UNICODE));

$now = time();
file_put_contents($paths['status'], json_encode([
    'state' => 'running',
    'stage' => 'привязываю строки к работам…',
    'started' => $now,
    'updated' => $now,
    'launched' => false,
], JSON_UNESCAPED_UNICODE));
$job['confirmed'] = $now;
file_put_contents($paths['job'], json_encode($job, JSON_UNESCAPED_UNICODE));

rv_launch(['--phase', 'bind', '--status-file', $paths['status'], '--work-file', $paths['work'],
           '--out-xlsx', $paths['xlsx'], '--out-json', $paths['json'],
           '--credentials', ANTHROPIC_CREDENTIALS_FILE, '--learning-file', RV_LEARNING_FILE, '--notes-file', RV_NOTES_FILE]);

header('Location: rv_status.php?token=' . urlencode($token));
exit;
