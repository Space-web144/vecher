<?php
declare(strict_types=1);

// Удаление РВ (своих и присланных из 1С — их видят все, у кого есть доступ к РВ): одной (кнопка в строке списка или на странице РВ) или
// отмеченных в списке «Мои РВ». Удаляются все файлы задачи на сервере —
// книга, результат, строки формы, проверка, файлы хода. Задачу, которая ещё
// строится, удалить нельзя: процесс дописал бы файлы уже без карточки.
// Память решений инженеров (RV_LEARNING_FILE) остаётся: исправления и
// подтверждения из удалённой РВ агент продолжает применять.

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require_once __DIR__ . '/users.php';
require_once __DIR__ . '/lib.php';
require_once __DIR__ . '/rv_lib.php';

rv_guard();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: rv.php');
    exit;
}
if (!hash_equals(rv_csrf(), (string) ($_POST['csrf'] ?? ''))) {
    header('Location: rv.php?err=' . urlencode('Сессия истекла — обновите страницу и повторите.'));
    exit;
}

$tokens = array_values(array_unique(array_map('strval', (array) ($_POST['tokens'] ?? []))));
$deleted = 0;
$busy = 0;
foreach ($tokens as $token) {
    if (!rv_token_valid($token)) {
        continue;
    }
    $job = rv_read_json(rv_paths($token)['job']);
    if ($job === null || !rv_can_access($job)) {
        continue;                       // чужие и уже удалённые — молча мимо
    }
    [$state] = rv_state($token, $job);
    if ($state === 'running') {
        $busy++;
        continue;
    }
    rv_delete_job($token);
    $deleted++;
}

$query = ['deleted' => $deleted];
if ($busy) {
    $query['busy'] = $busy;
}
header('Location: rv.php?' . http_build_query($query));
exit;
