<?php
declare(strict_types=1);

// Блок «Сверка с РВ из 1С» страницы РВ (rv_status.php) — для задач сверки (job mode = audit, 1c_rv.php):
// сводка; строки, где разнос в 1С и у агента расходится, — с работой из 1С, работой агента, вердиктом модели
// и выбором инженера «прав 1С / прав агент / как модель» (rv_audit_decide.php → память агента);
// объёмы работ 1С против агента; строки, которые в 1С не разнесены. Данные — result['audit']
// (web_rv_run.py, rv_audit.py). Подключается из rv_status.php: есть $token, $paths, $job.

if (!isset($token, $paths, $job)) {
    http_response_code(404);
    exit;
}
$auditResult = rv_read_packed($paths['json']);
$audit = is_array($auditResult['audit'] ?? null) ? $auditResult['audit'] : null;
$decisions = (array) ($job['audit_decisions'] ?? []);
$auditShow = (string) ($_GET['a'] ?? 'open');
$sideText = ['1c' => 'права 1С', 'agent' => 'прав агент', 'other' => 'обе неверны', 'question' => 'вопрос'];
$choiceText = ['1c' => 'прав 1С', 'agent' => 'прав агент', 'model' => 'как модель'];
$workStatus = ['match' => 'совпадает', 'volume' => 'объём расходится', 'only_1c' => 'только в 1С',
               'only_agent' => 'только у агента', 'not_isr' => 'в 1С без кода ИСР'];

/** Работы 1С строки: «код — работа (кол-во)» построчно. */
function rv_audit_c1(array $works): string
{
    $out = [];
    foreach ($works as $work) {
        $qty = isset($work['qty']) && $work['qty'] !== null ? ' <span class="muted-dash">(' . rv_h(rtrim(rtrim(number_format((float) $work['qty'], 3, ',', ' '), '0'), ',')) . ')</span>' : '';
        $out[] = '<span class="rv-audit-code">' . rv_h((string) ($work['code'] ?: 'без кода ИСР')) . '</span> ' . rv_h(mb_substr((string) ($work['name'] ?? ''), 0, 90)) . $qty;
    }
    return $out ? implode('<br>', $out) : '—';
}

/** Число объёма для таблицы. */
function rv_audit_num($value): string
{
    return $value === null ? '—' : rtrim(rtrim(number_format((float) $value, 3, ',', ' '), '0'), ',');
}
?>
  <div class="card rv-audit" id="audit">
    <h2>Сверка с РВ из 1С</h2>
    <?php if ($audit === null): ?>
    <p class="hint">Результат сверки не найден — задача строилась без данных 1С о разносе.</p>
    <?php else: ?>
    <?php
      $s = (array) ($audit['summary'] ?? []);
      $rows = (array) ($audit['rows'] ?? []);
      $disputed = array_values(array_filter($rows, static fn(array $r): bool => in_array($r['status'] ?? '', ['differ', 'agent_none'], true)));
      // Без решения — расхождения, по которым инженер ещё не выбирал; решённые — строки с решением (после пересборки
      // строка с решением «прав 1С» уже совпадает, «прав агент» — остаётся расхождением с 1С).
      $open = array_values(array_filter($disputed, static fn(array $r): bool => !isset($decisions[(string) $r['id']])));
      $decidedRows = array_values(array_filter($rows, static fn(array $r): bool => isset($decisions[(string) $r['id']])));
      $listed = $auditShow === 'all' ? array_merge($open, $decidedRows) : ($auditShow === 'decided' ? $decidedRows : $open);
      $noOnec = array_values(array_filter($rows, static fn(array $r): bool => ($r['status'] ?? '') === 'no_1c'));
      $notIsr = array_values(array_filter($rows, static fn(array $r): bool => ($r['status'] ?? '') === 'not_isr'));
      $works = array_values(array_filter((array) ($audit['works'] ?? []), static fn(array $w): bool => ($w['status'] ?? '') !== 'match'));
      $model = (array) ($s['model'] ?? []);
    ?>
    <p class="subtitle">Агент заново разнёс строки ЛРВ этой сметы и сравнил с тем, как их разнесли в 1С<?= !empty($audit['doc']) ? ' (' . rv_h((string) $audit['doc']) . ')' : '' ?>. Модель смотрела только расхождения. Отметьте, кто прав: решение уходит в память агента — он запомнит верную работу для таких строк.</p>
    <div class="rv-figures">
      <div class="<?= ($s['match_pct'] ?? 100) >= 90 ? 'is-done' : 'is-review' ?>"><b><?= ($s['match_pct'] ?? null) === null ? '—' : rv_h((string) $s['match_pct']) . '%' ?></b><span>строк совпадает (<?= (int) ($s['match'] ?? 0) ?> из <?= (int) ($s['match'] ?? 0) + (int) ($s['disputed'] ?? 0) ?>)</span></div>
      <div class="<?= $open ? 'is-question' : 'is-done' ?>"><b><?= count($disputed) ?></b><span>расхождений, без решения <?= count($open) ?></span></div>
      <div><b><?= (int) ($model['1c'] ?? 0) ?> / <?= (int) ($model['agent'] ?? 0) ?></b><span>модель: права 1С / прав агент<?= !empty($model['other']) ? ', обе неверны ' . (int) $model['other'] : '' ?></span></div>
      <div class="<?= count($noOnec) ? 'is-review' : '' ?>"><b><?= count($noOnec) ?></b><span>строк в 1С не разнесено</span></div>
      <div class="<?= count($works) ? 'is-review' : '' ?>"><b><?= (int) ($s['works_volume'] ?? 0) ?></b><span>работ с другим объёмом; только в 1С <?= (int) ($s['works_only_1c'] ?? 0) ?>, только у агента <?= (int) ($s['works_only_agent'] ?? 0) ?></span></div>
    </div>

    <h3>Расхождения</h3>
    <p class="rv-audit-tabs">
      <a href="rv_status.php?token=<?= rv_h($token) ?>&amp;a=open#audit"<?= $auditShow === 'open' ? ' class="is-active"' : '' ?>>без решения (<?= count($open) ?>)</a>
      <a href="rv_status.php?token=<?= rv_h($token) ?>&amp;a=decided#audit"<?= $auditShow === 'decided' ? ' class="is-active"' : '' ?>>решённые (<?= count($decidedRows) ?>)</a>
      <a href="rv_status.php?token=<?= rv_h($token) ?>&amp;a=all#audit"<?= $auditShow === 'all' ? ' class="is-active"' : '' ?>>все (<?= count($open) + count($decidedRows) ?>)</a>
      <a href="rv_audit.php?token=<?= rv_h($token) ?>&amp;csv=1">скачать сверку (CSV)</a>
    </p>
    <?php if (!$listed): ?>
    <p class="hint"><?= $disputed || $decidedRows ? 'Здесь пусто — смотрите другие вкладки.' : 'Расхождений нет: агент разнёс строки так же, как в 1С.' ?></p>
    <?php else: ?>
    <form action="rv_audit_decide.php" method="post">
      <input type="hidden" name="csrf" value="<?= rv_h(rv_csrf()) ?>">
      <input type="hidden" name="token" value="<?= rv_h($token) ?>">
      <div class="table-wrap">
      <table class="data-table rv-audit-table">
        <thead><tr><th>Строка ЛРВ</th><th>В 1С</th><th>Агент</th><th>Модель</th><th>Кто прав</th></tr></thead>
        <tbody>
        <?php foreach ($listed as $row): ?>
          <?php $id = (string) $row['id']; $m = is_array($row['model'] ?? null) ? $row['model'] : null; $d = $decisions[$id] ?? null;
                $agent = (array) ($row['agent'] ?? []); ?>
          <tr>
            <td data-label="Строка ЛРВ"><?= rv_h((string) $row['name']) ?><br><span class="muted-dash"><?= rv_h(rv_audit_num($row['qty'] ?? null) . ' ' . (string) ($row['unit'] ?? '')) ?><?= !empty($row['element']) ? ' · ' . rv_h((string) $row['element']) : '' ?></span></td>
            <td data-label="В 1С"><?= rv_audit_c1((array) ($row['c1'] ?? [])) ?></td>
            <td data-label="Агент"><?php if (!empty($agent['code'])): ?><span class="rv-audit-code"><?= rv_h((string) $agent['code']) ?></span> <?= rv_h(mb_substr((string) ($agent['work'] ?? ''), 0, 90)) ?><br><span class="muted-dash"><?= rv_h((string) ($agent['role'] ?? '')) ?><?= isset($agent['confidence']) ? ', ' . (int) round((float) $agent['confidence'] * 100) . '%' : '' ?><?= !empty($agent['learned']) ? ', по решению инженера' : '' ?></span><?php else: ?>не нашёл работу<?php endif; ?></td>
            <td data-label="Модель"><?php if ($m): ?><b><?= rv_h($sideText[$m['side']] ?? '') ?></b><?php if ($m['side'] === 'other' && !empty($m['code'])): ?>: <span class="rv-audit-code"><?= rv_h((string) $m['code']) ?></span> <?= rv_h(mb_substr((string) ($m['work'] ?? ''), 0, 80)) ?><?php endif; ?><?php if (!empty($m['reason'])): ?><br><span class="muted-dash"><?= rv_h(mb_substr((string) $m['reason'], 0, 300)) ?></span><?php endif; ?><?php else: ?><span class="muted-dash">не смотрела</span><?php endif; ?></td>
            <td data-label="Кто прав" class="rv-audit-choice">
              <?php if ($d): ?><span class="home-status is-done"><?= rv_h($choiceText[$d['choice']] ?? '') ?></span><br><span class="muted-dash"><?= rv_h((string) ($d['user'] ?? '')) ?>, <?= rv_h(rv_when((int) ($d['at'] ?? 0))) ?></span><br><?php endif; ?>
              <?php if (!empty($row['c1_main'])): ?><label><input type="radio" name="d[<?= rv_h($id) ?>]" value="1c"> 1С</label><?php endif; ?>
              <?php if (!empty($agent['code'])): ?><label><input type="radio" name="d[<?= rv_h($id) ?>]" value="agent"> агент</label><?php endif; ?>
              <?php if ($m && $m['side'] === 'other' && !empty($m['code'])): ?><label><input type="radio" name="d[<?= rv_h($id) ?>]" value="model"> модель</label><?php endif; ?>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      </div>
      <div class="rv-audit-save">
        <button type="submit">Сохранить решения</button>
        <span class="muted-dash">Отмеченные строки уйдут в память агента, РВ пересоберётся (модель заново не спрашивается). Неотмеченные остаются как есть.</span>
      </div>
    </form>
    <?php endif; ?>

    <?php if ($works): ?>
    <details class="rv-sample" open>
      <summary>Объёмы работ: 1С против агента (<?= count($works) ?> с расхождением)</summary>
      <div class="table-wrap"><table class="data-table rv-smeta-works">
        <thead><tr><th>Код ИСР</th><th>Работа</th><th>Ед.</th><th class="num">В 1С</th><th class="num">У агента</th><th>Итог</th></tr></thead>
        <tbody>
        <?php foreach ($works as $work): ?>
          <tr><td class="rv-smeta-code"><?= rv_h((string) ($work['code'] ?: '—')) ?></td><td><?= rv_h((string) ($work['name'] ?? '')) ?></td><td><?= rv_h((string) ($work['unit'] ?? '')) ?></td>
            <td class="num"><?= rv_h(rv_audit_num($work['vol_1c'] ?? null)) ?></td><td class="num"><?= rv_h(rv_audit_num($work['vol_agent'] ?? null)) ?></td>
            <td><?= rv_h($workStatus[$work['status']] ?? (string) $work['status']) ?></td></tr>
        <?php endforeach; ?>
        </tbody>
      </table></div>
    </details>
    <?php endif; ?>

    <?php if ($noOnec): ?>
    <details class="rv-sample">
      <summary>В 1С не разнесено (<?= count($noOnec) ?>) — строки ЛРВ без сопоставления с работой</summary>
      <div class="table-wrap"><table class="data-table">
        <thead><tr><th>Строка ЛРВ</th><th>Количество</th><th>Агент</th></tr></thead>
        <tbody>
        <?php foreach ($noOnec as $row): $agent = (array) ($row['agent'] ?? []); ?>
          <tr><td><?= rv_h((string) $row['name']) ?></td><td><?= rv_h(rv_audit_num($row['qty'] ?? null) . ' ' . (string) ($row['unit'] ?? '')) ?></td>
            <td><?= !empty($agent['code']) ? '<span class="rv-audit-code">' . rv_h((string) $agent['code']) . '</span> ' . rv_h(mb_substr((string) ($agent['work'] ?? ''), 0, 90)) : 'не нашёл работу' ?></td></tr>
        <?php endforeach; ?>
        </tbody>
      </table></div>
    </details>
    <?php endif; ?>
    <?php if ($notIsr): ?>
    <p class="hint">Строк, разнесённых в 1С на работы без кода ИСР (не из классификатора), — <?= count($notIsr) ?>: сравнить их нельзя.</p>
    <?php endif; ?>
    <?php endif; ?>
  </div>
