<?php
declare(strict_types=1);

// Назначение ответственного сметчика.
// Правило: ответственный — тот, кто отправил ЛРВ на сайт из 1С («Отправил» в пакете, логин через rv_onec_login).
// Руководитель может поверх этого:
//   level=smeta — назначить другого на конкретную РВ (smeta_id = ИдентификаторЛРВ, user; пусто — снять назначение);
//   level=onec  — сопоставить пользователя 1С с логином сайта (onec = имя в 1С, user; пусто — снять).
// Старые уровни folder / object / system (дерево rv_registry.php, пакеты без «Отправил») оставлены как были.
// Уровни smeta и onec — только руководитель (rv_can_assign или rv_is_manager). На старых уровнях сотрудник ЦО
// может взять свободную ЛРВ себе или снять с себя (user = свой логин или пусто).
// Хранится в RV_ASSIGN_FILE: smetas[ИдентификаторЛРВ], onec_users[имя 1С], folders[…], objects[…], systems[…] = {user, by, at, …}.

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require_once __DIR__ . '/users.php';
require_once __DIR__ . '/lib.php';
require_once __DIR__ . '/rv_lib.php';

rv_guard();

$back = (string) ($_POST['back'] ?? '');
if ($back === '' || !preg_match('~^rv(_registry|_responsibles)?\.php(\?[\w%&=.\-]*)?$~', $back)) {
    $back = 'rv.php';
}
$go = static function (string $message, bool $ok) use ($back): never {
    header('Location: ' . $back . (strpos($back, '?') === false ? '?' : '&') . ($ok ? 'ok=' : 'err=') . rawurlencode($message));
    exit;
};

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !hash_equals(rv_csrf(), (string) ($_POST['csrf'] ?? ''))) {
    $go('Форма устарела — обновите страницу и повторите.', false);
}
$me = (string) ($_SESSION['kb_user'] ?? '');
$level = (string) ($_POST['level'] ?? '');
$folderKey = trim((string) ($_POST['folder_key'] ?? ''));
$objKey = trim((string) ($_POST['obj_key'] ?? ''));
$systemKey = trim((string) ($_POST['system_key'] ?? ''));
$user = trim((string) ($_POST['user'] ?? ''));
$smetaId = mb_substr(trim((string) ($_POST['smeta_id'] ?? '')), 0, 120);
$onecName = mb_substr(preg_replace('/\s+/u', ' ', trim((string) ($_POST['onec'] ?? ''))) ?? '', 0, 150);
$levels = ['folder' => $folderKey, 'object' => $objKey, 'system' => $objKey . '|' . $systemKey, 'smeta' => $smetaId, 'onec' => $onecName];
if (!isset($levels[$level]) || $levels[$level] === '' || $levels[$level] === '|' || ($level === 'system' && $systemKey === '')) {
    $go('Не указано, на что назначать.', false);
}
if ($user !== '' && !isset(rv_estimators()[$user])) {
    $go('Назначить можно только сотрудника ЦО.', false);
}
$key = $levels[$level];
$bucket = ['folder' => 'folders', 'object' => 'objects', 'system' => 'systems', 'smeta' => 'smetas', 'onec' => 'onec_users'][$level];
$current = (string) (rv_assignments()[$bucket][$key]['user'] ?? '');
if (in_array($level, ['smeta', 'onec'], true) && !(rv_can_assign() || rv_is_manager())) {
    $go('Менять ответственного за РВ и сопоставлять пользователей 1С может руководитель.', false);
}
if (!rv_can_assign() && !rv_is_manager()) {
    // Сметчик: взять свободную ЛРВ себе или снять с себя — чужие назначения не трогает.
    $mine = $user === $me && ($current === '' || $current === $me);
    $release = $user === '' && $current === $me;
    if (!rv_can_take() || !($mine || $release)) {
        $go('Назначать ответственных может руководитель; взять можно только свободную ЛРВ.', false);
    }
}

$ok = rv_assign_update(static function (array $data) use ($bucket, $key, $user, $me): array {
    if ($user === '') {
        unset($data[$bucket][$key]);
    } else {
        $data[$bucket][$key] = [
            'user' => $user, 'login' => $user, 'by' => $me, 'at' => time(),
            'folder' => mb_substr(trim((string) ($_POST['folder'] ?? '')), 0, 150),
            'obj' => mb_substr(trim((string) ($_POST['obj'] ?? '')), 0, 150),
            'system' => mb_substr(trim((string) ($_POST['system'] ?? '')), 0, 150),
        ];
    }
    return $data;
});
if (!$ok) {
    $go('Не удалось записать назначение на сервере.', false);
}
if ($level === 'onec') {
    $go($user === '' ? 'Сопоставление снято: ' . $onecName . ' — снова по фамилии.' : $onecName . ' → ' . rv_person_label($user) . '.', true);
}
$go($user === '' ? ($level === 'smeta' ? 'Назначение снято — ответственный снова тот, кто отправил из 1С.' : 'Ответственный снят.') : 'Ответственный: ' . rv_person_label($user) . '.', true);
