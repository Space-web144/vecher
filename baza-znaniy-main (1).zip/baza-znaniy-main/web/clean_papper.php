<?php
declare(strict_types=1);

require __DIR__ . '/clean_papper_guard.php';
require_once __DIR__ . '/design.php';
require_once __DIR__ . '/clean_papper_api_lib.php';

if (empty($_SESSION['clean_papper_csrf'])) {
    $_SESSION['clean_papper_csrf'] = bin2hex(random_bytes(24));
}
$cpCredentialsPresent = cp_credentials_file() !== '' && is_file(cp_credentials_file());
$cleanPapperCss = __DIR__ . '/assets/clean_papper.css';
?>
<!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta name="robots" content="noindex, nofollow, noarchive">
  <title>Clean Papper — База знаний</title>
  <link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
  <link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
  <?= design_refresh_css() ?>
  <link rel="stylesheet" href="assets/clean_papper.css?v=<?= filemtime($cleanPapperCss) ?>">
  <script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
  <script src="assets/clean_papper.js?v=<?= filemtime(__DIR__ . '/assets/clean_papper.js') ?>" defer></script>
  <script src="assets/clean_papper_drawing.js?v=<?= filemtime(__DIR__ . '/assets/clean_papper_drawing.js') ?>" defer></script>
  <script src="assets/clean_papper_reports.js?v=<?= filemtime(__DIR__ . '/assets/clean_papper_reports.js') ?>" defer></script>
  <script src="assets/clean_papper_vector.js?v=<?= filemtime(__DIR__ . '/assets/clean_papper_vector.js') ?>" defer></script>
  <script src="assets/clean_papper_ducts.js?v=<?= filemtime(__DIR__ . '/assets/clean_papper_ducts.js') ?>" defer></script>
  <script src="assets/clean_papper_profile.js?v=<?= filemtime(__DIR__ . '/assets/clean_papper_profile.js') ?>" defer></script>
</head>
<body>
<div class="shell">
  <?php require __DIR__ . '/sidebar.php'; ?>
  <main class="dashboard-main">
    <div class="page cp-page">
      <section class="card cp-heading" aria-labelledby="cp-heading">
        <div class="cp-eyebrow">Администрирование · Личный стенд разработки</div>
        <h1 id="cp-heading">Clean Papper</h1>
        <p class="subtitle">Анализ вентиляционных чертежей, расчёт объёмов и подготовка спецификаций.</p>
        <div class="cp-status-line">
          <span class="cp-pill cp-pill-locked">Доступ: только veryhardlogin</span>
          <span class="cp-pill">Обзор PDF-альбома</span>
        </div>
      </section>

      <section class="card cp-drawing-card" aria-labelledby="cp-drawing-heading">
        <h2 id="cp-drawing-heading">Рабочее пространство проекта</h2>
        <p class="subtitle">Один исходный PDF для спецификации, просчёта и общего отчёта.</p>
        <div class="cp-workflow-steps" aria-label="Этапы обработки">
          <div class="cp-workflow-step is-current" data-cp-step="file"><span class="cp-step-number">1</span><span>Выбор проекта</span></div>
          <div class="cp-workflow-step" data-cp-step="processing"><span class="cp-step-number">2</span><span>Обработка PDF</span></div>
          <div class="cp-workflow-step" data-cp-step="results"><span class="cp-step-number">3</span><span>Просмотр результатов</span></div>
        </div>
        <form id="cp-drawing-form" enctype="multipart/form-data" method="post" action="clean_papper_pdf.php">
          <input type="hidden" name="csrf" value="<?= htmlspecialchars((string) $_SESSION['clean_papper_csrf'], ENT_QUOTES, 'UTF-8') ?>">
          <input type="hidden" id="cp-drawing-crop" name="crop" value="">
          <input type="hidden" id="cp-profile-json" name="profile" value="">
          <section class="cp-upload-panel" aria-labelledby="cp-upload-heading">
          <h3 id="cp-upload-heading">1. Загрузка проекта</h3>
          <div class="cp-drawing-fields cp-simple-upload">
            <label class="field" for="cp-drawing-file"><span class="field-label">PDF-альбом (до 100 МБ)</span>
              <input id="cp-drawing-file" name="pdf" type="file" accept=".pdf,application/pdf" required>
            </label>
          </div>

          <p id="cp-selected-file" class="cp-selected-file">PDF пока не выбран.</p>
          <div class="cp-actions cp-primary-actions">
            <button id="cp-album-run" type="button" disabled>Обработать альбом</button>
          </div>
          <div class="cp-run-feedback" aria-live="polite">
            <progress id="cp-upload-progress" max="100" value="0" hidden aria-label="Загрузка PDF"></progress>
            <p id="cp-run-phase" class="hint">Выберите файл, чтобы начать.</p>
          </div>
          <p class="hint">Первичная обработка выполняется на сервере без отправки PDF в Claude. Распознанные страницы и размеры — кандидаты для проверки, а не утверждённые объёмы.</p>
          <p id="cp-drawing-status" class="hint cp-feedback" role="status" aria-live="polite">Выберите PDF и нажмите «Обработать альбом».</p>
          </section>
          <section id="cp-processing-monitor" class="cp-processing-monitor" hidden aria-labelledby="cp-processing-title">
            <div class="cp-monitor-head"><span class="cp-monitor-dot" aria-hidden="true"></span><strong id="cp-processing-title">Обработка</strong><span id="cp-processing-time">00:00</span></div>
            <p id="cp-processing-stage" role="status" aria-live="polite"></p>
            <progress id="cp-processing-bar" max="100" aria-label="Ход текущего этапа"></progress>
            <p id="cp-processing-heartbeat" class="hint"></p>
          </section>
          <div class="cp-main-grid">
          <section id="cp-spec-workspace" class="cp-main-panel" aria-labelledby="cp-spec-heading">
            <h3 id="cp-spec-heading">2. Спецификация → Excel</h3>
            <p class="hint">Диапазон определяется после обработки проекта.</p>
            <p id="cp-spec-register" class="hint"></p>
            <p id="cp-spec-candidates" class="hint"></p>
            <div class="cp-spec-range">
              <label for="cp-spec-first">Начальная страница PDF <input id="cp-spec-first" type="number" disabled min="1" max="600" step="1"></label>
              <label for="cp-spec-last">Последняя страница PDF <input id="cp-spec-last" type="number" disabled min="1" max="600" step="1"></label>
            </div>
            <p class="hint">Проверьте границы диапазона. До 120 страниц за запуск. Проектные количества не являются результатом обмера.</p>
            <div class="cp-actions">
              <button id="cp-spec-convert" type="button" disabled>Конвертировать в Excel</button>
              <button id="cp-spec-extract" type="button" class="secondary" disabled>Выделить PDF диапазона</button>
            </div>
            <p id="cp-spec-status" class="hint" role="status" aria-live="polite"></p>
            <div id="cp-spec-downloads" class="cp-actions"></div>
          </section>
          <section id="statement-test" class="cp-main-panel" aria-labelledby="cp-statement-heading">
            <h3 id="cp-statement-heading">3. Автоматический просчёт</h3>
            <p>Для формирования ведомости расчётных объёмов и чертежей с разметкой достаточно PDF-проекта.</p>
            <details class="cp-reference-options">
              <summary>Дополнительная сверка с готовым расчётом (необязательно)</summary>
              <p class="hint">Excel с ранее рассчитанными объёмами нужен только для сравнения. На самостоятельный просчёт PDF его отсутствие не влияет.</p>
              <label class="field">Эталон Excel (XLSX, до 2 МБ)
                <input type="file" id="cp-reference-file" accept=".xlsx">
              </label>
            </details>
            <label class="field">Заполненная ведомость для пересчёта (необязательно, XLSX до 2 МБ)
              <input type="file" id="cp-statement-review" accept=".xlsx">
            </label>
            <label class="cp-consent"><input type="checkbox" id="cp-statement-claude"> Автоматически проверять сложные листы в Claude (до 5 запросов). Разрешаю платную передачу выбранных изображений чертежей в Anthropic.</label>
            <button type="button" id="cp-statement-run">Сформировать ведомость</button>
            <div id="cp-album-totals" class="cp-results-scroll" hidden>
              <table class="cp-results-table cp-calculation-table"><caption>Подтверждённые объёмы по анализу альбома</caption><thead><tr><th scope="col">Показатель</th><th scope="col">Значение</th></tr></thead><tbody id="cp-calculation-rows"></tbody></table>
            </div>
            <p id="cp-statement-status" role="status" aria-live="polite"></p>
            <div id="cp-statement-downloads" class="cp-actions"></div>
          </section>
          <section id="cp-problem-report" class="cp-main-panel" aria-labelledby="cp-problem-heading">
            <h3 id="cp-problem-heading">4. Общий отчёт о проблемах</h3>
            <p class="hint">Замечания по загрузке, распознаванию, конвертации и расчёту в одном месте.</p>
            <p id="cp-problem-summary" role="status" aria-live="polite">Обработка ещё не запускалась.</p>
            <ul id="cp-problem-list" class="cp-problem-list"></ul>
            <div class="cp-actions">
              <button id="cp-problem-download" type="button" class="secondary" disabled>Скачать отчёт JSON</button>
            </div>
          </section>
          </div>
        </form>
        <details id="cp-other-tools" class="cp-advanced-tools cp-other-tools">
          <summary>5. Остальные инструменты</summary>
          <details id="cp-advanced-tools" class="cp-advanced-tools">
            <summary>Расширенные инструменты: страница, разметка и Claude</summary>
            <div class="cp-advanced-body">
              <label class="field" for="cp-drawing-page"><span class="field-label">Страница PDF для ручного просмотра</span>
                <input id="cp-drawing-page" name="page" type="number" min="1" max="600" step="1" value="1" required form="cp-drawing-form">
              </label>
              <label class="cp-profile-import" for="cp-album-review">Разметка участков (JSON, необязательно)
                <input id="cp-album-review" name="album_review" type="file" accept=".json,application/json" form="cp-drawing-form">
              </label>
              <div class="cp-actions">
                <button id="cp-diagnostic-run" type="button" class="secondary">Проверить локальный обработчик</button>
              </div>
              <p id="cp-diagnostic-result" class="hint cp-feedback" role="status" aria-live="polite">Проверка серверного Python и PDF ещё не запускалась.</p>
            </div>

          <details class="cp-profile" id="cp-profile-setup">
            <summary>Масштаб и геометрические допуски</summary>
            <p class="hint">При просмотре сервер подбирает профиль листа. Для расчёта длин в метрах требуется отдельная калибровка.</p>
            <div class="cp-profile-fields">
              <label>Область листа
                <select id="cp-profile-region"><option value="unknown">Не определена</option><option value="plan">План</option><option value="axonometry">Аксонометрия</option><option value="fragment">Фрагмент</option><option value="section">Разрез</option></select>
              </label>
              <label>Масштаб (не подтверждён)
                <select id="cp-profile-scale"><option value="unknown">Не определён</option><option value="1:50">1:50</option><option value="1:100">1:100</option><option value="1:200">1:200</option><option value="custom">Другой / по калибровке</option></select>
              </label>
              <label>Мин. расстояние между стенками (PDF pt)
                <input id="cp-profile-rect_min_pt" type="number" value="5" min="0.5" max="60" step=".1">
              </label>
              <label>Макс. расстояние между стенками (PDF pt)
                <input id="cp-profile-rect_max_pt" type="number" value="32" min="2" max="150" step=".1">
              </label>
              <label>Допуск соосности (PDF pt)
                <input id="cp-profile-coaxial_tol_pt" type="number" value=".06" min=".01" max=".5" step=".01">
              </label>
              <label>Объединение зазора (PDF pt)
                <input id="cp-profile-join_gap_pt" type="number" value=".05" min=".01" max="1.5" step=".01">
              </label>
              <label>Минимальный зазор пунктиров (PDF pt)
                <input id="cp-profile-dash_gap_min_pt" type="number" value="1.2" min=".2" max="15" step=".1">
              </label>
              <label>Максимальный зазор пунктиров (PDF pt)
                <input id="cp-profile-dash_gap_max_pt" type="number" value="6.5" min=".5" max="30" step=".1">
              </label>
              <label>Минимальная медиана зазоров (PDF pt)
                <input id="cp-profile-dash_median_min_pt" type="number" value="3.6" min=".2" max="20" step=".1">
              </label>
            </div>
            <div class="cp-actions">
              <button type="button" id="cp-profile-auto" class="secondary">Автоподбор</button>
              <button type="button" id="cp-profile-apply" class="secondary">Применить вручную</button>
              <button type="button" id="cp-profile-download" class="secondary">Скачать профиль JSON</button>
              <label class="cp-profile-import">Импорт профиля JSON <input type="file" id="cp-profile-import" accept="application/json,.json"></label>
            </div>
            <p id="cp-profile-status" class="hint cp-feedback" role="status">Профиль не применён.</p>
          </details>
          <div class="cp-actions">
            <button id="cp-preview-run" type="button" class="secondary">1. Предпросмотр и геометрия</button>
            <button id="cp-selection-clear" type="button" class="secondary">Сбросить фрагмент</button>
          </div>
          <p class="cp-consent">
            <label for="cp-vision-consent">
              <input id="cp-vision-consent" type="checkbox" name="vision_consent" value="yes" form="cp-drawing-form">
              Подтверждаю передачу выбранной страницы или фрагмента в Anthropic для платного анализа Claude. В документе нет данных, передачу которых я не разрешаю.
            </label>
          </p>
          <div class="cp-actions">
            <button id="cp-vision-run" type="button">2. Отправить фрагмент Claude Vision</button>
          </div>
          <p class="hint">PDF передаётся на сервер блоками по 1 МБ, собирается в закрытом временном каталоге и удаляется после обработки. При локальном предпросмотре PDF не отправляется Anthropic. После подтверждения в ИИ уходит только JPEG выбранной области, а не весь PDF. Результаты остаются в текущей странице браузера.</p>
          </details>

        <section id="cp-album-result" class="cp-integrated-analysis" aria-labelledby="cp-album-heading" hidden>
          <h3 id="cp-album-heading">Альбом проекта</h3>
          <div id="cp-album-kpis" class="cp-result-metrics" aria-label="Сводка PDF-альбома"></div>
          <p id="cp-album-review-note" class="hint"></p>
          <section id="cp-project-profile" class="cp-spec-workspace" aria-labelledby="cp-project-profile-heading" hidden>
            <h4 id="cp-project-profile-heading">Автоматический профиль проекта</h4>
            <p id="cp-project-profile-summary" class="hint"></p>
            <p id="cp-project-text-recovery" class="hint"></p>
            <ul id="cp-project-profile-warnings" class="cp-profile-warnings"></ul>
            <details class="cp-sheet-evidence">
              <summary>Проверенные форматы и выборка листов</summary>
              <p id="cp-project-profile-formats" class="hint"></p>
              <ul id="cp-project-profile-samples"></ul>
            </details>
            <div class="cp-actions">
              <button id="cp-project-profile-download" type="button" class="secondary">Скачать профиль проекта JSON</button>
            </div>
          </section>
          <section id="cp-project-rules" class="cp-spec-workspace" aria-labelledby="cp-project-rules-heading" hidden>
            <h4 id="cp-project-rules-heading">Правила расчёта из документации</h4>
            <p id="cp-rules-summary" class="hint"></p>
            <p id="cp-rules-risk" class="hint"></p>
            <ul id="cp-rules-list" class="cp-profile-warnings"></ul>
            <p class="hint">Наблюдения требуют инженерной проверки. Примечания отдельных строк не являются общими коэффициентами проекта. Никакие запасы автоматически не начисляются.</p>
            <div class="cp-actions">
              <button id="cp-rules-download" type="button" class="secondary">Скачать правила и источники JSON</button>
            </div>
          </section>
          <div id="cp-album-suggested" class="cp-album-suggested"></div>
          <div class="cp-actions">
            <button id="cp-album-download" type="button" class="secondary">Скачать технические данные альбома (JSON)</button>
            <button id="cp-album-template" type="button" class="secondary">Скачать шаблон разметки</button>
          </div>
          <div class="cp-album-toolbar">
            <label for="cp-album-filter">Тип листов
              <select id="cp-album-filter">
                <option value="recognized">Планы и аксонометрии</option>
                <option value="plan">Только планы</option>
                <option value="axonometry">Только аксонометрии</option>
                <option value="unclassified">Без классификации</option>
                <option value="all">Все листы</option>
              </select>
            </label>
            <label for="cp-album-search">Поиск по номеру или названию
              <input id="cp-album-search" type="search" placeholder="Например: 25-го этажа или В4.1-1" autocomplete="off">
            </label>
          </div>
          <p id="cp-album-visible-count" class="hint" aria-live="polite"></p>
          <div id="cp-album-pages" class="cp-sheet-list"></div>
        </section>
        <details class="cp-advanced-tools cp-technical-results" id="cp-technical-results">
          <summary>Подробный просмотр и ручная проверка трасс</summary>
        <p id="cp-drawing-pages" class="cp-subtle"></p>
        <div id="cp-drawing-view" class="cp-drawing-view" hidden>
          <img id="cp-drawing-image" alt="Предпросмотр выбранной страницы PDF для разметки" draggable="false">
          <div id="cp-drawing-selection" class="cp-drawing-selection" hidden></div>
          <svg id="cp-vector-overlay" class="cp-vector-overlay" viewBox="0 0 1000 1000" preserveAspectRatio="none" aria-hidden="true"></svg>
          <svg id="cp-duct-overlay" class="cp-vector-overlay cp-duct-overlay" viewBox="0 0 1000 1000" preserveAspectRatio="none" aria-hidden="true"></svg>
        </div>
        <p id="cp-crop-caption" class="hint">Выделение не выбрано — отправится вся страница.</p>

        <section class="cp-integrated-analysis" aria-labelledby="cp-unified-heading">
          <h3 id="cp-unified-heading">Результат анализа и проверка участков</h3>
          <p class="hint">Основное представление — кандидаты воздуховодов с подсветкой на PDF. Подробные примитивы, диагностика и ответы Claude находятся в раскрываемой технической области.</p>
        <section class="cp-reports-panel" aria-labelledby="cp-duct-heading">
          <h3 id="cp-duct-heading">Этап 10.2 — цветные трассы и геометрические группы</h3>
          <p class="hint">Код восстанавливает длинные цветные линии из фрагментов и ищет параллельные пары, включая наклонные. Близкие участки объединяются только в пространственные группы для просмотра. Это НЕ проверенные воздуховоды, соединения или объёмы.</p>
          <div class="cp-actions cp-trace-controls">
            <label for="cp-duct-method">Метод анализа
              <select id="cp-duct-method">
                <option value="traces">Цветные трассы (10.2)</option>
                <option value="outlines">Пары стенок / оси (10.1)</option>
              </select>
            </label>
            <label for="cp-duct-filter">Фильтр по цвету
              <select id="cp-duct-filter"><option value="">Все цвета</option></select>
            </label>
          </div>
          <div class="cp-actions">
            <button type="button" class="secondary" id="cp-duct-mode">Выбрать геометрический участок</button>
            <label class="cp-duct-toggle" for="cp-duct-visible">
              <input id="cp-duct-visible" type="checkbox" checked>
              Показать кандидатов поверх PDF
            </label>
          </div>
          <p id="cp-duct-status" class="hint" role="status">После предпросмотра появятся найденные участки и статистика цвета.</p>
          <p id="cp-drawing-inventory" class="hint cp-feedback" role="status">Проверка всех PDF-путей ещё не выполнялась.</p>
          <div class="cp-vector-panels">
            <div>
              <h4>Участки-кандидаты</h4>
              <div id="cp-duct-candidates" class="cp-vector-list">Выполните локальную обработку PDF.</div>
            </div>
            <div>
              <h4>Геометрия и источники</h4>
              <div id="cp-duct-detail" class="cp-duct-detail">Выберите участок в списке или на чертеже.</div>
              <h4>Цветовые группы PDF</h4>
              <div id="cp-duct-layers" class="cp-duct-layers">Статистика появится после обработки.</div>
              <label class="cp-duct-field" for="cp-duct-system">Название системы для выбранного цвета (гипотеза)
                <input id="cp-duct-system" type="text" maxlength="60" placeholder="Например, П1, В4 или ДП7">
              </label>
              <button type="button" id="cp-duct-save-system" class="secondary">Сохранить гипотезу цвета</button>
            </div>
          </div>
          <p class="hint">Все расстояния указаны исключительно в PDF pt. Пространственная близость не подтверждает общий вентиляционный контур или высоту трассы. Система, реальный метраж, площадь и количество материалов автоматически не определяются.</p>
        </section>

          <details id="cp-diagnostics" class="cp-diagnostics">
            <summary>Диагностика: исходные PDF-линии, статистика кода и классификация Claude</summary>
        <div class="cp-review-grid">
          <div class="cp-review-pane">
            <h3>Геометрический разбор (код)</h3>
            <div id="cp-drawing-geometry">Геометрический анализ появится после предпросмотра.</div>
          </div>
          <div class="cp-review-pane">
            <h3>Claude Vision (ИИ)</h3>
            <div id="cp-drawing-vision">ИИ-анализ не запускался.</div>
          </div>
        </div>

        <section class="cp-reports-panel" aria-labelledby="cp-vector-heading">
          <h3 id="cp-vector-heading">Линии PDF — привязка к чертежу</h3>
          <p class="hint">Синие линии — графические штрихи-кандидаты, не доказанные воздуховоды. Выберите линию на изображении или в списке; координаты и исходный идентификатор PDF сохраняются в отчёте.</p>
          <div class="cp-actions">
            <button type="button" class="secondary" id="cp-vector-crop-mode">Выделение фрагмента</button>
            <button type="button" class="secondary" id="cp-vector-select-mode">Выбрать линию</button>
            <button type="button" class="secondary" id="cp-vector-calibrate-mode">Калибровать масштаб</button>
          </div>
          <p class="hint">Активный режим: <strong id="cp-vector-mode">Выделение области</strong></p>
          <div class="cp-vector-panels">
            <div>
              <h4>Линии-кандидаты</h4>
              <div id="cp-vector-list" class="cp-vector-list">Линии появятся после предпросмотра PDF.</div>
            </div>
            <div>
              <h4>Выбранная линия</h4>
              <div id="cp-vector-details">Выберите линию.</div>
              <div class="cp-vector-fields">
                <label for="cp-vector-system">Система (ручная гипотеза)
                  <input id="cp-vector-system" type="text" maxlength="60" placeholder="Например, В4.1-1">
                </label>
                <label for="cp-vector-ai">Связать с позицией Claude (вручную)
                  <select id="cp-vector-ai"><option value="">Без связи</option></select>
                </label>
                <button type="button" id="cp-vector-save-link" class="secondary">Сохранить связь для отчёта</button>
              </div>
              <h4>Масштаб по известному расстоянию</h4>
              <p class="hint">В режиме калибровки нажмите на чертеже две точки с известным реальным расстоянием. Калибровка предполагает единую масштабную плоскость и не подтверждает 3D-длины.</p>
              <div class="cp-vector-fields">
                <label for="cp-vector-known-mm">Расстояние между точками, мм
                  <input id="cp-vector-known-mm" type="number" min="10" max="200000" step="1" placeholder="Например, 5000">
                </label>
                <div class="cp-actions">
                  <button type="button" class="secondary" id="cp-vector-apply-scale">Применить</button>
                  <button type="button" class="secondary" id="cp-vector-clear-scale">Сбросить масштаб</button>
                </div>
              </div>
              <p id="cp-vector-calibration-status" class="hint">Масштаб не калиброван.</p>
            </div>
          </div>
          <p class="hint">Нельзя включать измеренную проекционную длину в площадь металла без проверки, что выбранный штрих — ось прямого воздуховода, и что обмер выполнен в той же плоскости.</p>
        </section>

          </details>
        </section>
        <section class="cp-reports-panel" aria-labelledby="cp-report-heading">
          <h3 id="cp-report-heading">Отчёты по текущему распознаванию</h3>
          <p>После локального предпросмотра доступны JSON и Excel с геометрией и диагностикой. После отдельного запуска Claude эти же отчёты дополняются классификацией ИИ без повторного вызова API при скачивании.</p>
          <div class="cp-actions">
            <button type="button" id="cp-report-json" class="secondary" disabled>Скачать отчёт для анализа (JSON)</button>
            <button type="button" id="cp-report-excel" class="secondary" disabled>Скачать ведомость материалов (Excel)</button>
          </div>
          <p id="cp-report-status" class="hint cp-feedback" role="status" aria-live="polite">После анализа Claude станут доступны оба отчёта.</p>
          <p class="hint">Это протокол распознавания, а не утверждённый просчёт. Сечения и системы сохраняются как гипотезы; количества, длины, площади и материал изготовления остаются неподтверждёнными.</p>
        </section>
        <p class="hint">Никакие найденные элементы, сечения и суммы не утверждаются автоматически. Здесь сравниваются гипотезы, а не окончательный просчёт.</p>
        </details>
      <details class="cp-advanced-tools cp-admin-tools">
        <summary>Настройки API, история разработки и дополнительные сведения</summary>
        <section class="card" aria-labelledby="cp-workflow-heading">
          <h2 id="cp-workflow-heading">Рабочий процесс</h2>
          <p class="hint">Загрузите PDF-альбом для просмотра планов, аксонометрии и подтверждённых объёмов. Отдельную страницу можно открыть для детального разбора.</p>
          <div class="cp-grid">
            <article class="cp-tile">
              <span class="cp-index">01</span>
              <h3>Исходные документы</h3>
              <p>DWG / DXF, векторные PDF, спецификации Excel, в дальнейшем — IFC.</p>
              <span class="cp-state">PDF: альбом целиком или выбранная страница</span>
            </article>
            <article class="cp-tile">
              <span class="cp-index">02</span>
              <h3>Распознавание</h3>
              <p>Геометрические алгоритмы плюс будущая проверка объектов с помощью ИИ.</p>
              <span class="cp-state">Claude Vision: по явному подтверждению</span>
            </article>
            <article class="cp-tile">
              <span class="cp-index">03</span>
              <h3>Инженерная проверка</h3>
              <p>Сечения, длины, связи трасс и исходные CAD-handle с контролем неопределённостей.</p>
              <span class="cp-state">Веб-проверка: предстоит</span>
            </article>
            <article class="cp-tile">
              <span class="cp-index">04</span>
              <h3>Результаты</h3>
              <p>Ведомость материалов, сопоставление номенклатуры, Excel и протокол расхождений.</p>
              <span class="cp-state">Экспорт на сайте: предстоит</span>
            </article>
          </div>
        </section>
      <section class="card" aria-labelledby="cp-api-heading">
        <h2 id="cp-api-heading">Claude API — подключение и проверка</h2>
        <div class="cp-api-layout">
          <div>
            <p class="subtitle">Clean Papper использует серверный клиент Anthropic и защищённый файл учётных данных. В браузере API-ключ не хранится и не отображается.</p>
            <p>Нажмите «Проверить настройки», чтобы проверить локальный файл без расходов. «Проверить API» выполнит один небольшой запрос к Claude с ограничением частоты.</p>
            <form id="cp-api-form" method="post" action="clean_papper_api.php">
              <input type="hidden" name="csrf" value="<?= htmlspecialchars((string) $_SESSION['clean_papper_csrf'], ENT_QUOTES, 'UTF-8') ?>">
              <div class="cp-actions">
                <button type="button" class="secondary" data-action="status">Проверить настройки</button>
                <button type="button" data-action="ping">Проверить API</button>
              </div>
            </form>
            <p id="cp-api-result" class="hint cp-feedback" role="status" aria-live="polite">Проверка API ещё не выполнялась.</p>
            <p class="hint">Для выделенной модели можно добавить поле <code>model_clean_papper</code> в защищённый серверный JSON. Другие модули сохраняют свои модели.</p>
          </div>
          <div class="cp-api-summary">
            <div class="cp-api-row"><span>Провайдер</span><strong>Anthropic (Claude)</strong></div>
            <div class="cp-api-row"><span>Файл API-ключа</span><strong><?= $cpCredentialsPresent ? 'Обнаружен на сервере' : 'Не найден на сервере' ?></strong></div>
            <div class="cp-api-row"><span>Модель</span><strong id="cp-api-model">Определяется при проверке</strong></div>
            <div class="cp-api-row"><span>Статус API</span><strong id="cp-api-test-status">Не проверен</strong></div>
            <div class="cp-api-row"><span>Анализ чертежей с ИИ</span><strong>Ещё не включён</strong></div>
          </div>
        </div>
      </section>

      <section class="card" aria-labelledby="cp-dev-heading">
        <h2 id="cp-dev-heading">Код и дальнейшая настройка</h2>
        <p>Расчётные и графические алгоритмы разрабатываются отдельно. Их перенос на сервер будет организован через ограниченный обработчик, без предоставления публичного доступа к проектным файлам.</p>
        <p><a class="cp-repo-link" href="https://github.com/veryhardlogin69/clean-papper" target="_blank" rel="noopener noreferrer">Открыть приватный репозиторий Clean Papper</a></p>
        <p class="hint">Этот раздел виден только разрешённой учётной записи. Доступ к приватному репозиторию GitHub регулируется отдельно.</p>
      </section>
      </details>
        </details>
      </section>
    </div>
  </main>
</div>
</body>
</html>
