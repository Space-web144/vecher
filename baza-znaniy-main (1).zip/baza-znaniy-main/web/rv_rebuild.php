<?php
declare(strict_types=1);

// Пересобрать РВ: агент привязывает строки и считает коэффициенты заново по текущим правилам и памяти решений —
// например, после исправления расчёта коэффициентов или чтобы в уже собранных РВ появились уменьшения по ЛРВ
// (отрицательные остатки из пакета 1С). Решения инженера по РВ остаются в памяти и применяются сами, проверка
// моделью не повторяется (--no-review). Согласование остаётся, если РВ для 1С не изменилась; изменилась (уменьшения,
// коэффициенты, объёмы, работы строк) — снимается, РВ снова «на проверку» (web_rv_run --rebuild).
// РВ, уже загруженную в 1С, не пересобираем: в 1С она не обновится, а повторная загрузка задвоила бы привязки —
// для неё смету отправляют из 1С заново (придёт новая РВ с учётом уже разнесённого).
//
//   token=<номер>            — одна РВ, сразу (кнопка «Пересобрать РВ» на rv_status.php); любой, кому доступна РВ;
//   scope=reductions | all   — пачкой через очередь (кнопка на rv.php, руководитель): РВ из 1С, в чьих пакетах
//                              есть отрицательные остатки (reductions), или все готовые РВ из 1С (all), кроме уже
//                              загруженных в 1С. РВ встают в очередь разборщика (статус queued с отметкой rebuild)
//                              и пересобираются по одной.

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require_once __DIR__ . '/users.php';
require_once __DIR__ . '/lib.php';
require_once __DIR__ . '/rv_lib.php';

rv_guard();

$scope = (string) ($_POST['scope'] ?? '');
$token = (string) ($_POST['token'] ?? '');
$bulk = in_array($scope, ['reductions', 'all'], true);
if (!$bulk && !rv_token_valid($token)) {
    header('Location: rv.php');
    exit;
}
$back = $bulk ? 'rv.php' : 'rv_status.php?token=' . urlencode($token);
$go = static function (string $message, string $kind = 'err') use ($back): never {
    header('Location: ' . $back . (strpos($back, '?') === false ? '?' : '&') . $kind . '=' . rawurlencode($message));
    exit;
};
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !hash_equals(rv_csrf(), (string) ($_POST['csrf'] ?? ''))) {
    $go('Форма устарела — обновите страницу и повторите.');
}
$me = (string) ($_SESSION['kb_user'] ?? '');
$now = time();

/** РВ можно пересобрать: готова, не сверка, разметка и результат на месте. */
$ready = static function (string $token, ?array $job) : ?array {
    if ($job === null || ($job['mode'] ?? '') === 'audit' || rv_onec_loaded($job)) {
        return null;
    }
    $paths = rv_paths($token);
    [$state, $status] = rv_state($token, $job);
    if ($state !== 'done' || !is_file($paths['work']) || !is_file($paths['json'])) {
        return null;
    }
    return [$paths, is_array($status) ? $status : []];
};

if ($bulk) {
    if (!rv_can_assign() && !rv_is_manager()) {
        $go('Пересобрать РВ пачкой может руководитель.');
    }
    $queued = 0;
    foreach (glob(RV_OUTPUT_DIR . '/*_job.json') ?: [] as $path) {
        $jobToken = basename($path, '_job.json');
        if (!rv_token_valid($jobToken)) {
            continue;
        }
        $job = rv_read_json($path);
        if ($job === null || ($job['origin'] ?? '') !== '1c') {
            continue;
        }
        $found = $ready($jobToken, $job);
        if ($found === null) {
            continue;
        }
        [$paths, $status] = $found;
        if ($scope === 'reductions' && !rv_packet_has_reductions($paths['in'])) {
            continue;
        }
        $job['rebuilt'] = ['by' => $me, 'at' => $now, 'onec_loaded' => rv_onec_loaded($job)];
        file_put_contents($paths['job'], json_encode($job, JSON_UNESCAPED_UNICODE));
        file_put_contents($paths['status'], json_encode([
            'state' => 'queued',
            'stage' => 'в очереди на пересборку',
            'started' => $now,
            'updated' => $now,
            'rebuild' => ['by' => $me, 'at' => $now],      // разборщик очереди запустит привязку заново (web_rv_run._queue_command)
            'feedback' => is_array($status['feedback'] ?? null) ? $status['feedback'] : null,
        ], JSON_UNESCAPED_UNICODE));
        $queued++;
    }
    if ($queued === 0) {
        $go($scope === 'reductions' ? 'РВ с уменьшениями по ЛРВ (отрицательными остатками в пакете 1С), ещё не загруженных в 1С, не найдено.'
            : 'Готовых РВ из 1С, ещё не загруженных в 1С, нет — пересобирать нечего.');
    }
    rv_queue_kick();
    $go('В очередь на пересборку поставлено РВ: ' . $queued . '. Они пересобираются по одной; у согласованных РВ, '
        . 'где изменится то, что уйдёт в 1С, согласование снимется — их нужно проверить заново.', 'ok');
}

$job = rv_read_json(rv_paths($token)['job']);
if ($job === null || !rv_can_access($job)) {
    $go('Задача не найдена или принадлежит другому пользователю.');
}
if (rv_onec_loaded($job)) {
    $go('РВ уже загружена в 1С — пересборка туда не попадёт, а повторная загрузка задвоила бы привязки. '
        . 'Чтобы учесть изменения (например, уменьшения по ЛРВ), отправьте смету из 1С заново — придёт новая РВ с учётом уже разнесённого.');
}
$found = $ready($token, $job);
if ($found === null) {
    [$state] = rv_state($token, $job);
    $go($state !== 'done' ? 'РВ сейчас строится — пересобрать можно, когда она будет готова.'
        : 'Разметка или результат этой РВ не найдены на сервере — пересобрать нельзя, загрузите ЛРВ заново.');
}
[$paths, $status] = $found;

$job['rebuilt'] = ['by' => $me, 'at' => $now, 'onec_loaded' => rv_onec_loaded($job)];
file_put_contents($paths['job'], json_encode($job, JSON_UNESCAPED_UNICODE));
file_put_contents($paths['status'], json_encode([
    'state' => 'running',
    'stage' => 'пересобираю РВ: привязка и коэффициенты заново…',
    'started' => $now,
    'updated' => $now,
    'launched' => false,
    'feedback' => is_array($status['feedback'] ?? null) ? $status['feedback'] : null,   // согласование переживает пересборку
], JSON_UNESCAPED_UNICODE));

rv_launch(['--phase', 'bind', '--status-file', $paths['status'], '--work-file', $paths['work'],
           '--out-xlsx', $paths['xlsx'], '--out-json', $paths['json'],
           '--credentials', ANTHROPIC_CREDENTIALS_FILE, '--learning-file', RV_LEARNING_FILE,
           '--rebuild', '--no-review', '--user', $me,
           '--source-name', (string) ($job['source_name'] ?? '')]);

header('Location: ' . $back);
exit;
