<?php
declare(strict_types=1);

// Приём номенклатуры от 1С — HTTP POST с JSON-телом (список позиций, поля
// Код/Наименование/Артикул/ВидНоменклатуры/... как в реальной выгрузке
// 1С, см. common/nomenclature_intake.py). Единственный эндпоинт на этом
// сайте, к которому обращается НЕ браузер с сессией пользователя, а
// внешняя система — поэтому вместо auth_guard.php (логин/пароль,
// $_SESSION) здесь общий секретный ключ в заголовке X-API-Key (см.
// ONEC_API_KEY_FILE в config.php). Ответ — JSON, а не HTML/редирект: его
// разбирает скрипт 1С, не человек в браузере.
//
// Проверка (опечатки/дубликаты/релевантность вентиляции/длина тройника)
// НЕ выполняется в этом же запросе — как и process.php, здесь только
// сохранение присланных данных и запуск фоновой Python-обработки (пачка
// в тысячи позиций может считаться дольше, чем разумно держать открытым
// HTTP-соединение с 1С). Результат — Excel-отчёт с флагами — смотрит
// администратор на web/onec_intake.php, НЕ 1С. Позиции без единого
// замечания фоновый процесс добавляет в базу сам; позиции с замечаниями
// уходят в очередь ручной проверки (web/onec_review.php), а не в базу
// напрямую (см. common/nomenclature_intake.py).

require __DIR__ . '/config.php';

if (is_file(__DIR__ . '/data/.catalog-routing-deploying')) {
    http_response_code(503);
    header('Retry-After: 30');
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['ok' => false, 'error' => 'Обновляется приём номенклатуры; повторите отправку через 30 секунд.'], JSON_UNESCAPED_UNICODE);
    exit;
}

header('Content-Type: application/json; charset=utf-8');

function json_fail(string $message, int $code = 400): never {
    http_response_code($code);
    echo json_encode(['ok' => false, 'error' => $message], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    json_fail('Ожидался POST-запрос.', 405);
}

if (!is_file(ONEC_API_KEY_FILE)) {
    json_fail('Приём номенклатуры от 1С не настроен на сервере (нет файла ключа). Обратитесь к администратору.', 500);
}
$apiKeyConfig = require ONEC_API_KEY_FILE;
$expectedKey = is_array($apiKeyConfig) ? (string) ($apiKeyConfig['api_key'] ?? '') : '';
$providedKey = (string) ($_SERVER['HTTP_X_API_KEY'] ?? '');
if ($expectedKey === '' || $providedKey === '' || !hash_equals($expectedKey, $providedKey)) {
    json_fail('Неверный или отсутствующий X-API-Key.', 401);
}

if (!is_file(ONEC_NOMENCLATURE_FILE)) {
    json_fail('На сервере нет эталонного снимка базы номенклатуры для сравнения. Обратитесь к администратору.', 500);
}

// Content-Length — быстрый предварительный отсев без чтения всего тела;
// окончательная проверка — по факту прочитанной строки (заголовку можно
// не доверять).
$contentLength = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);
if ($contentLength > MAX_1C_PAYLOAD_BYTES) {
    json_fail('Слишком большой пакет данных (максимум ' . intdiv(MAX_1C_PAYLOAD_BYTES, 1024 * 1024) . ' МБ).', 413);
}

$body = file_get_contents('php://input', false, null, 0, MAX_1C_PAYLOAD_BYTES + 1);
if ($body === false || $body === '') {
    json_fail('Пустое тело запроса — ожидался JSON со списком позиций номенклатуры.');
}
if (strlen($body) > MAX_1C_PAYLOAD_BYTES) {
    json_fail('Слишком большой пакет данных (максимум ' . intdiv(MAX_1C_PAYLOAD_BYTES, 1024 * 1024) . ' МБ).', 413);
}

$data = json_decode($body, true);
if (!is_array($data) || $data === [] || array_keys($data) !== range(0, count($data) - 1)) {
    json_fail('Ожидался непустой JSON-список позиций номенклатуры.');
}
// "Наименование" обязательно не для ВСЕХ позиций — группы 1С (узлы
// дерева, не карточки товара) и архивные/помеченные к удалению всё равно
// пропускаются из проверки на стороне Python (common.nomenclature_intake
// .filter_processable), где для них наименование не требуется. Без этого
// послабления пачка с реальной (пустой или отсутствующей) группой упала
// бы здесь с 400 ещё до Python-фильтрации — валидация на входе должна
// требовать ровно то же самое, что фильтр требует дальше, не строже.
foreach ($data as $item) {
    if (!is_array($item)) {
        json_fail('Каждая позиция должна быть объектом.');
    }
    $skipsNameCheck = !empty($item['ЭтоГруппа']) || !empty($item['ВАрхиве']) || !empty($item['ПометкаУдаления']);
    if (!$skipsNameCheck && empty($item['Наименование'])) {
        json_fail('Каждая позиция должна быть объектом с непустым полем "Наименование" '
            . '(кроме групп/архивных/помеченных к удалению — ЭтоГруппа/ВАрхиве/ПометкаУдаления).');
    }
}

if (!is_dir(UPLOAD_DIR) || !is_writable(UPLOAD_DIR)) {
    json_fail('Папка для входящих данных недоступна на сервере.', 500);
}
if (!is_dir(OUTPUT_DIR) || !is_writable(OUTPUT_DIR)) {
    json_fail('Папка для результатов недоступна на сервере.', 500);
}

$token = bin2hex(random_bytes(8));
$inputPath = UPLOAD_DIR . "/{$token}_1c_input.json";
if (file_put_contents($inputPath, $body) === false) {
    json_fail('Не удалось сохранить присланные данные.', 500);
}

$outputPath = OUTPUT_DIR . "/{$token}_1c_report.xlsx";
$statusPath = OUTPUT_DIR . "/{$token}_1c_status.json";
$pendingPath = OUTPUT_DIR . "/{$token}_1c_pending.json";
$logFile = OUTPUT_DIR . '/python_errors.log';

$cmdParts = [
    escapeshellarg(PYTHON_BIN),
    escapeshellarg(WEB_1C_INTAKE_SCRIPT),
    '--input', escapeshellarg($inputPath),
    '--existing', escapeshellarg(ONEC_NOMENCLATURE_FILE),
    '--output', escapeshellarg($outputPath),
    '--status-file', escapeshellarg($statusPath),
    '--pending-file', escapeshellarg($pendingPath),
    '--token', escapeshellarg($token),
];
// Позиции без единого замечания автоматически дописываются и в боевую
// базу сравнения спецификаций (DB_FILE) — не только в эталонный снимок
// для последующих проверок. Замеченные — в очередь ручной проверки
// (web/onec_review.php), никогда не в базу напрямую (см.
// common/nomenclature_intake.py).
if (is_file(DB_FILE)) {
    $cmdParts[] = '--db-file';
    $cmdParts[] = escapeshellarg(DB_FILE);
}
// Проверка дублей через Claude — только путь к файлу с ключом Anthropic,
// ключ читает сам процесс Python (см. process.php за тем же приёмом).
// Путь передаётся, даже если файла нет: в отчёте будет написано, что
// проверка не выполнена и почему.
if (defined('ANTHROPIC_CREDENTIALS_FILE') && ANTHROPIC_CREDENTIALS_FILE !== '') {
    $cmdParts[] = '--claude-credentials';
    $cmdParts[] = escapeshellarg(ANTHROPIC_CREDENTIALS_FILE);
}

// Не ждём здесь — как и process.php, отвязываем процесс через nohup и
// сразу отвечаем 1С. Результат проверки 1С не нужен, его смотрит
// администратор на отдельной странице (web/onec_intake.php).
$cmd = 'nohup ' . implode(' ', $cmdParts) . ' >> ' . escapeshellarg($logFile) . ' 2>&1 &';
exec($cmd);

http_response_code(202);
echo json_encode(['ok' => true, 'token' => $token, 'received' => count($data)], JSON_UNESCAPED_UNICODE);
