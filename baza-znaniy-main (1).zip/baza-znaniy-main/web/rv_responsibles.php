<?php
declare(strict_types=1);

// Объекты и ответственные: справочник объектов, корпусов и сметчиков ЦО, по которому строится дерево
// «Объекты и ЛРВ из 1С» (rv_registry.php) и назначается ответственный за РВ из 1С. Исходно — таблица
// «Объекты и сметчики» (program-c/rv_objects_import.py → RV_TABLE_DEFAULT), правится здесь и живёт в RV_TABLE_FILE:
// у каждого корпуса по системам — сметчик основного договора («осн») и наряд-заказов («НЗ», ДР и РВР не делятся);
// запасные сметчики на пустую ячейку (ОВ/ВК, ЭОМ/СС); закрытые объекты — исключены из дерева; привязки
// номенклатурных групп 1С к объекту и корпусу, когда по названию не нашлось (rv_table_match).
// Смотреть могут все, у кого есть доступ к РВ; править — руководитель (rv_can_assign).
// POST (csrf): action=save_object (object, resp[корпус][система][осн|НЗ], aliases), save_fallback, exclude, include,
// bind (obj_key, obj, target «объект|корпус»), unbind (obj_key), add_building (object, name),
// add_object (name, building; с obj_key и obj — сразу привязать к нему номенклатурную группу 1С),
// rename_object (object, name — привязки НГ и ТКП переходят), delete_object (object — только без привязок и РВ).

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require_once __DIR__ . '/users.php';
require_once __DIR__ . '/lib.php';
require_once __DIR__ . '/rv_lib.php';

rv_guard();

$me = (string) ($_SESSION['kb_user'] ?? '');
$canEdit = rv_is_manager();       // ответственных меняют руководитель и администратор
$csrf = rv_csrf();
$estimators = rv_estimators();
$systems = rv_table()['systems'];

/** Назад на страницу со служебным сообщением. */
function rv_resp_back(string $to, string $key, string $message): never
{
    $sep = strpos($to, '?') === false ? '?' : '&';
    header('Location: ' . $to . $sep . $key . '=' . rawurlencode($message));
    exit;
}

/** Логин из формы: сметчик сайта или логин таблицы как есть (буквы, цифры, точка, подчёркивание, дефис). */
function rv_resp_login(string $value): string
{
    $value = trim($value);
    return preg_match('/^[A-Za-z0-9._@-]{1,60}$/', $value) ? $value : '';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string) ($_POST['action'] ?? '');
    $backTo = (string) ($_POST['back'] ?? 'rv_responsibles.php');
    if (!preg_match('~^rv(_responsibles|_registry|_status)?\.php(\?[A-Za-z0-9_=&%.+-]*)?$~', $backTo)) {
        $backTo = 'rv_responsibles.php';
    }
    if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) {
        rv_resp_back($backTo, 'err', 'Форма устарела, обновите страницу.');
    }
    if (!$canEdit) {
        rv_resp_back($backTo, 'err', 'Править справочник может руководитель.');
    }
    $objectName = trim((string) ($_POST['object'] ?? ''));
    $ok = false;
    $message = '';
    switch ($action) {
        case 'save_object':
            $resp = (array) ($_POST['resp'] ?? []);
            $aliases = array_values(array_filter(array_map('trim', preg_split('/\R/u', (string) ($_POST['aliases'] ?? '')) ?: []), static fn(string $a): bool => $a !== ''));
            // Сметчики по корпусам (resp[…]) больше не правятся: ответственный — отправитель ЛРВ из 1С; старые
            // ячейки остаются как запасной вариант для пакетов без «Отправил». Если форма их прислала — сохраняем как раньше.
            $ok = rv_table_update(static function (array $table) use ($objectName, $resp, $aliases, $systems): array {
                foreach ($table['objects'] as &$o) {
                    if ((string) $o['name'] !== $objectName) {
                        continue;
                    }
                    $o['aliases'] = array_slice(array_map(static fn(string $a): string => mb_substr($a, 0, 120), $aliases), 0, 20);
                    if ($resp) {
                        foreach ($o['buildings'] as &$b) {
                            $cells = (array) ($resp[(string) $b['name']] ?? []);
                            foreach ($systems as $system) {
                                foreach (['осн', 'НЗ'] as $kind) {
                                    $b['resp'][$system][$kind] = rv_resp_login((string) ((($cells[$system] ?? [])[$kind]) ?? ''));
                                }
                            }
                        }
                        unset($b);
                    }
                }
                unset($o);
                return $table;
            });
            $message = 'Объект «' . $objectName . '» сохранён.';
            $backTo = strpos($backTo, 'rv.php') === 0 ? $backTo : 'rv_responsibles.php?object=' . rawurlencode($objectName);
            break;
        case 'add_object':
            // Новый объект справочника (1С прислала объект, которого в таблице «Объекты и сметчики» не было):
            // имя, один корпус (по умолчанию «к»), сразу привязка НГ из 1С, если пришла со строки «Не сопоставлено».
            $name = preg_replace('/\s+/u', ' ', mb_substr(trim((string) ($_POST['name'] ?? '')), 0, 120)) ?? '';
            $building = mb_substr(trim((string) ($_POST['building'] ?? '')), 0, 60);
            $building = $building !== '' ? $building : 'к';
            $objKey = trim((string) ($_POST['obj_key'] ?? ''));
            $ng = mb_substr(trim((string) ($_POST['obj'] ?? '')), 0, 150);
            if (mb_strlen($name) < 3) {
                rv_resp_back($backTo, 'err', 'Укажите название объекта (как в договоре, например «ЖК Западное Дегунино»).');
            }
            $exists = false;
            foreach (rv_table()['objects'] as $o) {
                if (rv_table_key((string) $o['name']) === rv_table_key($name)) {
                    $exists = true;
                    $name = (string) $o['name'];
                }
            }
            $ok = rv_table_update(static function (array $table) use ($name, $building, $objKey, $ng, $systems, $exists, $me): array {
                if (!$exists) {
                    $resp = [];
                    foreach ($systems as $system) {
                        $resp[$system] = ['осн' => '', 'НЗ' => ''];
                    }
                    $table['objects'][] = ['name' => $name, 'code' => '', 'aliases' => $ng !== '' ? [$ng] : [],
                                           'buildings' => [['name' => $building, 'nz' => '', 'resp' => $resp]]];
                    usort($table['objects'], static fn(array $a, array $b): int => strcoll((string) $a['name'], (string) $b['name']));
                    $table['excluded'] = array_values(array_filter((array) ($table['excluded'] ?? []), static fn($n): bool => rv_table_key((string) $n) !== rv_table_key($name)));
                }
                if ($objKey !== '') {
                    $table['bind'][$objKey] = ['object' => $name, 'building' => $exists ? '' : $building, 'ng' => $ng, 'by' => $me, 'at' => time()];
                }
                return $table;
            });
            $message = ($exists ? 'Объект «' . $name . '» уже есть в справочнике' : 'Объект «' . $name . '» добавлен') . ($objKey !== '' ? ', номенклатурная группа 1С привязана к нему' : '') . '. Ответственный — тот, кто отправил ЛРВ из 1С.';
            $backTo = 'rv.php?node=obj&obj=' . rawurlencode($name);
            break;
        case 'add_building':
            $name = mb_substr(trim((string) ($_POST['name'] ?? '')), 0, 60);
            if ($name === '') {
                rv_resp_back('rv_responsibles.php?object=' . rawurlencode($objectName), 'err', 'Укажите название корпуса.');
            }
            $ok = rv_table_update(static function (array $table) use ($objectName, $name, $systems): array {
                foreach ($table['objects'] as &$o) {
                    if ((string) $o['name'] !== $objectName) {
                        continue;
                    }
                    foreach ((array) $o['buildings'] as $b) {
                        if ((string) $b['name'] === $name) {
                            return $table;
                        }
                    }
                    $resp = [];
                    foreach ($systems as $system) {
                        $resp[$system] = ['осн' => '', 'НЗ' => ''];
                    }
                    $o['buildings'][] = ['name' => $name, 'nz' => '', 'resp' => $resp];
                }
                unset($o);
                return $table;
            });
            $message = 'Корпус «' . $name . '» добавлен.';
            $backTo = 'rv_responsibles.php?object=' . rawurlencode($objectName);
            break;
        case 'save_cell':
            // Ответственный по объекту целиком: система × вид работ (вкладка «Ответственные» на rv.php).
            $system = trim((string) ($_POST['system'] ?? ''));
            $kind = (string) ($_POST['kind'] ?? '') === 'НЗ' ? 'НЗ' : 'осн';
            $login = rv_resp_login((string) ($_POST['user'] ?? ''));
            if (!in_array($system, $systems, true)) {
                rv_resp_back($backTo, 'err', 'Неизвестная система.');
            }
            $ok = rv_table_update(static function (array $table) use ($objectName, $system, $kind, $login): array {
                foreach ($table['objects'] as &$o) {
                    if ((string) $o['name'] === $objectName) {
                        $o['resp'][$system][$kind] = $login;
                    }
                }
                unset($o);
                return $table;
            });
            $message = ($login !== '' ? rv_person_label($login) . ' — ' : 'Снято назначение: ') . $system . ', ' . ($kind === 'НЗ' ? 'наряд-заказ' : 'основной договор') . ' · ' . $objectName;
            break;
        case 'save_managers':
            if (!in_array((string) ($_SESSION['kb_role'] ?? ''), ['admin', 'mainadmin'], true)) {
                rv_resp_back($backTo, 'err', 'Список руководителей меняет администратор.');
            }
            $logins = array_values(array_unique(array_filter(array_map(static fn(string $l): string => rv_resp_login($l), preg_split('/[\s,;]+/u', (string) ($_POST['managers'] ?? '')) ?: []), static fn(string $l): bool => $l !== '')));
            $ok = rv_table_update(static function (array $table) use ($logins): array {
                $table['managers'] = array_slice($logins, 0, 50);
                return $table;
            });
            $message = 'Руководители: ' . ($logins ? implode(', ', $logins) : 'только администраторы');
            break;
        case 'save_fallback':
            $ok = rv_table_update(static function (array $table): array {
                $table['fallback'] = ['ОВВК' => rv_resp_login((string) ($_POST['ОВВК'] ?? '')), 'ЭОМСС' => rv_resp_login((string) ($_POST['ЭОМСС'] ?? ''))];
                return $table;
            });
            $message = 'Запасные сметчики сохранены.';
            break;
        case 'exclude':
        case 'include':
            $ok = rv_table_update(static function (array $table) use ($objectName, $action): array {
                $excluded = array_values(array_diff($table['excluded'], [$objectName]));
                if ($action === 'exclude') {
                    $excluded[] = $objectName;
                }
                $table['excluded'] = $excluded;
                return $table;
            });
            $message = $action === 'exclude' ? 'Объект «' . $objectName . '» перенесён в архив.' : 'Объект «' . $objectName . '» возвращён из архива.';
            break;
        case 'rename_object':
            // Переименование объекта: имя в справочнике, привязки НГ, привязки блоков ТКП и ручные назначения — на новое имя.
            $backTo = 'rv_responsibles.php?object=' . rawurlencode($objectName);
            $newName = preg_replace('/\s+/u', ' ', mb_substr(trim((string) ($_POST['name'] ?? '')), 0, 120)) ?? '';
            if (mb_strlen($newName) < 3) {
                rv_resp_back($backTo, 'err', 'Название объекта — хотя бы 3 знака.');
            }
            foreach (rv_table()['objects'] as $o) {
                if ((string) $o['name'] !== $objectName && rv_table_key((string) $o['name']) === rv_table_key($newName)) {
                    rv_resp_back($backTo, 'err', 'Объект «' . $o['name'] . '» уже есть — привяжите номенклатурную группу к нему, а этот удалите.');
                }
            }
            $ok = rv_table_update(static function (array $table) use ($objectName, $newName): array {
                foreach ($table['objects'] as &$o) {
                    if ((string) $o['name'] === $objectName) {
                        $o['name'] = $newName;
                    }
                }
                unset($o);
                foreach ($table['bind'] as &$bind) {
                    if ((string) ($bind['object'] ?? '') === $objectName) {
                        $bind['object'] = $newName;
                    }
                }
                unset($bind);
                $table['excluded'] = array_map(static fn($n): string => (string) $n === $objectName ? $newName : (string) $n, (array) $table['excluded']);
                return $table;
            });
            if ($ok && is_file(TKP_CUSTOMER_DIR . '/index.json')) {
                require_once __DIR__ . '/tkp_lib.php';
                tkp_index_update(static function (array $index) use ($objectName, $newName): ?array {
                    $changed = false;
                    foreach ($index['estimates'] as &$est) {
                        if (trim((string) ($est['object'] ?? '')) === $objectName) {
                            $est['object'] = $newName;
                            $changed = true;
                        }
                    }
                    unset($est);
                    return $changed ? $index : null;
                });
            }
            $message = 'Объект «' . $objectName . '» переименован в «' . $newName . '».';
            $backTo = 'rv_responsibles.php?object=' . rawurlencode($newName);
            break;
        case 'delete_object':
            // Удалить можно только объект, к которому ничего не привязано и по которому нет РВ на сайте.
            $backTo = 'rv_responsibles.php?object=' . rawurlencode($objectName);
            $bound = array_keys(array_filter(rv_table()['bind'], static fn(array $b): bool => (string) ($b['object'] ?? '') === $objectName));
            $withRv = 0;
            $objKeyNorm = rv_table_key($objectName);
            foreach (rv_registry_rows() as $row) {
                // folder/folder_key в строках реестра — объект справочника, к которому сопоставлена РВ (rv_table_meta)
                if ((string) ($row['folder_key'] ?? '') === $objKeyNorm || (string) ($row['folder'] ?? '') === $objectName) {
                    $withRv++;
                }
            }
            if ($bound || $withRv) {
                rv_resp_back($backTo, 'err', 'Объект не удалён: ' . ($bound ? 'к нему привязано номенклатурных групп — ' . count($bound) . ' (снимите привязки в таблице «Привязки номенклатурных групп 1С» на странице списка)' : '') . ($bound && $withRv ? ', ' : '') . ($withRv ? 'по нему есть РВ на сайте — ' . $withRv : '') . '.');
            }
            $ok = rv_table_update(static function (array $table) use ($objectName): array {
                $table['objects'] = array_values(array_filter($table['objects'], static fn(array $o): bool => (string) $o['name'] !== $objectName));
                $table['excluded'] = array_values(array_diff($table['excluded'], [$objectName]));
                return $table;
            });
            $message = 'Объект «' . $objectName . '» удалён.';
            $backTo = 'rv_responsibles.php';
            break;
        case 'bind':
        case 'unbind':
            $objKey = trim((string) ($_POST['obj_key'] ?? ''));
            $target = (string) ($_POST['target'] ?? '');
            [$tObject, $tBuilding] = array_pad(explode('|', $target, 2), 2, '');
            if ($objKey === '' || ($action === 'bind' && $tObject === '')) {
                rv_resp_back($backTo, 'err', 'Выберите объект и корпус.');
            }
            $ngName = mb_substr(trim((string) ($_POST['obj'] ?? '')), 0, 150);
            $ng = $ngName !== '' ? $ngName : (string) ((rv_table()['bind'][$objKey] ?? [])['ng'] ?? '');
            if ($action === 'bind' && !in_array($tObject, array_map(static fn(array $o): string => (string) $o['name'], rv_table()['objects']), true)) {
                rv_resp_back($backTo, 'err', 'Объекта «' . $tObject . '» нет в справочнике.');
            }
            $ok = rv_table_update(static function (array $table) use ($objKey, $action, $tObject, $tBuilding, $ngName): array {
                $was = (string) (($table['bind'][$objKey] ?? [])['object'] ?? '');
                $ng = $ngName !== '' ? $ngName : (string) (($table['bind'][$objKey] ?? [])['ng'] ?? '');
                if ($action === 'unbind') {
                    unset($table['bind'][$objKey]);
                } else {
                    $table['bind'][$objKey] = ['object' => $tObject, 'building' => $tBuilding, 'ng' => $ng,
                                               'by' => (string) ($_SESSION['kb_user'] ?? ''), 'at' => time()];
                }
                // «+ новый объект…» записывает название группы ещё и в «Названия в 1С» объекта: без этого после «Отвязать»
                // или переноса группа снова находила бы прежний объект по названию.
                if ($ng !== '') {
                    $ngNorm = rv_norm($ng);
                    foreach ($table['objects'] as &$o) {
                        $mine = $action === 'bind' ? (string) $o['name'] !== $tObject : ($was === '' || (string) $o['name'] === $was);
                        if ($mine) {
                            $o['aliases'] = array_values(array_filter((array) ($o['aliases'] ?? []), static fn($a): bool => rv_norm((string) $a) !== $ngNorm));
                        }
                    }
                    unset($o);
                }
                return $table;
            });
            $message = $action === 'bind' ? 'Номенклатурная группа «' . $ng . '» перенесена в «' . $tObject . ($tBuilding !== '' ? ' — ' . $tBuilding : '') . '».'
                : 'Привязка снята — группа вернулась к подбору по названию' . ($ng !== '' ? ' (если ни одно название не подходит — в «Не сопоставлено»)' : '') . '.';
            break;
        default:
            rv_resp_back($backTo, 'err', 'Неизвестное действие.');
    }
    if (!$ok) {
        rv_resp_back($backTo, 'err', 'Не удалось записать справочник на сервере.');
    }
    rv_resp_back($backTo, 'ok', $message);
}

$table = rv_table();
$objects = rv_table_objects($table);
$excluded = array_values(array_filter($table['objects'], static fn(array $o): bool => in_array((string) $o['name'], $table['excluded'], true)));
$unknownLogins = rv_table_unknown_logins();
$objectName = trim((string) ($_GET['object'] ?? ''));
$object = null;
foreach ($table['objects'] as $o) {
    if ((string) $o['name'] === $objectName) {
        $object = $o;
    }
}
$okNow = (string) ($_GET['ok'] ?? '');
$errNow = (string) ($_GET['err'] ?? '');

// Пользователи 1С, которых сайт видел в пакетах («Отправил»), и к какому сметчику сайта каждый сопоставлен: по фамилии
// сам (rv_onec_login) или руководителем вручную. Было на вкладке «Ответственные» в «РВ по ЛРВ».
$onecUsers = [];
if ($object === null) {
    $assignAll = rv_assignments();
    foreach (rv_registry_rows() as $row) {
        $sender = trim((string) ($row['sender'] ?? ''));
        if ($sender === '') {
            continue;
        }
        if (!isset($onecUsers[$sender])) {
            $onecUsers[$sender] = ['rv' => 0] + rv_onec_login($sender, $assignAll);
        }
        $onecUsers[$sender]['rv']++;
    }
    foreach ($assignAll['onec_users'] as $name => $rec) {
        if (!isset($onecUsers[(string) $name])) {
            $onecUsers[(string) $name] = ['rv' => 0, 'login' => (string) ($rec['login'] ?? ''), 'how' => 'manual'];
        }
    }
    uksort($onecUsers, 'strcoll');
}
$onecUnmatched = count(array_filter($onecUsers, static fn(array $u): bool => $u['login'] === ''));

/** Select сметчика: сметчики сайта и текущее значение (логин таблицы), если его на сайте нет. */
function rv_resp_select(string $name, string $value, array $estimators, bool $canEdit): string
{
    if (!$canEdit) {
        return $value !== '' ? rv_h($value) . (rv_table_user($value) === '' ? ' <span class="muted-dash">(нет на сайте)</span>' : '') : '<span class="muted-dash">—</span>';
    }
    $options = '<option value="">—</option>';
    $seen = false;
    foreach ($estimators as $login => $label) {
        $selected = $login === $value || ($value !== '' && rv_table_user($value) === $login);
        $seen = $seen || $selected;
        $options .= '<option value="' . rv_h($login) . '"' . ($selected ? ' selected' : '') . '>' . rv_h($label) . '</option>';
    }
    if ($value !== '' && !$seen) {
        $options .= '<option value="' . rv_h($value) . '" selected>' . rv_h($value) . ' (нет на сайте)</option>';
    }
    return '<select name="' . rv_h($name) . '" aria-label="Сметчик">' . $options . '</select>';
}

/**
 * Номенклатурные группы 1С, чьи РВ попали в объект: [obj_key => [ng, buildings[], count, bind (ручная привязка или
 * null), alias (по какому названию объекта нашлась, если не вручную)]]. По ним карточка объекта показывает, откуда
 * у объекта РВ, и даёт перенести группу в другой объект.
 */
function rv_resp_groups(array $object, array $table): array
{
    $key = rv_table_key((string) $object['name']);
    $names = array_merge([(string) $object['name']], array_map('strval', (array) ($object['aliases'] ?? [])));
    $out = [];
    foreach (rv_registry_rows() as $row) {
        if ((string) ($row['folder_key'] ?? '') !== $key || (string) ($row['obj_key'] ?? '') === '') {
            continue;
        }
        $objKey = (string) $row['obj_key'];
        if (!isset($out[$objKey])) {
            $bind = $table['bind'][$objKey] ?? null;
            $alias = '';
            if ($bind === null) {
                foreach ([(string) $row['obj'], (string) ($row['folder_1c'] ?? ''), (string) ($row['smeta'] ?? '')] as $text) {
                    $n = rv_norm($text);
                    foreach ($names as $name) {
                        $a = rv_norm($name);
                        if ($n !== '' && $a !== '' && strpos($n . ' ', $a . ' ') === 0 && mb_strlen($a) > mb_strlen(rv_norm($alias))) {
                            $alias = $name;
                        }
                    }
                }
            }
            $out[$objKey] = ['ng' => (string) $row['obj'], 'buildings' => [], 'count' => 0, 'bind' => $bind, 'alias' => $alias];
        }
        $out[$objKey]['count']++;
        if ((string) ($row['building_label'] ?? '') !== '') {
            $out[$objKey]['buildings'][(string) $row['building_label']] = true;
        }
    }
    uasort($out, static fn(array $a, array $b): int => strcoll($a['ng'], $b['ng']));
    return $out;
}

/** Сметчики объекта по системам одной строкой: «Вентиляция: vasileva.a · ЭОМ: melnikova.n». */
function rv_resp_summary(array $object, array $systems): string
{
    $by = [];
    foreach ((array) $object['buildings'] as $b) {
        foreach ($systems as $system) {
            foreach (['осн', 'НЗ'] as $kind) {
                $login = (string) ((($b['resp'] ?? [])[$system] ?? [])[$kind] ?? '');
                if ($login !== '') {
                    $by[$system][$login] = true;
                }
            }
        }
    }
    $parts = [];
    foreach ($by as $system => $logins) {
        $parts[] = $system . ': ' . implode(', ', array_keys($logins));
    }
    return implode(' · ', $parts);
}
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Объекты и ответственные — База знаний</title>
<link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
<script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
</head>
<body>
<div class="shell">
  <?php require __DIR__ . '/sidebar.php'; ?>

  <div class="dashboard-main">
  <div class="page-wide">

  <?php if ($okNow !== ''): ?><div class="alert success"><?= rv_h($okNow) ?></div><?php endif; ?>
  <?php if ($errNow !== ''): ?><div class="alert error"><?= rv_h($errNow) ?></div><?php endif; ?>

  <?php if ($object !== null): ?>
  <div class="card">
    <h1><?= rv_h((string) $object['name']) ?></h1>
    <p class="subtitle">Корпуса объекта и его названия в 1С. Ответственный за РВ — тот, кто отправил ЛРВ из 1С (<a href="rv_responsibles.php#onec">пользователи 1С</a>); сметчики по корпусам здесь больше не назначаются.<?= in_array((string) $object['name'], $table['excluded'], true) ? ' <b>Объект исключён из дерева.</b>' : '' ?></p>
    <form method="post" action="rv_responsibles.php">
      <input type="hidden" name="csrf" value="<?= rv_h($csrf) ?>"><input type="hidden" name="action" value="save_object"><input type="hidden" name="object" value="<?= rv_h((string) $object['name']) ?>">
      <div class="table-wrap">
      <table class="data-table">
        <thead><tr><th>Корпус</th><th>Наряд-заказы</th></tr></thead>
        <tbody>
        <?php foreach ((array) $object['buildings'] as $b): ?>
          <tr><td><b><?= rv_h((string) $b['name']) ?></b></td><td class="muted-dash"><?= !empty($b['nz']) ? rv_h((string) $b['nz']) : '—' ?></td></tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      </div>
      <?php if ($canEdit): ?>
      <p><label>Другие названия объекта в 1С (по одному в строке; сайт находит объект по началу названия номенклатурной группы)<br>
        <textarea name="aliases" rows="2" style="width:100%;max-width:640px"><?= rv_h(implode("\n", (array) ($object['aliases'] ?? []))) ?></textarea></label></p>
      <p><button type="submit" class="btn">Сохранить</button> <a class="btn secondary" href="rv_responsibles.php">К списку объектов</a></p>
      <?php else: ?>
      <p><a class="btn secondary" href="rv_responsibles.php">К списку объектов</a></p>
      <?php endif; ?>
    </form>
    <?php $groups = rv_resp_groups($object, $table); $here = 'rv_responsibles.php?object=' . rawurlencode((string) $object['name']); ?>
    <h2 id="ng" style="margin-top:24px">Номенклатурные группы 1С в этом объекте</h2>
    <?php if (!$groups): ?>
    <p class="muted-dash">По объекту пока нет РВ на сайте.</p>
    <?php else: ?>
    <p class="subtitle">Откуда у объекта РВ. Если группа попала не сюда — «Перенести» в нужный объект: привязка вручную главнее подбора по названию.</p>
    <div class="table-wrap"><table class="data-table">
      <thead><tr><th>Номенклатурная группа 1С</th><th>Корпус</th><th>РВ</th><th>Как попала</th></tr></thead>
      <tbody>
      <?php foreach ($groups as $objKey => $g): ?>
        <tr>
          <td><?= rv_h($g['ng']) ?>
            <?php if ($canEdit): ?>
            <div style="display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin-top:6px">
            <form method="post" action="rv_responsibles.php" class="rv-assign" style="display:flex;gap:6px;align-items:center">
              <input type="hidden" name="csrf" value="<?= rv_h($csrf) ?>"><input type="hidden" name="action" value="bind"><input type="hidden" name="back" value="<?= rv_h($here) ?>">
              <input type="hidden" name="obj_key" value="<?= rv_h((string) $objKey) ?>"><input type="hidden" name="obj" value="<?= rv_h($g['ng']) ?>">
              <select name="target" aria-label="Перенести в объект" required style="max-width:260px"><option value="">перенести в объект…</option>
              <?php foreach ($objects as $o): if ((string) $o['name'] === (string) $object['name']) { continue; } ?>
                <option value="<?= rv_h((string) $o['name'] . '|') ?>"><?= rv_h((string) $o['name']) ?></option>
              <?php endforeach; ?>
              </select>
              <button type="submit" class="btn-small secondary">Перенести</button>
            </form>
            <?php if ($g['bind'] !== null): ?>
            <form method="post" action="rv_responsibles.php" class="rv-assign" onsubmit="return confirm('Снять ручную привязку? Группа будет искать объект по названию, а если не найдёт — уйдёт в «Не сопоставлено».')">
              <input type="hidden" name="csrf" value="<?= rv_h($csrf) ?>"><input type="hidden" name="action" value="unbind"><input type="hidden" name="back" value="<?= rv_h($here) ?>">
              <input type="hidden" name="obj_key" value="<?= rv_h((string) $objKey) ?>"><input type="hidden" name="obj" value="<?= rv_h($g['ng']) ?>">
              <button type="submit" class="btn-small secondary">Отвязать</button>
            </form>
            <?php endif; ?>
            </div>
            <?php endif; ?>
          </td>
          <td class="muted-dash"><?= $g['buildings'] ? rv_h(implode(', ', array_keys($g['buildings']))) : '—' ?></td>
          <td><?= (int) $g['count'] ?></td>
          <td class="muted-dash"><?php if ($g['bind'] !== null): ?>вручную<?= !empty($g['bind']['by']) ? ': ' . rv_h(rv_person_label((string) $g['bind']['by'])) : '' ?><?= !empty($g['bind']['at']) ? ', ' . rv_h(rv_when((int) $g['bind']['at'])) : '' ?><?php else: ?>по названию «<?= rv_h($g['alias'] !== '' ? $g['alias'] : (string) $object['name']) ?>»<?php endif; ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
    <p class="muted-dash">Нужного объекта нет в списке — создайте его на странице <a href="rv_responsibles.php">справочника</a> («Добавить объект») и перенесите сюда.</p>
    <?php endif; ?>
    <?php if ($canEdit): ?>
    <form method="post" action="rv_responsibles.php" class="rv-reg-filter">
      <input type="hidden" name="csrf" value="<?= rv_h($csrf) ?>"><input type="hidden" name="action" value="add_building"><input type="hidden" name="object" value="<?= rv_h((string) $object['name']) ?>">
      <input type="text" name="name" placeholder="новый корпус, например к.2.3 или паркинг" aria-label="Название корпуса" maxlength="60">
      <button type="submit" class="btn-small secondary">Добавить корпус</button>
    </form>
    <?php $objBinds = array_filter($table['bind'], static fn(array $b): bool => (string) ($b['object'] ?? '') === (string) $object['name']); ?>
    <form method="post" action="rv_responsibles.php" class="rv-reg-filter" style="margin-top:12px">
      <input type="hidden" name="csrf" value="<?= rv_h($csrf) ?>"><input type="hidden" name="action" value="rename_object"><input type="hidden" name="object" value="<?= rv_h((string) $object['name']) ?>">
      <input type="text" name="name" value="<?= rv_h((string) $object['name']) ?>" aria-label="Новое название объекта" maxlength="120" required style="min-width:320px">
      <button type="submit" class="btn-small secondary">Переименовать</button>
      <span class="muted-dash">Привязки номенклатурных групп и ТКП перейдут на новое название.</span>
    </form>
    <form method="post" action="rv_responsibles.php" class="rv-reg-filter" style="margin-top:12px" onsubmit="return confirm('Удалить объект «<?= rv_h((string) $object['name']) ?>» из справочника?')">
      <input type="hidden" name="csrf" value="<?= rv_h($csrf) ?>"><input type="hidden" name="action" value="delete_object"><input type="hidden" name="object" value="<?= rv_h((string) $object['name']) ?>">
      <button type="submit" class="btn-small secondary"<?= $objBinds || $groups ? ' disabled title="Сначала перенесите номенклатурные группы в другие объекты (таблица выше)"' : '' ?>>Удалить объект</button>
      <span class="muted-dash"><?= $objBinds || $groups ? 'В объекте есть номенклатурные группы 1С — удалить можно, когда их не останется (перенесите их выше).' : 'По объекту нет РВ на сайте — его можно удалить.' ?></span>
    </form>
    <?php endif; ?>
  </div>
  <?php else: ?>
  <div class="card">
    <h1>Объекты и ответственные</h1>
    <p class="subtitle">Справочник объектов и корпусов: по нему строится дерево «РВ по ЛРВ» и подбираются сметы для ТКП заказчика. Ответственный за РВ — тот, кто отправил ЛРВ из 1С (<a href="#onec">пользователи 1С ниже</a>); сметчики по объектам здесь больше не назначаются. Исходно загружен из таблицы «Объекты и сметчики»<?= $table['version'] !== '' ? ' (' . rv_h($table['version']) . ')' : '' ?>, дальше правится здесь.<?= $canEdit ? '' : ' Править может руководитель.' ?></p>
    <?php if ($canEdit): ?>
    <form method="post" action="rv_responsibles.php" class="rv-assign" style="margin:0 0 12px;display:flex;gap:8px;flex-wrap:wrap;align-items:center">
      <input type="hidden" name="csrf" value="<?= rv_h($csrf) ?>"><input type="hidden" name="action" value="add_object">
      <input type="text" name="name" placeholder="новый объект, например ЖК Западное Дегунино" aria-label="Название объекта" maxlength="120" required style="min-width:320px">
      <input type="text" name="building" placeholder="корпус (по умолчанию «к»)" aria-label="Корпус" maxlength="60" style="min-width:200px">
      <button type="submit" class="btn-small">Добавить объект</button>
      <span class="muted-dash">Остальные корпуса, названия в 1С и сметчики — в карточке объекта.</span>
    </form>
    <?php endif; ?>
    <div class="table-wrap">
    <table class="data-table rv-resp-list">
      <thead><tr><th>Объект</th><th>Корпусов</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($objects as $o): ?>
        <tr>
          <td><a href="rv_responsibles.php?object=<?= rv_h(rawurlencode((string) $o['name'])) ?>"><b><?= rv_h((string) $o['name']) ?></b></a><?= !empty($o['aliases']) ? '<br><span class="muted-dash">в 1С: ' . rv_h(implode('; ', (array) $o['aliases'])) . '</span>' : '' ?></td>
          <td><?= count((array) $o['buildings']) ?></td>
          <td>
            <?php if ($canEdit): ?>
            <form method="post" action="rv_responsibles.php" class="rv-assign"><input type="hidden" name="csrf" value="<?= rv_h($csrf) ?>"><input type="hidden" name="action" value="exclude"><input type="hidden" name="object" value="<?= rv_h((string) $o['name']) ?>"><button type="submit" class="btn-small secondary">В архив</button></form>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    </div>
  </div>

  <div class="card" id="onec">
    <h2>Пользователи 1С и сметчики сайта<?= $onecUnmatched ? ' <span class="muted-dash">· без учётки: ' . $onecUnmatched . '</span>' : '' ?></h2>
    <p class="subtitle">За РВ отвечает тот, кто отправил ЛРВ на сайт из 1С (поле «Отправил» в пакете). Сайт находит его учётку по фамилии и первой букве имени («Васильева Анна» → vasileva.a); если не нашёл — укажите сметчика здесь. Другого ответственного на конкретную РВ руководитель назначает в строке списка «РВ по ЛРВ» (столбец «Кто»).</p>
    <?php if (!$onecUsers): ?>
    <p class="muted-dash">1С ещё не присылала отправителя: поле «Отправил» появится в пакетах после обновления модуля 1С.</p>
    <?php else: ?>
    <div class="table-wrap"><table class="data-table">
      <thead><tr><th>Пользователь 1С</th><th>РВ</th><th>Сметчик на сайте</th><th>Как сопоставлен</th></tr></thead>
      <tbody>
      <?php foreach ($onecUsers as $name => $u): $name = (string) $name; ?>
        <tr>
          <td><b><?= rv_h($name) ?></b></td>
          <td><?= (int) $u['rv'] ?: '' ?></td>
          <td>
            <?php if ($canEdit): ?>
            <form method="post" action="rv_assign.php" class="rv-assign">
              <input type="hidden" name="csrf" value="<?= rv_h($csrf) ?>"><input type="hidden" name="level" value="onec">
              <input type="hidden" name="onec" value="<?= rv_h($name) ?>"><input type="hidden" name="back" value="rv_responsibles.php">
              <select name="user" aria-label="Сметчик для <?= rv_h($name) ?>" onchange="this.form.submit()">
                <option value="">— <?= $u['how'] === 'manual' ? 'снять, искать по фамилии' : 'по фамилии' ?> —</option>
                <?php foreach ($estimators as $value => $label): ?>
                <option value="<?= rv_h((string) $value) ?>"<?= $u['how'] === 'manual' && (string) $value === $u['login'] ? ' selected' : '' ?>><?= rv_h(rv_person_label((string) $value)) ?></option>
                <?php endforeach; ?>
              </select>
            </form>
            <?php if ($u['how'] === 'auto'): ?><span class="muted-dash">найден: <?= rv_h(rv_person_label($u['login'])) ?></span><?php endif; ?>
            <?php else: ?>
            <?= $u['login'] !== '' ? rv_h(rv_person_label($u['login'])) : '<span class="muted-dash">нет учётки</span>' ?>
            <?php endif; ?>
          </td>
          <td class="muted-dash"><?= ['manual' => 'вручную, руководитель', 'auto' => 'по фамилии'][$u['how']] ?? ($u['login'] === '' ? '<b>не нашлось — выберите сметчика</b>' : '') ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table></div>
    <?php endif; ?>
  </div>

  <?php if (in_array((string) ($_SESSION['kb_role'] ?? ''), ['admin', 'mainadmin'], true)): ?>
  <div class="card">
    <h2>Руководители</h2>
    <p class="subtitle">Видят все РВ и общий счётчик, назначают ответственных, правят справочник. Администраторы видят всё и без списка.</p>
    <form method="post" action="rv_responsibles.php">
      <input type="hidden" name="csrf" value="<?= rv_h($csrf) ?>"><input type="hidden" name="action" value="save_managers"><input type="hidden" name="back" value="rv_responsibles.php">
      <label>Логины через запятую или с новой строки<br><textarea name="managers" rows="2" style="width:100%;max-width:640px"><?= rv_h(implode(', ', $table['managers'])) ?></textarea></label>
      <p><button type="submit" class="btn-small">Сохранить</button></p>
    </form>
  </div>
  <?php endif; ?>

  <?php if ($table['bind']): ?>
  <div class="card">
    <h2>Привязки номенклатурных групп 1С</h2>
    <p class="subtitle">Группы, привязанные к объекту вручную. Перенести группу в другой объект — в карточке объекта («Номенклатурные группы 1С в этом объекте»).</p>
    <div class="table-wrap"><table class="data-table"><thead><tr><th>Номенклатурная группа 1С</th><th>Объект — корпус</th><th>Кто, когда</th><th></th></tr></thead><tbody>
    <?php foreach ($table['bind'] as $key => $bind): ?>
      <tr>
        <td><?= rv_h((string) ($bind['ng'] ?? $key)) ?></td>
        <td><?= rv_h((string) ($bind['object'] ?? '')) ?><?= !empty($bind['building']) ? ' — ' . rv_h((string) $bind['building']) : '' ?></td>
        <td class="muted-dash"><?= rv_h((string) ($bind['by'] ?? '')) ?><?= !empty($bind['at']) ? ', ' . rv_h(rv_when((int) $bind['at'])) : '' ?></td>
        <td><?php if ($canEdit): ?><form method="post" action="rv_responsibles.php" class="rv-assign"><input type="hidden" name="csrf" value="<?= rv_h($csrf) ?>"><input type="hidden" name="action" value="unbind"><input type="hidden" name="obj_key" value="<?= rv_h((string) $key) ?>"><button type="submit" class="btn-small secondary">Отвязать</button></form><?php endif; ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody></table></div>
  </div>
  <?php endif; ?>

  <?php if ($excluded): ?>
  <div class="card">
    <h2>Архив (<?= count($excluded) ?>)</h2>
    <p class="subtitle">Завершённые объекты: в дереве и списке ответственных показываются только по кнопке «Показать архив».</p>
    <ul class="rv-resp-excluded">
    <?php foreach ($excluded as $o): ?>
      <li><?= rv_h((string) $o['name']) ?>
        <?php if ($canEdit): ?><form method="post" action="rv_responsibles.php" class="rv-assign"><input type="hidden" name="csrf" value="<?= rv_h($csrf) ?>"><input type="hidden" name="action" value="include"><input type="hidden" name="object" value="<?= rv_h((string) $o['name']) ?>"><button type="submit" class="btn-small secondary">Вернуть</button></form><?php endif; ?>
      </li>
    <?php endforeach; ?>
    </ul>
  </div>
  <?php endif; ?>
  <?php endif; ?>

  <p><a href="rv.php">← РВ по ЛРВ</a></p>
  </div>
  </div>
</div>
</body>
</html>
