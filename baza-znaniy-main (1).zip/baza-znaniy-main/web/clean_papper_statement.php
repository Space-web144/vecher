<?php
declare(strict_types=1);
require __DIR__ . '/clean_papper_guard.php';
require_once __DIR__ . '/clean_papper_api_lib.php';
require_once __DIR__ . '/clean_papper_upload_lib.php';
header('X-Content-Type-Options: nosniff');

function cp_statement_reply(array $data, int $code = 200): void {
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}
function cp_statement_remove(string $dir): void {
    foreach (glob($dir . '/*') ?: [] as $file) { if (is_file($file)) @unlink($file); }
    @rmdir($dir);
}
function cp_statement_excel(string $field, string $target, bool $required): void {
    $f = $_FILES[$field] ?? [];
    if (($f['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE && !$required) return;
    if (($f['error'] ?? -1) !== UPLOAD_ERR_OK || !is_uploaded_file($f['tmp_name']) ||
        strtolower(pathinfo($f['name'], PATHINFO_EXTENSION)) !== 'xlsx' || $f['size'] < 10 ||
        $f['size'] > 2097152 || !move_uploaded_file($f['tmp_name'], $target)) {
        throw new InvalidArgumentException('Выберите книгу XLSX до 2 МБ.');
    }
}
$root = cp_pdf_upload_dir();
$active = $_SESSION['cp_statement_job'] ?? '';
$dir = $root . '/statement_' . $active;
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if (!$active || !hash_equals($active, (string)($_GET['job'] ?? '')) || !is_dir($dir))
        cp_statement_reply(['message'=>'Результат недоступен.'],404);
    session_write_close();
    $state = json_decode((string)@file_get_contents($dir . '/state.json'), true);
    if (!is_array($state)) cp_statement_reply(['message'=>'Повторите проверку состояния.'],503);
    $started = (int) ($state['started'] ?? filemtime($dir . '/state.json'));
    if ($state['phase'] === 'running' && time()-$started > 930)
        $state = ['phase'=>'failed','message'=>'Время обработки истекло. Повторите запуск.'];
    $state['started'] = $started;
    $state['server_time'] = time();
    clearstatcache(true, $dir.'/heartbeat');
    $state['heartbeat'] = is_file($dir.'/heartbeat') ? (int) filemtime($dir.'/heartbeat') : null;
    $download = $_GET['download'] ?? '';
    if ($download !== '') {
        $files = ['statement'=>['statement.xlsx','application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'],
                  'atlas'=>['atlas.pdf','application/pdf']];
        if ($state['phase'] !== 'done' || !isset($files[$download]) || !is_file($dir.'/'.$files[$download][0]))
            cp_statement_reply(['message'=>'Файл недоступен.'],404);
        [$name,$type] = $files[$download];
        header('Content-Type: '.$type);
        header('Content-Disposition: attachment; filename="cleanpapper-'.$name.'"');
        readfile($dir.'/'.$name);
        exit;
    }
    cp_statement_reply($state);
}
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || empty($_SESSION['clean_papper_csrf']) ||
    !hash_equals($_SESSION['clean_papper_csrf'], (string)($_POST['csrf'] ?? '')))
    cp_statement_reply(['message'=>'Обновите страницу и повторите запуск.'],403);
if ($active && is_dir($dir)) {
    $old = json_decode((string)@file_get_contents($dir.'/state.json'),true);
    if (($old['phase'] ?? '') === 'running' && time()-(int)($old['started'] ?? filemtime($dir.'/state.json')) < 930)
        cp_statement_reply(['message'=>'Дождитесь окончания текущего расчёта.'],409);
}
foreach (glob($root.'/statement_*', GLOB_ONLYDIR) ?: [] as $stale) {
    if (!is_link($stale) && time()-filemtime($stale)>3600) cp_statement_remove($stale);
}
$id = bin2hex(random_bytes(16));
$dir = $root.'/statement_'.$id;
if (!mkdir($dir,0700)) cp_statement_reply(['message'=>'Недоступно временное хранилище.'],503);
try {
    $pdf = cp_pdf_upload_complete_path($_SESSION['clean_papper_upload'] ?? [], (string)($_POST['upload_id'] ?? ''));
    cp_statement_excel('reference',$dir.'/reference.xlsx',false);
    cp_statement_excel('review',$dir.'/review.xlsx',false);
    if (!rename($pdf,$dir.'/album.pdf')) throw new RuntimeException();
    unset($_SESSION['clean_papper_upload']);
    file_put_contents($dir.'/state.json',json_encode(['phase'=>'running','message'=>'Запуск расчёта.','started'=>time()], JSON_UNESCAPED_UNICODE));
    $python = cp_python_binary();
    if (!$python || !function_exists('exec') || !is_executable('/usr/bin/timeout')) throw new RuntimeException();
    $script = dirname(__DIR__).'/common/clean_papper_statement/run_job.py';
    $cmd = '/usr/bin/timeout -k 5s 900s '.escapeshellarg($python).' -B '.escapeshellarg($script).' '.escapeshellarg($dir);
    if (($_POST['claude_consent'] ?? '') === 'yes') {
        $cmd .= ' '.escapeshellarg(cp_credentials_file());
    }
    exec($cmd.' </dev/null >/dev/null 2>&1 &', $ignored, $code);
    if ($code !== 0) throw new RuntimeException();
    $_SESSION['cp_statement_job']=$id;
    cp_statement_reply(['job'=>$id],202);
} catch (InvalidArgumentException $e) {
    cp_statement_remove($dir);
    cp_statement_reply(['message'=>$e->getMessage()],400);
} catch (Throwable $e) {
    cp_statement_remove($dir);
    cp_statement_reply(['message'=>'Сервер не смог запустить обработчик ведомости.'],503);
}
