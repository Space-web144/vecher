<?php
declare(strict_types=1);

/**
 * Chunked PDF upload staging. Never accept an arbitrary path from a client.
 * 1 MiB parts bypass the site's 2M PHP upload_max_filesize.
 */
const CP_PDF_CHUNK_BYTES = 1048576;
const CP_PDF_MAX_BYTES = 104857600;
const CP_PDF_TTL_SECONDS = 1800;

function cp_pdf_upload_dir(): string
{
    $dir = rtrim(sys_get_temp_dir(), DIRECTORY_SEPARATOR) . DIRECTORY_SEPARATOR . 'clean-papper-private-pdfs';
    if (is_link($dir)) {
        throw new RuntimeException('Unsafe temporary directory');
    }
    if (!is_dir($dir) && !@mkdir($dir, 0700, false) && !is_dir($dir)) {
        throw new RuntimeException('Cannot create temporary storage');
    }
    @chmod($dir, 0700);
    clearstatcache(true, $dir);
    if (!is_dir($dir) || !is_writable($dir) || ((fileperms($dir) & 0077) !== 0)) {
        throw new RuntimeException('Temporary storage is not private');
    }
    return $dir;
}

function cp_pdf_upload_path(string $id): string
{
    if (!preg_match('/^[a-f0-9]{32}$/D', $id)) {
        throw new InvalidArgumentException('Invalid upload token');
    }
    return cp_pdf_upload_dir() . DIRECTORY_SEPARATOR . 'cp_' . $id . '.pdf';
}

/** Stale files are removed on subsequent upload requests; completed jobs delete immediately. */
function cp_pdf_upload_gc(): void
{
    $dir = cp_pdf_upload_dir();
    foreach (glob($dir . DIRECTORY_SEPARATOR . 'cp_*.pdf') ?: [] as $path) {
        if (!preg_match('/^cp_[a-f0-9]{32}\.pdf$/D', basename($path)) || is_link($path)) {
            continue;
        }
        $modified = @filemtime($path);
        if ($modified !== false && $modified < time() - CP_PDF_TTL_SECONDS) {
            @unlink($path);
        }
    }
    foreach (glob($dir . DIRECTORY_SEPARATOR . 'cp_*.pdf.status.json*') ?: [] as $path) {
        if (!preg_match('/^cp_[a-f0-9]{32}\.pdf\.status\.json(?:\.tmp)?$/D', basename($path)) || is_link($path)) continue;
        $modified = @filemtime($path);
        if ($modified !== false && $modified < time() - CP_PDF_TTL_SECONDS) @unlink($path);
    }
}

/** @return array<string,int|string|bool> */
function cp_pdf_upload_begin(string $name, int $size): array
{
    if (strlen($name) > 255 || strtolower(pathinfo($name, PATHINFO_EXTENSION)) !== 'pdf') {
        throw new InvalidArgumentException('Выберите PDF-файл.');
    }
    if ($size < 10 || $size > CP_PDF_MAX_BYTES) {
        throw new InvalidArgumentException('Разрешён PDF размером до 100 МБ.');
    }
    cp_pdf_upload_gc();
    $id = bin2hex(random_bytes(16));
    $path = cp_pdf_upload_path($id);
    $stream = @fopen($path, 'xb');
    if ($stream === false) {
        throw new RuntimeException('Cannot create private PDF');
    }
    fclose($stream);
    @chmod($path, 0600);
    return ['id' => $id, 'size' => $size, 'offset' => 0,
            'updated' => time(), 'complete' => false];
}

/**
 * The calling HTTP handler MUST verify is_uploaded_file before reading bytes.
 * @param array<string,int|string|bool> $upload
 */
function cp_pdf_upload_append(array &$upload, string $chunk, int $offset): int
{
    if (time() - (int) ($upload['updated'] ?? 0) > CP_PDF_TTL_SECONDS) {
        throw new InvalidArgumentException('Срок загрузки истёк.');
    }
    if (!empty($upload['complete'])) {
        throw new InvalidArgumentException('PDF уже загружен.');
    }
    $size = strlen($chunk);
    if ($size < 1 || $size > CP_PDF_CHUNK_BYTES) {
        throw new InvalidArgumentException('Часть PDF превышает 1 МБ.');
    }
    $expected = (int) $upload['offset'];
    $total = (int) $upload['size'];
    if ($offset !== $expected || $offset + $size > $total) {
        throw new InvalidArgumentException('Неправильный порядок загрузки частей.');
    }
    if ($offset === 0 && substr($chunk, 0, 5) !== '%PDF-') {
        throw new InvalidArgumentException('Файл не распознан как PDF.');
    }
    $path = cp_pdf_upload_path((string) $upload['id']);
    clearstatcache(true, $path);
    if (is_link($path) || !is_file($path) || filesize($path) !== $expected) {
        throw new RuntimeException('Temporary file integrity failed');
    }
    $written = @file_put_contents($path, $chunk, FILE_APPEND | LOCK_EX);
    if ($written !== $size) {
        throw new RuntimeException('Temporary write failed');
    }
    $upload['offset'] = $offset + $size;
    $upload['updated'] = time();
    $upload['complete'] = $upload['offset'] === $total;
    return (int) $upload['offset'];
}

/** @param array<string,int|string|bool> $upload */
function cp_pdf_upload_complete_path(array $upload, string $id): string
{
    if (!isset($upload['id']) || !is_string($upload['id']) || !hash_equals($upload['id'], $id)) {
        throw new InvalidArgumentException('Загрузка PDF не принадлежит этой сессии.');
    }
    if (time() - (int) ($upload['updated'] ?? 0) > CP_PDF_TTL_SECONDS) {
        throw new InvalidArgumentException('Срок хранения временного PDF истёк.');
    }
    if (($upload['complete'] ?? false) !== true ||
        (int) $upload['offset'] !== (int) $upload['size']) {
        throw new InvalidArgumentException('PDF ещё загружается.');
    }
    $path = cp_pdf_upload_path($id);
    clearstatcache(true, $path);
    if (is_link($path) || !is_file($path) || filesize($path) !== (int) $upload['size']) {
        throw new RuntimeException('PDF integrity check failed');
    }
    $stream = @fopen($path, 'rb');
    $magic = $stream ? (string) fread($stream, 5) : '';
    if ($stream) {
        fclose($stream);
    }
    if ($magic !== '%PDF-') {
        throw new InvalidArgumentException('Файл не распознан как PDF.');
    }
    return $path;
}

/** @param array<string,int|string|bool>|null $upload */
function cp_pdf_upload_discard(?array $upload): void
{
    if (!is_array($upload) || !is_string($upload['id'] ?? null)) {
        return;
    }
    try {
        $path = cp_pdf_upload_path($upload['id']);
        if (!is_link($path) && is_file($path)) {
            @unlink($path);
        }
    } catch (InvalidArgumentException | RuntimeException $ignored) {
        // No private path details in a user-facing response.
    }
}
