<?php
declare(strict_types=1);

// Схема направлений: все модули (structure.php) и их задачи одной
// схемой — вертикальный ствол с узлами-модулями, от каждого вправо идут
// задачи. Это схема «Структура отдела автоматизации», повёрнутая набок,
// чтобы читалась на экране без горизонтальной прокрутки.
// Часть обновлённого оформления; видна только тем, кому открыт план
// (KB_PLAN_VIEWERS в config.php), остальных ведёт на главную.

require __DIR__ . '/auth_guard.php';
require_once __DIR__ . '/users.php';
require_once __DIR__ . '/design.php';
require_once __DIR__ . '/structure_lib.php';

if (!design_refresh() || !kb_can_see_plans((string) ($_SESSION['kb_user'] ?? ''))) {
    header('Location: index.php');
    exit;
}

$sections = kb_structure();
$total = kb_counts($sections);
$mineIds = array_column(kb_user_sections((string) ($_SESSION['kb_user'] ?? '')), 'id');

/** Задача схемы: подпись, статус, пометка; ссылка — для готовых инструментов. */
function road_pill(string $text, string $status, string $note = '', string $href = ''): string
{
    $status = isset(KB_STATUSES[$status]) ? $status : 'todo';
    $tag = $href !== '' ? 'a' : 'span';
    $mark = '';
    if ($status === 'done') {
        $mark = '<svg class="kb-pill-mark" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m5 12.5 4.5 4.5L19 7.5"/></svg>';
    } elseif ($status === 'progress') {
        $mark = '<span class="kb-mark is-progress" aria-hidden="true"></span>';
    }
    // Короткая пометка — в самой плашке, длинная — подсказкой при наведении.
    $short = $note !== '' && mb_strlen($note) <= 28;
    $html = '<' . $tag . ' class="kb-pill is-' . $status . '" data-status="' . $status . '"'
        . ($href !== '' ? ' href="' . kb_e($href) . '"' : '')
        . ($note !== '' && !$short ? ' title="' . kb_e($note) . '"' : '') . '>'
        . $mark . '<span class="kb-pill-text">' . kb_e($text)
        . ($short ? ' <span class="kb-pill-note">' . kb_e($note) . '</span>' : '') . '</span>'
        . '<span class="kb-sr">, ' . mb_strtolower(KB_STATUSES[$status]) . '</span>'
        . '</' . $tag . '>';
    return $html;
}
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Схема направлений — База знаний</title>
<link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
<?= design_refresh_css() ?>
<script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
</head>
<body>
<div class="shell">
  <?php require __DIR__ . '/sidebar.php'; ?>

  <main class="dashboard-main kb-roadmap">
    <header class="home-head kb-road-head">
      <h1>Схема направлений</h1>
      <p class="lead">Модули отдела автоматизации и их задачи. Готово <?= $total['done'] ?> из <?= $total['total'] ?><?= $total['progress'] > 0 ? ', в работе ' . $total['progress'] : '' ?>.</p>
      <div class="kb-road-filter" role="group" aria-label="Какие задачи показывать" hidden>
        <button type="button" data-filter="all" aria-pressed="true">Все <b><?= $total['total'] ?></b></button>
        <button type="button" data-filter="done" aria-pressed="false"><span class="kb-pill-dot is-done" aria-hidden="true"></span>Готово <b><?= $total['done'] ?></b></button>
        <button type="button" data-filter="progress" aria-pressed="false"><span class="kb-pill-dot is-progress" aria-hidden="true"></span>В работе <b><?= $total['progress'] ?></b></button>
        <button type="button" data-filter="todo" aria-pressed="false"><span class="kb-pill-dot is-todo" aria-hidden="true"></span>Не начато <b><?= $total['todo'] ?></b></button>
      </div>
    </header>

    <ol class="kb-lanes">
      <?php foreach ($sections as $s): ?>
      <?php
      $c = kb_counts([$s]);
      $meta = [];
      if ($s['owners']) {
          $meta[] = implode(', ', $s['owners']);
      }
      if (!empty($s['departments'])) {
          $meta[] = 'отдел ' . implode(', ', $s['departments']);
      }
      ?>
      <li class="kb-lane<?= !empty($s['proposal']) ? ' is-proposal' : '' ?>" id="s-<?= kb_e($s['id']) ?>">
        <span class="kb-lane-node" aria-hidden="true"><?= kb_e($s['num']) ?></span>
        <div class="kb-lane-body">
          <header class="kb-lane-head">
            <div class="kb-lane-title">
              <h2><a href="section.php?id=<?= kb_e($s['id']) ?>"><?= kb_e($s['title']) ?></a></h2>
              <p class="kb-lane-meta">
                <?= kb_e(implode('. ', $meta)) ?><?= $meta ? '.' : '' ?>
                <?php if (in_array($s['id'], $mineIds, true)): ?> <span class="kb-tag is-section">ваш отдел</span><?php endif; ?>
                <?php if (!empty($s['private'])): ?> <span class="kb-tag">закрытый модуль</span><?php endif; ?>
                <?php if (!empty($s['proposal'])): ?> <span class="kb-tag is-warn">предложение</span><?php endif; ?>
              </p>
            </div>
            <div class="kb-lane-state">
              <span class="kb-lane-sum"><?= kb_e(kb_cap(kb_done_text($c))) ?></span>
              <?= kb_bar($c, false) ?>
            </div>
          </header>

          <div class="kb-lane-tasks">
            <?php foreach ($s['tools'] as $tool): ?>
              <?= road_pill($tool['name'], 'done', 'на сайте', $tool['href']) ?>
            <?php endforeach; ?>
            <?php foreach ($s['plan'] as $group): ?>
              <?php if (!empty($group['title'])): ?>
              <span class="kb-lane-group"><?= kb_e($group['title']) ?><?= !empty($group['owner']) ? ' <span>' . kb_e($group['owner']) . '</span>' : '' ?><?php if (!empty($group['about'])): ?><small class="kb-lane-about"><?= kb_e((string) $group['about']) ?></small><?php endif; ?></span>
              <?php endif; ?>
              <?php foreach ($group['items'] as $item): ?>
                <?= road_pill((string) $item[0], (string) $item[1], (string) ($item[2] ?? '')) ?>
              <?php endforeach; ?>
            <?php endforeach; ?>
          </div>
          <p class="kb-lane-empty" hidden>Нет задач в этом состоянии.</p>
        </div>
      </li>
      <?php endforeach; ?>
    </ol>
  </main>
</div>
<script>
  // Отбор задач по состоянию. Без JS кнопок нет — видны все задачи.
  (function () {
    var bar = document.querySelector('.kb-road-filter');
    if (!bar) return;
    bar.hidden = false;
    var buttons = bar.querySelectorAll('button');
    bar.addEventListener('click', function (e) {
      var btn = e.target.closest('button');
      if (!btn) return;
      var want = btn.getAttribute('data-filter');
      buttons.forEach(function (b) { b.setAttribute('aria-pressed', b === btn ? 'true' : 'false'); });
      document.querySelectorAll('.kb-lane').forEach(function (lane) {
        var shown = 0;
        var pills = lane.querySelectorAll('.kb-pill');
        pills.forEach(function (pill) {
          var ok = want === 'all' || pill.getAttribute('data-status') === want;
          pill.hidden = !ok;
          if (ok) shown++;
        });
        // Подпись группы остаётся, только если в группе что-то видно.
        lane.querySelectorAll('.kb-lane-group').forEach(function (label) {
          var visible = false, el = label.nextElementSibling;
          while (el && !el.classList.contains('kb-lane-group')) {
            if (!el.hidden) visible = true;
            el = el.nextElementSibling;
          }
          label.hidden = !visible;
        });
        lane.querySelector('.kb-lane-empty').hidden = shown > 0;
        lane.classList.toggle('is-dim', shown === 0);
      });
    });
  })();
</script>
</body>
</html>
