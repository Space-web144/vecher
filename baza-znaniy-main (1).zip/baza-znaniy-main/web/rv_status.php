<?php
declare(strict_types=1);

// Ход и результат задачи агента РВ. Пока процесс работает, страница
// опрашивает свой JSON (?json=1) и перерисовывает ход; по завершении
// показывает сводку, вопросы, кнопки скачивания и всю РВ по форме ТКП
// для проверки (assets/rv_review.js по ?rows=1): инженер исправляет
// работу там, где агент ошибся, остальное считается верным — rv_feedback.php.

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require_once __DIR__ . '/users.php';
require_once __DIR__ . '/lib.php';
require_once __DIR__ . '/rv_lib.php';

rv_guard();

$token = (string) ($_GET['token'] ?? '');
if (!rv_token_valid($token)) {
    rv_fail('Неверный номер задачи.');
}
$paths = rv_paths($token);
$job = rv_read_json($paths['job']);
if ($job === null) {
    rv_fail('Задача не найдена или устарела.', 404);
}
if (!rv_can_access($job)) {
    rv_fail('Эта задача принадлежит другому пользователю.', 403);
}
[$state, $status] = rv_state($token, $job);

if (isset($_GET['json'])) {
    rv_json([
        'state' => $state,
        'stage' => (string) ($status['stage'] ?? ''),
        'log' => array_values((array) ($status['log'] ?? [])),
        'elapsed' => time() - (int) ($job['created'] ?? time()),
    ]);
}
if (isset($_GET['rows'])) {
    // Строки формы и каталог работ — файл агента как есть (мегабайты; разбирать его в PHP незачем).
    if ($state !== 'done' || !is_file($paths['form'])) {
        rv_json(['ok' => false, 'error' => 'Строки РВ ещё не готовы.'], 404);
    }
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    $acceptsGzip = strpos((string) ($_SERVER['HTTP_ACCEPT_ENCODING'] ?? ''), 'gzip') !== false && !ini_get('zlib.output_compression');
    if (substr($paths['form'], -3) === '.gz') {
        if ($acceptsGzip) {
            header('Content-Encoding: gzip');
            header('Content-Length: ' . (string) filesize($paths['form']));
            readfile($paths['form']);
        } else {
            readgzfile($paths['form']);
        }
        exit;
    }
    $body = (string) file_get_contents($paths['form']);
    if ($acceptsGzip && function_exists('gzencode')) {
        $body = gzencode($body, 6);
        header('Content-Encoding: gzip');
    }
    header('Content-Length: ' . strlen($body));
    echo $body;
    exit;
}

$summary = is_array($status['summary'] ?? null) ? $status['summary'] : null;
$elapsed = time() - (int) ($job['created'] ?? time());
$title = 'РВ: ' . (string) ($job['source_name'] ?? '');
$feedbackDone = is_array($status['feedback'] ?? null) ? $status['feedback'] : null;
$approval = rv_approval($job, $status);
$isAudit = ($job['mode'] ?? '') === 'audit';    // сверка РВ, сделанной в 1С, с агентом — не рабочая ЛРВ
$rollback = is_array($job['rollback'] ?? null) ? $job['rollback'] : null;
$rollbackDone = is_array($status['rollback'] ?? null) ? $status['rollback'] : null;
// Откатить согласование: руководитель или тот, кто согласовал (rv_rollback.php); РВ, уже загруженную в 1С,
// откатывать нельзя — в 1С она останется, а сайт разошёлся бы с ней (rv_onec_loaded).
$canRollback = $feedbackDone !== null && !empty($job['feedback']) && !rv_onec_loaded($job)
    && (rv_can_assign() || ((string) ($feedbackDone['user'] ?? '') !== '' && (string) $feedbackDone['user'] === (string) ($_SESSION['kb_user'] ?? '')));
$pageError = mb_substr((string) ($_GET['err'] ?? ''), 0, 300);
$learned = is_array($summary['learned'] ?? null) ? $summary['learned'] : null;
// Пересборка по кнопке (rv_rebuild.php): баннер, пока это последнее действие с РВ (позже согласования и отката).
$rebuilt = is_array($job['rebuilt'] ?? null) ? $job['rebuilt'] : null;
$rebuiltLast = $rebuilt !== null && (int) ($rebuilt['at'] ?? 0) >= max((int) ($job['feedback'] ?? 0), (int) ($rollback['at'] ?? 0));
$canRebuild = !$isAudit && is_file($paths['work']) && is_file($paths['json']) && !rv_onec_loaded($job);
$rebuiltRun = is_array($status['rebuilt'] ?? null) ? $status['rebuilt'] : null;     // итог пересборки от агента
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= rv_h($title) ?> — База знаний</title>
<link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
<script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
</head>
<body>
<div class="shell">
  <?php require __DIR__ . '/sidebar.php'; ?>

  <?php $isDone = $state === 'done' && $summary !== null; ?>
  <div class="dashboard-main<?= $isDone ? ' kb' : '' ?>">
  <?php if (!$isDone): ?><div class="page-wide"><?php endif; ?>
<?php if ($pageError !== ''): ?>
  <div class="<?= $isDone ? 'kb-alert kb-alert--danger' : 'alert error' ?>"><?= rv_h($pageError) ?></div>
<?php endif; ?>

<?php if ($state === 'awaiting_confirm'): ?>
  <?php
    $work = rv_read_json($paths['work']) ?? [];
    $headers = (array) ($work['headers'] ?? []);
    $marks = (array) ($work['marks'] ?? []);
    $rowsUnder = (array) ($work['rows_under'] ?? []);
    $is1c = (string) ($work['format'] ?? '') === '1c_report';
    $jobSection = (string) ($job['section'] ?? 'авто');
    $defaultSystem = (string) ($work['default_system'] ?? '');
    $unresolved = 0;
    $meaningful = 0;   // заголовков, которые задают систему, элемент или «не включать»
    foreach ($marks as $m) {
        if (!empty($m['unresolved'])) { $unresolved++; }
        if (in_array((string) ($m['kind'] ?? 'other'), ['system', 'element', 'skip'], true)) { $meaningful++; }
    }
    // Короткий вопрос: в заголовках нет ни систем, ни элементов — нужна одна система на всю ЛРВ.
    $compact = !$is1c && !$unresolved && $meaningful === 0;
    $modelDefault = (string) ($work['model_default'] ?? '');
  ?>
  <div class="card">
    <?php $askCodeRoot = !empty($work['ask_code_root']); ?>
    <h1><?= $askCodeRoot ? 'Заказ-наряд: ДР или РВР?' : ($compact ? 'Выберите систему' : 'Проверьте системы') ?></h1>
    <p class="subtitle">
      <?= rv_h((string) ($job['source_name'] ?? '')) ?>:
      <?php if ($is1c): ?>
        отчёт 1С с группировкой <?= rv_h(implode(' → ', (array) ($work['levels'] ?? []))) ?>.
        Строк номенклатуры <?= (int) ($status['rows'] ?? 0) ?>, групп <?= count($headers) ?>;
        документов-регистраторов пропущено <?= (int) ($work['docs'] ?? 0) ?>, строк без планового количества <?= (int) ($work['skipped_zero'] ?? 0) ?>.
      <?php else: ?>
        прочитано <?= (int) ($status['rows'] ?? 0) ?> строк материалов и <?= count($headers) ?> заголовков групп.
      <?php endif; ?>
      <?php if ($compact): ?>
      Систем в файле нет<?= !empty($work['rows_no_system']) ? ' (строк без системы: ' . (int) $work['rows_no_system'] . ')' : '' ?>, а код работы зависит от системы — выберите её для всей ЛРВ.
      <?php if ($modelDefault !== ''): ?>Агент предлагает «<?= rv_h(str_replace('|', ' / ', $modelDefault)) ?>».<?php endif; ?>
      В следующий раз систему можно выбрать сразу при загрузке — тогда этого вопроса не будет.
      <?php else: ?>
      Разметка — <?= rv_h((string) ($work['marked_by'] ?? '')) ?>.
      <?= rv_h((string) ($work['confirm_reason'] ?? '')) ?><?= !empty($work['confirm_reason']) ? '. ' : '' ?>Код работы зависит от раздела и системы, поэтому агент не угадывает их молча: проверьте, что он понял по группам, и поправьте, где нужно.
      <?php endif; ?>
      <?php if ($unresolved): ?><b>Не распознано групп: <?= $unresolved ?></b> — выберите для них систему или «не включать».<?php endif; ?>
    </p>
    <?php foreach ((array) ($work['notes'] ?? []) as $note): ?>
      <p class="hint"><?= rv_h((string) $note) ?></p>
    <?php endforeach; ?>

    <form action="rv_confirm.php" method="post" class="rv-confirm">
      <input type="hidden" name="token" value="<?= rv_h($token) ?>">
      <?php if ($askCodeRoot): ?>
      <div class="field" id="rv-code-root">
        <span class="field-label">Вид заказ-наряда — по какому коду работ собирать РВ</span>
        <label style="display:block;margin:6px 0"><input type="radio" name="code_root" value="6" required> <b>ДР</b> — дополнительные работы, работы кода 6 (6.2.3…)</label>
        <label style="display:block;margin:6px 0"><input type="radio" name="code_root" value="12" required> <b>РВР</b> — работы кода 12 (12.1…, не предусмотренные основным проектом)</label>
        <p class="hint" style="margin:6px 0 0">ЛРВ пришла по заказ-наряду<?= !empty($job['meta']['zn']) ? ' № ' . rv_h((string) $job['meta']['zn']) : '' ?>, а его вид 1С не передала. Для РВР агент подбирает работу по тем же правилам и ставит работу кода 12 с тем же названием. Следующие версии этой ЛРВ соберутся по тому же коду без вопроса.</p>
      </div>
      <?php endif; ?>
      <?php if ($headers): ?>
      <?php if ($compact): ?><details class="rv-sample"><summary>Заголовки групп в файле (<?= count($headers) ?>) — систем в них нет</summary><?php endif; ?>
      <div class="table-wrap">
      <table class="data-table rv-headers">
        <thead><tr><th>Группа в ЛРВ</th><th>Строк</th><th>Что задаёт</th><th>Значение</th></tr></thead>
        <tbody>
        <?php foreach ($headers as $index => $header): ?>
          <?php
            $mark = (array) ($marks[(string) $index] ?? ['kind' => 'other']);
            $kind = (string) ($mark['kind'] ?? 'other');
            if ($kind === 'section') { $kind = 'other'; }
            $level = (int) ($header['level'] ?? 0);
            $selectedSystem = $kind === 'system' ? (string) ($mark['section'] ?? $jobSection) . '|' . (string) ($mark['system'] ?? '') : '';
            $rowClass = !empty($mark['unresolved']) ? ' class="is-unresolved"' : '';
          ?>
          <tr data-row="<?= (int) $index ?>"<?= $rowClass ?>>
            <td class="rv-group rv-level-<?= min($level, 4) ?>">
              <?php if (!empty($header['label'])): ?><span class="rv-label"><?= rv_h((string) $header['label']) ?></span><?php endif; ?>
              <?= rv_h((string) ($header['text'] ?? '')) ?>
              <span class="muted-dash">стр. <?= (int) ($header['row'] ?? 0) ?></span>
            </td>
            <td><?= (int) ($rowsUnder[(string) $index] ?? 0) ?></td>
            <td>
              <select name="kind[<?= (int) $index ?>]" class="rv-kind" aria-label="Что задаёт группа">
                <option value="system"<?= $kind === 'system' ? ' selected' : '' ?>>систему</option>
                <option value="element"<?= $kind === 'element' ? ' selected' : '' ?>>элемент (корпус, З/Н)</option>
                <option value="skip"<?= $kind === 'skip' ? ' selected' : '' ?>>не включать в РВ</option>
                <option value="other"<?= $kind === 'other' ? ' selected' : '' ?>>просто группа</option>
              </select>
              <?php if (!empty($mark['unresolved'])): ?><div class="rv-unresolved">система не распознана</div>
              <?php elseif ($kind === 'skip'): ?><div class="muted-dash"><?= rv_h((string) ($mark['reason'] ?? '')) ?></div><?php endif; ?>
            </td>
            <td>
              <select name="system[<?= (int) $index ?>]" class="rv-system" aria-label="Раздел и система"<?= $kind === 'system' || !empty($mark['unresolved']) ? '' : ' hidden' ?>>
                <?php if ($kind !== 'system'): ?><option value="">— выберите систему —</option><?php endif; ?>
                <?= rv_system_options($selectedSystem, $jobSection) ?>
              </select>
              <input type="text" name="element[<?= (int) $index ?>]" class="rv-element" maxlength="80" aria-label="Название элемента"
                     value="<?= rv_h((string) ($mark['element'] ?? $header['text'] ?? '')) ?>"<?= $kind === 'element' ? '' : ' hidden' ?>>
            </td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      </div>
      <?php if ($compact): ?></details><?php endif; ?>
      <?php else: ?>
      <p class="hint"><?php if (!empty($work['has_system_column'])): ?>В файле есть колонка «Система» — она и используется.<?php else: ?>Заголовков групп в файле нет: все строки получат систему, выбранную ниже.<?php endif; ?></p>
      <?php endif; ?>

      <div class="field">
        <label class="field-label" for="default_system"><?= $compact ? 'Система для всей ЛРВ' : 'Система для строк, у которых её нет в группах' ?><?= !$compact && (int) ($work['rows_without_header'] ?? 0) > 0 ? ' (таких строк вне групп: ' . (int) $work['rows_without_header'] . ')' : '' ?></label>
        <select id="default_system" name="default_system">
          <option value="">— не задавать: такие строки уйдут в вопросы (F-CTX) —</option>
          <?= rv_system_options($defaultSystem, $jobSection) ?>
        </select>
      </div>

      <?php if (!empty($work['sample'])): ?>
      <details class="rv-sample">
        <summary>Первые строки файла — как их прочитал агент</summary>
        <ul>
        <?php foreach ((array) $work['sample'] as $row): ?>
          <li><?= rv_h((string) ($row['name'] ?? '')) ?> <span class="muted-dash"><?= rv_h((string) ($row['unit'] ?? '')) ?: 'ед. нет' ?>, <?= rv_h((string) ($row['qty'] ?? '')) ?></span></li>
        <?php endforeach; ?>
        </ul>
      </details>
      <?php endif; ?>

      <button type="submit">Построить РВ</button>
    </form>
  </div>
  <script>
    document.querySelectorAll('.rv-kind').forEach(function (select) {
      var row = select.closest('tr');
      function sync() {
        row.querySelector('.rv-system').hidden = select.value !== 'system';
        row.querySelector('.rv-element').hidden = select.value !== 'element';
      }
      select.addEventListener('change', sync);
      sync();
    });
    document.querySelector('.rv-confirm').addEventListener('submit', function (event) {
      var bad = Array.prototype.filter.call(document.querySelectorAll('.rv-kind'), function (select) {
        return select.value === 'system' && !select.closest('tr').querySelector('.rv-system').value;
      });
      if (bad.length) {
        event.preventDefault();
        bad[0].closest('tr').scrollIntoView({ block: 'center' });
        bad[0].closest('tr').querySelector('.rv-system').focus();
      }
    });
  </script>

<?php elseif ($state === 'running' || $state === 'queued'): ?>
  <div class="card">
    <h1><?= $state === 'queued' ? 'РВ в очереди' : 'Строю РВ' ?></h1>
    <?php if ($state === 'queued'): ?><p class="hint">ЛРВ прислала 1С. Агент строит РВ по одной, эта начнётся, когда закончатся присланные раньше.</p><?php endif; ?>
    <p class="subtitle"><?= rv_h((string) ($job['source_name'] ?? '')) ?>, раздел <?= rv_h((string) $job['section']) ?>, <?= rv_h((string) (RV_OBJECT_TYPES[$job['object_type']] ?? $job['object_type'])) ?>.</p>
    <div class="alert is-running" id="rv-stage"><?= rv_h((string) ($status['stage'] ?? 'задача поставлена…')) ?></div>
    <p class="hint">Идёт: <span id="rv-seconds"><?= rv_h(verrata_elapsed_text($elapsed)) ?></span>. Загрузка данных агента занимает около минуты, проверка строк моделью — ещё несколько минут.</p>
    <pre class="rv-log" id="rv-log"><?= rv_h(implode("\n", (array) ($status['log'] ?? []))) ?></pre>
  </div>
  <script>
    (function () {
      var s = <?= (int) $elapsed ?>;
      var seconds = document.getElementById('rv-seconds');
      setInterval(function () {
        s += 1;
        var m = Math.floor(s / 60), sec = s % 60;
        seconds.textContent = m > 0 ? m + ' мин ' + (sec < 10 ? '0' : '') + sec + ' с' : s + ' с';
      }, 1000);
      function poll() {
        fetch('rv_status.php?token=<?= rv_h($token) ?>&json=1', {cache: 'no-store'})
          .then(function (r) { return r.json(); })
          .then(function (data) {
            if (data.state !== <?= json_encode($state) ?>) { location.reload(); return; }
            document.getElementById('rv-stage').textContent = data.stage || 'в работе…';
            document.getElementById('rv-log').textContent = (data.log || []).join('\n');
            setTimeout(poll, 4000);
          })
          .catch(function () { setTimeout(poll, 8000); });
      }
      setTimeout(poll, 4000);
    })();
  </script>

<?php elseif ($state === 'done' && $summary !== null): ?>
  <?php
    // Шапка: путь в дереве (объект › корпус › система › вид работ) для ЛРВ из 1С, иначе «Мои загрузки».
    $is1c = ($job['origin'] ?? '') === '1c';
    $meta = $is1c ? rv_table_meta(rv_registry_meta($job, rv_objects())) : null;
    $crumbs = [['РВ по ЛРВ', 'rv.php']];
    $title = (string) ($job['source_name'] ?? '');
    $subParts = [];
    if ($meta !== null) {
        $system = $meta['table_system'] !== '' ? $meta['table_system'] : $meta['system'];
        $kindText = $meta['work_kind'] === 'НЗ' ? 'Наряд-заказ' : 'Основной договор';
        if ($meta['folder'] !== '') {
            $q = ['obj' => $meta['folder_key']];
            $crumbs[] = [$meta['folder'], 'rv.php?' . http_build_query($q)];
            if ($meta['building_label'] !== '') {
                $q['bld'] = $meta['building_label'];
                $crumbs[] = [$meta['building_label'], 'rv.php?' . http_build_query($q)];
            } else {
                $q['bld'] = '';
            }
            $q['sys'] = $system;
            $crumbs[] = [$system, 'rv.php?' . http_build_query($q)];
            $q['kind'] = $meta['work_kind'] === 'НЗ' ? 'НЗ' : 'осн';
            $crumbs[] = [$kindText, 'rv.php?' . http_build_query($q)];
        } else {
            $crumbs[] = ['Не сопоставлено', 'rv.php?node=unmatched'];
            $crumbs[] = [$meta['obj'], null];
        }
        $zn = $meta['zn'] !== '' ? $meta['zn'] : implode(', ', array_map('strval', array_keys((array) ($summary['zn'] ?? []))));
        $title = ($meta['building_label'] !== '' ? $meta['building_label'] : $meta['obj']) . ' · ' . $system . ($meta['work_kind'] === 'НЗ' && $zn !== '' ? ' · НЗ ' . $zn : '');
        $subParts[] = 'ЛРВ из 1С от ' . rv_when((int) ($job['created'] ?? 0));
        if ($meta['smeta'] !== '') {
            $subParts[] = 'смета «' . (mb_strlen($meta['smeta']) > 60 ? mb_substr($meta['smeta'], 0, 58) . '…' : $meta['smeta']) . '»';
        }
    } else {
        $crumbs[] = ['Мои загрузки', 'rv.php?node=uploads'];
        $subParts[] = 'загружена ' . rv_when((int) ($job['created'] ?? 0)) . (!empty($job['user']) ? ', ' . rv_person_label((string) $job['user']) : '');
    }
    $sections = (array) ($summary['sections'] ?? []);
    $subParts[] = (int) $summary['rows'] . ' строк';
    $subParts[] = 'на проверку ' . (int) $summary['review'];
    if ((int) $summary['unbound']) {
        $subParts[] = 'без работы ' . (int) $summary['unbound'];
    }
    $subParts[] = 'работ ' . (int) $summary['works'];
    $resent = rv_resent_text($job);
    $jobMeta = is_array($job['meta'] ?? null) ? $job['meta'] : [];
    // Код работ РВ: заказ-наряд ДР — код 6, РВР — код 12 (rv_confirm.php, 1c_rv.php, rv_kind.php).
    $codeRoot = (string) ($summary['code_root'] ?? rv_code_root_of($job['code_root'] ?? '')) === '12' ? '12' : '6';
    $isOrder = ($jobMeta['kind'] ?? '') === 'НЗ';
    if ($isOrder || $codeRoot === '12') {
        $subParts[] = ($isOrder ? 'заказ-наряд: ' : 'код работ: ') . rv_code_root_label($codeRoot);
    }
    if ($is1c && array_key_exists('sender', $jobMeta)) {
        $subParts[] = (string) $jobMeta['sender'] !== '' ? 'отправил из 1С ' . $jobMeta['sender'] : 'отправлена из 1С автоматически';
    }
    $stateBadge = $isAudit ? ['info', 'Сверка с 1С'] : ($approval ? [!empty($job['onec']['ok']) ? 'success' : 'success', !empty($job['onec']['ok']) ? 'В 1С' : 'Согласована'] : ['warning', 'На проверку']);
  ?>
  <header class="kb-page">
    <nav class="kb-page__crumbs" aria-label="Путь">
      <?php foreach ($crumbs as $i => [$label, $href]): ?>
        <?php if ($i): ?><span>›</span><?php endif; ?>
        <?php if ($href !== null): ?><a href="<?= rv_h($href) ?>"><?= rv_h($label) ?></a><?php else: ?><span><?= rv_h($label) ?></span><?php endif; ?>
      <?php endforeach; ?>
      <?php if ($meta !== null && rv_is_manager()): ?>
        <span class="kb-muted">·</span>
        <?php if ($meta['folder'] !== ''): ?>
        <a href="rv_responsibles.php?object=<?= rv_h(rawurlencode($meta['folder'])) ?>#ng" title="Номенклатурная группа «<?= rv_h($meta['obj']) ?>» попала в объект «<?= rv_h($meta['folder']) ?>» — перенести в другой объект" style="color:var(--c-accent-text);font-weight:600">✎ изменить объект</a>
        <?php else: ?>
        <a href="rv.php?node=unmatched" title="Привязать номенклатурную группу к объекту справочника" style="color:var(--c-accent-text);font-weight:600">✎ привязать к объекту</a>
        <?php endif; ?>
      <?php endif; ?>
    </nav>
    <div class="kb-page__row">
      <div>
        <h1 class="kb-page__title"><?= rv_h($title) ?></h1>
        <p class="kb-page__sub"><span class="kb-badge kb-badge--<?= $stateBadge[0] ?>"><?= rv_h($stateBadge[1]) ?></span> <?= rv_h(implode(' · ', $subParts)) ?><?php if ($approval): ?> · согласовал <?= rv_h(rv_person_label($approval['user'] ?: '—')) ?>, <?= rv_h(rv_when($approval['when'])) ?><?php endif; ?></p>
        <?php $onecDoc = rv_onec_document($job); if ($onecDoc !== null): ?>
        <p class="kb-page__sub" title="<?= rv_h($onecDoc['message']) ?>">В 1С: <b><?= rv_h($onecDoc['title']) ?></b><?= $onecDoc['posted'] === null ? '' : ($onecDoc['posted'] ? ' · проведён' : ' · <span class="kb-warn">не проведён — откройте документ в 1С и проведите</span>') ?><?= $onecDoc['at'] ? ' · загружена ' . rv_h(rv_when($onecDoc['at'])) : '' ?></p>
        <?php endif; ?>
      </div>
      <div class="kb-page__actions">
        <details class="kb-menu">
          <summary class="kb-btn"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 4v11M7 10l5 5 5-5M4 20h16"/></svg>Скачать</summary>
          <ul class="kb-menu__list">
            <li><a href="rv_download.php?token=<?= rv_h($token) ?>&amp;kind=xlsx">РВ в Excel — по форме ТКП</a></li>
            <li><a href="rv_download.php?token=<?= rv_h($token) ?>&amp;kind=json">Результат в JSON</a></li>
            <?php if ($is1c && is_file($paths['onec'])): ?><li><a href="rv_download.php?token=<?= rv_h($token) ?>&amp;kind=onec">РВ для 1С (JSON — то, что забирает 1С)</a></li><?php endif; ?>
            <?php if ($is1c && is_file($paths['in'])): ?><li><a href="rv_download.php?token=<?= rv_h($token) ?>&amp;kind=in">Пакет из 1С (JSON — то, что прислала 1С)</a></li><?php endif; ?>
          </ul>
        </details>
        <details class="kb-menu">
          <summary class="kb-btn kb-btn--icon" aria-label="Ещё действия"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="6" cy="12" r="1.5"/><circle cx="12" cy="12" r="1.5"/><circle cx="18" cy="12" r="1.5"/></svg></summary>
          <ul class="kb-menu__list">
            <?php if ($meta !== null): ?><li><a href="rv_smeta.php?id=<?= rv_h(rawurlencode((string) ($job['lrv_id'] ?? $token))) ?>">Карточка сметы: версии, работы, НЗ</a></li><?php endif; ?>
            <?php if ($meta !== null && rv_is_manager()): ?><li><a href="<?= $meta['folder'] !== '' ? 'rv_responsibles.php?object=' . rv_h(rawurlencode($meta['folder'])) . '#ng' : 'rv.php?node=unmatched' ?>"><?= $meta['folder'] !== '' ? 'Изменить объект (сейчас «' . rv_h($meta['folder']) . '»)' : 'Привязать к объекту' ?></a></li><?php endif; ?>
            <?php if (!$isAudit && $meta !== null && !rv_onec_loaded($job)): ?><li><a href="#rv-local" onclick="var d=document.getElementById('rv-local'); if (d) d.open = true;">Указания для этой РВ (ТЗ агенту)</a></li><?php endif; ?>
            <li><a href="#rv-notes">Замечание к агенту (общее)</a></li>
            <?php if ($canRebuild): ?>
            <li><form action="rv_rebuild.php" method="post" onsubmit="return confirm('Пересобрать эту РВ?\n\nАгент заново привяжет строки и посчитает коэффициенты по текущим правилам (в том числе уменьшения по ЛРВ). Решения инженера по этой РВ учитываются.<?= $approval ? '\n\nРВ согласована: если изменится то, что уйдёт в 1С, согласование снимется и РВ нужно будет проверить заново.' : '' ?>');"><input type="hidden" name="csrf" value="<?= rv_h(rv_csrf()) ?>"><input type="hidden" name="token" value="<?= rv_h($token) ?>"><button type="submit">Пересобрать РВ</button></form></li>
            <?php endif; ?>
            <?php if ($canRebuild && ($isOrder || $codeRoot === '12')): ?>
            <?php $otherRoot = $codeRoot === '12' ? '6' : '12'; ?>
            <li><form action="rv_kind.php" method="post" onsubmit="return confirm('Собрать эту РВ заново из работ <?= $otherRoot === '12' ? 'кода 12 (РВР)' : 'кода 6 (ДР)' ?>?\n\nРаботы в другом коде другие: согласование, исправления по этой РВ, разбивки строк и добавленные работы будут сброшены.');"><input type="hidden" name="token" value="<?= rv_h($token) ?>"><input type="hidden" name="csrf" value="<?= rv_h(rv_csrf()) ?>"><input type="hidden" name="code_root" value="<?= $otherRoot ?>"><button type="submit">Заказ-наряд — <?= $otherRoot === '12' ? 'РВР: собрать в коде 12' : 'ДР: собрать в коде 6' ?></button></form></li>
            <?php endif; ?>
            <?php if ($canRollback): ?>
            <li><form action="rv_rollback.php" method="post" onsubmit="return confirm('Откатить согласование этой РВ?\n\nРешения инженера по ней будут убраны из памяти агента (где до них было другое решение — оно вернётся), РВ пересоберётся без них и станет «на проверку».');"><input type="hidden" name="csrf" value="<?= rv_h(rv_csrf()) ?>"><input type="hidden" name="token" value="<?= rv_h($token) ?>"><button type="submit">Откатить согласование</button></form></li>
            <?php endif; ?>
            <li><form action="rv_delete.php" method="post" onsubmit="return confirm('Удалить эту РВ с сервера? Решения по проверке агент сохранит.');"><input type="hidden" name="csrf" value="<?= rv_h(rv_csrf()) ?>"><input type="hidden" name="tokens[]" value="<?= rv_h($token) ?>"><button type="submit" style="color:var(--c-error)">Удалить РВ</button></form></li>
          </ul>
        </details>
        <?php if (!$isAudit): ?><button type="button" class="kb-btn kb-btn--primary rv-save-top"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12l5 5L20 7"/></svg>Согласовать РВ</button><?php endif; ?>
      </div>
    </div>
  </header>

  <?php
    // Поля пакета, которых сайт не знает, — подсказка для того, кто настраивает обмен с 1С (администратор), не для сметчика.
    // Служебные поля обработки (ОтветственныйGUID, ДатаОтправки) в пакетах до обновления сайта тоже здесь не показываются.
    $unknownShown = array_values(array_diff(array_map('strval', (array) ($job['unknown_fields'] ?? [])), ['ОтветственныйGUID', 'ОтправилGUID', 'ДатаОтправки']));
  ?>
  <?php if ($unknownShown && is_admin_tier_role((string) ($_SESSION['kb_role'] ?? ''))): ?>
  <div class="kb-alert kb-alert--warning"><span>Для администратора: в пакете из 1С есть поля, которых сайт не знает и не читает: <b><?= rv_h(implode(', ', $unknownShown)) ?></b>.<?php if (!empty($job['no_positions'])): ?> Работ сметы в пакете нет — они должны приходить в блоке «СметныеПозиции» (docs/1С_выгрузка_ЛРВ_на_сайт.md, 3.6).<?php endif; ?></span><?php if (is_file($paths['in'])): ?><a class="kb-btn kb-btn--sm" href="rv_download.php?token=<?= rv_h($token) ?>&amp;kind=in">Пакет из 1С</a><?php endif; ?></div>
  <?php endif; ?>
  <?php if (!$isAudit && (int) ($summary['unbound'] ?? 0) > 0): ?>
  <div class="kb-alert kb-alert--warning"><span>Строк без работы: <b><?= (int) $summary['unbound'] ?></b>. Согласовать можно, когда каждой назначена работа — фильтр «только без работы» в таблице. Несогласованную РВ 1С не загружает.</span></div>
  <?php endif; ?>
  <?php if ($feedbackDone && $isAudit): ?>
  <div class="kb-alert kb-alert--success"><span>Решения по сверке записаны в память агента<?= !empty($feedbackDone['user']) ? ' (' . rv_h(rv_person_label((string) $feedbackDone['user'])) . ')' : '' ?>: исправлено строк <?= (int) ($feedbackDone['corrected'] ?? 0) ?>, подтверждено <?= (int) ($feedbackDone['confirmed'] ?? 0) ?>; РВ пересобрана.</span></div>
  <?php elseif ($feedbackDone && !$approval): ?>
  <div class="kb-alert kb-alert--warning"><span>Проверка сохранена<?= !empty($feedbackDone['user']) ? ' (' . rv_h(rv_person_label((string) $feedbackDone['user'])) . ')' : '' ?>, но после пересборки остались строки без работы — РВ не согласована. Назначьте им работу и сохраните проверку ещё раз.</span></div>
  <?php endif; ?>
  <?php if (!$approval && $rollback !== null): ?>
  <div class="kb-alert kb-alert--warning"><span>Согласование отменено<?= ($rollback['by'] ?? '') !== '' ? ': ' . rv_h(rv_person_label((string) $rollback['by'])) : '' ?>, <?= rv_h(rv_when((int) ($rollback['at'] ?? 0))) ?><?php if ($rollbackDone): ?>. Из памяти агента убрано решений: <?= (int) ($rollbackDone['removed'] ?? 0) ?>, возвращено прежних: <?= (int) ($rollbackDone['restored'] ?? 0) ?><?php endif; ?> — РВ пересобрана и снова ждёт проверки<?= !empty($job['onec']['ok']) ? '. В 1С РВ уже была загружена — там она не меняется' : '' ?>.</span></div>
  <?php endif; ?>
  <?php if ($rebuiltLast): ?>
  <?php $rbChanges = is_array($rebuiltRun['changes'] ?? null) ? $rebuiltRun['changes'] : null; $rbReset = !empty($rebuiltRun['approval_reset']); ?>
  <div class="kb-alert <?= $rbReset ? 'kb-alert--warning' : 'kb-alert--info' ?>"><span>РВ пересобрана <?= rv_h(rv_when((int) ($rebuilt['at'] ?? 0))) ?><?= ($rebuilt['by'] ?? '') !== '' ? ' (' . rv_h(rv_person_label((string) $rebuilt['by'])) . ')' : '' ?>: привязка и коэффициенты пересчитаны по текущим правилам с учётом решений инженера<?php if ($rbChanges !== null): ?>; для 1С изменилось работ <?= (int) $rbChanges['works'] ?>, строк <?= (int) $rbChanges['rows'] ?><?php endif; ?>.<?php if ($rbReset): ?> <b>Согласование снято</b> — проверьте изменения (выделены зелёным) и согласуйте РВ заново; до этого 1С её не загрузит.<?php elseif ($approval): ?> Для 1С ничего не изменилось — согласование сохранено.<?php endif; ?></span></div>
  <?php endif; ?>
  <?php if (rv_onec_loaded($job) && !$isAudit): ?>
  <div class="kb-alert kb-alert--info"><span>РВ уже загружена в 1С — пересобрать её на сайте нельзя: в 1С она не обновится, а повторная загрузка задвоила бы привязки. Чтобы учесть изменения (уменьшения по ЛРВ, новые правила), отправьте смету из 1С заново — придёт новая РВ с учётом уже разнесённого.</span></div>
  <?php endif; ?>
  <?php if ($resent !== ''): ?>
  <div class="kb-alert kb-alert--info"><span><?= rv_h(mb_strtoupper(mb_substr($resent, 0, 1)) . mb_substr($resent, 1)) ?> — РВ не перестраивалась.</span></div>
  <?php endif; ?>
  <?php if ($isOrder && $canRebuild && rv_code_root_of($job['code_root'] ?? '') === ''): ?>
  <?php // Заказ-наряд, собранный до выбора ДР / РВР на сайте (или вид не задан): спрашиваем здесь — одним нажатием. ?>
  <div class="kb-alert kb-alert--warning" id="rv-order-kind"><span>Вид заказ-наряда не выбран — РВ собрана из работ <b>кода 6 (ДР)</b>. Если это <b>РВР</b>, соберите её из работ кода 12: согласование и исправления по этой РВ сбросятся.</span>
    <span style="display:flex;gap:8px;flex-wrap:wrap;margin-top:6px">
      <form action="rv_kind.php" method="post" style="margin:0"><input type="hidden" name="token" value="<?= rv_h($token) ?>"><input type="hidden" name="csrf" value="<?= rv_h(rv_csrf()) ?>"><input type="hidden" name="code_root" value="6"><button type="submit" class="kb-btn kb-btn--sm">ДР — оставить код 6</button></form>
      <form action="rv_kind.php" method="post" style="margin:0" onsubmit="return confirm('Собрать эту РВ заново из работ кода 12 (РВР)?\n\nСогласование, исправления по этой РВ, разбивки строк и добавленные работы будут сброшены.');"><input type="hidden" name="token" value="<?= rv_h($token) ?>"><input type="hidden" name="csrf" value="<?= rv_h(rv_csrf()) ?>"><input type="hidden" name="code_root" value="12"><button type="submit" class="kb-btn kb-btn--sm kb-btn--primary">РВР — собрать в коде 12</button></form>
    </span>
  </div>
  <?php endif; ?>

  <?php if ($isAudit) { require __DIR__ . '/rv_audit_block.php'; } ?>

  <div class="card rv-check" id="rv-check"
       data-token="<?= rv_h($token) ?>"
       data-rows-url="rv_status.php?token=<?= rv_h($token) ?>&amp;rows=1"
       data-title="<?= rv_h($meta !== null ? rv_smeta_title($meta) : '') ?>"
       data-feedback-url="rv_feedback.php">
    <h2>Проверка РВ</h2>
    <div class="rv-check-body"><p class="hint">Загружаю строки РВ…</p></div>
  </div>
  <script src="assets/rv_review.js?v=<?= filemtime(__DIR__ . '/assets/rv_review.js') ?>"></script>

  <?php
    $onecStats = is_array($summary['onec'] ?? null) ? $summary['onec'] : null;
    $notes = (array) ($status['notes'] ?? []);
    $questions = (array) ($status['questions'] ?? []);
  ?>
  <details class="kb-card kb-fold">
    <summary class="kb-card__head">Как агент разбирал ЛРВ <span class="kb-muted">· готово за <?= rv_h(verrata_elapsed_text((int) ($status['elapsed'] ?? 0))) ?><?= $notes || $questions ? ' · умолчания и вопросы: ' . (count($notes) + count($questions)) : '' ?></span></summary>
    <div class="kb-card__body">
      <ul class="kb-notes">
        <li>Раздел<?= count($sections) > 1 ? 'ы' : '' ?>: <?= rv_h($sections ? implode(', ', $sections) : (string) $job['section']) ?>; <?= rv_h((string) (RV_OBJECT_TYPES[$job['object_type']] ?? $job['object_type'])) ?>. Строк ЛРВ в работе <?= (int) $summary['rows'] ?><?= !empty($summary['skipped']) ? ', не включено ' . (int) $summary['skipped'] : '' ?>; готово <?= (int) $summary['done'] ?>, на проверку <?= (int) $summary['review'] ?>, без работы <?= (int) $summary['unbound'] ?>; работ <?= (int) $summary['works'] ?>, с объёмом <?= (int) $summary['works_with_volume'] ?>; строк крепежа <?= (int) $summary['kr'] ?>, распределено <?= (int) $summary['kr_distributed'] ?>.</li>
        <li>Проверка моделью: <?= rv_h((string) ($summary['review_note'] ?? '')) ?>. Рекомендации модели не меняют РВ — решение за сметчиком.</li>
        <?php if ($onecStats && ((int) ($onecStats['bound'] ?? 0) || (int) ($onecStats['smeta_works'] ?? 0))): ?>
        <li>Из 1С: работ сметы <b><?= (int) ($onecStats['smeta_works'] ?? 0) ?></b>, строк уже разнесено в 1С <b><?= (int) ($onecStats['bound'] ?? 0) ?></b><?php if ((int) ($onecStats['disputed'] ?? 0)): ?>, агент не согласен по <b><?= (int) $onecStats['disputed'] ?></b> (F-1C: строки блёкло-красные — оставить как в 1С или принять агента)<?php endif; ?><?php if ((int) ($onecStats['not_in_smeta'] ?? 0)): ?>; работ не из сметы — <b><?= (int) $onecStats['not_in_smeta'] ?></b> строк (F-SMETA, в 1С добавятся новыми позициями)<?php endif; ?>.</li>
        <?php endif; ?>
        <?php if ($learned && ((int) ($learned['corrected'] ?? 0) || (int) ($learned['confirmed'] ?? 0))): ?>
        <li>Память решений сметчиков: исправлено <b><?= (int) $learned['corrected'] ?></b> строк, подтверждено <b><?= (int) $learned['confirmed'] ?></b><?= !empty($learned['transferred']) ? ', перенесено из других систем ' . (int) $learned['transferred'] : '' ?> — такие строки повторно не проверяются.</li>
        <?php endif; ?>
        <?php foreach ($notes as $note): ?><li><?= rv_h((string) $note) ?></li><?php endforeach; ?>
        <?php foreach ($questions as $question): ?><li><b>Вопрос владельцу:</b> <?= rv_h((string) $question) ?></li><?php endforeach; ?>
      </ul>
    </div>
  </details>

  <?php $rvNotes = rv_notes($token); $noteState = (string) ($_GET['note'] ?? ''); ?>
  <?php if (!$isAudit && $meta !== null): ?>
  <?php
    // Указания только для этой РВ (rv_local.php): ТЗ агенту — текст и/или файлы; пересборка этой РВ по ним.
    $local = rv_local_read($token);
    if ($local !== null && trim((string) ($local['text'] ?? '')) === '' && !$local['files']) {
        $local = null;
    }
    $localStats = is_array($summary['local'] ?? null) ? $summary['local'] : null;
    $localAgent = $localStats !== null && is_array($localStats['agent'] ?? null) ? $localStats['agent'] : null;
    $localLocked = rv_onec_loaded($job);
  ?>
  <details class="kb-card kb-fold" id="rv-local"<?= $local !== null || ($_GET['err'] ?? '') !== '' ? ' open' : '' ?>>
    <summary class="kb-card__head">Указания для этой РВ <span class="kb-muted">· <?= $local !== null ? 'заданы ' . rv_h(rv_when((int) ($local['at'] ?? 0))) . ', ' . rv_h(rv_person_label((string) ($local['by'] ?? ''))) : 'ТЗ агенту только для этого сопоставления: текст, файлы' ?></span></summary>
    <div class="kb-card__body">
      <p class="kb-muted" style="margin-top:0">Напишите задание агенту и/или приложите файлы — смету, спецификацию, ТЗ. Агент пересоберёт <b>только эту РВ</b>: модель посмотрит все строки с учётом ТЗ и поменяет работы, где ТЗ этого требует, — такие строки будут «на проверку» с пометкой «по указаниям» и причиной. На другие сопоставления это не действует: в общую память агента попадут только ваши ручные исправления. Строки, разнесённые в 1С на другую работу, останутся как в 1С — работа по ТЗ будет предложением.</p>
      <?php if ($localStats !== null && ($localStats['error'] ?? '') !== ''): ?>
      <div class="kb-alert kb-alert--danger"><span>Указания не применены: <?= rv_h((string) $localStats['error']) ?>. Нажмите «Сохранить и пересобрать» ещё раз.</span></div>
      <?php elseif ($localAgent !== null): ?>
      <div class="kb-alert kb-alert--info"><span>По указаниям<?= !empty($localStats['agent_at']) ? ' (' . rv_h(rv_when((int) $localStats['agent_at'])) . ')' : '' ?>: модель проверила <?= (int) ($localAgent['checked'] ?? 0) ?> строк — изменила <?= (int) ($localStats['changed'] ?? $localAgent['changed'] ?? 0) ?> (они «на проверку», пометка «по указаниям»), подтвердила <?= (int) ($localAgent['confirmed'] ?? 0) ?>, вопросов <?= (int) ($localAgent['questions'] ?? 0) ?><?= !empty($localAgent['onec_proposed']) ? '; разнесено в 1С иначе — предложено ' . (int) $localAgent['onec_proposed'] : '' ?><?= !empty($localAgent['not_checked']) ? '; не проверено ' . (int) $localAgent['not_checked'] . ' строк с большей уверенностью' : '' ?>.<?= ($localAgent['files_error'] ?? '') !== '' ? ' PDF/картинки модель не приняла (' . rv_h((string) $localAgent['files_error']) . ') — учтён только текст.' : '' ?></span></div>
      <?php endif; ?>
      <?php if ($localStats !== null && !empty($localStats['skipped'])): ?>
      <div class="kb-alert kb-alert--danger"><span>Не прочитаны: <?= rv_h(implode('; ', array_map('strval', (array) $localStats['skipped']))) ?>.</span></div>
      <?php endif; ?>
      <?php if ($localLocked): ?>
      <p class="kb-muted">РВ уже загружена в 1С — пересобрать её нельзя. Отправьте смету из 1С заново и задайте указания у новой РВ.</p>
      <?php else: ?>
      <form action="rv_local.php" method="post" enctype="multipart/form-data" class="kb-field" onsubmit="return confirm((event.submitter && event.submitter.value === 'clear' ? 'Убрать указания и пересобрать РВ как обычно?' : 'Пересобрать эту РВ по указаниям? Модель посмотрит все строки — это займёт несколько минут.') + '<?= $approval ? '\n\nРВ согласована: если изменится то, что уйдёт в 1С, согласование снимется и РВ нужно будет проверить заново.' : '' ?>');">
        <input type="hidden" name="token" value="<?= rv_h($token) ?>"><input type="hidden" name="csrf" value="<?= rv_h(rv_csrf()) ?>"><input type="hidden" name="action" value="save">
        <label class="kb-field__label" for="rv-local-text">Задание агенту по этой РВ</label>
        <textarea class="kb-input" id="rv-local-text" name="text" rows="5" maxlength="<?= (int) RV_LOCAL_MAX_CHARS ?>" placeholder="Например: распредели материалы по работам приложенной сметы; воздуховоды на этом объекте 0,9 мм — к прокладке толщиной от 0,71 до 0,9; решётки — к монтажу решёток, не к диффузорам"><?= rv_h((string) ($local['text'] ?? '')) ?></textarea>
        <label class="kb-field__label" for="rv-local-files" style="margin-top:12px">Файлы ТЗ</label>
        <?php if ($local !== null && $local['files']): ?>
        <ul class="kb-list" style="margin:0 0 8px;padding-left:18px">
          <?php foreach ($local['files'] as $f): ?>
          <li><a href="rv_local.php?token=<?= rv_h(urlencode($token)) ?>&amp;file=<?= rv_h(urlencode((string) $f['file'])) ?>"><?= rv_h((string) ($f['name'] ?? $f['file'])) ?></a> <span class="kb-muted">· <?php $sz = (int) ($f['size'] ?? 0); echo $sz >= 1048576 ? rv_h(number_format($sz / 1048576, 1, ',', ' ')) . ' МБ' : max(1, (int) ceil($sz / 1024)) . ' КБ'; ?></span> <label class="kb-muted" style="margin-left:8px"><input type="checkbox" name="remove[]" value="<?= rv_h((string) $f['file']) ?>"> убрать</label></li>
          <?php endforeach; ?>
        </ul>
        <?php endif; ?>
        <input type="file" id="rv-local-files" name="files[]" multiple accept="<?= rv_h(implode(',', array_map(static fn (string $e): string => '.' . $e, RV_LOCAL_TYPES))) ?>">
        <span class="kb-field__help">PDF, Excel, Word (.docx), CSV, TXT, картинки — до <?= (int) megabytes(RV_LOCAL_MAX_BYTES) ?> МБ каждый, всего не больше <?= (int) RV_LOCAL_MAX_FILES ?>. Таблицы и Word агент читает текстом, PDF и картинки модель смотрит сама (PDF — лучше до 100 страниц).</span>
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin-top:12px">
          <button type="submit" class="kb-btn kb-btn--sm kb-btn--primary">Сохранить и пересобрать</button>
          <?php if ($local !== null): ?>
          <button type="submit" class="kb-btn kb-btn--sm" name="action" value="clear" formnovalidate>Убрать указания</button>
          <?php endif; ?>
        </div>
      </form>
      <?php endif; ?>
    </div>
  </details>
  <?php endif; ?>

  <details class="kb-card kb-fold" id="rv-notes"<?= $noteState !== '' || $rvNotes ? ' open' : '' ?>>
    <summary class="kb-card__head">Замечания к агенту <span class="kb-muted">· общие, для всех следующих РВ<?= $rvNotes ? ' · ' . count($rvNotes) : '' ?></span></summary>
    <div class="kb-card__body">
      <?php if ($noteState === 'saved'): ?><div class="kb-alert kb-alert--success"><span>Замечание сохранено — спасибо.</span></div><?php endif; ?>
      <?php if ($noteState === 'expired'): ?><div class="kb-alert kb-alert--danger"><span>Сессия истекла — обновите страницу и отправьте замечание ещё раз.</span></div><?php endif; ?>
      <form action="rv_note.php" method="post" class="kb-field">
        <input type="hidden" name="token" value="<?= rv_h($token) ?>">
        <input type="hidden" name="csrf" value="<?= rv_h(rv_csrf()) ?>">
        <label class="kb-field__label" for="rv-note-text">Что доработать в агенте или что ему нужно знать</label>
        <textarea class="kb-input" id="rv-note-text" name="text" rows="3" maxlength="<?= (int) RV_NOTE_MAX_CHARS ?>" required placeholder="Например: хомуты Rapid в К2 всегда относить к прокладке чугунных труб"></textarea>
        <div><button type="submit" class="kb-btn kb-btn--sm">Отправить замечание</button></div>
      </form>
      <?php if ($rvNotes): ?>
      <ul class="kb-notes" style="margin-top:16px">
        <?php foreach ($rvNotes as $note): ?>
        <li><span class="kb-muted"><?= rv_h(rv_when((int) ($note['when'] ?? 0))) ?>, <?= rv_h(rv_person_label((string) ($note['user'] ?? ''))) ?>:</span> <?= nl2br(rv_h((string) ($note['text'] ?? ''))) ?></li>
        <?php endforeach; ?>
      </ul>
      <?php endif; ?>
    </div>
  </details>

<?php else: ?>
  <div class="card">
    <h1>РВ не построена</h1>
    <?php if ($state === 'stalled'): ?>
      <?php if (($status['launched'] ?? null) === false): ?>
      <div class="alert error">Фоновый процесс агента не запустился за <?= (int) (RV_START_TIMEOUT_SEC / 60) ?> мин. Загрузите ЛРВ ещё раз; если повторится, сообщите администратору — ниже журнал запуска.</div>
      <?php else: ?>
      <div class="alert error">Фоновый процесс не подал признаков жизни дольше <?= (int) (RV_STALL_SEC / 60) ?> минут — обработка оборвалась<?= !empty($status['stage']) ? ' на шаге «' . rv_h((string) $status['stage']) . '»' : '' ?>. Чаще всего так бывает, когда хостинг останавливает процесс за превышение памяти или времени. Загрузите ЛРВ ещё раз; если повторится, сообщите администратору — ниже журнал агента.</div>
      <?php endif; ?>
    <?php elseif ($state === 'missing'): ?>
      <div class="alert error">Задача не была запущена: файл статуса не найден.</div>
    <?php else: ?>
      <div class="alert error"><?= rv_h((string) ($status['error'] ?? 'Ошибка обработки.')) ?></div>
    <?php endif; ?>
    <?php if (!empty($status['log'])): ?><pre class="rv-log"><?= rv_h(implode("\n", (array) $status['log'])) ?></pre><?php endif; ?>
    <?php
      // Хвост общего журнала агента (stdout/stderr фоновых процессов): трассировки, «Killed», MemoryError —
      // чтобы причину было видно без доступа к серверу. Страница открыта только тем, кому открыт ЦО.
      $errLog = RV_OUTPUT_DIR . '/rv_errors.log';
      $tail = [];
      if (is_file($errLog) && ($fh = fopen($errLog, 'r'))) {
          fseek($fh, max(0, filesize($errLog) - 8000));
          $tail = array_slice(explode("\n", trim((string) stream_get_contents($fh))), -40);
          fclose($fh);
      }
    ?>
    <?php if ($tail): ?>
    <details class="rv-sample"><summary>Журнал агента на сервере (последние строки)</summary><pre class="rv-log"><?= rv_h(implode("\n", $tail)) ?></pre></details>
    <?php endif; ?>
    <div class="rv-status-actions">
      <a class="back-link" href="rv.php">К форме загрузки</a>
      <form class="inline-form" action="rv_delete.php" method="post" onsubmit="return confirm('Удалить эту задачу с сервера?');">
        <input type="hidden" name="csrf" value="<?= rv_h(rv_csrf()) ?>">
        <input type="hidden" name="tokens[]" value="<?= rv_h($token) ?>">
        <button type="submit" class="btn-small btn-danger">Удалить</button>
      </form>
    </div>
  </div>
<?php endif; ?>

  <?php if (!$isDone): ?></div><?php endif; ?>
  </div>
</div>
</body>
</html>
