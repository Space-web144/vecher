<?php
declare(strict_types=1);

require __DIR__ . '/auth_guard.php';
require_once __DIR__ . '/users.php';
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Оборудование — База знаний</title>
<link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
<script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
<script src="assets/dropzone.js?v=<?= filemtime(__DIR__ . '/assets/dropzone.js') ?>" defer></script>
</head>
<body>
<div class="shell">
  <?php require __DIR__ . '/sidebar.php'; ?>

  <div class="dashboard-main">
  <div class="page">

  <div class="card">
    <h1>Сверка марок вентиляторов</h1>
    <p class="subtitle">Загрузите альбом проекта целиком (PDF). Программа сопоставит ХСОВ, спецификацию и листы подбора: вентиляторы сравниваются с вентиляторами, установки — с установками. В Excel сохраняются марки, статусы, номера страниц и замечания. Различия подсвечиваются красным, неполные данные и неоднозначные связи — жёлтым. На листах «Источники», «Листы» и «Проверка» можно проверить, откуда взяты значения и какие страницы требуют внимания.</p>

    <form action="process_pdf.php" method="post" enctype="multipart/form-data">
      <div class="field">
        <label class="field-label" for="pdf_file">Альбом проекта (.pdf)</label>
        <input type="file" id="pdf_file" name="pdf_file" accept=".pdf" required>
      </div>
      <input type="hidden" name="format" value="equipment">

      <button type="submit">Сверить марки вентиляторов</button>
    </form>
  </div>

  </div>
  </div>
</div>
</body>
</html>
