<?php
declare(strict_types=1);

require __DIR__ . '/auth_guard.php';
require_once __DIR__ . '/users.php';
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>VentSpec — База знаний</title>
<link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
<script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
<script src="assets/dropzone.js?v=<?= filemtime(__DIR__ . '/assets/dropzone.js') ?>" defer></script>
</head>
<body>
<div class="shell">
  <?php require __DIR__ . '/sidebar.php'; ?>

  <div class="dashboard-main">
  <div class="page">

  <div class="card">
    <h1>Обработка спецификации</h1>
    <p class="subtitle">Загрузите файл спецификации и выберите режим обработки.</p>

    <form action="process.php" method="post" enctype="multipart/form-data">
      <div class="field">
        <label class="field-label" for="spec_file">Файл спецификации (.xlsx)</label>
        <input type="file" id="spec_file" name="spec_file" accept=".xlsx,.xls" required>
      </div>

      <div class="field">
        <label class="field-label">Режим обработки</label>
        <div class="mode-options">
          <label class="mode-option">
            <input type="radio" name="mode" value="full" checked>
            <span class="mode-text">
              <strong>Полная обработка</strong>
              <span>Раскраска, формулы, площадь фасонных изделий, сравнение с 1С</span>
            </span>
          </label>
          <label class="mode-option">
            <input type="radio" name="mode" value="match">
            <span class="mode-text">
              <strong>Только сравнение с 1С</strong>
              <span>Проверка позиций по базе номенклатуры</span>
            </span>
          </label>
          <label class="mode-option">
            <input type="radio" name="mode" value="fitting">
            <span class="mode-text">
              <strong>Только расчёт площади фасонных изделий</strong>
              <span>Заполняет только столбец «Вспомогательный». Данные, формулы и оформление остальных ячеек сохраняются. База 1С не требуется.</span>
            </span>
          </label>
        </div>
      </div>

      <button type="submit">Обработать спецификацию</button>
    </form>
  </div>

  <div class="card">
    <h2>Конвертация PDF в Excel</h2>
    <p class="subtitle">Загрузите PDF-спецификацию («Спецификация оборудования и материалов») — данные из таблицы соберутся в Excel того же формата, что понимает VentSpec. Сравнение с 1С в этот шаг не входит — полученный файл можно после этого загрузить выше.</p>

    <form action="process_pdf.php" method="post" enctype="multipart/form-data">
      <div class="field">
        <label class="field-label" for="pdf_file">Файл спецификации (.pdf)</label>
        <input type="file" id="pdf_file" name="pdf_file" accept=".pdf" required>
      </div>
      <input type="hidden" name="format" value="ventspec">

      <button type="submit" class="secondary">Получить Excel из PDF</button>
    </form>
  </div>

  </div>
  </div>
</div>
</body>
</html>
