<?php
declare(strict_types=1);

// Подтверждение ВСЕЙ очереди ручной проверки (web/onec_review.php) одним
// действием — в отличие от web/onec_review_bulk.php (отмеченные галочками
// позиции, максимум 50 за раз — ограничение постраничного вывода) здесь
// список выбранного строится НА СЕРВЕРЕ из полного load_pending_entries(),
// а не из чекбоксов в браузере: при тысячах позиций кликать по страницам,
// отмечая каждую по 50 штук, непрактично.
//
// ВАЖНО: это самый грубый путь — позиции добавляются КАК ЕСТЬ, включая
// отмеченные "Опечатка?"/"Не вентиляция?"/"Семантически близко" (не
// только "Дубликат?"). Удаление дублей на web/onec_db_duplicates.php их
// не поймает — тот инструмент ищет только позиции с ПОЛНОСТЬЮ одинаковым
// текстом наименования, а опечатка/нерелевантность — другого рода
// проблема. Пользователь явно выбрал этот путь, зная о компромиссе.
// Доступно только admin/mainadmin (см. admin_guard.php).

require __DIR__ . '/admin_guard.php';
require __DIR__ . '/config.php';

if (is_file(__DIR__ . '/data/.catalog-routing-deploying')) {
    http_response_code(503);
    header('Retry-After: 30');
    exit('Обновляется приём номенклатуры. Повторите действие через 30 секунд.');
}

function back_with(array $params): never {
    header('Location: onec_review.php?' . http_build_query($params));
    exit;
}

function back_with_error(string $message, string $q): never {
    $params = ['err' => $message];
    if ($q !== '') {
        $params['q'] = $q;
    }
    back_with($params);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: onec_review.php');
    exit;
}

$q = trim((string) ($_POST['q'] ?? ''));

if (empty($_SESSION['csrf']) || !hash_equals((string) $_SESSION['csrf'], (string) ($_POST['csrf'] ?? ''))) {
    back_with_error('Сессия истекла, обновите страницу и попробуйте снова.', $q);
}

// Та же логика, что в web/onec_review.php — список неразрешённых записей
// из всех <токен>_1c_pending.json в OUTPUT_DIR, с тем же текстовым
// фильтром по q, если он задан.
function load_pending_entries(): array {
    $files = glob(OUTPUT_DIR . '/*_1c_pending.json') ?: [];
    $entries = [];
    foreach ($files as $path) {
        $raw = file_get_contents($path);
        $data = $raw !== false ? json_decode($raw, true) : null;
        if (!is_array($data)) {
            continue;
        }
        foreach ($data as $entry) {
            if (!is_array($entry) || !empty($entry['resolved'])) {
                continue;
            }
            $entries[] = $entry;
        }
    }
    return $entries;
}

function matches_entry_query(array $entry, string $q): bool {
    if ($q === '') {
        return true;
    }
    $needle = mb_strtolower($q, 'UTF-8');
    $item = $entry['raw_item'] ?? [];
    foreach (['Наименование', 'Код'] as $field) {
        $val = (string) ($item[$field] ?? '');
        if ($val !== '' && mb_strpos(mb_strtolower($val, 'UTF-8'), $needle) !== false) {
            return true;
        }
    }
    return false;
}

$allEntries = load_pending_entries();
$entries = $q === '' ? $allEntries : array_values(array_filter($allEntries, fn($e) => matches_entry_query($e, $q)));
if (!$entries) {
    back_with_error('Очередь (с учётом поиска) пуста — нечего подтверждать.', $q);
}

if (!is_file(ONEC_NOMENCLATURE_FILE)) {
    back_with_error('Нет эталонного снимка базы номенклатуры для сравнения.', $q);
}
if (!is_dir(OUTPUT_DIR) || !is_writable(OUTPUT_DIR)) {
    back_with_error('Папка для результатов недоступна на сервере.', $q);
}

$selections = [];
foreach ($entries as $entry) {
    if (!isset($entry['token'], $entry['id'])) {
        continue;
    }
    $selections[] = ['token' => (string) $entry['token'], 'id' => (int) $entry['id']];
}
if (!$selections) {
    back_with_error('Не удалось собрать список позиций для подтверждения.', $q);
}

$selectionsPath = OUTPUT_DIR . '/bulk_selections_' . bin2hex(random_bytes(8)) . '.json';
if (file_put_contents($selectionsPath, json_encode($selections, JSON_UNESCAPED_UNICODE)) === false) {
    back_with_error('Не удалось сохранить список позиций на сервере.', $q);
}

$cmdParts = [
    escapeshellarg(PYTHON_BIN),
    escapeshellarg(WEB_1C_REVIEW_BULK_SCRIPT),
    '--selections-file', escapeshellarg($selectionsPath),
    '--pending-dir', escapeshellarg(OUTPUT_DIR),
    '--existing', escapeshellarg(ONEC_NOMENCLATURE_FILE),
];
if (is_file(DB_FILE)) {
    $cmdParts[] = '--db-file';
    $cmdParts[] = escapeshellarg(DB_FILE);
}
$cmd = implode(' ', $cmdParts) . ' 2>&1';
$output = shell_exec($cmd);
@unlink($selectionsPath);

if ($output === null || trim($output) === '') {
    back_with_error('Не удалось подтвердить очередь: команда не выполнилась (shell_exec '
        . 'недоступен на сервере, или путь PYTHON_BIN в config.php неверный).', $q);
}

$result = json_decode($output, true);
if (!is_array($result) || empty($result['ok'])) {
    $detail = is_array($result) ? (string) ($result['error'] ?? 'неизвестная ошибка') : trim($output);
    if (mb_strlen($detail, 'UTF-8') > 2000) {
        $detail = '…' . mb_substr($detail, -2000, null, 'UTF-8');
    }
    back_with_error('Не удалось подтвердить очередь: ' . $detail, $q);
}

back_with([
    'bulk' => 'approve',
    'count' => (int) ($result['promoted'] ?? 0),
    'errCount' => count($result['errors'] ?? []),
    'q' => $q,
]);
