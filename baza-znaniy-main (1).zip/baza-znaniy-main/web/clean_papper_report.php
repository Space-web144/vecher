<?php
declare(strict_types=1);

// Private export: NEVER receives the PDF or API key. Uses only the current
// browser's bounded, explicitly unverified classification snapshot.
require __DIR__ . '/clean_papper_guard.php';
require_once __DIR__ . '/clean_papper_api_lib.php';

function cp_report_error(string $message, int $status): void
{
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: private, no-store');
    echo json_encode(['ok' => false, 'message' => $message], JSON_UNESCAPED_UNICODE);
    exit;
}
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    cp_report_error('Используйте POST.', 405);
}
if (!is_string($_SESSION['clean_papper_csrf'] ?? null)
    || !hash_equals($_SESSION['clean_papper_csrf'], (string) ($_POST['csrf'] ?? ''))) {
    cp_report_error('Сессия устарела. Обновите страницу.', 403);
}
$json = $_POST['report'] ?? null;
if (!is_string($json) || strlen($json) < 50 || strlen($json) > 180000) {
    cp_report_error('Протокол распознавания отсутствует или слишком большой.', 413);
}
$parsed = json_decode($json, true);
if (!is_array($parsed) || ($parsed['schema'] ?? '') !== 'clean-papper.evidence.v1'
    || !is_array($parsed['source'] ?? null)
    || !is_array($parsed['geometry'] ?? null)
    || !is_array($parsed['vision'] ?? null)
    || !is_array($parsed['vision']['elements'] ?? null)
    || count($parsed['vision']['elements']) > 16
    || !is_array($parsed['geometry']['section_text_candidates'] ?? null)
    || count($parsed['geometry']['section_text_candidates']) > 45) {
    cp_report_error('Неверный формат данных. Выполните анализ Claude повторно.', 400);
}
$python = cp_python_binary();
$worker = dirname(__DIR__) . '/common/clean_papper_reports.py';
if (!$python || !is_file($worker) || !function_exists('proc_open')) {
    cp_report_error('Генератор Excel недоступен на сервере.', 503);
}

session_write_close();
$process = @proc_open([$python, $worker],
    [0 => ['pipe', 'r'], 1 => ['pipe', 'w'], 2 => ['pipe', 'w']],
    $pipes, dirname(__DIR__));
if (!is_resource($process)) {
    cp_report_error('Не удалось запустить экспорт Excel.', 503);
}
$size = strlen($json);
$sent = 0;
while ($sent < $size) {
    $written = @fwrite($pipes[0], substr($json, $sent));
    if ($written === false || $written === 0) {
        break;
    }
    $sent += $written;
}
fclose($pipes[0]);
stream_set_blocking($pipes[1], false);
stream_set_blocking($pipes[2], false);
$bytes = '';
$started = microtime(true);
$failed = ($sent !== $size);
$timedOut = false;
while (true) {
    $bytes .= (string) stream_get_contents($pipes[1]);
    stream_get_contents($pipes[2]);  // Never expose internal logs/paths.
    if (strlen($bytes) > 2000000) {
        $failed = true;
        @proc_terminate($process);
        break;
    }
    $status = proc_get_status($process);
    if (!$status['running']) {
        break;
    }
    if (microtime(true) - $started > 25) {
        $timedOut = true;
        @proc_terminate($process);
        break;
    }
    usleep(100000);
}
$bytes .= (string) stream_get_contents($pipes[1]);
fclose($pipes[1]);
fclose($pipes[2]);
@proc_close($process);
if ($timedOut || $failed || strlen($bytes) > 2000000 || strlen($bytes) < 100
    || substr($bytes, 0, 2) !== 'PK') {
    cp_report_error('Не удалось собрать Excel. Повторите экспорт или скачайте JSON.', 503);
}
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="Clean_Papper_materials_' . gmdate('Ymd_His') . '.xlsx"');
header('Content-Length: ' . strlen($bytes));
header('Cache-Control: private, no-store, max-age=0');
header('X-Content-Type-Options: nosniff');
echo $bytes;
