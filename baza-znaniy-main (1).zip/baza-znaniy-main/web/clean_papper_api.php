<?php
declare(strict_types=1);

require __DIR__ . '/clean_papper_guard.php';
require_once __DIR__ . '/clean_papper_api_lib.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: private, no-store, max-age=0');
header('X-Content-Type-Options: nosniff');

function cp_json(array $value, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($value, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    cp_json(['ok' => false, 'message' => 'Разрешён только POST.'], 405);
}
if (!isset($_SESSION['clean_papper_csrf']) || !is_string($_SESSION['clean_papper_csrf'])
    || !hash_equals($_SESSION['clean_papper_csrf'], (string) ($_POST['csrf'] ?? ''))) {
    cp_json(['ok' => false, 'message' => 'Сессия устарела. Обновите страницу.'], 403);
}
$action = (string) ($_POST['action'] ?? '');
if (!in_array($action, ['status', 'ping'], true)) {
    cp_json(['ok' => false, 'message' => 'Неизвестный тип проверки.'], 400);
}
if ($action === 'ping') {
    $now = time();
    $last = (int) ($_SESSION['clean_papper_last_ping'] ?? 0);
    if ($now - $last < 60) {
        cp_json(['ok' => false, 'message' => 'Повторную платную проверку можно выполнить через минуту.'], 429);
    }
    // Reserve cooldown before starting a potentially billed request.
    $_SESSION['clean_papper_last_ping'] = $now;
}
session_write_close();

$result = cp_run_anthropic_probe($action);
cp_json($result, $result['ok'] ? 200 : 503);
