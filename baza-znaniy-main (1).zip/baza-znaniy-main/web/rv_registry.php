<?php
declare(strict_types=1);

// Объекты и ЛРВ из 1С: дерево объект → корпус → смета (система, вид работ, номер ЗН) с ответственными сметчиками
// и состоянием РВ по всему пути — пришла → строится → готова → согласована → загружена в 1С.
// Объекты и корпуса — из справочника «Объекты и ответственные» (rv_responsibles.php, таблица «Объекты и сметчики»);
// номенклатурная группа из 1С находит в нём свой объект и корпус по названию (rv_table_match), не нашла —
// лежит в «Не сопоставлено» до привязки вручную. Ответственный — свой у сметы, иначе назначенный на НГ или объект,
// иначе по ячейке справочника (корпус, система, вид работ), иначе запасной по группе систем.
// Карточка сметы с версиями РВ, основными работами и наряд-заказами — rv_smeta.php.
// Данные — задачи агента РВ (rv_registry_rows в rv_lib.php), назначения — rv_assign.php.
// Доступ — как к модулю ЦО (rv_guard). ?csv=1 — весь список файлом.

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require_once __DIR__ . '/users.php';
require_once __DIR__ . '/lib.php';
require_once __DIR__ . '/rv_lib.php';

rv_guard();

if (!isset($_GET['csv'])) {
    header('Location: rv.php');      // дерево объектов теперь на странице «РВ по ЛРВ»; здесь остался только CSV
    exit;
}

$me = (string) ($_SESSION['kb_user'] ?? '');
$canAssign = rv_can_assign();
$canTake = rv_can_take();
$estimators = rv_estimators();
$csrf = rv_csrf();
$all = rv_registry_rows();
$table = rv_table();
$tableObjects = rv_table_objects($table);

// ── Фильтры ──
$filter = [
    'q' => trim((string) ($_GET['q'] ?? '')),
    'user' => trim((string) ($_GET['user'] ?? '')),
    'state' => trim((string) ($_GET['state'] ?? '')),
];
$rows = array_values(array_filter($all, static function (array $row) use ($filter, $me): bool {
    if ($filter['q'] !== '') {
        $hay = mb_strtolower($row['folder'] . ' ' . $row['building_label'] . ' ' . $row['obj'] . ' ' . $row['system'] . ' ' . $row['smeta'] . ' '
            . $row['zn'] . ' ' . implode(' ', $row['zn_list']) . ' ' . (string) ($row['responsible']['user'] ?? '') . ' ' . (string) ($row['responsible']['login'] ?? ''));
        foreach (preg_split('/\s+/u', mb_strtolower($filter['q'])) ?: [] as $word) {
            if ($word !== '' && mb_strpos($hay, $word) === false) {
                return false;
            }
        }
    }
    $responsible = (string) ($row['responsible']['user'] ?? '');
    if ($filter['user'] === 'me' && $responsible !== $me) {
        return false;
    }
    if ($filter['user'] === 'none' && $responsible !== '') {
        return false;
    }
    if ($filter['user'] !== '' && !in_array($filter['user'], ['me', 'none'], true) && $responsible !== $filter['user']) {
        return false;
    }
    if ($filter['state'] !== '' && $row['code'] !== $filter['state']) {
        return false;
    }
    return true;
}));
$filterActive = $filter['q'] !== '' || $filter['user'] !== '' || $filter['state'] !== '';
$back = 'rv_registry.php' . ($filterActive ? '?' . http_build_query(array_filter($filter, static fn($v) => $v !== '')) : '');

// ── CSV всего списка ──
if (isset($_GET['csv'])) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="objects_lrv_1c.csv"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, ['Объект', 'Корпус', 'Номенклатурная группа', 'Система', 'Вид работ', 'Смета', 'Номер ЗН', 'Ответственный', 'Состояние', 'Строк ЛРВ', 'Работ', 'На проверку', 'Без работы',
                   'Согласовал', 'Согласовано', 'Загружена в 1С', 'Получена', 'Версий', 'Ссылка'], ';');
    foreach ($rows as $row) {
        fputcsv($out, [$row['folder'], $row['building_label'], $row['obj'], $row['table_system'] !== '' ? $row['table_system'] : $row['system'],
                       $row['work_kind'] === 'НЗ' ? 'НЗ' : 'основной договор', $row['smeta'], rv_zn_text(array_merge([$row['zn']], $row['zn_list'])),
                       (string) (($row['responsible']['user'] ?? '') !== '' ? $row['responsible']['user'] : ($row['responsible']['login'] ?? '')), $row['label'],
                       $row['rows'], $row['works'], $row['review'], $row['unbound'],
                       (string) ($row['approval']['user'] ?? ''), $row['approval'] ? date('d.m.Y H:i', (int) $row['approval']['when']) : '',
                       !empty($row['onec']['ok']) ? date('d.m.Y H:i', (int) $row['onec']['at']) : '',
                       date('d.m.Y H:i', $row['received']), $row['versions'], $row['token'] !== '' ? 'rv_status.php?token=' . $row['token'] : ''], ';');
    }
    exit;
}

// ── Сводка ──
$counts = array_fill_keys(array_keys(RV_REGISTRY_STATES), 0);
$noResponsible = 0;
$byUser = [];
foreach ($all as $row) {
    $counts[$row['code']]++;
    $login = (string) ($row['responsible']['user'] ?? '');
    if ($login === '') {
        $noResponsible++;
    } else {
        $byUser[$login] = $byUser[$login] ?? array_fill_keys(array_keys(RV_REGISTRY_STATES), 0) + ['total' => 0];
        $byUser[$login][$row['code']]++;
        $byUser[$login]['total']++;
    }
}
ksort($byUser, SORT_NATURAL | SORT_FLAG_CASE);
$inWork = $counts['queued'] + $counts['running'] + $counts['awaiting'];
$errors = $counts['error'] + $counts['load_error'];
$mine = $me !== '' ? count(array_filter($all, static fn(array $r): bool => $r['code'] === 'ready' && (string) ($r['responsible']['user'] ?? '') === $me)) : 0;

// ── Дерево: объект справочника → корпус → сметы. Объекты без РВ — в конце, одной строкой. ──
$tree = [];
foreach ($tableObjects as $o) {
    $key = rv_table_key((string) $o['name']);
    $tree[$key] = ['folder' => (string) $o['name'], 'folder_key' => $key, 'buildings' => [], 'count' => 0, 'states' => [], 'known' => true];
}
$unmatched = ['folder' => '', 'folder_key' => '', 'buildings' => [], 'count' => 0, 'states' => [], 'known' => false];
foreach ($rows as $row) {
    $fk = $row['folder_key'];
    if ($fk === '' || !isset($tree[$fk])) {
        $node = &$unmatched;
    } else {
        $node = &$tree[$fk];
    }
    $bk = $row['building_label'];
    $node['buildings'][$bk] = $node['buildings'][$bk] ?? ['label' => $bk, 'rows' => [], 'states' => []];
    $node['buildings'][$bk]['rows'][] = $row;
    $node['buildings'][$bk]['states'][$row['label']] = ($node['buildings'][$bk]['states'][$row['label']] ?? 0) + 1;
    $node['states'][$row['label']] = ($node['states'][$row['label']] ?? 0) + 1;
    $node['count']++;
    unset($node);
}
$withRows = array_filter($tree, static fn(array $n): bool => $n['count'] > 0);
$withoutRows = array_filter($tree, static fn(array $n): bool => $n['count'] === 0);
$assign = rv_assignments();
$okNow = (string) ($_GET['ok'] ?? '');
$errNow = (string) ($_GET['err'] ?? '');
$levelText = ['folder' => 'за объект', 'object' => 'за НГ', 'system' => '', 'table' => 'по таблице', 'table-object' => 'по объекту в таблице', 'fallback' => 'запасной'];

/** Форма назначения: select для руководителя, «взять себе / снять с себя» для сметчика. */
function rv_assign_form(string $level, array $meta, ?array $current, bool $canAssign, bool $canTake, string $me,
                        array $estimators, string $csrf, string $back): string
{
    $login = (string) ($current['user'] ?? '');
    $hidden = '<input type="hidden" name="csrf" value="' . rv_h($csrf) . '"><input type="hidden" name="back" value="' . rv_h($back) . '">'
        . '<input type="hidden" name="level" value="' . $level . '">';
    foreach (['folder_key', 'obj_key', 'system_key', 'folder', 'obj', 'system'] as $field) {
        $hidden .= '<input type="hidden" name="' . $field . '" value="' . rv_h((string) ($meta[$field] ?? '')) . '">';
    }
    if ($canAssign) {
        $options = '<option value="">— не назначен —</option>';
        foreach ($estimators as $value => $label) {
            $options .= '<option value="' . rv_h($value) . '"' . ($value === $login ? ' selected' : '') . '>' . rv_h($label) . '</option>';
        }
        return '<form class="rv-assign" action="rv_assign.php" method="post">' . $hidden
            . '<select name="user" aria-label="Ответственный" onchange="this.form.submit()">' . $options . '</select></form>';
    }
    if ($canTake && $login === '') {
        return '<form class="rv-assign" action="rv_assign.php" method="post">' . $hidden
            . '<input type="hidden" name="user" value="' . rv_h($me) . '"><button type="submit" class="btn-small">Взять в работу</button></form>';
    }
    if ($canTake && $login === $me) {
        return '<form class="rv-assign" action="rv_assign.php" method="post">' . $hidden
            . '<input type="hidden" name="user" value=""><button type="submit" class="btn-small secondary">Снять с себя</button></form>';
    }
    return '';
}

/**
 * Ячейка «Ответственный» узла: своё назначение — форма с ним; унаследованное или по таблице — форма «не назначен»
 * (руководитель может назначить своего) и подпись «логин (по таблице)»; у сметчика без права назначать — подпись.
 */
function rv_assign_cell(string $level, array $meta, ?array $own, ?array $inherited, array $ctx): string
{
    [$canAssign, $canTake, $me, $estimators, $csrf, $back, $levelText] = $ctx;
    if ($own !== null && !empty($own['user'])) {
        $form = rv_assign_form($level, $meta, $own, $canAssign, $canTake, $me, $estimators, $csrf, $back);
        return $form . (!$canAssign ? rv_h((string) $own['user']) : '');
    }
    $mineAbove = !$canAssign && (string) ($inherited['user'] ?? '') === $me;
    $form = $mineAbove ? '' : rv_assign_form($level, $meta, null, $canAssign, $canTake, $me, $estimators, $csrf, $back);
    if ($inherited !== null && (!empty($inherited['user']) || !empty($inherited['login']))) {
        $who = (string) (($inherited['user'] ?? '') !== '' ? $inherited['user'] : $inherited['login']);
        $note = (string) ($levelText[$inherited['level']] ?? '');
        if (($inherited['user'] ?? '') === '' && !empty($inherited['login'])) {
            $note = trim($note . ', нет на сайте');
        }
        return $form . ' <span class="muted-dash">' . rv_h($who) . ($note !== '' ? ' (' . rv_h($note) . ')' : '') . '</span>';
    }
    return $form;
}

/** Сводка состояний узла: «Согласована: 2, Строится: 1». */
function rv_states_text(array $states): string
{
    $parts = [];
    foreach ($states as $label => $n) {
        $parts[] = $label . ': ' . $n;
    }
    return implode(', ', $parts);
}

/** Строка сметы в дереве. */
function rv_registry_row_html(array $row, array $assign, array $ctx, string $me): string
{
    $resp = $row['responsible'];
    $own = $resp && $resp['level'] === 'system' ? $resp : null;
    $zn = rv_zn_text(array_merge([$row['zn']], $row['zn_list']));
    $system = $row['table_system'] !== '' ? $row['table_system'] : $row['system'];
    $sub = [];
    if ($row['system'] !== '' && $row['system'] !== $system) {
        $sub[] = $row['system'];
    }
    $sub[] = $row['work_kind'] === 'НЗ' ? ('НЗ' . ($zn !== '' ? ' ' . $zn : '')) : 'основной договор';
    $h = '<tr class="rv-reg-row' . ((($resp['user'] ?? '') === $me && $me !== '') ? ' is-mine' : '') . '">';
    $h .= '<td data-label="Смета"><span class="rv-reg-indent2"><b>' . rv_h($system) . '</b> <span class="muted-dash">' . rv_h(implode(' · ', $sub)) . '</span></span>';
    if ($row['smeta'] !== '') {
        $h .= '<br><span class="rv-reg-indent2 muted-dash">' . rv_h($row['smeta']) . '</span>';
    }
    if ($row['obj'] !== '' && $row['folder'] === '') {
        $h .= '<br><span class="rv-reg-indent2 muted-dash">НГ: ' . rv_h($row['obj']) . '</span>';
    }
    if ($row['versions'] > 1) {
        $h .= '<br><span class="rv-reg-indent2 muted-dash">версий: ' . $row['versions'] . '</span>';
    }
    $h .= '</td>';
    $h .= '<td data-label="Ответственный">' . rv_assign_cell('system', $row, $own, $own ? null : $resp, $ctx) . '</td>';
    $h .= '<td data-label="Состояние"><span class="home-status is-' . $row['kind'] . '">' . rv_h($row['label']) . '</span>';
    if ($row['approval']) {
        $h .= '<br><span class="muted-dash">' . rv_h((string) $row['approval']['user']) . ', ' . rv_h(rv_when((int) $row['approval']['when'])) . '</span>';
    }
    if (!empty($row['onec']['ok'])) {
        $h .= '<br><span class="muted-dash">в 1С ' . rv_h(rv_when((int) $row['onec']['at'])) . (!empty($row['onec']['document']) ? ', ' . rv_h((string) $row['onec']['document']) : '') . '</span>';
    }
    if ($row['error'] !== '') {
        $h .= '<br><span class="rv-reg-error">' . rv_h(mb_substr($row['error'], 0, 300)) . '</span>';
    }
    $h .= '</td><td data-label="РВ">';
    if ($row['token'] !== '' && $row['rows']) {
        $h .= '<a href="rv_status.php?token=' . rv_h($row['token']) . '">строк ' . $row['rows'] . ', работ ' . $row['works'] . '</a>'
            . ($row['review'] + $row['unbound'] ? ', на проверку ' . ($row['review'] + $row['unbound']) : '');
    } elseif ($row['token'] !== '') {
        $h .= '<a href="rv_status.php?token=' . rv_h($row['token']) . '">ход построения</a>';
    }
    $h .= '</td><td data-label="Получена">' . rv_h(rv_when($row['received']))
        . ((($row['resent'] ?? '') !== '') ? '<br><span class="muted-dash">' . rv_h((string) $row['resent']) . '</span>' : '') . '</td>';
    $h .= '<td><a class="btn secondary btn-small" href="rv_smeta.php?id=' . rv_h(rawurlencode($row['id'])) . '">Карточка</a></td></tr>';
    return $h;
}

$ctx = [$canAssign, $canTake, $me, $estimators, $csrf, $back, $levelText];
$bindOptions = '';
foreach ($tableObjects as $o) {
    $bindOptions .= '<optgroup label="' . rv_h((string) $o['name']) . '">';
    foreach ((array) $o['buildings'] as $b) {
        $bindOptions .= '<option value="' . rv_h((string) $o['name'] . '|' . (string) $b['name']) . '">' . rv_h((string) $o['name'] . ' — ' . (string) $b['name']) . '</option>';
    }
    $bindOptions .= '</optgroup>';
}
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Объекты и ЛРВ из 1С — База знаний</title>
<link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
<script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
</head>
<body>
<div class="shell">
  <?php require __DIR__ . '/sidebar.php'; ?>

  <div class="dashboard-main">
  <div class="page-wide">

  <div class="card">
    <h1>Объекты и ЛРВ из 1С</h1>
    <p class="subtitle">Объект → корпус → смета из 1С (система, вид работ, номер ЗН) и состояние её РВ. Объекты и корпуса — из справочника <a href="rv_responsibles.php">«Объекты и ответственные»</a>; ЛРВ из 1С сама встаёт под свой объект и корпус, а сметчик берётся из его ячейки, если руководитель не назначил другого.<?php if ($canAssign): ?> Назначать может руководитель, сметчик может взять свободную ЛРВ себе.<?php elseif ($canTake): ?> Свободную ЛРВ можно взять себе кнопкой «Взять в работу».<?php endif; ?></p>
    <p class="rv-reg-summary">
      <a href="rv_registry.php">Смет из 1С: <b><?= count($all) ?></b></a>
      · <a href="rv_registry.php?state=running">строятся <b><?= $inWork ?></b></a>
      · <a href="rv_registry.php?state=ready">ждут согласования <b><?= $counts['ready'] ?></b></a>
      · <a href="rv_registry.php?state=approved">согласованы, ждут 1С <b><?= $counts['approved'] ?></b></a>
      · <a href="rv_registry.php?state=loaded">загружены в 1С <b><?= $counts['loaded'] ?></b></a>
      <?php if ($errors): ?> · <a href="rv_registry.php?state=error">с ошибкой <b><?= $errors ?></b></a><?php endif; ?>
      <?php if ($noResponsible): ?> · <a href="rv_registry.php?user=none">без ответственного <b><?= $noResponsible ?></b></a><?php endif; ?>
      <?php if ($mine): ?> · <a href="rv_registry.php?user=me&amp;state=ready">мои на проверку <b><?= $mine ?></b></a><?php endif; ?>
    </p>

    <?php if ($byUser): ?>
    <details class="rv-sample">
      <summary>По сметчикам (<?= count($byUser) ?>)</summary>
      <div class="table-wrap"><table class="data-table rv-reg-users"><thead><tr>
        <th>Сметчик</th><th>Всего</th><th>Строятся</th><th>Ждут согласования</th><th>Согласованы</th><th>Загружены в 1С</th><th>С ошибкой</th>
      </tr></thead><tbody>
      <?php foreach ($byUser as $login => $c): ?>
        <tr><td><a href="rv_registry.php?user=<?= rv_h(rawurlencode($login)) ?>"><?= rv_h($login) ?></a></td><td><?= $c['total'] ?></td>
          <td><?= $c['queued'] + $c['running'] + $c['awaiting'] ?></td><td><?= $c['ready'] ?></td><td><?= $c['approved'] ?></td><td><?= $c['loaded'] ?></td><td><?= $c['error'] + $c['load_error'] ?></td></tr>
      <?php endforeach; ?>
      </tbody></table></div>
    </details>
    <?php endif; ?>
  </div>

  <?php if ($okNow !== ''): ?><div class="alert success"><?= rv_h($okNow) ?></div><?php endif; ?>
  <?php if ($errNow !== ''): ?><div class="alert error"><?= rv_h($errNow) ?></div><?php endif; ?>

  <div class="card">
    <form class="rv-reg-filter" method="get" action="rv_registry.php">
      <input type="search" name="q" value="<?= rv_h($filter['q']) ?>" placeholder="объект, корпус, система, смета, № ЗН, сметчик" aria-label="Поиск">
      <select name="user" aria-label="Ответственный">
        <option value="">все ответственные</option>
        <option value="me"<?= $filter['user'] === 'me' ? ' selected' : '' ?>>мои</option>
        <option value="none"<?= $filter['user'] === 'none' ? ' selected' : '' ?>>не назначен</option>
        <?php foreach ($estimators as $value => $label): ?>
        <option value="<?= rv_h($value) ?>"<?= $filter['user'] === $value ? ' selected' : '' ?>><?= rv_h($label) ?></option>
        <?php endforeach; ?>
      </select>
      <select name="state" aria-label="Состояние">
        <option value="">все состояния</option>
        <?php foreach (RV_REGISTRY_STATES as $code => $label): ?>
        <option value="<?= $code ?>"<?= $filter['state'] === $code ? ' selected' : '' ?>><?= rv_h($label) ?> (<?= $counts[$code] ?>)</option>
        <?php endforeach; ?>
      </select>
      <button type="submit" class="btn-small">Показать</button>
      <?php if ($filterActive): ?><a class="btn-small secondary" href="rv_registry.php">Сбросить</a><?php endif; ?>
      <a class="btn-small secondary" href="<?= rv_h($back . ($filterActive ? '&' : '?') . 'csv=1') ?>">Скачать список (CSV)</a>
      <span class="muted-dash"><?= $filterActive ? 'показано ' . count($rows) . ' из ' . count($all) : 'всего ' . count($all) ?></span>
    </form>

    <?php if (!$all): ?>
    <p class="hint">1С ещё ничего не присылала. Как только придёт первая ЛРВ (кнопка «Отправить ЛРВ на сайт» в 1С или регламентное задание), она встанет под свой объект и корпус.</p>
    <?php elseif (!$rows): ?>
    <p class="hint">По этому отбору ничего нет.</p>
    <?php endif; ?>

    <?php if ($rows || !$filterActive): ?>
    <div class="table-wrap">
    <table class="data-table rv-registry">
      <thead><tr>
        <th>Объект / корпус / смета</th><th>Ответственный</th><th>Состояние</th><th>РВ</th><th>Получена</th><th></th>
      </tr></thead>
      <tbody>
      <?php if ($unmatched['count']): ?>
        <tr class="rv-reg-folder is-unmatched">
          <td><b>Не сопоставлено со справочником</b> <span class="muted-dash">смет: <?= $unmatched['count'] ?>. Номенклатурная группа 1С не нашла свой объект по названию — привяжите её к объекту и корпусу, и сметчик подставится из справочника.</span></td>
          <td></td><td colspan="3" class="muted-dash"><?= rv_h(rv_states_text($unmatched['states'])) ?></td><td></td>
        </tr>
        <?php foreach ($unmatched['buildings'] as $b): ?>
          <?php $first = $b['rows'][0]; ?>
          <tr class="rv-reg-obj">
            <td><span class="rv-reg-indent"><?= rv_h($first['obj'] !== '' ? $first['obj'] : 'Без номенклатурной группы') ?></span> <span class="muted-dash">НГ из 1С<?= $first['folder_1c'] !== '' ? ', папка «' . rv_h($first['folder_1c']) . '»' : '' ?></span></td>
            <td colspan="4">
              <?php if ($canAssign): ?>
              <form class="rv-assign" action="rv_responsibles.php" method="post">
                <input type="hidden" name="csrf" value="<?= rv_h($csrf) ?>"><input type="hidden" name="action" value="bind"><input type="hidden" name="back" value="<?= rv_h($back) ?>">
                <input type="hidden" name="obj_key" value="<?= rv_h($first['obj_key']) ?>"><input type="hidden" name="obj" value="<?= rv_h($first['obj']) ?>">
                <select name="target" aria-label="Объект и корпус справочника" onchange="this.form.submit()"><option value="">— привязать к объекту и корпусу —</option><?= $bindOptions ?></select>
              </form>
              <?php else: ?><span class="muted-dash">привязать может руководитель</span><?php endif; ?>
            </td>
            <td></td>
          </tr>
          <?php foreach ($b['rows'] as $row): ?><?= rv_registry_row_html($row, $assign, $ctx, $me) ?><?php endforeach; ?>
        <?php endforeach; ?>
      <?php endif; ?>

      <?php foreach ($withRows as $node): ?>
        <?php $folderMeta = ['folder' => $node['folder'], 'folder_key' => $node['folder_key']];
              $folderResp = $assign['folders'][$node['folder_key']] ?? null; ?>
        <tr class="rv-reg-folder">
          <td><b><?= rv_h($node['folder']) ?></b> <span class="muted-dash">смет: <?= $node['count'] ?><?= $filterActive ? ' (по отбору)' : '' ?></span></td>
          <td><?= rv_assign_cell('folder', $folderMeta, $folderResp, null, $ctx) ?> <span class="muted-dash">за объект</span></td>
          <td colspan="3" class="muted-dash"><?= rv_h(rv_states_text($node['states'])) ?></td>
          <td><a class="btn secondary btn-small" href="rv_responsibles.php?object=<?= rv_h(rawurlencode($node['folder'])) ?>">Сметчики</a></td>
        </tr>
        <?php foreach ($node['buildings'] as $b): ?>
        <tr class="rv-reg-obj">
          <td><span class="rv-reg-indent"><?= rv_h($b['label'] !== '' ? $b['label'] : 'корпус не указан') ?></span> <span class="muted-dash">смет: <?= count($b['rows']) ?></span></td>
          <td></td>
          <td colspan="3" class="muted-dash"><?= rv_h(rv_states_text($b['states'])) ?></td>
          <td></td>
        </tr>
        <?php foreach ($b['rows'] as $row): ?><?= rv_registry_row_html($row, $assign, $ctx, $me) ?><?php endforeach; ?>
        <?php endforeach; ?>
      <?php endforeach; ?>

      <?php if ($withoutRows && !$filterActive): ?>
        <tr class="rv-reg-folder is-empty"><td colspan="6"><span class="muted-dash">Объекты справочника, по которым 1С ещё ничего не присылала (<?= count($withoutRows) ?>):</span></td></tr>
        <?php foreach ($withoutRows as $node): ?>
        <tr class="rv-reg-obj is-empty">
          <td><?= rv_h($node['folder']) ?></td>
          <td><?= rv_assign_cell('folder', ['folder' => $node['folder'], 'folder_key' => $node['folder_key']], $assign['folders'][$node['folder_key']] ?? null, null, $ctx) ?></td>
          <td colspan="3" class="muted-dash">РВ из 1С пока нет</td>
          <td><a class="btn secondary btn-small" href="rv_responsibles.php?object=<?= rv_h(rawurlencode($node['folder'])) ?>">Сметчики</a></td>
        </tr>
        <?php endforeach; ?>
      <?php endif; ?>
      </tbody>
    </table>
    </div>
    <?php endif; ?>
  </div>

  <p><a href="rv.php">← РВ по ЛРВ</a> · <a href="rv_responsibles.php">Объекты и ответственные</a></p>
  </div>
  </div>
</div>
</body>
</html>
