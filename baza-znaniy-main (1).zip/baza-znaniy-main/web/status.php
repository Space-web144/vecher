<?php
declare(strict_types=1);

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require_once __DIR__ . '/users.php';

// Каким блоком сайта запущена обработка ("mode" в статус-файле, см.
// web_run.py/web_pdf_run.py) — от этого зависят заголовок страницы и
// куда ведёт ссылка "Назад"/"Обработать ещё один файл".
function mode_page(string $mode, string $suffix): array {
    $pages = [
        'area' => ['area.php', 'Area'],
        'equipment' => ['equipment.php', 'Оборудование'],
    ];
    [$page, $name] = $pages[$mode] ?? ['ventspec.php', 'VentSpec'];
    return [$page, $name . ' — ' . $suffix];
}

$token = $_GET['token'] ?? '';
if (!is_string($token) || !preg_match('/^[a-f0-9]{16}$/', $token)) {
    http_response_code(400);
    exit('Некорректный идентификатор задачи.');
}

$statusPath = OUTPUT_DIR . "/{$token}_status.json";

header('Content-Type: text/html; charset=utf-8');

$progressState = is_file($statusPath) ? json_decode((string) file_get_contents($statusPath), true) : null;
if (!is_file($statusPath) || (is_array($progressState) && ($progressState['state'] ?? '') === 'running')) {
    // Ещё обрабатывается (или упало настолько рано, что даже статус-файл
    // не успел записаться) — покажем страницу ожидания с автообновлением
    // и крутящимся индикатором, чтобы было видно, что процесс жив, а не завис.
    //
    // Секунды считаем от времени создания загруженного файла (он
    // появляется на диске ровно в момент старта обработки), а не JS-
    // счётчиком с нуля — иначе он обнулялся бы при каждом автообновлении
    // страницы (каждые 10 сек), создавая впечатление, что всё началось
    // заново. Два возможных имени — обычная спецификация (.xlsx) или PDF
    // на конвертацию (.pdf), в зависимости от того, какой из двух форм
    // на сайте пользователь воспользовался.
    $elapsed = 0;
    foreach (["xlsx", "pdf"] as $ext) {
        $specPath = UPLOAD_DIR . "/{$token}_spec.{$ext}";
        if (is_file($specPath)) {
            $elapsed = max(0, time() - filemtime($specPath));
            break;
        }
    }
    ?>
    <!doctype html>
    <html lang="ru">
    <head>
      <meta charset="utf-8">
      <link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <meta http-equiv="refresh" content="3">
      <title>VentSpec — обработка...</title>
      <link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
      <script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
    </head>
    <body>
    <div class="shell">
      <?php require __DIR__ . '/sidebar.php'; ?>

      <div class="dashboard-main">
      <div class="page">

      <div class="card center">
        <div class="spinner"></div>
        <h1>Обработка идёт...</h1>
        <p class="subtitle"><?= htmlspecialchars((string) ($progressState['stage'] ?? 'Файл обрабатывается. Страница обновится автоматически.'), ENT_QUOTES, 'UTF-8') ?></p>
        <p class="elapsed">Прошло времени: <span id="seconds"><?= (int) $elapsed ?></span> сек</p>
      </div>

      </div>
      </div>
    </div>
    <script>
      var s = <?= (int) $elapsed ?>;
      setInterval(function () {
        s += 1;
        document.getElementById('seconds').textContent = s;
      }, 1000);
    </script>
    </body>
    </html>
    <?php
    exit;
}

$raw = file_get_contents($statusPath);
$result = $raw !== false ? json_decode($raw, true) : null;

if (!is_array($result) || empty($result['ok'])) {
    $msg = is_array($result) ? ($result['error'] ?? 'неизвестная ошибка') : 'не удалось прочитать статус';
    [$backLink, $pageTitle] = mode_page(is_array($result) ? ($result['mode'] ?? '') : '', 'ошибка');
    http_response_code(500);
    ?>
    <!doctype html>
    <html lang="ru">
    <head>
      <meta charset="utf-8">
      <link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title><?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') ?></title>
      <link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
      <script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
    </head>
    <body>
    <div class="shell">
      <?php require __DIR__ . '/sidebar.php'; ?>

      <div class="dashboard-main">
      <div class="page">

      <div class="card">
        <h1>Обработка не удалась</h1>
        <div class="alert error"><?= htmlspecialchars($msg, ENT_QUOTES, 'UTF-8') ?></div>
        <a class="back-link" href="<?= htmlspecialchars($backLink, ENT_QUOTES, 'UTF-8') ?>">← Назад</a>
      </div>

      </div>
      </div>
    </div>
    </body>
    </html>
    <?php
    exit;
}

$resultName = basename((string) $result['output_file']);
$reportName = !empty($result['report_file']) ? basename((string) $result['report_file']) : null;
// Файл на диске хранится под токеном (см. process.php/process_pdf.php), но
// пользователю показываем имя, привязанное к исходному загруженному файлу
// (см. lib.php::sanitize_display_base и web_run.py/web_pdf_run.py) — если
// оно не пришло (старый статус-файл от job, запущенного до этой правки),
// откатываемся на серверное имя.
$resultDisplay = !empty($result['output_display_name']) ? (string) $result['output_display_name'] : $resultName;
$reportDisplay = !empty($result['report_display_name']) ? (string) $result['report_display_name'] : $reportName;
[$backLink, $pageTitle] = mode_page($result['mode'] ?? '', 'готово');
?>
<!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') ?></title>
  <link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
  <script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
</head>
<body>
<div class="shell">
  <?php require __DIR__ . '/sidebar.php'; ?>

  <div class="dashboard-main">
  <div class="page">

  <div class="card">
    <h1>Обработка завершена</h1>
    <?php if (!empty($result['needs_review']) && in_array($result['mode'] ?? '', ['area', 'equipment'], true)): ?>
    <div class="alert warn">Файл сформирован. Сверьте распознанные страницы с PDF: замечания и номера страниц указаны на листе «Проверка» в Excel.</div>
    <?php else: ?>
    <div class="alert success">Готово — файлы можно скачать ниже.</div>
    <?php endif; ?>
    <div class="links">
      <a class="btn" href="download.php?file=<?= urlencode($resultName) ?>&dl=<?= urlencode($resultDisplay) ?>"><?= ($result['mode'] ?? '') === 'equipment' ? 'Скачать таблицу сверки' : 'Скачать обработанную спецификацию' ?></a>
      <?php if ($reportName): ?>
      <a class="btn secondary" href="download.php?file=<?= urlencode($reportName) ?>&dl=<?= urlencode($reportDisplay) ?>">Скачать отчёт сравнения с 1С</a>
      <?php endif; ?>
    </div>
    <a class="back-link" href="<?= htmlspecialchars($backLink, ENT_QUOTES, 'UTF-8') ?>">← Обработать ещё один файл</a>
  </div>

  </div>
  </div>
</div>
</body>
</html>
