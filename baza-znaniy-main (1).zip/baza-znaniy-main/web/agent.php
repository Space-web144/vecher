<?php
declare(strict_types=1);

// Чат «Ассистент»: вопрос с сайта уходит в Claude (Anthropic), ответ
// возвращается в этот же чат. Отправка и опрос — assets/agent.js через
// agent_api.php, ответ готовит фоновый процесс common/web_agent_chat.py.
// Здесь — только страница, список чатов и их удаление.

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require_once __DIR__ . '/users.php';
require __DIR__ . '/agent_lib.php';
require_once __DIR__ . '/lib.php';
require_once __DIR__ . '/design.php';

function h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

$user = (string) ($_SESSION['kb_user'] ?? '');
$csrf = agent_csrf();
$dir = agent_user_dir($user);

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete') {
    $id = (string) ($_POST['chat'] ?? '');
    $back = (string) ($_POST['current'] ?? '');
    if (hash_equals($csrf, (string) ($_POST['csrf'] ?? '')) && agent_valid_id($id)) {
        agent_delete_chat($dir, $id);
    }
    $target = 'agent.php';
    if ($back !== $id && agent_valid_id($back)) {
        $target .= '?chat=' . urlencode($back);
    }
    header('Location: ' . $target);
    exit;
}

// Вопрос с главной (поле «Спросите ассистента»): текст ждёт в сессии,
// страница открывается без него в адресе и отправляет его сама, один раз —
// обновление страницы вопрос не повторит.
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'ask') {
    $text = trim((string) ($_POST['text'] ?? ''));
    if (hash_equals($csrf, (string) ($_POST['csrf'] ?? '')) && $text !== '') {
        $_SESSION['agent_ask'] = mb_substr($text, 0, AGENT_MAX_MESSAGE_CHARS);
    }
    header('Location: agent.php');
    exit;
}

$chats = agent_locked($dir, function () use ($dir, $user) {
    agent_cleanup_uploads(agent_upload_dir($user));
    return agent_load_chats($dir);
});
$chatId = (string) ($_GET['chat'] ?? '');
$current = agent_valid_id($chatId) ? ($chats[$chatId] ?? null) : null;
$notFound = $chatId !== '' && $current === null;
$configured = agent_configured();
$ask = '';
if ($current === null && isset($_SESSION['agent_ask'])) {
    $ask = (string) $_SESSION['agent_ask'];
    unset($_SESSION['agent_ask']);
}

$state = [
    'chat' => $current !== null ? agent_public_chat($current) : null,
    'csrf' => $csrf,
    'maxChars' => AGENT_MAX_MESSAGE_CHARS,
    'maxFileBytes' => agent_file_limit(),
    'maxFiles' => AGENT_MAX_FILES,
    'chunkBytes' => agent_upload_chunk_limit(),
    'fileTypes' => AGENT_FILE_TYPES,
    // Вопрос с главной — отправляется сразу после открытия страницы.
    'ask' => $ask,
];
$fileMb = megabytes(agent_file_limit());
// В обновлённом оформлении (design.php) чат называется «Альфик».
$agentName = design_refresh() ? 'Альфик' : 'Ассистент';
if (design_refresh()) {
    $state['name'] = $agentName;
}

function agent_date(int $time): string
{
    if ($time <= 0) {
        return '';
    }
    return date('d.m.Y', $time) === date('d.m.Y') ? 'сегодня, ' . date('H:i', $time) : date('d.m.Y H:i', $time);
}
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= h($agentName) ?> — База знаний</title>
<link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
<script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
</head>
<body>
<div class="shell">
  <?php require __DIR__ . '/sidebar.php'; ?>

  <div class="dashboard-main">
  <div class="agent-page">

    <aside class="agent-side" aria-label="Чаты">
      <h1 class="agent-h1"><?= h($agentName) ?></h1>

      <div class="agent-side-bar">
        <button type="button" class="agent-side-toggle" id="agent-side-toggle" aria-expanded="false" aria-controls="agent-side-list"<?= $chats ? '' : ' hidden' ?>>
          Мои чаты <span class="agent-side-count" id="agent-side-count"><?= count($chats) ?></span>
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m6 9 6 6 6-6"/></svg>
        </button>
        <a class="btn secondary btn-small agent-new" id="agent-new" href="agent.php">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>
          Новый чат
        </a>
      </div>

      <div class="agent-side-list" id="agent-side-list">
        <ul class="agent-chats" id="agent-chats">
          <?php foreach ($chats as $id => $chat): ?>
            <?php
            // Ключ массива из одних цифр PHP превращает в число — а дальше
            // нужна строка (h(), сравнение с id из адреса).
            $id = (string) $id;
            $isCurrent = $id === $chatId;
            $chatTitle = (string) ($chat['title'] ?? '');
            ?>
            <li class="agent-chat<?= $isCurrent ? ' current' : '' ?>" data-chat="<?= h($id) ?>">
              <a class="agent-chat-link" href="agent.php?chat=<?= urlencode($id) ?>"<?= $isCurrent ? ' aria-current="page"' : '' ?>>
                <span class="agent-chat-title"><?= h($chatTitle) ?></span>
                <span class="agent-chat-meta"><?= h(agent_date((int) ($chat['updated'] ?? 0))) ?></span>
              </a>
              <form method="post" action="agent.php" onsubmit="return confirm('Удалить чат «<?= h(addslashes($chatTitle)) ?>» вместе с его файлами?');">
                <input type="hidden" name="csrf" value="<?= h($csrf) ?>">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="chat" value="<?= h($id) ?>">
                <input type="hidden" name="current" value="<?= h($chatId) ?>">
                <button type="submit" class="agent-chat-delete" title="Удалить чат" aria-label="Удалить чат «<?= h($chatTitle) ?>»">
                  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 7h16M10 11v6M14 11v6M6 7l1 12a2 2 0 0 0 2 2h6a2 2 0 0 0 2-2l1-12M9 7V4h6v3"/></svg>
                </button>
              </form>
            </li>
          <?php endforeach; ?>
        </ul>
        <p class="agent-side-note">Чаты и файлы <?= design_refresh() ? 'Альфика' : 'ассистента' ?> видны только вам и хранятся <?= AGENT_KEEP_DAYS ?> дней после последнего сообщения.<?php if (defined('AGENT_LOG_DIR')): ?> Текст вопросов, имена файлов и итог ответа сохраняются в журнале для анализа работы <?= design_refresh() ? 'Альфика' : 'ассистента' ?>; журнал видят администраторы сайта.<?php endif; ?></p>
      </div>
    </aside>

    <section class="agent-conv" aria-labelledby="agent-title">
      <?php if (!$configured): ?>
        <div class="alert warn">Ассистент не настроен на этом сервере: нет файла с ключом Anthropic (ANTHROPIC_CREDENTIALS_FILE в config.php). Обратитесь к администратору.</div>
      <?php endif; ?>
      <?php if ($notFound): ?>
        <div class="alert warn">Чат не найден — возможно, его удалили или истёк срок хранения. Начат новый чат.</div>
      <?php endif; ?>
      <noscript><div class="alert warn">Для чата нужен включённый JavaScript.</div></noscript>

      <h2 class="agent-title" id="agent-title"><?= h($current !== null ? (string) ($current['title'] ?? '') : 'Новый чат') ?></h2>

      <div class="agent-log" id="agent-log" aria-live="polite"></div>

      <form class="agent-composer" id="agent-form" action="agent_api.php" method="post">
        <div class="alert is-running" id="agent-upload" hidden></div>
        <div class="alert error" id="agent-form-error" role="alert" hidden></div>
        <div class="agent-box">
          <label class="agent-sr" for="agent-text">Задача для <?= design_refresh() ? 'Альфика' : 'ассистента' ?></label>
          <textarea id="agent-text" name="text" rows="2" maxlength="<?= AGENT_MAX_MESSAGE_CHARS ?>"
                    placeholder="Опишите задачу или задайте вопрос"
                    <?= $configured ? '' : 'disabled' ?>></textarea>
          <ul class="agent-picked" id="agent-picked" aria-label="Файлы к отправке" hidden></ul>
          <?php if ($configured && agent_vps_available()): ?>
            <label class="hint">
              <input type="checkbox" id="agent-heavy" name="processing" value="vps">
              Обработать файлы на VPS
            </label>
          <?php endif; ?>
          <div class="agent-box-bar">
            <button type="button" class="agent-attach" id="agent-attach" aria-describedby="agent-attach-note" <?= $configured ? '' : 'disabled' ?>>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m20 11.5-8.1 8.1a5 5 0 0 1-7.1-7.1l8.5-8.5a3.3 3.3 0 0 1 4.7 4.7l-8.5 8.5a1.7 1.7 0 0 1-2.4-2.4l7.8-7.8"/></svg>
              <span>Файлы</span>
            </button>
            <input type="file" class="agent-sr" id="agent-files" name="files[]" multiple tabindex="-1"
                   accept="<?= h(implode(',', array_map(fn($ext) => '.' . $ext, AGENT_FILE_TYPES))) ?>"
                   <?= $configured ? '' : 'disabled' ?>>
            <span class="agent-box-hint" id="agent-attach-note">До <?= AGENT_MAX_FILES ?> файлов по <?= $fileMb ?> МБ · перетащите сюда или вставьте снимок (Ctrl+V)</span>
            <span class="agent-box-hint agent-keys">Shift+Enter — новая строка</span>
            <button type="submit" class="agent-send" id="agent-send" <?= $configured ? '' : 'disabled' ?>>Отправить</button>
          </div>
        </div>
      </form>
    </section>

  </div>
  </div>
</div>
<script type="application/json" id="agent-state"><?= json_encode($state, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE | JSON_HEX_TAG | JSON_HEX_AMP) ?></script>
<script src="assets/agent.js?v=<?= filemtime(__DIR__ . '/assets/agent.js') ?>"></script>
</body>
</html>
