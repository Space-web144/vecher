<?php
declare(strict_types=1);

require __DIR__ . '/admin_guard.php';
require __DIR__ . '/config.php';
require_once __DIR__ . '/users.php';

if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(16));
}
$csrf = $_SESSION['csrf'];

function check_csrf(): bool
{
    global $csrf;
    return hash_equals($csrf, (string) ($_POST['csrf'] ?? ''));
}

$myLogin = (string) ($_SESSION['kb_user'] ?? '');
$isMainAdmin = ($_SESSION['kb_role'] ?? '') === ROLE_MAINADMIN;
$myDepartment = current_department();

// Только MainAdmin управляет учётками admin/mainadmin (создаёт, меняет им
// роль/пароль, удаляет). Обычный admin работает только с учётками уровня
// user — кроме сброса СВОЕГО СОБСТВЕННОГО пароля, иначе ему было бы негде
// его сменить (отдельной страницы «мой профиль» нет).
function admin_tier_locked_for_target(array $target, bool $isMainAdmin, string $myLogin): bool
{
    return !$isMainAdmin && is_admin_tier_role($target['role']) && !hash_equals($target['login'], $myLogin);
}

// Обычный admin управляет только учётками СВОЕГО отдела (отдел учётки,
// см. user_department() в users.php) — учётки другого отдела для него как
// будто не существует, независимо от роли. Проверяем это отдельно от
// admin_tier_locked_for_target (та про уровень роли, эта — про отдел), но
// обе относятся только к обычному admin: MainAdmin видит и меняет всех.
function department_locked_for_target(array $target, bool $isMainAdmin, ?string $myDepartment): bool
{
    return !$isMainAdmin && user_department($target) !== $myDepartment;
}

$error = null;
$success = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!check_csrf()) {
        $error = 'Форма устарела, попробуйте ещё раз.';
    } else {
        $users = load_users();
        $action = (string) ($_POST['action'] ?? '');
        $adminTier = array_filter($users, fn($u) => is_admin_tier_role($u['role']));
        $mainAdmins = array_filter($users, fn($u) => $u['role'] === ROLE_MAINADMIN);

        if ($action === 'add_user') {
            $login = trim((string) ($_POST['login'] ?? ''));
            $password = (string) ($_POST['password'] ?? '');
            $role = (string) ($_POST['role'] ?? ROLE_USER);
            // Отдел — обязательная характеристика учётки: по нему открываются модули сайта.
            // Обычный admin заводит сотрудников только своего отдела.
            $department = $isMainAdmin ? department_code((string) ($_POST['department'] ?? '')) : $myDepartment;

            if (!user_login_valid($login)) {
                $error = 'Логин может содержать только буквы, цифры, "_", "." и "-" (2–40 символов).';
            } elseif (find_user($users, $login) !== null) {
                $error = 'Такой логин уже есть.';
            } elseif (mb_strlen($password) < 6) {
                $error = 'Пароль должен быть не короче 6 символов.';
            } elseif (!in_array($role, VALID_ROLES, true)) {
                $error = 'Некорректная роль.';
            } elseif (!$isMainAdmin && $role !== ROLE_USER) {
                $error = 'Только MainAdmin может создавать пользователей с ролью admin/mainadmin.';
            } elseif ($department === null) {
                $error = 'Выберите отдел сотрудника — по нему открываются модули сайта.';
            } elseif (($departmentError = department_assignment_error($login, $department)) !== null) {
                $error = $departmentError;
            } else {
                $users[] = [
                    'login' => $login,
                    'password_hash' => password_hash($password, PASSWORD_DEFAULT),
                    'role' => $role,
                    'department' => $department,
                ];
                save_users($users);
                $success = "Пользователь «{$login}» добавлен (отдел: " . department_label($department) . ").";
            }
        } elseif ($action === 'delete_user') {
            $login = trim((string) ($_POST['login'] ?? ''));
            $target = find_user($users, $login);

            if ($target === null) {
                $error = 'Пользователь не найден.';
            } elseif (hash_equals($login, (string) ($_SESSION['kb_user'] ?? "\0"))) {
                $error = 'Нельзя удалить самого себя, пока вы вошли под этим пользователем.';
            } elseif (admin_tier_locked_for_target($target, $isMainAdmin, $myLogin)) {
                $error = 'Удалять администраторов может только MainAdmin.';
            } elseif (department_locked_for_target($target, $isMainAdmin, $myDepartment)) {
                $error = 'Удалять пользователей другого отдела может только MainAdmin.';
            } elseif (is_admin_tier_role($target['role']) && count($adminTier) <= 1) {
                $error = 'Нельзя удалить последнего администратора.';
            } elseif ($target['role'] === ROLE_MAINADMIN && count($mainAdmins) <= 1) {
                $error = 'Нельзя удалить последнего MainAdmin.';
            } else {
                $users = array_values(array_filter($users, fn($u) => !hash_equals($u['login'], $login)));
                save_users($users);
                $success = "Пользователь «{$login}» удалён.";
            }
        } elseif ($action === 'reset_password') {
            $login = trim((string) ($_POST['login'] ?? ''));
            $password = (string) ($_POST['password'] ?? '');
            $idx = null;
            foreach ($users as $i => $u) {
                if (hash_equals($u['login'], $login)) {
                    $idx = $i;
                    break;
                }
            }
            if ($idx === null) {
                $error = 'Пользователь не найден.';
            } elseif (admin_tier_locked_for_target($users[$idx], $isMainAdmin, $myLogin)) {
                $error = 'Сбрасывать пароль администраторам может только MainAdmin.';
            } elseif (department_locked_for_target($users[$idx], $isMainAdmin, $myDepartment)) {
                $error = 'Сбрасывать пароль пользователям другого отдела может только MainAdmin.';
            } elseif (mb_strlen($password) < 6) {
                $error = 'Пароль должен быть не короче 6 символов.';
            } else {
                $users[$idx]['password_hash'] = password_hash($password, PASSWORD_DEFAULT);
                save_users($users);
                $success = "Пароль пользователя «{$login}» обновлён.";
            }
        } elseif ($action === 'change_role') {
            $login = trim((string) ($_POST['login'] ?? ''));
            $role = (string) ($_POST['role'] ?? '');
            $idx = null;
            foreach ($users as $i => $u) {
                if (hash_equals($u['login'], $login)) {
                    $idx = $i;
                    break;
                }
            }
            if ($idx === null || !in_array($role, VALID_ROLES, true)) {
                $error = 'Некорректный запрос.';
            } elseif (!$isMainAdmin && (is_admin_tier_role($users[$idx]['role']) || is_admin_tier_role($role))) {
                $error = 'Изменять роль администраторов может только MainAdmin.';
            } elseif (is_admin_tier_role($users[$idx]['role']) && !is_admin_tier_role($role) && count($adminTier) <= 1) {
                $error = 'Нельзя снять права с последнего администратора.';
            } elseif ($users[$idx]['role'] === ROLE_MAINADMIN && $role !== ROLE_MAINADMIN && count($mainAdmins) <= 1) {
                $error = 'Нельзя снять права с последнего MainAdmin.';
            } else {
                $users[$idx]['role'] = $role;
                save_users($users);
                $success = "Роль пользователя «{$login}» изменена.";
            }
        } elseif ($action === 'change_department') {
            $login = trim((string) ($_POST['login'] ?? ''));
            $department = department_code((string) ($_POST['department'] ?? ''));
            $idx = null;
            foreach ($users as $i => $u) {
                if (hash_equals($u['login'], $login)) {
                    $idx = $i;
                    break;
                }
            }
            if ($idx === null || $department === null) {
                $error = 'Некорректный запрос.';
            } elseif (!$isMainAdmin) {
                $error = 'Менять отдел может только MainAdmin.';
            } elseif (($departmentError = department_assignment_error($login, $department)) !== null) {
                $error = $departmentError;
            } else {
                $users[$idx]['department'] = $department;
                save_users($users);
                if (hash_equals($login, $myLogin)) {
                    $_SESSION['kb_dept'] = $department;
                    $_SESSION['kb_dept_for'] = $login;
                }
                $success = "Отдел пользователя «{$login}» — " . department_label($department) . ".";
            }
        }
    }
}

$users = load_users();
$myLogin = (string) ($_SESSION['kb_user'] ?? '');
$isMainAdmin = ($_SESSION['kb_role'] ?? '') === ROLE_MAINADMIN;
$myDepartment = current_department();

// Группируем таблицу по отделу (без отдела — в конец), внутри отдела —
// по логину, как и раньше.
usort($users, function ($a, $b) {
    $da = user_department_profile($a) ?? "\xFF";
    $db = user_department_profile($b) ?? "\xFF";
    return $da === $db ? strcasecmp($a['login'], $b['login']) : strcmp($da, $db);
});

?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Пользователи — База знаний</title>
<link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
<script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
</head>
<body>
<div class="shell">
  <?php require __DIR__ . '/sidebar.php'; ?>

  <div class="dashboard-main">
  <div class="page-wide">

  <div class="card">
    <h1>Пользователи</h1>
    <p class="subtitle">Учётные записи для входа на сайт. У каждой — отдел: по нему сотруднику открываются модули его отдела (Альфик открыт всем). Admin управляет обычными пользователями своего отдела; учётки уровня admin/mainadmin и отдел любой учётки меняет только MainAdmin.</p>

    <?php if ($error): ?>
    <div class="alert error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
    <?php endif; ?>
    <?php if ($success): ?>
    <div class="alert success"><?= htmlspecialchars($success, ENT_QUOTES, 'UTF-8') ?></div>
    <?php endif; ?>

    <?php
      $departments = [];
      foreach ($users as $u) {
          $d = user_department_profile($u);
          if ($d !== null) {
              $departments[$d] = true;
          }
      }
      $departments = array_keys($departments);
      sort($departments);
      $legacy = count(array_filter($users, fn($u) => empty($u['department']) && login_department($u['login']) !== null));
    ?>
    <div class="table-filters">
      <input type="search" id="user-search" placeholder="Поиск по логину…">
      <?php if ($departments): ?>
      <select id="dept-filter">
        <option value="">Все отделы</option>
        <?php foreach ($departments as $d): ?>
        <option value="<?= htmlspecialchars(mb_strtolower($d), ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars(department_label($d), ENT_QUOTES, 'UTF-8') ?></option>
        <?php endforeach; ?>
      </select>
      <?php endif; ?>
    </div>
    <?php if ($legacy && $isMainAdmin): ?>
    <p class="hint">У <?= $legacy ?> учёток отдел пока не задан и берётся из логина (часть после «_») — задайте его в колонке «Отдел», и правило логина для них перестанет действовать.</p>
    <?php endif; ?>

    <div class="table-wrap">
      <table class="data-table">
        <thead>
          <tr>
            <th>Логин</th>
            <th>Отдел</th>
            <th>Роль</th>
            <th>Сменить роль</th>
            <th>Новый пароль</th>
            <th></th>
          </tr>
        </thead>
        <tbody id="users-tbody">
          <?php foreach ($users as $u):
            $isSelf = hash_equals($u['login'], $myLogin);
            $targetIsAdminTier = is_admin_tier_role($u['role']);
            $targetDepartment = user_department_profile($u);
            $effectiveDepartment = user_department($u);
            $departmentStored = !empty($u['department']);
            $sameDepartment = $effectiveDepartment === $myDepartment;
            $canChangeRole = $isMainAdmin;
            $canResetPassword = $isMainAdmin || $isSelf || (!$targetIsAdminTier && $sameDepartment);
            $canDelete = $isMainAdmin || (!$targetIsAdminTier && $sameDepartment);
          ?>
          <tr data-login="<?= htmlspecialchars(mb_strtolower($u['login']), ENT_QUOTES, 'UTF-8') ?>" data-dept="<?= htmlspecialchars(mb_strtolower((string) $targetDepartment), ENT_QUOTES, 'UTF-8') ?>">
            <td data-label="Логин"><?= htmlspecialchars($u['login'], ENT_QUOTES, 'UTF-8') ?></td>
            <td data-label="Отдел">
              <?php if ($isMainAdmin): ?>
              <form class="inline-form" method="post" action="admin_users.php">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
                <input type="hidden" name="action" value="change_department">
                <input type="hidden" name="login" value="<?= htmlspecialchars($u['login'], ENT_QUOTES, 'UTF-8') ?>">
                <select name="department" onchange="this.form.submit()" aria-label="Отдел" title="<?= $departmentStored ? 'Отдел учётки' : 'Отдел пока не задан — показан по логину' ?>"<?= $departmentStored ? '' : ' class="is-legacy"' ?>>
                  <option value=""<?= $targetDepartment === null ? ' selected' : '' ?>>— не задан —</option>
                  <?php foreach (KB_DEPARTMENT_NAMES as $code => $name): ?>
                  <option value="<?= $code ?>"<?= $targetDepartment === $code ? ' selected' : '' ?>><?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?></option>
                  <?php endforeach; ?>
                  <?php if ($targetDepartment !== null && !isset(KB_DEPARTMENT_NAMES[$targetDepartment])): ?>
                  <option value="<?= htmlspecialchars($targetDepartment, ENT_QUOTES, 'UTF-8') ?>" selected><?= htmlspecialchars($targetDepartment, ENT_QUOTES, 'UTF-8') ?></option>
                  <?php endif; ?>
                </select>
              </form>
              <?php else: ?>
              <?= $targetDepartment !== null ? htmlspecialchars(department_label($targetDepartment), ENT_QUOTES, 'UTF-8') : '<span class="muted-dash">—</span>' ?>
              <?php endif; ?>
              <?php if ($targetDepartment === 'NO'): ?>
              <span class="hint"><?= htmlspecialchars($effectiveDepartment !== null ? 'Рабочий отдел: ' . department_label($effectiveDepartment) . ' (по логину)' : 'Отдел в логине не распознан', ENT_QUOTES, 'UTF-8') ?></span>
              <?php endif; ?>
            </td>
            <td data-label="Роль"><span class="role-badge <?= role_badge_class($u['role']) ?>"><?= role_label($u['role']) ?></span></td>
            <td data-label="Сменить роль">
              <?php if ($canChangeRole): ?>
              <form class="inline-form" method="post" action="admin_users.php">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
                <input type="hidden" name="action" value="change_role">
                <input type="hidden" name="login" value="<?= htmlspecialchars($u['login'], ENT_QUOTES, 'UTF-8') ?>">
                <select name="role" onchange="this.form.submit()">
                  <option value="user" <?= $u['role'] === ROLE_USER ? 'selected' : '' ?>>user</option>
                  <option value="admin" <?= $u['role'] === ROLE_ADMIN ? 'selected' : '' ?>>admin</option>
                  <option value="mainadmin" <?= $u['role'] === ROLE_MAINADMIN ? 'selected' : '' ?>>MainAdmin</option>
                </select>
              </form>
              <?php else: ?>
              <span class="muted-dash" title="Только MainAdmin может менять роль администраторов">—</span>
              <?php endif; ?>
            </td>
            <td data-label="Новый пароль">
              <?php if ($canResetPassword): ?>
              <form class="inline-form" method="post" action="admin_users.php" onsubmit="return confirmResetPw(this);">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
                <input type="hidden" name="action" value="reset_password">
                <input type="hidden" name="login" value="<?= htmlspecialchars($u['login'], ENT_QUOTES, 'UTF-8') ?>">
                <span class="pw-field-wrap">
                  <input type="password" name="password" placeholder="новый пароль" autocomplete="new-password">
                  <button type="button" class="pw-toggle-btn" data-toggle-pw title="Показать/скрыть пароль" aria-label="Показать/скрыть пароль">
                    <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
                      <path d="M1 10S4.5 4 10 4s9 6 9 6-3.5 6-9 6-9-6-9-6z"/>
                      <circle cx="10" cy="10" r="2.4"/>
                      <line class="pw-toggle-slash" x1="2.5" y1="2.5" x2="17.5" y2="17.5" style="display:none"/>
                    </svg>
                  </button>
                </span>
                <button type="submit" class="btn-small">Сменить</button>
              </form>
              <?php else: ?>
              <span class="muted-dash" title="<?= $targetIsAdminTier ? 'Только MainAdmin может сбросить пароль другому администратору' : 'Только MainAdmin может сбросить пароль пользователю другого отдела' ?>">—</span>
              <?php endif; ?>
            </td>
            <td data-label="Действия">
              <?php if ($canDelete): ?>
              <form class="inline-form" method="post" action="admin_users.php" onsubmit="return confirm('Удалить пользователя «<?= htmlspecialchars($u['login'], ENT_QUOTES, 'UTF-8') ?>»?');">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
                <input type="hidden" name="action" value="delete_user">
                <input type="hidden" name="login" value="<?= htmlspecialchars($u['login'], ENT_QUOTES, 'UTF-8') ?>">
                <button type="submit" class="btn-small btn-danger">Удалить</button>
              </form>
              <?php else: ?>
              <span class="muted-dash" title="<?= $targetIsAdminTier ? 'Только MainAdmin может удалить администратора' : 'Только MainAdmin может удалить пользователя другого отдела' ?>">—</span>
              <?php endif; ?>
            </td>
          </tr>
          <?php endforeach; ?>
          <?php if (!$users): ?>
          <tr><td colspan="6">Пользователей пока нет.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
      <p id="users-empty-filtered" class="empty-state" style="display:none">Ничего не найдено.</p>
    </div>

    <h2>Добавить пользователя</h2>
    <form method="post" action="admin_users.php" autocomplete="off">
      <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
      <input type="hidden" name="action" value="add_user">
      <div class="field">
        <label class="field-label" for="new_login">Логин</label>
        <input type="text" id="new_login" name="login" required autocomplete="off">
      </div>
      <div class="field">
        <label class="field-label" for="new_password">Пароль</label>
        <span class="pw-field-wrap block">
          <input type="password" id="new_password" name="password" required minlength="6" autocomplete="new-password">
          <button type="button" class="pw-toggle-btn" data-toggle-pw title="Показать/скрыть пароль" aria-label="Показать/скрыть пароль">
            <svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
              <path d="M1 10S4.5 4 10 4s9 6 9 6-3.5 6-9 6-9-6-9-6z"/>
              <circle cx="10" cy="10" r="2.4"/>
              <line class="pw-toggle-slash" x1="2.5" y1="2.5" x2="17.5" y2="17.5" style="display:none"/>
            </svg>
          </button>
        </span>
      </div>
      <div class="field">
        <label class="field-label" for="new_department">Отдел</label>
        <?php if ($isMainAdmin): ?>
        <select id="new_department" name="department" required>
          <option value="">— выберите отдел —</option>
          <?php foreach (KB_DEPARTMENT_NAMES as $code => $name): ?>
          <option value="<?= $code ?>"><?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?></option>
          <?php endforeach; ?>
        </select>
        <p class="hint">Дирекция (ДР) — все инструменты. Начальник отдела (НО) — инструменты отдела из суффикса логина: например grigorian.g_CO → ЦО. Для этих отделов выберите роль user; административные права задаются отдельно ролью.</p>
        <?php else: ?>
        <input type="text" id="new_department" value="<?= htmlspecialchars(department_label($myDepartment), ENT_QUOTES, 'UTF-8') ?>" disabled>
        <p class="hint">Admin заводит сотрудников своего отдела.</p>
        <?php endif; ?>
      </div>
      <div class="field">
        <label class="field-label" for="new_role">Роль</label>
        <?php if ($isMainAdmin): ?>
        <select id="new_role" name="role">
          <option value="user" selected>user</option>
          <option value="admin">admin</option>
          <option value="mainadmin">MainAdmin</option>
        </select>
        <?php else: ?>
        <select id="new_role" name="role" disabled>
          <option value="user" selected>user</option>
        </select>
        <input type="hidden" name="role" value="user">
        <p class="hint">Только MainAdmin может создавать пользователей с ролью admin/mainadmin.</p>
        <?php endif; ?>
      </div>
      <button type="submit">Добавить пользователя</button>
    </form>
  </div>

  </div>
  </div>
</div>
<script>
  function confirmResetPw(form) {
    var pw = form.querySelector('input[name="password"]').value;
    if (!pw) { alert('Введите новый пароль в поле рядом с кнопкой.'); return false; }
    return true;
  }

  document.querySelectorAll('[data-toggle-pw]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var wrap = btn.closest('.pw-field-wrap');
      var input = wrap ? wrap.querySelector('input') : null;
      var slash = btn.querySelector('.pw-toggle-slash');
      if (!input) return;
      var willShow = input.type === 'password';
      input.type = willShow ? 'text' : 'password';
      if (slash) slash.style.display = willShow ? '' : 'none';
    });
  });

  (function () {
    var search = document.getElementById('user-search');
    var deptFilter = document.getElementById('dept-filter');
    var rows = Array.prototype.slice.call(document.querySelectorAll('#users-tbody tr[data-login]'));
    var emptyMsg = document.getElementById('users-empty-filtered');
    if (!search || !rows.length) return;
    function applyFilter() {
      var q = search.value.trim().toLowerCase();
      var dept = deptFilter ? deptFilter.value : '';
      var visibleCount = 0;
      rows.forEach(function (row) {
        var match = row.getAttribute('data-login').indexOf(q) !== -1
          && (!dept || row.getAttribute('data-dept') === dept);
        row.style.display = match ? '' : 'none';
        if (match) visibleCount++;
      });
      if (emptyMsg) emptyMsg.style.display = ((q || dept) && visibleCount === 0) ? '' : 'none';
    }
    search.addEventListener('input', applyFilter);
    if (deptFilter) deptFilter.addEventListener('change', applyFilter);
  })();
</script>
</body>
</html>
