<?php
declare(strict_types=1);

// Список пачек номенклатуры, присланных 1С (см. web/1c_intake.php), с
// результатом проверки по каждой — доступно только admin/mainadmin (см.
// admin_guard.php). Сама эта страница ничего не изменяет — только читает
// уже готовые статусы: позиции без единого замечания фоновый процесс уже
// добавил в базу сам (common.nomenclature_intake.auto_promote_clean_items),
// замеченные — ждут ручной проверки на web/onec_review.php.

require __DIR__ . '/admin_guard.php';
require __DIR__ . '/config.php';

if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(16));
}
$csrf = $_SESSION['csrf'];

function count_unresolved_in_file(string $path): int {
    $raw = file_get_contents($path);
    $data = $raw !== false ? json_decode($raw, true) : null;
    if (!is_array($data)) {
        return 0;
    }
    $n = 0;
    foreach ($data as $entry) {
        if (is_array($entry) && empty($entry['resolved'])) {
            $n++;
        }
    }
    return $n;
}

function count_pending_review(): int {
    $files = glob(OUTPUT_DIR . '/*_1c_pending.json') ?: [];
    $n = 0;
    foreach ($files as $path) {
        $n += count_unresolved_in_file($path);
    }
    return $n;
}

// Источник истины по списку присланных пачек — файлы <токен>_1c_input.json
// в UPLOAD_DIR (пишет 1c_intake.php сразу при приёме, ДО фоновой
// обработки) — так в списке видны и ещё не обработанные пачки, не только
// уже готовые. Ограничение на 200 последних — страница отчётов не
// рассчитана на бесконечную историю, старое можно найти прямо на сервере.
function list_onec_batches(): array {
    $inputFiles = glob(UPLOAD_DIR . '/*_1c_input.json') ?: [];
    usort($inputFiles, fn($a, $b) => filemtime($b) <=> filemtime($a));
    $inputFiles = array_slice($inputFiles, 0, 200);

    $batches = [];
    foreach ($inputFiles as $inputPath) {
        if (!preg_match('/^([a-f0-9]{16})_1c_input\.json$/', basename($inputPath), $m)) {
            continue;
        }
        $token = $m[1];
        $statusPath = OUTPUT_DIR . "/{$token}_1c_status.json";
        $batch = [
            'token' => $token,
            'received_at' => filemtime($inputPath),
            'status' => 'processing',
            'stats' => null,
            'error' => null,
        ];
        if (is_file($statusPath)) {
            $raw = file_get_contents($statusPath);
            $result = $raw !== false ? json_decode($raw, true) : null;
            if (is_array($result) && !empty($result['ok'])) {
                $batch['status'] = 'done';
                $batch['stats'] = $result['stats'] ?? null;
            } else {
                $batch['status'] = 'error';
                $batch['error'] = is_array($result) ? ($result['error'] ?? 'неизвестная ошибка') : 'не удалось прочитать статус';
            }
        }
        $pendingPath = OUTPUT_DIR . "/{$token}_1c_pending.json";
        $batch['pending_unresolved'] = is_file($pendingPath) ? count_unresolved_in_file($pendingPath) : 0;
        $batches[] = $batch;
    }
    return $batches;
}

$batches = list_onec_batches();
$pendingCount = count_pending_review();
$flagLabels = [
    'catalog_review' => 'Выберите раздел',
    'missing_code' => 'Нет кода 1С',
    'code_changed' => 'Изменение существующего кода',
    'batch_code_conflict' => 'Конфликт кода в пачке',
    'batch_name_duplicate' => 'Одинаковые наименования в пачке',
    'invalid_fields' => 'Неверные реквизиты',

    'not_vent_relevant' => 'Не вентиляция?',
    'possible_duplicate' => 'Дубликат?',
    'possible_typo' => 'Опечатка?',
    'tee_length_violation' => 'Тройник: длина мала',
    'tee_length_unknown' => 'Тройник: длина не указана',
    'semantic_similarity' => 'Семантически близко',
];
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="refresh" content="30">
<title>Номенклатура 1С — База знаний</title>
<link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
</head>
<body>
<div class="shell">
  <?php require __DIR__ . '/sidebar.php'; ?>

  <div class="dashboard-main">
  <div class="page-wide">

  <div class="card">
    <div style="display:flex; justify-content:space-between; align-items:flex-start; gap:16px; flex-wrap:wrap;">
      <div style="flex:1 1 320px; min-width:0;">
        <h1>Проверка номенклатуры от 1С</h1>
        <p class="subtitle">
          Пачки, присланные 1С (см. интеграцию с 1c_intake.php), и результат автоматической
          проверки по каждой — опечатки, дублирование, релевантность вентиляции, длина тройника.
          Позиции без единого замечания уже в боевой базе сравнения — фоновый процесс добавил их
          сам. Позиции с замечанием ждут ручной проверки — поправить и подтвердить можно на
          отдельной странице.
        </p>
      </div>
      <a class="btn-small btn-outline" href="onec_whitespace_cleanup.php" style="white-space:nowrap;">Убрать лишние пробелы →</a>
    </div>

    <?php if (isset($_GET['deleted'])): $deletedN = (int) $_GET['deleted']; ?>
    <div class="alert success"><?= $deletedN > 0 ? 'Пачка удалена.' : 'Нечего было удалять — файлы пачки уже отсутствовали.' ?></div>
    <?php endif; ?>
    <?php if (!empty($_GET['err'])): ?>
    <div class="alert error"><?= htmlspecialchars((string) $_GET['err'], ENT_QUOTES, 'UTF-8') ?></div>
    <?php endif; ?>

    <?php if ($pendingCount > 0): ?>
    <div class="alert error">
      На ручной проверке: <?= $pendingCount ?>.
      <a href="onec_review.php">Открыть очередь →</a>
    </div>
    <?php endif; ?>

    <?php if (!is_file(ONEC_API_KEY_FILE)): ?>
    <div class="alert error">Приём от 1С ещё не настроен на сервере — нет файла ключа (<?= htmlspecialchars(ONEC_API_KEY_FILE, ENT_QUOTES, 'UTF-8') ?>).</div>
    <?php endif; ?>
    <?php if (!is_file(ONEC_NOMENCLATURE_FILE)): ?>
    <div class="alert error">Нет эталонного снимка базы номенклатуры для сравнения (<?= htmlspecialchars(ONEC_NOMENCLATURE_FILE, ENT_QUOTES, 'UTF-8') ?>) — 1С не сможет прислать данные, пока администратор не положит этот файл на сервер.</div>
    <?php endif; ?>

    <div class="table-wrap">
      <table class="data-table" style="width: 100%; max-width: 100%;">
        <thead>
          <tr>
            <th style="white-space: nowrap;">Получено</th>
            <th style="white-space: nowrap;">Статус</th>
            <th style="white-space: normal; width: 170px;">Проверено / без замечаний / требуют проверки</th>
            <th style="white-space: normal;">По типам замечаний</th>
            <th style="white-space: nowrap;">Отчёт</th>
            <th></th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($batches as $b): ?>
          <tr>
            <td data-label="Получено"><?= htmlspecialchars(date('d.m.Y H:i:s', $b['received_at']), ENT_QUOTES, 'UTF-8') ?></td>
            <td data-label="Статус">
              <?php if ($b['status'] === 'processing'): ?>
                <span class="role-badge user">обрабатывается</span>
              <?php elseif ($b['status'] === 'error'): ?>
                <span class="role-badge admin" title="<?= htmlspecialchars((string) $b['error'], ENT_QUOTES, 'UTF-8') ?>">ошибка</span>
              <?php else: ?>
                <span class="role-badge mainadmin">готово</span>
              <?php endif; ?>
            </td>
            <td data-label="Итоги" style="white-space: normal; width: 170px;">
              <?php if ($b['stats']): $s = $b['stats']; ?>
                <?= (int) $s['total_checked'] ?> / <?= (int) $s['ok'] ?> / <?= (int) $s['flagged'] ?>
                <?php if (isset($s['auto_by_catalog'])): ?>
                  <div class="subtitle">Изменено автоматически — Вентиляция: <?= (int) ($s['auto_by_catalog']['ventilation'] ?? 0) ?>;
                    ВК: <?= (int) ($s['auto_by_catalog']['vk'] ?? 0) ?>.
                    На проверке: <?= (int) ($s['pending_review'] ?? 0) ?>.</div>
                <?php endif; ?>
                <?php if (!empty($s['auto_added'])): ?>
                  <div class="subtitle" style="margin: 4px 0 0; font-size: 0.8rem;">
                    добавлено в базу автоматически: <?= (int) $s['auto_added'] ?>
                  </div>
                <?php endif; ?>
                <?php if (!empty($s['skipped_groups']) || !empty($s['skipped_inactive'])): ?>
                  <div class="subtitle" style="margin: 4px 0 0; font-size: 0.8rem;">
                    пропущено: групп — <?= (int) $s['skipped_groups'] ?>, архив/к удалению — <?= (int) $s['skipped_inactive'] ?>
                  </div>
                <?php endif; ?>
              <?php elseif ($b['status'] === 'error'): ?>
                <span class="subtitle" style="margin:0;"><?= htmlspecialchars((string) $b['error'], ENT_QUOTES, 'UTF-8') ?></span>
              <?php else: ?>
                —
              <?php endif; ?>
            </td>
            <td data-label="Замечания" style="white-space: normal;">
              <?php if ($b['stats'] && !empty($s['by_flag_type'])): ?>
                <?php $parts = []; foreach ($s['by_flag_type'] as $type => $count) { $parts[] = ($flagLabels[$type] ?? $type) . ': ' . (int) $count; } ?>
                <span class="subtitle" style="margin:0; font-size:0.82rem;"><?= htmlspecialchars(implode('; ', $parts), ENT_QUOTES, 'UTF-8') ?></span>
              <?php else: ?>
                —
              <?php endif; ?>
            </td>
            <td data-label="Отчёт">
              <?php if ($b['status'] === 'done'): ?>
              <a class="btn-small" href="download.php?file=<?= urlencode($b['token']) ?>_1c_report.xlsx&dl=<?= urlencode('1c_intake_' . $b['token']) ?>">Скачать</a>
              <?php else: ?>
              —
              <?php endif; ?>
            </td>
            <td data-label="Действия">
              <?php
                $confirmMsg = $b['pending_unresolved'] > 0
                    ? "Удалить пачку? В ней {$b['pending_unresolved']} позиций(и) ещё в очереди ручной проверки — они будут удалены без следа, в базу не попадут."
                    : 'Удалить пачку из списка?';
              ?>
              <form class="inline-form" method="post" action="onec_intake_delete.php"
                    onsubmit="return confirm('<?= htmlspecialchars(addslashes($confirmMsg), ENT_QUOTES, 'UTF-8') ?>');">
                <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
                <input type="hidden" name="token" value="<?= htmlspecialchars($b['token'], ENT_QUOTES, 'UTF-8') ?>">
                <button type="submit" class="btn-small btn-danger">Удалить</button>
              </form>
            </td>
          </tr>
          <?php endforeach; ?>
          <?php if (!$batches): ?>
          <tr><td colspan="6">Пока ни одной пачки от 1С не поступало.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>
  </div>

  </div>
  </div>
</div>
</body>
</html>
