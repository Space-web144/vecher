<?php
declare(strict_types=1);

// Страница входа в обновлённом оформлении (DESIGN_REFRESH, см. design.php).
// Подключается из login.php после проверки логина; $error и $next оттуда.
// Прежний вид — в самом login.php, он не изменился.

if (!defined('KB_REFRESH_VIEW')) {
    http_response_code(404);
    exit;
}
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Вход — База знаний</title>
<link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
<?= design_refresh_css() ?>
<script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
</head>
<body class="kb-login">
<main class="kb-login-screen">
  <section class="kb-login-brand" aria-label="Альфастрой, База знаний">
    <svg class="kb-login-mark" viewBox="0 0 1100.0 1002.58" aria-hidden="true" focusable="false">
      <path fill-rule="evenodd" d="M546.73,50.0 L439.33,243.12 L400.43,307.83 L376.33,355.34 L285.11,518.5 L258.26,561.88 L170.14,724.01 L171.51,727.45 L175.99,729.17 L642.08,728.83 L653.1,730.21 L659.64,734.34 L670.65,755.34 L671.0,761.19 L664.8,764.63 L632.79,764.97 L154.65,764.63 L145.35,768.07 L140.53,778.74 L143.63,782.87 L149.14,784.25 L678.92,783.22 L687.52,787.35 L693.72,795.61 L699.91,810.41 L699.23,817.3 L692.0,820.74 L124.01,820.4 L114.37,823.15 L108.18,835.89 L113.34,840.36 L707.14,839.67 L716.44,842.43 L725.04,852.41 L731.24,865.15 L730.9,872.03 L722.63,875.82 L92.0,875.82 L83.05,878.23 L77.88,889.93 L83.39,894.75 L741.57,894.41 L748.45,897.16 L758.78,911.27 L761.53,920.57 L760.15,926.42 L755.34,929.86 L59.29,930.55 L50.34,936.4 L50.0,947.07 L54.13,952.58 L711.96,950.17 L752.24,952.58 L761.53,949.83 L793.89,952.58 L796.64,945.01 L794.23,936.06 L566.35,528.83 L563.6,520.22 L564.63,510.93 L574.61,493.03 L582.53,490.28 L592.86,500.6 L838.3,940.53 L847.93,952.58 L857.92,952.58 L860.67,945.35 L857.92,936.06 L595.96,467.21 L595.96,453.1 L606.63,434.85 L613.51,432.1 L619.71,436.23 L899.57,937.78 L909.55,948.45 L920.22,948.11 L922.98,943.29 L921.94,938.12 L628.66,414.89 L626.25,405.59 L628.66,394.58 L638.3,379.43 L645.87,376.33 L652.75,381.15 L745.01,549.14 L767.73,585.97 L963.25,938.47 L975.65,952.58 L982.19,952.58 L987.69,943.98 L978.4,923.67 L929.86,841.05 L859.64,710.93 L842.43,683.73 L660.33,356.37 L658.61,345.35 L667.56,325.04 L671.69,320.91 L677.88,319.54 L685.11,325.04 L1027.62,940.19 L1038.3,952.58 L1046.56,952.58 L1050.0,945.7 L1049.66,940.19 L930.55,728.49 L857.92,593.55 L762.22,426.94 L684.42,282.36 L678.92,276.51 L675.13,277.19 L668.24,285.46 L437.26,698.88 L431.07,706.45 L424.87,709.21 L402.84,709.21 L397.33,706.11 L398.02,695.09 L409.38,672.72 L429.0,641.39 L484.77,536.75 L649.31,245.18 L652.75,233.82 L646.56,220.74 L640.36,223.49 L375.3,696.82 L368.07,706.11 L361.53,708.86 L339.16,709.21 L333.99,706.11 L333.3,697.5 L619.02,185.28 L621.77,174.96 L614.54,162.91 L608.0,166.01 L586.32,206.97 L566.01,239.33 L496.82,367.38 L308.18,703.36 L302.67,707.83 L276.16,709.21 L269.62,705.77 L271.0,694.41 L582.53,138.47 L589.41,117.81 L586.66,109.9 L581.84,105.77 L577.02,107.83 L514.37,222.46 L402.15,419.02 L244.49,703.7 L234.85,709.21 L214.2,709.21 L207.31,706.11 L206.97,696.13 L357.75,423.84 L372.89,400.43 L483.05,199.4 L548.8,86.83 L558.78,61.7 L552.93,50.69 Z M545.7,545.7 L550.52,545.35 L560.84,558.78 L600.09,630.38 L618.33,658.26 L637.26,693.72 L638.98,704.04 L636.23,707.83 L467.56,709.21 L461.36,705.42 L461.02,696.47 L467.9,681.33 Z"/>
    </svg>
    <div class="kb-login-name">
      <span class="co">Альфастрой</span>
      <span class="kb">База знаний</span>
    </div>
    <p class="kb-login-tagline">Регламенты, инструкции и рабочие инструменты компании в одном месте.</p>
  </section>

  <section class="kb-login-form">
    <div class="kb-login-inner">
      <h1>Вход</h1>

      <?php if ($error): ?>
      <div class="alert error" role="alert"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
      <?php endif; ?>

      <form method="post" action="login.php" autocomplete="on">
        <input type="hidden" name="next" value="<?= htmlspecialchars($next, ENT_QUOTES, 'UTF-8') ?>">
        <div class="field">
          <label class="field-label" for="login">Логин</label>
          <input id="login" name="login" type="text" autocomplete="username" autocapitalize="none" spellcheck="false" required<?= $error ? '' : ' autofocus' ?>
                 value="<?= htmlspecialchars((string) ($_POST['login'] ?? ''), ENT_QUOTES, 'UTF-8') ?>">
        </div>
        <div class="field">
          <label class="field-label" for="password">Пароль</label>
          <div class="kb-pw">
            <input id="password" name="password" type="password" autocomplete="current-password" required aria-describedby="kb-caps"<?= $error ? ' autofocus' : '' ?>>
            <button type="button" class="kb-pw-toggle" aria-controls="password" aria-pressed="false" aria-label="Показать пароль" title="Показать пароль">
              <svg class="kb-eye" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 12s3.6-7 10-7 10 7 10 7-3.6 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/></svg>
              <svg class="kb-eye-off" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 3l18 18"/><path d="M10.6 5.1A10.4 10.4 0 0 1 12 5c6.4 0 10 7 10 7a17.6 17.6 0 0 1-3.2 4.1M6.6 6.6C3.8 8.4 2 12 2 12s3.6 7 10 7a9.7 9.7 0 0 0 5.4-1.6"/><path d="M9.9 9.9a3 3 0 0 0 4.2 4.2"/></svg>
            </button>
          </div>
          <p class="kb-caps" id="kb-caps" aria-live="polite"></p>
        </div>
        <button type="submit" class="kb-login-submit">Войти</button>
      </form>

      <p class="kb-login-help">Нет доступа или забыли пароль — обратитесь к администратору сайта.</p>
    </div>
  </section>
</main>
<script>
  (function () {
    var input = document.getElementById('password');
    var toggle = document.querySelector('.kb-pw-toggle');
    var caps = document.getElementById('kb-caps');
    toggle.addEventListener('click', function () {
      var show = input.type === 'password';
      input.type = show ? 'text' : 'password';
      toggle.setAttribute('aria-pressed', show ? 'true' : 'false');
      var label = show ? 'Скрыть пароль' : 'Показать пароль';
      toggle.setAttribute('aria-label', label);
      toggle.title = label;
    });
    // Пароль с включённым Caps Lock — частая причина «неверного пароля».
    function checkCaps(e) {
      if (!e.getModifierState) return;
      caps.textContent = e.getModifierState('CapsLock') ? 'Включён Caps Lock' : '';
    }
    input.addEventListener('keydown', checkCaps);
    input.addEventListener('keyup', checkCaps);
    input.addEventListener('blur', function () { caps.textContent = ''; });
  })();
</script>
</body>
</html>
