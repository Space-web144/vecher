<?php
declare(strict_types=1);

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require __DIR__ . '/lib.php';

$file = $_GET['file'] ?? '';

// Только имя файла, ровно в нашем формате (токен из process.php/
// 1c_intake.php) — никаких "../" и произвольных путей. Варианты имени,
// которые реально создают process.php/process_pdf.php + web_run.py/
// web_pdf_run.py, и отдельно 1c_intake.php + common/web_1c_intake_run.py:
//   <токен>_result.xlsx      — обработанная спецификация / результат конвертера
//   <токен>_spec_otch.xlsx   — отдельный файл-отчёт (см. common/report.py)
//   <токен>_1c_report.xlsx   — отчёт проверки номенклатуры от 1С (см.
//                              common/nomenclature_intake.py), скачивается
//                              только со страницы web/onec_intake.php
$pattern = '/^[a-f0-9]{16}_(result|spec_otch|1c_report)\.xlsx$/';
if (!is_string($file) || !preg_match($pattern, $file)) {
    http_response_code(400);
    exit('Некорректное имя файла.');
}

$path = OUTPUT_DIR . '/' . $file;
$realOutputDir = realpath(OUTPUT_DIR);
$realPath = realpath($path);

if ($realPath === false || $realOutputDir === false || strpos($realPath, $realOutputDir) !== 0 || !is_file($realPath)) {
    http_response_code(404);
    exit('Файл не найден.');
}

// Имя файла в диалоге "Сохранить как" у пользователя — привязанное к
// исходному загруженному файлу (см. lib.php::sanitize_display_base),
// передаётся отдельным параметром и не влияет на то, какой файл реально
// читается с диска (это всё ещё $realPath по строгой токен-маске выше).
$downloadName = basename($realPath);
$dl = $_GET['dl'] ?? '';
if (is_string($dl) && $dl !== '') {
    $safeDl = sanitize_display_base(preg_replace('/\.xlsx$/i', '', $dl) ?? '');
    $downloadName = $safeDl . '.xlsx';
}

header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="' . $downloadName . '"');
header('Content-Length: ' . filesize($realPath));
header('X-Content-Type-Options: nosniff');
readfile($realPath);
