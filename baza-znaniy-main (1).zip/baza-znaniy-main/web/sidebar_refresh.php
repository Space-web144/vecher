<?php
declare(strict_types=1);

// Меню в обновлённом оформлении (DESIGN_REFRESH, см. design.php).
// Подключается из sidebar.php вместо прежнего меню; $role/$isAdminTier
// там уже определены.
//
// Меню строится по модулям схемы отдела автоматизации (structure.php):
// общие пункты, затем модули. В модуле — инструменты и ссылка на страницу
// модуля. Плановые задачи и их статусы показываются на странице модуля,
// с прежней проверкой прав (KB_PLAN_VIEWERS). Открыт модуль текущей
// страницы; открытие другого сворачивает предыдущий. Внизу — строка
// пользователя с кнопками темы и выхода.

if (!function_exists('design_refresh')) {
    http_response_code(404);
    exit;
}

require_once __DIR__ . '/structure_lib.php';

$kbNavCurrent = basename((string) ($_SERVER['SCRIPT_NAME'] ?? ''));
// Страница направления отмечает своё направление, страница инструмента — сам инструмент.
$kbNavSection = $kbNavCurrent === 'section.php' ? (string) ($_GET['id'] ?? '') : '';
$kbPlans = kb_can_see_plans((string) ($_SESSION['kb_user'] ?? ''));

/** Сколько РВ из 1С ждут проверки текущего сметчика (значок у пункта «РВ по ЛРВ»); 0 — не сметчик ЦО или пусто. */
function kb_rv_queue_badge(): int
{
    static $n = null;
    if ($n === null) {
        $n = 0;
        if (kb_can_open_page('rv.php')) {
            require_once __DIR__ . '/rv_lib.php';
            $n = rv_can_take() ? rv_my_queue_count((string) ($_SESSION['kb_user'] ?? '')) : 0;
        }
    }
    return $n;
}

function kb_nav(string $href, array $files, string $label, string $icon, string $current, string $extra = ''): string
{
    $isCurrent = in_array($current, $files, true);
    return '<a class="nav-item available' . $extra . ($isCurrent ? ' current' : '') . '" href="' . kb_e($href) . '"'
        . ($isCurrent ? ' aria-current="page"' : '') . '>'
        . ($icon !== '' ? kb_icon($icon, 18) : '') . '<span>' . kb_e($label) . '</span></a>';
}

/** Текущий инструмент, включая ссылки на разные режимы одной страницы. */
function kb_nav_tool_current(array $tool, string $current): bool
{
    if (!in_array($current, $tool['files'] ?? [$tool['href']], true)) {
        return false;
    }
    foreach (($tool['nav_query'] ?? []) as $key => $value) {
        $actual = $_GET[$key] ?? '';
        if ($key === 'department') {
            $mine = current_department() === 'CO' ? 'co' : 'pto';
            if ($actual === '' || (!kb_can_see_plans((string) ($_SESSION['kb_user'] ?? '')) && !user_has_all_tools() && $actual !== $mine)) {
                $actual = $mine;
            }
        }
        if ((string) $actual !== $value) {
            return false;
        }
    }
    return true;
}

// Группируем только отделы; общие инструменты остаются самостоятельными пунктами.
$kbDepartmentIds = ['co', 'pto', 'gpr', 'sdo', 'hr', 'omts', 'buh', 'law'];
$kbNavGroups = [];
$kbDepartmentsCurrent = false;
foreach (kb_structure() as $kbNavModule) {
    if (($kbNavModule['in_nav'] ?? true) === false) {
        continue;
    }
    $kbIsDepartment = in_array($kbNavModule['id'], $kbDepartmentIds, true);
    $kbNavGroups[$kbIsDepartment ? 'departments' : $kbNavModule['id']][] = $kbNavModule;
    if ($kbIsDepartment) {
        $kbDepartmentsCurrent = $kbDepartmentsCurrent || $kbNavModule['id'] === $kbNavSection;
        foreach ($kbNavModule['tools'] as $kbNavTool) {
            $kbDepartmentsCurrent = $kbDepartmentsCurrent
                || kb_nav_tool_current($kbNavTool, $kbNavCurrent);
        }
    }
}

$kbRoleNames = ['mainadmin' => 'Главный администратор', 'admin' => 'Администратор'];
// Должность в подписи пользователя не меняет его роль и права.
$kbJobTitles = [
    'doronina.e' => 'Исполнительный директор',
    'novikov.e' => 'Директор по строительству',
    'vdovikin.d' => 'Генеральный директор',
    'kravcov' => 'Заместитель генерального директора',
    'blinov.n' => 'Первый заместитель генерального директора',
];
$kbDisplayLogin = mb_strtolower(trim((string) ($_SESSION['kb_user'] ?? '')));
$kbRoleName = $kbJobTitles[$kbDisplayLogin] ?? $kbRoleNames[$role] ?? 'Сотрудник';
$kbAdminFiles = ['admin_users.php', 'onec_intake.php', 'onec_review.php', 'onec_database.php', 'onec_whitespace_cleanup.php', 'onec_db_duplicates.php', 'agent_log.php', 'admin_developer_feedback.php', 'clean_papper.php'];
$kbFeedbackInbox = kb_can_open_page('admin_developer_feedback.php');
?>
  <?= design_refresh_css() ?>
  <script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
  <div class="sidebar kb-sidebar">
    <div class="sidebar-brand">
      <a class="kb-brand-link" href="index.php" aria-label="База знаний — на главную">
      <svg class="mark" width="30" height="27" viewBox="0 0 1100.0 1002.58" aria-hidden="true" focusable="false">
          <path fill-rule="evenodd" d="M546.73,50.0 L439.33,243.12 L400.43,307.83 L376.33,355.34 L285.11,518.5 L258.26,561.88 L170.14,724.01 L171.51,727.45 L175.99,729.17 L642.08,728.83 L653.1,730.21 L659.64,734.34 L670.65,755.34 L671.0,761.19 L664.8,764.63 L632.79,764.97 L154.65,764.63 L145.35,768.07 L140.53,778.74 L143.63,782.87 L149.14,784.25 L678.92,783.22 L687.52,787.35 L693.72,795.61 L699.91,810.41 L699.23,817.3 L692.0,820.74 L124.01,820.4 L114.37,823.15 L108.18,835.89 L113.34,840.36 L707.14,839.67 L716.44,842.43 L725.04,852.41 L731.24,865.15 L730.9,872.03 L722.63,875.82 L92.0,875.82 L83.05,878.23 L77.88,889.93 L83.39,894.75 L741.57,894.41 L748.45,897.16 L758.78,911.27 L761.53,920.57 L760.15,926.42 L755.34,929.86 L59.29,930.55 L50.34,936.4 L50.0,947.07 L54.13,952.58 L711.96,950.17 L752.24,952.58 L761.53,949.83 L793.89,952.58 L796.64,945.01 L794.23,936.06 L566.35,528.83 L563.6,520.22 L564.63,510.93 L574.61,493.03 L582.53,490.28 L592.86,500.6 L838.3,940.53 L847.93,952.58 L857.92,952.58 L860.67,945.35 L857.92,936.06 L595.96,467.21 L595.96,453.1 L606.63,434.85 L613.51,432.1 L619.71,436.23 L899.57,937.78 L909.55,948.45 L920.22,948.11 L922.98,943.29 L921.94,938.12 L628.66,414.89 L626.25,405.59 L628.66,394.58 L638.3,379.43 L645.87,376.33 L652.75,381.15 L745.01,549.14 L767.73,585.97 L963.25,938.47 L975.65,952.58 L982.19,952.58 L987.69,943.98 L978.4,923.67 L929.86,841.05 L859.64,710.93 L842.43,683.73 L660.33,356.37 L658.61,345.35 L667.56,325.04 L671.69,320.91 L677.88,319.54 L685.11,325.04 L1027.62,940.19 L1038.3,952.58 L1046.56,952.58 L1050.0,945.7 L1049.66,940.19 L930.55,728.49 L857.92,593.55 L762.22,426.94 L684.42,282.36 L678.92,276.51 L675.13,277.19 L668.24,285.46 L437.26,698.88 L431.07,706.45 L424.87,709.21 L402.84,709.21 L397.33,706.11 L398.02,695.09 L409.38,672.72 L429.0,641.39 L484.77,536.75 L649.31,245.18 L652.75,233.82 L646.56,220.74 L640.36,223.49 L375.3,696.82 L368.07,706.11 L361.53,708.86 L339.16,709.21 L333.99,706.11 L333.3,697.5 L619.02,185.28 L621.77,174.96 L614.54,162.91 L608.0,166.01 L586.32,206.97 L566.01,239.33 L496.82,367.38 L308.18,703.36 L302.67,707.83 L276.16,709.21 L269.62,705.77 L271.0,694.41 L582.53,138.47 L589.41,117.81 L586.66,109.9 L581.84,105.77 L577.02,107.83 L514.37,222.46 L402.15,419.02 L244.49,703.7 L234.85,709.21 L214.2,709.21 L207.31,706.11 L206.97,696.13 L357.75,423.84 L372.89,400.43 L483.05,199.4 L548.8,86.83 L558.78,61.7 L552.93,50.69 Z M545.7,545.7 L550.52,545.35 L560.84,558.78 L600.09,630.38 L618.33,658.26 L637.26,693.72 L638.98,704.04 L636.23,707.83 L467.56,709.21 L461.36,705.42 L461.02,696.47 L467.9,681.33 Z"/>
        </svg>
      <span class="wordmark">
        <span class="co">Альфастрой</span>
        <span class="kb">База знаний</span>
      </span>
      </a>
      <button type="button" class="sidebar-toggle" aria-expanded="false" aria-controls="sidebar-menu">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" aria-hidden="true"><line x1="4" y1="7" x2="20" y2="7"/><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="17" x2="20" y2="17"/></svg>
        <span>Меню</span>
      </button>
    </div>

    <div class="sidebar-menu" id="sidebar-menu">

    <nav class="sidebar-nav" aria-label="Разделы">
      <?php if (kb_can_open_page('index.php')): ?>
      <?= kb_nav('index.php', ['index.php'], 'Главная', 'home', $kbNavCurrent) ?>
      <?php endif; ?>
      <?php if (kb_can_open_page('docs.php')): ?>
      <?= kb_nav('docs.php', ['docs.php'], 'Документация', 'docs', $kbNavCurrent) ?>
      <?php endif; ?>
      <?= kb_nav('developer_feedback.php', ['developer_feedback.php'], 'Обращения к разработчику', 'log', $kbNavCurrent) ?>
      <?php if ($kbPlans): ?>
      <?= kb_nav('roadmap.php', ['roadmap.php'], 'Схема направлений', 'roadmap', $kbNavCurrent) ?>
      <?php endif; ?>

      <div class="nav-section" role="group" aria-labelledby="kb-nav-modules">
        <div class="nav-section-label" id="kb-nav-modules">Модули</div>
        <?php foreach ($kbNavGroups as $kbNavGroupId => $kbNavModules): ?>
          <?php if ($kbNavGroupId === 'departments'): ?>
          <details class="kb-departments"<?= $kbDepartmentsCurrent ? ' open' : '' ?>>
            <summary class="nav-item available kb-module-sum<?= $kbDepartmentsCurrent ? ' has-current' : '' ?>">
              <?= kb_icon('users', 18) ?><span>Отделы</span>
            </summary>
            <div class="kb-departments-list">
          <?php endif; ?>
        <?php foreach ($kbNavModules as $kbModule): ?>
          <?php
          if (($kbModule['in_nav'] ?? true) === false) {
              continue;
          }
          $kbHere = $kbModule['id'] === $kbNavSection;
          $kbHasCurrent = $kbHere;
          foreach ($kbModule['tools'] as $kbTool) {
              $kbHasCurrent = $kbHasCurrent || kb_nav_tool_current($kbTool, $kbNavCurrent);
          }
          ?>
          <?php if (!empty($kbModule['single']) && $kbModule['tools']): ?>
          <?php $kbTool = $kbModule['tools'][0]; ?>
          <?= kb_nav($kbTool['href'], array_merge($kbTool['files'] ?? [$kbTool['href']], $kbHere ? ['section.php'] : []), $kbModule['nav'], $kbModule['icon'], $kbNavCurrent) ?>
          <?php continue; endif; ?>
          <details class="kb-module" name="kb-module"<?= $kbHasCurrent ? ' open' : '' ?>>
            <summary class="nav-item available kb-module-sum<?= $kbHere ? ' current' : '' ?><?= $kbHasCurrent ? ' has-current' : '' ?><?= $kbModule['tools'] ? '' : ' is-quiet' ?>">
              <?= kb_icon($kbModule['icon'], 18) ?><span><?= kb_e($kbModule['nav']) ?></span>
            </summary>
            <?php
            $kbToolGroups = [];
            foreach (($kbModule['nav_groups'] ?? ['' => '']) as $kbToolGroupId => $kbToolGroupTitle) {
                $kbToolGroups[$kbToolGroupId] = array_values(array_filter(
                    $kbModule['tools'],
                    fn($tool) => ($tool['nav_group'] ?? '') === $kbToolGroupId
                ));
            }
            ?>
            <?php foreach ($kbToolGroups as $kbToolGroupId => $kbGroupTools): ?>
              <?php if ($kbToolGroupId !== ''): ?>
              <?php $kbGroupCurrent = (bool) array_filter($kbGroupTools, fn($tool) => kb_nav_tool_current($tool, $kbNavCurrent)); ?>
              <details class="kb-tool-group"<?= $kbGroupCurrent ? ' open' : '' ?>>
                <summary class="nav-item available kb-module-sum<?= $kbGroupCurrent ? ' has-current' : '' ?>"><span><?= kb_e($kbModule['nav_groups'][$kbToolGroupId]) ?></span></summary>
              <?php endif; ?>
            <ul class="kb-tasks">
              <?php foreach ($kbGroupTools as $kbTool): ?>
              <?php $kbToolCurrent = kb_nav_tool_current($kbTool, $kbNavCurrent); ?>
              <li>
                <a class="kb-task is-link<?= $kbToolCurrent ? ' current' : '' ?>" href="<?= kb_e($kbTool['href']) ?>"<?= $kbToolCurrent ? ' aria-current="page"' : '' ?>>
                  <?php if ($kbPlans): ?><span class="kb-mark is-done" aria-hidden="true"></span><?php endif; ?>
                  <span><?= kb_e($kbTool['name']) ?></span>
                  <?php if ($kbTool['href'] === 'rv.php' && kb_rv_queue_badge() > 0): ?><span class="kb-task-count" title="РВ из 1С ждут вашей проверки"><?= kb_rv_queue_badge() ?></span><?php endif; ?>
                </a>
              </li>
              <?php endforeach; ?>
            </ul>
              <?php if ($kbToolGroupId !== ''): ?></details><?php endif; ?>
            <?php endforeach; ?>
            <ul class="kb-tasks">
              <li><a class="kb-task kb-task-more<?= $kbHere ? ' current' : '' ?>" href="section.php?id=<?= kb_e($kbModule['id']) ?>"<?= $kbHere ? ' aria-current="page"' : '' ?>><span>Страница модуля</span></a></li>
            </ul>
          </details>
        <?php endforeach; ?>
          <?php if ($kbNavGroupId === 'departments'): ?>
            </div>
          </details>
          <?php endif; ?>
        <?php endforeach; ?>
      </div>

      <?php if ($isAdminTier || $kbFeedbackInbox): ?>
      <details class="nav-group"<?= in_array($kbNavCurrent, $kbAdminFiles, true) ? ' open' : '' ?>>
        <summary class="nav-group-label">Администрирование</summary>
        <?php if ($isAdminTier): ?>
        <?= kb_nav('admin_users.php', ['admin_users.php'], 'Пользователи', 'users', $kbNavCurrent) ?>
        <?= kb_nav('onec_intake.php', ['onec_intake.php', 'onec_review.php'], 'Номенклатура от 1С', 'onec', $kbNavCurrent) ?>
        <?= kb_nav('onec_database.php', ['onec_database.php', 'onec_db_duplicates.php', 'onec_whitespace_cleanup.php'], 'База', 'base', $kbNavCurrent) ?>
        <?= kb_nav('agent_log.php', ['agent_log.php'], 'Журнал Альфика', 'log', $kbNavCurrent) ?>
        <?php endif; ?>
        <?php if ($kbCleanPapperAllowed): ?>
        <?= kb_nav('clean_papper.php', ['clean_papper.php'], 'Clean Papper', 'base', $kbNavCurrent) ?>
        <?php endif; ?>
        <?php if ($kbFeedbackInbox): ?>
        <?= kb_nav('admin_developer_feedback.php', ['admin_developer_feedback.php'], 'Обращения', 'log', $kbNavCurrent) ?>
        <?php endif; ?>
      </details>
      <?php endif; ?>
    </nav>

    <div class="kb-side-foot">
      <div class="kb-user">
        <span class="kb-user-name"><?= htmlspecialchars((string) ($_SESSION['kb_user'] ?? ''), ENT_QUOTES, 'UTF-8') ?></span>
        <span class="kb-user-role"><?= htmlspecialchars($kbRoleName, ENT_QUOTES, 'UTF-8') ?></span>
      </div>
      <button type="button" class="kb-icon-btn kb-theme" role="switch" aria-checked="false" aria-label="Тёмная тема" title="Тёмная тема" data-theme-toggle>
        <svg class="kb-moon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5z"/></svg>
        <svg class="kb-sun" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2.5v2M12 19.5v2M2.5 12h2M19.5 12h2M5.3 5.3l1.4 1.4M17.3 17.3l1.4 1.4M18.7 5.3l-1.4 1.4M6.7 17.3l-1.4 1.4"/></svg>
      </button>
      <a class="kb-icon-btn" href="logout.php" aria-label="Выйти" title="Выйти">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M10 20H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h4"/><path d="M15 16.5 19.5 12 15 7.5"/><path d="M19.5 12H9"/></svg>
      </a>
      <?php if (design_preview()): ?>
      <a class="kb-design-back" href="index.php?design=old">Вернуть прежний вид</a>
      <?php endif; ?>
    </div>
    </div>
  </div>
  <script>
  // На узком экране меню свёрнуто под кнопку «Меню». Класс ставит скрипт:
  // без JS меню просто остаётся раскрытым.
  (function () {
    var sidebar = document.currentScript.previousElementSibling;
    var toggle = sidebar.querySelector('.sidebar-toggle');
    sidebar.classList.add('collapsible');
    toggle.addEventListener('click', function () {
      var open = sidebar.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });

    // На компьютере список модулей прокручивается сам по себе: открытый
    // модуль (текущий или только что раскрытый) показываем целиком.
    var nav = sidebar.querySelector('.sidebar-nav');
    function reveal(el) {
      if (!nav || nav.scrollHeight <= nav.clientHeight) return;
      var n = nav.getBoundingClientRect();
      var r = el.getBoundingClientRect();
      if (r.bottom > n.bottom) {
        nav.scrollTop += Math.min(r.bottom - n.bottom + 8, r.top - n.top - 8);
      } else if (r.top < n.top) {
        nav.scrollTop -= n.top - r.top + 8;
      }
    }
    var modules = sidebar.querySelectorAll('.kb-module, .kb-departments, .kb-tool-group');
    for (var i = 0; i < modules.length; i++) {
      modules[i].addEventListener('toggle', function (e) {
        if (e.currentTarget.open && !e.currentTarget.closest('details:not([open])')) reveal(e.currentTarget);
      });
    }
    var current = sidebar.querySelector('.kb-module[open]');
    if (current) reveal(current);
  })();
  </script>
