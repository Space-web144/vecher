<?php
declare(strict_types=1);

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require_once __DIR__ . '/lib.php';
require_once __DIR__ . '/users.php';

$token = $_GET['token'] ?? '';
if (!is_string($token) || !preg_match('/^[a-f0-9]{16}$/', $token)) {
    http_response_code(400);
    exit('Некорректный идентификатор задачи.');
}

$statusPath = VERRATA_OUTPUT_DIR . '/' . $token . '_status.json';
$status = null;
if (is_file($statusPath)) {
    $raw = file_get_contents($statusPath);
    $status = $raw !== false ? json_decode($raw, true) : null;
}
$state = is_array($status) ? (string) ($status['state'] ?? '') : '';
$stage = is_array($status) ? (string) ($status['stage'] ?? '') : '';
$updated = is_array($status) ? (int) ($status['updated'] ?? 0) : 0;
// Время начала обработки берём из карточки задачи: её пишут один раз при
// постановке и больше не трогают. Время изменения файла статуса для этого
// не годится — статус обновляется на каждом шаге прогона, и счётчик
// обнулялся бы при каждом обновлении страницы. Порядок источников: карточка
// задачи, поле started в статусе, и только в крайнем случае — время файла.
$startedAt = 0;
$jobPath = VERRATA_OUTPUT_DIR . '/' . $token . '_job.json';
if (is_file($jobPath)) {
    $job = json_decode((string) file_get_contents($jobPath), true);
    if (is_array($job)) {
        $startedAt = (int) ($job['created'] ?? 0);
    }
}
if ($startedAt <= 0 && is_array($status)) {
    $startedAt = (int) ($status['started'] ?? 0);
}
if ($startedAt <= 0) {
    $startedAt = is_file($statusPath) ? (int) filemtime($statusPath) : time();
}
$elapsed = max(0, time() - $startedAt);

// Файл статуса создаёт сам verrata_process.php до запуска процесса, поэтому
// его отсутствие — это не «ещё не начали», а «задача не была поставлена»
// (не тот токен в ссылке, либо папка отчётов недоступна на запись).
$missing = !is_file($statusPath) || !is_array($status);

// Молчание дольше VERRATA_STALL_SEC означает, что фоновый процесс оборвался:
// сам он в конце всегда пишет либо done, либо error. Показывать в этом случае
// бесконечный индикатор — значит врать про работу, которой уже нет.
$silence = $updated > 0 ? (time() - $updated) : null;
$stalled = ($state === 'running' || $state === 'inventory')
    && $silence !== null && $silence > VERRATA_STALL_SEC;

// Фоновый процесс не подал голоса: ключ launched остался от PHP, значит
// процесс умер ещё на импорте (на первом деплое так и было — OpenBLAS
// упёрся в лимит процессов хостинга). Отдельная ветка, чтобы не ждать
// десять минут ради очевидного.
$neverStarted = is_array($status) && ($status['launched'] ?? null) === false
    && $elapsed > VERRATA_START_TIMEOUT_SEC;
if ($neverStarted) {
    $stalled = true;
}

// Инвентаризация — такое же ожидание, как и сам разбор: читаются штампы
// всех листов, десяток секунд на комплект.
$running = !$missing && !$stalled
    && ($state === '' || $state === 'running' || $state === 'inventory');

// Инвентаризация закончилась — инженер подтверждает роли редакций на
// карточке «Что я нашёл». Это единственная точка human-in-the-loop во всём
// конвейере, и дальше без подтверждения разбор не идёт.
if (!$missing && !$stalled && $state === 'awaiting_confirm') {
    header('Location: verrata_confirm.php?token=' . urlencode($token));
    exit;
}

if ($missing) {
    $pageTitle = 'Verrata — задача не найдена';
} elseif ($stalled) {
    $pageTitle = 'Verrata — обработка прервалась';
} elseif ($running) {
    $pageTitle = 'Verrata — обработка';
} else {
    $pageTitle = $state === 'done' ? 'Verrata — готово' : 'Verrata — ошибка';
}
if (!$running && $state !== 'done') {
    http_response_code(500);
}
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
<meta name="viewport" content="width=device-width, initial-scale=1">
<?php if ($running): ?><meta http-equiv="refresh" content="5"><?php endif; ?>
<title><?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') ?></title>
<link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
<script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
</head>
<body>
<div class="shell">
  <?php require __DIR__ . '/sidebar.php'; ?>

  <div class="dashboard-main">
  <div class="page">

<?php if ($missing): ?>
  <div class="card">
    <h1>Задача не найдена</h1>
    <div class="alert error">Файла состояния этой задачи нет на диске. Либо ссылка устарела, либо папка отчётов на сервере недоступна на запись.</div>
    <a class="back-link" href="verrata.php">← Новое сравнение</a>
  </div>

<?php elseif ($stalled): ?>
  <div class="card">
    <h1><?= $neverStarted ? 'Обработка не запустилась' : 'Обработка прервалась' ?></h1>
    <?php if ($neverStarted): ?>
      <div class="alert error">
        Фоновый процесс не запустился: за <?= (int) VERRATA_START_TIMEOUT_SEC ?> секунд он не подал ни одного признака жизни. Обычно это значит, что он упал ещё на запуске — не хватило памяти или процессов, либо на сервере не хватает файлов обработки.
      </div>
    <?php else: ?>
      <div class="alert error">
        Фоновый процесс молчит <?= (int) round(((int) $silence) / 60) ?> мин. Он завершается либо готовым отчётом, либо ошибкой, поэтому такое молчание означает, что процесс оборвался: чаще всего это лимит процессорного времени хостинга или нехватка памяти.
      </div>
      <p class="hint">Последний шаг, до которого дело дошло: <?= $stage !== '' ? htmlspecialchars($stage, ENT_QUOTES, 'UTF-8') : 'неизвестен' ?></p>
    <?php endif; ?>
    <p class="hint">Причина пишется в лог на сервере: <code>web/data/verrata_outputs/verrata_errors.log</code></p>
    <a class="back-link" href="verrata.php">← Новое сравнение</a>
  </div>

<?php elseif ($running): ?>
  <div class="card">
    <h1>Идёт сравнение</h1>
    <p class="subtitle">Комплект в полторы сотни листов обрабатывается несколько минут. Страница обновляется сама — её можно оставить открытой.</p>
    <div class="alert is-running">
      <?= $stage !== '' ? htmlspecialchars($stage, ENT_QUOTES, 'UTF-8') : 'задача поставлена в работу…' ?>
    </div>
    <p class="hint">Идёт: <span id="seconds"><?= htmlspecialchars(verrata_elapsed_text($elapsed), ENT_QUOTES, 'UTF-8') ?></span></p>
  </div>
  <script>
    // Отсчёт продолжается между автообновлениями страницы, но точка отсчёта
    // всегда серверная: при следующей перезагрузке значение придёт заново
    // от времени постановки задачи, а не от времени этой загрузки.
    var s = <?= (int) $elapsed ?>;
    setInterval(function () {
      s += 1;
      var m = Math.floor(s / 60), sec = s % 60;
      document.getElementById('seconds').textContent =
        m > 0 ? m + ' мин ' + (sec < 10 ? '0' : '') + sec + ' с' : s + ' с';
    }, 1000);
  </script>

<?php elseif ($state === 'done'): ?>
  <?php
    $hasPdf = !empty($status['report_pdf']) && is_file(VERRATA_OUTPUT_DIR . '/' . $token . '_verrata.pdf');
    $hasXlsx = !empty($status['report_xlsx']) && is_file(VERRATA_OUTPUT_DIR . '/' . $token . '_verrata.xlsx');
  ?>
  <div class="card">
    <h1>Сравнение готово</h1>
    <p class="subtitle">Отчёты хранятся <?= VERRATA_KEEP_DAYS ?> дней и доступны в реестре сравнений. Загруженные PDF на сайте не сохраняются.</p>
    <?php foreach ((array) ($status['notes'] ?? []) as $note): ?>
      <div class="alert"><?= htmlspecialchars((string) $note, ENT_QUOTES, 'UTF-8') ?></div>
    <?php endforeach; ?>
    <div class="links">
      <?php if ($hasPdf): ?>
        <a class="btn" href="verrata_download.php?token=<?= urlencode($token) ?>&amp;kind=pdf">Скачать отчёт по чертежам (PDF)</a>
      <?php endif; ?>
      <?php if ($hasXlsx): ?>
        <a class="btn<?= $hasPdf ? ' secondary' : '' ?>" href="verrata_download.php?token=<?= urlencode($token) ?>&amp;kind=xlsx">Скачать отчёт по спецификации (Excel)</a>
      <?php endif; ?>
      <?php if (!$hasPdf && !$hasXlsx): ?>
        <div class="alert error">Отчёты не найдены на диске — возможно, их уже удалила очистка по сроку хранения.</div>
      <?php endif; ?>
    </div>
    <a class="back-link" href="verrata.php">← Новое сравнение</a>
  </div>

  <?php if ($hasXlsx && is_file(ANTHROPIC_CREDENTIALS_FILE)): ?>
  <div class="card">
    <h2>Вопрос по строке отчёта</h2>
    <p class="subtitle">Откройте Excel, найдите нужную позицию и назовите номер её строки. Агент ответит по фактам этой строки — количества по редакциям и дельты он видит, чертежей и остальной таблицы нет. Числа он не пересчитывает: они уже посчитаны.</p>
    <div class="ask-grid">
      <div class="field">
        <label class="field-label" for="ask-row">Номер строки в Excel</label>
        <input type="number" id="ask-row" min="1" step="1" placeholder="например, 13">
      </div>
      <div class="field">
        <label class="field-label" for="ask-question">Вопрос</label>
        <input type="text" id="ask-question" maxlength="500" placeholder="почему количество стало 0?">
      </div>
    </div>
    <div class="field">
      <button type="button" id="ask-send">Получить ответ по строке</button>
    </div>
    <div class="alert" id="ask-answer" hidden></div>
    <script>
      (function () {
        var button = document.getElementById('ask-send');
        var box = document.getElementById('ask-answer');
        button.addEventListener('click', function () {
          if (button.getAttribute('aria-busy') === 'true') return;
          var row = document.getElementById('ask-row').value;
          var question = document.getElementById('ask-question').value;
          // Ошибка — красный блок с иконкой, ответ — справочный.
          if (!row || !question.trim()) {
            box.className = 'alert error';
            box.hidden = false;
            box.textContent = 'Укажите номер строки и вопрос.';
            return;
          }
          button.setAttribute('aria-busy', 'true');
          box.className = 'alert is-running';
          box.hidden = false;
          box.textContent = 'Спрашиваю…';
          var body = new URLSearchParams();
          body.set('token', <?= json_encode($token) ?>);
          body.set('row', row);
          body.set('question', question);
          fetch('verrata_ask.php', {method: 'POST', body: body})
            .then(function (r) { return r.json(); })
            .then(function (data) {
              box.className = data.ok ? 'alert' : 'alert error';
              box.textContent = data.ok ? data.answer : (data.error || 'Агент не ответил.');
            })
            .catch(function () {
              box.className = 'alert error';
              box.textContent = 'Не удалось связаться с агентом.';
            })
            .finally(function () { button.removeAttribute('aria-busy'); });
        });
      })();
    </script>
  </div>
  <?php endif; ?>

<?php else: ?>
  <?php
    // Сравнение чертежей падает первым, а таблица спецификации к тому
    // моменту уже собрана и лежит на диске (см. program-b/compare.py).
    // Отдаём её и при ошибке: прятать от инженера готовый отчёт из-за
    // сбоя в другой части работы — хуже, чем показать его с оговоркой.
    $salvagedXlsx = !empty($status['report_xlsx'])
        && is_file(VERRATA_OUTPUT_DIR . '/' . $token . '_verrata.xlsx');
  ?>
  <div class="card">
    <h1>Обработка не удалась</h1>
    <div class="alert error"><?= htmlspecialchars((string) ($status['error'] ?? 'неизвестная ошибка'), ENT_QUOTES, 'UTF-8') ?></div>
    <?php if ($salvagedXlsx): ?>
      <p class="subtitle">Сравнение спецификаций успело пройти до сбоя — таблица количеств готова и доступна. Не собран только отчёт по чертежам.</p>
      <div class="links">
        <a class="btn" href="verrata_download.php?token=<?= urlencode($token) ?>&amp;kind=xlsx">Скачать отчёт по спецификации (Excel)</a>
      </div>
    <?php endif; ?>
    <a class="back-link" href="verrata.php">← Назад</a>
  </div>
<?php endif; ?>

  </div>
  </div>
</div>
</body>
</html>
