<?php
declare(strict_types=1);

require __DIR__ . '/auth_guard.php';
require_once __DIR__ . '/users.php';
require_once __DIR__ . '/design.php';

// Обновлённое оформление (DESIGN_REFRESH в config.php): ?design=new|old
// переключает вид, новая главная — в index_refresh.php. Ниже — прежняя.
design_handle_switch();
if (design_refresh()) {
    define('KB_REFRESH_VIEW', true);
    require __DIR__ . '/index_refresh.php';
    exit;
}

$role = (string) ($_SESSION['kb_role'] ?? '');
$isAdminTier = is_admin_tier_role($role);
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>База знаний — Альфастрой</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
<script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
</head>
<body>
<div class="shell">

  <?php require __DIR__ . '/sidebar.php'; ?>

  <div class="dashboard-main">
    <div class="page-head">
      <p class="eyebrow">Альфастрой · База знаний</p>
      <h1>Добро пожаловать в Базу знаний</h1>
      <p class="lead">Внутренние инструменты и регламенты компании «Альфастрой» в одном месте.</p>
    </div>

    <div class="product-grid">
      <?php if (kb_can_open_page('verrata.php')): ?>
      <a class="product-card" href="verrata.php">
        <div class="product-icon-sm">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M8 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h3"/><path d="M16 3h3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-3"/><path d="M9 8h2M9 12h4M9 16h2"/></svg>
        </div>
        <h3>Verrata</h3>
        <p>Сравнение ревизий РД — что изменилось в спецификации и на чертежах.</p>
        <span class="product-link">Открыть</span>
      </a>
      <?php endif; ?>
      <a class="product-card" href="agent.php">
        <div class="product-icon-sm">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M5 4h14a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-8l-5 4v-4H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z"/><path d="M8 9h8M8 12.5h5"/></svg>
        </div>
        <h3>Ассистент</h3>
        <p>Чат с Claude — нормативы, расчёты, подбор оборудования, формулировки.</p>
        <span class="product-link">Открыть</span>
      </a>
    </div>
  </div>

</div>
</body>
</html>
