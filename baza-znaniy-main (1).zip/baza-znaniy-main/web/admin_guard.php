<?php
declare(strict_types=1);

// Подключается первой строкой в admin-страницах (после auth_guard.php,
// который сам себя вызывает здесь же) — требует не просто вход, а роль
// admin или mainadmin. Обычный залогиненный пользователь получает 403, а
// не редирект на логин (он уже вошёл — просто прав не хватает). Тонкая
// граница между admin и mainadmin (кто кем может управлять) проверяется
// отдельно внутри admin_users.php, не здесь.

require __DIR__ . '/auth_guard.php';
require_once __DIR__ . '/users.php';

if (!is_admin_tier_role((string) ($_SESSION['kb_role'] ?? ''))) {
    http_response_code(403);
    header('Content-Type: text/html; charset=utf-8');
    ?>
    <!doctype html>
    <html lang="ru">
    <head>
      <meta charset="utf-8">
      <link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>Доступ запрещён</title>
      <link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
      <script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
    </head>
    <body>
    <div class="shell">
      <?php require __DIR__ . '/sidebar.php'; ?>

      <div class="dashboard-main">
      <div class="page">

      <div class="card">
        <h1>Доступ запрещён</h1>
        <div class="alert error">Эта страница доступна только администраторам.</div>
        <a class="back-link" href="index.php">← На главную</a>
      </div>

      </div>
      </div>
    </div>
    </body>
    </html>
    <?php
    exit;
}
