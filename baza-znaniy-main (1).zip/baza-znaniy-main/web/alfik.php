<?php
declare(strict_types=1);

// Персонаж и серверный контекст текущего сотрудника.
if (empty($_SESSION['kb_user'])) {
    return;
}
require_once __DIR__ . '/alfik_context_lib.php';
$alfikContext = alfik_session_context();
$alfikHints = alfik_pto_hints($alfikContext, basename((string) ($_SERVER['SCRIPT_NAME'] ?? '')), is_string($_GET['tool'] ?? null) ? $_GET['tool'] : '');
?>
<style>
.kb-alfik {
    position: fixed;
    right: max(16px, env(safe-area-inset-right));
    bottom: max(12px, env(safe-area-inset-bottom));
    width: 48px;
    aspect-ratio: 2 / 3;
    z-index: 20;
    pointer-events: none;
    user-select: none;
}
.kb-alfik.has-room {
    width: 144px;
}
.kb-alfik-figure { width: 100%; height: 100%; }
.kb-alfik img {
    display: block;
    width: 100%;
    height: 100%;
    object-fit: contain;
}
.kb-alfik-motion {
    position: absolute;
    top: -24px;
    right: 0;
    width: 28px;
    height: 28px;
    min-height: 0;
    padding: 0;
    border: 1px solid #ccd1d8;
    border-radius: 50%;
    background: #fff;
    color: #17304d;
    font: 14px/1 Arial, sans-serif;
    cursor: pointer;
    pointer-events: auto;
}
.kb-alfik-motion:focus-visible { outline: 2px solid #17304d; outline-offset: 3px; }

.kb-alfik button.kb-alfik-figure {
    display: block; padding: 0; border: 0; border-radius: 0;
    background: transparent; box-shadow: none; cursor: pointer; pointer-events: auto;
}
.kb-alfik-figure:focus-visible, .kb-alfik-help-toggle:focus-visible {
    outline: 2px solid #17304d; outline-offset: 3px;
}
.kb-alfik-help-toggle {
    position: absolute; top: -24px; right: 36px; width: max-content;
    min-height: 28px; padding: 4px 10px; border: 1px solid #ccd1d8;
    border-radius: 14px; background: #fff; color: #17304d;
    font: 12px/18px Arial, sans-serif; pointer-events: auto; cursor: pointer;
}
.kb-alfik-help {
    position: fixed;
    top: max(16px, env(safe-area-inset-top));
    right: max(16px, env(safe-area-inset-right));
    z-index: 1;
    width: min(340px, calc(100vw - 32px));
    max-height: min(520px, calc(100vh - 32px));
    max-height: min(520px, calc(100dvh - 32px));
    box-sizing: border-box; overflow-y: auto; padding: 16px;
    border: 1px solid #d9dfe7; border-radius: 16px; background: #fff;
    color: #17304d; box-shadow: 0 8px 32px #17304d26;
    font: 14px/1.5 Arial, sans-serif; user-select: text; pointer-events: auto;
}
.kb-alfik-help[hidden] { display: none; }
.kb-alfik-help-head { display: flex; align-items: flex-start; gap: 8px; }
.kb-alfik-help h2 { margin: 0; flex: 1; font: bold 16px/1.4 Arial, sans-serif; color: inherit; }
.kb-alfik-help p { margin: 10px 0; color: inherit; }
.kb-alfik-help ol { margin: 12px 0; padding-left: 20px; }
.kb-alfik-help li { margin: 6px 0; }
.kb-alfik-help-close {
    width: 28px; height: 28px; min-height: 0; flex: 0 0 28px; padding: 0;
    border: 0; border-radius: 6px; background: #edf1f6; color: #17304d;
    font: 20px/1 Arial, sans-serif; cursor: pointer;
}
.kb-alfik-help-tools { display: grid; gap: 8px; }
.kb-alfik-help-tools button {
    display: block; padding: 8px 10px; border: 1px solid #d9dfe7;
    border-radius: 8px; color: #17304d; text-decoration: none;
    width: 100%; background: #fff; text-align: left; white-space: normal; font: inherit; cursor: pointer;
}
.kb-alfik-help-tools button:hover { background: #edf1f6; }
.kb-alfik-help-tools strong { display: block; font-size: 13px; }
.kb-alfik-help-tools span { display: block; margin-top: 3px; font-size: 12px; }

.kb-alfik-help [hidden] { display: none !important; }
.kb-alfik-help h3 { margin: 12px 0; font: bold 16px/1.4 Arial, sans-serif; color: inherit; }
.kb-alfik-help-back { border: 0; padding: 6px 0; background: transparent; color: #17304d; font: inherit; cursor: pointer; }
.kb-alfik-help-go { display: block; margin-top: 16px; padding: 10px 12px; border-radius: 8px; background: #17304d; color: #fff; text-decoration: none; text-align: center; }
@media print {
    .kb-alfik { display: none; }
}
</style>
<div class="kb-alfik" data-help-scope="<?= kb_e(substr(hash('sha256', (string) $_SESSION['kb_user'] . ':' . session_id()), 0, 16)) ?>">
    <script type="application/json" class="kb-alfik-context"><?= json_encode($alfikContext, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE | JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?></script>
    <button type="button" class="kb-alfik-figure" data-alfik-help-toggle aria-label="Открыть подсказки Альфика" aria-expanded="false" aria-controls="kb-alfik-help">
        <img data-animated-src="assets/alfik-animation.webp?v=<?= filemtime(__DIR__ . '/assets/alfik-animation.webp') ?>" src="assets/alfik.svg?v=<?= filemtime(__DIR__ . '/assets/alfik.svg') ?>"
             width="144" height="216" alt="Альфик — маскот Альфастрой" decoding="async" draggable="false">
    </button>
    <button type="button" class="kb-alfik-help-toggle" data-alfik-help-toggle aria-expanded="false" aria-controls="kb-alfik-help">Подсказки</button>
    <section class="kb-alfik-help" id="kb-alfik-help" aria-labelledby="kb-alfik-help-title" tabindex="-1" hidden>
        <div class="kb-alfik-help-head">
            <h2 id="kb-alfik-help-title">Подсказки</h2>
            <button type="button" class="kb-alfik-help-close" aria-label="Закрыть подсказки">×</button>
        </div>
        <div class="kb-alfik-help-tools" data-guide-catalog>
            <button type="button" data-guide-target="prompt"><strong>Как писать промт</strong></button>
            <?php if ($alfikHints !== null): ?>
                <button type="button" data-guide-target="<?= kb_e($alfikHints['selectedHref'] ?? 'pto') ?>"><strong>Подсказки ПТО</strong></button>
            <?php endif; ?>
        </div>
        <article data-guide-panel="prompt" hidden>
            <button type="button" class="kb-alfik-help-back" data-guide-target="">← Все подсказки</button>
            <h3>Как получить точный ответ от ИИ?</h3>
            <p>Чтобы ассистент лучше понял вашу задачу, укажите:</p>
            <ol>
                <li><strong>Что нужно сделать?</strong> — найти информацию, рассчитать, сравнить, проверить, объяснить или составить документ.</li>
                <li><strong>К чему относится вопрос?</strong> — объект строительства, отдел, вид работ, система или документ.</li>
                <li><strong>Какие данные использовать?</strong> — укажите документы из Базы знаний или приложите необходимые файлы.</li>
                <li><strong>Как представить результат?</strong> — краткий ответ, пошаговая инструкция, таблица, расчёт или чек-лист.</li>
                <li><strong>Какие условия учесть?</strong> — сроки, ограничения, нормативы, требования к точности и другие особенности.</li>
            </ol>
            <p><strong>Чем конкретнее запрос, тем полезнее ответ.</strong></p>
            <p>Если вопрос связан с проектной или нормативной документацией, попросите ассистента указать источник информации.</p>
        </article>
        <?php if ($alfikHints !== null): ?>
            <section data-guide-panel="pto" hidden>
                <button type="button" class="kb-alfik-help-back" data-guide-target="">← Все подсказки</button>
                <h3>Подсказки ПТО</h3>
                <div class="kb-alfik-help-tools">
                <?php foreach ($alfikHints['tools'] as $tool): ?>
                    <button type="button" data-guide-target="<?= kb_e($tool['href']) ?>"><strong><?= kb_e($tool['name']) ?></strong><span><?= kb_e($tool['text']) ?></span></button>
                <?php endforeach; ?>
                </div>
            </section>
            <?php foreach ($alfikHints['tools'] as $tool): ?>
            <article data-guide-panel="<?= kb_e($tool['href']) ?>" hidden>
                <button type="button" class="kb-alfik-help-back" data-guide-target="pto">← Подсказки ПТО</button>
                <h3><?= kb_e($tool['title']) ?></h3>
                <p><?= kb_e($tool['text']) ?></p>
                <ol><?php foreach ($tool['steps'] as $step): ?><li><?= kb_e($step) ?></li><?php endforeach; ?></ol>
                <a class="kb-alfik-help-go" href="<?= kb_e($tool['href']) ?>">Перейти в <?= kb_e($tool['name']) ?></a>
            </article>
            <?php endforeach; ?>
        <?php endif; ?>
    </section>
    <button type="button" class="kb-alfik-motion" aria-label="Включить анимацию Альфика" aria-pressed="false" title="Включить анимацию Альфика" hidden>▶</button>
</div>
<script>
(function () {
    var mascot = document.currentScript.previousElementSibling;
    function sizeMascot() {
        var main = document.querySelector('.dashboard-main');
        if (!main) return;
        var frame = 0;
        function updateSize() {
            frame = 0;
            // Keep the full-size figure in the gutter only when there is room for it.
            var free = document.documentElement.clientWidth - main.getBoundingClientRect().right;
            mascot.classList.toggle('has-room', free >= 208 && window.innerHeight >= 280);
        }
        function scheduleSize() {
            if (!frame) frame = requestAnimationFrame(updateSize);
        }
        updateSize();
        window.addEventListener('resize', scheduleSize);
        if (window.ResizeObserver) new ResizeObserver(scheduleSize).observe(main);
        if (document.fonts) document.fonts.ready.then(scheduleSize);
    }
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', sizeMascot, {once: true});
    } else {
        sizeMascot();
    }
    var contextNode = mascot.querySelector('.kb-alfik-context');
    var context = contextNode ? JSON.parse(contextNode.textContent) : null;
    mascot.alfikContext = context;
    mascot.dispatchEvent(new CustomEvent('alfik:context', { detail: context, bubbles: true }));
    var button = mascot.querySelector('.kb-alfik-motion');
    var image = mascot.querySelector('img');
    var poster = image.getAttribute('src');
    var animated = image.getAttribute('data-animated-src');
    var motion = window.matchMedia('(prefers-reduced-motion: reduce)');
    var choice = null;
    try { choice = localStorage.getItem('kb-alfik-motion'); } catch (e) {}
    function render() {
        var enabled = choice === 'on' || (choice !== 'off' && !motion.matches);
        var source = enabled ? animated : poster;
        if (image.getAttribute('src') !== source) image.setAttribute('src', source);
        var label = enabled ? 'Остановить анимацию Альфика' : 'Включить анимацию Альфика';
        button.textContent = enabled ? 'Ⅱ' : '▶';
        button.setAttribute('aria-label', label);
        button.setAttribute('aria-pressed', enabled ? 'true' : 'false');
        button.title = label;
        button.hidden = false;
    }
    button.addEventListener('click', function () {
        choice = button.getAttribute('aria-pressed') === 'true' ? 'off' : 'on';
        try { localStorage.setItem('kb-alfik-motion', choice); } catch (e) {}
        render();
    });
    if (motion.addEventListener) motion.addEventListener('change', render);
    render();
    var panel = mascot.querySelector('.kb-alfik-help');
    if (panel) {
        var toggles = mascot.querySelectorAll('[data-alfik-help-toggle]');
        var opener = null;
        var catalog = panel.querySelector('[data-guide-catalog]');
        var guides = Array.from(panel.querySelectorAll('[data-guide-panel]'));
        var selectedHref = null;
        var stateKey = 'kb-alfik-help:' + mascot.dataset.helpScope;
        function saveHelp() {
            try { sessionStorage.setItem(stateKey, JSON.stringify({open: !panel.hidden, href: selectedHref})); } catch (e) {}
        }
        function selectGuide(href) {
            var found = guides.find(function (guide) { return guide.dataset.guidePanel === href; });
            selectedHref = found ? href : null;
            catalog.hidden = !!found;
            guides.forEach(function (guide) { guide.hidden = guide !== found; });
            panel.scrollTop = 0;
        }
        function showHelp(open, restoreFocus, focusPanel) {
            panel.hidden = !open;
            toggles.forEach(function (toggle) { toggle.setAttribute('aria-expanded', open ? 'true' : 'false'); });
            saveHelp();
            if (open && focusPanel !== false) panel.focus();
            else if (!open && restoreFocus && opener) opener.focus();
        }
        panel.querySelectorAll('[data-guide-target]').forEach(function (item) {
            item.addEventListener('click', function () {
                selectGuide(item.dataset.guideTarget);
                saveHelp();
                panel.focus();
            });
        });
        panel.querySelectorAll('.kb-alfik-help-go').forEach(function (link) {
            link.addEventListener('click', function () { saveHelp(); });
        });
        toggles.forEach(function (toggle) {
            toggle.addEventListener('click', function () {
                opener = toggle;
                showHelp(panel.hidden, false);
            });
        });
        panel.querySelector('.kb-alfik-help-close').addEventListener('click', function () { showHelp(false, true); });
        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape' && !panel.hidden) { showHelp(false, true); }
        });
        try {
            var saved = JSON.parse(sessionStorage.getItem(stateKey) || 'null');
            if (saved && typeof saved.open === 'boolean') {
                selectGuide(saved.href);
                showHelp(saved.open, false, false);
            }
        } catch (e) {}
    }
})();
</script>
