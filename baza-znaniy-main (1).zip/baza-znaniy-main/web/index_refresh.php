<?php
declare(strict_types=1);

// Главная в обновлённом оформлении (DESIGN_REFRESH, см. design.php).
// Подключается из index.php после проверки входа; сама по себе не
// открывается. Прежняя главная — в index.php, она не изменилась.
//
// На странице: вопрос Альфику (чат «Ассистент») сразу с главной, «Ваш отдел» (по коду
// отдела в логине), «Продолжить работу» (свои последние чаты, сравнения
// Verrata и новые документы), готовые инструменты и направления отдела
// автоматизации со степенью готовности (structure.php).

if (!defined('KB_REFRESH_VIEW')) {
    http_response_code(404);
    exit;
}

require_once __DIR__ . '/agent_lib.php';
require_once __DIR__ . '/structure_lib.php';

$user = (string) ($_SESSION['kb_user'] ?? '');

function home_h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

/** «сегодня, 14:20», «вчера, 09:10» или дата. */
function home_when(int $time): string
{
    if ($time <= 0) {
        return '';
    }
    $day = date('Y-m-d', $time);
    if ($day === date('Y-m-d')) {
        return 'сегодня, ' . date('H:i', $time);
    }
    if ($day === date('Y-m-d', time() - 86400)) {
        return 'вчера, ' . date('H:i', $time);
    }
    return date('d.m.Y', $time);
}

/** Пути файлов, новые сверху (по времени изменения). */
function home_newest(string $pattern, int $max): array
{
    $paths = glob($pattern) ?: [];
    $times = [];
    foreach ($paths as $path) {
        $times[$path] = (int) @filemtime($path);
    }
    arsort($times);
    return array_slice(array_keys($times), 0, $max);
}

/** Последние чаты ассистента — только свои, без побочных действий. */
function home_recent_chats(string $user, int $limit): array
{
    try {
        $dir = agent_user_dir($user);
    } catch (RuntimeException $e) {
        return [];
    }
    $now = time();
    $out = [];
    foreach (home_newest($dir . '/*.json', 20) as $path) {
        $id = basename($path, '.json');
        $chat = agent_valid_id($id) ? agent_read_chat($path) : null;
        if ($chat === null) {
            continue;
        }
        $updated = (int) ($chat['updated'] ?? 0);
        $pending = $chat['pending'] ?? null;
        $working = false;
        if (is_array($pending)) {
            // Та же граница, что в agent_expire_pending(): молчание дольше
            // порога — запрос оборвался, «работает» не пишем.
            $since = (int) ($pending['since'] ?? 0);
            $alive = max($since, (int) ($pending['started'] ?? 0), (int) ($pending['touched'] ?? 0));
            $working = !(!isset($pending['started']) && $now - $since > AGENT_START_TIMEOUT_SEC)
                && $now - $alive <= AGENT_STALL_SEC;
        }
        if (!$working && $updated < $now - AGENT_KEEP_DAYS * 86400) {
            continue;
        }
        $out[] = [
            'id' => $id,
            'title' => (string) ($chat['title'] ?? '') ?: 'Без названия',
            'when' => home_when($updated),
            'working' => $working,
        ];
        if (count($out) >= $limit) {
            break;
        }
    }
    return $out;
}

/** Последние сравнения Verrata этого пользователя. */
function home_recent_verrata(string $user, int $limit): array
{
    $modes = ['spec' => 'спецификация', 'graphics' => 'графическая часть', 'full' => 'спецификация и графика'];
    $now = time();
    $out = [];
    foreach (home_newest(VERRATA_OUTPUT_DIR . '/*_job.json', 400) as $path) {
        $token = basename($path, '_job.json');
        if (!preg_match('/^[a-f0-9]{16}$/', $token)) {
            continue;
        }
        $job = json_decode((string) @file_get_contents($path), true);
        if (!is_array($job) || (string) ($job['user'] ?? '') !== $user) {
            continue;
        }
        $created = (int) ($job['created'] ?? 0);
        if ($created < $now - VERRATA_KEEP_DAYS * 86400) {
            continue;
        }
        $status = json_decode((string) @file_get_contents(VERRATA_OUTPUT_DIR . '/' . $token . '_status.json'), true);
        $state = is_array($status) ? (string) ($status['state'] ?? '') : 'missing';
        $updated = is_array($status) ? (int) ($status['updated'] ?? 0) : 0;
        if ($state === 'done') {
            $label = ['Готово', 'done'];
        } elseif ($state === 'error' || $state === 'missing') {
            $label = ['Ошибка', 'error'];
        } elseif ($state === 'awaiting_confirm') {
            $label = ['Ждёт подтверждения', 'wait'];
        } elseif ($updated > 0 && $now - $updated > VERRATA_STALL_SEC) {
            $label = ['Прервано', 'error'];
        } else {
            $label = ['Идёт разбор', 'run'];
        }
        $names = array_map(fn($name) => (string) pathinfo((string) $name, PATHINFO_FILENAME), (array) ($job['files'] ?? []));
        $what = array_filter([(string) ($job['section'] ?? ''), $modes[(string) ($job['mode'] ?? '')] ?? '']);
        $out[] = [
            'token' => $token,
            'title' => $names ? implode(', ', $names) : 'Сравнение без файлов',
            'what' => implode(', ', $what),
            'when' => home_when($created),
            'status' => $label,
        ];
        if (count($out) >= $limit) {
            break;
        }
    }
    return $out;
}

/** Документы, добавленные или обновлённые последними. */
function home_recent_docs(int $limit): array
{
    $data = json_decode((string) @file_get_contents(DOCS_DIR . '/docs.json'), true);
    if (!is_array($data)) {
        return [];
    }
    $docs = [];
    foreach ($data as $d) {
        $id = is_array($d) ? (string) ($d['id'] ?? '') : '';
        if (!preg_match('/^[a-f0-9]{16}$/', $id)) {
            continue;
        }
        $uploaded = (int) ($d['uploaded_at'] ?? 0);
        $created = (int) ($d['created_at'] ?? $uploaded);
        $docs[] = [
            'id' => $id,
            'title' => (string) ($d['title'] ?? '') ?: (string) ($d['original_name'] ?? 'Документ'),
            'category' => (string) ($d['category'] ?? ''),
            'uploaded' => $uploaded,
            'revised' => $uploaded - $created > 3600,
            'inline' => in_array((string) ($d['ext'] ?? ''), ['pdf', 'png', 'jpg', 'jpeg', 'txt'], true),
        ];
    }
    usort($docs, fn($a, $b) => $b['uploaded'] <=> $a['uploaded']);
    return array_slice($docs, 0, $limit);
}

$chats = home_recent_chats($user, 3);
$jobs = home_recent_verrata($user, 3);
$docs = home_recent_docs(3);
$askReady = agent_configured();
$csrf = agent_csrf();

// Направления и инструменты — из structure.php (как меню и карта).
$sections = kb_structure();
$mySections = kb_user_sections($user);
$plans = kb_can_see_plans($user);
$myDepartment = current_department();
$tools = [];
foreach ($sections as $section) {
    foreach ($section['tools'] as $tool) {
        $tools[] = [$tool, $section['nav']];
    }
}
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>База знаний — Альфастрой</title>
<link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
<?= design_refresh_css() ?>
<script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
</head>
<body>
<div class="shell">

  <?php require __DIR__ . '/sidebar.php'; ?>

  <main class="dashboard-main home">
    <header class="home-head">
      <h1>База знаний</h1>
      <p class="lead">Рабочие инструменты, Альфик и документы «Альфастрой».</p>

      <?php if ($askReady): ?>
      <form class="home-ask" action="agent.php" method="post">
        <input type="hidden" name="action" value="ask">
        <input type="hidden" name="csrf" value="<?= home_h($csrf) ?>">
        <label class="home-ask-label" for="home-ask-text">Спросите Альфика</label>
        <div class="home-ask-box">
          <input id="home-ask-text" name="text" type="text" maxlength="<?= AGENT_MAX_MESSAGE_CHARS ?>" autocomplete="off" required
                 placeholder="Например, какая редакция СП 60.13330 действует сейчас" aria-describedby="home-ask-note">
          <button type="submit">Спросить</button>
        </div>
        <p class="home-ask-note" id="home-ask-note">Ответ откроется в чате с Альфиком — там же можно приложить файлы.</p>
      </form>
      <?php endif; ?>
    </header>

    <?php if ($mySections): ?>
    <section class="kb-mine" aria-labelledby="kb-mine-title">
      <div class="kb-mine-head">
        <h2 id="kb-mine-title">Для вашего отдела<?= $myDepartment !== null ? ' <span class="kb-mine-dept">' . home_h($myDepartment) . '</span>' : '' ?></h2>
      </div>
      <div class="kb-mine-grid">
        <?php foreach ($mySections as $my): ?>
        <?php $myCounts = kb_counts([$my]); ?>
        <article class="kb-mine-card<?= $my['tools'] ? '' : ' is-planned' ?>">
          <h3><a href="section.php?id=<?= home_h($my['id']) ?>"><?= home_h($my['title']) ?></a></h3>
          <?php if ($plans): ?>
          <?= kb_bar($myCounts, false) ?>
          <p class="kb-map-sum"><?= home_h(kb_cap(kb_done_text($myCounts))) ?></p>
          <?php endif; ?>
          <?php if ($my['tools']): ?>
          <ul class="kb-mine-tools">
            <?php foreach ($my['tools'] as $tool): ?>
            <li><a href="<?= home_h($tool['href']) ?>"><?= kb_icon($tool['icon'] ?? 'docs', 20) ?><?= home_h($tool['name']) ?></a></li>
            <?php endforeach; ?>
          </ul>
          <?php elseif (!$plans): ?>
          <p class="kb-mine-next">Инструменты для отдела готовятся — они появятся здесь и в меню.</p>
          <?php else: ?>
          <p class="kb-mine-next">Инструменты готовятся. Ближайшие задачи:</p>
          <ul class="kb-mine-list">
            <?php foreach (array_slice(array_values(array_filter(kb_items($my), fn($i) => $i[1] !== 'done')), 0, 3) as $item): ?>
            <li><span class="kb-mark is-<?= home_h($item[1]) ?>" aria-hidden="true"></span><?= home_h($item[0]) ?></li>
            <?php endforeach; ?>
          </ul>
          <?php endif; ?>
        </article>
        <?php endforeach; ?>
      </div>
    </section>
    <?php endif; ?>

    <section class="home-recent" aria-labelledby="home-recent-title">
      <h2 id="home-recent-title">Продолжить работу</h2>
      <div class="home-recent-grid">

        <div class="home-recent-col">
          <div class="home-col-head">
            <h3>Чаты с Альфиком</h3>
            <?php if ($chats): ?><a class="home-more" href="agent.php">Все чаты</a><?php endif; ?>
          </div>
          <?php if ($chats): ?>
          <ul class="home-list">
            <?php foreach ($chats as $c): ?>
            <li>
              <a class="home-item" href="agent.php?chat=<?= urlencode($c['id']) ?>">
                <span class="home-item-title"><?= home_h($c['title']) ?></span>
                <span class="home-item-meta">
                  <?php if ($c['working']): ?><span class="home-status is-run">Альфик работает</span><?php endif; ?>
                  <span><?= home_h($c['when']) ?></span>
                </span>
              </a>
            </li>
            <?php endforeach; ?>
          </ul>
          <?php else: ?>
          <p class="home-empty">Чатов пока нет. Задайте вопрос в поле выше или <a href="agent.php">откройте Альфика</a>.</p>
          <?php endif; ?>
        </div>

        <div class="home-recent-col">
          <div class="home-col-head">
            <h3>Сравнения Verrata</h3>
            <?php if ($jobs): ?><a class="home-more" href="verrata.php">Новое сравнение</a><?php endif; ?>
          </div>
          <?php if ($jobs): ?>
          <ul class="home-list">
            <?php foreach ($jobs as $j): ?>
            <li>
              <a class="home-item" href="verrata_status.php?token=<?= urlencode($j['token']) ?>">
                <span class="home-item-title"><?= home_h($j['title']) ?></span>
                <span class="home-item-meta">
                  <span class="home-status is-<?= home_h($j['status'][1]) ?>"><?= home_h($j['status'][0]) ?></span>
                  <span><?= home_h(trim($j['what'] . ($j['what'] !== '' ? ', ' : '') . $j['when'])) ?></span>
                </span>
              </a>
            </li>
            <?php endforeach; ?>
          </ul>
          <?php else: ?>
          <p class="home-empty">Сравнений пока нет. <a href="verrata.php">Сравните ревизии</a> — они появятся здесь.</p>
          <?php endif; ?>
        </div>

        <div class="home-recent-col">
          <div class="home-col-head">
            <h3>Новое в документации</h3>
            <?php if ($docs): ?><a class="home-more" href="docs.php">Все документы</a><?php endif; ?>
          </div>
          <?php if ($docs): ?>
          <ul class="home-list">
            <?php foreach ($docs as $d): ?>
            <li>
              <a class="home-item" href="doc_file.php?id=<?= urlencode($d['id']) ?>"<?= $d['inline'] ? ' target="_blank" rel="noopener"' : '' ?>>
                <span class="home-item-title"><?= home_h($d['title']) ?></span>
                <span class="home-item-meta">
                  <span><?= home_h(trim(($d['category'] !== '' ? $d['category'] . ', ' : '') . ($d['revised'] ? 'новая редакция ' : 'добавлен ') . home_when($d['uploaded']))) ?></span>
                </span>
              </a>
            </li>
            <?php endforeach; ?>
          </ul>
          <?php else: ?>
          <p class="home-empty">Документов пока нет.</p>
          <?php endif; ?>
        </div>

      </div>
    </section>

    <section class="home-tools" aria-labelledby="home-tools-title">
      <h2 id="home-tools-title">Инструменты на сайте</h2>
      <ul class="home-tiles">
        <?php foreach ($tools as [$tool, $sectionName]): ?>
        <li><?= kb_tool_tile($tool, $sectionName) ?></li>
        <?php endforeach; ?>
      </ul>
    </section>

    <?php if ($plans): ?>
    <section class="kb-dirs-section" aria-labelledby="kb-dirs-title">
      <div class="kb-mine-head">
        <h2 id="kb-dirs-title">Готовность модулей</h2>
        <a class="home-more" href="roadmap.php">Схема направлений</a>
      </div>
      <ul class="kb-dirs">
        <?php foreach ($sections as $s): ?>
        <?php $c = kb_counts([$s]); ?>
        <li>
          <a class="kb-dir<?= $s['tools'] ? '' : ' is-quiet' ?>" href="section.php?id=<?= home_h($s['id']) ?>">
            <?= kb_icon($s['icon']) ?>
            <span class="kb-dir-name"><?= home_h($s['title']) ?></span>
            <span class="kb-dir-state"><?= kb_bar($c, false) ?><span class="kb-dir-sum"><?= home_h(kb_done_text($c)) ?><?= $s['tools'] ? ', на сайте — ' . count($s['tools']) : '' ?></span></span>
          </a>
        </li>
        <?php endforeach; ?>
      </ul>
    </section>
    <?php endif; ?>
  </main>

</div>
</body>
</html>
