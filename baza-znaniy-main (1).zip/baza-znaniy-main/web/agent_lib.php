<?php
declare(strict_types=1);

// Общее для страницы чата «Ассистент» (agent.php) и её JSON-ручки
// (agent_api.php): где лежат чаты пользователя, чтение и запись под
// блокировкой, запуск фонового ответа модели. Формат файла чата и вторая
// сторона (кто дописывает ответ) — common/web_agent_chat.py.
//
// Файл чата пишут и PHP, и Python — оба только под flock на файле
// блокировки пользователя и только целиком (временный файл + rename).

// ini_bytes/megabytes — пределы загрузки сервера (общие с Verrata).
require_once __DIR__ . '/lib.php';

/** Ошибка, которую надо показать пользователю, с HTTP-кодом. */
final class AgentFail extends RuntimeException
{
}

function agent_configured(): bool
{
    return defined('ANTHROPIC_CREDENTIALS_FILE') && is_file(ANTHROPIC_CREDENTIALS_FILE);
}

function agent_vps_available(): bool
{
    $socket = '/run/alfik-worker/worker.sock';
    return @filetype($socket) === 'socket' && is_writable($socket);
}

/** Токен формы — тот же ключ сессии, что у admin_users.php. */
function agent_csrf(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
    }
    return (string) $_SESSION['csrf'];
}

function agent_user_dir(string $user): string
{
    // Логин бывает кириллицей и с точками — имя папки берём из хэша.
    $dir = AGENT_CHAT_DIR . '/' . substr(hash('sha256', $user), 0, 24);
    if (!is_dir($dir) && !mkdir($dir, 0700, true) && !is_dir($dir)) {
        throw new RuntimeException('Не удалось создать папку для чатов на сервере.');
    }
    return $dir;
}

/** Папка, где файлы пользователя ждут загрузки в Anthropic. */
function agent_upload_dir(string $user): string
{
    $dir = AGENT_UPLOAD_DIR . '/' . substr(hash('sha256', $user), 0, 24);
    if (!is_dir($dir) && !mkdir($dir, 0700, true) && !is_dir($dir)) {
        throw new RuntimeException('Не удалось создать папку для файлов на сервере.');
    }
    return $dir;
}

/**
 * Папка созданных ассистентом файлов этого пользователя — по тому же хэшу,
 * что и папка его чатов ($dir — результат agent_user_dir). Внутри — по
 * папке на чат (их создаёт common/web_agent_chat.py).
 */
function agent_outputs_dir(string $dir): string
{
    return AGENT_OUTPUT_DIR . '/' . basename($dir);
}

/** Удаляет созданные ассистентом файлы чата (папка чата, в ней только файлы). */
function agent_delete_outputs(string $dir, string $id): void
{
    if (!agent_valid_id($id)) {
        return;
    }
    $chatDir = agent_outputs_dir($dir) . '/' . $id;
    if (is_dir($chatDir)) {
        array_map('unlink', glob($chatDir . '/*') ?: []);
        @rmdir($chatDir);
    }
}

/**
 * Файлы ждут в папке минуты: фоновый процесс удаляет их сам — и после
 * загрузки, и после ошибки. Пролежавшее дольше суток осталось от
 * процесса, который убили посреди работы, — убираем.
 */
function agent_cleanup_uploads(string $uploadDir): void
{
    agent_cleanup_staged_uploads($uploadDir);
    $before = time() - 86400;
    foreach (glob($uploadDir . '/*') ?: [] as $path) {
        if (filemtime($path) >= $before) {
            continue;
        }
        if (is_dir($path)) {
            // Рабочая папка подготовки файла (agent-…): в ней только файлы.
            array_map('unlink', glob($path . '/*') ?: []);
            @rmdir($path);
        } else {
            @unlink($path);
        }
    }
}

/** Предел на собранный файл. HTTP-запросы передают только его части. */
function agent_file_limit(): int
{
    return 200 * 1024 * 1024;
}

function agent_upload_chunk_limit(): int
{
    $limit = 16 * 1024 * 1024;
    $upload = ini_bytes('upload_max_filesize');
    $post = ini_bytes('post_max_size');
    if ($upload > 0) {
        $limit = min($limit, $upload);
    }
    return $post > 0 ? min($limit, max(1, $post - 16384)) : $limit;
}

function agent_valid_id(string $id): bool
{
    return (bool) preg_match('/^[a-f0-9]{16}$/', $id);
}

function agent_chat_path(string $dir, string $id): string
{
    return $dir . '/' . $id . '.json';
}

function agent_lock_path(string $dir): string
{
    return $dir . '/.lock';
}

/**
 * Выполняет $fn под блокировкой чатов пользователя. Блокировка снимается
 * и при исключении — в том числе при AgentFail, который ловит вызывающий.
 */
function agent_locked(string $dir, callable $fn)
{
    $handle = fopen(agent_lock_path($dir), 'c');
    if ($handle === false || !flock($handle, LOCK_EX)) {
        throw new RuntimeException('Не удалось открыть чаты на сервере.');
    }
    try {
        return $fn();
    } finally {
        flock($handle, LOCK_UN);
        fclose($handle);
    }
}

function agent_read_chat(string $path): ?array
{
    if (!is_file($path)) {
        return null;
    }
    $chat = json_decode((string) file_get_contents($path), true);
    if (!is_array($chat)) {
        return null;
    }
    $chat['messages'] = is_array($chat['messages'] ?? null) ? $chat['messages'] : [];
    return $chat;
}

function agent_write_chat(string $path, array $chat): void
{
    $tmp = $path . '.' . getmypid() . '.tmp';
    $json = json_encode($chat, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    if ($json === false || file_put_contents($tmp, $json) === false || !rename($tmp, $path)) {
        @unlink($tmp);
        throw new RuntimeException('Не удалось сохранить чат на сервере.');
    }
}

/** Название чата — начало первого вопроса. */
function agent_title(string $text): string
{
    $title = trim((string) preg_replace('/\s+/u', ' ', $text));
    return mb_strlen($title) > 80 ? rtrim(mb_substr($title, 0, 79)) . '…' : $title;
}

function agent_new_chat(string $firstText, array $files = []): array
{
    $now = time();
    $title = $firstText !== '' ? $firstText : implode(', ', array_column($files, 'name'));
    return [
        'id' => bin2hex(random_bytes(8)),
        'title' => agent_title($title),
        'created' => $now,
        'updated' => $now,
        'pending' => null,
        'messages' => [],
    ];
}

/**
 * Если фоновый процесс так и не взялся за вопрос или не ответил за
 * AGENT_STALL_SEC — запрос оборвался (процесс убит лимитом хостинга,
 * сервер перезапущен). Снимает ожидание и пишет причину к вопросу, чтобы
 * его можно было задать ещё раз. true — чат изменился, его надо сохранить.
 */
function agent_expire_pending(array &$chat, ?int $now = null): bool
{
    $pending = $chat['pending'] ?? null;
    if (!is_array($pending)) {
        return false;
    }
    $now = $now ?? time();
    $since = (int) ($pending['since'] ?? 0);
    // Последний признак жизни: процесс отмечается на каждом шаге.
    $alive = max($since, (int) ($pending['started'] ?? 0), (int) ($pending['touched'] ?? 0));
    if (!isset($pending['started']) && $now - $since > AGENT_START_TIMEOUT_SEC) {
        $error = 'Ассистент не запустился на сервере. Спросите ещё раз; если не помогает — сообщите администратору.';
    } elseif ($now - $alive > AGENT_STALL_SEC) {
        $error = 'Ответа не было слишком долго — запрос оборвался. Спросите ещё раз.';
    } else {
        return false;
    }
    for ($i = count($chat['messages']) - 1; $i >= 0; $i--) {
        if (($chat['messages'][$i]['role'] ?? '') === 'user') {
            $chat['messages'][$i]['error'] = $error;
            // Необработанные файлы оборвавшегося запроса на сайте не нужны.
            foreach ($chat['messages'][$i]['attachments'] ?? [] as $k => $file) {
                if (($file['status'] ?? '') === 'new') {
                    if (!empty($file['path'])) {
                        @unlink((string) $file['path']);
                    }
                    unset($chat['messages'][$i]['attachments'][$k]['path']);
                    $chat['messages'][$i]['attachments'][$k]['status'] = 'error';
                    $chat['messages'][$i]['attachments'][$k]['error'] = 'Не обработан: запрос оборвался.';
                }
            }
            break;
        }
    }
    $chat['pending'] = null;
    return true;
}

/**
 * Файлы из поля формы files[] — проверенные, ещё во временной папке PHP.
 *
 * @return list<array{name: string, tmp: string, size: int}>
 */
function agent_collect_uploads(): array
{
    $uploads = $_FILES['files'] ?? null;
    if (!is_array($uploads) || !isset($uploads['name']) || !is_array($uploads['name'])) {
        return [];
    }
    // Для открытых до обновления страниц остаётся прежняя отправка одним POST.
    $server = ini_bytes('upload_max_filesize');
    $limit = $server > 0 ? min(AGENT_MAX_FILE_BYTES, $server) : AGENT_MAX_FILE_BYTES;
    $limitMb = megabytes($limit);
    $files = [];
    foreach ($uploads['name'] as $i => $originalName) {
        $name = trim(str_replace(["\0", '/', '\\'], '', (string) $originalName));
        $error = (int) ($uploads['error'][$i] ?? UPLOAD_ERR_NO_FILE);
        if ($error === UPLOAD_ERR_NO_FILE) {
            continue;
        }
        if ($error === UPLOAD_ERR_INI_SIZE || $error === UPLOAD_ERR_FORM_SIZE
            || (int) ($uploads['size'][$i] ?? 0) > $limit) {
            throw new AgentFail('Файл «' . $name . '» больше ' . $limitMb . ' МБ.', 413);
        }
        if ($error !== UPLOAD_ERR_OK) {
            throw new AgentFail('Файл «' . $name . '» не загрузился (код ' . $error . ') — прикрепите его снова.', 400);
        }
        $files[] = agent_upload_record($name, (string) ($uploads['tmp_name'][$i] ?? ''),
            (int) ($uploads['size'][$i] ?? 0));
    }
    if (count($files) > AGENT_MAX_FILES) {
        throw new AgentFail('За раз — не больше ' . AGENT_MAX_FILES . ' файлов.', 400);
    }
    return $files;
}

function agent_upload_record(string $name, string $path, int $size): array
{
    $name = trim(str_replace(["\0", '/', '\\'], '', $name));
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    if (!in_array($ext, AGENT_FILE_TYPES, true)) {
        throw new AgentFail('Файлы .' . ($ext !== '' ? $ext : '(без расширения)') . ' ассистент не принимает — «'
            . $name . '». Подходят документы, таблицы, презентации, картинки, текст и архивы: '
            . implode(', ', AGENT_FILE_TYPES) . '.', 400);
    }
    return ['name' => mb_substr($name, 0, 200), 'tmp' => $path, 'size' => $size, 'ext' => $ext];
}

/** Вызывается под блокировкой чатов пользователя. */
function agent_cleanup_staged_uploads(string $uploadDir): void
{
    $before = time() - 7200;
    foreach (glob($uploadDir . '/.staged/*', GLOB_ONLYDIR) ?: [] as $batch) {
        if (filemtime($batch) < $before) {
            agent_remove_upload_batch($batch);
        }
    }
}

function agent_upload_batch_path(string $uploadDir, string $batch): string
{
    if (!preg_match('/\A[a-f0-9]{32}\z/', $batch)) {
        throw new AgentFail('Неверный номер загрузки.', 400);
    }
    return $uploadDir . '/.staged/' . $batch;
}

function agent_remove_upload_batch(string $batch): void
{
    foreach (glob($batch . '/*') ?: [] as $path) {
        @unlink($path);
    }
    @rmdir($batch);
}

/** Дописывает часть на диск. Повтор уже записанной части безопасен. */
function agent_stage_upload_chunk(string $uploadDir, string $batch, int $index, int $offset, array $chunk): void
{
    $path = agent_upload_batch_path($uploadDir, $batch);
    $size = (int) ($chunk['size'] ?? 0);
    if ($index < 0 || $index >= AGENT_MAX_FILES || $offset < 0 || $size <= 0) {
        throw new AgentFail('Неверные параметры части файла.', 400);
    }
    if ($size > agent_upload_chunk_limit() || $offset > agent_file_limit() - $size) {
        throw new AgentFail('Превышен допустимый размер файла или его части.', 413);
    }
    $tmp = (string) ($chunk['tmp_name'] ?? '');
    if (($chunk['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK || !is_uploaded_file($tmp)) {
        throw new AgentFail('Часть файла не загрузилась. Повторите отправку.', 400);
    }
    if (!is_dir($path)) {
        if ($offset !== 0) {
            throw new AgentFail('Срок загрузки истёк. Повторите отправку.', 409);
        }
        agent_cleanup_staged_uploads($uploadDir);
        if (count(glob($uploadDir . '/.staged/*', GLOB_ONLYDIR) ?: []) >= 3) {
            throw new AgentFail('Слишком много незавершённых загрузок. Завершите их или повторите позже.', 429);
        }
        if (!mkdir($path, 0700, true)) {
            throw new RuntimeException('Не удалось создать папку загрузки.');
        }
    }

    $input = fopen($tmp, 'rb');
    $output = fopen($path . '/' . $index, 'c+b');
    try {
        if ($input === false || $output === false) {
            throw new RuntimeException('Не удалось открыть часть файла.');
        }
        $current = fstat($output)['size'];
        if ($current < $offset) {
            throw new AgentFail('Не получена предыдущая часть файла. Повторите отправку.', 409);
        }
        if ($current < $offset + $size) {
            // После прерванной записи переписываем часть с её начала.
            if (!ftruncate($output, $offset) || fseek($output, $offset) !== 0
                || stream_copy_to_stream($input, $output, $size) !== $size || !fflush($output)) {
                throw new RuntimeException('Не удалось сохранить часть файла.');
            }
        }
        touch($path);
    } finally {
        if ($input !== false) {
            fclose($input);
        }
        if ($output !== false) {
            fclose($output);
        }
    }
}

/** Проверяет, что все объявленные файлы получены целиком. */
function agent_staged_uploads(string $batch, string $manifest): array
{
    $items = json_decode($manifest, true);
    if (!is_array($items) || !$items || array_values($items) !== $items || count($items) > AGENT_MAX_FILES) {
        throw new AgentFail('Прикрепите от одного до ' . AGENT_MAX_FILES . ' файлов.', 400);
    }
    $files = [];
    foreach ($items as $index => $item) {
        $name = $item['name'] ?? null;
        $size = $item['size'] ?? null;
        if (!is_string($name) || !is_int($size) || $size <= 0 || $size > agent_file_limit()) {
            throw new AgentFail('Неверное имя или размер файла.', 400);
        }
        $path = $batch . '/' . $index;
        if (!is_file($path) || filesize($path) !== $size) {
            throw new AgentFail('Файл «' . $name . '» получен не полностью. Повторите отправку.', 422);
        }
        $files[] = agent_upload_record($name, $path, $size);
    }
    return $files;
}

/**
 * Переносит проверенные файлы в папку ожидания и возвращает записи для
 * вопроса (status "new" — их подхватит фоновый процесс). Если что-то не
 * перенеслось, уже перенесённые удаляются.
 */
function agent_store_uploads(array $files, string $uploadDir, bool $staged = false): array
{
    $records = [];
    foreach ($files as $file) {
        $path = $uploadDir . '/' . bin2hex(random_bytes(8)) . '.' . $file['ext'];
        // Сохраняем сборку до записи чата. При сбое можно повторить отправку.
        $stored = $staged ? @link($file['tmp'], $path) : move_uploaded_file($file['tmp'], $path);
        if (!$stored) {
            foreach ($records as $record) {
                @unlink($record['path']);
            }
            throw new RuntimeException('Не удалось сохранить файл «' . $file['name'] . '» на сервере.');
        }
        $records[] = ['name' => $file['name'], 'size' => $file['size'], 'status' => 'new', 'path' => $path];
    }
    return $records;
}

/** file_id всех загруженных в Anthropic файлов чата. */
function agent_chat_file_ids(array $chat): array
{
    $ids = [];
    foreach ($chat['messages'] as $message) {
        foreach ($message['attachments'] ?? [] as $file) {
            foreach ($file['files'] ?? [] as $part) {
                if (preg_match('/^[A-Za-z0-9_\-]{1,100}$/', (string) ($part['id'] ?? ''))) {
                    $ids[] = (string) $part['id'];
                }
            }
        }
    }
    return $ids;
}

/**
 * Удаляет чат: файл чата, ждущие обработки файлы и — в фоне — файлы в
 * хранилище Anthropic (иначе они пролежали бы там до конца срока, 90 дней).
 * Если ответ ещё готовится, процесс увидит, что чата нет, и уберёт за собой
 * сам (см. process_attachments в common/web_agent_chat.py).
 */
function agent_delete_chat(string $dir, string $id): void
{
    $ids = agent_locked($dir, function () use ($dir, $id) {
        $path = agent_chat_path($dir, $id);
        $chat = agent_read_chat($path);
        if ($chat === null) {
            return [];
        }
        if (empty($chat['pending'])) {
            foreach ($chat['messages'] as $message) {
                foreach ($message['attachments'] ?? [] as $file) {
                    if (!empty($file['path'])) {
                        @unlink((string) $file['path']);
                    }
                }
            }
        }
        @unlink($path);
        agent_delete_outputs($dir, $id);
        return agent_chat_file_ids($chat);
    });
    if ($ids && agent_configured()) {
        $cmd = [
            escapeshellarg(PYTHON_BIN),
            escapeshellarg(AGENT_CHAT_SCRIPT),
            '--delete-files', escapeshellarg(implode(',', $ids)),
            '--credentials', escapeshellarg(ANTHROPIC_CREDENTIALS_FILE),
        ];
        exec('nohup ' . implode(' ', $cmd) . ' >> ' . escapeshellarg(OUTPUT_DIR . '/python_errors.log') . ' 2>&1 &');
    }
}

/**
 * Все чаты пользователя, свежие первыми. Заодно удаляет чаты старше
 * AGENT_KEEP_DAYS и снимает оборвавшиеся ожидания. Вызывать под
 * agent_locked().
 *
 * @return array<string, array> id => чат
 */
function agent_load_chats(string $dir): array
{
    $chats = [];
    $expireBefore = time() - AGENT_KEEP_DAYS * 86400;
    foreach (glob($dir . '/*.json') ?: [] as $path) {
        $id = basename($path, '.json');
        $chat = agent_valid_id($id) ? agent_read_chat($path) : null;
        if ($chat === null) {
            continue;
        }
        if (agent_expire_pending($chat)) {
            agent_write_chat($path, $chat);
        }
        if (empty($chat['pending']) && (int) ($chat['updated'] ?? 0) < $expireBefore) {
            @unlink($path);
            agent_delete_outputs($dir, $id);
            continue;
        }
        $chat['id'] = $id;
        $chats[$id] = $chat;
    }
    uasort($chats, fn(array $a, array $b) => (int) ($b['updated'] ?? 0) <=> (int) ($a['updated'] ?? 0));
    return $chats;
}

/** Ставит отметку «ждём ответа»; возвращает id запроса для Python. */
function agent_start_pending(array &$chat): string
{
    $requestId = bin2hex(random_bytes(8));
    $now = time();
    $chat['pending'] = ['id' => $requestId, 'since' => $now];
    $chat['updated'] = $now;
    return $requestId;
}

/**
 * Журнал вопросов для анализа (AGENT_LOG_DIR): строка JSON на событие, файл
 * на месяц. Вопрос пишет PHP при отправке (agent_api.php), итог ответа —
 * фоновый процесс (common/web_agent_chat.py, --log-dir). Сбой записи журнала
 * вопрос не останавливает — только строка в журнал ошибок PHP.
 */
function agent_log_event(array $event): void
{
    if (!defined('AGENT_LOG_DIR')) {
        return;
    }
    try {
        if (!is_dir(AGENT_LOG_DIR) && !mkdir(AGENT_LOG_DIR, 0700, true) && !is_dir(AGENT_LOG_DIR)) {
            throw new RuntimeException('не создаётся папка ' . AGENT_LOG_DIR);
        }
        $path = AGENT_LOG_DIR . '/' . date('Y-m') . '.jsonl';
        $isNew = !is_file($path);
        $line = json_encode($event, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE) . "\n";
        if (file_put_contents($path, $line, FILE_APPEND | LOCK_EX) === false) {
            throw new RuntimeException('не пишется ' . $path);
        }
        if ($isNew) {
            @chmod($path, 0600);
            agent_log_cleanup();
        }
    } catch (Throwable $e) {
        error_log('Журнал Альфика: ' . $e->getMessage());
    }
}

/** Удаляет месяцы журнала старше AGENT_LOG_KEEP_MONTHS. */
function agent_log_cleanup(): void
{
    $keep = defined('AGENT_LOG_KEEP_MONTHS') ? (int) AGENT_LOG_KEEP_MONTHS : 24;
    $border = date('Y-m', strtotime('first day of -' . $keep . ' months'));
    foreach (agent_log_months() as $month) {
        if ($month < $border) {
            @unlink(AGENT_LOG_DIR . '/' . $month . '.jsonl');
        }
    }
}

/** Месяцы, за которые есть журнал, от новых к старым («2026-10»). */
function agent_log_months(): array
{
    $months = [];
    foreach (glob(AGENT_LOG_DIR . '/*.jsonl') ?: [] as $path) {
        $name = basename($path, '.jsonl');
        if (preg_match('/^\d{4}-\d{2}$/', $name)) {
            $months[] = $name;
        }
    }
    rsort($months);
    return $months;
}

/**
 * Записи журнала за месяц: вопрос и итог ответа сведены по номеру запроса.
 * От новых к старым. Ответ мог прийти в следующем месяце — он ищется и там.
 */
function agent_log_rows(string $month): array
{
    if (!preg_match('/^\d{4}-\d{2}$/', $month)) {
        return [];
    }
    $read = static function (string $m): array {
        $path = AGENT_LOG_DIR . '/' . $m . '.jsonl';
        $events = [];
        if (!is_file($path)) {
            return $events;
        }
        $handle = fopen($path, 'r');
        if ($handle === false) {
            return $events;
        }
        while (($line = fgets($handle)) !== false) {
            $event = json_decode($line, true);
            if (is_array($event) && !empty($event['request'])) {
                $events[] = $event;
            }
        }
        fclose($handle);
        return $events;
    };
    $next = date('Y-m', strtotime($month . '-01 +1 month'));
    $rows = [];
    $answers = [];
    foreach (array_merge($read($month), $read($next)) as $event) {
        if (($event['t'] ?? '') === 'answer') {
            $answers[(string) $event['request']] = $event;
        }
    }
    foreach ($read($month) as $event) {
        if (($event['t'] ?? '') === 'question') {
            $event['answer'] = $answers[(string) $event['request']] ?? null;
            $rows[] = $event;
        }
    }
    usort($rows, static fn(array $a, array $b): int => (int) ($b['time'] ?? 0) <=> (int) ($a['time'] ?? 0));
    return $rows;
}

/**
 * Запускает ответ модели в фоне. Ключ читает сам Python: здесь — только
 * ПУТЬ к файлу с ключом (см. ANTHROPIC_CREDENTIALS_FILE в config.php).
 */
function agent_launch(string $dir, string $id, string $requestId): void
{
    $cmd = [
        escapeshellarg(PYTHON_BIN),
        escapeshellarg(AGENT_CHAT_SCRIPT),
        '--chat', escapeshellarg(agent_chat_path($dir, $id)),
        '--lock', escapeshellarg(agent_lock_path($dir)),
        '--request', escapeshellarg($requestId),
        '--credentials', escapeshellarg(ANTHROPIC_CREDENTIALS_FILE),
        // Куда класть файлы, которые создаст ассистент, и данные сайта для
        // его инструментов («Документация», отчёты Verrata).
        '--outputs', escapeshellarg(agent_outputs_dir($dir)),
    ];
    if (defined('DOCS_DIR')) {
        array_push($cmd, '--docs-dir', escapeshellarg(DOCS_DIR));
    }
    if (defined('VERRATA_OUTPUT_DIR')) {
        array_push($cmd, '--verrata-dir', escapeshellarg(VERRATA_OUTPUT_DIR));
    }
    // Итог ответа — в журнал вопросов (agent_log_event).
    if (defined('AGENT_LOG_DIR')) {
        array_push($cmd, '--log-dir', escapeshellarg(AGENT_LOG_DIR),
            '--log-answer-chars', (string) (defined('AGENT_LOG_ANSWER_CHARS') ? (int) AGENT_LOG_ANSWER_CHARS : 0));
    }
    // Как и process.php: nohup отвязывает процесс от HTTP-запроса,
    // ошибки — в общий журнал Python, а не в /dev/null.
    exec('nohup ' . implode(' ', $cmd) . ' >> ' . escapeshellarg(OUTPUT_DIR . '/python_errors.log') . ' 2>&1 &');
}

/** То, что нужно странице: без расхода токенов и служебных полей. */
function agent_public_chat(array $chat): array
{
    $messages = [];
    foreach ($chat['messages'] as $message) {
        $item = [
            'role' => ($message['role'] ?? '') === 'assistant' ? 'assistant' : 'user',
            'text' => (string) ($message['text'] ?? ''),
            'time' => (int) ($message['time'] ?? 0),
        ];
        if (!empty($message['error'])) {
            $item['error'] = (string) $message['error'];
        }
        if (($message['processing'] ?? '') === 'vps') {
            $item['processing'] = 'vps';
        }
        if (!empty($message['truncated'])) {
            $item['truncated'] = true;
        }
        foreach ($message['attachments'] ?? [] as $file) {
            // Путь на сервере и file_id странице не нужны.
            $item['attachments'][] = array_intersect_key(
                (array) $file,
                array_flip(['name', 'size', 'status', 'kind', 'pages', 'tokens', 'note', 'error'])
            );
        }
        if ($item['role'] === 'assistant') {
            // Созданные ассистентом файлы: ссылка — agent_file.php по id.
            foreach ($message['files'] ?? [] as $file) {
                if (is_array($file) && agent_valid_id((string) ($file['id'] ?? ''))) {
                    $item['files'][] = [
                        'id' => (string) $file['id'],
                        'name' => (string) ($file['name'] ?? 'файл'),
                        'size' => (int) ($file['size'] ?? 0),
                    ];
                }
            }
            // Источники из интернета — только http(s).
            foreach ($message['sources'] ?? [] as $source) {
                $url = is_array($source) ? (string) ($source['url'] ?? '') : '';
                if (preg_match('~^https?://~i', $url)) {
                    $item['sources'][] = ['url' => $url, 'title' => (string) ($source['title'] ?? $url)];
                }
            }
        }
        $messages[] = $item;
    }
    $pending = $chat['pending'] ?? null;
    return [
        'id' => (string) $chat['id'],
        'title' => (string) ($chat['title'] ?? ''),
        'updated' => (int) ($chat['updated'] ?? 0),
        'pending' => is_array($pending) ? [
            'elapsed' => max(0, time() - (int) ($pending['since'] ?? 0)),
            'stage' => (string) ($pending['stage'] ?? ''),
            'filesDone' => (int) ($pending['files_done'] ?? 0),
            'filesTotal' => (int) ($pending['files_total'] ?? 0),
            // Ход работы: что ассистент делает сейчас и текст по мере написания.
            'activity' => (string) ($pending['activity'] ?? ''),
            'partial' => (string) ($pending['partial'] ?? ''),
        ] : null,
        'messages' => $messages,
    ];
}
