<?php
declare(strict_types=1);

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require __DIR__ . '/lib.php';
require __DIR__ . '/libob.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    fail('Ожидался POST-запрос.', 405);
}

// Формат результата: ventspec — 38-колоночная спецификация VentSpec,
// area — плоский список "Наименование"/"Площадь" для расчёта площади,
// equipment — сверка марок вентиляторов по альбому (блок "Оборудование")
// (см. program-a/web_pdf_run.py --format). От него же зависит, куда
// возвращает ссылка "Назад" на странице ошибки.
$format = $_POST['format'] ?? 'ventspec';
$backPages = [
    'ventspec' => 'ventspec.php',
    'area' => 'area.php',
    'equipment' => 'equipment.php',
];
if (!isset($backPages[$format])) {
    fail('Некорректный формат результата.');
}
$backPage = $backPages[$format];

if (empty($_FILES['pdf_file']) || $_FILES['pdf_file']['error'] === UPLOAD_ERR_NO_FILE) {
    fail('PDF-файл не выбран.', 400, $backPage);
}

$upload = $_FILES['pdf_file'];
if ($upload['error'] !== UPLOAD_ERR_OK) {
    fail('Ошибка загрузки файла (код ' . $upload['error'] . ').', 400, $backPage);
}
// Альбом проекта целиком заметно тяжелее одной только спецификации —
// под него отдельный, больший предел (см. config.php).
$maxBytes = $format === 'equipment' ? MAX_ALBUM_UPLOAD_BYTES : MAX_PDF_UPLOAD_BYTES;
if ($upload['size'] > $maxBytes) {
    fail('Файл слишком большой (максимум ' . intdiv($maxBytes, 1024 * 1024) . ' МБ).', 400, $backPage);
}

$ext = strtolower(pathinfo($upload['name'], PATHINFO_EXTENSION));
if ($ext !== 'pdf') {
    fail('Допустим только файл .pdf.', 400, $backPage);
}

if (!is_dir(UPLOAD_DIR) || !is_writable(UPLOAD_DIR)) {
    fail('Папка для загрузок недоступна на сервере.', 500, $backPage);
}
if (!is_dir(OUTPUT_DIR) || !is_writable(OUTPUT_DIR)) {
    fail('Папка для результатов недоступна на сервере.', 500, $backPage);
}

// Тот же формат имени, что и у process.php ({token}_result.xlsx,
// {token}_status.json) — status.php и download.php переиспользуются как
// есть, без отдельной ветки под конвертер PDF.
$token = bin2hex(random_bytes(8));
$pdfPath = UPLOAD_DIR . "/{$token}_spec.pdf";

if (!move_uploaded_file($upload['tmp_name'], $pdfPath)) {
    fail('Не удалось сохранить загруженный файл.', 500, $backPage);
}

$displayBase = sanitize_display_base(pathinfo($upload['name'], PATHINFO_FILENAME));

$outputPath = OUTPUT_DIR . "/{$token}_result.xlsx";
$statusPath = OUTPUT_DIR . "/{$token}_status.json";
$logFile = OUTPUT_DIR . '/python_errors.log';

$cmdParts = [
    escapeshellarg(PYTHON_BIN),
    escapeshellarg(WEB_PDF_RUN_SCRIPT),
    '--pdf', escapeshellarg($pdfPath),
    '--output', escapeshellarg($outputPath),
    '--status-file', escapeshellarg($statusPath),
    '--display-base', escapeshellarg($displayBase),
    '--format', escapeshellarg($format),
];

// Ключ Claude API (только для блока "Оборудование") передаётся дочернему
// процессу переменной окружения, а не аргументом командной строки:
// аргументы видно в ps aux всем пользователям хостинга. Тот же приём, что
// и с GC_AUTH_KEY в process.php. Сам файл секретов читается в libob.php —
// там же объяснено, почему JSON нельзя подключать через require.
$envPrefix = '';
if ($format === 'equipment') {
    $secrets = ob_claude_secrets();
    if (!empty($secrets['api_key'])) {
        $envPrefix .= 'ANTHROPIC_API_KEY=' . escapeshellarg($secrets['api_key']) . ' ';
        // Своя модель и усилие блока (по умолчанию Opus 5.5, high — см.
        // common/claude_client.py). Общее поле model сюда больше не идёт:
        // в файле там Fable 5.1, а чтению листов хватает Opus 5.5, который
        // в 2,5 раза дешевле.
        if (!empty($secrets['model_equipment'])) {
            $envPrefix .= 'ANTHROPIC_MODEL=' . escapeshellarg((string) $secrets['model_equipment']) . ' ';
        }
        if (!empty($secrets['effort_equipment'])) {
            $envPrefix .= 'ANTHROPIC_EFFORT=' . escapeshellarg((string) $secrets['effort_equipment']) . ' ';
        }
        if (!empty($secrets['proxy'])) {
            // Прокси нужен там, где прямой доступ к api.anthropic.com с
            // сервера невозможен; строка вида socks5h://user:pass@host:port
            // или http://host:port.
            $envPrefix .= 'ANTHROPIC_PROXY=' . escapeshellarg($secrets['proxy']) . ' ';
        }
    }
}

if ($format !== 'equipment') {
    $envPrefix = spec_claude_env_prefix();
}

// Конвертация PDF заметно быстрее полной обработки спецификации, но всё
// равно уходит в фон по тому же принципу, что и process.php — не хотим
// зависеть от того, насколько большой окажется конкретный PDF.
$cmd = $envPrefix . 'nohup ' . implode(' ', $cmdParts) . ' >> ' . escapeshellarg($logFile)
     . ' 2>&1 &';
exec($cmd);

header('Location: status.php?token=' . urlencode($token));
exit;
