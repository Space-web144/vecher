<?php
declare(strict_types=1);

// Переключатель обновлённого оформления (DESIGN_REFRESH в config.php).
// Решает, показывать ли новый вид главной, меню и входа, и запоминает
// выбор пользователя в cookie: ссылка ?design=new включает новый вид,
// ?design=old возвращает прежний.

require_once __DIR__ . '/config.php';

const DESIGN_COOKIE = 'kb_design';

function design_mode(): string
{
    $mode = defined('DESIGN_REFRESH') ? (string) DESIGN_REFRESH : 'off';
    return in_array($mode, ['off', 'preview', 'on'], true) ? $mode : 'off';
}

/** Показывать ли этому пользователю новый вид. */
function design_refresh(): bool
{
    $choice = (string) ($_COOKIE[DESIGN_COOKIE] ?? '');
    switch (design_mode()) {
        case 'on':
            return $choice !== 'old';
        case 'preview':
            return $choice === 'new';
    }
    return false;
}

/** Идёт ли показ «только по ссылке» — тогда в меню есть возврат к прежнему виду. */
function design_preview(): bool
{
    return design_mode() === 'preview' && design_refresh();
}

/**
 * Обрабатывает ?design=new|old: запоминает выбор и открывает ту же
 * страницу без параметра. Вызывать до вывода страницы.
 */
function design_handle_switch(): void
{
    $want = $_GET['design'] ?? null;
    if (!is_string($want) || !in_array($want, ['new', 'old'], true) || design_mode() === 'off') {
        return;
    }
    $dir = rtrim(str_replace('\\', '/', dirname((string) ($_SERVER['SCRIPT_NAME'] ?? '/'))), '/') . '/';
    setcookie(DESIGN_COOKIE, $want, [
        'expires' => time() + 365 * 86400,
        'path' => $dir,
        'secure' => !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off',
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    $query = $_GET;
    unset($query['design']);
    $target = basename((string) ($_SERVER['SCRIPT_NAME'] ?? 'index.php'));
    header('Location: ' . $target . ($query ? '?' . http_build_query($query) : ''));
    exit;
}

/** <link> на стили нового вида — только когда он включён. */
function design_refresh_css(): string
{
    // Главная и вход подключают стили в <head>, меню — на всех остальных
    // страницах; второй раз ссылка не выводится.
    static $done = false;
    if ($done || !design_refresh()) {
        return '';
    }
    $done = true;
    $file = __DIR__ . '/assets/refresh.css';
    return '<link rel="stylesheet" href="assets/refresh.css?v=' . (is_file($file) ? filemtime($file) : 0) . '">';
}
