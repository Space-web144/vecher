<?php
declare(strict_types=1);

// Решения инженера по сверке РВ из 1С (блок «Сверка с РВ из 1С» на rv_status.php): по строкам, где разнос
// в 1С и у агента расходится, — кто прав. POST: csrf, token, d[id] = 1c | agent | model.
//   1c    — верна работа из 1С (основная работа строки в 1С — с наибольшим количеством под ней);
//   agent — верна работа агента (подтверждение);
//   model — верен код, который предложила модель (обе работы неверны).
// Решения пишутся файлом проверки (как rv_feedback.php, только по отмеченным строкам, без «остальное верно»)
// и агент пересобирает РВ: решения уходят в память (RV_LEARNING_FILE) с номером этой задачи — их можно
// откатить кнопкой «Откатить согласование» (rv_rollback.php). Кто, что и когда решил — job['audit_decisions'].

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require_once __DIR__ . '/users.php';
require_once __DIR__ . '/lib.php';
require_once __DIR__ . '/rv_lib.php';

rv_guard();

$token = (string) ($_POST['token'] ?? '');
if (!rv_token_valid($token)) {
    header('Location: rv_audit.php');
    exit;
}
$back = 'rv_status.php?token=' . urlencode($token);
$go = static function (string $message) use ($back): never {
    header('Location: ' . $back . '&err=' . rawurlencode($message) . '#audit');
    exit;
};
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !hash_equals(rv_csrf(), (string) ($_POST['csrf'] ?? ''))) {
    $go('Форма устарела — обновите страницу и повторите.');
}
$paths = rv_paths($token);
$job = rv_read_json($paths['job']);
if ($job === null || !rv_can_access($job) || ($job['mode'] ?? '') !== 'audit') {
    $go('Сверка не найдена.');
}
[$state] = rv_state($token, $job);
if ($state !== 'done') {
    $go('РВ сейчас пересобирается — решения можно сохранить, когда она будет готова.');
}
$result = rv_read_packed($paths['json']);
$rows = [];
foreach ((array) ($result['audit']['rows'] ?? []) as $row) {
    if (is_array($row) && isset($row['id'])) {
        $rows[(string) $row['id']] = $row;
    }
}
$me = (string) ($_SESSION['kb_user'] ?? '');
$now = time();
$corrections = [];
$decided = [];
foreach ((array) ($_POST['d'] ?? []) as $id => $choice) {
    $id = (string) $id;
    $choice = (string) $choice;
    $row = $rows[$id] ?? null;
    if ($row === null || !in_array($choice, ['1c', 'agent', 'model'], true)) {
        continue;
    }
    $model = is_array($row['model'] ?? null) ? $row['model'] : [];
    $code = match ($choice) {
        '1c' => (string) ($row['c1_main'] ?? ''),
        'agent' => (string) ($row['agent']['code'] ?? ''),
        'model' => (string) ($model['code'] ?? ''),
    };
    if (!preg_match('/^\d{1,3}(\.\d{1,3}){3,9}$/', $code)) {
        continue;                    // у этой стороны нет кода ИСР — выбирать нечего
    }
    $corrections[] = ['id' => (int) $id, 'code' => $code, 'role' => '', 'coef' => null];
    $decided[$id] = ['choice' => $choice, 'code' => $code, 'user' => $me, 'at' => $now];
}
if (!$corrections) {
    $go('Не отмечено ни одной строки — выберите, кто прав, хотя бы в одной.');
}

$feedback = ['token' => $token, 'user' => $me, 'when' => $now, 'corrections' => $corrections, 'confirm_rest' => false];
if (file_put_contents($paths['feedback'], json_encode($feedback, JSON_UNESCAPED_UNICODE)) === false) {
    $go('Не удалось сохранить решения на сервере.');
}
$job['audit_decisions'] = $decided + (array) ($job['audit_decisions'] ?? []);
$job['feedback'] = $now;
$job['feedback_rounds'] = (int) ($job['feedback_rounds'] ?? 0) + 1;
file_put_contents($paths['job'], json_encode($job, JSON_UNESCAPED_UNICODE));
file_put_contents($paths['status'], json_encode([
    'state' => 'running',
    'stage' => 'записываю решения по сверке в память агента и строю РВ заново…',
    'started' => $now,
    'updated' => $now,
    'launched' => false,
], JSON_UNESCAPED_UNICODE));

rv_launch(['--phase', 'bind', '--status-file', $paths['status'], '--work-file', $paths['work'],
           '--out-xlsx', $paths['xlsx'], '--out-json', $paths['json'],
           '--credentials', ANTHROPIC_CREDENTIALS_FILE, '--learning-file', RV_LEARNING_FILE,
           '--feedback-file', $paths['feedback'], '--no-review', '--user', $me,
           '--source-name', (string) ($job['source_name'] ?? '')]);

header('Location: ' . $back);
exit;
