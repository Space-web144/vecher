<?php
declare(strict_types=1);

// ТКП заказчика ↔ РВ 1С: реестр ТКП заказчика с версиями и изменениями между ними, привязка блоков ТКП к сметам 1С
// и таблица блока «в договоре / в смету / объём» с ценами (этапы 1–2, логика — tkp_lib.php).
// GET: est — смета заказчика (estimateId), blk — ключ блока, diff — версия (изменения против from, по умолчанию прежней),
// show — фильтр таблицы блока (all|dev|no_rv|no_tkp).
// POST (csrf): action=upload (file), status (est, ver, status), object (est, object), bind (est, blk, smetas[]),
// delete (est, ver — руководитель). Доступ — как к модулю ЦО (rv_guard).

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require_once __DIR__ . '/users.php';
require_once __DIR__ . '/lib.php';
require_once __DIR__ . '/rv_lib.php';
require_once __DIR__ . '/rv_onec_lib.php';
require_once __DIR__ . '/tkp_lib.php';

rv_guard();

$me = (string) ($_SESSION['kb_user'] ?? '');
$isManager = rv_is_manager();
$csrf = rv_csrf();

function tkp_back(string $query, string $key, string $message): never
{
    header('Location: tkp_customer.php' . ($query !== '' ? '?' . $query . '&' : '?') . $key . '=' . rawurlencode($message));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = (string) ($_POST['action'] ?? '');
    $estId = (string) ($_POST['est'] ?? '');
    $back = tkp_id_valid($estId) ? 'est=' . $estId : '';
    if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) {
        tkp_back($back, 'err', 'Форма устарела, обновите страницу.');
    }
    try {
        switch ($action) {
            case 'upload':
                $file = $_FILES['file'] ?? null;
                if (!is_array($file) || (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
                    $code = is_array($file) ? (int) ($file['error'] ?? 0) : UPLOAD_ERR_NO_FILE;
                    tkp_back($back, 'err', match ($code) {
                        UPLOAD_ERR_NO_FILE => 'Выберите файл ТКП (.xlsx).',
                        UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE => 'Файл больше, чем принимает сервер (' . ini_get('upload_max_filesize') . ').',
                        default => 'Файл не загрузился (код ' . $code . ').',
                    });
                }
                $name = (string) ($file['name'] ?? '');
                if (!preg_match('/\.xlsx$/iu', $name)) {
                    tkp_back($back, 'err', 'Нужен Excel .xlsx, выгруженный с платформы заказчика.');
                }
                if ((int) ($file['size'] ?? 0) > TKP_MAX_BYTES) {
                    tkp_back($back, 'err', 'Файл больше ' . (int) (TKP_MAX_BYTES / 1048576) . ' МБ.');
                }
                [$newEst, $newVer, $message] = tkp_upload((string) $file['tmp_name'], $name, $me);
                tkp_back('est=' . $newEst, 'ok', $message);
            case 'status':
                $verId = (string) ($_POST['ver'] ?? '');
                $status = (string) ($_POST['status'] ?? '');
                if (!tkp_id_valid($estId) || !tkp_id_valid($verId) || !tkp_set_status($estId, $verId, $status, $me)) {
                    tkp_back($back, 'err', 'Статус не сохранён.');
                }
                tkp_back($back, 'ok', 'Версия ' . $verId . ': ' . mb_strtolower(TKP_STATUSES[$status]) . '.');
            case 'object':
                $object = trim((string) ($_POST['object'] ?? ''));
                if (!tkp_id_valid($estId) || ($object !== '' && rv_table_object($object) === null) || !tkp_set_object($estId, $object)) {
                    tkp_back($back, 'err', 'Объект не сохранён.');
                }
                tkp_back($back, 'ok', $object !== '' ? 'Объект ТКП: ' . $object . '.' : 'Объект снят.');
            case 'bind':
                $blk = (string) ($_POST['blk'] ?? '');
                $est = tkp_id_valid($estId) ? tkp_estimate($estId) : null;
                if ($est === null || !isset(((array) ($est['blocks'] ?? []))[$blk])) {
                    tkp_back($back, 'err', 'Блок не найден.');
                }
                $smetas = array_values(array_filter((array) ($_POST['smetas'] ?? []), 'is_string'));
                if (!tkp_bind($estId, $blk, $smetas, $me)) {
                    tkp_back($back . '&blk=' . rawurlencode($blk), 'err', 'Привязка не сохранена.');
                }
                tkp_back($back . '&blk=' . rawurlencode($blk), 'ok', $smetas ? 'Блок привязан: смет 1С — ' . count($smetas) . '.' : 'Привязка блока снята.');
            case 'delete':
                $verId = (string) ($_POST['ver'] ?? '');
                if (!$isManager) {
                    tkp_back($back, 'err', 'Удалить версию может руководитель.');
                }
                if (!tkp_id_valid($estId) || !tkp_id_valid($verId) || !tkp_delete_version($estId, $verId)) {
                    tkp_back($back, 'err', 'Версия не удалена.');
                }
                tkp_back(tkp_estimate($estId) !== null ? $back : '', 'ok', 'Версия ' . $verId . ' удалена.');
        }
    } catch (RuntimeException $e) {
        tkp_back($back, 'err', $e->getMessage());
    }
    tkp_back($back, 'err', 'Неизвестное действие.');
}

$okNow = (string) ($_GET['ok'] ?? '');
$errNow = (string) ($_GET['err'] ?? '');
$index = tkp_index();
$estimates = $index['estimates'];
uasort($estimates, static fn(array $a, array $b): int => [(string) ($a['object'] ?? ''), (string) ($a['address'] ?? '')] <=> [(string) ($b['object'] ?? ''), (string) ($b['address'] ?? '')]);
$estId = (string) ($_GET['est'] ?? '');
$est = tkp_id_valid($estId) && isset($estimates[$estId]) ? $estimates[$estId] : null;
$blk = (string) ($_GET['blk'] ?? '');
$blockName = $est !== null ? (string) (((array) ($est['blocks'] ?? []))[$blk] ?? '') : '';
if ($blockName === '') {
    $blk = '';
}
$diffVer = (string) ($_GET['diff'] ?? '');
$show = in_array((string) ($_GET['show'] ?? ''), ['dev', 'no_rv', 'no_tkp'], true) ? (string) $_GET['show'] : 'all';
$registryRows = $est !== null ? rv_registry_rows() : [];
$registry = tkp_registry_by_id($registryRows);

function tkp_url(array $params): string
{
    $params = array_filter($params, static fn($v): bool => $v !== '' && $v !== null);
    return 'tkp_customer.php' . ($params ? '?' . http_build_query($params) : '');
}

function tkp_tree_item(string $label, string $href, string $count, int $level, bool $selected, ?bool $open = null, bool $muted = false): string
{
    $chev = '<span class="kb-tree__chev">' . ($open === null ? '' : ($open ? '▾' : '▸')) . '</span>';
    $badge = $count !== '' ? '<span class="kb-count kb-count--quiet">' . rv_h($count) . '</span>' : '';
    return '<a href="' . rv_h($href) . '" class="kb-tree__l' . $level . ($muted ? ' is-muted' : '') . '"' . ($selected ? ' aria-current="true"' : '') . ' title="' . rv_h($label) . '">'
        . $chev . '<span class="kb-tree__label">' . rv_h($label) . '</span>' . $badge . '</a>';
}

function tkp_est_title(array $est): string
{
    $object = trim((string) ($est['object'] ?? ''));
    return $object !== '' ? $object : ((string) ($est['address'] ?? '') !== '' ? (string) $est['address'] : 'Смета ' . (string) ($est['id'] ?? ''));
}

function tkp_status_badge(string $status): string
{
    $cls = ['draft' => 'kb-badge--neutral', 'sent' => 'kb-badge--info', 'agreed' => 'kb-badge--success'][$status] ?? 'kb-badge--neutral';
    return '<span class="kb-badge ' . $cls . '">' . rv_h(TKP_STATUSES[$status] ?? $status) . '</span>';
}

/** Смета 1С в привязке: заголовок, корпус, система, вид работ, состояние РВ. */
function tkp_smeta_label(?array $row, string $lrvId): string
{
    if ($row === null) {
        return '<span class="kb-muted">' . rv_h($lrvId) . ' — нет в реестре РВ</span>';
    }
    $title = rv_smeta_title($row);
    $title = $title !== '' ? $title : (string) ($row['smeta'] ?? $lrvId);
    $sub = array_filter([(string) ($row['building_label'] ?? ''), (string) ($row['table_system'] ?? ''), (string) ($row['work_kind'] ?? '') === 'НЗ' ? 'наряд-заказ' : '', (string) ($row['label'] ?? '')]);
    $link = (string) ($row['token'] ?? '') !== '' ? '<a href="rv_status.php?token=' . rv_h((string) $row['token']) . '">' . rv_h($title) . '</a>' : rv_h($title);
    return $link . ($sub ? '<span class="kb-sub">' . rv_h(implode(' · ', $sub)) . '</span>' : '');
}

$pageTitle = 'ТКП заказчика';
$versions = $est !== null ? tkp_versions($est) : [];
$contract = $est !== null ? tkp_contract_version($est) : null;
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= rv_h($pageTitle) ?> — База знаний</title>
<link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
<script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
<style>
.kb.tkp-page .kb-two__side { flex-basis: 240px; }
.kb.tkp-page .kb-table td.is-num { white-space: nowrap; }
.kb .tkp-num { text-align: right; font-variant-numeric: tabular-nums; white-space: nowrap; }
.kb .tkp-status { min-width: 200px; }
.kb .tkp-flags { display: flex; flex-wrap: wrap; gap: 4px; margin-top: 2px; }
.kb .tkp-flags:empty { display: none; }
.kb .kb-table tr.is-over td { background: var(--c-error-bg); }
.kb .kb-table tr.is-norv td, .kb .kb-table tr.is-notkp td { background: var(--c-warning-bg); }
.kb .tkp-code { font-family: var(--font-mono, ui-monospace, monospace); font-size: 12px; color: var(--c-text-2); white-space: nowrap; }
.kb .tkp-upload { display: flex; flex-wrap: wrap; gap: var(--s2, 8px); align-items: center; }
.kb .tkp-upload input[type=file] { max-width: 320px; }
.kb .tkp-cand { display: flex; gap: 10px; align-items: flex-start; padding: 8px 12px; border-bottom: 1px solid var(--c-line); }
.kb .tkp-cand:last-child { border-bottom: 0; }
.kb .tkp-cand input { margin-top: 4px; }
.kb .tkp-cand .kb-sub { display: block; font-size: 13px; line-height: 18px; color: var(--c-text-2); }
.kb .tkp-bad { color: var(--c-error) !important; }
.kb .tkp-old { color: var(--c-text-2); text-decoration: line-through; }
.kb .tkp-filters { display: flex; gap: 6px; flex-wrap: wrap; padding: 10px 12px; border-bottom: 1px solid var(--c-line); }
.kb .tkp-about p { margin: 0 0 8px; }
</style>
</head>
<body>
<div class="shell">
  <?php require __DIR__ . '/sidebar.php'; ?>

  <div class="dashboard-main kb tkp-page">

  <header class="kb-page">
    <div class="kb-page__row">
      <div>
        <h1 class="kb-page__title"><?= $est !== null ? rv_h(tkp_est_title($est)) : 'ТКП заказчика' ?></h1>
        <p class="kb-page__sub">
          <?php if ($est !== null): ?>
            Смета заказчика № <?= rv_h((string) $est['id']) ?><?= (string) ($est['address'] ?? '') !== '' && (string) ($est['object'] ?? '') !== '' ? ' · ' . rv_h((string) $est['address']) : '' ?> · версий: <?= count($versions) ?><?php if ($contract !== null): ?> · в договоре: <?= $contract['draft'] ? 'согласованной версии нет, берём последнюю (' . rv_h((string) $contract['id']) . ')' : 'версия ' . rv_h((string) $contract['id']) ?><?php endif; ?>
          <?php else: ?>
            Реестр ТКП с платформы заказчика: версии, изменения, привязка блоков к сметам 1С и сверка объёмов · ТКП: <?= count($estimates) ?>
          <?php endif; ?>
        </p>
      </div>
      <?php if ($blk === '' && $diffVer === ''): ?>
      <div class="kb-page__actions">
        <form method="post" action="tkp_customer.php" enctype="multipart/form-data" class="tkp-upload">
          <input type="hidden" name="csrf" value="<?= rv_h($csrf) ?>"><input type="hidden" name="action" value="upload">
          <?php if ($est !== null): ?><input type="hidden" name="est" value="<?= rv_h((string) $est['id']) ?>"><?php endif; ?>
          <input type="file" name="file" accept=".xlsx" aria-label="Файл ТКП заказчика (.xlsx)" required>
          <button type="submit" class="kb-btn kb-btn--primary kb-btn--sm"><?= $est !== null ? 'Загрузить версию' : 'Загрузить ТКП' ?></button>
        </form>
      </div>
      <?php else: ?>
      <div class="kb-page__actions"><a class="kb-btn kb-btn--ghost kb-btn--sm" href="<?= rv_h(tkp_url(['est' => $est['id']])) ?>">Версии и блоки</a></div>
      <?php endif; ?>
    </div>
  </header>

  <?php if ($okNow !== ''): ?><div class="kb-alert kb-alert--success"><?= rv_h($okNow) ?></div><?php endif; ?>
  <?php if ($errNow !== ''): ?><div class="kb-alert kb-alert--danger"><?= rv_h($errNow) ?></div><?php endif; ?>

  <div class="kb-two">
    <?php if ($blk === '' && $diffVer === ''): ?>
    <aside class="kb-two__side">
      <nav class="kb-tree" aria-label="ТКП заказчика">
        <?= tkp_tree_item('Все ТКП', 'tkp_customer.php', (string) count($estimates), 0, $est === null) ?>
        <?php foreach ($estimates as $id => $e): ?>
          <?php $open = $est !== null && (string) $est['id'] === (string) $id; ?>
          <?= tkp_tree_item(tkp_est_title($e), tkp_url(['est' => $id]), $open ? '' : (string) count((array) ($e['versions'] ?? [])), 0, $open && $blk === '' && $diffVer === '', $open) ?>
          <?php if ($open): ?>
            <?php foreach ((array) ($e['blocks'] ?? []) as $uid => $name): ?>
              <?php $bound = count(tkp_block_smetas($e, (string) $uid)); ?>
              <?= tkp_tree_item((string) $name, tkp_url(['est' => $id, 'blk' => $uid]), $bound ? (string) $bound : '', 1, $blk === (string) $uid, null, !$bound) ?>
            <?php endforeach; ?>
          <?php endif; ?>
        <?php endforeach; ?>
      </nav>
      <?php if (!$estimates): ?><div class="kb-side-foot">ТКП ещё не загружали.</div><?php endif; ?>
    </aside>
    <?php endif; ?>

    <div class="kb-two__main">
    <?php if ($est === null): ?>
      <section class="kb-card">
        <div class="kb-card__head"><h2 class="kb-card__title">ТКП заказчика</h2></div>
        <div class="kb-table-wrap">
        <table class="kb-table">
          <thead><tr><th>Объект</th><th>Смета заказчика</th><th>Версии</th><th>В договоре</th><th class="is-num">Блоков привязано</th></tr></thead>
          <tbody>
          <?php foreach ($estimates as $id => $e): ?>
            <?php $c = tkp_contract_version($e); $blocks = (array) ($e['blocks'] ?? []); $boundBlocks = count(array_filter(array_keys($blocks), static fn($u): bool => (bool) tkp_block_smetas($e, (string) $u))); ?>
            <tr>
              <td><a href="<?= rv_h(tkp_url(['est' => $id])) ?>"><?= rv_h(tkp_est_title($e)) ?></a><span class="kb-sub"><?= rv_h((string) ($e['address'] ?? '')) ?></span></td>
              <td>№ <?= rv_h((string) $id) ?><span class="kb-sub"><?= rv_h((string) ($e['contractor'] ?? '')) ?></span></td>
              <td><?= count((array) ($e['versions'] ?? [])) ?></td>
              <td><?= $c === null ? '—' : ($c['draft'] ? '<span class="kb-muted">предварительное ' . rv_h((string) $c['id']) . '</span>' : tkp_status_badge('agreed') . ' ' . rv_h((string) $c['id'])) ?></td>
              <td class="is-num"><?= $boundBlocks ?> из <?= count($blocks) ?></td>
            </tr>
          <?php endforeach; ?>
          <?php if (!$estimates): ?>
            <tr><td colspan="5"><div class="kb-empty"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 4h12l4 4v12H4z"/><path d="M16 4v4h4"/></svg><div class="kb-empty__title">ТКП ещё не загружали</div><div>Выгрузите ТКП с платформы заказчика в Excel и загрузите кнопкой вверху: лист «ТКП» разберётся сам.</div></div></td></tr>
          <?php endif; ?>
          </tbody>
        </table>
        </div>
      </section>
      <details class="kb-card kb-fold" open>
        <summary class="kb-card__head">Как работает</summary>
        <div class="kb-card__body tkp-about">
          <p><b>1. Загрузка.</b> Excel с платформы заказчика как есть: смета и версия берутся из файла (ячейка D1), строки — с листа «ТКП». Каждая следующая выгрузка той же сметы — новая версия; сайт сам показывает, что в ней изменилось: объёмы, цены, новые и убранные строки. Строки узнаются по постоянному ключу платформы, номера п/п могут меняться.</p>
          <p><b>2. Статус.</b> Версии отмечаются: предварительное, отправлено заказчику, согласовано. Столбец «в договоре» берётся из последней согласованной версии; пока её нет — из последней загруженной, с пометкой.</p>
          <p><b>3. Привязка.</b> Каждый блок ТКП (корпус, секция, паркинг) привязывается к сметам 1С — сайт подсказывает сметы объекта с тем же корпусом и с теми же кодами работ. Привязка хранится по блоку и переходит на следующие версии сама.</p>
          <p><b>4. Сверка.</b> По каждому коду ИСР блока рядом три объёма: в договоре (ТКП), в смету (строки ЛРВ: количество в смету × коэф. работы) и объём (РВ — закупка). Объём не должен быть больше двух других: такие строки красные, работы без РВ и работы РВ без ТКП — жёлтые. Цены: ПСПР заказчика, цена подрядчика в ТКП и цена сметы 1С, когда 1С пришлёт факт.</p>
        </div>
      </details>

    <?php elseif ($diffVer !== ''): ?>
      <?php
        $to = $diffVer;
        $from = (string) ($_GET['from'] ?? '');
        $toMeta = ((array) ($est['versions'] ?? []))[$to] ?? null;
        if ($from === '' && is_array($toMeta)) {
            $from = (string) ($toMeta['prev'] ?? '');
        }
        $diff = $toMeta !== null && $from !== '' ? tkp_diff((string) $est['id'], $from, $to) : null;
        $newRows = [];
        $oldRows = [];
        if ($diff !== null) {
            foreach ((array) (tkp_version((string) $est['id'], $to)['rows'] ?? []) as $r) { $newRows[(string) $r['uid']] = $r; }
            foreach ((array) (tkp_version((string) $est['id'], $from)['rows'] ?? []) as $r) { $oldRows[(string) $r['uid']] = $r; }
        }
        $blocksNames = (array) ($est['blocks'] ?? []);
        $limit = 400;
        $fmt = static function ($v): string {
            return is_float($v) || is_int($v) ? tkp_num((float) $v, 4) : ($v === null || $v === '' ? '—' : (string) $v);
        };
      ?>
      <section class="kb-card">
        <div class="kb-card__head">
          <h2 class="kb-card__title">Изменения версии <?= rv_h($to) ?><?= $from !== '' ? ' против ' . rv_h($from) : '' ?></h2>
          <div class="kb-card__actions">
            <form method="get" action="tkp_customer.php" class="kb-inline-form">
              <input type="hidden" name="est" value="<?= rv_h((string) $est['id']) ?>"><input type="hidden" name="diff" value="<?= rv_h($to) ?>">
              <select class="kb-select kb-select--sm" name="from" aria-label="Сравнить с версией" onchange="this.form.submit()">
                <?php foreach ($versions as $v): if ((string) $v['id'] === $to) { continue; } ?>
                <option value="<?= rv_h((string) $v['id']) ?>"<?= (string) $v['id'] === $from ? ' selected' : '' ?>>против <?= rv_h((string) $v['id']) ?> · <?= rv_h(TKP_STATUSES[(string) ($v['status'] ?? 'draft')] ?? '') ?></option>
                <?php endforeach; ?>
              </select>
            </form>
            <a class="kb-btn kb-btn--sm kb-btn--ghost" href="<?= rv_h(tkp_url(['est' => $est['id']])) ?>">К версиям</a>
          </div>
        </div>
        <?php if ($diff === null): ?>
          <div class="kb-empty"><div class="kb-empty__title"><?= $from === '' ? 'Это первая версия — сравнивать не с чем' : 'Изменения не посчитались' ?></div></div>
        <?php else: ?>
          <div class="kb-card__foot" style="border-top:0;border-bottom:1px solid var(--c-line)"><?= rv_h(tkp_diff_text($diff['summary'] ?? null)) ?>.</div>
          <div class="kb-table-wrap">
          <table class="kb-table kb-table--dense">
            <thead><tr><th>№ п/п</th><th>Строка</th><th>Что изменилось</th><th>Блок</th></tr></thead>
            <tbody>
            <?php $changed = (array) ($diff['changed'] ?? []); ?>
            <?php if ($changed): ?><tr class="is-group"><td colspan="4">Изменены <span class="kb-muted">· <?= count($changed) ?></span></td></tr><?php endif; ?>
            <?php foreach (array_slice($changed, 0, $limit) as $c): $r = $newRows[(string) $c['uid']] ?? []; ?>
              <tr>
                <td class="tkp-code"><?= rv_h((string) ($r['num'] ?? '')) ?></td>
                <td><?= rv_h((string) ($r['name'] ?? '')) ?><span class="kb-sub"><?= rv_h(TKP_KIND_LABELS[(string) ($r['kind'] ?? '')] ?? '') ?><?= (string) ($r['code'] ?? '') !== '' ? ' · ' . rv_h((string) $r['code']) : '' ?><?= (string) ($r['unit'] ?? '') !== '' ? ' · ' . rv_h((string) $r['unit']) : '' ?></span></td>
                <td>
                  <?php foreach ((array) $c['fields'] as $field => $pair): ?>
                    <?php if ($field === 'parent'): ?>
                      <div><?= rv_h(TKP_DIFF_LABELS['parent']) ?>: <span class="tkp-old"><?= rv_h((string) ($oldRows[(string) $pair[0]]['name'] ?? $pair[0])) ?></span> → <?= rv_h((string) ($newRows[(string) $pair[1]]['name'] ?? $pair[1])) ?></div>
                    <?php else: ?>
                      <div><?= rv_h(TKP_DIFF_LABELS[$field] ?? $field) ?>: <span class="tkp-old"><?= rv_h($fmt($pair[0])) ?></span> → <b><?= rv_h($fmt($pair[1])) ?></b></div>
                    <?php endif; ?>
                  <?php endforeach; ?>
                </td>
                <td class="kb-muted"><?= rv_h((string) ($blocksNames[(string) ($r['block'] ?? '')] ?? '')) ?></td>
              </tr>
            <?php endforeach; ?>
            <?php $added = (array) ($diff['added'] ?? []); ?>
            <?php if ($added): ?><tr class="is-group"><td colspan="4">Новые строки <span class="kb-muted">· <?= count($added) ?></span></td></tr><?php endif; ?>
            <?php foreach (array_slice($added, 0, $limit) as $uid): $r = $newRows[(string) $uid] ?? []; ?>
              <tr class="is-notkp">
                <td class="tkp-code"><?= rv_h((string) ($r['num'] ?? '')) ?></td>
                <td><?= rv_h((string) ($r['name'] ?? '')) ?><span class="kb-sub"><?= rv_h(TKP_KIND_LABELS[(string) ($r['kind'] ?? '')] ?? '') ?><?= (string) ($r['code'] ?? '') !== '' ? ' · ' . rv_h((string) $r['code']) : '' ?></span></td>
                <td><?= isset($r['qty']) ? 'кол-во ' . rv_h(tkp_num((float) $r['qty'], 4)) . ' ' . rv_h((string) ($r['unit'] ?? '')) : '' ?></td>
                <td class="kb-muted"><?= rv_h((string) ($blocksNames[(string) ($r['block'] ?? '')] ?? '')) ?></td>
              </tr>
            <?php endforeach; ?>
            <?php $removed = (array) ($diff['removed'] ?? []); ?>
            <?php if ($removed): ?><tr class="is-group"><td colspan="4">Убраны <span class="kb-muted">· <?= count($removed) ?></span></td></tr><?php endif; ?>
            <?php foreach (array_slice($removed, 0, $limit) as $uid): $r = (array) (($diff['removed_rows'] ?? [])[(string) $uid] ?? []); ?>
              <tr class="is-over">
                <td class="tkp-code"><?= rv_h((string) ($r['num'] ?? '')) ?></td>
                <td><span class="tkp-old"><?= rv_h((string) ($r['name'] ?? '')) ?></span><span class="kb-sub"><?= rv_h(TKP_KIND_LABELS[(string) ($r['kind'] ?? '')] ?? '') ?><?= (string) ($r['code'] ?? '') !== '' ? ' · ' . rv_h((string) $r['code']) : '' ?></span></td>
                <td><?= isset($r['qty']) ? 'было ' . rv_h(tkp_num((float) $r['qty'], 4)) . ' ' . rv_h((string) ($r['unit'] ?? '')) : '' ?></td>
                <td class="kb-muted"><?= rv_h((string) ($blocksNames[(string) ($r['block'] ?? '')] ?? '')) ?></td>
              </tr>
            <?php endforeach; ?>
            <?php if (!$changed && !$added && !$removed): ?>
              <tr><td colspan="4"><div class="kb-empty"><div class="kb-empty__title">Версии совпадают</div></div></td></tr>
            <?php endif; ?>
            </tbody>
          </table>
          </div>
          <?php if (max(count($changed), count($added), count($removed)) > $limit): ?><div class="kb-card__foot">Показаны первые <?= $limit ?> строк каждой группы.</div><?php endif; ?>
        <?php endif; ?>
      </section>

    <?php elseif ($blk === ''): ?>
      <section class="kb-card">
        <div class="kb-card__head">
          <h2 class="kb-card__title">Версии</h2>
          <div class="kb-card__actions">
            <form method="post" action="tkp_customer.php" class="kb-inline-form">
              <input type="hidden" name="csrf" value="<?= rv_h($csrf) ?>"><input type="hidden" name="action" value="object"><input type="hidden" name="est" value="<?= rv_h((string) $est['id']) ?>">
              <select class="kb-select kb-select--sm" name="object" aria-label="Объект справочника" onchange="this.form.submit()" title="Объект из справочника «Объекты и ответственные»: по нему сайт подсказывает сметы 1С">
                <option value="">— объект не выбран —</option>
                <?php foreach (rv_table_objects() as $o): $name = (string) ($o['name'] ?? ''); ?>
                <option value="<?= rv_h($name) ?>"<?= $name === trim((string) ($est['object'] ?? '')) ? ' selected' : '' ?>><?= rv_h($name) ?></option>
                <?php endforeach; ?>
              </select>
            </form>
          </div>
        </div>
        <div class="kb-table-wrap">
        <table class="kb-table">
          <thead><tr><th>Версия</th><th>Загружена</th><th>Статус</th><th class="is-num">Работ / материалов</th><th class="is-num">Σ ПСПР, ₽</th><th class="is-num">Σ подрядчика, ₽</th><th>Изменения</th><th class="is-actions"><span class="kb-sr">Действия</span></th></tr></thead>
          <tbody>
          <?php foreach ($versions as $v): $vid = (string) $v['id']; $t = (array) ($v['totals'] ?? []); ?>
            <tr<?= $contract !== null && (string) $contract['id'] === $vid ? ' class="is-mine" title="Эта версия — «в договоре»"' : '' ?>>
              <td><b><?= rv_h($vid) ?></b><span class="kb-sub"><?= rv_h((string) ($v['file_name'] ?? '')) ?></span></td>
              <td class="is-date"><?= rv_h(rv_when((int) ($v['uploaded'] ?? 0))) ?><span class="kb-sub"><?= rv_h(rv_person_label((string) ($v['by'] ?? ''))) ?></span></td>
              <td>
                <form method="post" action="tkp_customer.php" class="kb-inline-form">
                  <input type="hidden" name="csrf" value="<?= rv_h($csrf) ?>"><input type="hidden" name="action" value="status">
                  <input type="hidden" name="est" value="<?= rv_h((string) $est['id']) ?>"><input type="hidden" name="ver" value="<?= rv_h($vid) ?>">
                  <select class="kb-select kb-select--sm tkp-status" name="status" aria-label="Статус версии <?= rv_h($vid) ?>" onchange="this.form.submit()">
                    <?php foreach (TKP_STATUSES as $code => $label): ?><option value="<?= rv_h($code) ?>"<?= (string) ($v['status'] ?? 'draft') === $code ? ' selected' : '' ?>><?= rv_h($label) ?></option><?php endforeach; ?>
                  </select>
                </form>
                <?php if ((int) ($v['status_at'] ?? 0)): ?><span class="kb-sub"><?= rv_h(rv_when((int) $v['status_at'])) ?>, <?= rv_h(rv_person_label((string) ($v['status_by'] ?? ''))) ?></span><?php endif; ?>
              </td>
              <td class="is-num"><?= (int) ($t['works'] ?? 0) ?> / <?= (int) ($t['materials'] ?? 0) ?><span class="kb-sub">с объёмом: <?= (int) ($t['works_with_qty'] ?? 0) ?></span></td>
              <td class="is-num"><?= rv_h(tkp_money(isset($t['ref_cost']) ? (float) $t['ref_cost'] : null)) ?></td>
              <td class="is-num"><?= rv_h(tkp_money(isset($t['cost']) ? (float) $t['cost'] : null)) ?></td>
              <td><?php if ((string) ($v['prev'] ?? '') !== ''): ?><a href="<?= rv_h(tkp_url(['est' => $est['id'], 'diff' => $vid])) ?>"><?= rv_h(tkp_diff_text(is_array($v['diff'] ?? null) ? $v['diff'] : null) ?: 'Изменения') ?></a><span class="kb-sub">против <?= rv_h((string) $v['prev']) ?></span><?php else: ?><span class="kb-muted">первая версия</span><?php endif; ?></td>
              <td class="is-actions">
                <?php if ($isManager): ?>
                <form method="post" action="tkp_customer.php" class="kb-inline-form" onsubmit="return confirm('Удалить версию <?= rv_h($vid) ?>? Привязка блоков останется.')">
                  <input type="hidden" name="csrf" value="<?= rv_h($csrf) ?>"><input type="hidden" name="action" value="delete">
                  <input type="hidden" name="est" value="<?= rv_h((string) $est['id']) ?>"><input type="hidden" name="ver" value="<?= rv_h($vid) ?>">
                  <button type="submit" class="kb-btn kb-btn--sm kb-btn--ghost">Удалить</button>
                </form>
                <?php endif; ?>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
        </div>
        <div class="kb-card__foot"><span>«В договоре» — <?= $contract === null ? '—' : ($contract['draft'] ? 'согласованной версии нет, сверка идёт по последней (' . rv_h((string) $contract['id']) . ')' : 'версия ' . rv_h((string) $contract['id'])) ?></span><span class="kb-right">Новая выгрузка той же сметы — кнопкой «Загрузить версию»</span></div>
      </section>

      <section class="kb-card">
        <div class="kb-card__head"><h2 class="kb-card__title">Блоки ТКП и сметы 1С</h2></div>
        <div class="kb-table-wrap">
        <table class="kb-table">
          <thead><tr><th>Блок</th><th>Сметы 1С</th><th class="is-num">Работ</th><th class="is-num" title="объём больше «в договоре» или «в смету»">Объём сверх</th><th class="is-num" title="работы ТКП с объёмом, которых нет в РВ">Нет в РВ</th><th class="is-num" title="работы РВ, которых нет в ТКП блока">Нет в ТКП</th><th class="is-actions"><span class="kb-sr">Действия</span></th></tr></thead>
          <tbody>
          <?php foreach ((array) ($est['blocks'] ?? []) as $uid => $name): $uid = (string) $uid; $bound = tkp_block_smetas($est, $uid); $cmp = $bound ? tkp_compare($est, $uid, $registry) : null; ?>
            <tr>
              <td><a href="<?= rv_h(tkp_url(['est' => $est['id'], 'blk' => $uid])) ?>"><?= rv_h((string) $name) ?></a></td>
              <td><?php if ($bound): ?><?php foreach ($bound as $lrvId): ?><div><?= tkp_smeta_label($registry[$lrvId] ?? null, $lrvId) ?></div><?php endforeach; ?><?php else: ?><span class="kb-muted">не привязан</span><?php endif; ?></td>
              <td class="is-num"><?= $cmp ? (int) $cmp['totals']['works'] : '' ?></td>
              <td class="is-num"><?= $cmp && $cmp['totals']['over'] ? '<span class="kb-badge kb-badge--danger">' . (int) $cmp['totals']['over'] . '</span>' : '' ?></td>
              <td class="is-num"><?= $cmp && $cmp['totals']['no_rv'] ? '<span class="kb-badge kb-badge--warning">' . (int) $cmp['totals']['no_rv'] . '</span>' : '' ?></td>
              <td class="is-num"><?= $cmp && $cmp['totals']['no_tkp'] ? '<span class="kb-badge kb-badge--warning">' . (int) $cmp['totals']['no_tkp'] . '</span>' : '' ?></td>
              <td class="is-actions"><a class="kb-btn kb-btn--sm kb-btn--ghost" href="<?= rv_h(tkp_url(['est' => $est['id'], 'blk' => $uid])) ?>"><?= $bound ? 'Сверка' : 'Привязать' ?></a></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
        </div>
      </section>

    <?php else: ?>
      <?php
        $bound = tkp_block_smetas($est, $blk);
        $cands = tkp_candidates($est, $blk, $registryRows);
        $candIds = array_map(static fn(array $c): string => (string) $c['row']['id'], $cands);
        $cmp = tkp_compare($est, $blk, $registry);
        $rowsShown = array_values(array_filter($cmp['rows'], static function (array $r) use ($show): bool {
            $f = $r['flags'];
            return $show === 'all' || ($show === 'dev' && ($f['over_contract'] || $f['over_smeta'] || $f['unit_diff']))
                || ($show === 'no_rv' && $f['no_rv']) || ($show === 'no_tkp' && $f['no_tkp']);
        }));
        $tot = $cmp['totals'];
      ?>
      <details class="kb-card kb-fold"<?= $bound ? '' : ' open' ?>>
        <summary class="kb-card__head">Привязка: <?= rv_h($blockName) ?> → <?= $bound ? 'смет 1С: ' . count($bound) : 'не привязан' ?></summary>
        <form method="post" action="tkp_customer.php">
          <input type="hidden" name="csrf" value="<?= rv_h($csrf) ?>"><input type="hidden" name="action" value="bind">
          <input type="hidden" name="est" value="<?= rv_h((string) $est['id']) ?>"><input type="hidden" name="blk" value="<?= rv_h($blk) ?>">
          <?php if ((string) ($est['object'] ?? '') === ''): ?><div class="kb-card__foot" style="border-top:0">Объект ТКП не выбран — показаны все сметы. Выберите объект на странице версий, и список сократится до смет объекта.</div><?php endif; ?>
          <?php foreach ($bound as $lrvId): if (in_array($lrvId, $candIds, true)) { continue; } ?>
            <label class="tkp-cand"><input type="checkbox" name="smetas[]" value="<?= rv_h($lrvId) ?>" checked><span><?= tkp_smeta_label($registry[$lrvId] ?? null, $lrvId) ?><span class="kb-sub">вне объекта ТКП</span></span></label>
          <?php endforeach; ?>
          <?php foreach ($cands as $c): $row = $c['row']; $id = (string) $row['id']; ?>
            <label class="tkp-cand">
              <input type="checkbox" name="smetas[]" value="<?= rv_h($id) ?>"<?= in_array($id, $bound, true) ? ' checked' : '' ?>>
              <span><?= tkp_smeta_label($row, $id) ?>
                <span class="kb-sub"><?= $c['building'] ? '<b>тот же корпус/секция</b> · ' : '' ?><?= $c['works'] ? 'кодов работ блока в РВ: ' . (int) $c['overlap'] . ' из ' . (int) $c['works'] . ' работ РВ' : 'РВ ещё нет' ?></span>
              </span>
            </label>
          <?php endforeach; ?>
          <?php if (!$cands && !$bound): ?><div class="kb-empty"><div class="kb-empty__title">Смет для привязки нет</div><div>Сметы появляются, когда 1С присылает ЛРВ на сайт (страница «РВ по ЛРВ»).</div></div><?php endif; ?>
          <div class="kb-card__foot"><button type="submit" class="kb-btn kb-btn--sm kb-btn--primary">Сохранить привязку</button><span class="kb-right">Привязка переходит на следующие версии ТКП сама</span></div>
        </form>
      </details>

      <section class="kb-card">
        <div class="kb-card__head">
          <h2 class="kb-card__title">Работы: три объёма и цены</h2>
          <div class="kb-card__actions">
            <span class="kb-muted">в договоре: <?= $cmp['contract'] === null ? '—' : ($cmp['contract']['draft'] ? 'предварительное, версия ' . rv_h((string) $cmp['contract']['id']) : 'версия ' . rv_h((string) $cmp['contract']['id'])) ?></span>
            <form method="get" action="tkp_customer.php" class="kb-inline-form">
              <input type="hidden" name="est" value="<?= rv_h((string) $est['id']) ?>">
              <select class="kb-select kb-select--sm" name="blk" aria-label="Другой блок ТКП" onchange="this.form.submit()">
                <?php foreach ((array) ($est['blocks'] ?? []) as $uid => $name): ?><option value="<?= rv_h((string) $uid) ?>"<?= (string) $uid === $blk ? ' selected' : '' ?>><?= rv_h((string) $name) ?><?= tkp_block_smetas($est, (string) $uid) ? '' : ' — не привязан' ?></option><?php endforeach; ?>
              </select>
            </form>
          </div>
        </div>
        <div class="tkp-filters">
          <?php foreach (['all' => 'Все · ' . count($cmp['rows']), 'dev' => 'Отклонения · ' . (int) $tot['over'], 'no_rv' => 'Нет в РВ · ' . (int) $tot['no_rv'], 'no_tkp' => 'Нет в ТКП · ' . (int) $tot['no_tkp']] as $key => $label): ?>
            <a class="kb-btn kb-btn--sm<?= $show === $key ? '' : ' kb-btn--ghost' ?>" href="<?= rv_h(tkp_url(['est' => $est['id'], 'blk' => $blk, 'show' => $key === 'all' ? '' : $key])) ?>"><?= rv_h($label) ?></a>
          <?php endforeach; ?>
        </div>
        <?php if ($cmp['no_rv']): ?><div class="kb-alert kb-alert--warning" style="margin:8px 12px">Без РВ на сайте: <?= rv_h(implode(', ', array_map(static fn(string $id): string => rv_smeta_title((array) ($registry[$id] ?? [])) ?: $id, $cmp['no_rv']))) ?> — объём по ним не считается.</div><?php endif; ?>
        <div class="kb-table-wrap">
        <table class="kb-table kb-table--dense">
          <thead><tr>
            <th>Код ИСР</th><th style="min-width:280px">Работа</th><th>Ед.</th>
            <th class="is-num" title="ТКП заказчика: «Общее кол-во» версии «в договоре»">В договоре</th>
            <th class="is-num" title="Строки ЛРВ: количество в смету × коэф. работы">В смету</th>
            <th class="is-num" title="РВ: объём работы по ЛРВ — то, что будет закуплено">Объём</th>
            <th class="is-num" title="Цена подрядчика в ТКП за единицу с НДС; под ней — предельная цена заказчика (ПСПР)">Цена ТКП, ₽</th>
            <th class="is-num" title="Цена сметной позиции 1С — приходит из 1С с фактом ЛРВ">Смета 1С, ₽</th>
            <th class="is-num" title="(объём − в договоре) × цена ТКП">Δ, ₽</th>
          </tr></thead>
          <tbody>
          <?php foreach ($rowsShown as $r): $f = $r['flags']; $cls = $f['over_contract'] || $f['over_smeta'] ? 'is-over' : ($f['no_rv'] ? 'is-norv' : ($f['no_tkp'] ? 'is-notkp' : '')); ?>
            <?php $delta = $r['volume'] !== null && $r['contract'] !== null && $r['price'] !== null ? ($r['volume'] - $r['contract']) * $r['price'] : null; ?>
            <tr<?= $cls !== '' ? ' class="' . $cls . '"' : '' ?>>
              <td class="tkp-code"><?= rv_h($r['code']) ?></td>
              <td><?= rv_h($r['name']) ?><?php if ($r['nums']): ?><span class="kb-sub">п/п <?= rv_h(implode(', ', array_slice($r['nums'], 0, 3))) ?><?= count($r['nums']) > 3 ? '…' : '' ?></span><?php endif; ?>
                <div class="tkp-flags">
                <?php if ($f['over_contract']): ?><span class="kb-badge kb-badge--danger" title="объём больше, чем в договоре">&gt; договора</span><?php endif; ?>
                <?php if ($f['over_smeta']): ?><span class="kb-badge kb-badge--danger" title="объём больше, чем в смету">&gt; в смету</span><?php endif; ?>
                <?php if ($f['no_rv']): ?><span class="kb-badge kb-badge--warning" title="в ТКП есть объём, в РВ привязанных смет работы нет">нет в РВ</span><?php endif; ?>
                <?php if ($f['no_tkp']): ?><span class="kb-badge kb-badge--warning" title="в РВ работа есть, в ТКП блока — нет">нет в ТКП</span><?php endif; ?>
                <?php if ($f['unit_diff']): ?><span class="kb-badge kb-badge--info" title="единицы ТКП и РВ разные — объёмы не сравниваются напрямую">ед. изм.</span><?php endif; ?>
                <?php if ($f['draft']): ?><span class="kb-badge kb-badge--neutral" title="РВ ещё не согласована — объём из черновика агента">черновик РВ</span><?php endif; ?>
</div></td>
              <td><?= rv_h($r['unit']) ?><?= $f['unit_diff'] ? '<span class="kb-sub">в РВ: ' . rv_h($r['unit_rv']) . '</span>' : '' ?></td>
              <td class="tkp-num"><?= rv_h(tkp_num($r['contract'], 3)) ?></td>
              <td class="tkp-num"<?= $r['qty_customer_1c'] !== null ? ' title="по смете заказчика в 1С: ' . rv_h(tkp_num($r['qty_customer_1c'], 3)) . '"' : '' ?>><?= rv_h(tkp_num($r['smeta'], 3)) ?></td>
              <td class="tkp-num"><b><?= rv_h(tkp_num($r['volume'], 3)) ?></b></td>
              <td class="tkp-num"><?= rv_h(tkp_num($r['price'], 2)) ?><?php if ($r['ref_price'] !== null && $r['ref_price'] > 0): ?><span class="kb-sub<?= $r['price'] !== null && $r['price'] > $r['ref_price'] + 0.005 ? ' tkp-bad' : '' ?>" title="ПСПР — предельная цена заказчика">ПСПР <?= rv_h(tkp_num($r['ref_price'], 2)) ?></span><?php endif; ?></td>
              <td class="tkp-num"><?= rv_h(tkp_num($r['price_1c'], 2)) ?></td>
              <td class="tkp-num"><?= $delta !== null && abs($delta) >= 0.5 ? rv_h(tkp_money($delta)) : '' ?></td>
            </tr>
          <?php endforeach; ?>
          <?php if (!$rowsShown): ?>
            <tr><td colspan="9"><div class="kb-empty"><div class="kb-empty__title"><?= $cmp['rows'] ? 'В этом фильтре строк нет' : ($bound ? 'Работ нет ни в ТКП, ни в РВ' : 'Привяжите блок к сметам 1С') ?></div></div></td></tr>
          <?php endif; ?>
          </tbody>
        </table>
        </div>
        <div class="kb-card__foot">
          <span>В договоре: <b><?= rv_h(tkp_money($tot['contract_cost'])) ?> ₽</b> · объём по цене ТКП: <b><?= rv_h(tkp_money($tot['volume_cost'])) ?> ₽</b> · ПСПР: <?= rv_h(tkp_money($tot['ref_cost'])) ?> ₽<?= $tot['over_cost'] > 0.5 ? ' · сверх договора: <b>' . rv_h(tkp_money($tot['over_cost'])) . ' ₽</b>' : '' ?></span>
          <span class="kb-right">Работы сравниваются по коду ИСР; материалы — этап 3</span>
        </div>
      </section>
    <?php endif; ?>
    </div>
  </div>

  </div>
</div>
</body>
</html>
