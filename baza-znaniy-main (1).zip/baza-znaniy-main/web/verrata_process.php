<?php
declare(strict_types=1);

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require_once __DIR__ . '/lib.php';

function verrata_fail(string $message, int $code = 400): never {
    fail($message, $code, 'verrata.php');
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    verrata_fail('Ожидался POST-запрос.', 405);
}

// Запрос больше post_max_size: PHP молча выбрасывает И файлы, И поля
// формы. Без этой проверки инженер увидел бы «Не выбран режим
// обработки», хотя выбирал, — и искал бы ошибку не там.
$contentLength = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);
if (!$_POST && !$_FILES && $contentLength > 0) {
    $postLimit = ini_bytes('post_max_size');
    verrata_fail('Файлы вместе весят ' . megabytes($contentLength) . ' МБ — больше, чем сервер '
        . 'принимает за одну загрузку'
        . ($postLimit > 0 ? ' (' . megabytes($postLimit) . ' МБ)' : '')
        . '. Загрузите меньше файлов за раз или попросите администратора поднять '
        . 'post_max_size в настройках PHP сайта.', 413);
}

/**
 * Фаза 2: инженер подтвердил роли на карточке — запускаем разбор.
 *
 * Роли приходят из формы как имя файла → номер изменения (0 — исходная).
 * Проверку однозначности делает сам Python (revisions.apply_roles): роль
 * не может достаться двум файлам, и нельзя подтвердить роль файла, которого
 * нет в задаче. Перепутанные роли дают отчёт, по которому закупят не то,
 * поэтому решение инженера проверяется, а не принимается на слово.
 */
function verrata_launch_confirmed(string $token): never {
    if (!preg_match('/^[a-f0-9]{16}$/', $token)) {
        verrata_fail('Неверный номер задачи.');
    }
    $jobPath = VERRATA_OUTPUT_DIR . '/' . $token . '_job.json';
    $job = is_file($jobPath)
        ? json_decode((string) file_get_contents($jobPath), true)
        : null;
    if (!is_array($job) || empty($job['paths'])) {
        verrata_fail('Задача не найдена или устарела — загрузите файлы заново.');
    }
    // Чужую задачу подтвердить нельзя: отчёты живут по токену, и токен
    // можно подобрать перебором, а имя пользователя в карточке есть.
    if ((string) ($job['user'] ?? '') !== (string) ($_SESSION['kb_user'] ?? '')) {
        verrata_fail('Эта задача принадлежит другому пользователю.', 403);
    }
    $mode = (string) ($job['mode'] ?? '');
    if (!in_array($mode, VERRATA_MODES_ENABLED, true)) {
        verrata_fail('Режим обработки этой задачи отключён.');
    }

    $roles = $_POST['role'] ?? [];
    if (!is_array($roles)) {
        verrata_fail('Роли редакций не переданы.');
    }
    $paths = array_values(array_filter((array) $job['paths'], 'is_file'));
    if (!$paths) {
        verrata_fail('Загруженные файлы уже удалены — загрузите их заново.');
    }

    $statusPath = VERRATA_OUTPUT_DIR . '/' . $token . '_status.json';
    $pdfPath = VERRATA_OUTPUT_DIR . '/' . $token . '_verrata.pdf';
    $xlsxPath = VERRATA_OUTPUT_DIR . '/' . $token . '_verrata.xlsx';
    $logFile = VERRATA_OUTPUT_DIR . '/verrata_errors.log';

    $cmd = [escapeshellarg(PYTHON_BIN), '-u', escapeshellarg(VERRATA_RUN_SCRIPT),
            '--mode', escapeshellarg($mode),
            '--tmp-dir', escapeshellarg((string) $job['job_dir']),
            '--status-file', escapeshellarg($statusPath)];
    // Раздел проекта (ОВ, ВК, ЭОМ, СС): по нему агент берёт свой промт и
    // эталон отчёта (program-b/system_prompts.py). Значение уже сверено
    // со списком VERRATA_SECTIONS при загрузке.
    $section = (string) ($job['section'] ?? '');
    if ($section !== '' && in_array($section, VERRATA_SECTIONS, true)) {
        $cmd[] = '--section';
        $cmd[] = escapeshellarg($section);
    }
    if ($mode !== 'spec') {
        $cmd[] = '--output';
        $cmd[] = escapeshellarg($pdfPath);
    }
    if ($mode !== 'graphics') {
        $cmd[] = '--spec-xlsx';
        $cmd[] = escapeshellarg($xlsxPath);
    }
    foreach ($paths as $path) {
        $name = basename($path);
        if (!array_key_exists($name, $roles)) {
            continue;
        }
        $number = (string) $roles[$name];
        if (!preg_match('/^\d{1,2}$/', $number)) {
            verrata_fail('Номер изменения для файла «' . $name . '» задан неверно.');
        }
        $cmd[] = '--role';
        $cmd[] = escapeshellarg($name . '=' . $number);
    }
    // Наряд-заказы идут отдельным списком: их материалы становятся
    // колонками рядом с колонками редакций (см. program-b/compare.py).
    $nzPaths = array_values(array_filter((array) ($job['nz_paths'] ?? []), 'is_file'));
    if ($nzPaths && $mode !== 'graphics') {
        $cmd[] = '--nz';
        foreach ($nzPaths as $path) {
            $cmd[] = escapeshellarg($path);
        }
    }
    // Черновой текст пишет модель поверх посчитанных фактов, и он ложится
    // в PDF (в Excel его нет) — поэтому только для режимов с чертежами.
    // Файл с ключом читает сам Python; здесь передаётся ПУТЬ, не секрет.
    if ($mode !== 'spec' && VERRATA_NARRATIVE !== '' && is_file(ANTHROPIC_CREDENTIALS_FILE)) {
        $cmd[] = '--narrative';
        $cmd[] = escapeshellarg(VERRATA_NARRATIVE);
        $cmd[] = '--narrative-credentials';
        $cmd[] = escapeshellarg(ANTHROPIC_CREDENTIALS_FILE);
    }
    // "--" закрывает список --nz: дальше идут пути редакций.
    $cmd[] = '--';
    foreach ($paths as $path) {
        $cmd[] = escapeshellarg($path);
    }

    $started = time();
    file_put_contents($statusPath, json_encode([
        'state' => 'running',
        'mode' => $mode,
        'stage' => 'задача поставлена в работу…',
        'started' => $started,
        'updated' => $started,
        'launched' => false,
    ], JSON_UNESCAPED_UNICODE));

    exec('nohup ' . implode(' ', $cmd) . ' >> ' . escapeshellarg($logFile) . ' 2>&1 &');
    header('Location: verrata_status.php?token=' . urlencode($token));
    exit;
}

// ── Фаза 2: подтверждение ролей ──
// Инженер подтвердил карточку «Что я нашёл» — запускаем разбор с его
// ролями. Файлы уже лежат в папке задачи с фазы 1, заново их не грузят.
if (isset($_POST['confirm_token'])) {
    verrata_launch_confirmed((string) $_POST['confirm_token']);
}

$mode = (string) ($_POST['mode'] ?? '');
if (!array_key_exists($mode, VERRATA_MODES)) {
    verrata_fail('Не выбран режим обработки.');
}
// Отключённую кнопку браузер не отправит, но форму можно отправить и в
// обход страницы — а обработка в отключённом режиме обрывается по лимитам
// хостинга и уносит с собой уже посчитанный Excel. Проверка режима здесь,
// а не только в разметке.
if (!in_array($mode, VERRATA_MODES_ENABLED, true)) {
    verrata_fail('Режим «' . VERRATA_MODES[$mode] . '» временно отключён. '
        . 'Пока доступно только сравнение спецификаций — кнопка «'
        . VERRATA_MODES['spec'] . '».');
}

$section = (string) ($_POST['section'] ?? '');
if (!in_array($section, VERRATA_SECTIONS, true)) {
    verrata_fail('Не выбран раздел проекта.');
}

/**
 * Проверенные .pdf из одного поля формы. Пустая загрузка выглядит
 * по-разному: браузер может не прислать поле вовсе, а может прислать с
 * кодом UPLOAD_ERR_NO_FILE — для пользователя это одно и то же.
 */
function verrata_collect_uploads(string $field): array {
    $uploads = $_FILES[$field] ?? null;
    if (!is_array($uploads) || !isset($uploads['name']) || !is_array($uploads['name'])) {
        return [];
    }
    $files = [];
    foreach ($uploads['name'] as $i => $originalName) {
        $error = (int) ($uploads['error'][$i] ?? UPLOAD_ERR_NO_FILE);
        if ($error === UPLOAD_ERR_NO_FILE) {
            continue;
        }
        if ($error === UPLOAD_ERR_INI_SIZE || $error === UPLOAD_ERR_FORM_SIZE) {
            verrata_fail('Файл «' . (string) $originalName . '» больше, чем сервер принимает '
                . 'одним файлом (' . megabytes(verrata_file_limit()) . ' МБ).', 413);
        }
        if ($error !== UPLOAD_ERR_OK) {
            verrata_fail('Ошибка загрузки файла «' . (string) $originalName . '» (код ' . $error . ').');
        }
        if ((int) ($uploads['size'][$i] ?? 0) > verrata_file_limit()) {
            verrata_fail('Файл «' . (string) $originalName . '» больше допустимого размера ('
                . megabytes(verrata_file_limit()) . ' МБ).', 413);
        }
        if (strtolower(pathinfo((string) $originalName, PATHINFO_EXTENSION)) !== 'pdf') {
            verrata_fail('Допустимы только файлы .pdf — «' . (string) $originalName . '» не подходит.');
        }
        $files[] = ['name' => (string) $originalName, 'tmp' => (string) ($uploads['tmp_name'][$i] ?? '')];
    }
    return $files;
}

$files = verrata_collect_uploads('revisions');
// Наряд-заказы необязательны: при их отсутствии сравниваются только
// редакции, как и раньше.
$nzFiles = verrata_collect_uploads('nz');

if (!$files) {
    verrata_fail('Файлы редакций не выбраны.');
}
// Одной редакции хватает, если загружены наряды: сравнивать есть с чем —
// проект против дополнительных объёмов (см. program-b/compare.py).
$minFiles = $nzFiles ? 1 : VERRATA_MIN_FILES;
if (count($files) < $minFiles) {
    verrata_fail('Нужно загрузить хотя бы ' . VERRATA_MIN_FILES
        . ' редакции: исходную и пакет изменений. Одной редакции достаточно, '
        . 'только если приложены наряд-заказы.');
}
if (count($nzFiles) > VERRATA_MAX_NZ) {
    verrata_fail('За один раз обрабатывается не больше ' . VERRATA_MAX_NZ
        . ' наряд-заказов, выбрано ' . count($nzFiles) . '.');
}
if (count($files) > VERRATA_MAX_FILES) {
    verrata_fail('За один раз сравниваются не больше ' . VERRATA_MAX_FILES
        . ' редакций, выбрано ' . count($files) . '.');
}

$token = bin2hex(random_bytes(8));
$jobDir = VERRATA_UPLOAD_DIR . '/' . $token;
if (!is_dir(VERRATA_UPLOAD_DIR) && !@mkdir(VERRATA_UPLOAD_DIR, 0775, true)) {
    verrata_fail('Папка для загрузок недоступна на сервере.', 500);
}
if (!@mkdir($jobDir, 0775, true)) {
    verrata_fail('Не удалось подготовить папку для этой задачи.', 500);
}
if (!is_dir(VERRATA_OUTPUT_DIR) && !@mkdir(VERRATA_OUTPUT_DIR, 0775, true)) {
    verrata_fail('Папка для отчётов недоступна на сервере.', 500);
}

// Имя файла сохраняем: порядок редакций определяется именно по нему
// (см. program-b/revisions.py). Чистим только то, что опасно для shell и
// файловой системы, а пометку «изм.N» и обозначение комплекта — нет.
function verrata_save_uploads(array $files, string $dir): array {
    $paths = [];
    foreach ($files as $i => $file) {
        $safeName = sanitize_display_base(pathinfo($file['name'], PATHINFO_FILENAME));
        $target = $dir . '/' . $safeName . '.pdf';
        if (is_file($target)) {
            $target = $dir . '/' . $safeName . '_' . $i . '.pdf';
        }
        if (!move_uploaded_file($file['tmp'], $target)) {
            verrata_fail('Не удалось сохранить загруженный файл «' . $file['name'] . '».', 500);
        }
        $paths[] = $target;
    }
    return $paths;
}

$savedPaths = verrata_save_uploads($files, $jobDir);
$savedNames = array_map('basename', $savedPaths);
// Наряды кладём в отдельную папку: имена у них свои и с именами редакций
// пересекаться не должны (порядок редакций определяется по имени файла).
$nzDir = $jobDir . '/nz';
$nzPaths = [];
if ($nzFiles) {
    if (!@mkdir($nzDir, 0775, true)) {
        verrata_fail('Не удалось подготовить папку для наряд-заказов.', 500);
    }
    $nzPaths = verrata_save_uploads($nzFiles, $nzDir);
}

$statusPath = VERRATA_OUTPUT_DIR . '/' . $token . '_status.json';
$cardPath = VERRATA_OUTPUT_DIR . '/' . $token . '_card.json';
$pdfPath = VERRATA_OUTPUT_DIR . '/' . $token . '_verrata.pdf';
$xlsxPath = VERRATA_OUTPUT_DIR . '/' . $token . '_verrata.xlsx';
$logFile = VERRATA_OUTPUT_DIR . '/verrata_errors.log';

// Карточка задачи для реестра сравнений: кто, что и когда сравнивал.
// Сами отчёты живут VERRATA_KEEP_DAYS дней, карточка — столько же.
$job = [
    'token' => $token,
    'user' => (string) ($_SESSION['kb_user'] ?? ''),
    'section' => $section,
    'mode' => $mode,
    'files' => $savedNames,
    'nz' => array_map('basename', $nzPaths),
    // Пути нужны фазе 2: после подтверждения ролей запускается разбор уже
    // лежащих файлов, заново их никто не грузит.
    'paths' => $savedPaths,
    'nz_paths' => $nzPaths,
    'job_dir' => $jobDir,
    'created' => time(),
];
file_put_contents(VERRATA_OUTPUT_DIR . '/' . $token . '_job.json',
    json_encode($job, JSON_UNESCAPED_UNICODE));

// ── Фаза 1: инвентаризация ──
// Разбор не начинается молча: сначала собирается карточка «Что я нашёл»
// (какие файлы, какая марка в штампе, где листы спецификации, какие есть
// разрешения), и инженер подтверждает роли редакций. Это единственная
// точка human-in-the-loop во всём конвейере: роль берётся из имени файла,
// а имя врёт — пакеты пересылают почтой, браузер дописывает «(1)».
// -u: без буферизации вывода. На Python 3.8 stderr, перенаправленный в
// файл, буферизуется целиком — строки о ходе работы копятся в памяти и
// попадают в лог пачкой, уже после того как они были нужны.
$cmd = [escapeshellarg(PYTHON_BIN), '-u', escapeshellarg(VERRATA_INVENTORY_SCRIPT),
        '--status-file', escapeshellarg($statusPath),
        '--card-file', escapeshellarg($cardPath)];
if ($nzPaths) {
    $cmd[] = '--nz';
    foreach ($nzPaths as $path) {
        $cmd[] = escapeshellarg($path);
    }
}
$cmd[] = '--';
foreach ($savedPaths as $path) {
    $cmd[] = escapeshellarg($path);
}

// Статус пишем ДО запуска процесса, а не доверяем это самому процессу:
// иначе отсутствие файла статуса нельзя отличить от «процесс умер, не
// успев ничего записать» — и страница ожидания крутится вечно, показывая
// работу там, где её нет. Фоновый процесс этот файл сразу перепишет
// своим.
$started = time();
file_put_contents($statusPath, json_encode([
    'state' => 'inventory',
    'mode' => $mode,
    'stage' => 'читаю файлы…',
    'started' => $started,
    'updated' => $started,
    // Признак «писал PHP, а не сам процесс»: фоновый процесс пишет свой
    // статус заново и этот ключ не повторяет. Пока ключ на месте, значит
    // процесс ещё не подал голос (см. verrata_status.php).
    'launched' => false,
], JSON_UNESCAPED_UNICODE));

exec('nohup ' . implode(' ', $cmd) . ' >> ' . escapeshellarg($logFile) . ' 2>&1 &');

header('Location: verrata_status.php?token=' . urlencode($token));
exit;
