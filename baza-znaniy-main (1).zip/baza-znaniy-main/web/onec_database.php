<?php
declare(strict_types=1);

// Просмотр всей номенклатуры 1С, загруженной на сайт — только для
// admin/mainadmin (см. admin_guard.php). ЧИСТО ПРОСМОТРОВАЯ страница: не
// изменяет и не пишет ничего (кроме своего JSON-кэша, см. ниже) — и
// показывает ИМЕННО DB_FILE, ту боевую базу, которую реально читает
// сопоставление в VentSpec (program-a/vent_processor.py), а не
// ONEC_NOMENCLATURE_FILE (тот отдельный снимок для проверки дублей при
// приёме от 1С — держится в синхроне по кодам, но физически другой
// файл). На работу сопоставления это не влияет: та логика продолжает
// читать DB_FILE напрямую, про существование этой страницы не знает.
//
// PHP не умеет читать .xlsx сам — DB_FILE_DUMP_CACHE пересчитывается
// через WEB_DB_FILE_DUMP_SCRIPT (common/web_db_file_dump.py), который
// читает DB_FILE ТОЙ ЖЕ функцией, что и сама матчинг-логика
// (_load_names_from_file), только когда DB_FILE новее уже посчитанного
// кэша — не на каждый запрос, файл может быть десятки тысяч строк.
//
// Матчер строит индекс ТОЛЬКО по наименованиям (колонка B) — код
// (колонка A) в сопоставлении не участвует вообще, здесь показан просто
// для ориентира. Структурирование по категориям — начато: воздуховоды
// (категория 2) сгруппированы по толщине металла, внутри группы
// упорядочены по сечению и длине (см. build_duct_tree ниже). Остальные
// категории — пока без структуры, обсуждается отдельно.

require __DIR__ . '/admin_guard.php';
require __DIR__ . '/config.php';

const PER_PAGE = 100;
// Должно совпадать с SCHEMA_VERSION в common/web_db_file_dump.py — если
// кэш посчитан более старой версией схемы (нет нужных полей), его нужно
// пересчитать независимо от времени изменения DB_FILE.
const EXPECTED_DUMP_SCHEMA_VERSION = 3;
// Защита от слишком длинной страницы, если в одной группе толщины
// окажутся тысячи позиций — пока не разбито на страницы, просто не
// рендерим больше разумного.
const MAX_ITEMS_PER_THICKNESS_GROUP = 300;

function refresh_db_dump_if_stale(): ?string {
    if (!is_file(DB_FILE)) {
        return 'Файл базы (DB_FILE) ещё не положен на сервер.';
    }
    $cacheFresh = is_file(DB_FILE_DUMP_CACHE) && filemtime(DB_FILE_DUMP_CACHE) >= filemtime(DB_FILE);
    if ($cacheFresh && dump_cache_schema_is_current()) {
        return null; // кэш свежий и нужной версии схемы — пересчитывать не нужно
    }
    $cmd = implode(' ', [
        escapeshellarg(PYTHON_BIN),
        escapeshellarg(WEB_DB_FILE_DUMP_SCRIPT),
        '--db', escapeshellarg(DB_FILE),
        '--out', escapeshellarg(DB_FILE_DUMP_CACHE),
    ]) . ' 2>&1';
    $output = shell_exec($cmd);
    if ($output === null || trim($output) === '') {
        return 'Не удалось прочитать базу: команда не выполнилась (shell_exec недоступен на '
            . 'сервере, или путь PYTHON_BIN в config.php неверный).';
    }
    $result = json_decode($output, true);
    if (!is_array($result) || empty($result['ok'])) {
        // Показываем реальный вывод скрипта (например, traceback Python или
        // "command not found" от шелла) — страница admin-only, скрывать
        // диагностику от самого администратора смысла нет, а без неё причину
        // ошибки не понять без доступа к серверу. Хвост длинного traceback
        // обычно содержательнее начала, поэтому обрезаем С НАЧАЛА, не с конца.
        $detail = is_array($result) ? (string) ($result['error'] ?? 'неизвестная ошибка') : trim($output);
        if (mb_strlen($detail, 'UTF-8') > 2000) {
            $detail = '…' . mb_substr($detail, -2000, null, 'UTF-8');
        }
        return 'Не удалось прочитать базу: ' . $detail;
    }
    return null;
}

function dump_cache_schema_is_current(): bool {
    $raw = file_get_contents(DB_FILE_DUMP_CACHE);
    $data = $raw !== false ? json_decode($raw, true) : null;
    return is_array($data) && (int) ($data['schema_version'] ?? 0) >= EXPECTED_DUMP_SCHEMA_VERSION;
}

function load_database_items(): array {
    if (!is_file(DB_FILE_DUMP_CACHE)) {
        return [];
    }
    $raw = file_get_contents(DB_FILE_DUMP_CACHE);
    $data = $raw !== false ? json_decode($raw, true) : null;
    return is_array($data) && is_array($data['items'] ?? null) ? $data['items'] : [];
}

function load_vk_database_items(?string &$error): array {
    $path = __DIR__ . '/data/1c_vk_catalog.json';
    if (!is_file($path)) return [];
    $raw = file_get_contents($path);
    $data = $raw !== false ? json_decode($raw, true) : null;
    if (!is_array($data) || ($data['schema_version'] ?? null) !== 1 || ($data['catalog'] ?? null) !== 'vk'
        || !is_array($data['items'] ?? null) || ($data['item_count'] ?? null) !== count($data['items'])) {
        $error = 'Не удалось прочитать номенклатуру ВК. Требуется проверить файл базы.';
        return [];
    }
    return $data['items'];
}

function matches_query(array $item, string $q): bool {
    if ($q === '') {
        return true;
    }
    $needle = mb_strtolower($q, 'UTF-8');
    foreach (['Код', 'Наименование'] as $field) {
        $val = (string) ($item[$field] ?? '');
        if ($val !== '' && mb_strpos(mb_strtolower($val, 'UTF-8'), $needle) !== false) {
            return true;
        }
    }
    return false;
}

// ── Деревья категорий (воздуховоды — категория 2, отводы — категория 3 ──
// ── + "Вид" = ОТВОД): группировка по толщине металла, внутри группы — ──
// ── по сечению и длине ──────────────────────────────────────────────────

function section_key_compare(?array $a, ?array $b): int {
    $a = $a ?? [];
    $b = $b ?? [];
    $len = max(count($a), count($b));
    for ($i = 0; $i < $len; $i++) {
        // Отсутствующий (более короткая запись сечения) компонент — в
        // конец, не в начало: неполные/нераспознанные данные хуже
        // определённого размера, а не "меньше" него.
        $av = $a[$i] ?? PHP_INT_MAX;
        $bv = $b[$i] ?? PHP_INT_MAX;
        if ($av !== $bv) {
            return $av <=> $bv;
        }
    }
    return 0;
}

function compare_items_by_section_length(array $a, array $b): int {
    $cmp = section_key_compare($a['СечениеКлюч'] ?? null, $b['СечениеКлюч'] ?? null);
    if ($cmp !== 0) {
        return $cmp;
    }
    return ((int) ($a['Длина'] ?? 0)) <=> ((int) ($b['Длина'] ?? 0));
}

function thickness_label(float $thickness): string {
    if ($thickness <= 0) {
        return 'толщина не указана';
    }
    $s = rtrim(rtrim(number_format($thickness, 2, '.', ''), '0'), '.');
    return $s . ' мм';
}

/**
 * Группы толщины металла (уже отсортированные) для одной категории —
 * опционально ограниченной конкретным "Видом" внутри неё (например,
 * категория 3 "Фасонка" целиком включает отводы/переходы/тройники/...,
 * а для дерева "Отводы" нужны только позиции с Вид === "ОТВОД").
 * Каждая группа — ['label' => string, 'items' => array].
 */
function build_thickness_groups(array $allItems, int $category, ?string $kw = null): array {
    $groups = []; // ключ группы (строка) => ['thickness' => float, 'label' => string, 'items' => []]
    foreach ($allItems as $it) {
        if (!is_array($it) || (int) ($it['Категория'] ?? -1) !== $category) {
            continue;
        }
        if ($kw !== null && ($it['Вид'] ?? null) !== $kw) {
            continue;
        }
        $thickness = (float) ($it['Толщина'] ?? 0);
        $key = $thickness > 0 ? sprintf('%.3f', $thickness) : '__unknown__';
        if (!isset($groups[$key])) {
            $groups[$key] = ['thickness' => $thickness, 'label' => thickness_label($thickness), 'items' => []];
        }
        $groups[$key]['items'][] = $it;
    }
    uasort($groups, function ($a, $b) {
        $av = $a['thickness'] > 0 ? $a['thickness'] : PHP_FLOAT_MAX;
        $bv = $b['thickness'] > 0 ? $b['thickness'] : PHP_FLOAT_MAX;
        return $av <=> $bv;
    });
    foreach ($groups as &$g) {
        usort($g['items'], 'compare_items_by_section_length');
    }
    unset($g);
    return array_values($groups);
}

// Существующая база относится к вентиляции. ВК наполняется отдельно;
// экран выбора и ветка ВК не читают базу/кэш вентиляции.
$catalogParam = $_GET['catalog'] ?? '';
$catalog = is_string($catalogParam) && in_array($catalogParam, ['ventilation', 'vk'], true)
    ? $catalogParam : '';
$catalogTitle = ['ventilation' => 'Вентиляция', 'vk' => 'ВК'][$catalog] ?? '';
$dumpError = $catalog === 'ventilation' ? refresh_db_dump_if_stale() : null;
$allItems = $catalog === 'ventilation' && $dumpError === null ? load_database_items() : [];
if ($catalog === 'vk') $allItems = load_vk_database_items($dumpError);
$totalAll = count($allItems);
$ductGroups = $catalog === 'ventilation' && $dumpError === null ? build_thickness_groups($allItems, 2) : [];
$ductTotal = array_sum(array_map(fn($g) => count($g['items']), $ductGroups));

// Все виды фасонки (категория 3) — определение каждого см. common/
// parameters.py::get_strict_type (type_patterns). "Вид" дампа уже
// различает их, здесь просто для каждого строим своё дерево толщины,
// той же функцией, что и для воздуховодов выше.
const FITTING_KINDS = [
    'ОТВОД' => ['title' => 'Отводы', 'empty' => 'Отводов в базе не найдено.'],
    'ПЕРЕХОД' => ['title' => 'Переходы', 'empty' => 'Переходов в базе не найдено.'],
    'ТРОЙНИК' => ['title' => 'Тройники', 'empty' => 'Тройников в базе не найдено.'],
    'КРЕСТОВИНА' => ['title' => 'Крестовины', 'empty' => 'Крестовин в базе не найдено.'],
    'ВРЕЗКА' => ['title' => 'Врезки', 'empty' => 'Врезок в базе не найдено.'],
    'ЗАГЛУШКА' => ['title' => 'Заглушки', 'empty' => 'Заглушек в базе не найдено.'],
];

$fittingTrees = [];
foreach (FITTING_KINDS as $kw => $info) {
    $groups = $catalog === 'ventilation' && $dumpError === null ? build_thickness_groups($allItems, 3, $kw) : [];
    $fittingTrees[] = [
        'title' => $info['title'],
        'empty' => $info['empty'],
        'groups' => $groups,
        'total' => array_sum(array_map(fn($g) => count($g['items']), $groups)),
    ];
}

$q = trim((string) ($_GET['q'] ?? ''));
$filtered = $q === '' ? $allItems : array_values(array_filter($allItems, fn($it) => is_array($it) && matches_query($it, $q)));
$totalFiltered = count($filtered);

$page = max(1, (int) ($_GET['page'] ?? 1));
$totalPages = max(1, (int) ceil($totalFiltered / PER_PAGE));
$page = min($page, $totalPages);
$offset = ($page - 1) * PER_PAGE;
$pageItems = array_slice($filtered, $offset, PER_PAGE);

function page_url(int $page, string $q, string $catalog): string {
    $params = ['catalog' => $catalog, 'page' => $page];
    if ($q !== '') {
        $params['q'] = $q;
    }
    return 'onec_database.php?' . http_build_query($params);
}
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>База номенклатуры 1С<?= $catalogTitle !== '' ? ' — ' . $catalogTitle : '' ?> — База знаний</title>
<link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
<script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
</head>
<body>
<div class="shell">
  <?php require __DIR__ . '/sidebar.php'; ?>

  <div class="dashboard-main">
  <div class="page-wide">

  <?php if ($catalog === ''): ?>
  <a class="back-link" href="onec_intake.php">← К пачкам от 1С</a>
  <?php else: ?>
  <a class="back-link" href="onec_database.php">← К разделам базы</a>
  <?php endif; ?>

  <div class="card">
    <?php if ($catalog === ''): ?>
    <h1>База номенклатуры 1С</h1>
    <p class="subtitle">Выберите раздел номенклатуры.</p>
    <div style="display:flex; flex-wrap:wrap; gap:12px;">
      <a class="btn" href="onec_database.php?catalog=ventilation">Вентиляция</a>
      <a class="btn" href="onec_database.php?catalog=vk">ВК</a>
    </div>
    <?php elseif ($catalog === 'vk' && !$allItems && $dumpError === null): ?>
    <h1>Номенклатура ВК</h1>
    <p class="subtitle">Номенклатура ВК пока не добавлена.</p>
    <?php else: ?>
    <h1><?= $catalog === 'vk' ? 'Номенклатура ВК' : 'Номенклатура вентиляции' ?></h1>
    <p class="subtitle">
      <?php if ($catalog === 'vk'): ?>
      Номенклатура ВК из выгрузки 1С. Поиск по коду или наименованию.
      Коды, наименования и единицы измерения сохранены из исходного файла.
      <?php else: ?>
      Номенклатура для сравнения спецификаций вентиляции с 1С.
      Позиции доступны по группам и через поиск по коду или наименованию.
      Лишние пробелы в наименованиях можно исправить на
      <a href="onec_whitespace_cleanup.php">отдельной странице</a>, дополнительная проверка на
      дубли внутри самой базы — на <a href="onec_db_duplicates.php">этой</a>.
      <?php endif; ?>
    </p>

    <?php if ($dumpError !== null): ?>
    <div class="alert error" style="white-space: pre-wrap; font-family: ui-monospace, monospace; font-size: 0.85rem;"><?= htmlspecialchars($dumpError, ENT_QUOTES, 'UTF-8') ?></div>
    <?php else: ?>

    <?php if ($catalog === 'ventilation'): ?>
    <?php $categoryTrees = array_merge(
        [['title' => 'Воздуховоды', 'total' => $ductTotal, 'groups' => $ductGroups, 'empty' => 'Воздуховодов в базе не найдено.']],
        $fittingTrees
    ); ?>
    <?php foreach ($categoryTrees as $tree): ?>
    <details class="db-tree-root" style="margin-bottom: 18px;">
      <summary style="cursor:pointer; font-weight:700; padding: 8px 0;"><?= htmlspecialchars($tree['title'], ENT_QUOTES, 'UTF-8') ?> (<?= $tree['total'] ?>)</summary>
      <?php if (!$tree['groups']): ?>
      <p class="subtitle"><?= htmlspecialchars($tree['empty'], ENT_QUOTES, 'UTF-8') ?></p>
      <?php endif; ?>
      <?php foreach ($tree['groups'] as $group): $groupItems = $group['items']; $groupTotal = count($groupItems); ?>
      <details style="margin: 6px 0 6px 18px;">
        <summary style="cursor:pointer;"><?= htmlspecialchars($group['label'], ENT_QUOTES, 'UTF-8') ?> (<?= $groupTotal ?>)</summary>
        <div class="table-wrap" style="margin: 8px 0 8px 18px;">
          <table class="data-table">
            <thead>
              <tr>
                <th>Код</th>
                <th>Наименование</th>
                <th>Сечение</th>
                <th>Длина, мм</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach (array_slice($groupItems, 0, MAX_ITEMS_PER_THICKNESS_GROUP) as $it): ?>
              <tr>
                <td data-label="Код"><?= htmlspecialchars((string) ($it['Код'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                <td data-label="Наименование"><?= htmlspecialchars((string) ($it['Наименование'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                <td data-label="Сечение"><?= htmlspecialchars((string) ($it['Сечение'] ?? '—'), ENT_QUOTES, 'UTF-8') ?></td>
                <td data-label="Длина, мм"><?= (int) ($it['Длина'] ?? 0) ?: '—' ?></td>
              </tr>
              <?php endforeach; ?>
            </tbody>
          </table>
        </div>
        <?php if ($groupTotal > MAX_ITEMS_PER_THICKNESS_GROUP): ?>
        <p class="subtitle" style="margin: 0 0 0 18px;">Показаны первые <?= MAX_ITEMS_PER_THICKNESS_GROUP ?> из <?= $groupTotal ?> — используйте поиск выше, чтобы найти конкретную позицию.</p>
        <?php endif; ?>
      </details>
      <?php endforeach; ?>
    </details>
    <?php endforeach; ?>
    <?php endif; ?>

    <form method="get" action="onec_database.php" style="display:flex; gap:10px; margin-bottom:14px;">
      <input type="hidden" name="catalog" value="<?= htmlspecialchars($catalog, ENT_QUOTES, 'UTF-8') ?>">
      <input type="search" name="q" value="<?= htmlspecialchars($q, ENT_QUOTES, 'UTF-8') ?>"
             placeholder="Поиск по коду или наименованию…"
             style="flex:1; padding:10px 12px; border-radius:8px; border:1px solid var(--border); font:inherit;">
      <button type="submit" class="btn-small">Найти</button>
      <?php if ($q !== ''): ?>
      <a class="btn-small btn-outline" href="onec_database.php?catalog=<?= htmlspecialchars($catalog, ENT_QUOTES, 'UTF-8') ?>">Сбросить</a>
      <?php endif; ?>
    </form>

    <p class="subtitle">
      <?php if ($q !== ''): ?>
        Найдено: <?= $totalFiltered ?> из <?= $totalAll ?>.
      <?php else: ?>
        Всего позиций: <?= $totalAll ?>.
      <?php endif; ?>
    </p>

    <div class="table-wrap">
      <table class="data-table">
        <thead>
          <tr>
            <th>Код</th>
            <th>Наименование</th>
            <?php if ($catalog === 'vk'): ?><th>Единица измерения</th><?php endif; ?>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($pageItems as $it): if (!is_array($it)) continue; ?>
          <tr>
            <td data-label="Код"><?= htmlspecialchars((string) ($it['Код'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
            <td data-label="Наименование"><?= htmlspecialchars((string) ($it['Наименование'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
            <?php if ($catalog === 'vk'): ?>
            <td data-label="Единица измерения"><?= htmlspecialchars((string) (($it['ЕдиницаИзмерения'] ?? '') ?: '—'), ENT_QUOTES, 'UTF-8') ?></td>
            <?php endif; ?>
          </tr>
          <?php endforeach; ?>
          <?php if (!$pageItems): ?>
          <tr><td colspan="<?= $catalog === 'vk' ? 3 : 2 ?>">Ничего не найдено.</td></tr>
          <?php endif; ?>
        </tbody>
      </table>
    </div>

    <?php if ($totalPages > 1): ?>
    <div style="display:flex; align-items:center; gap:10px; margin-top:16px;">
      <?php if ($page > 1): ?>
      <a class="btn-small" href="<?= htmlspecialchars(page_url($page - 1, $q, $catalog), ENT_QUOTES, 'UTF-8') ?>">← Назад</a>
      <?php endif; ?>
      <span class="subtitle" style="margin:0;">Страница <?= $page ?> из <?= $totalPages ?></span>
      <?php if ($page < $totalPages): ?>
      <a class="btn-small" href="<?= htmlspecialchars(page_url($page + 1, $q, $catalog), ENT_QUOTES, 'UTF-8') ?>">Вперёд →</a>
      <?php endif; ?>
    </div>
    <?php endif; ?>

    <?php endif; ?>
    <?php endif; ?>
  </div>

  </div>
  </div>
</div>
</body>
</html>
