<?php
declare(strict_types=1);

/**
 * Bounded process runner for uploaded PDF pages and albums. Upload stays in PHP's
 * private temporary location for this request only, never in web/data.
 */
function cp_pdf_worker(string $file, int $page, string $mode, ?string $crop, ?string $profile = null, ?string $review = null, ?array $spec = null, ?callable $heartbeat = null): array
{
    $python = cp_python_binary();
    if (!$python || !function_exists('proc_open')) {
        return ['ok' => false, 'message' => 'PDF-обработчик не установлен на сервере.'];
    }
    $cwd = dirname(__DIR__);
    $stdin = ['pipe', 'r'];
    if ($mode === 'album') {
        $cwd .= '/common/clean_papper_album_worker';
        if (!is_file($cwd . '/modules/pdf/project_album.py')) {
            return ['ok' => false, 'message' => 'Обработчик PDF-альбомов ещё не подключён на сервере.'];
        }
        $cmd = [$python, '-B', '-m', 'modules.pdf.project_album', '--file', $file];
        if ($review !== null) {
            $cmd[] = '--review-stdin';
            $stdin = ['file', $review, 'r'];
        }
    } elseif ($mode === 'specification') {
        $script = $cwd . '/common/web_clean_papper_specification.py';
        if ($spec === null || !is_file($script)) {
            return ['ok'=>false,'message'=>'Конвертор спецификации недоступен.'];
        }
        $cmd = [$python, '-B', $script, '--file', $file, '--first', $spec['first'],
                '--last', $spec['last'], '--sha', $spec['sha'], '--action', $spec['action']];
    } else {
        $script = $cwd . '/common/web_clean_papper_pdf.py';
        if (!is_file($script)) {
            return ['ok' => false, 'message' => 'PDF-обработчик не установлен на сервере.'];
        }
        $cmd = [$python, $script, '--mode', $mode];
    }
    if ($mode !== 'diagnostic' && $mode !== 'album' && $mode !== 'specification') {
        $cmd[] = '--file';
        $cmd[] = $file;
        $cmd[] = '--page';
        $cmd[] = (string) $page;
    }
    if ($crop !== null && $crop !== '') {
        $cmd[] = '--crop';
        $cmd[] = $crop;
    }
    if ($profile !== null && $profile !== '') {
        $cmd[] = '--profile-json';
        $cmd[] = $profile;
    }
    if ($mode === 'vision') {
        $secret = cp_credentials_file();
        if (!$secret || !is_file($secret)) {
            return ['ok' => false, 'message' => 'Claude API не настроен на сервере.'];
        }
        $cmd[] = '--credentials';
        $cmd[] = $secret;
    }

    $proc = @proc_open($cmd, [
        0 => $stdin, 1 => ['pipe', 'w'], 2 => ['pipe', 'w'],
    ], $pipes, $cwd);
    if (!is_resource($proc)) {
        return ['ok' => false, 'message' => 'Не удалось запустить PDF-обработчик.'];
    }
    if (isset($pipes[0])) fclose($pipes[0]);
    stream_set_blocking($pipes[1], false);
    stream_set_blocking($pipes[2], false);
    $output = '';
    $started = microtime(true);
    $timeout = in_array($mode, ['album', 'specification'], true) ? 75 : ($mode === 'vision' ? 85 : ($mode === 'diagnostic' ? 15 : 45));
    $limit = in_array($mode, ['album', 'specification'], true) ? 8 * 1024 * 1024 : 2600000;
    $bad = false;
    $timedOut = false;
    $lastHeartbeat = 0.0;
    while (true) {
        $output .= (string) stream_get_contents($pipes[1]);
        stream_get_contents($pipes[2]); // Never expose raw stderr: may contain private paths.
        if (strlen($output) > $limit) {
            $bad = true;
            @proc_terminate($proc);
            break;
        }
        $status = proc_get_status($proc);
        if (!$status['running']) {
            break;
        }
        if ($heartbeat !== null && microtime(true) - $lastHeartbeat >= 2.0) {
            $heartbeat('running');
            $lastHeartbeat = microtime(true);
        }
        if (microtime(true) - $started >= $timeout) {
            $timedOut = true;
            @proc_terminate($proc);
            break;
        }
        usleep(100000);
    }
    $output .= (string) stream_get_contents($pipes[1]);
    stream_get_contents($pipes[2]);
    fclose($pipes[1]);
    fclose($pipes[2]);
    @proc_close($proc);
    if ($timedOut) {
        if ($mode === 'album') return ['ok' => false, 'message' => 'Разбор альбома превысил лимит времени.'];
        if ($mode === 'specification') return ['ok'=>false,'message'=>'Конвертация превысила лимит времени. Скачайте диапазон PDF и используйте обычный VentSpec.'];
        return ['ok' => false, 'message' => 'Анализ превысил лимит времени. Выберите фрагмент меньшего размера.'];
    }
    if ($bad || strlen($output) > $limit) {
        return ['ok' => false, 'message' => 'Ответ PDF-обработчика слишком большой.'];
    }
    // Preserve empty JSON objects in the downloadable album review template.
    $result = json_decode(trim($output), $mode !== 'album');
    if ($mode === 'album' && is_object($result)) $result = (array) $result;
    if (!is_array($result) || !isset($result['ok']) || !is_bool($result['ok'])) {
        return ['ok' => false, 'message' => 'Сервер не вернул корректный результат анализа.'];
    }
    // Only pass known worker errors, never arbitrary sensitive debug strings.
    if (!$result['ok'] && !in_array(($result['code'] ?? ''), ['invalid_pdf','configuration','connection','api','internal','pdf_module_missing','pdf_render_failed','invalid_album_input','album_processing_error','specification_review_required','specification_input_error','specification_output_limit'], true)) {
        return ['ok' => false, 'message' => 'Ошибка при анализе PDF.'];
    }
    if ($mode === 'diagnostic' && $result['ok']) {
        // Non-sensitive, useful upload limits for troubleshooting.
        $result['php_upload_max'] = (string) ini_get('upload_max_filesize');
        $result['php_post_max'] = (string) ini_get('post_max_size');
    }
    return $result;
}
