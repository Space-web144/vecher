<?php
declare(strict_types=1);

// ТКП заказчика ↔ РВ 1С (этапы 1–2 плана модуля ЦО, страница tkp_customer.php).
//
// Реестр: ТКП заказчика — Excel платформы заказчика (лист «ТКП»), разбирает program-c/tkp_customer.py.
// Смета заказчика (estimateId) — запись реестра, у неё версии (estimateVersionId) со статусом: предварительное,
// отправлено заказчику, согласовано (в договоре). Строки версии связаны между версиями постоянным ключом
// платформы (zeroParent_id), поэтому изменения новой версии видны сразу: объёмы, цены, новые и убранные строки.
// Привязка: блок ТКП («1. Жилое здание», «2. Жилой корпус/секция 1») → сметы 1С (ИдентификаторЛРВ сайта).
// Привязка хранится по ключу блока и переходит на следующие версии сама.
// Сравнение по блоку — по коду ИСР работы: «в договоре» (согласованная версия, пока её нет — последняя,
// с пометкой «предварительное»), «в смету» (строки ЛРВ: количество в смету × коэф. работы), «объём» (РВ — закупка);
// правило: объём не больше двух других. Цены: ПСПР заказчика, цена подрядчика в ТКП, цена сметы 1С (факт из 1С).
//
// Файлы — TKP_CUSTOMER_DIR (web/data, в репозиторий не идёт): index.json — реестр, <смета>_<версия>.json — разбор,
// <смета>_<версия>.xlsx — исходный файл, <смета>_<от>_<до>_diff.json — изменения между версиями.

require_once __DIR__ . '/rv_lib.php';
require_once __DIR__ . '/rv_onec_lib.php';

const TKP_STATUSES = [
    'draft' => 'Предварительное',
    'sent' => 'Отправлено заказчику',
    'agreed' => 'Согласовано — в договоре',
];
const TKP_DIFF_LABELS = [
    'code' => 'код ИСР', 'name' => 'наименование', 'unit' => 'ед. изм.', 'coef' => 'коэф. расхода',
    'qty_base' => 'кол-во БО', 'qty' => 'кол-во', 'ref_price_mat' => 'ПСПР мат.', 'ref_price_smr' => 'ПСПР СМР',
    'price_mat' => 'цена мат.', 'price_smr' => 'цена СМР', 'comment' => 'комментарий подрядчика',
    'isr_comment' => 'комментарий по ИСР', 'parent' => 'перенесена', 'ref_cost' => 'Σ ПСПР', 'cost' => 'Σ подрядчика',
];
const TKP_KIND_LABELS = ['block' => 'блок', 'node' => 'узел', 'work' => 'работа', 'material' => 'материал'];
const TKP_EPS = 1e-6;

function tkp_dir(): string
{
    $dir = TKP_CUSTOMER_DIR;
    if (!is_dir($dir) && !mkdir($dir, 0775, true) && !is_dir($dir)) {
        throw new RuntimeException('Нет каталога для ТКП заказчика.');
    }
    return $dir;
}

function tkp_id_valid(string $id): bool
{
    return (bool) preg_match('/^[0-9]{1,15}$/', $id);
}

function tkp_index(): array
{
    $data = is_file(TKP_CUSTOMER_DIR . '/index.json') ? rv_read_json(TKP_CUSTOMER_DIR . '/index.json') : null;
    $data = is_array($data) ? $data : [];
    $data['estimates'] = is_array($data['estimates'] ?? null) ? $data['estimates'] : [];
    return $data;
}

/** $change(array $index): ?array — null: писать нечего. */
function tkp_index_update(callable $change): bool
{
    return rv_data_update(tkp_dir() . '/index.json', static function (array $raw) use ($change): ?array {
        $raw['estimates'] = is_array($raw['estimates'] ?? null) ? $raw['estimates'] : [];
        return $change($raw);
    });
}

function tkp_estimate(string $estId): ?array
{
    $est = tkp_index()['estimates'][$estId] ?? null;
    return is_array($est) ? $est : null;
}

function tkp_version_path(string $estId, string $verId, string $suffix = '.json'): string
{
    return TKP_CUSTOMER_DIR . '/' . $estId . '_' . $verId . $suffix;
}

/** Разобранная версия ТКП (rows, totals, …) — кэш на запрос. */
function tkp_version(string $estId, string $verId): ?array
{
    static $cache = [];
    $key = $estId . '_' . $verId;
    if (!array_key_exists($key, $cache)) {
        $cache[$key] = tkp_id_valid($estId) && tkp_id_valid($verId) ? rv_read_json(tkp_version_path($estId, $verId)) : null;
    }
    return $cache[$key];
}

/** Версии сметы заказчика, новые первыми. */
function tkp_versions(array $est): array
{
    $list = array_values(array_filter((array) ($est['versions'] ?? []), 'is_array'));
    usort($list, static fn(array $a, array $b): int => [(int) ($b['uploaded'] ?? 0), (string) ($b['id'] ?? '')] <=> [(int) ($a['uploaded'] ?? 0), (string) ($a['id'] ?? '')]);
    return $list;
}

/** Версия «в договоре»: последняя согласованная; пока её нет — последняя загруженная ('draft' => true). */
function tkp_contract_version(array $est): ?array
{
    $versions = tkp_versions($est);
    $agreed = array_values(array_filter($versions, static fn(array $v): bool => ($v['status'] ?? '') === 'agreed'));
    if ($agreed) {
        usort($agreed, static fn(array $a, array $b): int => (int) ($b['status_at'] ?? 0) <=> (int) ($a['status_at'] ?? 0));
        return $agreed[0] + ['draft' => false];
    }
    return $versions ? $versions[0] + ['draft' => true] : null;
}

/** Выполнить program-c/tkp_customer.py; [код, данные JSON из stdout или null, текст вывода]. */
function tkp_run(array $args): array
{
    $cmd = escapeshellarg(PYTHON_BIN) . ' ' . escapeshellarg(TKP_CUSTOMER_SCRIPT);
    foreach ($args as $arg) {
        $cmd .= ' ' . escapeshellarg($arg);
    }
    $out = [];
    $code = 0;
    exec($cmd . ' 2>&1', $out, $code);
    $text = trim(implode("\n", $out));
    $data = $text !== '' && $text[0] === '{' ? json_decode($text, true) : null;
    return [$code, is_array($data) ? $data : null, $text];
}

/** Объект справочника по адресу ТКП: слова названия объекта (без «ЖК») в адресе. '' — не нашёлся. */
function tkp_guess_object(string $address): string
{
    $addr = rv_norm($address);
    $best = '';
    $bestScore = 0;
    foreach (rv_table_objects() as $object) {
        $name = (string) ($object['name'] ?? '');
        $score = 0;
        foreach (preg_split('/[^\p{L}\p{N}]+/u', rv_norm($name)) ?: [] as $word) {
            if (mb_strlen($word) >= 5 && $word !== 'строительный' && str_contains($addr, $word)) {
                $score += mb_strlen($word);
            }
        }
        if ($score > $bestScore) {
            [$best, $bestScore] = [$name, $score];
        }
    }
    return $best;
}

/**
 * Загрузить версию ТКП из Excel. Возвращает [estimateId, versionId, сообщение] или бросает RuntimeException
 * с текстом для пользователя. Изменения считаются против последней загруженной до неё версии.
 */
function tkp_upload(string $tmpFile, string $fileName, string $user): array
{
    $dir = tkp_dir();
    $work = $dir . '/upload_' . bin2hex(random_bytes(6));
    if (!move_uploaded_file($tmpFile, $work . '.xlsx') && !rename($tmpFile, $work . '.xlsx')) {
        throw new RuntimeException('Не удалось сохранить файл на сервере.');
    }
    try {
        [$code, $err, $text] = tkp_run(['parse', $work . '.xlsx', '--out', $work . '.json']);
        if ($code !== 0) {
            throw new RuntimeException($err['error'] ?? ('Разбор ТКП не удался: ' . mb_substr($text, -400)));
        }
        $parsed = rv_read_json($work . '.json');
        if (!is_array($parsed) || !tkp_id_valid((string) ($parsed['estimate_id'] ?? '')) || !tkp_id_valid((string) ($parsed['version_id'] ?? ''))) {
            throw new RuntimeException('Разбор ТКП не вернул идентификаторы сметы и версии.');
        }
        $estId = (string) $parsed['estimate_id'];
        $verId = (string) $parsed['version_id'];
        $est = tkp_estimate($estId);
        $prev = null;
        foreach ($est ? tkp_versions($est) : [] as $v) {
            if ((string) $v['id'] !== $verId && is_file(tkp_version_path($estId, (string) $v['id']))) {
                $prev = (string) $v['id'];
                break;
            }
        }
        $replaced = $est !== null && isset($est['versions'][$verId]);
        rename($work . '.json', tkp_version_path($estId, $verId));
        rename($work . '.xlsx', tkp_version_path($estId, $verId, '.xlsx'));
        foreach (glob($dir . '/' . $estId . '_*_' . $verId . '_diff.json') ?: [] as $stale) {
            @unlink($stale);
        }
        foreach (glob($dir . '/' . $estId . '_' . $verId . '_*_diff.json') ?: [] as $stale) {
            @unlink($stale);
        }
        $diffSummary = null;
        if ($prev !== null) {
            $diff = tkp_diff($estId, $prev, $verId);
            $diffSummary = $diff['summary'] ?? null;
        }
        $totals = (array) ($parsed['totals'] ?? []);
        $blocks = [];
        foreach ((array) ($parsed['rows'] ?? []) as $row) {
            if (($row['kind'] ?? '') === 'block') {
                $blocks[(string) $row['uid']] = (string) ($row['num'] ?? '') . '. ' . (string) ($row['name'] ?? '');
            }
        }
        $ok = tkp_index_update(static function (array $index) use ($estId, $verId, $parsed, $fileName, $user, $prev, $diffSummary, $totals, $blocks): array {
            $est = (array) ($index['estimates'][$estId] ?? []);
            $now = time();
            $est += ['id' => $estId, 'created' => $now, 'by' => $user, 'binding' => [], 'object' => tkp_guess_object((string) ($parsed['address'] ?? ''))];
            $est['title'] = (string) ($parsed['title'] ?? '');
            $est['address'] = (string) ($parsed['address'] ?? '');
            $est['contractor'] = (string) ($parsed['contractor'] ?? '');
            $est['blocks'] = $blocks + (array) ($est['blocks'] ?? []);
            $old = (array) (($est['versions'] ?? [])[$verId] ?? []);
            $est['versions'][$verId] = [
                'id' => $verId, 'uploaded' => $now, 'by' => $user, 'file_name' => mb_substr($fileName, 0, 200),
                'status' => (string) ($old['status'] ?? 'draft'), 'status_by' => (string) ($old['status_by'] ?? ''),
                'status_at' => (int) ($old['status_at'] ?? 0), 'totals' => $totals, 'prev' => $prev, 'diff' => $diffSummary,
            ];
            $index['estimates'][$estId] = $est;
            return $index;
        });
        if (!$ok) {
            throw new RuntimeException('Не удалось записать реестр ТКП.');
        }
        $what = sprintf('%d блоков, %d работ, %d материалов', (int) ($totals['blocks'] ?? 0), (int) ($totals['works'] ?? 0), (int) ($totals['materials'] ?? 0));
        $msg = ($replaced ? 'Версия ' . $verId . ' загружена заново' : 'Загружена версия ' . $verId) . ': ' . $what . '.';
        if ($diffSummary !== null) {
            $msg .= ' ' . tkp_diff_text($diffSummary) . ' против версии ' . $prev . '.';
        }
        return [$estId, $verId, $msg];
    } finally {
        @unlink($work . '.xlsx');
        @unlink($work . '.json');
    }
}

/** Изменения версии $to против $from (по постоянному ключу строки); кэш в файле. */
function tkp_diff(string $estId, string $from, string $to): ?array
{
    if (!tkp_id_valid($estId) || !tkp_id_valid($from) || !tkp_id_valid($to) || $from === $to) {
        return null;
    }
    $path = TKP_CUSTOMER_DIR . '/' . $estId . '_' . $from . '_' . $to . '_diff.json';
    $diff = rv_read_json($path);
    if ($diff !== null) {
        return $diff;
    }
    if (!is_file(tkp_version_path($estId, $from)) || !is_file(tkp_version_path($estId, $to))) {
        return null;
    }
    [$code] = tkp_run(['diff', tkp_version_path($estId, $from), tkp_version_path($estId, $to), '--out', $path]);
    return $code === 0 ? rv_read_json($path) : null;
}

function tkp_diff_text(?array $summary): string
{
    if (!$summary) {
        return '';
    }
    $sum = static fn(array $kinds): int => array_sum(array_map('intval', $kinds));
    $parts = [];
    if ((int) ($summary['qty_changed'] ?? 0)) {
        $parts[] = 'объём изменён у ' . (int) $summary['qty_changed'];
    }
    if ((int) ($summary['price_changed'] ?? 0)) {
        $parts[] = 'цена у ' . (int) $summary['price_changed'];
    }
    $other = (int) ($summary['changed'] ?? 0) - (int) ($summary['qty_changed'] ?? 0);
    if ($other > 0 && !(int) ($summary['price_changed'] ?? 0)) {
        $parts[] = 'другие правки у ' . $other;
    }
    if ($n = $sum((array) ($summary['added'] ?? []))) {
        $parts[] = 'новых строк ' . $n;
    }
    if ($n = $sum((array) ($summary['removed'] ?? []))) {
        $parts[] = 'убрано ' . $n;
    }
    return $parts ? 'Изменения: ' . implode(', ', $parts) : 'Изменений нет';
}

function tkp_set_status(string $estId, string $verId, string $status, string $user): bool
{
    if (!isset(TKP_STATUSES[$status])) {
        return false;
    }
    return tkp_index_update(static function (array $index) use ($estId, $verId, $status, $user): ?array {
        if (!isset($index['estimates'][$estId]['versions'][$verId])) {
            return null;
        }
        $index['estimates'][$estId]['versions'][$verId]['status'] = $status;
        $index['estimates'][$estId]['versions'][$verId]['status_by'] = $user;
        $index['estimates'][$estId]['versions'][$verId]['status_at'] = time();
        return $index;
    });
}

function tkp_delete_version(string $estId, string $verId): bool
{
    $ok = tkp_index_update(static function (array $index) use ($estId, $verId): ?array {
        if (!isset($index['estimates'][$estId]['versions'][$verId])) {
            return null;
        }
        unset($index['estimates'][$estId]['versions'][$verId]);
        if (!$index['estimates'][$estId]['versions']) {
            unset($index['estimates'][$estId]);
        }
        return $index;
    });
    if ($ok) {
        @unlink(tkp_version_path($estId, $verId));
        @unlink(tkp_version_path($estId, $verId, '.xlsx'));
        foreach (array_merge(glob(TKP_CUSTOMER_DIR . '/' . $estId . '_*_' . $verId . '_diff.json') ?: [],
                             glob(TKP_CUSTOMER_DIR . '/' . $estId . '_' . $verId . '_*_diff.json') ?: []) as $file) {
            @unlink($file);
        }
    }
    return $ok;
}

/** Привязать блок ТКП к сметам 1С (ИдентификаторЛРВ); пустой список — отвязать. */
function tkp_bind(string $estId, string $blockUid, array $lrvIds, string $user): bool
{
    $lrvIds = array_values(array_unique(array_filter(array_map(static fn($v): string => mb_substr(trim((string) $v), 0, 120), $lrvIds), 'strlen')));
    return tkp_index_update(static function (array $index) use ($estId, $blockUid, $lrvIds, $user): ?array {
        if (!isset($index['estimates'][$estId]) || $blockUid === '') {
            return null;
        }
        if ($lrvIds) {
            $index['estimates'][$estId]['binding'][$blockUid] = ['smetas' => $lrvIds, 'by' => $user, 'at' => time()];
        } else {
            unset($index['estimates'][$estId]['binding'][$blockUid]);
        }
        return $index;
    });
}

/** Объект справочника «Объекты и ответственные» у ТКП ('' — снять): по нему подсказываются сметы. */
function tkp_set_object(string $estId, string $object): bool
{
    return tkp_index_update(static function (array $index) use ($estId, $object): ?array {
        if (!isset($index['estimates'][$estId])) {
            return null;
        }
        $index['estimates'][$estId]['object'] = $object;
        return $index;
    });
}

function tkp_block_smetas(array $est, string $blockUid): array
{
    return array_values(array_map('strval', (array) (($est['binding'][$blockUid] ?? [])['smetas'] ?? [])));
}

function tkp_code_key(string $code): array
{
    return array_map(static fn(string $p) => ctype_digit($p) ? (int) $p : $p, explode('.', $code));
}

function tkp_unit_key(string $unit): string
{
    $u = mb_strtolower(trim(str_replace(['.', ' '], '', $unit)));
    return ['погм' => 'м', 'мп' => 'м', 'м.п' => 'м', 'шт' => 'шт', 'компл' => 'компл', 'комплект' => 'компл', 'кв м' => 'м2', 'м²' => 'м2', 'куб м' => 'м3', 'м³' => 'м3'][$u] ?? $u;
}

/**
 * Работы РВ задачи по коду ИСР: [код => name, unit, qty (объём), qty_smeta (в смету), in_smeta, source].
 * Согласованная РВ (пакет для 1С) — источник «approved», иначе строки формы агента — «draft».
 * «В смету» работы — объём × Σ(в смету × коэф.) / Σ(количество × коэф.) по её материалам; без данных — null.
 */
function tkp_rv_works(string $token): array
{
    static $cache = [];
    if (isset($cache[$token])) {
        return $cache[$token];
    }
    $works = [];
    $paths = rv_token_valid($token) ? rv_paths($token) : null;
    $packet = $paths ? rv_read_packed($paths['onec']) : null;
    if ($packet !== null && is_array($packet['Работы'] ?? null)) {
        foreach ($packet['Работы'] as $w) {
            if (!is_array($w) || trim((string) ($w['КодИСР'] ?? '')) === '') {
                continue;
            }
            $num = 0.0;
            $den = 0.0;
            $known = false;
            foreach ((array) ($w['Материалы'] ?? []) as $m) {
                $k = rv_onec_num($m['Коэффициент'] ?? 0);
                if (!is_array($m) || $k <= 0) {
                    continue;
                }
                $den += rv_onec_num($m['Количество'] ?? 0) * $k;
                if (array_key_exists('КоличествоВСмету', $m) || array_key_exists('КолвоВСмету', $m)) {
                    $known = true;
                    $num += rv_onec_num($m['КоличествоВСмету'] ?? $m['КолвоВСмету'] ?? 0) * $k;
                }
            }
            $qty = rv_onec_num($w['Объем'] ?? 0);
            $code = trim((string) $w['КодИСР']);
            tkp_rv_add($works, $code, (string) ($w['Наименование'] ?? ''), (string) ($w['ЕдиницаИзмерения'] ?? ''), $qty,
                $known && $den > 0 ? $qty * $num / $den : null, !empty($w['ЕстьВСмете']), 'approved');
        }
    } elseif ($paths !== null && ($form = rv_read_packed($paths['form'])) !== null) {
        $current = null;
        $acc = [];
        $flush = static function () use (&$current, &$acc, &$works): void {
            if ($current === null) {
                return;
            }
            $qty = (float) ($current['qty'] ?? 0);
            tkp_rv_add($works, (string) $current['code'], (string) ($current['name'] ?? ''), (string) ($current['unit'] ?? ''), $qty,
                $acc['known'] && $acc['den'] > 0 ? $qty * $acc['num'] / $acc['den'] : null, false, 'draft');
            $current = null;
        };
        foreach ((array) ($form['rows'] ?? []) as $row) {
            $t = (string) ($row['t'] ?? '');
            if ($t === 'work') {
                $flush();
                $current = $row;
                $acc = ['num' => 0.0, 'den' => 0.0, 'known' => false];
            } elseif ($t === 'mat' && $current !== null && (string) ($row['code'] ?? '') === (string) $current['code']) {
                $k = (float) ($row['coef'] ?? 0);
                if ($k > 0) {
                    $acc['den'] += (float) ($row['qty'] ?? 0) * $k;
                    if (($row['qty2'] ?? null) !== null) {
                        $acc['known'] = true;
                        $acc['num'] += (float) $row['qty2'] * $k;
                    }
                }
            } elseif ($t !== 'mat') {
                $flush();
            }
        }
        $flush();
    }
    return $cache[$token] = $works;
}

function tkp_rv_add(array &$works, string $code, string $name, string $unit, float $qty, ?float $qtySmeta, bool $inSmeta, string $source): void
{
    if (!isset($works[$code])) {
        $works[$code] = ['name' => $name, 'unit' => $unit, 'qty' => 0.0, 'qty_smeta' => null, 'in_smeta' => false, 'source' => $source];
    }
    $works[$code]['qty'] += $qty;
    if ($qtySmeta !== null) {
        $works[$code]['qty_smeta'] = ($works[$code]['qty_smeta'] ?? 0.0) + $qtySmeta;
    }
    $works[$code]['in_smeta'] = $works[$code]['in_smeta'] || $inSmeta;
}

/** Строки реестра РВ по ИдентификаторЛРВ. */
function tkp_registry_by_id(?array $rows = null): array
{
    $by = [];
    foreach ($rows ?? rv_registry_rows() as $row) {
        $by[(string) $row['id']] = $row;
    }
    return $by;
}

/** Работы ТКП блока по коду ИСР: [код => name, unit, qty, ref_price, price, ref_cost, cost, rows, uids, nums]. */
function tkp_block_works(array $version, string $blockUid): array
{
    $out = [];
    foreach ((array) ($version['rows'] ?? []) as $row) {
        if (($row['kind'] ?? '') !== 'work' || (string) ($row['block'] ?? '') !== $blockUid) {
            continue;
        }
        $code = (string) ($row['code'] ?? '');
        $qty = (float) ($row['qty'] ?? 0);
        $refPrice = isset($row['ref_price']) ? (float) $row['ref_price'] : (float) ($row['ref_price_mat'] ?? 0) + (float) ($row['ref_price_smr'] ?? 0);
        $price = isset($row['price']) ? (float) $row['price'] : (float) ($row['price_mat'] ?? 0) + (float) ($row['price_smr'] ?? 0);
        if (!isset($out[$code])) {
            $out[$code] = ['name' => (string) ($row['name'] ?? ''), 'unit' => (string) ($row['unit'] ?? ''), 'qty' => 0.0,
                           'ref_price' => $refPrice, 'price' => $price, 'ref_cost' => 0.0, 'cost' => 0.0, 'rows' => 0, 'uids' => [], 'nums' => []];
        }
        $w = &$out[$code];
        $w['qty'] += $qty;
        $w['ref_cost'] += $qty * $refPrice;
        $w['cost'] += $qty * $price;
        $w['rows']++;
        $w['uids'][] = (string) $row['uid'];
        $w['nums'][] = (string) ($row['num'] ?? '');
        unset($w);
    }
    foreach ($out as &$w) {
        if ($w['qty'] > TKP_EPS) {              // у повторов кода цена — средняя по объёму
            $w['ref_price'] = $w['ref_cost'] / $w['qty'];
            $w['price'] = $w['cost'] / $w['qty'];
        }
    }
    unset($w);
    return $out;
}

/** Цены сметы 1С по коду ИСР из факта (событие «ФактЛРВ», блок «РаботыСметы»): [код => price, qty_customer, price_customer]. */
function tkp_fact_works(array $smetaIds): array
{
    $out = [];
    foreach ($smetaIds as $smetaId) {
        $fact = $smetaId !== '' ? rv_fact($smetaId) : null;
        foreach ((array) ($fact['works'] ?? []) as $w) {
            $code = (string) ($w['code'] ?? '');
            if ($code === '' || !empty($w['virtual'])) {
                continue;
            }
            $out[$code] = ['price' => (float) ($w['price'] ?? 0), 'qty_customer' => (float) ($w['qty_customer'] ?? 0) + (float) (($out[$code] ?? [])['qty_customer'] ?? 0),
                           'price_customer' => (float) ($w['price_customer'] ?? 0)];
        }
    }
    return $out;
}

/**
 * Таблица блока: работы ТКП «в договоре» против РВ привязанных смет. Возвращает
 * ['contract' => версия, 'smetas' => [ид => строка реестра|null], 'rows' => [...], 'totals' => [...], 'no_rv' => [ид смет без РВ]].
 * Строка: code, name, unit, unit_rv, contract (кол-во в договоре), smeta (в смету), volume (объём), ref_price, price,
 * price_1c, flags: over_contract, over_smeta, no_rv, no_tkp, unit_diff, draft (РВ не согласована).
 */
function tkp_compare(array $est, string $blockUid, ?array $registry = null): array
{
    $contract = tkp_contract_version($est);
    $version = $contract ? tkp_version((string) $est['id'], (string) $contract['id']) : null;
    $tkpWorks = $version ? tkp_block_works($version, $blockUid) : [];
    $registry = $registry ?? tkp_registry_by_id();
    $smetas = [];
    $rv = [];
    $noRv = [];
    $smetaIds = [];
    foreach (tkp_block_smetas($est, $blockUid) as $lrvId) {
        $row = $registry[$lrvId] ?? null;
        $smetas[$lrvId] = $row;
        if ($row === null || (string) ($row['token'] ?? '') === '') {
            $noRv[] = $lrvId;
            continue;
        }
        $smetaIds[] = (string) ($row['smeta_id'] ?? '');
        foreach (tkp_rv_works((string) $row['token']) as $code => $w) {
            if (!isset($rv[$code])) {
                $rv[$code] = $w + ['smetas' => []];
            } else {
                $rv[$code]['qty'] += $w['qty'];
                $rv[$code]['qty_smeta'] = $w['qty_smeta'] === null && $rv[$code]['qty_smeta'] === null ? null : (float) $rv[$code]['qty_smeta'] + (float) $w['qty_smeta'];
                $rv[$code]['in_smeta'] = $rv[$code]['in_smeta'] || $w['in_smeta'];
                if ($w['source'] === 'draft') {
                    $rv[$code]['source'] = 'draft';
                }
            }
            $rv[$code]['smetas'][] = $lrvId;
        }
    }
    $fact = tkp_fact_works($smetaIds);
    $codes = array_unique(array_merge(array_keys($tkpWorks), array_keys($rv)));
    usort($codes, static fn($a, $b): int => tkp_code_key((string) $a) <=> tkp_code_key((string) $b));
    $rows = [];
    $totals = ['contract_cost' => 0.0, 'volume_cost' => 0.0, 'ref_cost' => 0.0, 'over' => 0, 'no_rv' => 0, 'no_tkp' => 0, 'works' => 0, 'over_cost' => 0.0];
    foreach ($codes as $code) {
        $code = (string) $code;
        $t = $tkpWorks[$code] ?? null;
        $r = $rv[$code] ?? null;
        $f = $fact[$code] ?? null;
        $contractQty = $t ? $t['qty'] : null;
        $volume = $r ? $r['qty'] : null;
        $smetaQty = $r ? $r['qty_smeta'] : null;
        $price = $t ? $t['price'] : 0.0;
        $flags = [
            'no_rv' => $t !== null && $r === null && $t['qty'] > TKP_EPS,
            'no_tkp' => $t === null && $r !== null,
            'over_contract' => $t !== null && $r !== null && $volume > $contractQty + TKP_EPS,
            'over_smeta' => $r !== null && $smetaQty !== null && $volume > $smetaQty + TKP_EPS,
            'unit_diff' => $t !== null && $r !== null && $r['unit'] !== '' && tkp_unit_key($t['unit']) !== tkp_unit_key($r['unit']),
            'draft' => $r !== null && $r['source'] === 'draft',
        ];
        if ($t === null && $r === null) {
            continue;
        }
        $rows[] = [
            'code' => $code, 'name' => $t['name'] ?? $r['name'] ?? '', 'unit' => $t['unit'] ?? $r['unit'] ?? '', 'unit_rv' => $r['unit'] ?? '',
            'contract' => $contractQty, 'smeta' => $smetaQty, 'volume' => $volume,
            'ref_price' => $t['ref_price'] ?? null, 'price' => $t['price'] ?? null, 'price_1c' => $f['price'] ?? null,
            'qty_customer_1c' => $f['qty_customer'] ?? null, 'tkp_rows' => $t['rows'] ?? 0, 'nums' => $t['nums'] ?? [],
            'smetas' => $r['smetas'] ?? [], 'in_smeta' => $r['in_smeta'] ?? false, 'flags' => $flags,
        ];
        $totals['works']++;
        $totals['contract_cost'] += $t['cost'] ?? 0.0;
        $totals['ref_cost'] += $t['ref_cost'] ?? 0.0;
        $totals['volume_cost'] += $volume !== null ? $volume * $price : 0.0;
        if ($flags['over_contract'] || $flags['over_smeta']) {
            $totals['over']++;
            $totals['over_cost'] += $flags['over_contract'] ? ($volume - $contractQty) * $price : 0.0;
        }
        $totals['no_rv'] += $flags['no_rv'] ? 1 : 0;
        $totals['no_tkp'] += $flags['no_tkp'] ? 1 : 0;
    }
    return ['contract' => $contract, 'smetas' => $smetas, 'rows' => $rows, 'totals' => $totals, 'no_rv' => $noRv];
}

/**
 * Кандидаты в сметы блока: строки реестра РВ объекта ТКП (или все, если объект не выбран) с оценкой —
 * сколько кодов работ блока есть в РВ сметы и совпадает ли номер корпуса/секции с названием блока.
 */
function tkp_candidates(array $est, string $blockUid, array $registryRows): array
{
    $object = trim((string) ($est['object'] ?? ''));
    $objectKey = $object !== '' ? rv_table_key($object) : '';
    $contract = tkp_contract_version($est);
    $version = $contract ? tkp_version((string) $est['id'], (string) $contract['id']) : null;
    $codes = $version ? array_keys(tkp_block_works($version, $blockUid)) : [];
    $blockName = (string) (($est['blocks'] ?? [])[$blockUid] ?? '');
    preg_match_all('/\d+(?:\.\d+)?/u', preg_replace('/^\d+\.\s*/u', '', $blockName) ?? '', $m);
    $blockNums = $m[0];
    $out = [];
    foreach ($registryRows as $row) {
        if ($objectKey !== '' && (string) ($row['folder_key'] ?? '') !== $objectKey) {
            continue;
        }
        $works = (string) ($row['token'] ?? '') !== '' ? tkp_rv_works((string) $row['token']) : [];
        $overlap = $codes ? count(array_intersect($codes, array_keys($works))) : 0;
        preg_match_all('/\d+(?:\.\d+)?/u', (string) ($row['building_label'] ?? ''), $bm);
        $bldMatch = $blockNums && array_intersect($blockNums, $bm[0]);
        $out[] = ['row' => $row, 'overlap' => $overlap, 'works' => count($works), 'building' => (bool) $bldMatch];
    }
    usort($out, static fn(array $a, array $b): int => [$b['building'], $b['overlap'], (string) $a['row']['smeta']] <=> [$a['building'], $a['overlap'], (string) $b['row']['smeta']]);
    return $out;
}

function tkp_num(?float $value, int $digits = 2): string
{
    if ($value === null) {
        return '';
    }
    $text = number_format($value, $digits, ',', ' ');
    return $digits > 0 ? rtrim(rtrim($text, '0'), ',') : $text;
}

function tkp_money(?float $value): string
{
    return $value === null ? '' : number_format($value, 0, ',', ' ');
}
