<?php
declare(strict_types=1);

// Сверка РВ из 1С с агентом: все РВ, присланные 1С на сверку (1c_rv.php, «Режим»: «Сверка»; в 1С — команда
// «Сверка РВ с агентом сайта»), по последней версии каждой: объект, смета, документ РВ, доля совпавших строк,
// расхождения (с вердиктом модели и решениями инженеров), работы с другим объёмом. Худшие — сверху.
// ?csv=1 — список файлом; ?token=…&csv=1 — все строки одной сверки (для разбора в Excel).
// Доступ — как к модулю ЦО (rv_guard).

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require_once __DIR__ . '/users.php';
require_once __DIR__ . '/lib.php';
require_once __DIR__ . '/rv_lib.php';

rv_guard();

$statusText = ['match' => 'совпадает', 'differ' => 'другая работа', 'agent_none' => 'агент не нашёл работу',
               'no_1c' => 'в 1С не разнесена', 'not_isr' => 'в 1С работа без кода ИСР'];
$sideText = ['1c' => 'права 1С', 'agent' => 'прав агент', 'other' => 'обе неверны', 'question' => 'вопрос'];

// ── Строки одной сверки файлом ──
$oneToken = (string) ($_GET['token'] ?? '');
if ($oneToken !== '' && isset($_GET['csv'])) {
    if (!rv_token_valid($oneToken)) {
        rv_fail('Неверный номер задачи.');
    }
    $paths = rv_paths($oneToken);
    $job = rv_read_json($paths['job']);
    if ($job === null || !rv_can_access($job) || ($job['mode'] ?? '') !== 'audit') {
        rv_fail('Сверка не найдена.', 404);
    }
    $result = rv_read_packed($paths['json']);
    $decisions = (array) ($job['audit_decisions'] ?? []);
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="audit_' . $oneToken . '.csv"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, ['Строка ЛРВ', 'Количество', 'Ед.', 'Элемент', 'Итог', 'Работы в 1С', 'Код агента', 'Работа агента',
                   'Уверенность агента', 'Модель', 'Код модели', 'Причина', 'Решение инженера', 'Кто решил'], ';');
    foreach ((array) ($result['audit']['rows'] ?? []) as $row) {
        $c1 = [];
        foreach ((array) ($row['c1'] ?? []) as $work) {
            $c1[] = (($work['code'] ?? '') ?: 'без кода') . ' ' . ($work['name'] ?? '') . (($work['qty'] ?? null) !== null ? ' (' . $work['qty'] . ')' : '');
        }
        $m = is_array($row['model'] ?? null) ? $row['model'] : [];
        $d = $decisions[(string) $row['id']] ?? [];
        fputcsv($out, [(string) $row['name'], $row['qty'], (string) ($row['unit'] ?? ''), (string) ($row['element'] ?? ''),
                       $statusText[$row['status']] ?? $row['status'], implode('; ', $c1),
                       (string) ($row['agent']['code'] ?? ''), (string) ($row['agent']['work'] ?? ''),
                       isset($row['agent']['confidence']) ? round((float) $row['agent']['confidence'] * 100) . '%' : '',
                       $sideText[$m['side'] ?? ''] ?? '', (string) ($m['code'] ?? ''), (string) ($m['reason'] ?? ''),
                       ['1c' => 'прав 1С', 'agent' => 'прав агент', 'model' => 'как модель'][$d['choice'] ?? ''] ?? '',
                       (string) ($d['user'] ?? '')], ';');
    }
    exit;
}

// ── Все сверки: последняя версия по каждому документу РВ ──
$latest = [];
$versions = [];
foreach (rv_my_jobs((string) ($_SESSION['kb_user'] ?? ''), true) as $job) {
    $id = (string) ($job['lrv_id'] ?? $job['token']);
    $versions[$id] = ($versions[$id] ?? 0) + 1;
    if (!isset($latest[$id]) || (int) ($job['created'] ?? 0) > (int) ($latest[$id]['created'] ?? 0)) {
        $latest[$id] = $job;
    }
}
$objects = rv_objects();
$all = [];
foreach ($latest as $id => $job) {
    $status = is_array($job['status'] ?? null) ? $job['status'] : [];
    $audit = (array) ($status['summary']['audit'] ?? []);
    $meta = rv_registry_meta($job, $objects);
    $decisions = (array) ($job['audit_decisions'] ?? []);
    $openIds = array_filter((array) ($audit['disputed_ids'] ?? []), static fn($id): bool => !isset($decisions[(string) $id]));
    $all[] = $meta + [
        'id' => $id, 'token' => (string) $job['token'], 'state' => (string) $job['state'], 'versions' => $versions[$id],
        'doc' => (string) ($job['audit_doc'] ?? ''), 'received' => (int) ($job['created'] ?? 0),
        'error' => (string) ($status['error'] ?? ''),
        'rows' => (int) ($audit['rows'] ?? 0), 'match_pct' => $audit['match_pct'] ?? null,
        'disputed' => (int) ($audit['disputed'] ?? 0), 'decided' => count($decisions),
        'open' => isset($audit['disputed_ids']) ? count($openIds) : max(0, (int) ($audit['disputed'] ?? 0) - count($decisions)),
        'no_1c' => (int) ($audit['no_1c'] ?? 0), 'model_1c' => (int) ($audit['model']['1c'] ?? 0),
        'model_agent' => (int) ($audit['model']['agent'] ?? 0), 'works_volume' => (int) ($audit['works_volume'] ?? 0),
        'works_only_1c' => (int) ($audit['works_only_1c'] ?? 0), 'works_only_agent' => (int) ($audit['works_only_agent'] ?? 0),
        'done' => $job['state'] === 'done' && $audit,
    ];
}

$filter = ['q' => trim((string) ($_GET['q'] ?? '')), 'show' => (string) ($_GET['show'] ?? '')];
$rows = array_values(array_filter($all, static function (array $row) use ($filter): bool {
    if ($filter['q'] !== '') {
        $hay = mb_strtolower($row['folder'] . ' ' . $row['obj'] . ' ' . $row['system'] . ' ' . $row['smeta'] . ' ' . $row['doc']);
        foreach (preg_split('/\s+/u', mb_strtolower($filter['q'])) ?: [] as $word) {
            if ($word !== '' && mb_strpos($hay, $word) === false) {
                return false;
            }
        }
    }
    return match ($filter['show']) {
        'open' => $row['done'] && $row['open'] > 0,
        'wait' => !$row['done'] && !in_array($row['state'], ['error', 'stalled'], true),
        'error' => in_array($row['state'], ['error', 'stalled'], true),
        default => true,
    };
}));
// Худшие сверки сверху; ещё не готовые — после готовых.
usort($rows, static fn(array $a, array $b): int
    => [!$a['done'], $a['match_pct'] ?? 101, -$a['open']] <=> [!$b['done'], $b['match_pct'] ?? 101, -$b['open']]);

if (isset($_GET['csv'])) {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="audit_rv_1c.csv"');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, ['Объект', 'Номенклатурная группа', 'Система', 'Смета', 'Документ РВ', 'Строк', 'Совпадает, %',
                   'Расхождений', 'Без решения', 'Решено', 'Модель: права 1С', 'Модель: прав агент', 'В 1С не разнесено',
                   'Работ с другим объёмом', 'Работ только в 1С', 'Работ только у агента', 'Получена', 'Ссылка'], ';');
    foreach ($rows as $row) {
        fputcsv($out, [$row['folder'], $row['obj'], $row['system'], $row['smeta'], $row['doc'], $row['rows'],
                       $row['match_pct'] === null ? '' : str_replace('.', ',', (string) $row['match_pct']),
                       $row['disputed'], $row['open'], $row['decided'], $row['model_1c'], $row['model_agent'], $row['no_1c'],
                       $row['works_volume'], $row['works_only_1c'], $row['works_only_agent'],
                       date('d.m.Y H:i', $row['received']), 'rv_status.php?token=' . $row['token']], ';');
    }
    exit;
}

$done = array_values(array_filter($all, static fn(array $r): bool => (bool) $r['done']));
$rowsTotal = array_sum(array_column($done, 'rows'));
$matchTotal = 0.0;
$comparable = 0;
foreach ($done as $row) {
    if ($row['match_pct'] !== null) {
        $n = $row['rows'] - $row['no_1c'];
        $matchTotal += $row['match_pct'] * $n;
        $comparable += $n;
    }
}
$openTotal = array_sum(array_column($done, 'open'));
$decidedTotal = array_sum(array_column($done, 'decided'));
$waiting = count(array_filter($all, static fn(array $r): bool => !$r['done'] && !in_array($r['state'], ['error', 'stalled'], true)));
$errors = count(array_filter($all, static fn(array $r): bool => in_array($r['state'], ['error', 'stalled'], true)));
$stateText = ['queued' => 'в очереди', 'running' => 'строится', 'awaiting_confirm' => 'ждёт выбора системы',
              'error' => 'ошибка', 'stalled' => 'оборвалась', 'done' => 'готово'];
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Сверка РВ из 1С — База знаний</title>
<link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
<script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
</head>
<body>
<div class="shell">
  <?php require __DIR__ . '/sidebar.php'; ?>

  <div class="dashboard-main">
  <div class="page-wide">

  <div class="card">
    <h1>Сверка РВ из 1С</h1>
    <p class="subtitle">РВ, уже сделанные в 1С, агент разносит заново и сравнивает: та же ли работа у каждой строки ЛРВ и те же ли объёмы работ. Модель смотрит только расхождения и говорит, кто прав; окончательно решает инженер на странице сверки — решения уходят в память агента. Отправить РВ на сверку — команда «Сверка РВ с агентом сайта» в списке или документе «Ресурсная ведомость» в 1С. Сверки идут в очереди после рабочих ЛРВ.</p>
    <div class="rv-figures">
      <div><b><?= count($done) ?></b><span>РВ сверено<?= $waiting ? ', ещё в очереди ' . $waiting : '' ?></span></div>
      <div class="<?= $comparable && $matchTotal / $comparable >= 90 ? 'is-done' : 'is-review' ?>"><b><?= $comparable ? rv_h(number_format($matchTotal / $comparable, 1, ',', '')) . '%' : '—' ?></b><span>строк совпадает (из <?= $rowsTotal ?>)</span></div>
      <div class="<?= $openTotal ? 'is-question' : 'is-done' ?>"><b><?= $openTotal ?></b><span>расхождений без решения; решений инженеров <?= $decidedTotal ?></span></div>
      <div><b><?= array_sum(array_column($done, 'model_1c')) ?> / <?= array_sum(array_column($done, 'model_agent')) ?></b><span>модель: права 1С / прав агент</span></div>
      <div class="<?= $errors ? 'is-question' : '' ?>"><b><?= $errors ?></b><span>с ошибкой</span></div>
    </div>
  </div>

  <div class="card">
    <form class="rv-reg-filter" method="get" action="rv_audit.php">
      <input type="search" name="q" value="<?= rv_h($filter['q']) ?>" placeholder="объект, НГ, система, смета, документ" aria-label="Поиск">
      <select name="show" aria-label="Показать">
        <option value="">все</option>
        <option value="open"<?= $filter['show'] === 'open' ? ' selected' : '' ?>>есть нерешённые расхождения</option>
        <option value="wait"<?= $filter['show'] === 'wait' ? ' selected' : '' ?>>в очереди и строятся</option>
        <option value="error"<?= $filter['show'] === 'error' ? ' selected' : '' ?>>с ошибкой</option>
      </select>
      <button type="submit" class="btn-small">Показать</button>
      <a class="btn-small secondary" href="rv_audit.php?<?= rv_h(http_build_query(array_filter($filter + ['csv' => '1'], static fn($v) => $v !== ''))) ?>">Скачать список (CSV)</a>
      <span class="muted-dash">показано <?= count($rows) ?> из <?= count($all) ?></span>
    </form>
    <?php if (!$all): ?>
    <p class="hint">1С ещё не присылала РВ на сверку. В 1С: список документов «Ресурсная ведомость» → «Сверка РВ с агентом сайта» → «Все проведённые РВ».</p>
    <?php elseif (!$rows): ?>
    <p class="hint">По этому отбору ничего нет.</p>
    <?php else: ?>
    <div class="table-wrap">
    <table class="data-table rv-audit-list">
      <thead><tr><th>Объект / смета</th><th>Документ РВ</th><th>Совпадает</th><th>Расхождения</th><th>Объёмы работ</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($rows as $row): ?>
        <tr>
          <td data-label="Объект / смета"><?= rv_h($row['folder'] !== '' ? $row['folder'] . ' › ' : '') ?><?= rv_h($row['obj']) ?><br><span class="muted-dash"><?= rv_h($row['system']) ?><?= $row['smeta'] !== '' && $row['smeta'] !== $row['system'] ? ' · ' . rv_h($row['smeta']) : '' ?></span></td>
          <td data-label="Документ РВ"><?= rv_h($row['doc'] !== '' ? $row['doc'] : '—') ?><br><span class="muted-dash">получена <?= rv_h(rv_when($row['received'])) ?><?= $row['versions'] > 1 ? ', версий ' . $row['versions'] : '' ?></span></td>
          <td data-label="Совпадает">
            <?php if ($row['done']): ?><b><?= $row['match_pct'] === null ? '—' : rv_h(number_format((float) $row['match_pct'], 1, ',', '')) . '%' ?></b><br><span class="muted-dash">строк <?= $row['rows'] ?><?= $row['no_1c'] ? ', в 1С не разнесено ' . $row['no_1c'] : '' ?></span>
            <?php else: ?><span class="home-status is-<?= in_array($row['state'], ['error', 'stalled'], true) ? 'error' : 'wait' ?>"><?= rv_h($stateText[$row['state']] ?? $row['state']) ?></span><?php if ($row['error'] !== ''): ?><br><span class="rv-reg-error"><?= rv_h(mb_substr($row['error'], 0, 200)) ?></span><?php endif; ?><?php endif; ?>
          </td>
          <td data-label="Расхождения"><?php if ($row['done']): ?>без решения <?= $row['open'] ?><?= $row['decided'] ? ', решено ' . $row['decided'] : '' ?><?php if ($row['model_1c'] + $row['model_agent']): ?><br><span class="muted-dash">модель: 1С <?= $row['model_1c'] ?>, агент <?= $row['model_agent'] ?></span><?php endif; ?><?php endif; ?></td>
          <td data-label="Объёмы работ"><?php if ($row['done']): ?><?= $row['works_volume'] + $row['works_only_1c'] + $row['works_only_agent'] ? 'расходится ' . $row['works_volume'] . ', только в 1С ' . $row['works_only_1c'] . ', только у агента ' . $row['works_only_agent'] : 'совпадают' ?><?php endif; ?></td>
          <td><a class="btn secondary btn-small" href="rv_status.php?token=<?= rv_h($row['token']) ?>#audit">Открыть</a></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    </div>
    <?php endif; ?>
  </div>

  <p><a href="rv.php">← РВ по ЛРВ</a> · <a href="rv_registry.php">Объекты и ЛРВ из 1С</a></p>
  </div>
  </div>
</div>
</body>
</html>
