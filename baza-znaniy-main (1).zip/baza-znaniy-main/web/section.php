<?php
declare(strict_types=1);

// Страница модуля (structure.php): что уже работает на сайте, а для тех,
// кому виден план (KB_PLAN_VIEWERS), — ответственные и задачи со
// статусами. Часть обновлённого оформления — при выключенном новом виде
// ведёт на главную.

require __DIR__ . '/auth_guard.php';
require_once __DIR__ . '/users.php';
require_once __DIR__ . '/design.php';
require_once __DIR__ . '/structure_lib.php';

if (!design_refresh()) {
    header('Location: index.php');
    exit;
}

$section = kb_section((string) ($_GET['id'] ?? ''));
if ($section === null) {
    http_response_code(404);
}
$counts = $section !== null ? kb_counts([$section]) : null;
$login = (string) ($_SESSION['kb_user'] ?? '');
$mine = $section !== null && in_array($section, kb_user_sections($login), true);
$plans = kb_can_see_plans($login);
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= kb_e($section['title'] ?? 'Модуль не найден') ?> — База знаний</title>
<link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
<?= design_refresh_css() ?>
<script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
</head>
<body>
<div class="shell">
  <?php require __DIR__ . '/sidebar.php'; ?>

  <main class="dashboard-main kb-section-page">
  <?php if ($section === null): ?>
    <header class="home-head">
      <h1>Модуль не найден</h1>
      <p class="lead">Такого модуля нет. Все модули — в меню слева.</p>
    </header>
  <?php else: ?>
    <header class="home-head">
      <?php if ($plans): ?>
      <p class="kb-crumbs"><a href="roadmap.php">Схема направлений</a><?php if ($section['num'] !== ''): ?><span aria-hidden="true"> / </span>модуль <?= kb_e($section['num']) ?><?php endif; ?><?= $mine ? ', ваш отдел' : '' ?></p>
      <?php elseif ($mine): ?>
      <p class="kb-crumbs">Модуль вашего отдела</p>
      <?php endif; ?>
      <h1><?= kb_e($section['title']) ?></h1>
      <p class="lead"><?= kb_e($section['about']) ?></p>
      <?php if ($plans): ?>
      <p class="kb-owners"><?= kb_e(kb_owners($section['owners'])) ?></p>
      <?php endif; ?>
    </header>

    <?php if ($plans && !empty($section['proposal'])): ?>
    <div class="alert info">Направление предложено для обсуждения: состав задач и ответственные ещё не утверждены.</div>
    <?php endif; ?>

    <?php if ($section['tools']): ?>
    <section aria-labelledby="kb-tools-title">
      <h2 id="kb-tools-title">На сайте</h2>
      <ul class="home-tiles">
        <?php foreach ($section['tools'] as $tool): ?>
        <li><?= kb_tool_tile($tool) ?></li>
        <?php endforeach; ?>
      </ul>
    </section>
    <?php endif; ?>

    <?php if (!$plans && !$section['tools']): ?>
    <p class="kb-plan-lead">Готовых инструментов в этом модуле пока нет — они появятся здесь и в меню.</p>
    <?php endif; ?>

    <?php if ($plans): ?>
    <section class="kb-plan-section" aria-labelledby="kb-plan-heading">
      <div class="kb-plan-head">
        <h2 id="kb-plan-heading">План модуля</h2>
        <p class="kb-plan-sum"><?= kb_e(kb_cap(kb_done_text($counts))) ?></p>
      </div>
      <?= kb_bar($counts) ?>
      <?php if (!$section['tools']): ?>
      <p class="kb-plan-lead">Готовых инструментов на сайте пока нет. Как только задача будет готова, инструмент появится здесь и в меню модуля.</p>
      <?php endif; ?>
      <div class="kb-plan-box"><?= kb_plan_html($section) ?></div>
    </section>
    <?php endif; ?>
  <?php endif; ?>
  </main>
</div>
</body>
</html>
