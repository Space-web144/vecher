<?php
declare(strict_types=1);

/** Private, server-only Anthropic credentials. No API tokens in HTML or argv. */
function cp_credentials_file(): string
{
    $configured = defined('CLEAN_PAPPER_CREDENTIALS_FILE')
        ? (string) CLEAN_PAPPER_CREDENTIALS_FILE
        : (defined('ANTHROPIC_CREDENTIALS_FILE') ? (string) ANTHROPIC_CREDENTIALS_FILE : '');
    return $configured;
}

/** Pick existing Python runtime, falling back to the VPS system Python. */
function cp_python_binary(): ?string
{
    $candidates = [
        defined('CLEAN_PAPPER_PYTHON_BIN') ? (string) CLEAN_PAPPER_PYTHON_BIN : '',
        defined('PYTHON_BIN') ? (string) PYTHON_BIN : '',
        '/usr/bin/python3', '/usr/local/bin/python3',
    ];
    foreach ($candidates as $path) {
        if ($path !== '' && is_file($path) && is_executable($path)) {
            return $path;
        }
    }
    return null;
}

/**
 * Invoke a fixed, repo-owned command, not arbitrary user-supplied code.
 * The key is only read within Python from a protected file path.
 * All output/error from Python is capped; stderr is discarded.
 */
function cp_run_anthropic_probe(string $action): array
{
    if (!in_array($action, ['status', 'ping'], true)) {
        return ['ok' => false, 'message' => 'Неизвестная операция.'];
    }
    $credentialPath = cp_credentials_file();
    if ($credentialPath === '' || !is_file($credentialPath)) {
        return ['ok' => false, 'code' => 'credentials_missing',
                'message' => 'На сервере не найден файл ключа Anthropic.'];
    }
    $python = cp_python_binary();
    $script = dirname(__DIR__) . '/common/web_clean_papper_api.py';
    if ($python === null || !is_file($script) || !function_exists('proc_open')) {
        return ['ok' => false, 'code' => 'worker_unavailable',
                'message' => 'Серверный Python-обработчик Clean Papper недоступен.'];
    }

    $cmd = [$python, $script, '--credentials', $credentialPath, '--action', $action];
    $pipes = [];
    $descriptors = [
        0 => ['pipe', 'r'],
        1 => ['pipe', 'w'],
        2 => ['pipe', 'w'],
    ];
    $process = @proc_open($cmd, $descriptors, $pipes, dirname(__DIR__));
    if (!is_resource($process)) {
        return ['ok' => false, 'code' => 'worker_unavailable',
                'message' => 'Не удалось запустить серверный обработчик.'];
    }

    fclose($pipes[0]);
    stream_set_blocking($pipes[1], false);
    stream_set_blocking($pipes[2], false);
    $stdout = '';
    $started = microtime(true);
    $timeout = ($action === 'ping') ? 30 : 10;
    $timedOut = false;
    $oversize = false;
    do {
        $stdout .= (string) stream_get_contents($pipes[1]);
        // stderr can contain detailed internal paths; never publish or log it.
        stream_get_contents($pipes[2]);
        if (strlen($stdout) > 8192) {
            $oversize = true;
            @proc_terminate($process);
            break;
        }
        $status = proc_get_status($process);
        if (!$status['running']) {
            break;
        }
        if (microtime(true) - $started > $timeout) {
            $timedOut = true;
            @proc_terminate($process);
            break;
        }
        usleep(100000);
    } while (true);
    $stdout .= (string) stream_get_contents($pipes[1]);
    fclose($pipes[1]);
    fclose($pipes[2]);
    @proc_close($process);

    if ($timedOut) {
        return ['ok' => false, 'code' => 'timeout',
                'message' => 'Проверка Claude API превысила лимит времени.'];
    }
    if ($oversize || strlen($stdout) > 8192) {
        return ['ok' => false, 'code' => 'worker_response_invalid',
                'message' => 'Неверный размер ответа серверного обработчика.'];
    }
    $result = json_decode(trim($stdout), true);
    if (!is_array($result) || !isset($result['ok']) || !is_bool($result['ok'])) {
        return ['ok' => false, 'code' => 'worker_response_invalid',
                'message' => 'Серверный обработчик не вернул корректный результат.'];
    }
    // Defense in depth: do not allow arbitrary Python error strings to reach UI.
    if (!$result['ok']) {
        $allowed = ['configuration', 'connection', 'api', 'internal'];
        if (!in_array((string) ($result['code'] ?? ''), $allowed, true)) {
            return ['ok' => false, 'code' => 'internal',
                    'message' => 'Серверный тест завершился ошибкой.'];
        }
        return ['ok' => false, 'code' => (string) $result['code'],
                'message' => (string) ($result['message'] ?? 'Не удалось проверить API.')];
    }
    return [
        'ok' => true,
        'provider' => 'Anthropic',
        'model' => substr((string) ($result['model'] ?? ''), 0, 102),
        'live_verified' => ($result['live_verified'] ?? false) === true,
        'message' => (string) ($result['message'] ?? 'Проверка завершена.'),
        'input_tokens' => max(0, (int) ($result['input_tokens'] ?? 0)),
        'output_tokens' => max(0, (int) ($result['output_tokens'] ?? 0)),
    ];
}
