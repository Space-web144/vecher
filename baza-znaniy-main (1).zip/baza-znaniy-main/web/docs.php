<?php
declare(strict_types=1);

// Раздел «Документация» — библиотека сторонних документов (нормативы, ГОСТ,
// СП, регламенты, каталоги производителей и т. п.). Смотреть и скачивать
// могут все вошедшие пользователи; загружать, править, заменять редакцию и
// удалять — admin/mainadmin. Хранилище — docs_lib.php, отдача файлов —
// doc_file.php.

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require_once __DIR__ . '/users.php';
require __DIR__ . '/docs_lib.php';

$role = (string) ($_SESSION['kb_role'] ?? '');
$isAdminTier = is_admin_tier_role($role);
$maxDocMb = intdiv(MAX_DOC_UPLOAD_BYTES, 1024 * 1024);
$uploadLimit = effective_doc_upload_limit();
$me = (string) ($_SESSION['kb_user'] ?? '');

if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(16));
}
$csrf = $_SESSION['csrf'];

function clean_text(string $s, int $max): string
{
    $s = trim(preg_replace('/[\x00-\x1F\x7F]+/u', ' ', $s) ?? '');
    return mb_substr($s, 0, $max);
}

// Поля, общие для загрузки и редактирования.
function posted_meta(): array
{
    return [
        'title' => clean_text((string) ($_POST['title'] ?? ''), 200),
        'category' => clean_text((string) ($_POST['category'] ?? ''), 80),
        'description' => clean_text((string) ($_POST['description'] ?? ''), 500),
    ];
}

$errors = [];
$flash = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Файл больше post_max_size PHP молча отбрасывает целиком — вместе с
    // csrf и остальными полями, поэтому без этой проверки пользователь
    // увидел бы непонятное «форма устарела».
    if (!$_POST && (int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > 0) {
        $errors[] = 'Файлы слишком большие для настроек сервера (post_max_size).';
    } elseif (!$isAdminTier) {
        http_response_code(403);
        $errors[] = 'Загружать и изменять документы могут только администраторы.';
    } elseif (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) {
        $errors[] = 'Форма устарела, попробуйте ещё раз.';
    } else {
        $action = (string) ($_POST['action'] ?? '');
        $id = (string) ($_POST['id'] ?? '');
        try {
            if ($action === 'upload') {
                // Несколько файлов за раз: каждый — отдельный документ с общей
                // категорией и описанием. Название из формы — только когда
                // файл один, иначе у каждого своё, из имени файла.
                $uploads = uploaded_files_list($_FILES['doc_file'] ?? null);
                $meta = posted_meta();
                $added = [];
                if (!$uploads) {
                    $errors[] = 'Выберите хотя бы один файл.';
                }
                foreach ($uploads as $upload) {
                    try {
                        $file = store_uploaded_doc_file($upload, $me);
                    } catch (RuntimeException $e) {
                        $errors[] = $e->getMessage();
                        continue;
                    }
                    $title = count($uploads) === 1 && $meta['title'] !== ''
                        ? $meta['title']
                        : clean_text(pathinfo($file['original_name'], PATHINFO_FILENAME), 200);
                    $added[] = $file + [
                        'id' => bin2hex(random_bytes(8)),
                        'title' => $title,
                        'category' => $meta['category'],
                        'description' => $meta['description'],
                        'created_at' => $file['uploaded_at'],
                        'versions' => [],
                    ];
                }
                if ($added) {
                    update_docs(fn(array $docs) => array_merge($docs, $added));
                    $flash[] = count($added) === 1
                        ? "Документ «{$added[0]['title']}» добавлен."
                        : 'Добавлено документов: ' . count($added) . '.';
                }
            } elseif ($action === 'update') {
                // Правка названия/категории/описания и, если выбран файл, —
                // новая редакция: текущий файл уходит в «прежние редакции».
                $meta = posted_meta();
                if ($meta['title'] === '') {
                    throw new RuntimeException('Название не может быть пустым.');
                }
                $uploads = uploaded_files_list($_FILES['doc_file'] ?? null);
                $newFile = $uploads ? store_uploaded_doc_file($uploads[0], $me) : null;
                $found = false;
                update_docs(function (array $docs) use ($id, $meta, $newFile, &$found) {
                    foreach ($docs as &$d) {
                        if (!hash_equals($d['id'], $id)) {
                            continue;
                        }
                        $found = true;
                        $d = array_merge($d, $meta);
                        if ($newFile !== null) {
                            array_unshift($d['versions'], array_intersect_key($d, array_flip(
                                ['file', 'ext', 'original_name', 'size', 'uploaded_at', 'uploaded_by']
                            )));
                            $d = array_merge($d, $newFile);
                        }
                    }
                    unset($d);
                    return $docs;
                });
                if (!$found) {
                    if ($newFile !== null) {
                        @unlink(doc_file_path($newFile['file'], $newFile['ext']));
                    }
                    throw new RuntimeException('Документ не найден — возможно, его уже удалили.');
                }
                $flash[] = $newFile !== null
                    ? "Загружена новая редакция «{$meta['title']}», прежняя сохранена."
                    : "Документ «{$meta['title']}» обновлён.";
            } elseif ($action === 'delete') {
                $removed = null;
                update_docs(function (array $docs) use ($id, &$removed) {
                    $removed = find_doc($docs, $id);
                    return array_filter($docs, fn($d) => !hash_equals($d['id'], $id));
                });
                if ($removed === null) {
                    throw new RuntimeException('Документ не найден — возможно, его уже удалили.');
                }
                @unlink(doc_path($removed));
                foreach ($removed['versions'] as $v) {
                    @unlink(doc_file_path($v['file'], $v['ext']));
                }
                $flash[] = "Документ «{$removed['title']}» удалён вместе с прежними редакциями.";
            } elseif ($action === 'delete_version') {
                $versionId = (string) ($_POST['version'] ?? '');
                $removed = null;
                update_docs(function (array $docs) use ($id, $versionId, &$removed) {
                    foreach ($docs as &$d) {
                        if (!hash_equals($d['id'], $id)) {
                            continue;
                        }
                        foreach ($d['versions'] as $i => $v) {
                            if (hash_equals($v['file'], $versionId)) {
                                $removed = $v;
                                array_splice($d['versions'], $i, 1);
                                break;
                            }
                        }
                    }
                    unset($d);
                    return $docs;
                });
                if ($removed === null) {
                    throw new RuntimeException('Редакция не найдена — возможно, её уже удалили.');
                }
                @unlink(doc_file_path($removed['file'], $removed['ext']));
                $flash[] = 'Прежняя редакция от ' . date('d.m.Y', $removed['uploaded_at']) . ' удалена.';
            } else {
                $errors[] = 'Неизвестное действие.';
            }
        } catch (RuntimeException $e) {
            $errors[] = $e->getMessage();
        }
    }

    // Post/Redirect/Get: обновление страницы не должно повторно отправлять
    // файлы. При пакетной загрузке часть файлов может пройти, а часть нет —
    // поэтому и успехи, и ошибки переносим через сессию.
    if ($flash || !$errors) {
        $_SESSION['docs_flash'] = $flash;
        $_SESSION['docs_errors'] = $errors;
        header('Location: docs.php');
        exit;
    }
}

$flash = array_merge($flash, (array) ($_SESSION['docs_flash'] ?? []));
$errors = array_merge($errors, (array) ($_SESSION['docs_errors'] ?? []));
unset($_SESSION['docs_flash'], $_SESSION['docs_errors']);

$docs = load_docs();
$groups = group_docs($docs);
$categories = array_values(array_filter(array_keys($groups), fn($c) => $c !== ''));
$acceptAttr = '.' . implode(',.', array_keys(DOC_TYPES));

function h(string $s): string
{
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

function doc_file_url(array $doc, ?array $version = null, bool $download = false): string
{
    $url = 'doc_file.php?id=' . urlencode($doc['id']);
    if ($version !== null) {
        $url .= '&v=' . urlencode($version['file']);
    }
    return $url . ($download ? '&dl=1' : '');
}

function csrf_fields(string $csrf, string $action, string $id = ''): string
{
    return '<input type="hidden" name="csrf" value="' . h($csrf) . '">'
        . '<input type="hidden" name="action" value="' . h($action) . '">'
        . ($id !== '' ? '<input type="hidden" name="id" value="' . h($id) . '">' : '');
}
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Документация — База знаний</title>
<link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
<script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
<script src="assets/dropzone.js?v=<?= filemtime(__DIR__ . '/assets/dropzone.js') ?>" defer></script>
</head>
<body>
<div class="shell">
  <?php require __DIR__ . '/sidebar.php'; ?>

  <div class="dashboard-main">
  <div class="page-wide">

  <?php foreach ($errors as $e): ?><div class="alert error"><?= h($e) ?></div><?php endforeach; ?>
  <?php foreach ($flash as $f): ?><div class="alert success"><?= h($f) ?></div><?php endforeach; ?>

  <datalist id="doc_categories">
    <?php foreach ($categories as $cat): ?><option value="<?= h($cat) ?>"><?php endforeach; ?>
  </datalist>

  <div class="card">
    <h1>Документы</h1>
    <p class="subtitle">Нормативы, стандарты, регламенты и другие справочные материалы.</p>

    <?php if ($docs): ?>
    <div class="docs-filters">
      <input type="search" id="docs-search" class="docs-search" placeholder="Поиск по названию, описанию или имени файла" aria-label="Поиск документов">
      <?php if (count($groups) > 1): ?>
      <div class="docs-chips" role="group" aria-label="Категории">
        <button type="button" class="docs-chip active" data-cat="*">Все</button>
        <?php foreach (array_keys($groups) as $cat): ?>
        <button type="button" class="docs-chip" data-cat="<?= h((string) $cat) ?>"><?= $cat === '' ? 'Без категории' : h((string) $cat) ?></button>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>
    </div>

    <?php foreach ($groups as $cat => $items): $cat = (string) $cat; ?>
    <section class="docs-group" data-cat="<?= h($cat) ?>">
      <h2 class="docs-group-title"><?= $cat === '' ? 'Без категории' : h($cat) ?> <span class="docs-group-count"><?= count($items) ?></span></h2>
      <ul class="docs-list">
        <?php foreach ($items as $d): $type = DOC_TYPES[$d['ext']]; ?>
        <li class="docs-item" data-text="<?= h(mb_strtolower($d['title'] . ' ' . $d['description'] . ' ' . $d['original_name'] . ' ' . $d['category'])) ?>">
          <div class="docs-item-row">
            <span class="docs-ext docs-ext-<?= h($d['ext']) ?>"><?= h(strtoupper($d['ext'])) ?></span>
            <div class="docs-item-body">
              <a class="docs-item-title" href="<?= h(doc_file_url($d)) ?>"<?= $type['inline'] ? ' target="_blank" rel="noopener"' : '' ?>><?= h($d['title']) ?></a>
              <?php if ($d['description'] !== ''): ?><div class="docs-item-desc"><?= h($d['description']) ?></div><?php endif; ?>
              <div class="docs-item-meta">
                <span><?= h($type['label']) ?> · <?= h(format_size($d['size'])) ?></span>
                <span><?= $d['versions'] ? 'редакция от' : 'добавлен' ?> <?= h(date('d.m.Y', $d['uploaded_at'])) ?></span>
              </div>
            </div>
            <div class="docs-item-actions">
              <?php if ($type['inline']): ?>
              <a class="btn btn-small" href="<?= h(doc_file_url($d)) ?>" target="_blank" rel="noopener">Открыть</a>
              <?php endif; ?>
              <a class="btn btn-small<?= $type['inline'] ? ' btn-outline' : '' ?>" href="<?= h(doc_file_url($d, null, true)) ?>">Скачать</a>
            </div>
          </div>

          <?php if ($d['versions']): ?>
          <details class="docs-sub">
            <summary>Прежние редакции (<?= count($d['versions']) ?>)</summary>
            <ul class="docs-versions">
              <?php foreach ($d['versions'] as $v): ?>
              <li>
                <span><?= h(date('d.m.Y', $v['uploaded_at'])) ?> · <?= h(strtoupper($v['ext'])) ?> · <?= h(format_size($v['size'])) ?></span>
                <a href="<?= h(doc_file_url($d, $v, true)) ?>">Скачать</a>
                <?php if ($isAdminTier): ?>
                <form method="post" class="inline-form" onsubmit="return confirm('Удалить прежнюю редакцию от <?= h(date('d.m.Y', $v['uploaded_at'])) ?>?');">
                  <?= csrf_fields($csrf, 'delete_version', $d['id']) ?>
                  <input type="hidden" name="version" value="<?= h($v['file']) ?>">
                  <button type="submit" class="docs-link-danger">Удалить</button>
                </form>
                <?php endif; ?>
              </li>
              <?php endforeach; ?>
            </ul>
          </details>
          <?php endif; ?>

          <?php if ($isAdminTier): ?>
          <details class="docs-sub docs-edit">
            <summary>Изменить</summary>
            <form method="post" enctype="multipart/form-data" class="docs-edit-form">
              <?= csrf_fields($csrf, 'update', $d['id']) ?>
              <div class="docs-edit-grid">
                <label>Название
                  <input type="text" class="text-input" name="title" maxlength="200" value="<?= h($d['title']) ?>" required>
                </label>
                <label>Категория
                  <input type="text" class="text-input" name="category" maxlength="80" list="doc_categories" value="<?= h($d['category']) ?>">
                </label>
                <label class="wide">Описание
                  <textarea class="text-input" name="description" maxlength="500" rows="2"><?= h($d['description']) ?></textarea>
                </label>
                <label class="wide">Новая редакция файла <span class="docs-optional">(необязательно — текущий файл сохранится в «Прежних редакциях»)</span>
                  <input type="file" name="doc_file" accept="<?= h($acceptAttr) ?>">
                </label>
              </div>
              <div class="docs-edit-actions">
                <button type="submit" class="btn-small">Сохранить</button>
              </div>
            </form>
            <form method="post" class="docs-delete-form" onsubmit="return confirm('Удалить документ «<?= h(addslashes($d['title'])) ?>» вместе со всеми редакциями?');">
              <?= csrf_fields($csrf, 'delete', $d['id']) ?>
              <button type="submit" class="btn-small btn-danger">Удалить документ</button>
            </form>
          </details>
          <?php endif; ?>
        </li>
        <?php endforeach; ?>
      </ul>
    </section>
    <?php endforeach; ?>
    <p class="docs-empty" id="docs-empty" hidden>Ничего не найдено.</p>
    <?php else: ?>
    <p class="docs-empty">Документов пока нет.<?= $isAdminTier ? ' Загрузите первые с помощью формы ниже.' : '' ?></p>
    <?php endif; ?>
  </div>

  <?php if ($isAdminTier): ?>
  <div class="card">
    <h2>Добавить документы</h2>
    <p class="subtitle">Видно только администраторам. Можно выбрать сразу несколько файлов — каждый станет отдельным документом. Допустимые форматы: <?= h(implode(', ', array_keys(DOC_TYPES))) ?>; до <?= h(format_size($uploadLimit)) ?> на файл.<?php if ($uploadLimit < MAX_DOC_UPLOAD_BYTES): ?> Предел задан настройками PHP на сервере (upload_max_filesize / post_max_size) — чтобы загружать файлы до <?= $maxDocMb ?> МБ, их нужно увеличить.<?php endif; ?></p>
    <form method="post" enctype="multipart/form-data">
      <?= csrf_fields($csrf, 'upload') ?>
      <div class="field">
        <label class="field-label" for="doc_file">Файлы</label>
        <input type="file" id="doc_file" name="doc_file[]" accept="<?= h($acceptAttr) ?>" multiple required>
      </div>
      <div class="field" id="doc_title_field">
        <label class="field-label" for="doc_title">Название</label>
        <input type="text" class="text-input" id="doc_title" name="title" maxlength="200" placeholder="Если не заполнить — возьмётся имя файла">
      </div>
      <div class="field">
        <label class="field-label" for="doc_category">Категория <span class="docs-optional">(общая для всех выбранных файлов)</span></label>
        <input type="text" class="text-input" id="doc_category" name="category" maxlength="80" list="doc_categories" placeholder="Например: ГОСТ, СП, Регламенты, Каталоги">
      </div>
      <div class="field">
        <label class="field-label" for="doc_description">Описание <span class="docs-optional">(необязательно)</span></label>
        <textarea class="text-input" id="doc_description" name="description" maxlength="500" rows="2"></textarea>
      </div>
      <button type="submit">Загрузить документы</button>
    </form>
  </div>
  <?php endif; ?>

  </div>
  </div>
</div>

<script>
(function () {
  // Поле «Название» имеет смысл только для одного файла — при выборе
  // нескольких названия берутся из имён файлов, и поле прячем.
  var fileInput = document.getElementById('doc_file');
  var titleField = document.getElementById('doc_title_field');
  if (fileInput && titleField) {
    fileInput.addEventListener('change', function () {
      titleField.hidden = fileInput.files.length > 1;
    });
  }

  var search = document.getElementById('docs-search');
  if (!search) return;
  var groups = document.querySelectorAll('.docs-group');
  var chips = document.querySelectorAll('.docs-chip');
  var empty = document.getElementById('docs-empty');
  var cat = '*';
  function apply() {
    var q = search.value.trim().toLowerCase();
    var shown = 0;
    groups.forEach(function (g) {
      var inGroup = 0;
      if (cat === '*' || g.dataset.cat === cat) {
        g.querySelectorAll('.docs-item').forEach(function (li) {
          var ok = q === '' || li.dataset.text.indexOf(q) !== -1;
          li.hidden = !ok;
          if (ok) inGroup++;
        });
      }
      g.hidden = inGroup === 0;
      shown += inGroup;
    });
    empty.hidden = shown !== 0;
  }
  search.addEventListener('input', apply);
  chips.forEach(function (chip) {
    chip.addEventListener('click', function () {
      chips.forEach(function (c) { c.classList.remove('active'); });
      chip.classList.add('active');
      cat = chip.dataset.cat;
      apply();
    });
  });
})();
</script>
</body>
</html>
