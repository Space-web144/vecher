<?php
declare(strict_types=1);

// Общие для process.php/process_pdf.php вещи — страница ошибки одна на оба
// обработчика, чтобы не расходиться в двух копиях.

// Имя загруженного файла (без расширения) для пользовательского имени
// результата ("<имя спецификации>_full_obr.xlsx" и т.п.) — храним на диске
// файлы по-прежнему под токеном (безопасность/защита от перебора), но
// показывать при скачивании должны имя, привязанное к исходному файлу.
// Разрешаем буквы (кириллица/латиница), цифры, пробел, "-", "_", "(", ")",
// "." — остального в оригинальных именах файлов обычно не бывает, а на
// заголовок Content-Disposition лишние символы (кавычки, переводы строк)
// пускать нельзя.
function sanitize_display_base(string $name): string {
    $name = preg_replace('/[\x00-\x1F\x7F]/u', '', $name) ?? '';
    $name = preg_replace('/[^\p{L}\p{N} ()_.\-]/u', '_', $name) ?? '';
    $name = trim($name);
    if ($name === '') {
        return 'файл';
    }
    if (function_exists('mb_substr')) {
        $name = mb_substr($name, 0, 150);
    } else {
        $name = substr($name, 0, 150);
    }
    return $name;
}

// Как подписывается страница ошибки для каждого блока: заголовок вкладки
// и надпись под логотипом. VentSpec выделяет вторую половину названия
// цветом — отсюда разметка в значении, а не просто текст.
const FAIL_PAGE_BRANDS = [
    'area.php' => ['Area — ошибка', 'Area'],
    'verrata.php' => ['Verrata — ошибка', 'Verrata'],
    'ventspec.php' => ['VentSpec — ошибка', 'Vent<span class="accent">Spec</span>'],
];

// $backPage — куда ведёт ссылка "Назад" и чьим именем подписана страница:
// process.php обслуживает только VentSpec, process_pdf.php — VentSpec, Area
// и «Оборудование» (см. там же $format), а verrata_process.php — сравнение
// ревизий, и возвращать пользователя не в тот блок, из которого он пришёл,
// нельзя.
function fail(string $message, int $code = 400, string $backPage = 'ventspec.php'): never {
    http_response_code($code);
    header('Content-Type: text/html; charset=utf-8');
    $safe = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');
    $cssVer = filemtime(__DIR__ . '/assets/style.css');
    $uiVer = filemtime(__DIR__ . '/assets/ui.js');
    // Подписи блоков со своим lib-файлом (libob.php — «Оборудование»)
    // добавляются, только если этот файл подключён.
    $brands = FAIL_PAGE_BRANDS + (defined('OB_FAIL_PAGE_BRANDS') ? OB_FAIL_PAGE_BRANDS : []);
    [$title, $brand] = $brands[$backPage] ?? FAIL_PAGE_BRANDS['ventspec.php'];
    $back = htmlspecialchars($backPage, ENT_QUOTES, 'UTF-8');
    echo <<<HTML
    <!doctype html>
    <html lang="ru">
    <head>
      <meta charset="utf-8">
      <link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <title>{$title}</title>
      <link rel="stylesheet" href="assets/style.css?v={$cssVer}">
      <script src="assets/ui.js?v={$uiVer}"></script>
    </head>
    <body>
    <div class="page">
      <div class="brand">
        <svg width="26" height="24" viewBox="0 0 1100.0 1002.58" aria-hidden="true" focusable="false" style="flex-shrink:0;">
          <path fill-rule="evenodd" fill="#d9432a" d="M546.73,50.0 L439.33,243.12 L400.43,307.83 L376.33,355.34 L285.11,518.5 L258.26,561.88 L170.14,724.01 L171.51,727.45 L175.99,729.17 L642.08,728.83 L653.1,730.21 L659.64,734.34 L670.65,755.34 L671.0,761.19 L664.8,764.63 L632.79,764.97 L154.65,764.63 L145.35,768.07 L140.53,778.74 L143.63,782.87 L149.14,784.25 L678.92,783.22 L687.52,787.35 L693.72,795.61 L699.91,810.41 L699.23,817.3 L692.0,820.74 L124.01,820.4 L114.37,823.15 L108.18,835.89 L113.34,840.36 L707.14,839.67 L716.44,842.43 L725.04,852.41 L731.24,865.15 L730.9,872.03 L722.63,875.82 L92.0,875.82 L83.05,878.23 L77.88,889.93 L83.39,894.75 L741.57,894.41 L748.45,897.16 L758.78,911.27 L761.53,920.57 L760.15,926.42 L755.34,929.86 L59.29,930.55 L50.34,936.4 L50.0,947.07 L54.13,952.58 L711.96,950.17 L752.24,952.58 L761.53,949.83 L793.89,952.58 L796.64,945.01 L794.23,936.06 L566.35,528.83 L563.6,520.22 L564.63,510.93 L574.61,493.03 L582.53,490.28 L592.86,500.6 L838.3,940.53 L847.93,952.58 L857.92,952.58 L860.67,945.35 L857.92,936.06 L595.96,467.21 L595.96,453.1 L606.63,434.85 L613.51,432.1 L619.71,436.23 L899.57,937.78 L909.55,948.45 L920.22,948.11 L922.98,943.29 L921.94,938.12 L628.66,414.89 L626.25,405.59 L628.66,394.58 L638.3,379.43 L645.87,376.33 L652.75,381.15 L745.01,549.14 L767.73,585.97 L963.25,938.47 L975.65,952.58 L982.19,952.58 L987.69,943.98 L978.4,923.67 L929.86,841.05 L859.64,710.93 L842.43,683.73 L660.33,356.37 L658.61,345.35 L667.56,325.04 L671.69,320.91 L677.88,319.54 L685.11,325.04 L1027.62,940.19 L1038.3,952.58 L1046.56,952.58 L1050.0,945.7 L1049.66,940.19 L930.55,728.49 L857.92,593.55 L762.22,426.94 L684.42,282.36 L678.92,276.51 L675.13,277.19 L668.24,285.46 L437.26,698.88 L431.07,706.45 L424.87,709.21 L402.84,709.21 L397.33,706.11 L398.02,695.09 L409.38,672.72 L429.0,641.39 L484.77,536.75 L649.31,245.18 L652.75,233.82 L646.56,220.74 L640.36,223.49 L375.3,696.82 L368.07,706.11 L361.53,708.86 L339.16,709.21 L333.99,706.11 L333.3,697.5 L619.02,185.28 L621.77,174.96 L614.54,162.91 L608.0,166.01 L586.32,206.97 L566.01,239.33 L496.82,367.38 L308.18,703.36 L302.67,707.83 L276.16,709.21 L269.62,705.77 L271.0,694.41 L582.53,138.47 L589.41,117.81 L586.66,109.9 L581.84,105.77 L577.02,107.83 L514.37,222.46 L402.15,419.02 L244.49,703.7 L234.85,709.21 L214.2,709.21 L207.31,706.11 L206.97,696.13 L357.75,423.84 L372.89,400.43 L483.05,199.4 L548.8,86.83 L558.78,61.7 L552.93,50.69 Z M545.7,545.7 L550.52,545.35 L560.84,558.78 L600.09,630.38 L618.33,658.26 L637.26,693.72 L638.98,704.04 L636.23,707.83 L467.56,709.21 L461.36,705.42 L461.02,696.47 L467.9,681.33 Z"/>
        </svg>
        <div class="name">{$brand}</div>
      </div>
      <div class="card">
        <h1>Не удалось обработать запрос</h1>
        <div class="alert error">{$safe}</div>
        <a class="back-link" href="{$back}">← Назад</a>
      </div>
    </div>
    </body>
    </html>
    HTML;
    exit;
}

/**
 * Длительность словами: секунды до минуты, дальше «5 мин 07 с». Инженер
 * смотрит на этот счётчик несколько минут подряд, и «Прошло секунд: 247»
 * он в уме всё равно переводит в минуты.
 */
function verrata_elapsed_text(int $seconds): string {
    $seconds = max(0, $seconds);
    if ($seconds < 60) {
        return $seconds . ' с';
    }
    return intdiv($seconds, 60) . ' мин ' . str_pad((string) ($seconds % 60), 2, '0', STR_PAD_LEFT) . ' с';
}


/**
 * Размер из php.ini («150M», «1G», «0») в байтах. 0 — предела нет.
 */
function ini_bytes(string $key): int {
    $value = trim((string) ini_get($key));
    if ($value === '') {
        return 0;
    }
    $multipliers = ['k' => 1024, 'm' => 1024 * 1024, 'g' => 1024 * 1024 * 1024];
    $unit = strtolower(substr($value, -1));
    return (int) ((float) $value * ($multipliers[$unit] ?? 1));
}

/**
 * Сколько на самом деле можно загрузить одним файлом в Verrata: меньшее
 * из нашего предела (MAX_VERRATA_UPLOAD_BYTES) и предела сервера
 * (upload_max_filesize). Если хостинг не дал поднять свой предел,
 * форма покажет настоящий, а не обещанный в config.php.
 */
function verrata_file_limit(): int {
    $server = ini_bytes('upload_max_filesize');
    return $server > 0 ? min(MAX_VERRATA_UPLOAD_BYTES, $server) : MAX_VERRATA_UPLOAD_BYTES;
}

function megabytes(int $bytes): int {
    return intdiv($bytes + 1024 * 1024 - 1, 1024 * 1024);
}

