<?php
declare(strict_types=1);

require __DIR__ . '/config.php';
require __DIR__ . '/users.php';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// Обновлённое оформление (DESIGN_REFRESH в config.php): ?design=new|old.
require_once __DIR__ . '/design.php';
design_handle_switch();

// Разрешаем возврат после входа только на свои же страницы (по имени
// файла) — иначе ?next= превратился бы в открытый редирект.
function safe_next(?string $next): string
{
    if (!$next) {
        return 'index.php';
    }
    $next = trim($next);
    if ($next === '' || $next[0] !== '/' || strpos($next, '//') === 0) {
        return 'index.php';
    }
    $path = parse_url($next, PHP_URL_PATH);
    $base = $path ? basename($path) : '';
    $allowed = ['index.php', 'ventspec.php', 'status.php'];
    return in_array($base, $allowed, true) ? $next : 'index.php';
}

$next = safe_next($_GET['next'] ?? ($_POST['next'] ?? null));

if (!empty($_SESSION['kb_user'])) {
    header('Location: ' . $next);
    exit;
}

$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim((string) ($_POST['login'] ?? ''));
    $password = (string) ($_POST['password'] ?? '');

    $users = load_users();
    if (!$users) {
        $error = 'Учётные данные не настроены на сервере. Обратитесь к администратору.';
    } else {
        $found = $login !== '' ? find_user($users, $login) : null;
        $validPassword = $found !== null && password_verify($password, $found['password_hash']);

        if ($found !== null && $validPassword) {
            session_regenerate_id(true);
            $_SESSION['kb_user'] = $found['login'];
            $_SESSION['kb_role'] = $found['role'];
            $_SESSION['kb_dept'] = user_department_profile($found);
            $_SESSION['kb_dept_for'] = $found['login'];
            header('Location: ' . $next);
            exit;
        }
        $error = 'Неверный логин или пароль. Проверьте раскладку клавиатуры и повторите.';
    }
}

if (design_refresh()) {
    define('KB_REFRESH_VIEW', true);
    require __DIR__ . '/login_refresh.php';
    exit;
}
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Вход — База знаний</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
<script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
<link rel="stylesheet" href="assets/login.css?v=<?= filemtime(__DIR__ . '/assets/login.css') ?>">
</head>
<body>
<div class="login-shell">
  <div class="login-screen">
    <div class="login-panel-dark">
      <svg class="mark-bg" viewBox="0 0 1100.0 1002.58" aria-hidden="true" focusable="false">
        <path fill-rule="evenodd" d="M546.73,50.0 L439.33,243.12 L400.43,307.83 L376.33,355.34 L285.11,518.5 L258.26,561.88 L170.14,724.01 L171.51,727.45 L175.99,729.17 L642.08,728.83 L653.1,730.21 L659.64,734.34 L670.65,755.34 L671.0,761.19 L664.8,764.63 L632.79,764.97 L154.65,764.63 L145.35,768.07 L140.53,778.74 L143.63,782.87 L149.14,784.25 L678.92,783.22 L687.52,787.35 L693.72,795.61 L699.91,810.41 L699.23,817.3 L692.0,820.74 L124.01,820.4 L114.37,823.15 L108.18,835.89 L113.34,840.36 L707.14,839.67 L716.44,842.43 L725.04,852.41 L731.24,865.15 L730.9,872.03 L722.63,875.82 L92.0,875.82 L83.05,878.23 L77.88,889.93 L83.39,894.75 L741.57,894.41 L748.45,897.16 L758.78,911.27 L761.53,920.57 L760.15,926.42 L755.34,929.86 L59.29,930.55 L50.34,936.4 L50.0,947.07 L54.13,952.58 L711.96,950.17 L752.24,952.58 L761.53,949.83 L793.89,952.58 L796.64,945.01 L794.23,936.06 L566.35,528.83 L563.6,520.22 L564.63,510.93 L574.61,493.03 L582.53,490.28 L592.86,500.6 L838.3,940.53 L847.93,952.58 L857.92,952.58 L860.67,945.35 L857.92,936.06 L595.96,467.21 L595.96,453.1 L606.63,434.85 L613.51,432.1 L619.71,436.23 L899.57,937.78 L909.55,948.45 L920.22,948.11 L922.98,943.29 L921.94,938.12 L628.66,414.89 L626.25,405.59 L628.66,394.58 L638.3,379.43 L645.87,376.33 L652.75,381.15 L745.01,549.14 L767.73,585.97 L963.25,938.47 L975.65,952.58 L982.19,952.58 L987.69,943.98 L978.4,923.67 L929.86,841.05 L859.64,710.93 L842.43,683.73 L660.33,356.37 L658.61,345.35 L667.56,325.04 L671.69,320.91 L677.88,319.54 L685.11,325.04 L1027.62,940.19 L1038.3,952.58 L1046.56,952.58 L1050.0,945.7 L1049.66,940.19 L930.55,728.49 L857.92,593.55 L762.22,426.94 L684.42,282.36 L678.92,276.51 L675.13,277.19 L668.24,285.46 L437.26,698.88 L431.07,706.45 L424.87,709.21 L402.84,709.21 L397.33,706.11 L398.02,695.09 L409.38,672.72 L429.0,641.39 L484.77,536.75 L649.31,245.18 L652.75,233.82 L646.56,220.74 L640.36,223.49 L375.3,696.82 L368.07,706.11 L361.53,708.86 L339.16,709.21 L333.99,706.11 L333.3,697.5 L619.02,185.28 L621.77,174.96 L614.54,162.91 L608.0,166.01 L586.32,206.97 L566.01,239.33 L496.82,367.38 L308.18,703.36 L302.67,707.83 L276.16,709.21 L269.62,705.77 L271.0,694.41 L582.53,138.47 L589.41,117.81 L586.66,109.9 L581.84,105.77 L577.02,107.83 L514.37,222.46 L402.15,419.02 L244.49,703.7 L234.85,709.21 L214.2,709.21 L207.31,706.11 L206.97,696.13 L357.75,423.84 L372.89,400.43 L483.05,199.4 L548.8,86.83 L558.78,61.7 L552.93,50.69 Z M545.7,545.7 L550.52,545.35 L560.84,558.78 L600.09,630.38 L618.33,658.26 L637.26,693.72 L638.98,704.04 L636.23,707.83 L467.56,709.21 L461.36,705.42 L461.02,696.47 L467.9,681.33 Z"/>
      </svg>
      <div class="top-row">
        <svg class="logo-mark" viewBox="0 0 1100.0 1002.58" aria-hidden="true" focusable="false">
          <path fill-rule="evenodd" d="M546.73,50.0 L439.33,243.12 L400.43,307.83 L376.33,355.34 L285.11,518.5 L258.26,561.88 L170.14,724.01 L171.51,727.45 L175.99,729.17 L642.08,728.83 L653.1,730.21 L659.64,734.34 L670.65,755.34 L671.0,761.19 L664.8,764.63 L632.79,764.97 L154.65,764.63 L145.35,768.07 L140.53,778.74 L143.63,782.87 L149.14,784.25 L678.92,783.22 L687.52,787.35 L693.72,795.61 L699.91,810.41 L699.23,817.3 L692.0,820.74 L124.01,820.4 L114.37,823.15 L108.18,835.89 L113.34,840.36 L707.14,839.67 L716.44,842.43 L725.04,852.41 L731.24,865.15 L730.9,872.03 L722.63,875.82 L92.0,875.82 L83.05,878.23 L77.88,889.93 L83.39,894.75 L741.57,894.41 L748.45,897.16 L758.78,911.27 L761.53,920.57 L760.15,926.42 L755.34,929.86 L59.29,930.55 L50.34,936.4 L50.0,947.07 L54.13,952.58 L711.96,950.17 L752.24,952.58 L761.53,949.83 L793.89,952.58 L796.64,945.01 L794.23,936.06 L566.35,528.83 L563.6,520.22 L564.63,510.93 L574.61,493.03 L582.53,490.28 L592.86,500.6 L838.3,940.53 L847.93,952.58 L857.92,952.58 L860.67,945.35 L857.92,936.06 L595.96,467.21 L595.96,453.1 L606.63,434.85 L613.51,432.1 L619.71,436.23 L899.57,937.78 L909.55,948.45 L920.22,948.11 L922.98,943.29 L921.94,938.12 L628.66,414.89 L626.25,405.59 L628.66,394.58 L638.3,379.43 L645.87,376.33 L652.75,381.15 L745.01,549.14 L767.73,585.97 L963.25,938.47 L975.65,952.58 L982.19,952.58 L987.69,943.98 L978.4,923.67 L929.86,841.05 L859.64,710.93 L842.43,683.73 L660.33,356.37 L658.61,345.35 L667.56,325.04 L671.69,320.91 L677.88,319.54 L685.11,325.04 L1027.62,940.19 L1038.3,952.58 L1046.56,952.58 L1050.0,945.7 L1049.66,940.19 L930.55,728.49 L857.92,593.55 L762.22,426.94 L684.42,282.36 L678.92,276.51 L675.13,277.19 L668.24,285.46 L437.26,698.88 L431.07,706.45 L424.87,709.21 L402.84,709.21 L397.33,706.11 L398.02,695.09 L409.38,672.72 L429.0,641.39 L484.77,536.75 L649.31,245.18 L652.75,233.82 L646.56,220.74 L640.36,223.49 L375.3,696.82 L368.07,706.11 L361.53,708.86 L339.16,709.21 L333.99,706.11 L333.3,697.5 L619.02,185.28 L621.77,174.96 L614.54,162.91 L608.0,166.01 L586.32,206.97 L566.01,239.33 L496.82,367.38 L308.18,703.36 L302.67,707.83 L276.16,709.21 L269.62,705.77 L271.0,694.41 L582.53,138.47 L589.41,117.81 L586.66,109.9 L581.84,105.77 L577.02,107.83 L514.37,222.46 L402.15,419.02 L244.49,703.7 L234.85,709.21 L214.2,709.21 L207.31,706.11 L206.97,696.13 L357.75,423.84 L372.89,400.43 L483.05,199.4 L548.8,86.83 L558.78,61.7 L552.93,50.69 Z M545.7,545.7 L550.52,545.35 L560.84,558.78 L600.09,630.38 L618.33,658.26 L637.26,693.72 L638.98,704.04 L636.23,707.83 L467.56,709.21 L461.36,705.42 L461.02,696.47 L467.9,681.33 Z"/>
        </svg>
        <div class="wordmark-stack">
          <span class="co">Альфастрой</span>
          <span class="kb">База знаний</span>
        </div>
      </div>
      <div class="tagline">
        Регламенты, инструкции и рабочие инструменты компании в одном месте.
      </div>
    </div>
    <div class="login-panel-light">
      <h1>Вход</h1>

      <?php if ($error): ?>
      <div class="alert error"><?= htmlspecialchars($error, ENT_QUOTES, 'UTF-8') ?></div>
      <?php endif; ?>

      <form method="post" action="login.php" autocomplete="on">
        <input type="hidden" name="next" value="<?= htmlspecialchars($next, ENT_QUOTES, 'UTF-8') ?>">
        <div class="field">
          <label class="field-label" for="login">Логин</label>
          <div class="input-wrap">
            <input id="login" name="login" type="text" placeholder="ivanov" autocomplete="username" required autofocus>
          </div>
        </div>
        <div class="field">
          <div class="field-row">
            <label class="field-label" for="password" style="margin-bottom:0">Пароль</label>
            <button type="button" class="hint-link" data-toggle-pw="password">показать</button>
          </div>
          <div class="input-wrap" style="margin-top:7px">
            <input id="password" name="password" type="password" placeholder="••••••••" autocomplete="current-password" required>
          </div>
        </div>
        <button type="submit">Войти</button>
      </form>
    </div>
  </div>
</div>
<script>
  document.querySelectorAll('[data-toggle-pw]').forEach(function (btn) {
    btn.addEventListener('click', function () {
      var input = document.getElementById(btn.getAttribute('data-toggle-pw'));
      if (!input) return;
      var showing = input.type === 'text';
      input.type = showing ? 'password' : 'text';
      btn.textContent = showing ? 'показать' : 'скрыть';
    });
  });
</script>
</body>
</html>
