<?php
declare(strict_types=1);

const DEVELOPER_FEEDBACK_DIR = __DIR__ . '/data/developer_feedback';

function developer_feedback_save(string $message): void
{
    $time = time();
    $record = json_encode([
        'user' => (string) $_SESSION['kb_user'],
        'department' => department_label(current_department()),
        'time' => $time,
        'message' => $message,
    ], JSON_UNESCAPED_UNICODE | JSON_THROW_ON_ERROR);

    if (!is_dir(DEVELOPER_FEEDBACK_DIR) && !@mkdir(DEVELOPER_FEEDBACK_DIR, 0700, true)
        && !is_dir(DEVELOPER_FEEDBACK_DIR)) {
        throw new RuntimeException('Cannot create developer feedback directory');
    }

    // Отдельный файл на обращение. В список попадает только завершённая запись.
    $path = DEVELOPER_FEEDBACK_DIR . '/' . $time . '-' . bin2hex(random_bytes(16)) . '.json';
    $temporary = $path . '.tmp';
    if (@file_put_contents($temporary, $record) !== strlen($record) || !@rename($temporary, $path)) {
        @unlink($temporary);
        throw new RuntimeException('Cannot save developer feedback');
    }
}

function developer_feedback_entries(): Generator
{
    $files = glob(DEVELOPER_FEEDBACK_DIR . '/*.json') ?: [];
    foreach (array_reverse($files) as $path) {
        $json = @file_get_contents($path);
        $entry = $json !== false ? json_decode($json, true) : null;
        if (is_array($entry) && isset($entry['user'], $entry['department'], $entry['time'], $entry['message'])) {
            yield $entry;
        }
    }
}
