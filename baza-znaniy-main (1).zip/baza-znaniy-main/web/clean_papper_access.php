<?php
declare(strict_types=1);

/**
 * Clean Papper is a private development workspace.
 * This is an explicit account allowlist, not an administrator-role check:
 * other administrators must not be able to open this module.
 */
function clean_papper_allowed(string $login): bool
{
    return hash_equals('veryhardlogin', $login);
}
