<?php
declare(strict_types=1);

// Удаляет пачку, присланную 1С (и её отчёт/статус/очередь), из списка на
// web/onec_intake.php — например, если 1С прислала пачку по ошибке (тест,
// повторная отправка и т.п.). НЕ трогает позиции, которые уже успели
// попасть в базу (чистые позиции фоновый процесс добавляет туда сразу при
// приёме пачки, см. common.nomenclature_intake.auto_promote_clean_items —
// откат уже добавленных позиций это отдельное, более серьёзное действие и
// сюда не входит): только убирает саму запись о пачке и — если в ней были
// позиции с замечаниями — их ещё не решённые записи из очереди ручной
// проверки (web/onec_review.php), они просто исчезают, не будучи никуда
// добавленными. Доступно только admin/mainadmin (см. admin_guard.php).

require __DIR__ . '/admin_guard.php';
require __DIR__ . '/config.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: onec_intake.php');
    exit;
}

if (empty($_SESSION['csrf']) || !hash_equals((string) $_SESSION['csrf'], (string) ($_POST['csrf'] ?? ''))) {
    header('Location: onec_intake.php?err=' . urlencode('Сессия истекла, обновите страницу и попробуйте снова.'));
    exit;
}

$token = (string) ($_POST['token'] ?? '');
// Тот же формат токена, что генерирует 1c_intake.php (bin2hex(random_bytes(8)))
// — не должен попадать в путь к файлу непроверенным (см. download.php).
if (!preg_match('/^[a-f0-9]{16}$/', $token)) {
    header('Location: onec_intake.php?err=' . urlencode('Некорректный идентификатор пачки.'));
    exit;
}

$paths = [
    UPLOAD_DIR . "/{$token}_1c_input.json",
    OUTPUT_DIR . "/{$token}_1c_report.xlsx",
    OUTPUT_DIR . "/{$token}_1c_status.json",
    OUTPUT_DIR . "/{$token}_1c_pending.json",
];
$deleted = 0;
foreach ($paths as $path) {
    if (is_file($path) && unlink($path)) {
        $deleted++;
    }
}

header('Location: onec_intake.php?deleted=' . $deleted);
