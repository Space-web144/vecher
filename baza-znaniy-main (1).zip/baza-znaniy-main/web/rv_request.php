<?php
declare(strict_types=1);

// Запросить у 1С смету из «Полноты ЛРВ» (rv.php?node=lrv): ЛРВ есть в 1С, а на сайте сметы нет или ЛРВ изменилась
// после РВ. Запрашивают руководитель и ответственный за смету. 1С забирает запросы регламентом
// (GET 1c_rv.php?action=requests), отправляет смету и включает ей автообмен (rv_onec_lib.php).

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require_once __DIR__ . '/users.php';
require_once __DIR__ . '/lib.php';
require_once __DIR__ . '/rv_lib.php';
require_once __DIR__ . '/rv_onec_lib.php';

rv_guard();

$back = 'rv.php?node=lrv';
$go = static function (string $key, string $message) use ($back): never {
    header('Location: ' . $back . '&' . $key . '=' . rawurlencode($message));
    exit;
};
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ' . $back);
    exit;
}
if (!hash_equals(rv_csrf(), (string) ($_POST['csrf'] ?? ''))) {
    $go('err', 'Форма устарела, обновите страницу.');
}
$smetaId = rv_onec_guid((string) ($_POST['smeta_id'] ?? ''));
$lrv = rv_completeness();
$entry = null;
foreach (array_merge($lrv['missing'] ?? [], $lrv['stale'] ?? []) as $e) {
    if ($e['smeta_id'] === $smetaId) {
        $entry = $e;
        break;
    }
}
if ($smetaId === '' || $entry === null) {
    $go('err', 'Этой сметы нет среди расхождений — возможно, 1С уже прислала её. Обновите страницу.');
}
$me = (string) ($_SESSION['kb_user'] ?? '');
if (!rv_is_manager() && (string) ($entry['responsible']['user'] ?? '') !== $me) {
    $go('err', 'Запросить смету может руководитель или ответственный за неё.');
}
try {
    $go('ok', rv_request_add($smetaId, (string) $entry['lrv_id'], (string) $entry['smeta'], $me));
} catch (Throwable $e) {
    $go('err', 'Не удалось записать запрос: ' . $e->getMessage());
}
