<?php
declare(strict_types=1);

/**
 * JSON-ручка чата «Ассистент» (web/agent.php, assets/agent.js).
 *
 *   GET  ?action=poll&chat=<id>          — состояние чата; страница
 *                                           опрашивает его, пока ждёт ответа;
 *   POST action=upload_chunk, batch, index, offset, chunk — часть вложения;
 *   POST action=upload_discard, batch    — удалить незавершённую загрузку;
 *   POST action=send, chat=<id>|'', text, batch, attachments — вопрос со
 *                                           списком собранных вложений;
 *                                           files[] принимаются от старых страниц;
 *   POST action=retry, chat=<id>         — задать ещё раз вопрос, на который
 *                                           ответа не было.
 * POST — с токеном формы csrf.
 *
 * Сам ответ модели здесь не ждём: вопрос пишется в файл чата, ответ
 * готовит фоновый процесс (common/web_agent_chat.py).
 *
 * Отвечает {"ok":true,"chat":{…}} или {"ok":false,"error":"…"}.
 */

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require __DIR__ . '/agent_lib.php';
require_once __DIR__ . '/design.php';
require_once __DIR__ . '/users.php';
// ini_bytes/megabytes — пределы загрузки сервера, как у Verrata.
require_once __DIR__ . '/lib.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');

/** @return never */
function agent_reply(array $payload, int $code = 200)
{
    http_response_code($code);
    echo json_encode($payload, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}

$user = (string) ($_SESSION['kb_user'] ?? '');
$csrf = agent_csrf();
// Сессия дальше не меняется — отпускаем её файл, иначе опрос и отправка
// из соседней вкладки ждали бы друг друга.
session_write_close();

$action = (string) ($_GET['action'] ?? $_POST['action'] ?? '');

try {
    $dir = agent_user_dir($user);

    if ($action === 'poll') {
        $id = (string) ($_GET['chat'] ?? '');
        if (!agent_valid_id($id)) {
            throw new AgentFail('Неверный номер чата.', 400);
        }
        $chat = agent_locked($dir, function () use ($dir, $id) {
            $path = agent_chat_path($dir, $id);
            $chat = agent_read_chat($path);
            if ($chat !== null && agent_expire_pending($chat)) {
                agent_write_chat($path, $chat);
            }
            return $chat;
        });
        if ($chat === null) {
            throw new AgentFail('Чат не найден — возможно, его удалили.', 404);
        }
        $chat['id'] = $id;
        agent_reply(['ok' => true, 'chat' => agent_public_chat($chat)]);
    }

    if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
        throw new AgentFail('Ожидался POST-запрос.', 405);
    }
    // Запрос больше post_max_size: PHP молча выбрасывает и файлы, и поля
    // формы — без этой проверки пользователь увидел бы «Страница устарела».
    $contentLength = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);
    if (!$_POST && !$_FILES && $contentLength > 0) {
        $postLimit = ini_bytes('post_max_size');
        throw new AgentFail('Запрос больше, чем сервер принимает за одну отправку'
            . ($postLimit > 0 ? ' (' . megabytes($postLimit) . ' МБ)' : '') . '.', 413);
    }
    if (!hash_equals($csrf, (string) ($_POST['csrf'] ?? ''))) {
        throw new AgentFail('Страница устарела — обновите её и повторите.', 403);
    }
    if (!agent_configured()) {
        throw new AgentFail('Ассистент не настроен на этом сервере: нет файла с ключом Anthropic.', 503);
    }

    $batch = (string) ($_POST['batch'] ?? '');
    if ($action === 'upload_chunk' || $action === 'upload_discard') {
        agent_locked($dir, function () use ($user, $action, $batch) {
            $uploadDir = agent_upload_dir($user);
            if ($action === 'upload_discard') {
                agent_remove_upload_batch(agent_upload_batch_path($uploadDir, $batch));
                return;
            }
            $index = filter_var($_POST['index'] ?? '', FILTER_VALIDATE_INT);
            $offset = filter_var($_POST['offset'] ?? '', FILTER_VALIDATE_INT);
            agent_stage_upload_chunk($uploadDir, $batch, $index === false ? -1 : $index,
                $offset === false ? -1 : $offset, (array) ($_FILES['chunk'] ?? []));
        });
        agent_reply(['ok' => true]);
    }

    $id = (string) ($_POST['chat'] ?? '');
    if ($id !== '' && !agent_valid_id($id)) {
        throw new AgentFail('Неверный номер чата.', 400);
    }

    $text = '';
    $files = [];
    $manifest = (string) ($_POST['attachments'] ?? '');
    $useVps = ($_POST['processing'] ?? '') === 'vps';
    if ($action === 'send') {
        $text = trim(str_replace(["\r\n", "\r"], "\n", (string) ($_POST['text'] ?? '')));
        $files = agent_collect_uploads();
        if (($batch !== '' && $files) || ($batch === '' && $manifest !== '')) {
            throw new AgentFail('Неверные параметры вложений.', 400);
        }
        if ($text === '' && !$files && $batch === '') {
            throw new AgentFail('Напишите вопрос или прикрепите файл.', 400);
        }
        if (mb_strlen($text) > AGENT_MAX_MESSAGE_CHARS) {
            throw new AgentFail('Сообщение длиннее ' . number_format(AGENT_MAX_MESSAGE_CHARS, 0, ',', ' ')
                . ' знаков — сократите его или разбейте на несколько вопросов.', 400);
        }
    } elseif ($action === 'retry') {
        if ($id === '') {
            throw new AgentFail('Не указан чат.', 400);
        }
    } else {
        throw new AgentFail('Неизвестное действие.', 400);
    }

    [$chat, $requestId] = agent_locked($dir, function () use ($dir, $id, $action, $text, $files, $user, $batch, $manifest, $useVps) {
        $staged = null;
        $chats = agent_load_chats($dir);
        if ($action === 'send' && $batch !== '') {
            $staged = agent_upload_batch_path(agent_upload_dir($user), $batch);
            // Если ответ на POST потерялся в сети, возвращаем уже записанный вопрос.
            foreach ($chats as $previous) {
                if ($id !== '' && $previous['id'] !== $id) {
                    continue;
                }
                foreach ($previous['messages'] as $message) {
                    if (($message['upload_batch'] ?? null) === $batch) {
                        return [$previous, null];
                    }
                }
            }
            $files = agent_staged_uploads($staged, $manifest);
        }
        if ($id === '') {
            $chat = agent_new_chat($text, $files);
        } elseif (isset($chats[$id])) {
            $chat = $chats[$id];
        } else {
            throw new AgentFail('Чат не найден — возможно, его удалили.', 404);
        }

        // Один вопрос в работе на пользователя: каждый ответ — отдельный
        // процесс на хостинге с лимитом процессов, и каждый оплачивается.
        foreach ($chats as $otherId => $other) {
            if (!empty($other['pending'])) {
                // (string): номер чата из одних цифр PHP хранит в ключе числом.
                throw new AgentFail((string) $otherId === $chat['id']
                    ? (design_refresh() ? 'Альфик' : 'Ассистент') . ' ещё отвечает на предыдущий вопрос.'
                    : (design_refresh() ? 'Альфик' : 'Ассистент') . ' ещё отвечает в другом чате — дождитесь ответа там.', 409);
            }
        }

        if ($action === 'send') {
            if ($useVps && !$files) {
                throw new AgentFail('Прикрепите файлы для обработки на VPS.', 400);
            }
            if ($useVps && !agent_vps_available()) {
                throw new AgentFail('Обработка на VPS сейчас недоступна. Повторите позже.', 503);
            }
            if (count($chat['messages']) + 2 > AGENT_MAX_MESSAGES) {
                throw new AgentFail('Чат стал слишком длинным — начните новый.', 409);
            }
            $message = ['role' => 'user', 'text' => $text, 'time' => time()];
            if ($useVps) {
                $message['processing'] = 'vps';
            }
            if ($staged !== null) {
                $message['upload_batch'] = $batch;
            }
            if ($files) {
                $message['attachments'] = agent_store_uploads($files, agent_upload_dir($user), $staged !== null);
            }
            $chat['messages'][] = $message;
        } else {
            $last = count($chat['messages']) - 1;
            if ($last < 0 || ($chat['messages'][$last]['role'] ?? '') !== 'user'
                || empty($chat['messages'][$last]['error'])) {
                throw new AgentFail('Повторять нечего: на последний вопрос ответ уже есть.', 409);
            }
            $retryVps = ($chat['messages'][$last]['processing'] ?? '') === 'vps';
            if ($retryVps && !agent_vps_available()) {
                throw new AgentFail('Обработка на VPS сейчас недоступна. Повторите позже.', 503);
            }
            foreach ($chat['messages'][$last]['attachments'] ?? [] as $file) {
                $ready = $retryVps ? (($file['status'] ?? '') === 'new' && is_file($file['path'] ?? ''))
                    : ($file['status'] ?? '') === 'ok';
                if (!$ready) {
                    throw new AgentFail('Файлы этого вопроса не обработаны — прикрепите их заново '
                        . 'в новом сообщении.', 409);
                }
            }
            unset($chat['messages'][$last]['error']);
        }

        $requestId = agent_start_pending($chat);
        try {
            agent_write_chat(agent_chat_path($dir, $chat['id']), $chat);
        } catch (RuntimeException $e) {
            // Вопрос не записан — его файлы никто не подхватит.
            if ($action === 'send') {
                foreach (end($chat['messages'])['attachments'] ?? [] as $file) {
                    if (($file['status'] ?? '') === 'new') {
                        @unlink((string) $file['path']);
                    }
                }
            }
            throw $e;
        }
        if ($staged !== null) {
            agent_remove_upload_batch($staged);
        }
        return [$chat, $requestId];
    });

    if ($requestId === null) {
        agent_reply(['ok' => true, 'chat' => agent_public_chat($chat)]);
    }

    // Журнал вопросов для анализа: текст, имена файлов, кто и когда.
    $asked = end($chat['messages']) ?: [];
    agent_log_event([
        't' => 'question',
        'time' => time(),
        'request' => $requestId,
        'user' => $user,
        'dept' => (string) (current_department() ?? ''),
        'chat' => (string) $chat['id'],
        'title' => (string) ($chat['title'] ?? ''),
        'action' => $action,
        'n' => count(array_filter($chat['messages'], static fn(array $m): bool => ($m['role'] ?? '') === 'user')),
        'text' => (string) ($asked['text'] ?? ''),
        'files' => array_map(static fn(array $f): array => ['name' => (string) ($f['name'] ?? ''), 'size' => (int) ($f['size'] ?? 0)],
            (array) ($asked['attachments'] ?? [])),
    ]);
    agent_launch($dir, $chat['id'], $requestId);
    agent_reply(['ok' => true, 'chat' => agent_public_chat($chat)]);
} catch (AgentFail $e) {
    agent_reply(['ok' => false, 'error' => $e->getMessage()], $e->getCode() ?: 400);
} catch (RuntimeException $e) {
    agent_reply(['ok' => false, 'error' => $e->getMessage()], 500);
}
