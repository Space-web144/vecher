<?php
declare(strict_types=1);

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require __DIR__ . '/lib.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    fail('Ожидался POST-запрос.', 405);
}

if (empty($_FILES['spec_file']) || $_FILES['spec_file']['error'] === UPLOAD_ERR_NO_FILE) {
    fail('Файл спецификации не выбран.');
}

$upload = $_FILES['spec_file'];
if ($upload['error'] !== UPLOAD_ERR_OK) {
    fail('Ошибка загрузки файла (код ' . $upload['error'] . ').');
}
if ($upload['size'] > MAX_UPLOAD_BYTES) {
    fail('Файл слишком большой (максимум ' . intdiv(MAX_UPLOAD_BYTES, 1024 * 1024) . ' МБ).');
}

$ext = strtolower(pathinfo($upload['name'], PATHINFO_EXTENSION));
if (!in_array($ext, ['xlsx', 'xls'], true)) {
    fail('Допустимы только файлы .xlsx / .xls.');
}

$mode = $_POST['mode'] ?? 'full';
if (!in_array($mode, ['full', 'match', 'fitting', 'area'], true)) {
    fail('Некорректный режим обработки.');
}

if (!in_array($mode, ['fitting', 'area'], true) && !is_file(DB_FILE)) {
    fail('База номенклатуры 1С не найдена на сервере (' . DB_FILE . '). Обратитесь к администратору.', 500);
}

if (!is_dir(UPLOAD_DIR) || !is_writable(UPLOAD_DIR)) {
    fail('Папка для загрузок недоступна на сервере.', 500);
}
if (!is_dir(OUTPUT_DIR) || !is_writable(OUTPUT_DIR)) {
    fail('Папка для результатов недоступна на сервере.', 500);
}

// Не доверяем оригинальному имени файла — своё безопасное имя на базе
// случайного токена.
$token = bin2hex(random_bytes(8));
$specPath = UPLOAD_DIR . "/{$token}_spec.xlsx";

if (!move_uploaded_file($upload['tmp_name'], $specPath)) {
    fail('Не удалось сохранить загруженный файл.', 500);
}

$displayBase = sanitize_display_base(pathinfo($upload['name'], PATHINFO_FILENAME));

$outputPath = OUTPUT_DIR . "/{$token}_result.xlsx";
$statusPath = OUTPUT_DIR . "/{$token}_status.json";
$logFile = OUTPUT_DIR . '/python_errors.log';

$cmdParts = [
    escapeshellarg(PYTHON_BIN),
    escapeshellarg(WEB_RUN_SCRIPT),
    '--spec', escapeshellarg($specPath),
    '--mode', escapeshellarg($mode),
    '--output', escapeshellarg($outputPath),
    '--status-file', escapeshellarg($statusPath),
    '--display-base', escapeshellarg($displayBase),
];
// Tier 3 (Claude выбирает позицию базы среди кандидатов Tier 2):
// передаётся только ПУТЬ к файлу с ключом Anthropic — ключ читает сам
// процесс Python (см. common/anthropic_client.py), PHP его не открывает.
// Путь передаётся, даже если файла нет: тогда в отчёте будет написано,
// что Tier 3 не подключён и почему, а не молчаливый ноль.
if (!in_array($mode, ['fitting', 'area'], true)) {
    $cmdParts[] = '--db';
    $cmdParts[] = escapeshellarg(DB_FILE);
    $cmdParts[] = '--report-folder';
    $cmdParts[] = escapeshellarg(OUTPUT_DIR);

    if (defined('ANTHROPIC_CREDENTIALS_FILE') && ANTHROPIC_CREDENTIALS_FILE !== '') {
        $cmdParts[] = '--claude-credentials';
        $cmdParts[] = escapeshellarg(ANTHROPIC_CREDENTIALS_FILE);
    }
}

// Большие спецификации (тысячи строк) обрабатываются дольше, чем живёт
// HTTP-соединение с браузером/прокси хостинга — поэтому не ждём здесь
// (никакого shell_exec с блокировкой): запускаем в фоне и сразу отдаём
// страницу опроса статуса. "nohup ... &" отвязывает процесс от этого
// PHP-запроса, чтобы он не оборвался вместе с ответом браузеру.
// stderr — в лог-файл, не в /dev/null, чтобы ошибки было видно при отладке.
$cmd = 'nohup ' . implode(' ', $cmdParts) . ' >> ' . escapeshellarg($logFile)
     . ' 2>&1 &';
exec($cmd);

header('Location: status.php?token=' . urlencode($token));
exit;
