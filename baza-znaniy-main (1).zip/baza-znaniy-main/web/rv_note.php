<?php
declare(strict_types=1);

// Замечание инженера к агенту РВ в свободной форме — со страницы готовой РВ
// (rv_status.php): что доработать, что агенту нужно знать. Строка JSON
// дописывается в RV_NOTES_FILE (кто, когда, по какой РВ, разделы, текст).
// Последние замечания агент передаёт модели при проверке строк следующих РВ
// (web_rv_run.py --notes-file), все видны на странице «РВ по ЛРВ» тем, кто
// ведёт агента.

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require_once __DIR__ . '/users.php';
require_once __DIR__ . '/lib.php';
require_once __DIR__ . '/rv_lib.php';

rv_guard();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: rv.php');
    exit;
}
$token = (string) ($_POST['token'] ?? '');
if (!rv_token_valid($token)) {
    rv_fail('Неверный номер задачи.');
}
$back = 'rv_status.php?token=' . urlencode($token);
if (!hash_equals(rv_csrf(), (string) ($_POST['csrf'] ?? ''))) {
    header('Location: ' . $back . '&note=expired#rv-notes');
    exit;
}
[$job] = rv_own_job($token);
$text = trim(str_replace("\r\n", "\n", (string) ($_POST['text'] ?? '')));
if ($text === '') {
    header('Location: ' . $back . '#rv-notes');
    exit;
}
if (mb_strlen($text) > RV_NOTE_MAX_CHARS) {
    $text = mb_substr($text, 0, RV_NOTE_MAX_CHARS);
}
$status = rv_read_json(rv_paths($token)['status']) ?? [];
$note = [
    'when' => time(),
    'user' => (string) ($_SESSION['kb_user'] ?? ''),
    'token' => $token,
    'source_name' => (string) ($job['source_name'] ?? ''),
    'sections' => array_values((array) (($status['summary'] ?? [])['sections'] ?? [])),
    'text' => $text,
];
$dir = dirname(RV_NOTES_FILE);
if (!is_dir($dir)) {
    @mkdir($dir, 0775, true);
}
if (file_put_contents(RV_NOTES_FILE, json_encode($note, JSON_UNESCAPED_UNICODE) . "\n", FILE_APPEND | LOCK_EX) === false) {
    rv_fail('Не удалось сохранить замечание на сервере.', 500);
}
header('Location: ' . $back . '&note=saved#rv-notes');
exit;
