<?php
declare(strict_types=1);

// Контроль полноты ЛРВ и факт по строкам ЛРВ из 1С (модуль СайтРВ_Обмен, область «КонтрольПолноты»).
//
// Эталон (событие «Эталон», раз в несколько часов): все сметы 1С с плановыми остатками ЛРВ — строк, количество,
// дата последнего изменения ЛРВ, когда модуль отправлял смету на сайт, — и группы остатков (НГ, Аналитика 1–4),
// которые не берёт ни одна смета. Сайт сверяет эталон со своим реестром (rv_completeness): «есть ЛРВ — нет на сайте»,
// «ЛРВ изменилась после РВ», «ЛРВ без сметы».
// Факт (событие «ФактЛРВ», после каждой отправки сметы и с эталоном): по строкам ЛРВ сметы — документ ЛРВ,
// стоимость по плану, поступило по приходным ордерам. Нужен модулю «ТКП заказчика ↔ РВ 1С» (этап 4).
// Запросы (rv_request.php → GET 1c_rv.php?action=requests): руководитель или ответственный просит 1С прислать
// смету; регламент 1С забирает запросы, отправляет сметы и отвечает событием «ЗапросВыполнен».
// Файлы — RV_1C_CATALOG_FILE, RV_1C_FACT_DIR/<СметаGUID>.json, RV_1C_REQUESTS_FILE (в web/data, в репозиторий не идут).

require_once __DIR__ . '/rv_lib.php';

const RV_REQUEST_TTL = 2 * 86400;          // запрос, взятый 1С и без ответа дольше, считается «1С не ответила»
const RV_CATALOG_STALE_SEC = 60;           // ЛРВ «изменилась после РВ», если позже отправки больше чем на минуту

/** JSON-файл под блокировкой: $change(array $data): [array $data, mixed $result]. */
function rv_onec_locked(string $file, callable $change)
{
    $dir = dirname($file);
    if (!is_dir($dir) && !mkdir($dir, 0775, true) && !is_dir($dir)) {
        throw new RuntimeException('Нет каталога данных.');
    }
    $fh = fopen($file, 'c+');
    if ($fh === false) {
        throw new RuntimeException('Не открыть файл данных.');
    }
    try {
        flock($fh, LOCK_EX);
        $data = json_decode((string) stream_get_contents($fh), true);
        [$data, $result] = $change(is_array($data) ? $data : []);
        ftruncate($fh, 0);
        rewind($fh);
        fwrite($fh, json_encode($data, JSON_UNESCAPED_UNICODE));
        fflush($fh);
        return $result;
    } finally {
        flock($fh, LOCK_UN);
        fclose($fh);
    }
}

/** Дата 1С «2026-11-08T10:15:00» → метка времени сервера; пусто или не дата — 0. */
function rv_onec_time($value): int
{
    $value = trim((string) $value);
    if ($value === '' || str_starts_with($value, '0001')) {
        return 0;
    }
    $time = strtotime($value);
    return $time === false ? 0 : $time;
}

function rv_onec_num($value): float
{
    return is_numeric(str_replace([',', ' '], ['.', ''], (string) $value)) ? (float) str_replace([',', ' '], ['.', ''], (string) $value) : 0.0;
}

function rv_onec_str($value, int $max = 150): string
{
    return is_scalar($value) ? mb_substr(trim((string) $value), 0, $max) : '';
}

function rv_onec_guid($value): string
{
    $value = strtolower(trim((string) $value));
    return preg_match('/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/', $value) ? $value : '';
}

// ── Эталон ──

/**
 * Принять эталон из 1С: привести к виду сайта и сохранить целиком (прежний заменяется).
 * Возвращает ['smetas' => n, 'nosmeta' => n].
 */
function rv_catalog_save(array $data): array
{
    $smetas = [];
    foreach ((array) ($data['Сметы'] ?? []) as $item) {
        if (!is_array($item)) {
            continue;
        }
        $guid = rv_onec_guid($item['СметаGUID'] ?? '');
        $lrvId = rv_onec_str($item['ИдентификаторЛРВ'] ?? '', 120);
        if ($guid === '' && $lrvId === '') {
            continue;
        }
        $smetas[] = [
            'lrv_id' => $lrvId !== '' ? $lrvId : 'Смета-' . $guid,
            'smeta_id' => $guid,
            'smeta' => rv_onec_str($item['Смета'] ?? ''),
            'object' => rv_onec_str($item['Объект'] ?? ''),
            'folder' => rv_onec_str($item['ПапкаНГ'] ?? ''),
            'folder_id' => rv_onec_guid($item['ПапкаНГGUID'] ?? ''),
            'obj' => rv_onec_str($item['НоменклатурнаяГруппа'] ?? ''),
            'obj_id' => rv_onec_guid($item['НоменклатурнаяГруппаGUID'] ?? ''),
            'system' => rv_onec_str($item['СистемаСметы'] ?? ''),
            'group4' => rv_onec_str($item['Аналитика4'] ?? ''),
            'zn' => rv_onec_str($item['НомерЗН'] ?? ''),
            'rows' => (int) rv_onec_num($item['Строк'] ?? 0),
            'qty' => rv_onec_num($item['Количество'] ?? 0),
            'changed' => rv_onec_str($item['ДатаИзменения'] ?? '', 25),
            'sent' => rv_onec_str($item['ДатаОтправки'] ?? '', 25),
            'token' => rv_onec_str($item['Токен'] ?? '', 40),
            'auto' => !empty($item['Автообмен']),
        ];
    }
    $nosmeta = [];
    foreach ((array) ($data['БезСметы'] ?? []) as $item) {
        if (!is_array($item)) {
            continue;
        }
        $row = [
            'obj' => rv_onec_str($item['НоменклатурнаяГруппа'] ?? ''),
            'obj_id' => rv_onec_guid($item['НоменклатурнаяГруппаGUID'] ?? ''),
            'rows' => (int) rv_onec_num($item['Строк'] ?? 0),
            'qty' => rv_onec_num($item['Количество'] ?? 0),
            'changed' => rv_onec_str($item['ДатаИзменения'] ?? '', 25),
        ];
        for ($i = 1; $i <= 4; $i++) {
            $row['a' . $i] = rv_onec_str($item['Аналитика_' . $i . '_Имя'] ?? '');
        }
        $nosmeta[] = $row;
    }
    $catalog = ['at' => time(), 'version' => rv_onec_str($data['Версия'] ?? '', 25), 'smetas' => $smetas, 'nosmeta' => $nosmeta];
    $dir = dirname(RV_1C_CATALOG_FILE);
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
    $tmp = RV_1C_CATALOG_FILE . '.tmp';
    file_put_contents($tmp, json_encode($catalog, JSON_UNESCAPED_UNICODE));
    rename($tmp, RV_1C_CATALOG_FILE);
    return ['smetas' => count($smetas), 'nosmeta' => count($nosmeta)];
}

function rv_catalog(): ?array
{
    return defined('RV_1C_CATALOG_FILE') ? rv_read_json(RV_1C_CATALOG_FILE) : null;
}

/**
 * Сверка эталона с реестром сайта. $rows — строки реестра (rv_registry_rows), если уже посчитаны.
 * Возвращает ['at', 'version', 'missing' => [...], 'stale' => [...], 'nosmeta' => [...]]; у смет — meta дерева
 * (объект, корпус, система, вид работ), ответственный и запрос к 1С, если есть. Архивные объекты не попадают.
 * Без эталона — null.
 */
function rv_completeness(?array $rows = null): ?array
{
    $catalog = rv_catalog();
    if ($catalog === null) {
        return null;
    }
    $rows ??= rv_registry_rows();
    $byId = [];
    foreach ($rows as $row) {
        $byId[(string) $row['id']] = $row;
    }
    $objects = rv_objects();
    $assign = rv_assignments();
    $requests = rv_requests();
    $out = ['at' => (int) ($catalog['at'] ?? 0), 'version' => (string) ($catalog['version'] ?? ''),
            'missing' => [], 'stale' => [], 'nosmeta' => []];
    foreach ((array) ($catalog['smetas'] ?? []) as $item) {
        $row = $byId[(string) $item['lrv_id']] ?? null;
        $onSite = $row !== null && (string) $row['code'] !== 'gone' && (int) $row['versions'] > 0;
        $changed = rv_onec_time($item['changed'] ?? '');
        $sent = rv_onec_time($item['sent'] ?? '');
        // «Изменилась после РВ»: дата изменения ЛРВ позже отправки (обе — часы 1С); 1С не знает, когда отправляла
        // (смету слали обработкой) — сравниваем с получением на сайте.
        $after = $onSite && $changed > 0
            && ($sent > 0 ? $changed > $sent + RV_CATALOG_STALE_SEC : $changed > (int) $row['received'] + RV_CATALOG_STALE_SEC);
        if ($onSite && !$after) {
            continue;
        }
        if ($onSite) {
            $meta = $row;
        } else {
            $job = ['object' => (string) $item['object'], 'lrv_id' => (string) $item['lrv_id'], 'meta' => [
                'obj' => (string) $item['obj'], 'obj_id' => (string) $item['obj_id'], 'system' => (string) $item['system'],
                'smeta' => (string) $item['smeta'], 'smeta_id' => (string) $item['smeta_id'],
                'folder' => (string) $item['folder'], 'folder_id' => (string) $item['folder_id'], 'zn' => (string) $item['zn'],
                'kind' => rv_kind_of((string) $item['smeta'], (string) $item['zn'], (string) $item['group4']),
            ]];
            $meta = rv_table_meta(rv_registry_meta($job, $objects));
            $meta['responsible'] = rv_responsible($assign, $meta);
        }
        if (!empty($meta['match']['archived'])) {
            continue;
        }
        $entry = $item + [
            'folder_key' => (string) ($meta['folder_key'] ?? ''), 'object_name' => (string) ($meta['folder'] ?? ''),
            'building_label' => (string) ($meta['building_label'] ?? ''), 'table_system' => (string) ($meta['table_system'] ?? ''),
            'work_kind' => (string) ($meta['work_kind'] ?? ''), 'responsible' => $meta['responsible'] ?? null,
            'changed_at' => $changed, 'sent_at' => $sent, 'site_token' => $onSite ? (string) $row['token'] : '',
            'site_received' => $onSite ? (int) $row['received'] : 0, 'site_code' => $onSite ? (string) $row['code'] : '',
            'request' => $requests[(string) $item['smeta_id']] ?? null,
        ];
        $out[$onSite ? 'stale' : 'missing'][] = $entry;
    }
    foreach ((array) ($catalog['nosmeta'] ?? []) as $item) {
        $item['changed_at'] = rv_onec_time($item['changed'] ?? '');
        $out['nosmeta'][] = $item;
    }
    $order = static fn(array $a, array $b): int
        => [$a['object_name'] === '', mb_strtolower($a['object_name'] ?: $a['folder']), mb_strtolower($a['building_label']), mb_strtolower($a['smeta'])]
           <=> [$b['object_name'] === '', mb_strtolower($b['object_name'] ?: $b['folder']), mb_strtolower($b['building_label']), mb_strtolower($b['smeta'])];
    usort($out['missing'], $order);
    usort($out['stale'], $order);
    usort($out['nosmeta'], static fn(array $a, array $b): int => $b['changed_at'] <=> $a['changed_at']);
    return $out;
}

/** Записи сверки, которые касаются пользователя: руководитель видит все, сметчик — свои (по ответственному). */
function rv_completeness_for(array $entries, string $user, bool $all): array
{
    if ($all) {
        return $entries;
    }
    return array_values(array_filter($entries, static fn(array $e): bool => (string) ($e['responsible']['user'] ?? '') === $user));
}

// ── Факт по строкам ЛРВ ──

function rv_fact_path(string $smetaId): string
{
    return RV_1C_FACT_DIR . '/' . $smetaId . '.json';
}

/** Принять факт по строкам ЛРВ и сметным позициям сметы; тот же факт второй раз не пересохраняется. ['changed', 'rows', 'works']. */
function rv_fact_save(array $data): array
{
    $smetaId = rv_onec_guid($data['СметаGUID'] ?? '');
    if ($smetaId === '') {
        throw new InvalidArgumentException('Нужен «СметаGUID».');
    }
    $rows = [];
    foreach ((array) ($data['Строки'] ?? []) as $item) {
        if (!is_array($item)) {
            continue;
        }
        $key = rv_onec_str($item['ИдентификаторСтроки'] ?? '', 400);
        if ($key === '') {
            continue;
        }
        $rows[] = [
            'id' => $key,
            'name' => rv_onec_str($item['Номенклатура'] ?? '', 300),
            'nom_id' => rv_onec_guid($item['НоменклатураGUID'] ?? ''),
            'unit' => rv_onec_str($item['ЕдиницаИзмерения'] ?? '', 30),
            'qty' => rv_onec_num($item['Количество'] ?? 0),
            'qty_smeta' => rv_onec_num($item['КоличествоВСмету'] ?? 0),
            'qty_fact' => rv_onec_num($item['КоличествоФакт'] ?? 0),
            'cost' => rv_onec_num($item['Стоимость'] ?? 0),
            'cost_smeta' => rv_onec_num($item['СтоимостьВСмету'] ?? 0),
            'position_id' => rv_onec_guid($item['СметнаяПозиция_GUID'] ?? ''),
            'zn' => rv_onec_str($item['НомерЗН'] ?? '', 60),
            'lrv_doc' => rv_onec_str($item['ДокументЛРВ'] ?? '', 200),
            'lrv_doc_id' => rv_onec_guid($item['ДокументЛРВGUID'] ?? ''),
            'lrv_date' => rv_onec_str($item['ДатаЛРВ'] ?? '', 25),
            'lrv_last' => rv_onec_str($item['ПоследнийДокументЛРВ'] ?? '', 200),
            'lrv_changed' => rv_onec_str($item['ДатаИзмененияЛРВ'] ?? '', 25),
            'received_qty' => rv_onec_num($item['Поступило'] ?? 0),
            'received_cost' => rv_onec_num($item['СтоимостьПоступления'] ?? 0),
            'received_date' => rv_onec_str($item['ДатаПоступления'] ?? '', 25),
        ];
    }
    // Экономика сметных позиций (бит_стр_СметныеПозиции, срез последних): цена сметы, «по смете» заказчика —
    // для таблицы «ТКП заказчика ↔ РВ 1С». В пакет РВ она не входит: сайт хэширует строки и работы РВ целиком.
    $works = [];
    foreach ((array) ($data['РаботыСметы'] ?? []) as $item) {
        if (!is_array($item)) {
            continue;
        }
        $code = rv_onec_str($item['Код'] ?? $item['КодИСР'] ?? '', 60);
        $position = rv_onec_guid($item['СметнаяПозицияGUID'] ?? '');
        if ($code === '' && $position === '') {
            continue;
        }
        $works[] = [
            'code' => $code, 'position_id' => $position,
            'name' => rv_onec_str($item['Наименование'] ?? '', 300),
            'unit' => rv_onec_str($item['ЕдиницаИзмерения'] ?? '', 30),
            'qty' => rv_onec_num($item['Количество'] ?? 0),
            'price' => rv_onec_num($item['Цена'] ?? 0),
            'qty_customer' => rv_onec_num($item['КоличествоПоСмете'] ?? 0),
            'unit_customer' => rv_onec_str($item['ЕдиницаИзмеренияПоСмете'] ?? '', 30),
            'price_customer' => rv_onec_num($item['ЦенаЗаказчика'] ?? 0),
            'sum_customer' => rv_onec_num($item['СуммаПоСмете'] ?? 0),
            'mat_cost' => rv_onec_num($item['СтоимостьМатериалов'] ?? 0),
            'mat_cost_customer' => rv_onec_num($item['СтоимостьМатериаловПоСмете'] ?? 0),
            'name_customer' => rv_onec_str($item['СметноеНаименование'] ?? '', 300),
            'virtual' => !empty($item['Виртуальная']),
        ];
    }
    $hash = hash('sha256', json_encode([$rows, $works], JSON_UNESCAPED_UNICODE));
    $path = rv_fact_path($smetaId);
    $old = rv_read_json($path);
    if (is_array($old) && (string) ($old['hash'] ?? '') === $hash) {
        return ['changed' => false, 'rows' => count($rows), 'works' => count($works)];
    }
    if (!is_dir(RV_1C_FACT_DIR) && !mkdir(RV_1C_FACT_DIR, 0775, true) && !is_dir(RV_1C_FACT_DIR)) {
        throw new RuntimeException('Нет каталога для факта ЛРВ.');
    }
    $fact = ['smeta_id' => $smetaId, 'smeta' => rv_onec_str($data['Смета'] ?? ''), 'lrv_id' => rv_onec_str($data['ИдентификаторЛРВ'] ?? '', 120),
             'version' => rv_onec_str($data['Версия'] ?? '', 25), 'at' => time(), 'hash' => $hash, 'rows' => $rows, 'works' => $works];
    $tmp = $path . '.tmp';
    file_put_contents($tmp, json_encode($fact, JSON_UNESCAPED_UNICODE));
    rename($tmp, $path);
    return ['changed' => true, 'rows' => count($rows), 'works' => count($works)];
}

function rv_fact(string $smetaId): ?array
{
    $smetaId = rv_onec_guid($smetaId);
    return $smetaId !== '' && defined('RV_1C_FACT_DIR') ? rv_read_json(rv_fact_path($smetaId)) : null;
}

// ── Запросы смет у 1С ──

/** Запросы по СметаGUID: ['smeta_id', 'lrv_id', 'title', 'user', 'at', 'state' => pending|taken|done|error, 'taken', 'done', 'message', 'token']. */
function rv_requests(): array
{
    $data = defined('RV_1C_REQUESTS_FILE') ? rv_read_json(RV_1C_REQUESTS_FILE) : null;
    return is_array($data) ? $data : [];
}

/** Запросить у 1С смету. Возвращает текст для сообщения. */
function rv_request_add(string $smetaId, string $lrvId, string $title, string $user): string
{
    $smetaId = rv_onec_guid($smetaId);
    if ($smetaId === '') {
        throw new InvalidArgumentException('Неверный идентификатор сметы.');
    }
    return rv_onec_locked(RV_1C_REQUESTS_FILE, static function (array $data) use ($smetaId, $lrvId, $title, $user): array {
        $old = $data[$smetaId] ?? null;
        if (is_array($old) && in_array($old['state'] ?? '', ['pending', 'taken'], true)
                && ($old['state'] === 'pending' || (int) ($old['taken'] ?? 0) > time() - RV_REQUEST_TTL)) {
            return [$data, 'Смета уже запрошена — 1С пришлёт её при ближайшем обмене (раз в 15 минут).'];
        }
        $data[$smetaId] = ['smeta_id' => $smetaId, 'lrv_id' => mb_substr($lrvId, 0, 120), 'title' => mb_substr($title, 0, 200),
                           'user' => $user, 'at' => time(), 'state' => 'pending'];
        return [$data, 'Смета запрошена у 1С: она придёт при ближайшем обмене (раз в 15 минут), РВ построится сама.'];
    });
}

/** Для 1С: запросы, которые ждут отправки (и взятые, но без ответа дольше суток), — помечаются взятыми. */
function rv_requests_take(): array
{
    return rv_onec_locked(RV_1C_REQUESTS_FILE, static function (array $data): array {
        $out = [];
        foreach ($data as $id => $request) {
            $state = (string) ($request['state'] ?? '');
            if ($state === 'pending' || ($state === 'taken' && (int) ($request['taken'] ?? 0) < time() - 86400)) {
                $data[$id]['state'] = 'taken';
                $data[$id]['taken'] = time();
                $out[] = ['СметаGUID' => (string) $id, 'ИдентификаторЛРВ' => (string) ($request['lrv_id'] ?? ''), 'Кто' => (string) ($request['user'] ?? '')];
            }
        }
        // Старше 60 дней — убрать: история не нужна.
        foreach ($data as $id => $request) {
            if (in_array($request['state'] ?? '', ['done', 'error'], true) && (int) ($request['done'] ?? 0) < time() - 60 * 86400) {
                unset($data[$id]);
            }
        }
        return [$data, $out];
    });
}

/** Ответ 1С на запрос: отправила смету или нет. */
function rv_request_done(string $smetaId, bool $ok, string $message, string $token): bool
{
    $smetaId = rv_onec_guid($smetaId);
    if ($smetaId === '') {
        return false;
    }
    return rv_onec_locked(RV_1C_REQUESTS_FILE, static function (array $data) use ($smetaId, $ok, $message, $token): array {
        if (!isset($data[$smetaId])) {
            return [$data, false];
        }
        $data[$smetaId]['state'] = $ok ? 'done' : 'error';
        $data[$smetaId]['done'] = time();
        $data[$smetaId]['message'] = mb_substr($message, 0, 500);
        $data[$smetaId]['token'] = rv_token_valid($token) ? $token : '';
        return [$data, true];
    });
}

/** Состояние запроса словами для таблицы. */
function rv_request_text(?array $request): string
{
    if ($request === null) {
        return '';
    }
    $who = (string) ($request['user'] ?? '') !== '' ? rv_person_label((string) $request['user']) . ', ' : '';
    switch ((string) ($request['state'] ?? '')) {
        case 'pending':
            return 'запрошено ' . $who . rv_when((int) $request['at']) . ' — ждём 1С';
        case 'taken':
            return (int) ($request['taken'] ?? 0) < time() - RV_REQUEST_TTL
                ? '1С взяла запрос и не ответила — запросите ещё раз'
                : '1С отправляет (взяла ' . rv_when((int) $request['taken']) . ')';
        case 'done':
            return '1С отправила ' . rv_when((int) ($request['done'] ?? 0));
        case 'error':
            return '1С не отправила: ' . (string) ($request['message'] ?? '');
    }
    return '';
}
