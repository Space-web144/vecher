<?php
declare(strict_types=1);

// Отдаёт файл, который ассистент создал в ответе (Excel, Word, PDF,
// график): common/web_agent_chat.py скачивает такие файлы из хранилища
// Anthropic в AGENT_OUTPUT_DIR/<пользователь>/<чат>/<id>.<расширение> и
// пишет их в сообщение ответа (поле files). Здесь — только по ссылке из
// своего чата: id чата и файла из запроса сверяются с записью в чате,
// путь на диске собирается здесь, а не приходит снаружи.

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require __DIR__ . '/agent_lib.php';

$user = (string) ($_SESSION['kb_user'] ?? '');
session_write_close();

function agent_file_fail(int $code, string $message): void
{
    http_response_code($code);
    header('Content-Type: text/plain; charset=utf-8');
    echo $message;
    exit;
}

$chatId = (string) ($_GET['chat'] ?? '');
$fileId = (string) ($_GET['file'] ?? '');
if (!agent_valid_id($chatId) || !agent_valid_id($fileId)) {
    agent_file_fail(400, 'Некорректный запрос.');
}

$dir = agent_user_dir($user);
$chat = agent_locked($dir, fn() => agent_read_chat(agent_chat_path($dir, $chatId)));
$record = null;
foreach ($chat['messages'] ?? [] as $message) {
    foreach ((array) ($message['files'] ?? []) as $file) {
        if (is_array($file) && hash_equals((string) ($file['id'] ?? ''), $fileId)) {
            $record = $file;
        }
    }
}
$ext = is_array($record) ? (string) ($record['ext'] ?? '') : '';
if ($record === null || !preg_match('/^[a-z0-9]{1,8}$/', $ext)) {
    agent_file_fail(404, 'Файл не найден — возможно, чат удалили или истёк срок хранения.');
}

$baseDir = realpath(AGENT_OUTPUT_DIR);
$path = realpath(agent_outputs_dir($dir) . '/' . $chatId . '/' . $fileId . '.' . $ext);
if ($baseDir === false || $path === false || strpos($path, $baseDir . DIRECTORY_SEPARATOR) !== 0
    || !is_file($path)) {
    agent_file_fail(404, 'Файл не найден на сервере.');
}

// Имя для диалога «Сохранить как» — как его назвал ассистент. Отдаём
// всегда как скачивание и без угадывания типа: HTML или SVG из ответа
// модели не должен открыться прямо на сайте.
$name = trim((string) preg_replace('/[\x00-\x1f\x7f"\\\\\/]+/u', '_', (string) ($record['name'] ?? '')));
if ($name === '') {
    $name = 'файл.' . $ext;
}
// Запасное имя латиницей — для старых браузеров без filename*.
$asciiBase = trim((string) preg_replace('/[^A-Za-z0-9._-]+/', '_', pathinfo($name, PATHINFO_FILENAME)), '_.');
$asciiName = ($asciiBase !== '' ? $asciiBase : 'file') . '.' . $ext;

header('Content-Type: application/octet-stream');
header('Content-Length: ' . (string) filesize($path));
header('Content-Disposition: attachment; filename="' . $asciiName . '"; '
    . "filename*=UTF-8''" . rawurlencode($name));
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store');
readfile($path);
