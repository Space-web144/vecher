<?php
declare(strict_types=1);

// Общие вещи блока «Оборудование» (сверка марок вентиляторов по альбому,
// см. equipment.php) — отдельно от lib.php, чтобы код блока не смешивался
// с общим кодом остальных страниц. Подключается после lib.php там, где
// обрабатываются запросы «Оборудования» (process_pdf.php).

// Подпись страницы ошибки для «Оборудования» — дополняет FAIL_PAGE_BRANDS
// из lib.php (см. fail() там же).
const OB_FAIL_PAGE_BRANDS = [
    'equipment.php' => ['Оборудование — ошибка', 'Оборудование'],
];

/**
 * Ключ Claude API и настройки доступа к нему.
 *
 * Возвращает ['api_key' => ..., 'model' => ..., 'proxy' => ...]; пустой
 * массив, если секретов нет — тогда блок работает без модели.
 *
 * Файл секретов бывает двух видов, и читаются они по-разному:
 *   *.php  — `return [...]`, подключается через require;
 *   *.json — читается и разбирается json_decode().
 *
 * JSON НЕЛЬЗЯ подключать через require: PHP не разбирает такой файл, а
 * печатает его содержимое в ответ — то есть выкладывает ключ прямо на
 * страницу пользователю (так и случилось однажды, см. историю правок).
 * Здесь оба вида читаются без единого echo, а ключ дальше уходит только
 * в переменную окружения дочернего процесса.
 */
function ob_claude_secrets(): array
{
    $candidates = [];
    if (defined('ANTHROPIC_SECRETS_FILE')) {
        $candidates[] = ANTHROPIC_SECRETS_FILE;
    }
    if (defined('ANTHROPIC_CREDENTIALS_FILE')) {
        $candidates[] = ANTHROPIC_CREDENTIALS_FILE;
    }

    foreach ($candidates as $path) {
        if (!is_string($path) || $path === '' || !is_file($path) || !is_readable($path)) {
            continue;
        }

        if (strtolower((string) pathinfo($path, PATHINFO_EXTENSION)) === 'json') {
            $raw = file_get_contents($path);
            if ($raw === false) {
                continue;
            }
            $data = json_decode($raw, true);
        } else {
            $data = require $path;
        }

        if (!is_array($data)) {
            continue;
        }

        // Ключи в файле могут быть названы по-разному — в том числе
        // по-русски, если файл заводили руками.
        $key = $data['api_key'] ?? $data['key'] ?? $data['ключ'] ?? '';
        if ($key === '') {
            continue;
        }

        return [
            'api_key' => (string) $key,
            'model' => (string) ($data['model'] ?? $data['модель'] ?? ''),
            'proxy' => (string) ($data['proxy'] ?? $data['прокси'] ?? ''),
            'model_spec' => (string) ($data['model_spec'] ?? ''),
            'effort_spec' => (string) ($data['effort_spec'] ?? ''),
        ];
    }

    return [];
}

/** Настройки резервного чтения спецификаций; секреты идут только в окружение Python. */
function spec_claude_env_prefix(): string
{
    $secrets = ob_claude_secrets();
    if (empty($secrets['api_key'])) {
        return '';
    }
    $prefix = 'ANTHROPIC_API_KEY=' . escapeshellarg($secrets['api_key']) . ' ';
    foreach (['model_spec' => 'ANTHROPIC_MODEL', 'effort_spec' => 'ANTHROPIC_EFFORT',
              'proxy' => 'ANTHROPIC_PROXY'] as $key => $variable) {
        if (!empty($secrets[$key])) {
            $prefix .= $variable . '=' . escapeshellarg($secrets[$key]) . ' ';
        }
    }
    return $prefix;
}
