<?php
declare(strict_types=1);

// РВ по ЛРВ: дерево объектов слева (объект → система → основной договор / наряд-заказ) с красными
// счётчиками непроверенных РВ, справа — РВ выбранного узла: сначала «На проверку» по времени получения,
// ниже строящиеся и проверенные. Сметчик видит только свои объекты (rv_responsible), руководитель
// (rv_is_manager) — все. Архивные объекты (архив справочника) спрятаны, ?archive=1 показывает.
// Вкладки «Ответственные» больше нет (?tab=resp ведёт в справочник): пользователи 1С → сметчики сайта, руководители,
// объекты и перенос номенклатурных групп — rv_responsibles.php (кнопка «Справочник объектов» у руководителя).
// Загрузка ЛРВ вручную — диалог «Загрузить ЛРВ» (rv_process.php); ход и результат — rv_status.php.
// Узел «Полнота ЛРВ» (?node=lrv) — сверка эталона из 1С с реестром (rv_onec_lib.php): сметы с ЛРВ, которых нет на
// сайте, ЛРВ, изменившиеся после РВ, и ЛРВ без сметы; кнопка «Запросить из 1С» — rv_request.php.
// Доступ — как к модулю ЦО (rv_guard).

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require_once __DIR__ . '/users.php';
require_once __DIR__ . '/lib.php';
require_once __DIR__ . '/rv_lib.php';
require_once __DIR__ . '/rv_onec_lib.php';

rv_guard();

$me = (string) ($_SESSION['kb_user'] ?? '');
$isManager = rv_is_manager();
$canTake = rv_can_take();
$canAssign = rv_is_manager();          // ответственных меняют руководитель и администратор, остальным - просмотр
$seesAll = $isManager || !$canTake;          // руководитель и те, кто не сметчик, видят всё; сметчик - своё
$csrf = rv_csrf();
if ((string) ($_GET['tab'] ?? '') === 'resp') {
    // вкладки «Ответственные» больше нет: пользователи 1С и руководители — в справочнике объектов
    header('Location: rv_responsibles.php#onec');
    exit;
}
$tab = 'obj';
$archive = (int) ($_GET['archive'] ?? 0) === 1;
$table = rv_table();
$systems = $table['systems'];
$estimators = rv_estimators();
$okNow = (string) ($_GET['ok'] ?? '');
$errNow = (string) ($_GET['err'] ?? '');
$deletedNow = isset($_GET['deleted']) ? (int) $_GET['deleted'] : null;
$busyNow = (int) ($_GET['busy'] ?? 0);

$all = rv_registry_rows();
$rows = rv_tree_rows($me, $seesAll, $archive, $all);
$tree = rv_tree($rows);
$readyTotal = count(rv_ready_rows($rows));
// Полнота ЛРВ: руководитель и не-сметчики видят все расхождения, сметчик - по своим сметам; ЛРВ без сметы - руководитель.
$lrv = rv_completeness($all);
$lrvMissing = $lrv ? rv_completeness_for($lrv['missing'], $me, $seesAll) : [];
$lrvStale = $lrv ? rv_completeness_for($lrv['stale'], $me, $seesAll) : [];
$lrvNosmeta = $lrv && $seesAll ? $lrv['nosmeta'] : [];
$lrvCount = count($lrvMissing) + count($lrvStale) + count($lrvNosmeta);
$uploads = array_values(array_filter(rv_my_jobs($me), static fn(array $j): bool => ($j['origin'] ?? '') !== '1c'));

// ── Выбранный узел ──
$selObj = (string) ($_GET['obj'] ?? '');
$selBld = isset($_GET['bld']) ? (string) $_GET['bld'] : null;      // null - корпус не выбран; '' - «без корпуса»
$selSys = (string) ($_GET['sys'] ?? '');
$selKind = in_array((string) ($_GET['kind'] ?? ''), ['осн', 'НЗ'], true) ? (string) $_GET['kind'] : '';
$node = (string) ($_GET['node'] ?? '');
if ($selObj !== '' && !isset($tree['objects'][$selObj])) {
    $selObj = '';
}
$selSingle = $selObj !== '' && array_keys($tree['objects'][$selObj]['buildings']) === [''];   // объект без корпусов
if ($selObj === '') {
    $selBld = null;
    $selSys = '';
    $selKind = '';
} elseif ($selSingle) {
    $selBld = $selSys !== '' || $selBld !== null ? '' : null;
} elseif ($selBld !== null && !isset($tree['objects'][$selObj]['buildings'][$selBld])) {
    $selBld = null;
}
if ($selBld === null) {
    $selSys = '';
    $selKind = '';
}
if (!in_array($node, ['unmatched', 'uploads', 'lrv'], true)) {
    $node = $selObj !== '' ? 'obj' : 'all';
}

/** Ссылка на узел дерева с сохранением архива. */
function rv_tree_url(array $params): string
{
    global $archive;
    if ($archive && !array_key_exists('archive', $params)) {
        $params['archive'] = 1;
    }
    if (isset($params['archive']) && !$params['archive']) {
        unset($params['archive']);
    }
    return 'rv.php' . ($params ? '?' . http_build_query($params) : '');
}

/** Значок состояния РВ в списке. */
/** Подпись «Сопоставление РВ и ЛРВ № … от …» под значком «В 1С» (по данным события «РВЗагружена»). */
function rv_onec_doc_html(?array $onec): string
{
    $doc = $onec ? rv_onec_document(['onec' => $onec]) : null;
    if ($doc === null) {
        return '';
    }
    $tip = $doc['title'] . ($doc['posted'] === null ? '' : ($doc['posted'] ? ' — проведён' : ' — не проведён')) . ($doc['message'] !== '' ? "\n" . $doc['message'] : '');
    return '<span class="kb-sub" title="' . rv_h($tip) . '">1С: ' . rv_h($doc['short']) . ($doc['posted'] === false ? ' · не проведён' : '') . '</span>';
}

/** Строка под датой получения: кто в 1С отправил на сайт (поле «Отправил» в шапке пакета; пусто — регламент). */
function rv_sender_html(array $row): string
{
    if (($row['sender'] ?? null) === null) {
        return '';
    }
    $sender = trim((string) $row['sender']);
    return $sender !== ''
        ? '<span class="kb-sub" title="пользователь 1С, отправивший ЛРВ на сайт">из 1С: ' . rv_h($sender) . '</span>'
        : '<span class="kb-sub kb-muted" title="отправило регламентное задание 1С">из 1С: автоматически</span>';
}

function rv_badge(string $code): string
{
    $map = [
        'ready' => ['warning', 'На проверку'], 'approved' => ['success', 'Согласована'], 'loaded' => ['success', 'В 1С'],
        'load_error' => ['danger', 'Ошибка загрузки в 1С'], 'error' => ['danger', 'Ошибка построения'],
        'queued' => ['info', 'В очереди'], 'running' => ['info', 'Строится'], 'awaiting' => ['info', 'Ждёт выбора (система, ДР / РВР)'],
        'gone' => ['neutral', 'Удалена'],
    ];
    [$kind, $label] = $map[$code] ?? ['neutral', RV_REGISTRY_STATES[$code] ?? $code];
    return '<span class="kb-badge kb-badge--' . $kind . '">' . rv_h($label) . '</span>';
}

/** Человек: инициалы в круге и подпись; $compact — только круг и подпись (имя в title). */
function rv_person_html(string $login, string $sub = '', string $title = '', bool $compact = false): string
{
    $empty = $login === '';
    $name = $empty ? 'не назначен' : rv_person_label($login);
    $title = $title !== '' ? $title : $name;
    return '<span class="kb-person' . ($empty ? ' kb-person--empty' : '') . '" title="' . rv_h($title) . '">'
        . '<span class="kb-avatar' . ($empty ? ' kb-avatar--empty' : '') . '">' . rv_h(rv_person_initials($login)) . '</span>'
        . '<span>' . ($compact ? '' : '<span class="kb-person__name">' . rv_h($name) . '</span>')
        . ($sub !== '' ? '<span class="kb-person__sub">' . rv_h($sub) . '</span>' : '') . '</span></span>';
}

/** Короткая дата: «сегодня 14:02», «3 ноя 14:02», «3 ноя 2025». */
function rv_when_short(int $time): string
{
    if ($time <= 0) {
        return '';
    }
    $months = ['', 'янв', 'фев', 'мар', 'апр', 'мая', 'июн', 'июл', 'авг', 'сен', 'окт', 'ноя', 'дек'];
    if (date('Y-m-d', $time) === date('Y-m-d')) {
        return 'сегодня ' . date('H:i', $time);
    }
    $day = (int) date('j', $time) . ' ' . $months[(int) date('n', $time)];
    return date('Y', $time) === date('Y') ? $day . ' ' . date('H:i', $time) : $day . ' ' . date('Y', $time);
}

/** Строка списка РВ. $withObject — показать объект в подписи (узел выше объекта). */
function rv_list_row(array $row, bool $withObject, string $me, array $ctx): string
{
    [$csrf, $canAssign, $objects, $estimators] = $ctx + [3 => []];
    $kindText = $row['work_kind'] === 'НЗ' ? 'НЗ' . ($row['zn'] !== '' || $row['zn_list'] ? ' ' . rv_zn_text(array_merge([$row['zn']], $row['zn_list'])) : '') : 'основной договор';
    $system = $row['table_system'] !== '' ? $row['table_system'] : $row['system'];
    $place = $row['folder_key'] === '' ? $row['obj'] : ($row['building_label'] !== '' ? $row['building_label'] : $row['obj']);
    $title = $place . ' · ' . $system;
    $sub = [];
    if ($withObject && $row['folder'] !== '') {
        $sub[] = $row['folder'];
    }
    // Название сметы из 1С — чтобы отличать сметы одного корпуса и системы («Отопление к.1.2» / «ВК к.1.2»).
    $smetaName = trim((string) ($row['smeta'] ?? ''));
    if ($smetaName !== '' && rv_norm($smetaName) !== rv_norm($title)) {
        $sub[] = $smetaName;
    }
    $sub[] = $kindText;
    $check = $row['review'] + $row['unbound'];
    $checkHtml = $row['code'] === 'ready' && $check ? '<b style="color:var(--c-accent-text)">' . $check . '</b>' : '<span class="kb-muted">' . ($row['rows'] ? $check : '—') . '</span>';
    $who = '';
    $resp = is_array($row['responsible']) ? $row['responsible'] : [];
    $respLogin = (string) (($resp['user'] ?? '') !== '' ? $resp['user'] : ($resp['login'] ?? ''));
    $level = (string) ($resp['level'] ?? '');
    if ($row['approval']) {
        $who = rv_person_html((string) $row['approval']['user'], 'согласовал ' . rv_when_short((int) $row['approval']['when']), 'согласовал ' . rv_person_label((string) $row['approval']['user']));
    } elseif ($respLogin !== '') {
        $note = ['sender' => 'отправил из 1С', 'smeta' => 'назначен', 'fallback' => 'проверяет (запасной)'][$level] ?? 'проверяет';
        $who = rv_person_html($respLogin, $note, 'ответственный: ' . rv_person_label($respLogin) . ($level === 'sender' ? ' — отправил ЛРВ из 1С (' . (string) ($resp['onec'] ?? '') . ')' : ''));
    } elseif ($level === 'sender_unknown') {
        $who = rv_person_html('', 'нет учётки: ' . (string) ($resp['onec'] ?? ''), 'отправил из 1С ' . (string) ($resp['onec'] ?? '') . ' — на сайте такого сметчика не нашлось; сопоставьте на вкладке «Ответственные»');
    } else {
        $who = rv_person_html('', 'не назначен', 'ответственный не назначен');
    }
    // Руководитель меняет ответственного прямо в строке: назначение на эту РВ сильнее отправителя из 1С.
    if ($canAssign && !$row['approval'] && $row['token'] !== '' && $estimators) {
        $options = '<option value="">' . rv_h($level === 'smeta' ? '— снять назначение (по отправителю) —' : ($respLogin !== '' ? '— как есть —' : '— не назначен —')) . '</option>';
        foreach ($estimators as $value => $label) {
            $options .= '<option value="' . rv_h($value) . '"' . ($level === 'smeta' && $value === $respLogin ? ' selected' : '') . '>' . rv_h(rv_person_label($value)) . '</option>';
        }
        $who .= '<form class="kb-inline-form rv-who-form" method="post" action="rv_assign.php"><input type="hidden" name="csrf" value="' . rv_h($csrf) . '">'
            . '<input type="hidden" name="level" value="smeta"><input type="hidden" name="smeta_id" value="' . rv_h($row['id']) . '">'
            . '<input type="hidden" name="back" value="rv.php?node=' . rv_h(rawurlencode((string) ($_GET['node'] ?? ''))) . '">'
            . '<select class="kb-select kb-select--sm" name="user" aria-label="Сменить ответственного" title="Назначить другого сметчика на эту РВ" onchange="this.form.submit()">' . $options . '</select></form>';
    }
    $acts = '';
    if ($row['token'] !== '') {
        $acts .= '<a class="kb-btn kb-btn--sm' . ($row['code'] === 'ready' ? ' kb-btn--primary' : ' kb-btn--ghost') . '" href="rv_status.php?token=' . rv_h($row['token']) . '">' . ($row['code'] === 'ready' ? 'Проверить' : 'Открыть') . '</a>';
    } else {
        $acts .= '<a class="kb-btn kb-btn--sm kb-btn--ghost" href="rv_smeta.php?id=' . rv_h(rawurlencode($row['id'])) . '">Карточка</a>';
    }
    if ($row['folder_key'] === '' && $canAssign) {
        $options = '<option value="">привязать к объекту…</option>';
        foreach ($objects as $o) {
            $options .= '<option value="' . rv_h((string) $o['name'] . '|') . '">' . rv_h((string) $o['name']) . '</option>';
        }
        $options .= '<option value="+">+ новый объект…</option>';
        // Новый объект: имя — папка НГ из 1С, иначе НГ без слов системы («Западное Дегунино Электромонтажные работы» → «Западное Дегунино»).
        $guess = (string) ($row['folder_1c'] ?? '');
        if ($guess === '') {
            $guess = trim(preg_replace('/\s+(электромонтажные|сантехнические|вентиляционные|слаботочные|общестроительные|монтажные)?\s*работы.*$/iu', '', $row['obj']) ?? $row['obj']);
        }
        $acts = '<form class="kb-inline-form rv-unmatched-bind" method="post" action="rv_responsibles.php"><input type="hidden" name="csrf" value="' . rv_h($csrf) . '">'
            . '<input type="hidden" name="action" value="bind"><input type="hidden" name="back" value="rv.php?node=unmatched">'
            . '<input type="hidden" name="obj_key" value="' . rv_h($row['obj_key']) . '"><input type="hidden" name="obj" value="' . rv_h($row['obj']) . '">'
            . '<select class="kb-select kb-select--sm" name="target" aria-label="Объект справочника" data-guess="' . rv_h($guess) . '" onchange="rvUnmatchedPick(this)">' . $options . '</select>'
            . '</form>' . $acts;
    }
    $error = $row['error'] !== '' ? '<span class="kb-sub" style="color:var(--c-error)">' . rv_h(mb_substr($row['error'], 0, 160)) . '</span>' : '';
    return '<tr' . ($row['code'] === 'ready' && (string) ($row['responsible']['user'] ?? '') === $me ? ' class="is-mine"' : '') . '>'
        . '<td title="' . rv_h($row['smeta']) . '"><a class="kb-title-link" href="rv_smeta.php?id=' . rv_h(rawurlencode($row['id'])) . '" title="Карточка сметы: версии РВ, работы, наряд-заказы"><b>' . rv_h($title) . '</b></a><span class="kb-sub">' . rv_h(implode(' · ', $sub)) . '</span>' . $error . '</td>'
        . '<td style="white-space:nowrap">' . rv_badge($row['code']) . '<span class="kb-sub">' . rv_h(rv_when_short($row['received'])) . '</span>' . rv_sender_html($row) . rv_onec_doc_html($row['onec'] ?? null) . '</td>'
        . '<td class="is-num">' . $checkHtml . '</td>'
        . '<td class="is-who">' . $who . '</td>'
        . '<td class="is-actions"><div class="kb-row-actions">' . $acts . '</div></td></tr>';
}

/** Где смета в дереве: «объект › корпус · система · вид работ»; смета не сопоставлена с объектом — папка НГ из 1С. */
function rv_lrv_place(array $e): array
{
    $system = $e['table_system'] !== '' ? $e['table_system'] : $e['system'];
    $place = $e['object_name'] !== '' ? $e['object_name'] . ($e['building_label'] !== '' ? ' › ' . $e['building_label'] : '') : ($e['folder'] !== '' ? $e['folder'] : $e['obj']);
    $kind = $e['work_kind'] === 'НЗ' ? 'НЗ' . ($e['zn'] !== '' ? ' ' . $e['zn'] : '') : 'основной договор';
    return [$place . ' · ' . $system, $e['smeta'] . ' · ' . $kind . ($e['object_name'] === '' ? ' · объект не сопоставлен' : '')];
}

/** Кнопка «Запросить из 1С» или состояние запроса. Запрашивают руководитель и ответственный за смету. */
function rv_lrv_request(array $e, string $me, bool $isManager, string $csrf, string $label): string
{
    $request = $e['request'] ?? null;
    $state = (string) ($request['state'] ?? '');
    $text = rv_request_text(is_array($request) ? $request : null);
    $waiting = $state === 'pending' || ($state === 'taken' && (int) ($request['taken'] ?? 0) >= time() - RV_REQUEST_TTL);
    $can = $isManager || ((string) ($e['responsible']['user'] ?? '') !== '' && (string) $e['responsible']['user'] === $me);
    if ($can && !$waiting && $e['smeta_id'] !== '') {
        return '<form class="kb-inline-form" method="post" action="rv_request.php"><input type="hidden" name="csrf" value="' . rv_h($csrf) . '">'
            . '<input type="hidden" name="smeta_id" value="' . rv_h($e['smeta_id']) . '">'
            . '<button type="submit" class="kb-btn kb-btn--sm kb-btn--ghost" title="1С пришлёт ЛРВ сметы при ближайшем обмене (раз в 15 минут) и включит автообмен">' . rv_h($label) . '</button></form>';
    }
    return '';
}

/** Состояние запроса сметы у 1С — строкой под сметой. */
function rv_lrv_request_note(array $e): string
{
    $text = rv_request_text(is_array($e['request'] ?? null) ? $e['request'] : null);
    $error = (string) ($e['request']['state'] ?? '') === 'error';
    return $text !== '' ? '<span class="kb-sub"' . ($error ? ' style="color:var(--c-error)"' : '') . '>' . rv_h($text) . '</span>' : '';
}

/** Ответственный за смету — кружок и подпись. */
function rv_lrv_who(array $e): string
{
    $login = (string) (($e['responsible']['user'] ?? '') !== '' ? $e['responsible']['user'] : ($e['responsible']['login'] ?? ''));
    return $login !== '' ? rv_person_html($login, 'ответственный') : rv_person_html('', 'не назначен');
}

/** Узел «Полнота ЛРВ»: эталон 1С против реестра сайта. */
function rv_lrv_card(?array $lrv, array $missing, array $stale, array $nosmeta, string $me, bool $isManager, string $csrf, bool $seesAll = true): string
{
    $empty = static fn(string $title, string $text): string => '<div class="kb-empty"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12 4 4 10-10"/></svg><div class="kb-empty__title">' . rv_h($title) . '</div><div>' . rv_h($text) . '</div></div>';
    $html = '<section class="kb-card"><div class="kb-card__head"><h2 class="kb-card__title">Полнота ЛРВ</h2>'
        . ($lrv !== null ? '<span class="kb-muted">эталон из 1С ' . rv_h(rv_when_short((int) $lrv['at'])) . '</span>' : '') . '</div>';
    if ($lrv === null) {
        return $html . '<div class="kb-card__body">' . $empty('1С ещё не присылала эталон',
            'Эталон смет с ЛРВ приходит регламентом 1С раз в 6 часов после обновления модуля СайтРВ_Обмен.') . '</div></section>';
    }
    $html .= '<div class="kb-card__foot" style="border-top:0;border-bottom:1px solid var(--c-line)">1С раз в 6 часов присылает все сметы с плановыми остатками ЛРВ. Здесь — то, чего на сайте нет или что изменилось после РВ.</div>';
    if (!$missing && !$stale && !$nosmeta) {
        return $html . '<div class="kb-card__body">' . $empty($seesAll ? 'Всё сходится' : 'По вашим сметам всё сходится',
            'Каждая смета с ЛРВ есть на сайте, и ЛРВ не менялись после РВ.') . '</div></section>';
    }
    $html .= '<div class="kb-table-wrap"><table class="kb-table">'
        . '<thead><tr><th style="min-width:200px">Смета</th><th class="is-num" title="Строк ЛРВ с плановым остатком">Строк</th><th>ЛРВ изменилась</th><th>Кто</th><th class="is-actions"><span class="kb-sr">Действия</span></th></tr></thead><tbody>';
    if ($missing) {
        $html .= '<tr class="is-group"><td colspan="5">Есть ЛРВ в 1С — нет на сайте <span class="kb-muted">· ' . count($missing) . '</span></td></tr>';
        foreach ($missing as $e) {
            [$title, $sub] = rv_lrv_place($e);
            $html .= '<tr><td><b>' . rv_h($title) . '</b><span class="kb-sub">' . rv_h($sub) . '</span>' . rv_lrv_request_note($e) . '</td>'
                . '<td class="is-num">' . (int) $e['rows'] . '</td>'
                . '<td style="white-space:nowrap">' . rv_h(rv_when_short((int) $e['changed_at'])) . '</td>'
                . '<td class="is-who">' . rv_lrv_who($e) . '</td>'
                . '<td class="is-actions"><div class="kb-row-actions">' . rv_lrv_request($e, $me, $isManager, $csrf, 'Запросить из 1С') . '</div></td></tr>';
        }
    }
    if ($stale) {
        $html .= '<tr class="is-group"><td colspan="5">ЛРВ изменилась после РВ <span class="kb-muted">· ' . count($stale) . '</span></td></tr>';
        foreach ($stale as $e) {
            [$title, $sub] = rv_lrv_place($e);
            $sent = $e['sent_at'] > 0 ? $e['sent_at'] : $e['site_received'];
            $html .= '<tr><td><a class="kb-title-link" href="rv_status.php?token=' . rv_h($e['site_token']) . '"><b>' . rv_h($title) . '</b></a><span class="kb-sub">' . rv_h($sub) . ' · РВ по ЛРВ от ' . rv_h(rv_when_short($sent)) . '</span>' . rv_lrv_request_note($e) . '</td>'
                . '<td class="is-num">' . (int) $e['rows'] . '</td>'
                . '<td style="white-space:nowrap"><b>' . rv_h(rv_when_short((int) $e['changed_at'])) . '</b></td>'
                . '<td class="is-who">' . rv_lrv_who($e) . '</td>'
                . '<td class="is-actions"><div class="kb-row-actions">' . rv_lrv_request($e, $me, $isManager, $csrf, 'Запросить заново') . '</div></td></tr>';
        }
    }
    if ($nosmeta) {
        $html .= '<tr class="is-group"><td colspan="5">ЛРВ без сметы <span class="kb-muted">· ' . count($nosmeta) . '</span></td></tr>'
            . '<tr><td colspan="5" class="kb-muted" style="white-space:normal">Плановые остатки, которые не берёт ни одна смета: заведите смету в 1С или исправьте аналитики ЛРВ — тогда они уйдут на сайт со сметой.</td></tr>';
        foreach ($nosmeta as $g) {
            $analytics = implode(' · ', array_filter([$g['a1'], $g['a2'], $g['a3'], $g['a4']], static fn(string $v): bool => $v !== ''));
            $html .= '<tr><td><b>' . rv_h($g['obj'] !== '' ? $g['obj'] : 'без номенклатурной группы') . '</b><span class="kb-sub">' . rv_h($analytics) . '</span></td>'
                . '<td class="is-num">' . (int) $g['rows'] . '</td>'
                . '<td style="white-space:nowrap">' . rv_h(rv_when_short((int) $g['changed_at'])) . '</td><td></td><td></td></tr>';
        }
    }
    return $html . '</tbody></table></div><div class="kb-card__foot"><span>Расхождений: ' . (count($missing) + count($stale) + count($nosmeta)) . '</span>'
        . '<span class="kb-right">«Запросить из 1С» — смета придёт при ближайшем обмене (раз в 15 минут) и дальше будет обновляться сама</span></div></section>';
}

/** Строка загруженной вручную ЛРВ (не из 1С). */
function rv_upload_row(array $job, string $csrf): string
{
    [$label, $kind] = rv_state_label($job['state']);
    $summary = is_array($job['status']['summary'] ?? null) ? $job['status']['summary'] : null;
    $approval = $job['state'] === 'done' ? rv_approval($job, $job['status']) : null;
    $code = $job['state'] === 'done' ? ($approval ? 'approved' : 'ready') : ($job['state'] === 'running' ? 'running' : ($job['state'] === 'queued' ? 'queued' : ($job['state'] === 'awaiting_confirm' ? 'awaiting' : 'error')));
    $sections = is_array($summary) && !empty($summary['sections']) ? implode(', ', (array) $summary['sections']) : (string) ($job['section'] ?? '');
    $sub = [($sections === 'авто' ? 'раздел по файлу' : $sections), (string) (RV_OBJECT_TYPES[$job['object_type'] ?? ''] ?? $job['object_type'] ?? '')];
    if (is_array($summary)) {
        $sub[] = (int) $summary['rows'] . ' строк';
    }
    $check = is_array($summary) ? (int) $summary['review'] + (int) $summary['unbound'] : 0;
    $who = $approval ? rv_person_html((string) $approval['user'], 'согласовал ' . rv_when_short((int) $approval['when'])) : rv_person_html((string) ($job['user'] ?? ''), 'загрузил');
    $acts = '<a class="kb-btn kb-btn--sm' . ($code === 'ready' ? ' kb-btn--primary' : ' kb-btn--ghost') . '" href="rv_status.php?token=' . rv_h($job['token']) . '">' . ($code === 'ready' ? 'Проверить' : 'Открыть') . '</a>';
    if ($job['state'] !== 'running') {
        $acts .= '<form class="kb-inline-form" action="rv_delete.php" method="post" onsubmit="return confirm(\'Удалить РВ «' . rv_h(addslashes((string) ($job['source_name'] ?? ''))) . '»?\');">'
            . '<input type="hidden" name="csrf" value="' . rv_h($csrf) . '"><input type="hidden" name="tokens[]" value="' . rv_h($job['token']) . '">'
            . '<button type="submit" class="kb-btn kb-btn--sm kb-btn--ghost">Удалить</button></form>';
    }
    return '<tr><td><b>' . rv_h((string) ($job['source_name'] ?? '')) . '</b><span class="kb-sub">' . rv_h(implode(' · ', array_filter($sub))) . '</span></td>'
        . '<td style="white-space:nowrap">' . rv_badge($code) . '<span class="kb-sub">' . rv_h(rv_when_short((int) ($job['created'] ?? 0))) . '</span></td>'
        . '<td class="is-num">' . ($code === 'ready' && $check ? '<b style="color:var(--c-accent-text)">' . $check . '</b>' : '<span class="kb-muted">' . ($summary ? $check : '—') . '</span>') . '</td>'
        . '<td class="is-who">' . $who . '</td><td class="is-actions"><div class="kb-row-actions">' . $acts . '</div></td></tr>';
}

/** Пункт дерева. Счётчик непроверенных - тихий; у раскрытого узла не показывается (он есть у вложенных). */
function rv_tree_item(string|int $label, string $href, int $count, int $level, bool $selected, ?bool $open = null, bool $muted = false, bool $folder = false): string
{
    $label = (string) $label;    // ключи массивов вида «1» PHP хранит как int — корпус «1» приходил сюда числом
    $chev = $open === null ? '<span class="kb-tree__chev"></span>' : '<span class="kb-tree__chev">' . ($open ? '▾' : '▸') . '</span>';
    $icon = $folder ? '<span class="kb-tree__folder"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 6h6l2 2h10v11H3z"/></svg></span>' : '';
    $badge = $count && $open !== true ? '<span class="kb-count kb-count--quiet" title="непроверенных РВ: ' . $count . '">' . $count . '</span>' : '';
    return '<a href="' . rv_h($href) . '" class="kb-tree__l' . $level . ($muted ? ' is-muted' : '') . '"' . ($selected ? ' aria-current="true"' : '') . ' title="' . rv_h($label) . '">'
        . $chev . $icon . '<span class="kb-tree__label">' . rv_h($label) . '</span>' . $badge . '</a>';
}

// ── Узел: заголовок и строки ──
$nodeRows = [];
$nodeTitle = '';
$nodeCrumb = '';
if ($node === 'unmatched') {
    $nodeRows = rv_node_rows($rows, 'unmatched');
    $nodeTitle = 'Не сопоставлено с объектами';
} elseif ($node === 'uploads') {
    $nodeTitle = 'Загружено вручную';
} elseif ($node === 'lrv') {
    $nodeTitle = 'Полнота ЛРВ';
} elseif ($node === 'obj') {
    $nodeRows = rv_node_rows($rows, $selObj, $selBld, $selSys, $selKind);
    $objName = (string) $tree['objects'][$selObj]['name'];
    $crumb = [$objName];
    if ($selBld !== null && !$selSingle) {
        $crumb[] = $selBld !== '' ? $selBld : 'без корпуса';
    }
    if ($selSys !== '') {
        $crumb[] = $selSys;
    }
    if ($selKind !== '') {
        $crumb[] = $selKind === 'НЗ' ? 'Наряд-заказ' : 'Основной договор';
    }
    $nodeTitle = (string) array_pop($crumb);
    $nodeCrumb = $crumb ? implode(' › ', $crumb) . ' ›' : '';
} else {
    $nodeRows = array_values(array_filter($rows, static fn(array $r): bool => (string) $r['folder_key'] !== ''));
    $nodeTitle = $seesAll ? 'Все объекты' : 'Мои объекты';
}
$groups = rv_node_groups($nodeRows);
$nodeReady = count($groups['ready']);
$unmatchedTotal = $tree['unmatched']['total'];
$uploadsReady = count(array_filter($uploads, static fn(array $j): bool => $j['state'] === 'done' && rv_approval($j, $j['status']) === null));

$respObjects = rv_table_objects($table);

$pageTitle = 'РВ по ЛРВ';
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= rv_h($pageTitle) ?> — База знаний</title>
<link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
<script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
</head>
<body>
<div class="shell">
  <?php require __DIR__ . '/sidebar.php'; ?>

  <div class="dashboard-main kb">

  <header class="kb-page">
    <div class="kb-page__row">
      <div>
        <h1 class="kb-page__title">РВ по ЛРВ</h1>
        <p class="kb-page__sub">
          <?= $readyTotal ? '<b>' . $readyTotal . '</b> на проверку' : 'На проверку ничего нет' ?><?= $seesAll ? ' · все объекты' : ' · ваши объекты' ?>
        </p>
      </div>
      <div class="kb-page__actions">
        <?php if ($canAssign): ?>
        <a class="kb-btn kb-btn--ghost" href="rv_responsibles.php" title="Объекты и корпуса, названия в 1С, перенос номенклатурных групп между объектами, пользователи 1С">Справочник объектов</a>
        <details class="kb-menu">
          <summary class="kb-btn kb-btn--ghost" title="Привязка и коэффициенты заново по текущим правилам; согласование сохраняется">Пересобрать РВ</summary>
          <ul class="kb-menu__list">
            <li><form action="rv_rebuild.php" method="post" onsubmit="return confirm('Пересобрать РВ, в пакетах которых есть уменьшения по ЛРВ (отрицательные остатки)?\n\nРВ встанут в очередь и пересоберутся по одной: количество под работами уменьшится, строки будут отмечены «уменьшение». Решения инженеров сохраняются; у согласованных РВ согласование снимется — их нужно проверить заново. РВ, уже загруженные в 1С, не трогаются.');"><input type="hidden" name="csrf" value="<?= rv_h(rv_csrf()) ?>"><input type="hidden" name="scope" value="reductions"><button type="submit">С уменьшениями по ЛРВ</button></form></li>
            <li><form action="rv_rebuild.php" method="post" onsubmit="return confirm('Пересобрать ВСЕ готовые РВ из 1С, ещё не загруженные в 1С?\n\nОни встанут в очередь и пересоберутся по одной по текущим правилам (коэффициенты, уменьшения по ЛРВ). Решения инженеров сохраняются; у согласованных РВ, где изменится то, что уйдёт в 1С, согласование снимется. Это может занять время.');"><input type="hidden" name="csrf" value="<?= rv_h(rv_csrf()) ?>"><input type="hidden" name="scope" value="all"><button type="submit">Все РВ из 1С</button></form></li>
          </ul>
        </details>
        <?php endif; ?>
        <a class="kb-btn kb-btn--ghost" href="<?= rv_h(rv_tree_url(['archive' => $archive ? 0 : 1])) ?>"><?= $archive ? 'Скрыть архив' : 'Показать архив' ?></a>
      </div>
    </div>
  </header>

  <?php if ($okNow !== ''): ?><div class="kb-alert kb-alert--success"><?= rv_h($okNow) ?></div><?php endif; ?>
  <?php if ($errNow !== ''): ?><div class="kb-alert kb-alert--danger"><?= rv_h($errNow) ?></div><?php endif; ?>
  <?php if ($deletedNow !== null): ?>
  <div class="kb-alert <?= $busyNow ? 'kb-alert--warning' : 'kb-alert--success' ?>"><?= $deletedNow ? 'Удалено РВ: ' . $deletedNow . '.' : 'Ничего не удалено.' ?><?php if ($busyNow): ?> <?= $busyNow ?> ещё строится — её можно удалить, когда агент закончит.<?php endif; ?> Решения инженеров из удалённых РВ агент помнит.</div>
  <?php endif; ?>

  <div class="kb-two">
    <aside class="kb-two__side">
      <nav class="kb-tree" aria-label="Объекты">
        <?= rv_tree_item($seesAll ? 'Все объекты' : 'Мои объекты', rv_tree_url([]), $readyTotal - $tree['unmatched']['count'], 0, $node === 'all', $node === 'all' ? true : null) ?>
        <?php foreach ($tree['objects'] as $key => $o): ?>
          <?php $key = (string) $key; $openObj = $selObj === $key; $single = array_keys($o['buildings']) === ['']; ?>
          <?= rv_tree_item($o['name'], rv_tree_url(['obj' => $key]), $o['count'], 0, $openObj && $selBld === null, $openObj, $o['archived'], $o['archived']) ?>
          <?php if ($openObj): ?>
            <?php foreach ($o['buildings'] as $bld => $b): ?>
              <?php $bld = (string) $bld; $openBld = $selBld === $bld; $base = $single ? 1 : 2; ?>
              <?php if (!$single): ?>
                <?= rv_tree_item($bld !== '' ? $bld : 'без корпуса', rv_tree_url(['obj' => $key, 'bld' => $bld]), $b['count'], 1, $openBld && $selSys === '', $openBld) ?>
              <?php endif; ?>
              <?php if ($openBld || $single): ?>
                <?php foreach ($b['systems'] as $sysName => $sys): ?>
                  <?php $sysName = (string) $sysName; $openSys = $openBld && $selSys === $sysName; ?>
                  <?= rv_tree_item($sysName, rv_tree_url(['obj' => $key, 'bld' => $bld, 'sys' => $sysName]), $sys['count'], $base, $openSys && $selKind === '', $openSys) ?>
                  <?php if ($openSys): ?>
                    <?php foreach ($sys['kinds'] as $kindName => $k): $kindName = (string) $kindName; ?>
                      <?= rv_tree_item($kindName === 'НЗ' ? 'Наряд-заказ' : 'Основной договор', rv_tree_url(['obj' => $key, 'bld' => $bld, 'sys' => $sysName, 'kind' => $kindName]), $k['count'], $base + 1, $selKind === $kindName) ?>
                    <?php endforeach; ?>
                  <?php endif; ?>
                <?php endforeach; ?>
              <?php endif; ?>
            <?php endforeach; ?>
          <?php endif; ?>
        <?php endforeach; ?>
        <?php if ($unmatchedTotal): ?>
          <?= rv_tree_item('Не сопоставлено', rv_tree_url(['node' => 'unmatched']), $tree['unmatched']['count'], 0, $node === 'unmatched', null, true) ?>
        <?php endif; ?>
        <?php if ($uploads): ?>
          <?= rv_tree_item('Загружено вручную', rv_tree_url(['node' => 'uploads']), $uploadsReady, 0, $node === 'uploads', null, true, true) ?>
        <?php endif; ?>
        <?php if ($lrv !== null): ?>
          <?= rv_tree_item('Полнота ЛРВ', rv_tree_url(['node' => 'lrv']), $lrvCount, 0, $node === 'lrv', null, true, true) ?>
        <?php endif; ?>
      </nav>
      <?php if (!$tree['objects'] && !$unmatchedTotal && !$uploads): ?>
      <div class="kb-side-foot"><?= $seesAll ? '1С ещё ничего не присылала.' : 'За вами пока нет РВ: ответственный — тот, кто отправил ЛРВ из 1С.' ?></div>
      <?php endif; ?>
    </aside>

    <div class="kb-two__main">
    <?php if ($node === 'lrv'): ?>
      <?= rv_lrv_card($lrv, $lrvMissing, $lrvStale, $lrvNosmeta, $me, $isManager, $csrf, $seesAll) ?>
    <?php else: ?>
      <section class="kb-card">
        <div class="kb-card__head">
          <h2 class="kb-card__title"><?= $nodeCrumb !== '' ? '<span class="kb-muted">' . rv_h($nodeCrumb) . '</span> ' : '' ?><?= rv_h($nodeTitle) ?></h2>
          <?php if ($node !== 'uploads' && $nodeReady): ?><span class="kb-count kb-count--quiet" title="непроверенных РВ"><?= $nodeReady ?></span><?php endif; ?>
          <div class="kb-card__actions">
          </div>
        </div>
        <?php if ($node === 'unmatched'): ?>
        <div class="kb-card__foot" style="border-top:0;border-bottom:1px solid var(--c-line)">1С прислала номенклатурные группы, которых нет в справочнике объектов. <?= $canAssign ? 'Выберите объект в строке — РВ встанет под него и получит ответственного.' : 'Привязать к объекту может руководитель.' ?></div>
        <?php endif; ?>
        <div class="kb-table-wrap">
        <table class="kb-table">
          <thead><tr><th style="min-width:160px"><?= $node === 'uploads' ? 'ЛРВ' : 'РВ / смета' ?></th><th title="Состояние и дата получения">Состояние</th><th class="is-num" title="Строк на проверку и без работы">Проверить</th><th>Кто</th><th class="is-actions"><span class="kb-sr">Действия</span></th></tr></thead>
          <tbody>
          <?php if ($node === 'uploads'): ?>
            <?php foreach ($uploads as $job): ?><?= rv_upload_row($job, $csrf) ?><?php endforeach; ?>
          <?php else: ?>
            <?php $ctx = [$csrf, $canAssign, $respObjects, $estimators]; $withObject = $node !== 'obj'; ?>
            <?php if ($groups['ready']): ?>
            <tr class="is-group"><td colspan="5">На проверку <span class="kb-muted">· <?= count($groups['ready']) ?></span></td></tr>
            <?php foreach ($groups['ready'] as $row): ?><?= rv_list_row($row, $withObject, $me, $ctx) ?><?php endforeach; ?>
            <?php endif; ?>
            <?php if ($groups['work']): ?>
            <tr class="is-group"><td colspan="5">В работе у агента <span class="kb-muted">· <?= count($groups['work']) ?></span></td></tr>
            <?php foreach ($groups['work'] as $row): ?><?= rv_list_row($row, $withObject, $me, $ctx) ?><?php endforeach; ?>
            <?php endif; ?>
            <?php if ($groups['done']): ?>
            <tr class="is-group"><td colspan="5">Проверенные <span class="kb-muted">· <?= count($groups['done']) ?></span></td></tr>
            <?php foreach ($groups['done'] as $row): ?><?= rv_list_row($row, $withObject, $me, $ctx) ?><?php endforeach; ?>
            <?php endif; ?>
            <?php if (!$nodeRows): ?>
            <tr><td colspan="5"><div class="kb-empty"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5h16v14H4z"/><path d="M4 10h16M9 10v9"/></svg><div class="kb-empty__title"><?= $node === 'all' && !$seesAll ? 'За вами пока нет РВ' : 'Здесь пока ничего нет' ?></div><div>РВ появляются сами, как только 1С отправляет ЛРВ на сайт.</div></div></td></tr>
            <?php endif; ?>
          <?php endif; ?>
          </tbody>
        </table>
        </div>
        <div class="kb-card__foot">
          <span><?= $node === 'uploads' ? count($uploads) . ' ЛРВ, загруженных вручную раньше (не из 1С)' : count($nodeRows) . ' РВ' ?><?= $archive ? ' · с архивом' : '' ?></span>
          <span class="kb-right"><?= $seesAll ? 'Руководитель: видны все объекты' : 'Видны объекты, за которые вы отвечаете' ?></span>
        </div>
      </section>

      <?php $allNotes = kb_can_see_plans($me) ? rv_notes(null, 40) : []; ?>
      <?php if ($allNotes): ?>
      <details class="kb-card kb-fold">
        <summary class="kb-card__head">Замечания инженеров к агенту <span class="kb-muted">· <?= count($allNotes) ?></span></summary>
        <div class="kb-card__body">
          <ul class="kb-notes">
          <?php foreach ($allNotes as $note): ?>
            <li><span class="kb-muted"><?= rv_h(rv_when((int) ($note['when'] ?? 0))) ?>, <?= rv_h((string) ($note['user'] ?? '')) ?>,
              <?php if (rv_token_valid((string) ($note['token'] ?? '')) && is_file(rv_paths((string) $note['token'])['job'])): ?><a href="rv_status.php?token=<?= rv_h((string) $note['token']) ?>"><?= rv_h(pathinfo((string) ($note['source_name'] ?? ''), PATHINFO_FILENAME)) ?></a><?php else: ?><?= rv_h(pathinfo((string) ($note['source_name'] ?? ''), PATHINFO_FILENAME)) ?><?php endif; ?>:</span>
              <?= nl2br(rv_h((string) ($note['text'] ?? ''))) ?></li>
          <?php endforeach; ?>
          </ul>
        </div>
      </details>
      <?php endif; ?>

    <?php endif; ?>
    </div>
  </div>


  </div>
</div>
<?php if ($canAssign): ?>
<div class="kb">
<dialog class="kb-dialog" id="rv-new-object">
  <form method="post" action="rv_responsibles.php">
    <input type="hidden" name="csrf" value="<?= rv_h($csrf) ?>"><input type="hidden" name="action" value="add_object">
    <input type="hidden" name="back" value="rv.php?node=unmatched"><input type="hidden" name="obj_key" value=""><input type="hidden" name="obj" value="">
    <div class="kb-dialog__head"><strong>Новый объект в справочнике</strong></div>
    <div class="kb-dialog__body">
      <p class="muted" id="rv-new-object-ng"></p>
      <div class="field"><label class="field-label" for="rv-new-object-name">Название объекта</label>
        <input class="kb-input" type="text" id="rv-new-object-name" name="name" maxlength="120" required placeholder="ЖК Западное Дегунино">
        <p class="hint">Как объект называется в договоре — так он будет в дереве «РВ по ЛРВ» и в ТКП заказчика.</p></div>
      <div class="field"><label class="field-label" for="rv-new-object-building">Корпус</label>
        <input class="kb-input" type="text" id="rv-new-object-building" name="building" maxlength="60" placeholder="к">
        <p class="hint">Можно оставить пустым; остальные корпуса добавляются в карточке объекта.</p></div>
      <p class="hint">После создания номенклатурная группа 1С будет привязана к объекту, а страница откроет его ответственных — там назначается сметчик по системе.</p>
      <div class="kb-dialog__actions"><button type="button" class="kb-btn kb-btn--ghost" onclick="document.getElementById('rv-new-object').close()">Отмена</button>
        <button type="submit" class="kb-btn kb-btn--primary">Создать объект</button></div>
    </div>
  </form>
</dialog>
</div>
<script>
// Строка «Не сопоставлено»: выбор объекта из списка привязывает сразу; «+ новый объект…» открывает окно создания.
function rvUnmatchedPick(select) {
  if (select.value === '+') {
    var dlg = document.getElementById('rv-new-object'), form = select.form;
    dlg.querySelector('[name=obj_key]').value = form.querySelector('[name=obj_key]').value;
    dlg.querySelector('[name=obj]').value = form.querySelector('[name=obj]').value;
    dlg.querySelector('[name=name]').value = select.getAttribute('data-guess') || '';
    dlg.querySelector('[name=building]').value = '';
    document.getElementById('rv-new-object-ng').textContent = 'Из 1С: ' + form.querySelector('[name=obj]').value;
    select.value = '';
    dlg.showModal();
    dlg.querySelector('[name=name]').focus();
    return;
  }
  if (select.value !== '') select.form.submit();
}
</script>
<?php endif; ?>
</body>
</html>
