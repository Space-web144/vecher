<?php
declare(strict_types=1);

// Общее для страниц агента РВ (rv.php, rv_process.php, rv_status.php,
// rv_download.php): доступ, папки, карточки задач и их статусы.
// Обработку делает фоновый процесс program-c/web_rv_run.py.

require_once __DIR__ . '/config.php';
require_once __DIR__ . '/structure_lib.php';

/** Доступ к агенту — как к модулю ЦО: сотрудники отдела ЦО (и те, кому открыты все модули). */
function rv_guard(): void
{
    if (!kb_can_open_page('rv.php')) {
        http_response_code(404);
        header('Content-Type: text/html; charset=utf-8');
        echo '<!doctype html><meta charset="utf-8"><title>Страница не найдена</title><p>Страница не найдена.</p>';
        exit;
    }
}

function rv_fail(string $message, int $code = 400): never
{
    fail($message, $code, 'rv.php');
}

function rv_token_valid(string $token): bool
{
    return (bool) preg_match('/^[a-f0-9]{16}$/', $token);
}

/**
 * Файлы задачи в RV_OUTPUT_DIR. Результат и строки формы хранятся сжатыми (.json.gz — в 15 раз
 * меньше); у задач, построенных до сжатия, — несжатые .json, их и берём, пока задача жива.
 */
function rv_paths(string $token): array
{
    $base = RV_OUTPUT_DIR . '/' . $token;
    $packed = static function (string $name) use ($base): string {
        return is_file($base . $name) && !is_file($base . $name . '.gz') ? $base . $name : $base . $name . '.gz';
    };
    return ['job' => $base . '_job.json', 'status' => $base . '_status.json',
            'work' => $base . '_work.json', 'feedback' => $base . '_feedback.json',
            'xlsx' => $base . '_rv.xlsx', 'json' => $packed('_rv.json'), 'form' => $packed('_rv_form.json'),
            'onec' => $packed('_rv_1c.json'), 'in' => $base . '_in.json.gz', 'audit' => $base . '_audit.json', 'smeta' => $base . '_smeta.json',
            'head' => $base . '_head.json'];
}

/** Все файлы задачи на сервере (и недописанные .tmp, и загруженная ЛРВ, если осталась). */
function rv_job_files(string $token): array
{
    if (!rv_token_valid($token)) {
        return [];
    }
    return array_merge(glob(RV_OUTPUT_DIR . '/' . $token . '_*') ?: [], glob(RV_UPLOAD_DIR . '/' . $token . '.*') ?: []);
}

/** Сколько места занимает задача, байт. */
function rv_job_size(string $token): int
{
    $size = 0;
    foreach (rv_job_files($token) as $file) {
        $size += (int) @filesize($file);
    }
    return $size;
}

/** Замечания инженеров к агенту, новые первыми; $token — только по одной РВ. */
function rv_notes(?string $token = null, int $limit = 50): array
{
    if (!is_file(RV_NOTES_FILE)) {
        return [];
    }
    $notes = [];
    foreach (file(RV_NOTES_FILE, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [] as $line) {
        $note = json_decode($line, true);
        if (!is_array($note) || ($token !== null && (string) ($note['token'] ?? '') !== $token)) {
            continue;
        }
        $notes[] = $note;
    }
    return array_slice(array_reverse($notes), 0, $limit);
}

/** Размер для человека: «640 КБ», «1,6 МБ». */
function rv_size_text(int $bytes): string
{
    if ($bytes < 1024 * 1024) {
        return max(1, (int) round($bytes / 1024)) . ' КБ';
    }
    return str_replace('.', ',', (string) round($bytes / 1024 / 1024, 1)) . ' МБ';
}

/** Удалить задачу целиком. Память решений инженеров (RV_LEARNING_FILE) не трогается. */
function rv_delete_job(string $token): void
{
    foreach (rv_job_files($token) as $file) {
        @unlink($file);
    }
}

/**
 * Уборка без владельца: файлы задач без карточки (её удалили, пока процесс дописывал результат)
 * и загруженные ЛРВ, оставшиеся от оборванных запусков, — старше суток.
 */
function rv_sweep(): void
{
    $old = time() - 86400;
    foreach (glob(RV_OUTPUT_DIR . '/*') ?: [] as $file) {
        $name = basename($file);
        if (!preg_match('/^([a-f0-9]{16})_/', $name, $m) || is_file(RV_OUTPUT_DIR . '/' . $m[1] . '_job.json')) {
            continue;
        }
        if ((int) @filemtime($file) < $old) {
            @unlink($file);
        }
    }
    foreach (glob(RV_UPLOAD_DIR . '/*') ?: [] as $file) {
        if (preg_match('/^[a-f0-9]{16}\./', basename($file)) && (int) @filemtime($file) < $old) {
            @unlink($file);
        }
    }
}

function rv_read_json(string $path): ?array
{
    if (!is_file($path)) {
        return null;
    }
    $data = json_decode((string) file_get_contents($path), true);
    return is_array($data) ? $data : null;
}

/** JSON задачи, сжатый (.json.gz) или нет. */
function rv_read_packed(string $path): ?array
{
    if (!is_file($path)) {
        return null;
    }
    $raw = (string) file_get_contents($path);
    if (substr($path, -3) === '.gz') {
        $raw = (string) @gzdecode($raw);
    }
    $data = json_decode($raw, true);
    return is_array($data) ? $data : null;
}

/** Указания для одной РВ (rv_local.php): <токен>_local.json рядом с задачей — агент читает его сам (web_rv_run.local_input). */
function rv_local_path(string $token): string
{
    return RV_OUTPUT_DIR . '/' . $token . '_local.json';
}

/** Папка файлов ТЗ из указаний для одной РВ: <токен>_local/ рядом с задачей. */
function rv_local_dir(string $token): string
{
    return RV_OUTPUT_DIR . '/' . $token . '_local';
}

/** Указания для одной РВ: {text, files: [{name, file, size, by, at}], by, at, agent, fixes} или null. */
function rv_local_read(string $token): ?array
{
    $local = rv_read_json(rv_local_path($token));
    if (!is_array($local)) {
        return null;
    }
    $local['files'] = array_values(array_filter(is_array($local['files'] ?? null) ? $local['files'] : [],
        static fn ($f): bool => is_array($f) && preg_match('/^[a-z0-9_]+\.[a-z0-9]+$/', (string) ($f['file'] ?? '')) === 1));
    return $local;
}

/** UUID v5 (RFC 4122, SHA-1) по пространству имён и имени — как uuid.uuid5 в Python. */
function rv_uuid5(string $namespace, string $name): string
{
    $hash = sha1(hex2bin(str_replace('-', '', $namespace)) . $name);
    $hash = substr($hash, 0, 12) . '5' . substr($hash, 13, 3) . dechex((hexdec($hash[16]) & 0x3) | 0x8) . substr($hash, 17, 15);
    return substr($hash, 0, 8) . '-' . substr($hash, 8, 4) . '-' . substr($hash, 12, 4) . '-' . substr($hash, 16, 4) . '-' . substr($hash, 20, 12);
}

/** УИД сайта для задачи РВ — тот же, что пишет агент (web_rv_run.site_uuid): постоянен для token. */
function rv_site_uuid(string $token): string
{
    return $token !== '' ? rv_uuid5('6ba7b811-9dad-11d1-80b4-00c04fd430c8', 'alfastroi.info/rv/job/' . $token) : '';
}

/** GUID из идентификатора ЛРВ без приставки «Смета-»/«Сверка-» (web_rv_run.clean_guid); не GUID — ''. */
function rv_clean_guid(string $value): string
{
    return preg_match('/^(?:[^-]*-)?([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/', trim($value), $m) ? $m[1] : '';
}

/**
 * РВ для 1С (<token>_rv_1c.json[.gz]) на выдачу: файл, записанный агентом до появления полей связи с сайтом и сметой
 * (КодСайта, УИДСайта, ЛРВGUID, Смета, СметаGUID — в корне и в СопоставлениеРВиЛРВ.Документ), дополняется ими из
 * задачи, чтобы 1С получала их и по уже согласованным РВ без пересборки. Новый файл отдаётся как есть: null.
 */
function rv_onec_json_enriched(string $path, array $job): ?string
{
    $raw = (string) file_get_contents($path);
    if (substr($path, -3) === '.gz') {
        $raw = (string) @gzdecode($raw);
    }
    if ($raw === '' || strpos(substr($raw, 0, 600), '"КодСайта"') !== false) {
        return null;
    }
    $doc = json_decode($raw);          // объекты — stdClass, чтобы пустые {} не стали [] при обратной записи
    if (!$doc instanceof stdClass) {
        return null;
    }
    $token = (string) ($job['token'] ?? '');
    $meta = (array) ($job['meta'] ?? []);
    $head = isset($doc->{'Сопоставление1С'}) && $doc->{'Сопоставление1С'} instanceof stdClass ? (array) $doc->{'Сопоставление1С'} : [];
    $lrvId = (string) ($doc->{'ИдентификаторЛРВ'} ?? '');
    if ($lrvId === '') {
        $lrvId = (string) ($job['lrv_id'] ?? '');
    }
    $fields = [
        'ИдентификаторЛРВ' => $lrvId, 'ЛРВGUID' => rv_clean_guid($lrvId),
        'КодСайта' => $token, 'УИДСайта' => rv_site_uuid($token),
        'Смета' => (string) ($head['Смета'] ?? '') !== '' ? (string) $head['Смета'] : (string) ($meta['smeta'] ?? ''),
        'СметаGUID' => (string) ($head['СметаGUID'] ?? '') !== '' ? (string) $head['СметаGUID']
            : ((string) ($meta['smeta_id'] ?? '') !== '' ? (string) $meta['smeta_id'] : rv_clean_guid($lrvId)),
    ];
    foreach ($fields as $key => $value) {
        if (!isset($doc->{$key}) || (string) $doc->{$key} === '') {
            $doc->{$key} = $value;
        }
    }
    if (isset($doc->{'СопоставлениеРВиЛРВ'}) && $doc->{'СопоставлениеРВиЛРВ'} instanceof stdClass) {
        $sopost = $doc->{'СопоставлениеРВиЛРВ'};
        if (!isset($sopost->{'Документ'}) || !$sopost->{'Документ'} instanceof stdClass) {
            $sopost->{'Документ'} = new stdClass();
        }
        foreach ($fields as $key => $value) {
            if (!isset($sopost->{'Документ'}->{$key}) || (string) $sopost->{'Документ'}->{$key} === '') {
                $sopost->{'Документ'}->{$key} = $value;
            }
        }
    }
    $out = json_encode($doc, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_PRESERVE_ZERO_FRACTION);
    return is_string($out) ? $out : null;
}

/**
 * В пакете, как его прислала 1С (<token>_in.json.gz), есть отрицательные остатки: ЛРВ стала меньше, чем уже
 * разнесено в 1С (агент уменьшает разнесённое — web_rv_run.apply_reductions). Быстрая проверка, чтобы выбрать
 * РВ на пересборку (rv_rebuild.php, scope=reductions); точный разбор — в агенте.
 */
function rv_packet_has_reductions(string $path): bool
{
    if (!is_file($path)) {
        return false;
    }
    $data = json_decode((string) @gzdecode((string) file_get_contents($path)), true);
    if (!is_array($data)) {
        return false;
    }
    foreach ($data as $key => $rows) {
        if (!in_array(mb_strtolower((string) $key), ['строки', 'rows'], true) || !is_array($rows)) {
            continue;
        }
        foreach ($rows as $row) {
            foreach (is_array($row) ? $row : [] as $field => $value) {
                $name = mb_strtolower(str_replace([' ', '_'], '', (string) $field));
                if (($name === 'колво' || $name === 'количество') && is_scalar($value)
                        && (float) str_replace([',', ' '], ['.', ''], (string) $value) < 0) {
                    return true;
                }
            }
        }
    }
    return false;
}

/**
 * Строки ЛРВ без работы в РВ задачи: [id => наименование]. Пока они есть, РВ нельзя согласовать
 * («Согласовать РВ»): каждой строке инженер назначает работу, иначе в 1С материал останется
 * без работы. Строки, которые агент не включил (накладные расходы и т. п.), сюда не входят.
 */
function rv_unbound_rows(string $token): array
{
    $form = rv_read_packed(rv_paths($token)['form']);
    $out = [];
    foreach ((array) ($form['rows'] ?? []) as $row) {
        if (($row['t'] ?? '') === 'mat' && trim((string) ($row['code'] ?? '')) === '') {
            $out[(int) ($row['id'] ?? 0)] = (string) ($row['name'] ?? '');
        }
    }
    return $out;
}

/**
 * Состояние задачи для страницы: running / done / error / stalled / missing
 * и сам статус. Молчание дольше RV_STALL_SEC — процесс оборвался.
 */
function rv_state(string $token, ?array $job): array
{
    $paths = rv_paths($token);
    $status = rv_read_json($paths['status']);
    if ($status === null) {
        return ['missing', null];
    }
    $state = (string) ($status['state'] ?? '');
    if ($state === 'done' && !is_file($paths['xlsx'])) {
        $state = 'error';
        $status['error'] = 'Книга Excel не сохранилась на сервере.';
    }
    if ($state === 'awaiting_confirm') {
        return [is_file($paths['work']) ? 'awaiting_confirm' : 'error', $status];
    }
    if ($state === 'queued') {
        return ['queued', $status];
    }
    if ($state === 'running' || $state === '') {
        $updated = (int) ($status['updated'] ?? 0);
        $since = time() - max($updated, (int) ($job['created'] ?? 0));
        if (($status['launched'] ?? null) === false && $since > RV_START_TIMEOUT_SEC) {
            $state = 'stalled';
        } elseif ($since > RV_STALL_SEC) {
            $state = 'stalled';
        } else {
            $state = 'running';
        }
    }
    return [$state, $status];
}

/**
 * Задачу видит её автор; ЛРВ, присланные 1С (origin = 1c), — все, у кого есть доступ к РВ:
 * это общий входящий поток объекта, а не чья-то личная загрузка.
 */
function rv_can_access(array $job): bool
{
    $me = (string) ($_SESSION['kb_user'] ?? '');
    return ($me !== '' && (string) ($job['user'] ?? '') === $me) || (string) ($job['origin'] ?? '') === '1c';
}

/**
 * Запустить разбор очереди ЛРВ из 1С. Второй разборщик сам выходит, если первый уже работает,
 * поэтому звать можно смело — после каждого приёма и при открытии списка, если очередь стоит.
 */
function rv_queue_kick(): void
{
    rv_launch(['--phase', 'queue', '--queue-dir', RV_OUTPUT_DIR, '--credentials', ANTHROPIC_CREDENTIALS_FILE,
               '--learning-file', RV_LEARNING_FILE, '--notes-file', RV_NOTES_FILE]);
}

/**
 * Мои задачи и задачи из 1С, новые сверху; попутно удаляются просроченные и бесхозные файлы.
 * Сверка РВ из 1С (mode = audit) здесь не показывается — у неё свой список, rv_audit.php ($audit = true — только она).
 */
function rv_my_jobs(string $user, bool $audit = false): array
{
    $jobs = [];
    $expire = time() - RV_KEEP_DAYS * 86400;
    rv_sweep();
    foreach (glob(RV_OUTPUT_DIR . '/*_job.json') ?: [] as $path) {
        $token = basename($path, '_job.json');
        if (!rv_token_valid($token)) {
            continue;
        }
        $job = rv_read_json($path);
        if ($job === null) {
            continue;
        }
        if ((int) ($job['created'] ?? 0) < $expire) {
            rv_delete_job($token);
            continue;
        }
        if (!rv_can_access($job)) {
            continue;
        }
        [$state, $status] = rv_state($token, $job);
        $job['token'] = $token;
        $job['state'] = $state;
        $job['status'] = $status;
        if ($state === 'queued' && time() - (int) ($status['updated'] ?? 0) > RV_QUEUE_KICK_SEC) {
            $stuck = true;
        }
        if ((($job['mode'] ?? '') === 'audit') !== $audit) {
            continue;
        }
        $job['size'] = rv_job_size($token);
        $jobs[] = $job;
    }
    if (!empty($stuck)) {
        rv_queue_kick();      // очередь стоит дольше обычного — разборщик мог не запуститься
    }
    usort($jobs, fn($a, $b) => (int) ($b['created'] ?? 0) <=> (int) ($a['created'] ?? 0));
    return $jobs;
}

/**
 * Согласование РВ инженером: «Согласовать РВ» на странице РВ, после чего агент пересобрал РВ,
 * и в ней не осталось строк без работы. Возвращает [user, when, corrected, confirmed] или null —
 * РВ только подготовлена агентом. Это же правило отдаётся 1С полем checked (1c_rv.php).
 */
function rv_approval(?array $job, ?array $status): ?array
{
    $feedback = is_array($status['feedback'] ?? null) ? $status['feedback'] : null;
    if ($feedback === null || ($status['state'] ?? '') !== 'done' || empty($job['feedback'])
            || (int) ($status['summary']['unbound'] ?? 0) > 0) {
        return null;
    }
    return ['user' => (string) ($feedback['user'] ?? ''), 'when' => (int) $job['feedback'],
            'corrected' => (int) ($feedback['corrected'] ?? 0), 'confirmed' => (int) ($feedback['confirmed'] ?? 0)];
}

function rv_state_label(string $state): array
{
    switch ($state) {
        case 'done':
            return ['Готово', 'done'];
        case 'running':
            return ['Идёт разбор', 'run'];
        case 'awaiting_confirm':
            return ['Ждёт подтверждения', 'wait'];
        case 'queued':
            return ['В очереди', 'wait'];
        case 'stalled':
            return ['Прервано', 'error'];
        case 'missing':
            return ['Не запущено', 'error'];
    }
    return ['Ошибка', 'error'];
}

function rv_when(int $time): string
{
    if ($time <= 0) {
        return '';
    }
    return date('d.m.Y', $time) === date('d.m.Y') ? 'сегодня, ' . date('H:i', $time) : date('d.m.Y H:i', $time);
}

/**
 * Запуск фазы агента в фоне; вывод — в журнал ошибок папки РВ.
 * Оболочка повторяет запуск, если процессу не хватило памяти на старте (код 75 —
 * на общем хостинге память аккаунта бывает занята другими процессами);
 * MALLOC_ARENA_MAX=2 — меньше резервируемой виртуальной памяти (лимит хостинга считает и её).
 */
function rv_launch(array $args): void
{
    $cmd = [escapeshellarg(PYTHON_BIN), '-u', escapeshellarg(RV_RUN_SCRIPT)];
    foreach ($args as $arg) {
        $cmd[] = escapeshellarg((string) $arg);
    }
    $phase = '';
    $i = array_search('--phase', $args, true);
    if ($i !== false && isset($args[$i + 1])) {
        $phase = preg_replace('/[^a-z]/', '', (string) $args[$i + 1]);
    }
    $attempts = (int) RV_START_ATTEMPTS;
    $threadEnv = '';
    foreach (PYTHON_THREAD_ENV as $name => $value) {
        $threadEnv .= $name . '=' . escapeshellarg($value) . ' ';
    }
    $script = 'echo "=== $(date "+%d.%m.%Y %H:%M:%S") агент РВ, фаза ' . $phase . '"; '
            . 'for i in ' . implode(' ', range(1, max(1, $attempts))) . '; do '
            . 'RV_ATTEMPT=$i RV_ATTEMPTS=' . $attempts . ' RV_RETRY_SEC=' . (int) RV_START_RETRY_SEC
            . ' MALLOC_ARENA_MAX=2 ' . $threadEnv . implode(' ', $cmd) . '; rc=$?; '
            . '[ $rc -eq 75 ] || exit $rc; '
            . '[ $i -lt ' . $attempts . ' ] && sleep ' . (int) RV_START_RETRY_SEC . '; '
            . 'done';
    $logFile = RV_OUTPUT_DIR . '/rv_errors.log';
    rv_trim_log($logFile);
    exec('nohup sh -c ' . escapeshellarg($script) . ' >> ' . escapeshellarg($logFile) . ' 2>&1 &');
}

/** Журнал фоновых запусков не растёт без конца: больше RV_LOG_MAX_BYTES — остаётся последняя четверть. */
function rv_trim_log(string $logFile): void
{
    $size = is_file($logFile) ? (int) filesize($logFile) : 0;
    if ($size <= RV_LOG_MAX_BYTES || !($fh = fopen($logFile, 'r'))) {
        return;
    }
    fseek($fh, $size - intdiv(RV_LOG_MAX_BYTES, 4));
    $tail = (string) stream_get_contents($fh);
    fclose($fh);
    $cut = strpos($tail, "\n");
    file_put_contents($logFile, $cut === false ? $tail : substr($tail, $cut + 1), LOCK_EX);
}

/** Словарь систем раздела для выбора на странице подтверждения (как A2 мастер-инструкции). */
function rv_systems(string $section): array
{
    switch ($section) {
        case 'ВК':
            return ['К1', 'К2', 'К3', 'К4', 'В1', 'В2', 'ШП', 'прочие'];
        case 'ОВ1':
            return ['отопление', 'ПУ', 'УУ'];
        case 'ОВ2':
            return ['ОВ', 'ПДВ'];
        case 'ЭОМ':
            return ['нежилая', 'квартиры', 'кондиционирование', 'ЦИН', 'фасад'];
        case 'СС':
            return ['1', '2.1', '2.2', '3', '4', '5', '6', '7', '8', '9', '9.1', '9.2', '9.3', '9.4', '9.5', '9.6', '9.7', '9.8', '9.9',
                    '10', '10.1', '10.2', '10.3', '10.4', '11', '12', '13', '14', '15'];
    }
    return [];
}

/** Системы всех разделов: раздел → список значений для bind.py. */
function rv_systems_all(): array
{
    $all = [];
    foreach (RV_SECTIONS as $section) {
        $all[$section] = rv_systems($section);
    }
    return $all;
}

/** Подпись системы для выбора: у СС — ветка с названием подсистемы. */
function rv_system_label(string $section, string $system): string
{
    static $ss = [
        '1' => 'АК — автоматизация', '2.1' => 'АИИС КУЭ', '2.2' => 'АСКУВТ — учёт воды и тепла', '3' => 'АОДИ',
        '4' => 'АСУД — диспетчеризация', '5' => 'АПС/СОУЭ', '6' => 'АУПТ', '7' => 'КК — кабельные конструкции',
        '8' => 'ОСПД', '9' => 'Сети связи (общий том)', '9.1' => 'СКС', '9.2' => 'Радиофикация', '9.3' => 'Телевидение',
        '9.4' => 'ветка 9.4', '9.5' => 'Часофикация', '9.6' => 'Оповещение ГОЧС', '9.7' => 'Wi-Fi', '9.8' => 'ВОЛС',
        '9.9' => 'ЛВС/АРМ', '10' => 'СОВ/СКУД (общий том)', '10.1' => 'СОВ — домофония', '10.2' => 'СКУД/САВ',
        '10.3' => 'СКУД шлагбаум', '10.4' => 'СКУД калитка', '11' => 'СВН/СОТ — видеонаблюдение', '12' => 'ОЗДС',
        '13' => 'Безопасный регион', '14' => 'СОТС', '15' => 'СКЗ',
    ];
    // ВК: ветки КЦ 6.2.3.1.1–7, 99 (К3 — производственная канализация, дренажная — К4).
    static $vk = [
        'К1' => 'хоз-бытовая канализация', 'К2' => 'ливневая канализация', 'К3' => 'производственная канализация',
        'К4' => 'дренажная канализация', 'В1' => 'хоз-питьевое водоснабжение', 'В2' => 'противопожарный водопровод, АУПТ',
        'ШП' => 'шахт-пакеты',
    ];
    if ($section === 'СС') {
        return $system . ' — ' . ($ss[$system] ?? 'ветка ' . $system);
    }
    if ($section === 'ВК' && isset($vk[$system])) {
        return $system . ' — ' . $vk[$system];
    }
    return $system;
}

/** <option> систем всех разделов, значения «ВК|В1»; $selected — такое же значение. */
function rv_system_options(string $selected = '', string $firstSection = ''): string
{
    $all = rv_systems_all();
    if ($firstSection !== '' && isset($all[$firstSection])) {
        $all = [$firstSection => $all[$firstSection]] + $all;
    }
    $html = '';
    foreach ($all as $section => $systems) {
        $html .= '<optgroup label="' . rv_h($section) . '">';
        foreach ($systems as $system) {
            $value = $section . '|' . $system;
            $html .= '<option value="' . rv_h($value) . '"' . ($value === $selected ? ' selected' : '') . '>'
                . rv_h($section . ': ' . rv_system_label($section, $system)) . '</option>';
        }
        $html .= '</optgroup>';
    }
    return $html;
}

/** «ВК|В1» → [раздел, система]; проверка по словарю. */
function rv_system_split(string $value): ?array
{
    if (strpos($value, '|') === false) {
        return null;
    }
    [$section, $system] = explode('|', $value, 2);
    if (!in_array($section, RV_SECTIONS, true) || !in_array($system, rv_systems($section), true)) {
        return null;
    }
    return [$section, $system];
}

/** Токен формы против подделки запроса (общий для сайта ключ сессии csrf). */
function rv_csrf(): string
{
    if (empty($_SESSION['csrf'])) {
        $_SESSION['csrf'] = bin2hex(random_bytes(16));
    }
    return (string) $_SESSION['csrf'];
}

/** Задача принадлежит текущему пользователю — иначе страница ошибки. */
function rv_own_job(string $token): array
{
    if (!rv_token_valid($token)) {
        rv_fail('Неверный номер задачи.');
    }
    $paths = rv_paths($token);
    $job = rv_read_json($paths['job']);
    if ($job === null) {
        rv_fail('Задача не найдена или устарела.', 404);
    }
    if (!rv_can_access($job)) {
        rv_fail('Эта задача принадлежит другому пользователю.', 403);
    }
    return [$job, $paths];
}

/** Ответ JSON (со сжатием, если браузер его принимает: строки РВ — мегабайты). */
function rv_json(array $payload, int $code = 200): never
{
    http_response_code($code);
    header('Content-Type: application/json; charset=utf-8');
    header('Cache-Control: no-store');
    if (!headers_sent() && strpos((string) ($_SERVER['HTTP_ACCEPT_ENCODING'] ?? ''), 'gzip') !== false
            && function_exists('gzencode') && !ini_get('zlib.output_compression')) {
        $body = gzencode(json_encode($payload, JSON_UNESCAPED_UNICODE), 6);
        header('Content-Encoding: gzip');
        header('Content-Length: ' . strlen($body));
        echo $body;
        exit;
    }
    echo json_encode($payload, JSON_UNESCAPED_UNICODE);
    exit;
}

function rv_h(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}


// ── Объекты и ЛРВ из 1С (rv_registry.php, rv_smeta.php) ──
// Дерево: объект (папка номенклатурных групп в 1С) → номенклатурная группа → смета (система, номер ЗН) → РВ.
// Объекты регистрируются сами: каждая присланная ЛРВ пополняет справочник RV_OBJECTS_FILE
// (rv_objects_register), новый объект появляется с первой ЛРВ, имена и номер ЗН — по последней.

/** Ключ для группировки: GUID из 1С, если он есть, иначе название без регистра и лишних пробелов. */
function rv_registry_key(string $guid, string $name): string
{
    $guid = trim($guid);
    if ($guid !== '') {
        return 'g:' . mb_strtolower($guid);
    }
    return 'n:' . mb_strtolower(preg_replace('/\s+/u', ' ', trim($name)) ?? '');
}

/** Прочитать JSON-файл данных и записать изменённый под блокировкой. $change(array): ?array — null: писать нечего. */
function rv_data_update(string $file, callable $change): bool
{
    $dir = dirname($file);
    if (!is_dir($dir) && !mkdir($dir, 0775, true) && !is_dir($dir)) {
        return false;
    }
    $handle = fopen($file . '.lock', 'c');
    if ($handle === false || !flock($handle, LOCK_EX)) {
        return false;
    }
    $ok = false;
    try {
        $data = $change(rv_read_json($file) ?? []);
        if ($data === null) {
            $ok = true;
        } else {
            $tmp = $file . '.tmp';
            $ok = file_put_contents($tmp, json_encode($data, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT)) !== false
                && rename($tmp, $file);
        }
    } finally {
        flock($handle, LOCK_UN);
        fclose($handle);
    }
    return $ok;
}

/**
 * Справочник объектов из 1С: {folders: {ключ: {name, guid, first, updated}},
 * groups: {ключ НГ: {name, guid, folder, first, updated}},
 * smetas: {ИдентификаторЛРВ: {smeta, smeta_id, system, system_id, group, zn, token, first, updated}}}.
 */
function rv_objects(?array $data = null): array
{
    $data = $data ?? (rv_read_json(RV_OBJECTS_FILE) ?? []);
    return ['folders' => (array) ($data['folders'] ?? []), 'groups' => (array) ($data['groups'] ?? []),
            'smetas' => (array) ($data['smetas'] ?? [])];
}

/**
 * Объект, номенклатурная группа, система, смета и номер ЗН задачи из 1С. С 1С приходят в шапке пакета
 * (meta при приёме, 1c_rv.php); у задач, принятых раньше, — из «Объект» вида «Номенклатурная группа / Смета».
 * С $objects (справочник) имена, папка НГ и номер ЗН берутся по последней присланной ЛРВ: задачи, пришедшие
 * до того, как 1С стала присылать папку, встают под свой объект, как только папка придёт с любой ЛРВ этой НГ.
 * folder_known / zn_known — 1С прислала поле (пусть и пустое): пустое значение тогда тоже значимо.
 */
function rv_registry_meta(array $job, ?array $objects = null): array
{
    $meta = is_array($job['meta'] ?? null) ? $job['meta'] : [];
    $object = (string) ($job['object'] ?? '');
    $parts = array_map('trim', explode(' / ', $object, 2));
    $obj = trim((string) ($meta['obj'] ?? '')) ?: ($parts[0] !== '' ? $parts[0] : 'Без номенклатурной группы');
    $smeta = trim((string) ($meta['smeta'] ?? '')) ?: ($parts[1] ?? '');
    $system = trim((string) ($meta['system'] ?? '')) ?: ($smeta !== '' ? $smeta : 'Система не указана');
    $objKey = rv_registry_key((string) ($meta['obj_id'] ?? ''), $obj);
    $folder = trim((string) ($meta['folder'] ?? ''));
    $folderId = trim((string) ($meta['folder_id'] ?? ''));
    $folderKey = $folder !== '' || $folderId !== '' ? rv_registry_key($folderId, $folder) : '';
    $zn = trim((string) ($meta['zn'] ?? ''));
    $kind = trim((string) ($meta['kind'] ?? ''));
    if ($objects !== null) {
        $group = (array) ($objects['groups'][$objKey] ?? []);
        if (!empty($group['name'])) {
            $obj = (string) $group['name'];
        }
        if (array_key_exists('folder', $group)) {
            $folderKey = (string) $group['folder'];
        }
        $folder = $folderKey !== '' ? (string) ($objects['folders'][$folderKey]['name'] ?? $folder) : '';
        $known = (array) ($objects['smetas'][(string) ($job['lrv_id'] ?? '')] ?? []);
        if (array_key_exists('zn', $known)) {
            $zn = (string) $known['zn'];
        }
    }
    return [
        'folder' => $folder, 'folder_key' => $folderKey, 'folder_id' => $folderId,
        'folder_known' => array_key_exists('folder', $meta) || array_key_exists('folder_id', $meta),
        'obj' => $obj, 'obj_key' => $objKey, 'obj_id' => (string) ($meta['obj_id'] ?? ''),
        'system' => $system, 'system_key' => rv_registry_key((string) ($meta['system_id'] ?? ''), $system),
        'system_id' => (string) ($meta['system_id'] ?? ''),
        'smeta' => $smeta, 'smeta_id' => (string) ($meta['smeta_id'] ?? ''),
        'analytics' => trim((string) ($meta['analytics'] ?? '')),            // Аналитика 2 и 3 сметы (уточняют систему)
        'zn' => $zn, 'zn_known' => array_key_exists('zn', $meta),
        'sender' => array_key_exists('sender', $meta) ? trim((string) $meta['sender']) : null,  // кто отправил из 1С ('' — регламент)
        'work_kind' => $kind !== '' ? $kind : rv_kind_of($smeta, $zn),       // вид работ: осн / НЗ ('kind' занят видом значка)
    ];
}

/**
 * Вид работ сметы: «осн» — основные работы (основной договор), «НЗ» — наряд-заказ. По «Аналитике 4» при приёме
 * (1c_rv.php), у старых задач — по номеру ЗН и имени сметы. ДР и РВР не различаются (решение ЦО).
 */
function rv_kind_of(string $smeta, string $zn, string $analytic4 = ''): string
{
    $text = mb_strtolower($analytic4 !== '' ? $analytic4 : $smeta);
    if ($zn !== '' || preg_match('~з\s*/\s*н|заказ[\s-]*наряд|наряд[\s-]*заказ|(^|[^а-яё])нз([^а-яё]|$)~u', $text)) {
        return 'НЗ';
    }
    return 'осн';
}

/**
 * Зарегистрировать в справочнике объект, номенклатурную группу и смету задач из 1С (job с 'token').
 * Новое появляется само; известное обновляется, только если задача не старее записи (имена, папка НГ, номер ЗН —
 * по последней ЛРВ). $onlyMissing — только сметы, которых в справочнике нет (дозаполнение по старым задачам).
 */
function rv_objects_register(array $jobs, bool $onlyMissing = false): bool
{
    return rv_data_update(RV_OBJECTS_FILE, static function (array $raw) use ($jobs, $onlyMissing): ?array {
        $data = rv_objects($raw);
        $changed = false;
        $set = static function (array $old, array $fields, int $at): array {
            $newer = $at >= (int) ($old['updated'] ?? 0);
            foreach ($fields as $key => $value) {
                if ($value !== null && ($newer || !array_key_exists($key, $old) || $old[$key] === '')) {
                    $old[$key] = $value;
                }
            }
            $old['first'] = min((int) ($old['first'] ?? $at), $at);
            $old['updated'] = max((int) ($old['updated'] ?? 0), $at);
            return $old;
        };
        foreach ($jobs as $job) {
            $lrvId = (string) ($job['lrv_id'] ?? '');
            if ($lrvId === '' || ($onlyMissing && isset($data['smetas'][$lrvId]))) {
                continue;
            }
            $m = rv_registry_meta($job);
            $at = (int) ($job['created'] ?? time());
            if ($m['folder_key'] !== '') {
                $data['folders'][$m['folder_key']] = $set((array) ($data['folders'][$m['folder_key']] ?? []),
                    ['name' => $m['folder'] !== '' ? $m['folder'] : 'Объект без названия', 'guid' => $m['folder_id']], $at);
            }
            $data['groups'][$m['obj_key']] = $set((array) ($data['groups'][$m['obj_key']] ?? []),
                ['name' => $m['obj'], 'guid' => $m['obj_id'], 'folder' => $m['folder_known'] ? $m['folder_key'] : null], $at);
            $data['smetas'][$lrvId] = $set((array) ($data['smetas'][$lrvId] ?? []),
                ['smeta' => $m['smeta'], 'smeta_id' => $m['smeta_id'], 'system' => $m['system'], 'system_id' => $m['system_id'],
                 'group' => $m['obj_key'], 'zn' => $m['zn_known'] ? $m['zn'] : null, 'token' => (string) ($job['token'] ?? '')], $at);
            $changed = true;
        }
        return $changed ? $data : null;
    });
}

/** Ответственные сметчики: {folders: {ключ объекта: {user, by, at}}, objects: {ключ НГ: {…}}, systems: {ключ НГ|ключ системы: {…}}}. */
function rv_assignments(?array $data = null): array
{
    $data = $data ?? (rv_read_json(RV_ASSIGN_FILE) ?? []);
    return ['folders' => (array) ($data['folders'] ?? []), 'objects' => (array) ($data['objects'] ?? []),
            'systems' => (array) ($data['systems'] ?? []),
            'smetas' => (array) ($data['smetas'] ?? []),          // руководитель назначил на конкретную РВ (ИдентификаторЛРВ)
            'onec_users' => (array) ($data['onec_users'] ?? [])]; // пользователь 1С → логин сайта, когда автосопоставление не сошлось
}

/**
 * Логин сайта для пользователя 1С («Отправил» в пакете ЛРВ): сначала ручное сопоставление руководителя, иначе по
 * фамилии и первой букве имени — логины сайта вида «vasileva.a_CO». Транслитерация допускает варианты
 * (й → y/i/j, я → ya/ia, ю → yu/u/iu, щ → sch/csh/shch, х → h/kh, ц → ts/c), совпадение — по началу логина до точки
 * и букве после неё. Возвращает ['login' => '', 'how' => 'manual'|'auto'|''].
 */
function rv_onec_login(string $name, ?array $assign = null): array
{
    static $memo = [];
    $name = preg_replace('/\s+/u', ' ', trim($name)) ?? '';
    if ($name === '') {
        return ['login' => '', 'how' => ''];
    }
    $assign = $assign ?? rv_assignments();
    $manual = (string) ((($assign['onec_users'][$name] ?? [])['login']) ?? '');
    if ($manual !== '') {
        return ['login' => $manual, 'how' => 'manual'];
    }
    if (isset($memo[$name])) {
        return $memo[$name];
    }
    $words = preg_split('/[\s.,]+/u', mb_strtolower($name)) ?: [];
    $words = array_values(array_filter($words, static fn(string $w): bool => $w !== '' && preg_match('/^[а-яё-]+$/u', $w) === 1));
    if (!$words) {
        return $memo[$name] = ['login' => '', 'how' => ''];
    }
    $surnames = rv_translit_variants($words[0]);
    $initials = isset($words[1]) ? rv_translit_variants(mb_substr($words[1], 0, 1)) : [];
    $hits = [];
    foreach (array_keys(rv_estimators()) as $login) {
        $base = mb_strtolower(preg_replace('/_[A-Za-z]{1,4}$/', '', $login) ?? $login);
        [$sur, $ini] = array_pad(explode('.', $base, 2), 2, '');
        if (!in_array($sur, $surnames, true)) {
            continue;
        }
        if ($initials && $ini !== '' && !in_array(mb_substr($ini, 0, 1), array_map(static fn(string $v): string => mb_substr($v, 0, 1), $initials), true)) {
            continue;
        }
        $hits[] = $login;
    }
    return $memo[$name] = count($hits) === 1 ? ['login' => $hits[0], 'how' => 'auto'] : ['login' => '', 'how' => ''];
}

/** Варианты латинского написания русского слова (для сопоставления с логинами сайта). */
function rv_translit_variants(string $word): array
{
    static $map = [
        'а' => ['a'], 'б' => ['b'], 'в' => ['v'], 'г' => ['g'], 'д' => ['d'], 'е' => ['e', 'ye'], 'ё' => ['e', 'yo', 'io'], 'ж' => ['zh'],
        'з' => ['z'], 'и' => ['i'], 'й' => ['y', 'i', 'j'], 'к' => ['k'], 'л' => ['l'], 'м' => ['m'], 'н' => ['n'], 'о' => ['o'],
        'п' => ['p'], 'р' => ['r'], 'с' => ['s'], 'т' => ['t'], 'у' => ['u'], 'ф' => ['f'], 'х' => ['h', 'kh'], 'ц' => ['ts', 'c'],
        'ч' => ['ch'], 'ш' => ['sh'], 'щ' => ['sch', 'csh', 'shch', 'sh'], 'ъ' => [''], 'ы' => ['y', 'i'], 'ь' => [''], 'э' => ['e'],
        'ю' => ['yu', 'u', 'iu', 'ju'], 'я' => ['ya', 'ia', 'ja'], '-' => ['-', ''],
    ];
    $variants = [''];
    foreach (preg_split('//u', $word, -1, PREG_SPLIT_NO_EMPTY) ?: [] as $ch) {
        $next = [];
        foreach ($variants as $v) {
            foreach ($map[$ch] ?? [$ch] as $t) {
                $next[] = $v . $t;
            }
        }
        $variants = array_slice(array_unique($next), 0, 400);
    }
    return $variants;
}

/** Изменить назначения под блокировкой файла: $change(array $data): array. */
function rv_assign_update(callable $change): bool
{
    return rv_data_update(RV_ASSIGN_FILE, static fn(array $raw): array => $change(rv_assignments($raw)));
}

/**
 * Ответственный за РВ. Правило: кто отправил ЛРВ на сайт из 1С («Отправил» в пакете), тот и отвечает — его логин
 * на сайте через rv_onec_login. Руководитель может назначить другого на конкретную РВ (assign['smetas'][ИдентификаторЛРВ]).
 * Пакеты без поля «Отправил» (регламентное задание, старый модуль 1С) — по прежней таблице объектов и ячеек.
 * ['user' => логин, 'level' => smeta|sender|…, 'onec' => имя в 1С]; отправитель без учётки — ['user' => '', 'level' => 'sender_unknown'].
 */
function rv_responsible(array $assign, array $meta): ?array
{
    $manual = ($meta['id'] ?? '') !== '' ? ($assign['smetas'][(string) $meta['id']] ?? null) : null;
    if (is_array($manual) && !empty($manual['user'])) {
        return $manual + ['level' => 'smeta', 'onec' => (string) ($meta['sender'] ?? '')];
    }
    $sender = trim((string) ($meta['sender'] ?? ''));
    if ($sender !== '') {
        $login = rv_onec_login($sender, $assign);
        return ['user' => $login['login'], 'login' => $login['login'], 'level' => $login['login'] !== '' ? 'sender' : 'sender_unknown',
                'how' => $login['how'], 'onec' => $sender];
    }
    $own = $assign['systems'][$meta['obj_key'] . '|' . $meta['system_key']] ?? null;
    if (is_array($own) && !empty($own['user'])) {
        return $own + ['level' => 'system'];
    }
    $group = $assign['objects'][$meta['obj_key']] ?? null;
    if (is_array($group) && !empty($group['user'])) {
        return $group + ['level' => 'object'];
    }
    $folder = ($meta['folder_key'] ?? '') !== '' ? ($assign['folders'][$meta['folder_key']] ?? null) : null;
    if (is_array($folder) && !empty($folder['user'])) {
        return $folder + ['level' => 'folder'];
    }
    $table = rv_table_responsible($meta['match'] ?? rv_table_match($meta), (string) ($meta['work_kind'] ?? 'осн'));
    return $table['user'] !== '' || $table['login'] !== '' ? $table : null;
}

// ── Объекты, корпуса и ответственные (таблица «Объекты и сметчики» на сайте) ──

/**
 * Справочник объектов: {version, systems, objects: [{name, code, buildings: [{name, nz, resp: {система: {осн, НЗ}}}]}],
 * excluded: [имена закрытых объектов], fallback: {ОВВК, ЭОМСС} — запасные сметчики, когда в ячейке пусто,
 * bind: {ключ НГ: {object, building}} — привязки номенклатурных групп 1С, сделанные вручную}.
 * Правленый на сайте RV_TABLE_FILE, иначе исходный из репозитория RV_TABLE_DEFAULT.
 */
function rv_table(bool $fresh = false): array
{
    static $cache = null;
    if ($cache !== null && !$fresh) {
        return $cache;
    }
    $data = (is_file(RV_TABLE_FILE) ? rv_read_json(RV_TABLE_FILE) : null) ?? rv_read_json(RV_TABLE_DEFAULT) ?? [];
    $cache = [
        'version' => (string) ($data['version'] ?? ''),
        'systems' => (array) ($data['systems'] ?? ['Отопление', 'Вентиляция', 'ВК', 'ЭОМ', 'СС', 'Механизация']),
        'objects' => array_values(array_filter((array) ($data['objects'] ?? []), 'is_array')),
        'excluded' => array_values(array_map('strval', (array) ($data['excluded'] ?? []))),
        'fallback' => ['ОВВК' => (string) (($data['fallback'] ?? [])['ОВВК'] ?? ''), 'ЭОМСС' => (string) (($data['fallback'] ?? [])['ЭОМСС'] ?? '')],
        'bind' => (array) ($data['bind'] ?? []),
        'managers' => array_values(array_filter(array_map('strval', (array) ($data['managers'] ?? [])), static fn(string $l): bool => $l !== '')),
        'source' => is_file(RV_TABLE_FILE) ? 'site' : 'default',
    ];
    return $cache;
}

/** Записать справочник (правка на сайте): $change(array $table): array. */
function rv_table_update(callable $change): bool
{
    $ok = rv_data_update(RV_TABLE_FILE, static function (array $raw) use ($change): array {
        $table = rv_table(true);
        $table = $change($table);
        unset($table['source']);
        return $table;
    });
    rv_table(true);
    return $ok;
}

/** Действующие объекты справочника (без архива — «excluded»), в порядке таблицы. */
function rv_table_objects(?array $table = null): array
{
    $table = $table ?? rv_table();
    $excluded = array_flip($table['excluded']);
    return array_values(array_filter($table['objects'], static fn(array $o): bool => !isset($excluded[(string) ($o['name'] ?? '')])));
}

/** Объекты в архиве (завершённые: «excluded» справочника) — в дереве и списке ответственных только по запросу. */
function rv_table_archived(?array $table = null): array
{
    $table = $table ?? rv_table();
    $excluded = array_flip($table['excluded']);
    return array_values(array_filter($table['objects'], static fn(array $o): bool => isset($excluded[(string) ($o['name'] ?? '')])));
}

/** Объект справочника по имени (действующий или в архиве) или null. */
function rv_table_object(string $name, ?array $table = null): ?array
{
    foreach (($table ?? rv_table())['objects'] as $o) {
        if ((string) ($o['name'] ?? '') === $name) {
            return $o;
        }
    }
    return null;
}

/** Ключ объекта справочника для назначений (rv_assign.php, уровень folder): «t:имя». */
function rv_table_key(string $objectName): string
{
    return 't:' . mb_strtolower(preg_replace('/\s+/u', ' ', trim($objectName)) ?? '');
}

/**
 * Имя для сравнения: строчные, «ё» → «е», знаки → пробелы, точки только внутри чисел («к.1.4» → «к 1.4»),
 * без «жк» в начале.
 */
function rv_norm(string $text): string
{
    $t = mb_strtolower(trim($text));
    $t = str_replace('ё', 'е', $t);
    $t = preg_replace('/(?<=\d)[,](?=\d)/u', '.', $t) ?? $t;               // 16,2 → 16.2
    $t = preg_replace('/(?<!\d)\.|\.(?!\d)/u', ' ', $t) ?? $t;             // точки не между цифрами
    $t = preg_replace('/[,;:()«»"\'\/\\№_]+|\s-\s|-(?!\d)/u', ' ', $t) ?? $t;
    $t = preg_replace('/\s+/u', ' ', $t) ?? $t;
    $t = preg_replace('/^(жк|ж к)\s+/u', '', trim($t)) ?? $t;
    return trim($t);
}

/**
 * Корпус из названия (номенклатурной группы 1С или строки таблицы): номер корпуса, секция, строение, блок,
 * паркинг. Возвращает [num, section, stroenie, blok, parking(bool), label] — label в виде таблицы: «к.1.4»,
 * «к.16.1 секц 1», «паркинг», «к.2.4 паркинг», «строение 1», «блок 4».
 */
function rv_parse_building(string $text): array
{
    $t = rv_norm($text);
    $r = ['num' => '', 'section' => '', 'stroenie' => '', 'blok' => '', 'parking' => false, 'label' => ''];
    if (preg_match('/(?:^|\s)(?:корпус|корп|к)\s*(\d+(?:\.\d+)*)(?:\s*-\s*(\d+(?:\.\d+)*))?/u', $t, $m)) {
        $r['num'] = $m[1] . (isset($m[2]) && $m[2] !== '' ? '-' . $m[2] : '');
    } elseif (preg_match('/^(\d+(?:\.\d+)+)(?:\s*-\s*(\d+(?:\.\d+)*))?(\s|$)/u', $t, $m)) {
        $r['num'] = $m[1] . (isset($m[2]) && $m[2] !== '' ? '-' . $m[2] : '');     // «21.3», «22.1-22.4» без «к.»
    }
    if (preg_match('/(?:^|\s)секц(?:ия|ии)?\s*(\d+(?:\.\d+)*)/u', $t, $m)) {
        $r['section'] = $m[1];
    }
    if (preg_match('/(?:^|\s)(?:стр|строение)\s*(\d+)(?:\s*-\s*(\d+))?/u', $t, $m)) {
        $r['stroenie'] = $m[1] . (isset($m[2]) && $m[2] !== '' ? '-' . $m[2] : '');
    }
    if (preg_match('/(?:^|\s)блок\s*(\d+)/u', $t, $m)) {
        $r['blok'] = $m[1];
    }
    $r['parking'] = (bool) preg_match('/паркинг|парковк/u', $t);
    $label = [];
    if ($r['num'] !== '') {
        $label[] = 'к.' . $r['num'];
    }
    if ($r['section'] !== '') {
        $label[] = 'секц ' . $r['section'];
    }
    if ($r['stroenie'] !== '') {
        $label[] = 'строение ' . $r['stroenie'];
    }
    if ($r['blok'] !== '' && $r['num'] === '') {
        $label[] = 'блок ' . $r['blok'];
    }
    if ($r['parking']) {
        $label[] = 'паркинг';
    }
    $r['label'] = implode(' ', $label);
    return $r;
}

/** Код работ РВ из значения 1С или формы: «12» (РВР), «6» (ДР, основные работы) или '' — не задан. */
function rv_code_root_of($value): string
{
    $text = mb_strtolower(trim(is_scalar($value) ? (string) $value : ''));
    if ($text === '12' || preg_match('/(^|[^а-яёa-z])рвр([^а-яёa-z]|$)/u', $text)) {
        return '12';
    }
    if ($text === '6' || preg_match('/(^|[^а-яёa-z])др([^а-яёa-z]|$)|дополнительн/u', $text)) {
        return '6';
    }
    return '';
}

/** Код работ по работам сметы или РВ из 1С ([{Код | КодИСР, …}]): все работы одного кода — он, иначе ''. */
function rv_code_root_of_works(array $works): string
{
    $roots = [];
    foreach ($works as $work) {
        $code = trim((string) ($work['Код'] ?? $work['КодИСР'] ?? ''));
        if ($code !== '') {
            $roots[explode('.', $code)[0]] = true;
        }
    }
    return count($roots) === 1 && isset($roots['12']) ? '12' : (count($roots) === 1 && isset($roots['6']) ? '6' : '');
}

/** Подпись кода работ РВ: «ДР · код 6» / «РВР · код 12». */
function rv_code_root_label(string $root): string
{
    return $root === '12' ? 'РВР · код 12' : 'ДР · код 6';
}

/**
 * ЛРВ теплоснабжения (калориферы приточных установок, воздушно-тепловые завесы) — в КЦ раздел 6.2.3.2.7: $system —
 * «Аналитика 1» сметы, $others — смета, аналитики 2–3. Система, прямо названная иначе (отопление, вентиляция, ВК…),
 * сильнее упоминания теплоснабжения в остальных текстах.
 */
function rv_heat_supply(string $system, string ...$others): bool
{
    $heat = '/теплоснаб|калорифер/u';
    $system = mb_strtolower($system);
    if (preg_match($heat, $system)) {
        return true;
    }
    if (preg_match('/отоплен|вентиляц|кондицион|дымоудал|водоснаб|водопров|канализ|водосток|пожар|электро|освещ|слаботоч|автоматиз/u', $system)) {
        return false;
    }
    foreach ($others as $text) {
        if (preg_match($heat, mb_strtolower($text))) {
            return true;
        }
    }
    return false;
}

/** Система по названию (конец имени НГ, «Аналитика 1», смета): одна из шести систем таблицы или ''. */
function rv_table_system(string ...$texts): string
{
    // Сначала — явные системы в любом из текстов (смета, аналитики, НГ), и только потом общее «сантехнические
    // работы»: в 1С оно объединяет отопление и ВК, а смета или аналитика говорят точнее («Отопление к.1.2»).
    $specific = [
        'Вентиляция' => '/вентиляц|кондицион|дымоудал/u',
        'Отопление' => '/отоплен|теплоснаб|(^|[^а-яa-z])итп([^а-яa-z]|$)|(^|[^а-яa-z])ов([^а-яa-z]|$)|теплов[а-я]* пункт/u',
        'ЭОМ' => '/электромонтаж|электро|(^|[^а-яa-z])эом([^а-яa-z]|$)|освещен|молниез/u',
        'СС' => '/слаботоч|(^|[^а-яa-z])сс([^а-яa-z]|$)|(^|[^а-яa-z])cc([^а-яa-z]|$)|диспетчериз|видеонабл|пожарн[а-я]* сигнализ/u',
        'ВК' => '/(^|[^а-яa-z])вк([^а-яa-z]|$)|водоснаб|канализ|водопров|насосн|водоотвед/u',
        'Механизация' => '/механизац/u',
    ];
    $lower = array_values(array_filter(array_map('mb_strtolower', $texts), static fn(string $t): bool => $t !== ''));
    foreach ($lower as $t) {
        foreach ($specific as $system => $re) {
            if (preg_match($re, $t)) {
                return $system;
            }
        }
    }
    foreach ($lower as $t) {
        if (preg_match('/сантех/u', $t)) {
            return 'ВК';
        }
    }
    return '';
}

/**
 * Объект и корпус справочника для номенклатурной группы 1С: сначала ручная привязка (bind по ключу НГ),
 * иначе по названию: объект — самое длинное имя справочника, с которого начинается имя НГ (или папки НГ, или сметы);
 * корпус — по номеру корпуса, секции, строению, паркингу в имени НГ; не нашёлся — корпус из 1С как есть
 * (считаем верным то, что в 1С), ответственные по объекту. Система — по имени НГ, иначе по «Аналитике 1».
 * Возвращает {object (имя или ''), object_key, building (имя из таблицы или ''), building_label (как показывать),
 * building_row (строка таблицы или null), system, bound (ручная привязка)}.
 */
function rv_table_match(array $meta): array
{
    static $memo = [];
    $obj = (string) ($meta['obj'] ?? '');
    $key = ($meta['obj_key'] ?? '') . '|' . $obj . '|' . ($meta['folder'] ?? '') . '|' . ($meta['smeta'] ?? '') . '|' . ($meta['system'] ?? '') . '|' . ($meta['analytics'] ?? '');
    if (isset($memo[$key])) {
        return $memo[$key];
    }
    $table = rv_table();
    $out = ['object' => '', 'object_key' => '', 'building' => '', 'building_label' => '', 'building_row' => null,
            'system' => rv_table_system((string) ($meta['smeta'] ?? ''), (string) ($meta['analytics'] ?? ''), (string) ($meta['system'] ?? ''), $obj), 'bound' => false, 'archived' => false];
    $archived = array_flip($table['excluded']);
    $byName = [];
    foreach ($table['objects'] as $o) {
        $byName[(string) $o['name']] = $o;
    }
    $parsed = rv_parse_building($obj);
    $bind = (array) ($table['bind'][(string) ($meta['obj_key'] ?? '')] ?? []);
    $found = null;
    if (!empty($bind['object']) && isset($byName[(string) $bind['object']])) {
        $found = $byName[(string) $bind['object']];
        $out['bound'] = true;
        if (!empty($bind['building'])) {
            foreach ((array) $found['buildings'] as $b) {
                if ((string) ($b['name'] ?? '') === (string) $bind['building']) {
                    $out['building_row'] = $b;
                }
            }
        }
    } else {
        // по названию: сначала действующие объекты, архивные - только если среди действующих ничего не нашлось
        foreach ([rv_table_objects($table), rv_table_archived($table)] as $objects) {
            $best = 0;
            foreach ([$obj, (string) ($meta['folder'] ?? ''), (string) ($meta['smeta'] ?? '')] as $text) {
                $n = rv_norm($text);
                if ($n === '') {
                    continue;
                }
                foreach ($objects as $o) {
                    foreach (array_merge([(string) $o['name']], (array) ($o['aliases'] ?? [])) as $alias) {
                        $a = rv_norm($alias);
                        if ($a !== '' && mb_strlen($a) > $best && (strpos($n . ' ', $a . ' ') === 0)) {
                            $best = mb_strlen($a);
                            $found = $o;
                        }
                    }
                }
            }
            if ($found !== null) {
                break;
            }
        }
    }
    if ($found !== null) {
        $out['object'] = (string) $found['name'];
        $out['object_key'] = rv_table_key($out['object']);
        $out['archived'] = isset($archived[$out['object']]);
        if ($out['building_row'] === null) {
            $out['building_row'] = rv_table_building($found, $parsed);
        }
        $out['building'] = (string) (($out['building_row'] ?? [])['name'] ?? '');
    }
    $out['building_label'] = $out['building'] !== '' ? $out['building']
        : ($parsed['label'] !== '' ? $parsed['label'] : ($found !== null && count((array) $found['buildings']) === 1 ? '' : ''));
    $memo[$key] = $out;
    return $out;
}

/** Строка таблицы (корпус) объекта по разобранному имени НГ; null — не нашлась. */
function rv_table_building(array $object, array $parsed): ?array
{
    $buildings = (array) ($object['buildings'] ?? []);
    if (!$buildings) {
        return null;
    }
    $score = static function (array $b) use ($parsed): int {
        $p = rv_parse_building((string) ($b['name'] ?? ''));
        $s = 0;
        if ($parsed['num'] !== '' && $p['num'] === $parsed['num']) {
            $s += 4;
        } elseif ($parsed['num'] !== '' && $p['num'] !== '' && $p['num'] !== $parsed['num']) {
            return -1;
        }
        if ($parsed['stroenie'] !== '' && $p['stroenie'] === $parsed['stroenie']) {
            $s += 4;
        } elseif ($parsed['stroenie'] !== '' && $p['stroenie'] !== '' && $p['stroenie'] !== $parsed['stroenie']) {
            return -1;
        }
        if ($parsed['blok'] !== '' && $p['blok'] === $parsed['blok']) {
            $s += 3;
        }
        if ($parsed['section'] !== '' && $p['section'] === $parsed['section']) {
            $s += 2;
        } elseif ($parsed['section'] !== '' && $p['section'] !== '' && $p['section'] !== $parsed['section']) {
            return -1;
        } elseif ($parsed['section'] === '' && $p['section'] !== '') {
            $s -= 1;                        // у НГ секции нет, у строки есть - подходит хуже строки без секции
        }
        if ($parsed['parking'] !== $p['parking']) {
            return $parsed['parking'] ? -1 : ($s > 0 ? $s - 2 : -1);
        }
        if ($parsed['parking']) {
            $s += 2;
        }
        return $s;
    };
    $bestRow = null;
    $best = 0;
    foreach ($buildings as $b) {
        $sc = $score($b);
        if ($sc > $best) {
            $best = $sc;
            $bestRow = $b;
        }
    }
    if ($bestRow === null && count($buildings) === 1) {
        return $buildings[0];               // объект без деления на корпуса — «(основной)»
    }
    return $bestRow;
}

/**
 * Ответственный по справочнику: назначение по объекту целиком (система, вид работ «осн»/«НЗ» — правится на вкладке
 * «Ответственные»), иначе ячейка корпуса из таблицы, иначе та же ячейка любого корпуса объекта, иначе запасной
 * по группе систем (ОВ/ВК, ЭОМ/СС). Логин таблицы (login) — логин Трекера, user — логин на сайте (rv_table_user)
 * или ''. level: object / table / table-object / fallback.
 */
function rv_table_responsible(array $match, string $kind): array
{
    $none = ['user' => '', 'login' => '', 'level' => 'table', 'system' => (string) ($match['system'] ?? ''), 'kind' => $kind];
    $system = (string) ($match['system'] ?? '');
    if ($system === '' || ($match['object'] ?? '') === '' || !empty($match['archived'])) {
        return $none;                       // объекта в справочнике нет (сначала привязать НГ) или он в архиве - никого
    }
    $kind = $kind === 'НЗ' ? 'НЗ' : 'осн';
    $cell = static fn(?array $row): string => (string) ((($row['resp'] ?? [])[$system] ?? [])[$kind] ?? '');
    $object = rv_table_object((string) $match['object']);
    $login = $cell($object);            // назначение по объекту (ЖК) целиком - главное
    $level = 'object';
    if ($login === '') {
        $login = $cell($match['building_row'] ?? null);
        $level = 'table';
    }
    if ($login === '' && $object !== null) {
        foreach ((array) $object['buildings'] as $b) {
            $login = $cell($b);
            if ($login !== '') {
                $level = 'table-object';
                break;
            }
        }
    }
    if ($login === '') {
        $group = in_array($system, ['ЭОМ', 'СС'], true) ? 'ЭОМСС' : (in_array($system, ['Отопление', 'Вентиляция', 'ВК'], true) ? 'ОВВК' : '');
        $login = $group !== '' ? (string) (rv_table()['fallback'][$group] ?? '') : '';
        $level = 'fallback';
    }
    if ($login === '') {
        return $none;
    }
    return ['user' => rv_table_user($login), 'login' => $login, 'level' => $level, 'system' => $system, 'kind' => $kind];
}

/** Логин на сайте по логину таблицы (Трекера): тот же логин или он же с суффиксом отдела («vasileva.a_CO»). */
function rv_table_user(string $login): string
{
    static $users = null;
    if ($users === null) {
        $users = [];
        foreach (load_users() as $u) {
            $users[] = (string) ($u['login'] ?? '');
        }
    }
    $login = trim($login);
    if ($login === '') {
        return '';
    }
    foreach ($users as $u) {
        if (strcasecmp($u, $login) === 0) {
            return $u;
        }
    }
    foreach ($users as $u) {
        // «vasileva.a» → «vasileva.a_CO»; фамилия без инициала («levchuk») → «levchuk.a_CO»
        if (stripos($u, $login) === 0 && in_array(substr($u, strlen($login), 1), ['_', '.'], true)) {
            return $u;
        }
    }
    return '';
}

/** Логины справочника, которых нет на сайте (для страницы ответственных). */
function rv_table_unknown_logins(): array
{
    $logins = [];
    $table = rv_table();
    foreach (rv_table_objects($table) as $o) {
        foreach (array_merge([$o], (array) $o['buildings']) as $b) {
            foreach ((array) ($b['resp'] ?? []) as $cell) {
                foreach ((array) $cell as $login) {
                    if ((string) $login !== '') {
                        $logins[(string) $login] = true;
                    }
                }
            }
        }
    }
    foreach ($table['fallback'] as $login) {
        if ((string) $login !== '') {
            $logins[(string) $login] = true;
        }
    }
    $unknown = [];
    foreach (array_keys($logins) as $login) {
        if (rv_table_user((string) $login) === '') {
            $unknown[] = (string) $login;
        }
    }
    sort($unknown, SORT_NATURAL | SORT_FLAG_CASE);
    return $unknown;
}

/** Назначать сметчиков может руководитель: администраторы и те, кто ведёт агента РВ (KB_PLAN_VIEWERS). */
function rv_can_assign(): bool
{
    $role = (string) ($_SESSION['kb_role'] ?? '');
    return in_array($role, ['admin', 'mainadmin'], true) || kb_can_see_plans((string) ($_SESSION['kb_user'] ?? ''));
}

/** Сметчики, которых можно назначить: сотрудники ЦО и руководители агента РВ. [логин => подпись] */
function rv_estimators(): array
{
    $out = [];
    foreach (load_users() as $user) {
        $login = (string) ($user['login'] ?? '');
        if ($login !== '' && (user_department($user) === 'CO' || kb_can_see_plans($login))) {
            $out[$login] = $login;
        }
    }
    ksort($out, SORT_NATURAL | SORT_FLAG_CASE);
    return $out;
}

/** Может ли текущий пользователь взять ЛРВ в работу сам: сотрудник ЦО или руководитель. */
function rv_can_take(): bool
{
    return current_department() === 'CO' || rv_can_assign();
}

/**
 * Документ 1С, в который загружена РВ («Сопоставление РВ и ЛРВ»): ['title' => 'Сопоставление РВ и ЛРВ № 000000012 от 09.11.2026',
 * 'short' => '№ 000000012 от 09.11.2026', 'posted' => bool|null]. 1С присылает «Документ» (представление) и, в новых
 * версиях модуля, «Номер», «Дата», «Проведен». Без загрузки — null.
 */
function rv_onec_document(array $job): ?array
{
    $onec = is_array($job['onec'] ?? null) ? $job['onec'] : null;
    if ($onec === null || empty($onec['ok'])) {
        return null;
    }
    $title = trim((string) ($onec['document'] ?? ''));
    $number = trim((string) ($onec['number'] ?? ''));     // как в 1С, с ведущими нулями — по нему ищут документ
    $date = trim((string) ($onec['date'] ?? ''));
    if ($number === '' && preg_match('/\b(\d{6,})\b/u', $title, $m)) {
        $number = $m[1];
    }
    if ($date === '' && preg_match('/\b(\d{2}\.\d{2}\.\d{4})\b/u', $title, $m)) {
        $date = $m[1];
    }
    $short = $number !== '' ? '№ ' . $number . ($date !== '' ? ' от ' . $date : '') : ($title !== '' ? $title : 'документ 1С');
    if ($title === '') {
        $title = 'Сопоставление РВ и ЛРВ ' . $short;
    }
    return ['title' => $title, 'short' => $short, 'posted' => array_key_exists('posted', $onec) ? (bool) $onec['posted'] : null,
            'message' => (string) ($onec['message'] ?? ''), 'at' => (int) ($onec['at'] ?? 0)];
}

/** РВ уже загружена в 1С («Загрузить подбор с сайта» прошла): 1С отметила задачу — откат согласования закрыт. */
function rv_onec_loaded(array $job): bool
{
    $onec = is_array($job['onec'] ?? null) ? $job['onec'] : null;
    return $onec !== null && !empty($onec['ok']);
}

/**
 * Состояние ЛРВ в реестре по всему пути: пришла из 1С → строится → готова → согласована → загружена в 1С.
 * Возвращает [код, подпись, вид для значка].
 */
function rv_registry_state(array $job, string $state, ?array $status): array
{
    if ($state === 'done') {
        if (rv_approval($job, $status) === null) {
            return ['ready', 'Готова, не согласована', 'wait'];
        }
        $onec = is_array($job['onec'] ?? null) ? $job['onec'] : null;
        if ($onec !== null && !empty($onec['ok'])) {
            $doc = rv_onec_document($job);
            return ['loaded', 'Загружена в 1С' . ($doc ? ': ' . $doc['short'] : ''), 'done'];
        }
        if ($onec !== null) {
            return ['load_error', 'Ошибка загрузки в 1С', 'error'];
        }
        return ['approved', 'Согласована', 'done'];
    }
    if ($state === 'queued') {
        return ['queued', 'В очереди', 'wait'];
    }
    if ($state === 'running') {
        return ['running', 'Строится', 'run'];
    }
    if ($state === 'awaiting_confirm') {
        return ['awaiting', 'Ждёт выбора (система, ДР / РВР)', 'wait'];
    }
    return ['error', 'Ошибка построения', 'error'];
}

const RV_REGISTRY_STATES = [
    'queued' => 'В очереди', 'running' => 'Строится', 'awaiting' => 'Ждёт выбора (система, ДР / РВР)',
    'ready' => 'Готова, не согласована', 'approved' => 'Согласована', 'loaded' => 'Загружена в 1С',
    'load_error' => 'Ошибка загрузки в 1С', 'error' => 'Ошибка построения', 'gone' => 'РВ удалена на сайте',
];

/**
 * Задачи из 1С: [ИдентификаторЛРВ => [версии, новые первыми]] — у каждой задачи 'token'.
 * $lrvId — только эта ЛРВ (карточка сметы).
 */
function rv_onec_jobs(?string $lrvId = null): array
{
    $byId = [];
    foreach (glob(RV_OUTPUT_DIR . '/*_job.json') ?: [] as $path) {
        $token = basename($path, '_job.json');
        if (!rv_token_valid($token)) {
            continue;
        }
        $job = rv_read_json($path);
        if ($job === null || ($job['origin'] ?? '') !== '1c' || ($job['mode'] ?? '') === 'audit') {
            continue;                   // сверка РВ из 1С — не рабочая ЛРВ: ни в дереве объектов, ни в карточке
        }
        $id = (string) ($job['lrv_id'] ?? $token);
        if ($lrvId !== null && $id !== $lrvId) {
            continue;
        }
        $job['token'] = $token;
        $byId[$id][] = $job;
    }
    foreach ($byId as &$versions) {
        usort($versions, static fn(array $a, array $b): int => (int) ($b['created'] ?? 0) <=> (int) ($a['created'] ?? 0));
    }
    unset($versions);
    return $byId;
}

/**
 * Строки реестра — по смете: последняя версия ЛРВ (ИдентификаторЛРВ = смета) с объектом, номенклатурной группой,
 * системой, номером ЗН, ответственным, состоянием и итогами РВ; старые версии — только их число.
 * Сметы из справочника, у которых РВ на сайте уже удалены, тоже в дереве — с состоянием «РВ удалена».
 * Задачи, которых в справочнике ещё нет (пришли до него), дописываются в справочник здесь же.
 */
function rv_registry_rows(): array
{
    $byId = rv_onec_jobs();
    $objects = rv_objects();
    $missing = [];
    foreach ($byId as $id => $versions) {
        if (!isset($objects['smetas'][$id])) {
            $missing[] = $versions[0];
        }
    }
    if ($missing && rv_objects_register($missing, true)) {
        $objects = rv_objects();
    }
    $assign = rv_assignments();
    $rows = [];
    foreach ($byId as $id => $versions) {
        $job = $versions[0];
        [$state, $status] = rv_state($job['token'], $job);
        [$code, $label, $kind] = rv_registry_state($job, $state, $status);
        $meta = rv_table_meta(rv_registry_meta($job, $objects));
        $meta['id'] = (string) $id;
        $summary = is_array($status['summary'] ?? null) ? $status['summary'] : [];
        $onec = is_array($job['onec'] ?? null) ? $job['onec'] : null;
        $rows[] = $meta + [
            'id' => (string) $id, 'token' => $job['token'], 'versions' => count($versions),
            'code' => $code, 'label' => $label, 'kind' => $kind,
            'responsible' => rv_responsible($assign, $meta),
            'approval' => rv_approval($job, $status),
            'onec' => $onec,
            'error' => in_array($code, ['error', 'load_error'], true)
                ? (string) ($code === 'load_error' ? ($onec['message'] ?? '') : ($status['error'] ?? '')) : '',
            'rows' => (int) ($summary['rows'] ?? 0), 'works' => (int) ($summary['works'] ?? 0),
            'review' => (int) ($summary['review'] ?? 0), 'unbound' => (int) ($summary['unbound'] ?? 0),
            'zn_list' => array_map('strval', array_keys((array) ($summary['zn'] ?? []))),
            'received' => (int) ($job['created'] ?? 0), 'resent' => rv_resent_text($job),
            'updated' => max((int) ($job['created'] ?? 0), (int) ($status['updated'] ?? 0), (int) ($onec['at'] ?? 0),
                             (int) ($job['resent']['at'] ?? 0)),
        ];
    }
    foreach ($objects['smetas'] as $id => $known) {
        if (isset($byId[$id]) || !is_array($known)) {
            continue;
        }
        $group = (array) ($objects['groups'][(string) ($known['group'] ?? '')] ?? []);
        $folderKey = (string) ($group['folder'] ?? '');
        $meta = [
            'folder' => $folderKey !== '' ? (string) ($objects['folders'][$folderKey]['name'] ?? '') : '', 'folder_key' => $folderKey,
            'folder_id' => '', 'folder_known' => true,
            'obj' => (string) ($group['name'] ?? 'Без номенклатурной группы'), 'obj_key' => (string) ($known['group'] ?? ''), 'obj_id' => '',
            'system' => (string) ($known['system'] ?? ''), 'system_key' => rv_registry_key((string) ($known['system_id'] ?? ''), (string) ($known['system'] ?? '')),
            'system_id' => '', 'smeta' => (string) ($known['smeta'] ?? ''), 'smeta_id' => (string) ($known['smeta_id'] ?? ''),
            'zn' => (string) ($known['zn'] ?? ''), 'zn_known' => true,
        ];
        $meta['work_kind'] = rv_kind_of($meta['smeta'], $meta['zn']);
        $meta = rv_table_meta($meta);
        $rows[] = $meta + [
            'id' => (string) $id, 'token' => '', 'versions' => 0, 'code' => 'gone', 'label' => RV_REGISTRY_STATES['gone'], 'kind' => 'wait',
            'responsible' => rv_responsible($assign, $meta), 'approval' => null, 'onec' => null, 'error' => '',
            'rows' => 0, 'works' => 0, 'review' => 0, 'unbound' => 0, 'zn_list' => [],
            'received' => (int) ($known['updated'] ?? 0), 'updated' => (int) ($known['updated'] ?? 0),
        ];
    }
    usort($rows, static fn(array $a, array $b): int
        => [$a['folder'] === '', mb_strtolower($a['folder']), mb_strtolower($a['building_label']), mb_strtolower($a['obj']), mb_strtolower($a['system']), mb_strtolower($a['smeta'])]
           <=> [$b['folder'] === '', mb_strtolower($b['folder']), mb_strtolower($b['building_label']), mb_strtolower($b['obj']), mb_strtolower($b['system']), mb_strtolower($b['smeta'])]);
    return $rows;
}

/**
 * Очередь сметчика «Мои РВ на проверку»: готовые, ещё не согласованные РВ из 1С, за которые он отвечает
 * (rv_responsible), новые первыми. $rows — строки реестра, если уже посчитаны.
 */
function rv_my_queue(string $user, ?array $rows = null): array
{
    if ($user === '') {
        return [];
    }
    $out = [];
    foreach ($rows ?? rv_registry_rows() as $row) {
        if ($row['code'] === 'ready' && (string) ($row['responsible']['user'] ?? '') === $user) {
            $out[] = $row;
        }
    }
    usort($out, static fn(array $a, array $b): int => $b['updated'] <=> $a['updated']);
    return $out;
}

/** Число РВ в очереди сметчика для значка в меню; считается не чаще раза в RV_QUEUE_BADGE_SEC (файл в data). */
function rv_my_queue_count(string $user): int
{
    if ($user === '' || !defined('RV_OUTPUT_DIR') || !is_dir(RV_OUTPUT_DIR)) {
        return 0;
    }
    $file = RV_OUTPUT_DIR . '/queue_' . substr(sha1($user), 0, 12) . '.json';
    $cached = is_file($file) ? rv_read_json($file) : null;
    if (is_array($cached) && (int) ($cached['at'] ?? 0) > time() - 120) {
        return (int) ($cached['n'] ?? 0);
    }
    $n = rv_is_manager($user) ? count(rv_ready_rows(rv_tree_rows($user, true, false))) : count(rv_my_queue($user));
    @file_put_contents($file, json_encode(['at' => time(), 'n' => $n]));
    return $n;
}

/**
 * Дополнить meta задачи объектом и корпусом справочника (rv_table_match): folder/folder_key — объект справочника
 * (назначение «за объект» — по нему), building_label — корпус как показывать, table_system — система таблицы.
 * Не сопоставилось — folder пустой, папка НГ из 1С остаётся в folder_1c.
 */
function rv_table_meta(array $meta): array
{
    $match = rv_table_match($meta);
    $meta['match'] = $match;
    $meta['folder_1c'] = $meta['folder'];
    $meta['building_label'] = $match['building_label'];
    $meta['table_system'] = $match['system'];
    if ($match['object'] !== '') {
        $meta['folder'] = $match['object'];
        $meta['folder_key'] = $match['object_key'];
    } else {
        $meta['folder'] = '';
        $meta['folder_key'] = '';
    }
    return $meta;
}

/**
 * Заголовок РВ сметы на странице проверки: смета, как её называют в 1С, без объекта и корпуса —
 * «Электромонтажные работы / Электромонтажные работы в нежилой части» (хвост имени НГ после объекта и корпуса,
 * затем «Аналитика 1»); вид работ («Основные работы», «Работы по З/Н …») страница добавляет сама по блоку.
 * Пусто — нет ни НГ, ни системы.
 */
function rv_smeta_title(array $meta): string
{
    $ng = trim((string) ($meta['obj'] ?? ''));
    $system = trim((string) ($meta['system'] ?? ''));
    $tail = $ng !== '' ? rv_ng_tail($ng, (string) (($meta['match'] ?? [])['object'] ?? '')) : '';
    if ($tail !== '' && $system !== '' && rv_norm($tail) === rv_norm($system)) {
        $tail = '';
    }
    return implode(' / ', array_values(array_filter([$tail, $system], static fn(string $t): bool => $t !== '')));
}

/**
 * Хвост имени номенклатурной группы после объекта и корпуса: «ЖК Большая Академическая к.3.6 Электромонтажные
 * работы» → «Электромонтажные работы». Объект — имя или псевдоним объекта таблицы, с которого начинается НГ
 * (самый длинный), корпус — слова вида «к.3.6», «корпус 3», «секция 2», «стр. 1», «блок 1», «паркинг».
 * Если имя объекта не узнано, НГ возвращается как есть.
 */
function rv_ng_tail(string $ng, string $objectName): string
{
    $words = preg_split('/\s+/u', trim($ng)) ?: [];
    $skip = 0;
    $names = [];
    if ($objectName !== '') {
        $object = rv_table_object($objectName);
        $names = array_merge([$objectName], (array) (($object ?? [])['aliases'] ?? []));
    }
    foreach ($names as $alias) {
        $aliasWords = preg_split('/\s+/u', trim((string) $alias)) ?: [];
        $n = count($aliasWords);
        if ($n === 0 || $n > count($words)) {
            continue;
        }
        $head = implode(' ', array_slice($words, 0, $n));
        if (rv_norm($head) === rv_norm((string) $alias) && $n > $skip) {
            $skip = $n;
        }
        if (preg_match('/^жк\s/iu', $head) && $n + 1 <= count($words)
            && rv_norm(implode(' ', array_slice($words, 0, $n + 1))) === rv_norm((string) $alias) && $n + 1 > $skip) {
            $skip = $n + 1;          // «ЖК» в НГ, а в таблице без него — rv_norm его срезает
        }
    }
    if ($skip === 0) {
        return $ng;
    }
    $n = count($words);
    while ($skip < $n) {
        $w = mb_strtolower($words[$skip]);
        $marker = (bool) preg_match('/^(к|корп|корпус|секц|секция|стр|строение|блок)\.?(\d+(\.\d+)*(-\d+(\.\d+)*)?)?\.?$/u', $w);
        $number = (bool) preg_match('/^\d+(\.\d+)*(-\d+(\.\d+)*)?\.?$/u', $w) && $skip > 0
            && preg_match('/^(к|корп|корпус|секц|секция|стр|строение|блок)\.?$/u', mb_strtolower($words[$skip - 1]));
        if (!$marker && !$number && !preg_match('/^(паркинг|парковка)$/u', $w)) {
            break;
        }
        $skip++;
    }
    return trim(implode(' ', array_slice($words, $skip)));
}

/**
 * Наряд-заказ строки ЛРВ из 1С: «НомерЗН», а если он пуст — Аналитика 4 вида «Работы по З/Н №ЭОМ-1»
 * (номер после «№», без него — имя аналитики). Пусто — основные работы. То же — zn_of в web_rv_run.py.
 */
function rv_zn_of(array $row): string
{
    $number = trim((string) ($row['НомерЗН'] ?? ''));
    if ($number !== '') {
        return $number;
    }
    $analytic = trim((string) (($row['Аналитика'] ?? '') !== '' ? $row['Аналитика'] : ($row['Аналитика_4_Имя'] ?? '')));
    if (!preg_match('~з\s*/\s*н|заказ[\s-]*наряд|наряд[\s-]*заказ~iu', $analytic)) {
        return '';
    }
    return preg_match('~№\s*(\S.*)$~u', $analytic, $m) ? trim($m[1]) : $analytic;
}

/**
 * Повторная отправка той же ЛРВ из 1С без изменений (1c_rv.php, ответ duplicate): новой РВ не строится,
 * повтор отмечается у прежней задачи. Текст для страниц: «повторно из 1С 2 раза, последний — сегодня, 10:15:
 * без изменений» или ''.
 */
function rv_resent_text(array $job): string
{
    $resent = is_array($job['resent'] ?? null) ? $job['resent'] : null;
    if (!$resent || empty($resent['at'])) {
        return '';
    }
    $count = (int) ($resent['count'] ?? 1);
    return 'повторно из 1С' . ($count > 1 ? ' ' . $count . ' раз' . (in_array($count % 10, [2, 3, 4], true) && !in_array($count % 100, [12, 13, 14], true) ? 'а' : '') . ', последний —' : '')
        . ' ' . rv_when((int) $resent['at']) . ': без изменений';
}

/** Номера ЗН строкой: «№ 12, № 15». */
function rv_zn_text(array $numbers): string
{
    $numbers = array_values(array_unique(array_filter(array_map(static fn($n): string => trim((string) $n), $numbers), static fn(string $n): bool => $n !== '')));
    return implode(', ', array_map(static fn(string $n): string => '№ ' . $n, $numbers));
}

// ── Дерево объектов на странице «РВ по ЛРВ»: кто что видит, счётчики, ответственные по объекту ──

/**
 * Руководитель видит все РВ и общий счётчик непроверенных: администраторы, те, кто ведёт агента (KB_PLAN_VIEWERS),
 * и логины из списка «Руководители» на вкладке «Ответственные» (поле managers справочника) или RV_MANAGERS в config.
 */
function rv_is_manager(?string $user = null): bool
{
    $me = (string) ($_SESSION['kb_user'] ?? '');
    $user = $user ?? $me;
    if ($user === '') {
        return false;
    }
    if ($user === $me && in_array((string) ($_SESSION['kb_role'] ?? ''), ['admin', 'mainadmin'], true)) {
        return true;
    }
    if (kb_can_see_plans($user)) {
        return true;
    }
    $list = array_merge(defined('RV_MANAGERS') ? (array) RV_MANAGERS : [], rv_table()['managers']);
    foreach ($list as $login) {
        $login = (string) $login;
        if ($login !== '' && (strcasecmp($login, $user) === 0 || strcasecmp(rv_table_user($login), $user) === 0)) {
            return true;
        }
    }
    return false;
}

/**
 * Строки реестра для дерева: руководителю ($all) — все, сметчику — только те, за которые отвечает он
 * (своих объектов). Без $archive — без смет архивных объектов.
 */
function rv_tree_rows(string $user, bool $all, bool $archive, ?array $rows = null): array
{
    $out = [];
    foreach ($rows ?? rv_registry_rows() as $row) {
        if (!$archive && !empty($row['match']['archived'])) {
            continue;
        }
        if (!$all && (string) ($row['responsible']['user'] ?? '') !== $user) {
            continue;
        }
        $out[] = $row;
    }
    return $out;
}

/** Непроверенные РВ: готовы, но не согласованы (их считают красные кружки). */
function rv_ready_rows(array $rows): array
{
    return array_values(array_filter($rows, static fn(array $r): bool => $r['code'] === 'ready'));
}

/**
 * Дерево объект → корпус → система → вид работ (основной договор / наряд-заказ) со счётчиками непроверенных РВ.
 * [objects: {folder_key: {name, key, archived, count, total, buildings: {корпус ('' — без корпуса): {count, total,
 *  systems: {система: {count, total, kinds: {осн: {count, total}, НЗ: …}}}}}}}, unmatched: {count, total}]
 * — total: всего смет узла, count: непроверенных.
 */
function rv_tree(array $rows): array
{
    $tree = ['objects' => [], 'unmatched' => ['count' => 0, 'total' => 0]];
    $order = array_flip(rv_table()['systems']);
    foreach ($rows as $row) {
        $ready = $row['code'] === 'ready' ? 1 : 0;
        $fk = (string) $row['folder_key'];
        if ($fk === '') {
            $tree['unmatched']['count'] += $ready;
            $tree['unmatched']['total']++;
            continue;
        }
        $building = (string) $row['building_label'];
        $system = rv_row_system($row);
        $kind = $row['work_kind'] === 'НЗ' ? 'НЗ' : 'осн';
        $o = &$tree['objects'][$fk];
        $o = $o ?? ['name' => $row['folder'], 'key' => $fk, 'archived' => !empty($row['match']['archived']), 'count' => 0, 'total' => 0, 'buildings' => []];
        $o['count'] += $ready;
        $o['total']++;
        $b = &$o['buildings'][$building];
        $b = $b ?? ['count' => 0, 'total' => 0, 'systems' => []];
        $b['count'] += $ready;
        $b['total']++;
        $s = &$b['systems'][$system];
        $s = $s ?? ['count' => 0, 'total' => 0, 'kinds' => []];
        $s['count'] += $ready;
        $s['total']++;
        $k = &$s['kinds'][$kind];
        $k = $k ?? ['count' => 0, 'total' => 0];
        $k['count'] += $ready;
        $k['total']++;
        unset($o, $b, $s, $k);
    }
    $bySystem = static fn(string $a, string $b): int => [($order[$a] ?? 99), mb_strtolower($a)] <=> [($order[$b] ?? 99), mb_strtolower($b)];
    foreach ($tree['objects'] as &$o) {
        uksort($o['buildings'], static fn(string $a, string $b): int => [$a === '', strnatcasecmp($a, $b)] <=> [$b === '', 0]);
        foreach ($o['buildings'] as &$b) {
            uksort($b['systems'], $bySystem);
            foreach ($b['systems'] as &$s) {
                uksort($s['kinds'], static fn(string $a, string $b): int => ($a === 'осн' ? 0 : 1) <=> ($b === 'осн' ? 0 : 1));
            }
            unset($s);
        }
        unset($b);
    }
    unset($o);
    uasort($tree['objects'], static fn(array $a, array $b): int => [$a['archived'], mb_strtolower($a['name'])] <=> [$b['archived'], mb_strtolower($b['name'])]);
    return $tree;
}

/** Система строки для дерева: по таблице, иначе из 1С, иначе «Система не указана». */
function rv_row_system(array $row): string
{
    return $row['table_system'] !== '' ? $row['table_system'] : ($row['system'] !== '' ? $row['system'] : 'Система не указана');
}

/**
 * Строки узла дерева: объект ($folderKey), корпус ($building: null — любой, '' — без корпуса), система ($system,
 * '' — любая), вид работ ($kind, '' — любой); $folderKey = 'unmatched' — не сопоставленные с объектами.
 */
function rv_node_rows(array $rows, string $folderKey, ?string $building = null, string $system = '', string $kind = ''): array
{
    return array_values(array_filter($rows, static function (array $row) use ($folderKey, $building, $system, $kind): bool {
        if ($folderKey === 'unmatched') {
            return (string) $row['folder_key'] === '';
        }
        if ((string) $row['folder_key'] !== $folderKey) {
            return false;
        }
        if ($building !== null && (string) $row['building_label'] !== $building) {
            return false;
        }
        if ($system !== '' && rv_row_system($row) !== $system) {
            return false;
        }
        return $kind === '' || ($row['work_kind'] === 'НЗ' ? 'НЗ' : 'осн') === $kind;
    }));
}

/**
 * Список РВ узла тремя группами: ready — на проверку по времени получения (старые первыми), work — строится
 * или ждёт выбора системы, done — проверенные и остальные, новые первыми.
 */
function rv_node_groups(array $rows): array
{
    $groups = ['ready' => [], 'work' => [], 'done' => []];
    foreach ($rows as $row) {
        if ($row['code'] === 'ready') {
            $groups['ready'][] = $row;
        } elseif (in_array($row['code'], ['queued', 'running', 'awaiting'], true)) {
            $groups['work'][] = $row;
        } else {
            $groups['done'][] = $row;
        }
    }
    usort($groups['ready'], static fn(array $a, array $b): int => $a['received'] <=> $b['received']);
    usort($groups['work'], static fn(array $a, array $b): int => $a['received'] <=> $b['received']);
    usort($groups['done'], static fn(array $a, array $b): int => $b['updated'] <=> $a['updated']);
    return $groups;
}

/**
 * Ответственные объекта по системам и видам работ: назначенный по объекту целиком (source = object), иначе
 * из корпусов таблицы — один на все корпуса (buildings) или разные (mixed, берётся первый непустой).
 * [система => [осн|НЗ => [login, source]]].
 */
function rv_object_resp(array $object, ?array $systems = null): array
{
    $out = [];
    foreach ($systems ?? rv_table()['systems'] as $system) {
        foreach (['осн', 'НЗ'] as $kind) {
            $login = (string) ((($object['resp'] ?? [])[$system] ?? [])[$kind] ?? '');
            if ($login !== '') {
                $out[$system][$kind] = ['login' => $login, 'source' => 'object'];
                continue;
            }
            $seen = [];
            foreach ((array) ($object['buildings'] ?? []) as $b) {
                $l = (string) ((($b['resp'] ?? [])[$system] ?? [])[$kind] ?? '');
                if ($l !== '') {
                    $seen[$l] = true;
                }
            }
            $out[$system][$kind] = ['login' => $seen ? (string) array_key_first($seen) : '', 'source' => count($seen) > 1 ? 'mixed' : ($seen ? 'buildings' : '')];
        }
    }
    return $out;
}

/** Подпись человека: логин сайта как есть («vasileva.a_CO» → «vasileva.a»); пусто — «—». */
function rv_person_label(string $login): string
{
    $login = trim($login);
    if ($login === '') {
        return '—';
    }
    return preg_replace('/_[A-Za-z]{1,4}$/', '', $login) ?? $login;
}

/** Инициалы для аватара по логину вида «фамилия.и» или «фамилия»: «ВА», «Л». */
function rv_person_initials(string $login): string
{
    $login = rv_person_label($login);
    if ($login === '—') {
        return '—';
    }
    $parts = preg_split('/[._-]+/', $login) ?: [];
    $out = '';
    foreach (array_slice($parts, 0, 2) as $part) {
        if ($part !== '') {
            $out .= mb_strtoupper(mb_substr($part, 0, 1));
        }
    }
    return $out !== '' ? $out : '?';
}
