<?php
declare(strict_types=1);

require __DIR__ . '/clean_papper_guard.php';
require_once __DIR__ . '/clean_papper_api_lib.php';
require_once __DIR__ . '/clean_papper_pdf_lib.php';
require_once __DIR__ . '/clean_papper_upload_lib.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: private, no-store, max-age=0');
header('X-Content-Type-Options: nosniff');

function cp_pdf_json(array $result, int $code = 200): void
{
    http_response_code($code);
    echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}
// Read-only status for this session's current synchronous worker; no arbitrary paths.
if (($_SERVER['REQUEST_METHOD'] ?? '') === 'GET') {
    $token = (string) ($_GET['status'] ?? '');
    $owned = (string) ($_SESSION['cp_pdf_status_token'] ?? '');
    if (!preg_match('/^[a-f0-9]{32}$/D', $token) || !$owned || !hash_equals($owned, $token)) {
        cp_pdf_json(['ok'=>false,'message'=>'Состояние недоступно.'],404);
    }
    session_write_close();
    $statusPath = cp_pdf_upload_path($token) . '.status.json';
    $progress = json_decode((string) @file_get_contents($statusPath), true);
    if (!is_array($progress)) cp_pdf_json(['ok'=>false,'message'=>'Ожидается ответ обработчика.'],404);
    cp_pdf_json(['ok'=>true,'updated'=>$progress['updated'] ?? 0, 'phase'=>$progress['phase'] ?? 'running','server_time'=>time()]);
}
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    cp_pdf_json(['ok'=>false,'message'=>'Разрешён только POST.'],405);
}
// A too-large POST leaves $_POST/$_FILES empty and otherwise looks like a CSRF failure.
function cp_pdf_php_bytes(string $value): int
{
    $value = trim($value);
    if (!preg_match('/^([0-9]+)([KMG]?)$/i', $value, $m)) {
        return 0;
    }
    $power = ['' => 0, 'K' => 1, 'M' => 2, 'G' => 3][strtoupper($m[2])];
    return (int) ((int) $m[1] * pow(1024, $power));
}
$postMax = cp_pdf_php_bytes((string) ini_get('post_max_size'));
$inputLength = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);
if ($postMax > 0 && $inputLength > $postMax) {
    cp_pdf_json(['ok'=>false,'code'=>'post_size_limit',
        'message'=>'PDF превышает post_max_size PHP ('.ini_get('post_max_size').'). Нужен файл меньшего размера или настройка сервера.'], 413);
}
if (!isset($_SESSION['clean_papper_csrf']) ||
    !hash_equals((string) $_SESSION['clean_papper_csrf'], (string) ($_POST['csrf'] ?? ''))) {
    cp_pdf_json(['ok'=>false,'message'=>'Обновите страницу: сессия устарела.'],403);
}
$mode = (string) ($_POST['mode'] ?? '');
if (!in_array($mode,['diagnostic','preview','vision','album','specification'],true)) {
    cp_pdf_json(['ok'=>false,'message'=>'Недопустимый тип обработки.'],400);
}
if ($mode === 'diagnostic') {
    session_write_close();
    $result = cp_pdf_worker('', 1, 'diagnostic', null);
    cp_pdf_json($result, !empty($result['ok']) ? 200 : 503);
}
// Chunked PDF: token is bound to this exact authenticated PHP session.
// Do not use a filename or path supplied by the browser.
$assembledPath = null;
$heartbeat = null;
$uploadId = (string) ($_POST['upload_id'] ?? '');
if ($uploadId !== '') {
    try {
        $assembledPath = cp_pdf_upload_complete_path(
            $_SESSION['clean_papper_upload'] ?? [], $uploadId
        );
        unset($_SESSION['clean_papper_upload']);
        $_SESSION['cp_pdf_status_token'] = $uploadId;
        $statusPath = $assembledPath . '.status.json';
        $heartbeat = static function (string $phase = 'running') use ($statusPath): void {
            $tmp = $statusPath . '.tmp';
            if (@file_put_contents($tmp, json_encode(['phase'=>$phase,'updated'=>time()])) !== false) {
                @rename($tmp, $statusPath);
            }
        };
        $heartbeat('starting');
        register_shutdown_function(static function () use ($assembledPath, $statusPath): void {
            @unlink($assembledPath);
            @unlink($statusPath);
            @unlink($statusPath . '.tmp');
        });
    } catch (InvalidArgumentException $e) {
        cp_pdf_json(['ok'=>false,'message'=>$e->getMessage()],400);
    } catch (Throwable $e) {
        cp_pdf_json(['ok'=>false,'message'=>'Не удалось открыть собранный PDF. Загрузите его повторно.'],503);
    }
}
if ($assembledPath === null) {
$file = $_FILES['pdf'] ?? null;
$errorCode = is_array($file) ? (int) ($file['error'] ?? UPLOAD_ERR_NO_FILE) : UPLOAD_ERR_NO_FILE;
if ($errorCode === UPLOAD_ERR_INI_SIZE || $errorCode === UPLOAD_ERR_FORM_SIZE) {
    cp_pdf_json(['ok'=>false,'code'=>'upload_size_limit',
        'message'=>'PDF превышает upload_max_filesize PHP ('.ini_get('upload_max_filesize').'). Выберите меньший файл.'], 413);
}
if ($errorCode === UPLOAD_ERR_PARTIAL) {
    cp_pdf_json(['ok'=>false,'code'=>'partial_upload',
        'message'=>'Файл загрузился не полностью. Проверьте соединение и повторите загрузку.'], 400);
}

if (!is_array($file) || (int) ($file['error'] ?? -1) !== UPLOAD_ERR_OK ||
    !is_string($file['tmp_name'] ?? null) || !is_uploaded_file($file['tmp_name'])) {
    cp_pdf_json(['ok'=>false,'code'=>'upload_missing',
        'message'=>'Сервер не получил PDF. Проверьте выбранный файл и ограничения PHP.'],400);
}
$maxBytes = 100 * 1024 * 1024;
$size = (int) ($file['size'] ?? 0);
if ($size < 10 || $size > $maxBytes) {
    cp_pdf_json(['ok'=>false,'message'=>'Допустим PDF размером до 100 МБ.'],413);
}
$filename = (string) ($file['name'] ?? '');
if (strtolower(pathinfo($filename, PATHINFO_EXTENSION)) !== 'pdf') {
    cp_pdf_json(['ok'=>false,'message'=>'Выберите файл с расширением .pdf'],400);
}
$fh = @fopen($file['tmp_name'], 'rb');
$signature = $fh ? (string) fread($fh, 5) : '';
if ($fh) fclose($fh);
if ($signature !== '%PDF-') {
    cp_pdf_json(['ok'=>false,'message'=>'Файл не распознан как PDF.'],400);
}
} // End legacy small-file upload fallback.
if ($mode === 'album') {
    $review = $_FILES['album_review'] ?? null;
    $reviewPath = null;
    if ($review !== null && (!is_array($review) || ($review['error'] ?? null) !== UPLOAD_ERR_NO_FILE)) {
        if (!is_array($review) || ($review['error'] ?? null) !== UPLOAD_ERR_OK ||
            !is_string($review['tmp_name'] ?? null) || !is_uploaded_file($review['tmp_name']) ||
            (int) ($review['size'] ?? 0) < 1 || (int) ($review['size'] ?? 0) > 96 * 1024) {
            cp_pdf_json(['ok' => false, 'message' => 'Выберите файл разметки JSON размером до 96 КиБ.'], 400);
        }
        $reviewPath = $review['tmp_name'];
    }
    session_write_close();
    if (function_exists('set_time_limit')) @set_time_limit(110);
    $result = cp_pdf_worker($assembledPath ?? $file['tmp_name'], 1, 'album', null, null, $reviewPath, null, $heartbeat);
    cp_pdf_json($result, !empty($result['ok']) ? 200 : 422);
}
if ($mode === 'specification') {
    $first = (string) ($_POST['spec_first'] ?? '');
    $last = (string) ($_POST['spec_last'] ?? '');
    $sha = (string) ($_POST['source_pdf_sha256'] ?? '');
    $action = (string) ($_POST['spec_action'] ?? '');
    if (!preg_match('/^[1-9][0-9]{0,2}$/D', $first) ||
        !preg_match('/^[1-9][0-9]{0,2}$/D', $last) ||
        (int) $first > (int) $last || (int) $last > 600 ||
        (int) $last - (int) $first + 1 > 120 ||
        !preg_match('/^[a-f0-9]{64}$/D', $sha) ||
        !in_array($action, ['extract', 'convert'], true)) {
        cp_pdf_json(['ok'=>false,'message'=>'Выберите диапазон до 120 страниц и заново обработайте исходный альбом.'],400);
    }
    session_write_close();
    if (function_exists('set_time_limit')) @set_time_limit(110);
    $result = cp_pdf_worker($assembledPath ?? $file['tmp_name'], 1, 'specification',
        null, null, null, ['first'=>$first, 'last'=>$last, 'sha'=>$sha, 'action'=>$action], $heartbeat);
    cp_pdf_json($result, !empty($result['ok']) ? 200 : 422);
}
$pageText = (string) ($_POST['page'] ?? '');
if (!preg_match('/^[1-9][0-9]{0,2}$/D', $pageText)) {
    cp_pdf_json(['ok'=>false,'message'=>'Укажите номер страницы от 1 до 600.'],400);
}
$page = (int) $pageText;
if ($page > 600) cp_pdf_json(['ok'=>false,'message'=>'Максимум 600 страниц.'],400);
$profile = (string) ($_POST['profile'] ?? '');
if (strlen($profile) > 2500) {
    cp_pdf_json(['ok'=>false,'message'=>'Слишком большой профиль проекта.'],400);
}
$crop = trim((string) ($_POST['crop'] ?? ''));
if ($crop !== '' && !preg_match('/^(?:0(?:\.\d+)?|1(?:\.0+)?)(?:,(?:0(?:\.\d+)?|1(?:\.0+)?)){3}$/D', $crop)) {
    cp_pdf_json(['ok'=>false,'message'=>'Некорректная область выбранного фрагмента.'],400);
}
if ($mode === 'vision') {
    if (($_POST['vision_consent'] ?? '') !== 'yes') {
        cp_pdf_json(['ok'=>false,'message'=>'Сначала подтвердите передачу фрагмента в Anthropic.'],400);
    }
    $now=time();
    if ($now-(int) ($_SESSION['clean_papper_last_vision'] ?? 0) < 90) {
        cp_pdf_json(['ok'=>false,'message'=>'Повторный вызов Claude доступен через 90 секунд.'],429);
    }
    $_SESSION['clean_papper_last_vision']=$now;
}
session_write_close();
// PHP's uploaded temporary file is removed automatically at end of request.
if (function_exists('set_time_limit')) @set_time_limit(110);
$result = cp_pdf_worker($assembledPath ?? $file['tmp_name'], $page, $mode, $crop ?: null, $profile, null, null, $heartbeat);
if ($assembledPath !== null) {
    @unlink($assembledPath);
}
cp_pdf_json($result, !empty($result['ok']) ? 200 : 422);
