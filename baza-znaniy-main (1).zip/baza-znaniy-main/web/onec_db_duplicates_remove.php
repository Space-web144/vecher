<?php
declare(strict_types=1);

// Удаление выбранных администратором дублей номенклатуры с web/
// onec_db_duplicates.php — отмеченные галочками позиции уходят ИЗ боевой
// базы сравнения (DB_FILE) и, в синхроне, из снимка для проверки дублей
// при приёме от 1С (ONEC_NOMENCLATURE_FILE). Сам список кодов здесь не
// проверяется на то, что это действительно дубль, — это делает скрипт
// (common/web_db_duplicates_remove_run.py), заново считая группы дублей
// по текущему DB_FILE перед удалением: страница могла быть открыта раньше,
// чем кто-то ещё изменил базу. Доступно только admin/mainadmin.

require __DIR__ . '/admin_guard.php';
require __DIR__ . '/config.php';

function back_with(array $params): never {
    header('Location: onec_db_duplicates.php?' . http_build_query($params));
    exit;
}

function back_with_error(string $message, int $page): never {
    back_with(['page' => $page, 'err' => $message]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: onec_db_duplicates.php');
    exit;
}

$page = max(1, (int) ($_POST['page'] ?? 1));

if (empty($_SESSION['csrf']) || !hash_equals((string) $_SESSION['csrf'], (string) ($_POST['csrf'] ?? ''))) {
    back_with_error('Сессия истекла, обновите страницу и попробуйте снова.', $page);
}

$rawCodes = $_POST['remove'] ?? [];
if (!is_array($rawCodes) || !$rawCodes) {
    back_with_error('Не выбрано ни одной позиции.', $page);
}

$codes = [];
foreach ($rawCodes as $raw) {
    if (is_string($raw) && $raw !== '') {
        $codes[] = $raw;
    }
}
$codes = array_values(array_unique($codes));
if (!$codes) {
    back_with_error('Не выбрано ни одной корректной позиции.', $page);
}

if (!is_file(DB_FILE)) {
    back_with_error('Боевая база сравнения (DB_FILE) ещё не положена на сервер.', $page);
}

if (!is_dir(OUTPUT_DIR) || !is_writable(OUTPUT_DIR)) {
    back_with_error('Папка для результатов недоступна на сервере.', $page);
}

// Список может быть длинным — через файл, не argv (см. web/
// onec_review_bulk.php за тем же приёмом).
$codesPath = OUTPUT_DIR . '/dup_remove_codes_' . bin2hex(random_bytes(8)) . '.json';
if (file_put_contents($codesPath, json_encode($codes, JSON_UNESCAPED_UNICODE)) === false) {
    back_with_error('Не удалось сохранить список выбранных позиций на сервере.', $page);
}

$cmdParts = [
    escapeshellarg(PYTHON_BIN),
    escapeshellarg(WEB_DB_DUPLICATES_REMOVE_SCRIPT),
    '--db', escapeshellarg(DB_FILE),
    '--codes-file', escapeshellarg($codesPath),
];
if (is_file(ONEC_NOMENCLATURE_FILE)) {
    $cmdParts[] = '--existing';
    $cmdParts[] = escapeshellarg(ONEC_NOMENCLATURE_FILE);
}

$cmd = implode(' ', $cmdParts) . ' 2>&1';
$output = shell_exec($cmd);
@unlink($codesPath);

if ($output === null || trim($output) === '') {
    back_with_error('Не удалось удалить выбранные позиции: команда не выполнилась (shell_exec '
        . 'недоступен на сервере, или путь PYTHON_BIN в config.php неверный).', $page);
}

$result = json_decode($output, true);
if (!is_array($result) || empty($result['ok'])) {
    // Admin-only страница — показываем реальный вывод скрипта, как и на
    // onec_database.php/onec_whitespace_cleanup.php/onec_review_bulk.php.
    $detail = is_array($result) ? (string) ($result['error'] ?? 'неизвестная ошибка') : trim($output);
    if (mb_strlen($detail, 'UTF-8') > 2000) {
        $detail = '…' . mb_substr($detail, -2000, null, 'UTF-8');
    }
    back_with_error('Не удалось удалить выбранные позиции: ' . $detail, $page);
}

back_with([
    'page' => $page,
    'removed' => 1,
    'dbRemoved' => (int) ($result['db_removed'] ?? 0),
    'skippedCount' => count($result['skipped'] ?? []),
]);
