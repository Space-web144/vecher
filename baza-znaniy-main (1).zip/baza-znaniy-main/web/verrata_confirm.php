<?php
declare(strict_types=1);

/**
 * Карточка «Что я нашёл» — подтверждение ролей редакций перед разбором.
 *
 * Роль редакции (исходная, изм.1, изм.2) определяется по имени файла, а
 * имя врёт: пакеты пересылают почтой, браузер дописывает «(1)», даты в
 * именах ставят от руки. Перепутанные роли дают отчёт, по которому закупят
 * не то, и в готовом Excel этого не видно — там всё стройно, только задом
 * наперёд. Поэтому инженер видит, что нашлось в файлах, и подтверждает
 * роли; его выбор побеждает имена (см. revisions.apply_roles).
 */

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require __DIR__ . '/lib.php';
// users.php нужен боковому меню: sidebar.php зовёт is_admin_tier_role().
require_once __DIR__ . '/users.php';

$token = $_GET['token'] ?? '';
if (!is_string($token) || !preg_match('/^[a-f0-9]{16}$/', $token)) {
    fail('Неверный номер задачи.', 400, 'verrata.php');
}
$cardPath = VERRATA_OUTPUT_DIR . '/' . $token . '_card.json';
$jobPath = VERRATA_OUTPUT_DIR . '/' . $token . '_job.json';
$card = is_file($cardPath) ? json_decode((string) file_get_contents($cardPath), true) : null;
$job = is_file($jobPath) ? json_decode((string) file_get_contents($jobPath), true) : null;
if (!is_array($card) || !is_array($job)) {
    fail('Карточка задачи не найдена или устарела — загрузите файлы заново.', 404, 'verrata.php');
}
if ((string) ($job['user'] ?? '') !== (string) ($_SESSION['kb_user'] ?? '')) {
    fail('Эта задача принадлежит другому пользователю.', 403, 'verrata.php');
}

$revisions = $card['revisions'] ?? [];
$warnings = $card['warnings'] ?? [];
$maxNumber = max(1, count($revisions) - 1);

function h(?string $text): string {
    return htmlspecialchars((string) $text, ENT_QUOTES, 'UTF-8');
}
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Verrata — что я нашёл</title>
<link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
<script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
</head>
<body>
<div class="shell">
  <?php require __DIR__ . '/sidebar.php'; ?>
  <div class="dashboard-main">
  <div class="page">

  <div class="card">
    <h1>Что я нашёл</h1>
    <p class="subtitle">Проверьте роли редакций перед разбором. Роль взята из имени файла — если она неверна, поменяйте её здесь: отчёт строится по тому порядку, который вы подтвердите.</p>

    <?php if ($warnings): ?>
      <div class="notice warn">
        <?php foreach ($warnings as $warning): ?>
          <p><?= h((string) $warning) ?></p>
        <?php endforeach; ?>
      </div>
    <?php endif; ?>

    <form action="verrata_process.php" method="post">
      <input type="hidden" name="confirm_token" value="<?= h($token) ?>">

      <?php foreach ($revisions as $revision): ?>
        <?php $file = (string) ($revision['file'] ?? ''); ?>
        <div class="field">
          <label class="field-label" for="role-<?= h(md5($file)) ?>"><?= h($file) ?></label>
          <select id="role-<?= h(md5($file)) ?>" name="role[<?= h($file) ?>]">
            <option value="0" <?= ((int) ($revision['role_number'] ?? 0) === 0) ? 'selected' : '' ?>>исходная редакция</option>
            <?php for ($n = 1; $n <= $maxNumber; $n++): ?>
              <option value="<?= $n ?>" <?= ((int) ($revision['role_number'] ?? 0) === $n) ? 'selected' : '' ?>>изм. <?= $n ?></option>
            <?php endfor; ?>
          </select>
          <p class="hint">
            Листов: <?= (int) ($revision['pages'] ?? 0) ?>.
            <?php if (!empty($revision['marka'])): ?>Марка в штампе: <?= h((string) $revision['marka']) ?>. <?php endif; ?>
            <?php if (!empty($revision['spec_pages'])): ?>
              Листы спецификации: <?= (int) $revision['spec_pages'][0] ?>–<?= (int) $revision['spec_pages'][1] ?>
              (<?= (int) ($revision['spec_sheets'] ?? 0) ?> л.).
            <?php else: ?>
              Листов спецификации не найдено.
            <?php endif; ?>
          </p>
          <?php foreach (($revision['permits'] ?? []) as $permit): ?>
            <p class="hint">
              Разрешение на стр. <?= (int) ($permit['page'] ?? 0) ?><?php
                if (!empty($permit['number'])) { echo ', № ' . h((string) $permit['number']); }
                if (!empty($permit['dates'])) { echo ' от ' . h((string) $permit['dates'][0]); }
              ?>:
              <?php foreach (($permit['changes'] ?? []) as $change): ?>
                <br><?= h((string) $change) ?>
              <?php endforeach; ?>
            </p>
          <?php endforeach; ?>
          <?php if (!empty($revision['change_log'])): ?>
            <p class="hint">Таблица изменений штампа: <?= h(implode(' · ', array_map('strval', $revision['change_log']))) ?></p>
          <?php endif; ?>
        </div>
      <?php endforeach; ?>

      <?php if (!empty($card['nz'])): ?>
        <div class="field">
          <label class="field-label">Наряд-заказы</label>
          <p class="hint"><?= h(implode(', ', array_map(static fn($item) => (string) ($item['file'] ?? ''), $card['nz']))) ?></p>
        </div>
      <?php endif; ?>

      <div class="field">
        <button type="submit">Всё верно — сравнивать</button>
        <p class="hint">Исходные файлы на сайте не хранятся: они удаляются сразу после обработки.</p>
      </div>
    </form>
  </div>

  </div>
  </div>
</div>
</body>
</html>
