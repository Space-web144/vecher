<?php
declare(strict_types=1);

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require_once __DIR__ . '/users.php';
// Пределы загрузки считаются там же, где их проверяет обработчик (lib.php).
require_once __DIR__ . '/lib.php';

// Пределы — действующие, с учётом настроек сервера: обещать на форме
// больше, чем примет PHP, нельзя.
$maxMb = megabytes(verrata_file_limit());
$postLimit = ini_bytes('post_max_size');
$totalMb = $postLimit > 0 ? megabytes($postLimit) : 0;
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Verrata — База знаний</title>
<link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
<script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
<script src="assets/dropzone.js?v=<?= filemtime(__DIR__ . '/assets/dropzone.js') ?>" defer></script>
</head>
<body>
<div class="shell">
  <?php require __DIR__ . '/sidebar.php'; ?>

  <div class="dashboard-main">
  <div class="page">

  <div class="card">
    <h1>Сравнение ревизий</h1>
    <p class="subtitle">Загрузите от <?= VERRATA_MIN_FILES ?> до <?= VERRATA_MAX_FILES ?> редакций одного комплекта — исходную и пакеты изменений. Порядок определяется по именам файлов: файл без пометки «изм.» считается исходной редакцией, остальные — по возрастанию номера.</p>

    <form action="verrata_process.php" method="post" enctype="multipart/form-data">
      <div class="field">
        <label class="field-label" for="section">Раздел проекта</label>
        <select id="section" name="section" required>
          <option value="" disabled selected>— выберите раздел —</option>
          <?php foreach (VERRATA_SECTIONS as $section): ?>
            <option value="<?= htmlspecialchars($section, ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($section, ENT_QUOTES, 'UTF-8') ?></option>
          <?php endforeach; ?>
        </select>
      </div>

      <div class="field">
        <label class="field-label" for="revisions">Файлы редакций (.pdf, до <?= $maxMb ?> МБ каждый<?= $totalMb ? ', всего до ' . $totalMb . ' МБ за загрузку' : '' ?>)</label>
        <input type="file" id="revisions" name="revisions[]" accept=".pdf" multiple required>
        <p class="hint">Выберите все редакции сразу — порядок не важен, он определится по именам файлов.</p>
      </div>

      <div class="field">
        <label class="field-label" for="nz">Наряд-заказы (.pdf, необязательно)</label>
        <input type="file" id="nz" name="nz[]" accept=".pdf" multiple>
        <p class="hint">Если приложить наряд-заказы, их материалы встанут в таблицу отдельными колонками рядом с колонками редакций: видно, что заказано сверх проекта. До <?= VERRATA_MAX_NZ ?> нарядов за раз. Без них сравниваются только редакции.</p>
      </div>

      <div class="field">
        <label class="field-label">Что обработать</label>
        <div class="verrata-modes">
          <?php foreach (VERRATA_MODES as $modeValue => $modeCaption): ?>
            <?php $enabled = in_array($modeValue, VERRATA_MODES_ENABLED, true); ?>
            <button type="submit" name="mode" value="<?= htmlspecialchars($modeValue, ENT_QUOTES, 'UTF-8') ?>"
                    <?= $enabled ? '' : 'disabled title="Режим временно отключён"' ?>>
              <?= htmlspecialchars($modeCaption, ENT_QUOTES, 'UTF-8') ?>
            </button>
          <?php endforeach; ?>
        </div>
        <p class="hint">«Спецификация» — сравнение спецификаций: таблица количеств по колонкам редакций, отчёт в Excel. «Графическая часть» — сравнение чертежей: сводка по листам, таблица отличий и карточки «было/стало» в PDF. «Полная обработка» — и то и другое; Excel собирается первым и остаётся доступным, даже если разбор чертежей сорвётся.</p>
        <p class="hint">Комплект на полторы сотни листов считается две-три минуты — страница ожидания обновляется сама, её можно оставить открытой.</p>
        <?php if (count(VERRATA_MODES_ENABLED) < count(VERRATA_MODES)): ?>
          <p class="hint">Часть режимов отключена администратором (см. VERRATA_MODES_ENABLED в настройках).</p>
        <?php endif; ?>
      </div>
    </form>
  </div>

  </div>
  </div>
</div>
</body>
</html>
