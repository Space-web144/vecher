/* Clean Papper evidence exports: all observations are unverified, never a bill. */
(function () {
  'use strict';
  var jsonButton = document.getElementById('cp-report-json');
  var excelButton = document.getElementById('cp-report-excel');
  var status = document.getElementById('cp-report-status');
  var form = document.getElementById('cp-drawing-form');
  if (!jsonButton || !excelButton || !form) return;

  var report = null;
  var MAX_ELEMENTS = 16, MAX_LABELS = 45;
  function setStatus(message) { status.textContent = message; }
  function enable(enabled) {
    jsonButton.disabled = !enabled;
    excelButton.disabled = !enabled;
  }
  function safeNum(value, max) {
    var v = Number(value);
    return Number.isFinite(v) && v >= 0 ? Math.min(v, max) : 0;
  }
  function short(value, n) {
    return typeof value === 'string' ? value.slice(0, n) : '';
  }
  function norm(value) {
    return short(value, 100).toLowerCase().replace(/\s+/g, '')
      .replace(/[xх×]/g, 'x').replace(/[Ø⌀ø]/g, 'ø');
  }
  function asPoint(x) {
    return Array.isArray(x) && x.length === 2 ? x.map(function (v) {
      return Number.isFinite(Number(v)) ? Number(v) : null;
    }) : [];
  }
  function cleanTrace(value) {
    if (!value || typeof value !== 'object') return {candidates: [], path_scanning: {}};
    var paths = value.path_scanning || {};
    return {
      source_page_rect_pdf_pt: Array.isArray(value.source_page_rect_pdf_pt)
        ? value.source_page_rect_pdf_pt.slice(0,4).map(Number) : [],
      region_pdf_pt: Array.isArray(value.region_pdf_pt)
        ? value.region_pdf_pt.slice(0,4).map(Number) : [],
      path_scanning: {
        scanned_paths: safeNum(paths.scanned_paths,100000),
        scan_truncated: paths.scan_truncated === true,
        candidate_lines_found: safeNum(paths.candidate_lines_found,100000),
        candidates_returned: safeNum(paths.candidates_returned,55),
        colored_paths_encountered: safeNum(paths.colored_paths_encountered,100000)
      },
      candidates: (Array.isArray(value.candidates)?value.candidates:[]).slice(0,55)
        .map(function (line) {
          return {
            candidate_id: short(line.candidate_id,12), source_id: short(line.source_id,75),
            status:'unverified_pdf_line', start_pdf_pt:asPoint(line.start_pdf_pt),
            end_pdf_pt:asPoint(line.end_pdf_pt),
            start_page_norm:asPoint(line.start_page_norm),
            end_page_norm:asPoint(line.end_page_norm),
            projected_length_pt:safeNum(line.projected_length_pt,100000),
            stroke_color:short(line.stroke_color,9),
            colored_stroke:line.colored_stroke === true,
            dimension_text_nearby: line.dimension_text_nearby ? {
              text:short(line.dimension_text_nearby.text,60),
              label_id:short(line.dimension_text_nearby.label_id,10),
              distance_pdf_pt:safeNum(line.dimension_text_nearby.distance_pdf_pt,100000)
            } : null,
            system_text_nearby:line.system_text_nearby ? {
              text:short(line.system_text_nearby.text,60),
              distance_pdf_pt:safeNum(line.system_text_nearby.distance_pdf_pt,100000)
            } : null,
            scale_verified:false, physical_length_m:null
          };
        })
    };
  }
  function point2(p) {
    return Array.isArray(p)&&p.length===2 ? p.map(function(x){return Number.isFinite(Number(x))?Number(x):null;}) : [];
  }
  function cleanTraceNetwork(value) {
    if(!value||typeof value!=='object')
      return {status:'not_available',scanning:{},candidates:[],spatial_groups:[]};
    var s=value.scanning||{};
    return {
      status:short(value.status,55),
      scanning:{
        colored_line_strokes_scanned:safeNum(s.colored_line_strokes_scanned,35000),
        trace_scan_truncated:s.trace_scan_truncated===true,
        collinear_families:safeNum(s.collinear_families,35000),
        parallel_pair_proposals:safeNum(s.parallel_pair_proposals,100000),
        trace_candidates_returned:safeNum(s.trace_candidates_returned,100),
        spatial_groups_returned:safeNum(s.spatial_groups_returned,100),
        source_selection_incomplete:s.source_selection_incomplete===true
      },
      candidates:(Array.isArray(value.candidates)?value.candidates:[]).slice(0,100)
        .map(function(c){
          return {
            candidate_id:short(c.candidate_id,12),
            kind:'parallel_colored_strokes',
            status:'unverified_trace_candidate',
            orientation:short(c.orientation,16),
            angle_deg:safeNum(c.angle_deg,180),
            stroke_color:short(c.stroke_color,12),
            spatial_group_id:short(c.spatial_group_id,12),
            center_start_pdf_pt:point2(c.center_start_pdf_pt),
            center_end_pdf_pt:point2(c.center_end_pdf_pt),
            center_start_page_norm:point2(c.center_start_page_norm),
            center_end_page_norm:point2(c.center_end_page_norm),
            projected_length_pt:safeNum(c.projected_length_pt,100000),
            width_between_strokes_pt:safeNum(c.width_between_strokes_pt,200),
            source_line_ids:(Array.isArray(c.source_line_ids)?c.source_line_ids:[])
              .slice(0,24).map(function(id){return short(id,80);}),
            source_line_count:safeNum(c.source_line_count,35000),
            dimension_text_nearby:c.dimension_text_nearby?{
              text:short(c.dimension_text_nearby.text,50),
              distance_pdf_pt:safeNum(c.dimension_text_nearby.distance_pdf_pt,100000)
            }:null,
            physical_length_m:null,scale_verified:false,system_verified:false,
            section_verified:false,manual_review_required:true
          };
        }),
      spatial_groups:(Array.isArray(value.spatial_groups)?value.spatial_groups:[])
        .slice(0,100).map(function(g){
          return {group_id:short(g.group_id,12),
            stroke_color:short(g.stroke_color,12),
            candidate_count:safeNum(g.candidate_count,100),
            bounds_pdf_pt:Array.isArray(g.bounds_pdf_pt)?g.bounds_pdf_pt.slice(0,4)
              .map(function(x){return Number.isFinite(Number(x))?Number(x):null;}):[],
            status:'spatial_hint_unverified'
          };
        }),
      limitations:(Array.isArray(value.limitations)?value.limitations:[])
        .slice(0,6).map(function(x){return short(x,160);})
    };
  }
  function cleanDuctGeometry(value) {
    if(!value||typeof value!=='object')return {status:'not_available',scanning:{},layer_statistics:[],candidates:[]};
    var scans=value.scanning||{};
    return {
      status:short(value.status,45),
      profile_applied: value.profile_applied && typeof value.profile_applied==='object'
        ? value.profile_applied : null,
      trace_network:cleanTraceNetwork(value.trace_network),
      scanning:{
        pdf_paths_scanned:safeNum(scans.pdf_paths_scanned,50000),
        segments_scanned:safeNum(scans.segments_scanned,130000),
        inclined_segments_excluded:safeNum(scans.inclined_segments_excluded,130000),
        scan_truncated:scans.scan_truncated===true,
        line_families_found:safeNum(scans.line_families_found,50000),
        candidate_duct_shapes_found:safeNum(scans.candidate_duct_shapes_found,50000),
        candidates_returned:safeNum(scans.candidates_returned,35)
      },
      layer_statistics:(Array.isArray(value.layer_statistics)?value.layer_statistics:[]).slice(0,12).map(function(l){
        return {stroke_color:short(l.stroke_color,12),stroke_width_pt:safeNum(l.stroke_width_pt,1000),
          dash_signature:short(l.dash_signature,45),stroke_count:safeNum(l.stroke_count,130000),
          pdf_path_count:safeNum(l.pdf_path_count,50000),
          total_stroke_length_pt:safeNum(l.total_stroke_length_pt,10000000),
          system:'unassigned'};
      }),
      candidates:(Array.isArray(value.candidates)?value.candidates:[]).slice(0,35).map(function(c){
        return {
          candidate_id:short(c.candidate_id,12),kind:short(c.kind,48),
          status:'unverified_duct_geometry',orientation:short(c.orientation,15),
          stroke_color:short(c.stroke_color,12),
          center_start_pdf_pt:point2(c.center_start_pdf_pt),
          center_end_pdf_pt:point2(c.center_end_pdf_pt),
          center_start_page_norm:point2(c.center_start_page_norm),
          center_end_page_norm:point2(c.center_end_page_norm),
          projected_length_pt:safeNum(c.projected_length_pt,100000),
          width_between_strokes_pt:c.width_between_strokes_pt==null?null:safeNum(c.width_between_strokes_pt,10000),
          source_line_ids:(Array.isArray(c.source_line_ids)?c.source_line_ids:[]).slice(0,24).map(function(id){return short(id,80);}),
          source_line_count:safeNum(c.source_line_count,100000),
          dimension_text_nearby:c.dimension_text_nearby?{text:short(c.dimension_text_nearby.text,50),
            distance_pdf_pt:safeNum(c.dimension_text_nearby.distance_pdf_pt,100000)}:null,
          physical_length_m:null,scale_verified:false,system_verified:false,
          section_verified:false,manual_review_required:true
        };
      }),
      assumptions:value.assumptions||{},
      limitations:(Array.isArray(value.limitations)?value.limitations:[]).slice(0,8).map(function(x){return short(x,160);})
    };
  }
  function cleanGeometry(info) {
    info = info && typeof info === 'object' ? info : {};
    return {
      vector_paths_sampled: safeNum(info.vector_paths_sampled, 100000),
      colored_paths_sampled: safeNum(info.colored_paths_sampled, 100000),
      sampling_limited: info.sampling_limited === true,
      drawing_inventory: (function(){
        var inv=info.drawing_inventory||{};
        return {
          strategy:short(inv.strategy,80),
          source_paths_total:safeNum(inv.source_paths_total,10000000),
          region_paths_total:safeNum(inv.region_paths_total,10000000),
          selected_paths:safeNum(inv.selected_paths,50000),
          sampling_truncated:inv.sampling_truncated===true,
          colored_paths_in_region:safeNum(inv.colored_paths_in_region,10000000),
          gray_or_unspecified_paths_in_region:safeNum(inv.gray_or_unspecified_paths_in_region,10000000),
          stroke_colors_in_region:(Array.isArray(inv.stroke_colors_in_region)?inv.stroke_colors_in_region:[]).slice(0,12)
            .map(function(c){return {color:short(c.color,9),path_count:safeNum(c.path_count,10000000)};}),
          fill_colors_in_region:(Array.isArray(inv.fill_colors_in_region)?inv.fill_colors_in_region:[]).slice(0,12)
            .map(function(c){return {color:short(c.color,9),path_count:safeNum(c.path_count,10000000)};})
        };
      })(),
      vector_trace: cleanTrace(info.vector_trace),
      vector_review: {calibration: null, manual_links: []},
      duct_geometry: cleanDuctGeometry(info.duct_geometry),
      duct_review: {layer_systems: []},
      section_text_candidates: (Array.isArray(info.section_text_candidates)
        ? info.section_text_candidates : []).slice(0, MAX_LABELS).map(function (x) {
        return {
          text: short(x.text, 75),
          at_pdf_pt: Array.isArray(x.at_pdf_pt) ? x.at_pdf_pt.slice(0, 2).map(function (n) {
            return Number.isFinite(Number(n)) ? Number(n) : null;
          }) : []
        };
      })
    };
  }
  function cleanVision(info, labels) {
    info = info && typeof info === 'object' ? info : {};
    var labelSet = labels.map(function (x) { return norm(x.text); });
    return {
      model: short(info.model, 105),
      input_tokens: safeNum(info.input_tokens, 1000000),
      output_tokens: safeNum(info.output_tokens, 1000000),
      elements: (Array.isArray(info.elements) ? info.elements : []).slice(0, MAX_ELEMENTS).map(function (x, i) {
        var dimension = short(x.dimension, 65);
        var match = !!dimension && labelSet.indexOf(norm(dimension)) !== -1;
        return {
          evidence_id: 'AI-' + String(i + 1).padStart(3, '0'),
          type: short(x.type, 30), label: short(x.label, 150),
          dimension: dimension, system: short(x.system, 65),
          confidence: short(x.confidence, 16), note: short(x.note, 260),
          pdf_dimension_text_match: match,
          quantity: null, length_m: null, surface_m2: null,
          confirmed_material: null, source: 'claude_vision',
          review_status: 'unverified'
        };
      }),
      notes: (Array.isArray(info.notes) ? info.notes : []).slice(0, 5).map(function (x) {
        return short(x, 260);
      })
    };
  }
  function createReport(detail) {
    var geometry = cleanGeometry(detail.geometry);
    var vision = cleanVision(detail.vision, geometry.section_text_candidates);
    var crop = Array.isArray(detail.crop) && detail.crop.length === 4
      ? detail.crop.map(function (x) { return Number(x); }) : [0, 0, 1, 1];
    return {
      schema: 'clean-papper.evidence.v1',
      created_at: new Date().toISOString(),
      scope: 'single_pdf_page_or_crop',
      source: {
        filename: short(detail.filename, 255),
        size_bytes: safeNum(detail.size_bytes, 104857600),
        page: safeNum(detail.page, 600),
        page_count: safeNum(detail.page_count, 600),
        crop_normalized: crop,
        preview_image_width_px: safeNum(detail.preview_image_width_px, 5000),
        preview_image_height_px: safeNum(detail.preview_image_height_px, 5000)
      },
      geometry: geometry,
      vision: vision,
      audit: {
        classification: 'DRAFT_NOT_A_BILL_OF_QUANTITIES',
        quantities_confirmed: false,
        lengths_confirmed: false,
        surface_areas_confirmed: false,
        material_grades_confirmed: false,
        localization_verified: false,
        scale_verified: false,
        systems_verified: false,
        note: 'PDF text occurrence is not physical duct-object proof; one model response is not an exhaustive drawing takeoff.',
        data_limits: {
          max_ai_items_per_request: MAX_ELEMENTS,
          max_pdf_section_labels: MAX_LABELS,
          vector_path_sample_limit: 8000,
          geometric_scan_budget: 50000,
          global_path_inventory_performed: true,
          duct_geometry_candidate_limit: 35,
          trace_network_candidate_limit: 100,
          trace_components_verified: false,
          system_color_mapping_verified: false
        }
      }
    };
  }
  function forget() {
    report = null;
    enable(false);
    setStatus('После локального предпросмотра можно скачать JSON/Excel-отчёт о геометрии; после Claude он дополнится объектами ИИ.');
  }
  window.addEventListener('clean-papper:reset', forget);
  window.addEventListener('clean-papper:preview', function (event) {
    var source=event.detail||{};
    var fileInput=document.getElementById('cp-drawing-file');
    var f=fileInput&&fileInput.files&&fileInput.files[0];
    report=createReport({
      filename:f?f.name:'',size_bytes:f?f.size:0,
      page:source.page, page_count:source.page_count||source.pages||source.page,
      crop:source.crop, geometry:source.geometry||{},
      vision:{model:'not_called',input_tokens:0,output_tokens:0,elements:[],notes:[]}
    });
    enable(true);
    setStatus('Готов JSON/Excel по локальной геометрии без Claude. Физические длины и объёмы не подтверждены.');
  });
  window.addEventListener('clean-papper:vision', function (event) {
    report = createReport(event.detail || {});
    enable(true);
    var count = report.vision.elements.length;
    var labels = report.geometry.section_text_candidates.length;
    setStatus('Доступно для экспорта: ' + count + ' кандидатов ИИ и ' +
      labels + ' подписей PDF. Расчётных объёмов пока нет.');
  });

  window.addEventListener('clean-papper:duct-review', function (event) {
    if (!report) return;
    var allowed=report.geometry.duct_geometry.layer_statistics.map(function(l){return l.stroke_color;});
    var traces=report.geometry.duct_geometry.trace_network.candidates||[];
    traces.forEach(function(t){if(allowed.indexOf(t.stroke_color)===-1)allowed.push(t.stroke_color);});
    var assignments=(event.detail&&Array.isArray(event.detail.layer_systems))?event.detail.layer_systems:[];
    report.geometry.duct_review={
      layer_systems:assignments.slice(0,12)
        .filter(function(v){return v&&allowed.indexOf(v.stroke_color)!==-1;})
        .map(function(v){return {
          stroke_color:short(v.stroke_color,12),
          system_manual:short(v.system_manual,60),
          review_status:'manual_color_hypothesis_unverified'
        };})
    };
  });
  window.addEventListener('clean-papper:vector-review', function (event) {
    if (!report) return;
    var review = event.detail || {};
    var known = report.geometry.vector_trace.candidates.map(function (line) {return line.source_id;});
    var links=(Array.isArray(review.manual_links)?review.manual_links:[])
      .filter(function (link) {return link && known.indexOf(link.source_id) !== -1;})
      .slice(0,55).map(function (link) {
        return {source_id:short(link.source_id,75),
          ai_evidence_id:short(link.ai_evidence_id,15),
          system_manual:short(link.system_manual,60),
          review_status:'manual_link_unverified'};
      });
    var c=review.calibration, calibration=null;
    if(c && c.method==='two_user_points_known_distance' &&
       Number.isFinite(Number(c.mm_per_pdf_pt)) && Number(c.mm_per_pdf_pt)>0 &&
       Number(c.mm_per_pdf_pt)<100000 &&
       Array.isArray(c.point_a_page_norm) && Array.isArray(c.point_b_page_norm)) {
      calibration={method:c.method, review_status:'manual_unverified',
        known_distance_mm:safeNum(c.known_distance_mm,200000),
        projected_distance_pdf_pt:safeNum(c.projected_distance_pdf_pt,100000),
        mm_per_pdf_pt:safeNum(c.mm_per_pdf_pt,100000),
        point_a_page_norm:asPoint(c.point_a_page_norm),
        point_b_page_norm:asPoint(c.point_b_page_norm)};
    }
    report.geometry.vector_review={calibration:calibration,manual_links:links};
  });

  function download(blob, name) {
    var url = URL.createObjectURL(blob);
    var link = document.createElement('a');
    link.href = url;
    link.download = name;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 2000);
  }
  jsonButton.addEventListener('click', function () {
    if (!report) return;
    var content = JSON.stringify(report, null, 2) + '\n';
    download(new Blob([content], {type: 'application/json;charset=utf-8'}),
      'clean-papper-evidence-page-' + report.source.page + '.json');
    setStatus('JSON-протокол скачан. Его можно приложить к диалогу для анализа.');
  });
  excelButton.addEventListener('click', async function () {
    if (!report) return;
    excelButton.disabled = true;
    setStatus('Составляем Excel-ведомость без повторного обращения к Claude…');
    try {
      var data = new FormData();
      var csrf = form.querySelector('input[name="csrf"]');
      data.set('csrf', csrf ? csrf.value : '');
      data.set('report', JSON.stringify(report));
      var response = await fetch('clean_papper_report.php', {
        method: 'POST', credentials: 'same-origin', body: data,
        headers: {Accept: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'}
      });
      if (!response.ok) {
        var error = await response.json().catch(function () { return {}; });
        throw new Error(error.message || ('Ошибка Excel (HTTP ' + response.status + ').'));
      }
      var blob = await response.blob();
      if (!blob.size || blob.size > 2000000) throw new Error('Неправильный ответ Excel.');
      download(blob, 'clean-papper-materials-page-' + report.source.page + '.xlsx');
      setStatus('Excel-ведомость скачана. Количества, метры и площади пока не подтверждены.');
    } catch (error) {
      setStatus(error && error.message ? error.message : 'Не удалось создать Excel.');
    } finally {
      excelButton.disabled = !report;
    }
  });
  forget();
})();
