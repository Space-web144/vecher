/* Automatic page settings and optional manual album override. */
(function(){
'use strict';
var form=document.getElementById('cp-drawing-form');
var file=document.getElementById('cp-drawing-file');
var hidden=document.getElementById('cp-profile-json');
var status=document.getElementById('cp-profile-status');
var importFile=document.getElementById('cp-profile-import');
var page=document.getElementById('cp-drawing-page');
var names=['rect_min_pt','rect_max_pt','coaxial_tol_pt','join_gap_pt',
'dash_gap_min_pt','dash_gap_max_pt','dash_median_min_pt'];
var defaults=[5,32,.06,.05,1.2,6.5,3.6];
var limits=[[.5,60],[2,150],[.01,.5],[.01,1.5],[.2,15],[.5,30],[.2,20]];
var active=null;
if(!form||!file||!hidden)return;
function text(s){status.textContent=s;}
function clearProfile(){
  active=null;hidden.value='';
  names.forEach(function(name,i){document.getElementById('cp-profile-'+name).value=defaults[i];});
  document.getElementById('cp-profile-region').value='unknown';
  document.getElementById('cp-profile-scale').value='unknown';
  text('Параметры подберутся при просмотре листа.');
}
function writeFields(value){
  names.forEach(function(name){document.getElementById('cp-profile-'+name).value=value.geometry[name];});
  document.getElementById('cp-profile-region').value=value.region_kind;
  document.getElementById('cp-profile-scale').value=value.nominal_scale;
}
function readForm(){
  var f=file.files&&file.files[0];
  if(!f)throw new Error('Сначала выберите PDF-альбом.');
  var geom={};
  names.forEach(function(name,i){
    var val=Number(document.getElementById('cp-profile-'+name).value);
    if(!Number.isFinite(val)||val<limits[i][0]||val>limits[i][1])
      throw new Error('Неверное значение '+name+'.');
    geom[name]=val;
  });
  if(geom.rect_min_pt>=geom.rect_max_pt||
     geom.dash_gap_min_pt>=geom.dash_gap_max_pt||
     geom.dash_median_min_pt<geom.dash_gap_min_pt||
     geom.dash_median_min_pt>geom.dash_gap_max_pt)
    throw new Error('Диапазоны допусков противоречат друг другу.');
  return {schema:'clean-papper.profile.v1',
    album:{name:f.name.slice(0,200),size_bytes:f.size},
    region_kind:document.getElementById('cp-profile-region').value,
    nominal_scale:document.getElementById('cp-profile-scale').value,
    geometry:geom,review_status:'manual_unverified'};
}
function apply(value){
  var f=file.files&&file.files[0];
  if(!f||value.schema!=='clean-papper.profile.v1'||
    !value.album||value.album.name!==f.name.slice(0,200)||
    value.album.size_bytes!==f.size)
    throw new Error('Этот профиль принадлежит другому PDF. Для него нужна отдельная настройка.');
  if(!value.geometry||typeof value.geometry!=='object')throw new Error('Нет геометрических настроек.');
  writeFields(value);
  // Re-validate after copying all fields, using the exact selected source.
  active=readForm();
  hidden.value=JSON.stringify(active);
  window.dispatchEvent(new CustomEvent('clean-papper:profile-changed',{detail:{profile:active}}));
  text('Применён ручной профиль альбома. Откройте лист повторно.');
}
document.getElementById('cp-profile-auto').addEventListener('click',function(){
  clearProfile();
  window.dispatchEvent(new CustomEvent('clean-papper:profile-changed'));
  document.getElementById('cp-preview-run').click();
});
document.getElementById('cp-profile-apply').addEventListener('click',function(){
  try{apply(readForm());}catch(e){text(e.message);}
});
document.getElementById('cp-profile-download').addEventListener('click',function(){
  try{
    var blob=new Blob([JSON.stringify(readForm(),null,2)+'\n'],{type:'application/json'});
    var url=URL.createObjectURL(blob),link=document.createElement('a');
    link.href=url;link.download='clean-papper-profile.json';
    document.body.appendChild(link);link.click();link.remove();
    setTimeout(function(){URL.revokeObjectURL(url);},1500);
  }catch(e){text(e.message);}
});
importFile.addEventListener('change',async function(){
  var f=importFile.files&&importFile.files[0];
  if(!f)return;
  try{
    if(f.size>6000)throw new Error('Профиль слишком большой.');
    apply(JSON.parse(await f.text()));
  }catch(e){text(e.message||'Не удалось открыть профиль.');}
  importFile.value='';
});
file.addEventListener('change',clearProfile);
page.addEventListener('change',function(){
  if(!active)clearProfile();
});
window.addEventListener('clean-papper:preview',function(event){
  var geometry=(event.detail||{}).geometry||{};
  var profile=(geometry.duct_geometry||{}).profile_applied;
  if(!profile||active)return;
  writeFields(profile);
  var evidence=profile.evidence||{};
  var scale=profile.nominal_scale;
  var message='Лист '+event.detail.page+'. ';
  if(scale!=='unknown'){
    message+='Масштаб '+scale+(evidence.scale_source==='horizontal_dimension_ticks'?' по горизонтальным размерам. ':'. ');
  }else message+='Масштаб не определён. ';
  var changed=(profile.geometry_updated||[]).length;
  message+=changed?'Допусков подобрано: '+changed+'.':'Применены стандартные допуски.';
  text(message);
});
names.concat(['region','scale']).forEach(function(name){
  document.getElementById('cp-profile-'+name).addEventListener('change',function(){
    active=null;hidden.value='';
    window.dispatchEvent(new CustomEvent('clean-papper:profile-changed'));
    text('Настройки изменились. Примените их вручную или вернитесь к автоподбору.');
  });
});
clearProfile();
})();
