// Общий скрипт интерфейса. Подключается в <head> каждой страницы
// синхронно, до отрисовки: тему нужно поставить раньше, чем браузер
// покажет страницу, иначе при тёмной теме мелькает светлый экран.
// sidebar.php подключает его ещё раз — на случай страницы, где в <head>
// его забыли; повторный запуск ничего не делает.
(function () {
  if (window.kbUi) return;
  window.kbUi = true;

  var root = document.documentElement;
  var KEY = 'kb-theme';

  // Тема: светлая по умолчанию, тёмная — по переключателю в меню. Выбор
  // хранится в браузере; если хранилище недоступно (приватный режим),
  // переключатель работает до перезагрузки страницы.
  function stored() {
    try { return localStorage.getItem(KEY); } catch (e) { return null; }
  }
  function apply(theme) {
    root.setAttribute('data-theme', theme === 'dark' ? 'dark' : 'light');
    var buttons = document.querySelectorAll('[data-theme-toggle]');
    for (var i = 0; i < buttons.length; i++) {
      buttons[i].setAttribute('aria-checked', theme === 'dark' ? 'true' : 'false');
    }
  }
  apply(stored());

  document.addEventListener('DOMContentLoaded', function () { apply(root.getAttribute('data-theme')); });

  document.addEventListener('click', function (e) {
    var toggle = e.target.closest && e.target.closest('[data-theme-toggle]');
    if (!toggle) return;
    var next = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    apply(next);
    try { localStorage.setItem(KEY, next); } catch (err) { /* без сохранения */ }
  });

  // Отклик на отправку формы: кнопка, которой отправили форму, получает
  // состояние «загрузка» (aria-busy), повторная отправка блокируется —
  // загрузка комплекта PDF идёт десятки секунд, и без отклика его
  // отправляют по второму разу. Кнопку не отключаем (disabled): тогда
  // браузер не передал бы её name/value, а по ним Verrata выбирает режим.
  document.addEventListener('submit', function (e) {
    if (e.defaultPrevented) return; // confirm() ответили «Отмена»
    var form = e.target;
    if (form.getAttribute('data-busy') === '1') {
      e.preventDefault();
      return;
    }
    form.setAttribute('data-busy', '1');
    if (e.submitter) e.submitter.setAttribute('aria-busy', 'true');
  });

  // Возврат кнопкой «Назад» достаёт страницу из кэша вместе с состоянием
  // «загрузка» — снимаем его.
  window.addEventListener('pageshow', function (e) {
    if (!e.persisted) return;
    var busy = document.querySelectorAll('[data-busy], [aria-busy="true"]');
    for (var i = 0; i < busy.length; i++) {
      busy[i].removeAttribute('data-busy');
      busy[i].removeAttribute('aria-busy');
    }
  });
})();
