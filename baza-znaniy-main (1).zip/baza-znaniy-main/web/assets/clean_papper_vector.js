/* PDF stroke evidence viewer. No stroke is automatically a verified duct. */
(function () {
'use strict';
var view=document.getElementById('cp-drawing-view');
var image=document.getElementById('cp-drawing-image');
var svg=document.getElementById('cp-vector-overlay');
var list=document.getElementById('cp-vector-list');
var detail=document.getElementById('cp-vector-details');
var modeText=document.getElementById('cp-vector-mode');
var scaleText=document.getElementById('cp-vector-calibration-status');
var knownInput=document.getElementById('cp-vector-known-mm');
var systemInput=document.getElementById('cp-vector-system');
var aiSelect=document.getElementById('cp-vector-ai');
if(!view||!image||!svg||!list)return;
var trace=null,mode='crop',selected='',marks=[],calibration=null,links=Object.create(null);
var NS='http://www.w3.org/2000/svg';
function write(el,s){if(el)el.textContent=s;}
function shape(tag,attrs){var el=document.createElementNS(NS,tag);Object.keys(attrs).forEach(function(k){el.setAttribute(k,attrs[k]);});svg.appendChild(el);}
function pointOk(p){return Array.isArray(p)&&p.length===2&&p.every(function(x){return Number.isFinite(Number(x));});}
function pagePoint(e){var r=image.getBoundingClientRect();if(!r.width||!r.height)return null;return [Math.max(0,Math.min(1,(e.clientX-r.left)/r.width)),Math.max(0,Math.min(1,(e.clientY-r.top)/r.height))];}
function pageDist(a,b){if(!trace)return 0;var r=trace.source_page_rect_pdf_pt;if(!r||r.length!==4)return 0;return Math.hypot((b[0]-a[0])*(r[2]-r[0]),(b[1]-a[1])*(r[3]-r[1]));}
function hitDistance(line,p){
var r=image.getBoundingClientRect(),a=line.start_page_norm,b=line.end_page_norm;
var ax=a[0]*r.width,ay=a[1]*r.height,bx=b[0]*r.width,by=b[1]*r.height,x=p[0]*r.width,y=p[1]*r.height;
var dx=bx-ax,dy=by-ay,den=dx*dx+dy*dy;if(!den)return 1e10;
var t=Math.max(0,Math.min(1,((x-ax)*dx+(y-ay)*dy)/den));
return Math.hypot(x-ax-t*dx,y-ay-t*dy);
}
function emitReview(){
var manual=Object.keys(links).slice(0,55).map(function(id){return {source_id:id,ai_evidence_id:links[id].ai_evidence_id,system_manual:links[id].system_manual,review_status:'manual_link_unverified'};});
window.dispatchEvent(new CustomEvent('clean-papper:vector-review',{detail:{calibration:calibration,manual_links:manual}}));
}
function paint(){
svg.replaceChildren();if(!trace)return;
(trace.candidates||[]).forEach(function(line){
var a=line.start_page_norm,b=line.end_page_norm;if(!pointOk(a)||!pointOk(b))return;
shape('line',{x1:a[0]*1000,y1:a[1]*1000,x2:b[0]*1000,y2:b[1]*1000,
stroke:line.source_id===selected?'#e95142':'#129ed4','stroke-width':line.source_id===selected?3.5:1.6,
'stroke-linecap':'round',opacity:line.source_id===selected?1:.68});
});
marks.forEach(function(p){shape('circle',{cx:p[0]*1000,cy:p[1]*1000,r:5,fill:'#14212d',stroke:'#efa93c','stroke-width':2.3});});
if(marks.length===2){shape('line',{x1:marks[0][0]*1000,y1:marks[0][1]*1000,x2:marks[1][0]*1000,y2:marks[1][1]*1000,stroke:'#efa93c','stroke-width':2,'stroke-dasharray':'8 6'});}
}
function showDetail(){
detail.replaceChildren();if(!trace||!selected){write(detail,'Выберите строку или нажмите на линию на чертеже.');return;}
var line=(trace.candidates||[]).find(function(v){return v.source_id===selected;});if(!line)return;
var info=document.createElement('p');info.textContent=line.candidate_id+' · '+line.source_id+' · '+line.projected_length_pt+' PDF pt';detail.appendChild(info);
var loc=document.createElement('p');loc.textContent='Начало '+line.start_pdf_pt.join(', ')+' pt; конец '+line.end_pdf_pt.join(', ')+' pt. Это концы штриха PDF, не подтверждённые стыки воздуховода.';detail.appendChild(loc);
var near=document.createElement('p');near.textContent='Рядом размер: '+(line.dimension_text_nearby?line.dimension_text_nearby.text:'не найден')+
'; система: '+(line.system_text_nearby?line.system_text_nearby.text:'не найдена')+'. Пространственная близость не доказывает принадлежность.';detail.appendChild(near);
if(calibration){
var estimate=document.createElement('p');estimate.className='cp-line-provisional';estimate.textContent='Проекционная длина по ручной калибровке: '+
(line.projected_length_pt*calibration.mm_per_pdf_pt/1000).toFixed(3)+' м (не подтверждена, НЕ включается в объёмы).';detail.appendChild(estimate);
}
var review=links[selected]||{ai_evidence_id:'',system_manual:''};
systemInput.value=review.system_manual;aiSelect.value=review.ai_evidence_id;
}
function select(id){selected=id;paint();list.querySelectorAll('button[data-source-id]').forEach(function(b){b.setAttribute('aria-pressed',b.dataset.sourceId===id?'true':'false');});showDetail();}
function showList(){
list.replaceChildren();
if(!trace){write(list,'Линии появятся после локального предпросмотра PDF.');showDetail();return;}
var stat=trace.path_scanning||{},p=document.createElement('p');p.className='hint';
p.textContent='Показано '+(trace.candidates||[]).length+' линий-кандидатов из '+(stat.candidate_lines_found||0)+
' найденных в '+(stat.scanned_paths||0)+' просмотренных PDF-путях'+(stat.scan_truncated?' (лимит достигнут)':'')+
'. Линия не равна воздуховоду.';list.appendChild(p);
(trace.candidates||[]).forEach(function(line){var b=document.createElement('button');b.type='button';b.className='cp-vector-item';b.dataset.sourceId=line.source_id;
b.textContent=line.candidate_id+' · '+line.projected_length_pt+' pt'+
(line.dimension_text_nearby?' · '+line.dimension_text_nearby.text:'')+
(line.colored_stroke?' · цвет':'');
b.addEventListener('click',function(){select(line.source_id);});list.appendChild(b);});
showDetail();
}
function setMode(v){
mode=v;
write(modeText,v==='crop'?'Выделение области':v==='line'?'Выбор линии':
 v==='duct'?'Выбор геометрического кандидата':'Калибровка по двум точкам');
}
window.CleanPapperVector={mode:function(){return mode;},setMode:setMode};
function reset(){
trace=null;selected='';marks=[];calibration=null;links=Object.create(null);setMode('crop');
aiSelect.replaceChildren();paint();showList();write(scaleText,'Масштаб не калиброван. PDF pt нельзя переводить в метры.');emitReview();
}
document.getElementById('cp-vector-crop-mode').addEventListener('click',function(){setMode('crop');});
document.getElementById('cp-vector-select-mode').addEventListener('click',function(){setMode('line');});
document.getElementById('cp-vector-calibrate-mode').addEventListener('click',function(){
marks=[];calibration=null;setMode('calibrate');paint();showDetail();emitReview();
write(scaleText,'Отметьте две точки с известным реальным расстоянием.');
});
document.getElementById('cp-vector-apply-scale').addEventListener('click',function(){
var mm=Number(knownInput.value);
if(marks.length!==2||!Number.isFinite(mm)||mm<10||mm>200000){write(scaleText,'Нужно отметить две точки и указать расстояние 10–200 000 мм.');return;}
var dist=pageDist(marks[0],marks[1]);if(dist<2){write(scaleText,'Точки слишком близки для калибровки.');return;}
calibration={method:'two_user_points_known_distance',review_status:'manual_unverified',
known_distance_mm:mm,point_a_page_norm:marks[0],point_b_page_norm:marks[1],
projected_distance_pdf_pt:Number(dist.toFixed(3)),mm_per_pdf_pt:Number((mm/dist).toFixed(8))};
write(scaleText,'Предварительно: '+calibration.mm_per_pdf_pt+' мм/PDF pt. Требует проверки плоскости и масштаба.');showDetail();emitReview();
});
document.getElementById('cp-vector-clear-scale').addEventListener('click',function(){
marks=[];calibration=null;paint();showDetail();emitReview();write(scaleText,'Калибровка сброшена.');
});
document.getElementById('cp-vector-save-link').addEventListener('click',function(){
if(!selected)return;var value=(systemInput.value||'').trim().slice(0,60).replace(/[\x00-\x1f\x7f<>]/g,'');
links[selected]={ai_evidence_id:aiSelect.value||'',system_manual:value};emitReview();
write(modeText,'Ручная связь сохранена (не подтверждена)');
});
view.addEventListener('pointerup',function(e){
if(mode==='crop'||mode==='duct'||!trace||view.hidden)return;
var p=pagePoint(e);if(!p)return;
if(mode==='calibrate'){
if(marks.length===2){marks=[];calibration=null;emitReview();}
marks.push(p);paint();
write(scaleText,marks.length===1?'Первая точка есть, укажите вторую.':'Точки выбраны. Введите известное расстояние и нажмите «Применить».');
}else{
var nearest=null,distance=16;(trace.candidates||[]).forEach(function(line){var d=hitDistance(line,p);if(d<distance){nearest=line;distance=d;}});
if(nearest)select(nearest.source_id);
}
});
window.addEventListener('clean-papper:reset',reset);
window.addEventListener('clean-papper:preview',function(e){
reset();trace=(e.detail&&e.detail.geometry&&e.detail.geometry.vector_trace)||null;paint();showList();
});
window.addEventListener('clean-papper:vision',function(e){
var d=e.detail||{},next=d.geometry&&d.geometry.vector_trace;
if(next){trace=next;selected='';links=Object.create(null);paint();showList();}
aiSelect.replaceChildren();var empty=document.createElement('option');empty.value='';empty.textContent='Без связи';aiSelect.appendChild(empty);
((d.vision&&d.vision.elements)||[]).forEach(function(el,i){var o=document.createElement('option');o.value='AI-'+String(i+1).padStart(3,'0');o.textContent=o.value+' '+String(el.label||el.type||'').slice(0,80);aiSelect.appendChild(o);});
showDetail();emitReview();
});
reset();
})();
