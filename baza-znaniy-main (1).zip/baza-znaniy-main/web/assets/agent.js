// Чат «Ассистент» (web/agent.php). Части файлов и вопрос отправляются
// через XHR в agent_api.php, ответ модели готовит
// фоновый процесс — пока чат в ожидании, страница опрашивает его раз в
// две секунды.
//
// Ответ модели — Markdown. Он собирается в DOM только через textContent и
// createElement: HTML из ответа на страницу не попадает никогда, ссылки —
// только http(s).
(function () {
  var stateEl = document.getElementById('agent-state');
  if (!stateEl) return;
  var state = JSON.parse(stateEl.textContent);
  // Имя чата: в обновлённом оформлении — «Альфик» (state.name), иначе —
  // прежнее «Ассистент».
  var NAME = state.name || 'Ассистент';
  var NAME_LOWER = state.name || 'ассистент';
  var chat = state.chat;

  var log = document.getElementById('agent-log');
  var form = document.getElementById('agent-form');
  var input = document.getElementById('agent-text');
  var sendBtn = document.getElementById('agent-send');
  var formError = document.getElementById('agent-form-error');
  var titleEl = document.getElementById('agent-title');
  var list = document.getElementById('agent-chats');
  var fileInput = document.getElementById('agent-files');
  var heavyInput = document.getElementById('agent-heavy');
  var picked = document.getElementById('agent-picked');
  var uploadBox = document.getElementById('agent-upload');
  var attachBtn = document.getElementById('agent-attach');
  var sideToggle = document.getElementById('agent-side-toggle');
  var sideList = document.getElementById('agent-side-list');
  var sideCount = document.getElementById('agent-side-count');

  var POLL_MS = 2000;
  var pollTimer = null;
  var tickTimer = null;
  var pendingSince = 0;
  var renderedKey = null;
  var requestInFlight = false;

  // ── мелочи ──

  function el(tag, cls, text) {
    var node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text !== undefined && text !== null) node.textContent = text;
    return node;
  }

  function elapsedText(sec) {
    sec = Math.max(0, Math.floor(sec));
    if (sec < 60) return sec + ' с';
    var s = sec % 60;
    return Math.floor(sec / 60) + ' мин ' + (s < 10 ? '0' : '') + s + ' с';
  }

  var SVG = 'http://www.w3.org/2000/svg';
  function icon(d) {
    var svg = document.createElementNS(SVG, 'svg');
    svg.setAttribute('width', '18');
    svg.setAttribute('height', '18');
    svg.setAttribute('viewBox', '0 0 24 24');
    svg.setAttribute('fill', 'none');
    svg.setAttribute('stroke', 'currentColor');
    svg.setAttribute('stroke-width', '1.7');
    svg.setAttribute('stroke-linecap', 'round');
    svg.setAttribute('stroke-linejoin', 'round');
    svg.setAttribute('aria-hidden', 'true');
    var path = document.createElementNS(SVG, 'path');
    path.setAttribute('d', d);
    svg.appendChild(path);
    return svg;
  }

  function showFormError(message) {
    formError.textContent = message;
    formError.hidden = !message;
  }

  function sizeText(bytes) {
    if (bytes >= 1024 * 1024) return (bytes / 1024 / 1024).toFixed(1).replace('.', ',') + ' МБ';
    return Math.max(1, Math.round(bytes / 1024)) + ' КБ';
  }

  function tokensText(tokens) {
    return tokens >= 1000 ? '≈ ' + Math.round(tokens / 1000) + ' тыс. токенов' : '≈ ' + tokens + ' токенов';
  }

  // ── Markdown → DOM ──

  var FENCE_RE = /^\s*(```|~~~)/;
  var HEADING_RE = /^\s*#{1,6}\s+(.+?)\s*#*\s*$/;
  var HR_RE = /^\s*(-{3,}|\*{3,}|_{3,})\s*$/;
  var LIST_RE = /^(\s*)([-*+•]|\d{1,3}[.)])\s+(.*)$/;
  var QUOTE_RE = /^\s*>\s?(.*)$/;
  var TABLE_SEP_RE = /^\s*\|?\s*:?-{2,}:?\s*(\|\s*:?-{2,}:?\s*)*\|?\s*$/;
  // Код, **жирный**, *курсив* (звёздочка не внутри слова: 2*3*4 — не
  // курсив), [ссылка](http…), голый адрес http(s).
  var INLINE_SRC = '(`+)([^`]|[^`][\\s\\S]*?[^`])\\1(?!`)'
    + '|\\*\\*(?=\\S)([\\s\\S]+?)\\*\\*'
    + '|(^|[\\s(«"„])\\*(?=[^\\s*])([^*\\n]+?)\\*(?![\\w*])'
    + '|\\[([^\\]\\n]+)\\]\\((https?:\\/\\/[^\\s)]+)\\)'
    + '|(https?:\\/\\/[^\\s<>()«»"]+[^\\s<>()«»".,;:!?\'])';

  function link(text, href) {
    var a = el('a', null, text);
    a.href = href;
    a.target = '_blank';
    a.rel = 'noopener noreferrer';
    return a;
  }

  function inline(text, parent) {
    var re = new RegExp(INLINE_SRC, 'g');
    var last = 0;
    var m;
    while ((m = re.exec(text)) !== null) {
      var start = m.index;
      if (m[4] !== undefined) start += m[4].length;  // пробел перед *курсивом*
      if (start > last) parent.appendChild(document.createTextNode(text.slice(last, start)));
      if (m[1]) {
        parent.appendChild(el('code', null, m[2]));
      } else if (m[3] !== undefined) {
        var strong = el('strong');
        inline(m[3], strong);
        parent.appendChild(strong);
      } else if (m[5] !== undefined) {
        var em = el('em');
        inline(m[5], em);
        parent.appendChild(em);
      } else if (m[6] !== undefined) {
        parent.appendChild(link(m[6], m[7]));
      } else if (m[8]) {
        parent.appendChild(link(m[8], m[8]));
      }
      last = re.lastIndex;
      if (m[0] === '') re.lastIndex++;
    }
    if (last < text.length) parent.appendChild(document.createTextNode(text.slice(last)));
  }

  function isBlank(line) { return /^\s*$/.test(line); }

  function isTableStart(lines, i) {
    return lines[i].indexOf('|') !== -1 && i + 1 < lines.length && TABLE_SEP_RE.test(lines[i + 1])
      && lines[i + 1].indexOf('-') !== -1;
  }

  function startsBlock(lines, i) {
    var line = lines[i];
    return FENCE_RE.test(line) || HEADING_RE.test(line) || HR_RE.test(line)
      || LIST_RE.test(line) || QUOTE_RE.test(line) || isTableStart(lines, i);
  }

  function splitRow(line) {
    var s = line.trim();
    if (s.charAt(0) === '|') s = s.slice(1);
    if (s.charAt(s.length - 1) === '|') s = s.slice(0, -1);
    return s.split('|').map(function (cell) { return cell.trim(); });
  }

  function renderTable(lines, i, root) {
    var head = splitRow(lines[i]);
    var aligns = splitRow(lines[i + 1]).map(function (cell) {
      var left = cell.charAt(0) === ':';
      var right = cell.charAt(cell.length - 1) === ':';
      return left && right ? 'center' : (right ? 'right' : '');
    });
    i += 2;
    var wrap = el('div', 'agent-table-wrap');
    var table = el('table', 'agent-table');
    var thead = el('thead');
    var tr = el('tr');
    head.forEach(function (cell, k) {
      var th = el('th');
      if (aligns[k]) th.style.textAlign = aligns[k];
      inline(cell, th);
      tr.appendChild(th);
    });
    thead.appendChild(tr);
    table.appendChild(thead);
    var tbody = el('tbody');
    while (i < lines.length && !isBlank(lines[i]) && lines[i].indexOf('|') !== -1) {
      var row = el('tr');
      splitRow(lines[i]).forEach(function (cell, k) {
        var td = el('td');
        if (aligns[k]) td.style.textAlign = aligns[k];
        inline(cell, td);
        row.appendChild(td);
      });
      tbody.appendChild(row);
      i++;
    }
    table.appendChild(tbody);
    wrap.appendChild(table);
    root.appendChild(wrap);
    return i;
  }

  function renderList(lines, i, root) {
    var first = lines[i].match(LIST_RE);
    var ordered = /\d/.test(first[2]);
    var indent = first[1].length;
    var listEl = el(ordered ? 'ol' : 'ul');
    if (ordered && parseInt(first[2], 10) > 1) listEl.start = parseInt(first[2], 10);
    var item = null;
    while (i < lines.length) {
      var line = lines[i];
      if (isBlank(line)) {
        // Пустая строка между пунктами не обрывает список.
        var j = i + 1;
        while (j < lines.length && isBlank(lines[j])) j++;
        var next = j < lines.length ? lines[j].match(LIST_RE) : null;
        if (next && next[1].length >= indent) { i = j; continue; }
        break;
      }
      var m = line.match(LIST_RE);
      if (m) {
        var depth = m[1].length;
        if (depth < indent - 1) break;                 // пункт внешнего списка
        if (depth > indent + 1 && item) {              // вложенный список
          i = renderList(lines, i, item);
          continue;
        }
        if (/\d/.test(m[2]) !== ordered) break;
        item = el('li');
        inline(m[3], item);
        listEl.appendChild(item);
        i++;
        continue;
      }
      if (item && /^\s+\S/.test(line)) {               // продолжение пункта
        item.appendChild(el('br'));
        inline(line.trim(), item);
        i++;
        continue;
      }
      break;
    }
    root.appendChild(listEl);
    return i;
  }

  function renderMarkdown(text, root) {
    var lines = String(text).replace(/\r\n?/g, '\n').split('\n');
    var i = 0;
    while (i < lines.length) {
      var line = lines[i];
      if (isBlank(line)) { i++; continue; }

      var fence = line.match(FENCE_RE);
      if (fence) {
        var code = [];
        i++;
        while (i < lines.length && lines[i].trim().indexOf(fence[1]) !== 0) { code.push(lines[i]); i++; }
        i++;
        var pre = el('pre', 'agent-code');
        pre.appendChild(el('code', null, code.join('\n')));
        root.appendChild(pre);
        continue;
      }
      var heading = line.match(HEADING_RE);
      if (heading) {
        var h = el('p', 'agent-md-heading');
        inline(heading[1], h);
        root.appendChild(h);
        i++;
        continue;
      }
      if (HR_RE.test(line)) { root.appendChild(el('hr')); i++; continue; }
      if (isTableStart(lines, i)) { i = renderTable(lines, i, root); continue; }
      if (LIST_RE.test(line)) { i = renderList(lines, i, root); continue; }
      if (QUOTE_RE.test(line)) {
        var quoted = [];
        while (i < lines.length && QUOTE_RE.test(lines[i])) { quoted.push(lines[i].match(QUOTE_RE)[1]); i++; }
        var bq = el('blockquote');
        renderMarkdown(quoted.join('\n'), bq);
        root.appendChild(bq);
        continue;
      }
      // Абзац: строки до пустой или до начала другого блока; перевод
      // строки внутри абзаца сохраняется — в расчётах он значим.
      var p = el('p');
      inline(line.trim(), p);
      i++;
      while (i < lines.length && !isBlank(lines[i]) && !startsBlock(lines, i)) {
        p.appendChild(el('br'));
        inline(lines[i].trim(), p);
        i++;
      }
      root.appendChild(p);
    }
  }

  // ── выбранные файлы ──

  // Свой список вместо FileList поля: из него можно убрать один файл.
  var files = [];
  var uploadDraft = null;

  function fileProblem(file) {
    var ext = (file.name.split('.').pop() || '').toLowerCase();
    if (file.name.indexOf('.') === -1 || state.fileTypes.indexOf(ext) === -1) {
      return '«' + file.name + '» — такие файлы ' + NAME_LOWER + ' не принимает. Подходят: ' + state.fileTypes.join(', ') + '.';
    }
    if (file.size > state.maxFileBytes) {
      return '«' + file.name + '» больше ' + Math.floor(state.maxFileBytes / 1024 / 1024) + ' МБ.';
    }
    if (file.size === 0) return '«' + file.name + '» — пустой файл.';
    return '';
  }

  function extOf(name) {
    var dot = name.lastIndexOf('.');
    return dot > 0 ? name.slice(dot + 1).toLowerCase() : '';
  }

  function renderPicked() {
    picked.textContent = '';
    picked.hidden = !files.length;
    files.forEach(function (file, k) {
      var li = el('li', 'agent-chip');
      li.appendChild(el('span', 'agent-chip-ext', extOf(file.name) || 'файл'));
      var chipName = el('span', 'agent-chip-name');
      breakable(file.name, chipName);
      li.appendChild(chipName);
      li.appendChild(el('span', 'agent-chip-meta', sizeText(file.size)));
      var remove = el('button', 'agent-chip-remove');
      remove.type = 'button';
      remove.setAttribute('aria-label', 'Убрать файл ' + file.name);
      remove.title = 'Убрать';
      remove.appendChild(icon('M6 6l12 12M18 6 6 18'));
      remove.addEventListener('click', function () {
        if (requestInFlight) return;
        files.splice(k, 1);
        renderPicked();
        input.focus();
      });
      li.appendChild(remove);
      picked.appendChild(li);
    });
  }

  // Своя кнопка вместо системного поля выбора файла: у системного надпись
  // на языке браузера («Choose Files») и вид не настраивается.
  if (attachBtn) {
    attachBtn.addEventListener('click', function () { fileInput.click(); });
    var note = document.getElementById('agent-attach-note');
    if (note) attachBtn.title = 'Прикрепить файлы. ' + note.textContent;
  }

  // Добавить файлы в список к отправке — из поля выбора, перетаскиванием
  // или вставкой из буфера. Одни и те же проблемы не повторяются.
  function addFiles(fileList) {
    if (fileInput.disabled || requestInFlight) return;
    var problems = [];
    Array.prototype.forEach.call(fileList || [], function (file) {
      var problem = fileProblem(file);
      if (problem) {
        problems.push(problem);
      } else if (files.length >= state.maxFiles) {
        problems.push('За раз — не больше ' + state.maxFiles + ' файлов.');
      } else {
        files.push(file);
      }
    });
    showFormError(problems.filter(function (p, k) { return problems.indexOf(p) === k; }).join(' '));
    renderPicked();
  }

  fileInput.addEventListener('change', function () {
    addFiles(fileInput.files);
    // Поле очищаем: выбранное живёт в списке files, а повторный выбор
    // того же файла должен снова срабатывать.
    fileInput.value = '';
  });

  // Вставка из буфера (Ctrl+V): снимок экрана приходит файлом без имени —
  // даём имя с датой, чтобы в чате было видно, что это. Текст вставляется
  // как обычно.
  var pasteCount = 0;
  document.addEventListener('paste', function (event) {
    var data = event.clipboardData;
    if (!data || !data.files || !data.files.length) return;
    var named = Array.prototype.map.call(data.files, function (file) {
      if (file.name && file.name !== 'image.png' && file.name.indexOf('.') > 0) return file;
      var ext = (file.type.split('/')[1] || 'png').replace('jpeg', 'jpg');
      pasteCount += 1;
      var stamp = new Date();
      var name = 'Снимок экрана ' + stamp.toLocaleDateString('ru-RU') + ' ' +
        stamp.toLocaleTimeString('ru-RU', {hour: '2-digit', minute: '2-digit'}).replace(':', '.') +
        (pasteCount > 1 ? ' (' + pasteCount + ')' : '') + '.' + ext;
      try {
        return new File([file], name, {type: file.type});
      } catch (err) {
        return file;
      }
    });
    event.preventDefault();
    addFiles(named);
    input.focus();
  });

  // Перетаскивание файлов на страницу чата: подсвечиваем поле ввода, по
  // отпусканию добавляем. Браузер по умолчанию открыл бы файл — отменяем.
  var box = form.querySelector('.agent-box');
  var dragDepth = 0;
  function hasFiles(event) {
    var types = event.dataTransfer && event.dataTransfer.types;
    return !!types && Array.prototype.indexOf.call(types, 'Files') !== -1;
  }
  document.addEventListener('dragenter', function (event) {
    if (!hasFiles(event) || fileInput.disabled) return;
    event.preventDefault();
    dragDepth += 1;
    if (box) box.classList.add('is-dragover');
  });
  document.addEventListener('dragover', function (event) {
    if (!hasFiles(event)) return;
    event.preventDefault();
    if (event.dataTransfer) event.dataTransfer.dropEffect = fileInput.disabled ? 'none' : 'copy';
  });
  document.addEventListener('dragleave', function (event) {
    if (!hasFiles(event)) return;
    dragDepth = Math.max(0, dragDepth - 1);
    if (!dragDepth && box) box.classList.remove('is-dragover');
  });
  document.addEventListener('drop', function (event) {
    if (!hasFiles(event)) return;
    event.preventDefault();
    dragDepth = 0;
    if (box) box.classList.remove('is-dragover');
    addFiles(event.dataTransfer.files);
    input.focus();
  });

  // ── чат ──

  var STATUS_TEXT = {new: 'обрабатывается…', error: 'не обработан'};

  function renderAttachments(items) {
    var ul = el('ul', 'agent-chips');
    items.forEach(function (item) {
      var li = el('li', 'agent-chip' + (item.status === 'error' ? ' is-error' : ''));
      li.appendChild(el('span', 'agent-chip-ext', extOf(item.name) || 'файл'));
      var chipName = el('span', 'agent-chip-name');
      breakable(item.name, chipName);
      li.appendChild(chipName);
      var meta = [sizeText(item.size || 0)];
      if (item.status === 'ok') {
        if (item.pages) meta.push(item.pages + ' стр.');
        if (item.note) meta.push(item.note);
      } else {
        meta.push(STATUS_TEXT[item.status] || '');
      }
      li.appendChild(el('span', 'agent-chip-meta', meta.join(', ')));
      if (item.status === 'error' && item.error) {
        li.appendChild(el('span', 'agent-chip-error', item.error));
      }
      ul.appendChild(li);
    });
    return ul;
  }

  // Файлы, которые создал ассистент: карточка с типом файла и кнопкой
  // «Скачать» (agent_file.php отдаёт их только автору чата).
  function renderOutputs(items) {
    var ul = el('ul', 'agent-outputs');
    items.forEach(function (item) {
      var href = 'agent_file.php?chat=' + encodeURIComponent(chat.id) + '&file=' + encodeURIComponent(item.id);
      var li = el('li', 'agent-output');
      li.appendChild(el('span', 'agent-output-ext', extOf(item.name) || 'файл'));
      var body = el('span', 'agent-output-body');
      var name = el('a', 'agent-output-name');
      breakable(item.name, name);
      name.href = href;
      name.setAttribute('download', '');
      body.appendChild(name);
      body.appendChild(el('span', 'agent-output-meta', sizeText(item.size || 0)));
      li.appendChild(body);
      var get = el('a', 'btn secondary btn-small agent-output-get');
      get.href = href;
      get.setAttribute('download', '');
      get.setAttribute('aria-label', 'Скачать ' + item.name);
      get.appendChild(icon('M12 4v11m0 0-4.5-4.5M12 15l4.5-4.5M5 20h14'));
      get.appendChild(el('span', null, 'Скачать'));
      li.appendChild(get);
      ul.appendChild(li);
    });
    return ul;
  }

  // Имя файла без пробелов («Воздухообмен_по_кратности.xlsx») браузер
  // переносит по буквам. Подсказываем места: после «_», «-», «.».
  function breakable(text, parent) {
    String(text).split(/([_\-.])/).forEach(function (part, k) {
      if (!part) return;
      parent.appendChild(document.createTextNode(part));
      if (k % 2 === 1) parent.appendChild(document.createElement('wbr'));
    });
  }

  function domainOf(url) {
    var m = /^https?:\/\/(?:www\.)?([^\/?#:]+)/i.exec(url);
    return m ? m[1] : '';
  }

  // Источники из интернета, на которые опирается ответ: адрес сайта и
  // название страницы — по адресу видно, первоисточник это или пересказ.
  function renderSources(items) {
    var box = el('div', 'agent-sources');
    box.appendChild(el('p', 'agent-sources-title', 'Источники'));
    var ul = el('ul');
    items.forEach(function (item) {
      if (!/^https?:\/\//i.test(item.url)) return;
      var li = el('li');
      li.appendChild(el('span', 'agent-source-domain', domainOf(item.url)));
      li.appendChild(link(item.title || item.url, item.url));
      ul.appendChild(li);
    });
    box.appendChild(ul);
    return box;
  }

  function renderMessage(message, isLast) {
    var isUser = message.role === 'user';
    var wrap = el('div', 'agent-msg ' + (isUser ? 'is-user' : 'is-assistant'));
    wrap.appendChild(el('div', 'agent-msg-who caps', isUser ? 'Вы' : NAME));
    var attachments = message.attachments || [];
    if (!isUser || message.text || !attachments.length) {
      var body = el('div', 'agent-msg-body');
      if (isUser) {
        body.textContent = message.text;
      } else {
        renderMarkdown(message.text, body);
      }
      wrap.appendChild(body);
    }
    if (attachments.length) wrap.appendChild(renderAttachments(attachments));
    if (!isUser && message.files && message.files.length) wrap.appendChild(renderOutputs(message.files));
    if (!isUser && message.sources && message.sources.length) wrap.appendChild(renderSources(message.sources));

    if (message.truncated) {
      wrap.appendChild(el('p', 'hint', 'Ответ оборвался по пределу длины — напишите «продолжи», и ' + NAME_LOWER + ' допишет.'));
    }
    if (!isUser && navigator.clipboard) {
      var actions = el('div', 'agent-msg-actions');
      var copy = el('button', 'agent-copy', 'Скопировать ответ');
      copy.type = 'button';
      copy.addEventListener('click', function () {
        navigator.clipboard.writeText(message.text).then(function () {
          copy.textContent = 'Скопировано';
          setTimeout(function () { copy.textContent = 'Скопировать ответ'; }, 2000);
        });
      });
      actions.appendChild(copy);
      wrap.appendChild(actions);
    }
    if (message.error) {
      wrap.appendChild(el('div', 'alert error', 'Ответ не получен. ' + message.error));
      // Повтор — только если файлы вопроса в порядке: не обработанные
      // нужно прикрепить заново.
      var filesOk = attachments.every(function (item) {
        return item.status === (message.processing === 'vps' ? 'new' : 'ok');
      });
      if (isLast && !chat.pending && filesOk) {
        var retry = el('button', 'secondary btn-small', 'Спросить ещё раз');
        retry.type = 'button';
        retry.addEventListener('click', function () {
          if (requestInFlight) return;
          retry.setAttribute('aria-busy', 'true');
          post({action: 'retry', chat: chat.id}).then(function () { retry.removeAttribute('aria-busy'); });
        });
        wrap.appendChild(retry);
      }
    }
    return wrap;
  }

  // Пустой чат: короткая подсказка, что можно приложить.
  function renderStart() {
    var box = el('div', 'agent-start');
    box.appendChild(el('p', 'agent-start-note', 'Можно приложить документы, таблицы и чертежи в PDF. Каждый следующий вопрос ' + NAME_LOWER + ' читает вместе со всей перепиской и файлами чата.'));
    return box;
  }

  function stageText(pending) {
    if (pending.stage === 'files' && pending.filesTotal) {
      return NAME + ' готовит файлы: ' + pending.filesDone + ' из ' + pending.filesTotal + '…';
    }
    // Процесс ещё не взялся за вопрос, а файлы в нём есть — первым делом
    // будут они, а не ответ.
    var last = chat.messages[chat.messages.length - 1];
    var waiting = last && (last.attachments || []).some(function (item) { return item.status === 'new'; });
    if (!pending.stage && waiting) return NAME + ' готовит файлы…';
    // Что ассистент делает сейчас: думает, ищет в интернете, работает с
    // кодом, открывает документ.
    if (pending.activity) return NAME + ' ' + pending.activity.charAt(0).toLowerCase() + pending.activity.slice(1) + '…';
    return NAME + ' готовит ответ…';
  }

  // Переписка перерисовывается, только когда меняются сами сообщения.
  // Пока ответ пишется, меняются лишь черновик и строка «что делает» —
  // их узлы обновляются на месте: иначе каждый опрос (раз в 2 с) сбрасывал
  // бы выделение текста и прокрутку в предыдущих ответах.
  var draftEl = null;
  var draftBody = null;
  var draftText = null;
  var runningEl = null;

  function render() {
    var stage = chat && chat.pending ? stageText(chat.pending) : '';
    var partial = chat && chat.pending ? (chat.pending.partial || '') : '';
    var changed = false;
    var key = chat ? JSON.stringify([chat.messages, !!chat.pending]) : '';
    if (key !== renderedKey) {
      renderedKey = key;
      changed = true;
      log.textContent = '';
      draftEl = draftBody = runningEl = null;
      draftText = null;
      if (!chat || !chat.messages.length) {
        log.appendChild(renderStart());
        return true;
      }
      chat.messages.forEach(function (message, k) {
        log.appendChild(renderMessage(message, k === chat.messages.length - 1));
      });
    }
    if (!chat) return changed;

    // Ответ по мере написания: тот же вид, что у готового, но без кнопок.
    if (chat.pending && partial) {
      if (!draftEl) {
        draftEl = el('div', 'agent-msg is-assistant is-draft');
        draftEl.appendChild(el('div', 'agent-msg-who caps', NAME));
        draftBody = el('div', 'agent-msg-body');
        draftEl.appendChild(draftBody);
        log.insertBefore(draftEl, runningEl);
      }
      if (partial !== draftText) {
        draftText = partial;
        draftBody.textContent = '';
        renderMarkdown(partial, draftBody);
        changed = true;
      }
    } else if (draftEl) {
      log.removeChild(draftEl);
      draftEl = draftBody = null;
      draftText = null;
      changed = true;
    }

    if (chat.pending) {
      if (!runningEl) {
        runningEl = el('div', 'agent-status agent-running');
        runningEl.setAttribute('role', 'status');
        var line = el('p', 'agent-status-line');
        line.appendChild(el('span', 'agent-status-text', ''));
        line.appendChild(el('span', 'agent-elapsed', elapsedText((Date.now() - pendingSince) / 1000)));
        runningEl.appendChild(line);
        runningEl.appendChild(el('p', 'agent-status-note', 'Обычно от минуты до нескольких. Страницу можно закрыть — ответ сохранится в этом чате.'));
        log.appendChild(runningEl);
        changed = true;
      }
      var statusText = runningEl.querySelector('.agent-status-text');
      if (statusText.textContent !== stage) {
        statusText.textContent = stage;
        changed = true;
      }
    } else if (runningEl) {
      log.removeChild(runningEl);
      runningEl = null;
      changed = true;
    }
    return changed;
  }

  function tick() {
    var span = log.querySelector('.agent-elapsed');
    if (span) span.textContent = elapsedText((Date.now() - pendingSince) / 1000);
  }

  function addToList() {
    if (!list || list.querySelector('[data-chat="' + chat.id + '"]')) return;
    Array.prototype.forEach.call(list.querySelectorAll('.agent-chat.current'), function (item) {
      item.classList.remove('current');
      var a = item.querySelector('[aria-current]');
      if (a) a.removeAttribute('aria-current');
    });
    var li = el('li', 'agent-chat current');
    li.setAttribute('data-chat', chat.id);
    var a = el('a', 'agent-chat-link');
    a.href = 'agent.php?chat=' + encodeURIComponent(chat.id);
    a.setAttribute('aria-current', 'page');
    a.appendChild(el('span', 'agent-chat-title', chat.title));
    a.appendChild(el('span', 'agent-chat-meta', 'только что'));
    li.appendChild(a);
    list.insertBefore(li, list.firstChild);
    if (sideCount) sideCount.textContent = String(list.children.length);
    if (sideToggle) sideToggle.hidden = false;
  }

  function apply(newChat) {
    var wasPending = chat && chat.pending;
    chat = newChat;
    if (chat.pending) pendingSince = Date.now() - chat.pending.elapsed * 1000;
    if (location.search.indexOf('chat=' + chat.id) === -1 && window.history.replaceState) {
      history.replaceState(null, '', 'agent.php?chat=' + encodeURIComponent(chat.id));
    }
    titleEl.textContent = chat.title;
    addToList();
    var changed = render();

    if (chat.pending) {
      sendBtn.setAttribute('aria-busy', 'true');
      if (!pollTimer) pollTimer = setInterval(poll, POLL_MS);
      if (!tickTimer) tickTimer = setInterval(tick, 1000);
    } else {
      sendBtn.removeAttribute('aria-busy');
      clearInterval(pollTimer);
      clearInterval(tickTimer);
      pollTimer = tickTimer = null;
    }
    // Пришёл ответ — показываем его начало, а не конец.
    if (changed && wasPending && !chat.pending && log.lastElementChild) {
      log.lastElementChild.scrollIntoView({block: 'start', behavior: 'smooth'});
    }
  }

  function parseJson(body) {
    try {
      return JSON.parse(body);
    } catch (e) {
      // Вместо JSON пришла страница входа — сессия закончилась.
      return {ok: false, fatal: true, error: 'Сессия закончилась — обновите страницу и войдите заново.'};
    }
  }

  function showUpload(loaded, total) {
    uploadBox.hidden = false;
    uploadBox.textContent = loaded >= total
      ? 'Файлы загружены, ставлю вопрос в очередь…'
      : 'Загружаю файлы на сайт: ' + Math.floor(loaded * 100 / total) + '% (' + sizeText(loaded) + ' из ' + sizeText(total) + ')';
  }

  function request(fields, chunk, progress) {
    var data = new FormData();
    data.append('csrf', state.csrf);
    Object.keys(fields).forEach(function (k) { data.append(k, fields[k]); });
    if (chunk) data.append('chunk', chunk, 'chunk');

    return new Promise(function (resolve) {
      var xhr = new XMLHttpRequest();
      xhr.open('POST', 'agent_api.php');
      if (progress) {
        xhr.upload.addEventListener('progress', function (e) {
          if (e.lengthComputable) progress(e.loaded / e.total);
        });
      }
      xhr.onload = function () {
        var answer;
        if (xhr.status === 413 && !xhr.responseText.trim().startsWith('{')) {
          answer = {ok: false, error: 'Сервер отклонил загрузку из-за размера запроса.'};
        } else {
          answer = parseJson(xhr.responseText);
        }
        answer.status = xhr.status;
        resolve(answer);
      };
      xhr.onerror = xhr.onabort = function () {
        resolve({ok: false, error: 'Нет связи с сайтом — проверьте сеть и повторите.'});
      };
      xhr.send(data);
    });
  }

  async function uploadFiles(fields, attachments) {
    if (uploadDraft && (uploadDraft.files.length !== attachments.length ||
        uploadDraft.files.some(function (file, index) { return file !== attachments[index]; }))) {
      await request({action: 'upload_discard', batch: uploadDraft.id});
      uploadDraft = null;
    }
    if (!attachments.length) return request(fields);

    if (!uploadDraft) {
      var random = window.crypto.getRandomValues(new Uint8Array(16));
      uploadDraft = {
        id: Array.from(random, function (byte) { return byte.toString(16).padStart(2, '0'); }).join(''),
        files: attachments.slice(),
        offsets: attachments.map(function () { return 0; }),
        chunkBytes: state.chunkBytes || 16 * 1024 * 1024
      };
    }
    var total = attachments.reduce(function (sum, file) { return sum + file.size; }, 0);
    var loaded = uploadDraft.offsets.reduce(function (sum, offset) { return sum + offset; }, 0);
    showUpload(loaded, total);
    for (var index = 0; index < attachments.length; index++) {
      var file = attachments[index];
      while (uploadDraft.offsets[index] < file.size) {
        var offset = uploadDraft.offsets[index];
        var end = Math.min(file.size, offset + uploadDraft.chunkBytes);
        var chunk = file.slice(offset, end);
        var result = await request({action: 'upload_chunk', batch: uploadDraft.id, index: index, offset: offset},
          chunk, function (fraction) {
            showUpload(loaded + Math.floor(fraction * chunk.size), total);
          });
        if (!result.ok) {
          // У прокси может быть более низкий предел, чем у PHP.
          if (result.status === 413 && uploadDraft.chunkBytes > 256 * 1024) {
            uploadDraft.chunkBytes = Math.floor(uploadDraft.chunkBytes / 2);
            continue;
          }
          if (result.status === 409) uploadDraft.offsets.fill(0);
          return result;
        }
        uploadDraft.offsets[index] = end;
        loaded += chunk.size;
      }
    }
    showUpload(total, total);
    fields.batch = uploadDraft.id;
    fields.attachments = JSON.stringify(attachments.map(function (file) {
      return {name: file.name, size: file.size};
    }));
    var answer = await request(fields);
    if (answer.ok) uploadDraft = null;
    else if (answer.status === 422) uploadDraft.offsets.fill(0);
    return answer;
  }

  async function post(fields, attachFiles) {
    requestInFlight = true;
    showFormError('');
    try {
      var answer = attachFiles ? await uploadFiles(fields, attachFiles) : await request(fields);
      if (!answer.ok) {
        showFormError(answer.error || 'Не удалось отправить вопрос.');
        return false;
      }
      apply(answer.chat);
      var running = log.querySelector('.agent-running');
      if (running) running.scrollIntoView({block: 'nearest', behavior: 'smooth'});
      return true;
    } catch (error) {
      showFormError('Не удалось отправить вопрос. Повторите попытку.');
      return false;
    } finally {
      uploadBox.hidden = true;
      requestInFlight = false;
    }
  }

  function poll() {
    if (!chat) return;
    fetch('agent_api.php?action=poll&chat=' + encodeURIComponent(chat.id), {credentials: 'same-origin', cache: 'no-store'})
      .then(function (response) { return response.text(); })
      .then(function (body) {
        var data = parseJson(body);
        if (data.ok) {
          apply(data.chat);
        } else {
          clearInterval(pollTimer);
          clearInterval(tickTimer);
          pollTimer = tickTimer = null;
          sendBtn.removeAttribute('aria-busy');
          showFormError(data.error || 'Чат недоступен.');
        }
      })
      .catch(function () { /* сеть мигнула — следующий опрос повторит */ });
  }

  form.addEventListener('submit', function (e) {
    e.preventDefault();
    if (requestInFlight || sendBtn.disabled) return;
    if (chat && chat.pending) {
      showFormError('Дождитесь ответа на предыдущий вопрос.');
      return;
    }
    var text = input.value.trim();
    if (!text && !files.length) {
      showFormError('Напишите вопрос или прикрепите файл.');
      input.focus();
      return;
    }
    if (text.length > state.maxChars) {
      showFormError('Сообщение длиннее ' + state.maxChars + ' знаков — сократите его.');
      return;
    }
    var processing = heavyInput && heavyInput.checked ? 'vps' : '';
    if (processing && !files.length) {
      showFormError('Прикрепите файлы для обработки на VPS.');
      return;
    }
    sendBtn.setAttribute('aria-busy', 'true');
    post({action: 'send', chat: chat ? chat.id : '', text: text, processing: processing}, files).then(function (ok) {
      if (ok) {
        input.value = '';
        if (heavyInput) heavyInput.checked = false;
        autosize();
        files = [];
        renderPicked();
      } else if (!(chat && chat.pending)) {
        sendBtn.removeAttribute('aria-busy');
      }
    });
  });

  // Enter отправляет, Shift+Enter — новая строка. На телефоне Enter
  // остаётся переводом строки: там отправляют кнопкой.
  var coarse = window.matchMedia && window.matchMedia('(pointer: coarse)').matches;
  input.addEventListener('keydown', function (e) {
    if (e.key !== 'Enter' || e.shiftKey || e.isComposing || coarse) return;
    e.preventDefault();
    if (form.requestSubmit) form.requestSubmit(); else sendBtn.click();
  });

  // Поле растёт вместе с текстом — до трети экрана, дальше прокрутка.
  function autosize() {
    input.style.height = 'auto';
    var max = Math.max(120, Math.round(window.innerHeight * 0.33));
    input.style.height = Math.min(input.scrollHeight + 2, max) + 'px';
    input.style.overflowY = input.scrollHeight + 2 > max ? 'auto' : 'hidden';
  }
  input.addEventListener('input', autosize);

  // Поле ввода прикреплено к низу экрана: прокрутка к сообщению
  // оставляет под ним место ровно на высоту поля.
  if (window.ResizeObserver) {
    new ResizeObserver(function () {
      document.documentElement.style.setProperty('--agent-composer-h', form.offsetHeight + 'px');
    }).observe(form);
  }

  // Телефон: список чатов свёрнут в одну строку над перепиской. На
  // компьютере он всегда открыт слева (см. style.css), кнопки там нет.
  if (sideToggle && sideList) {
    var openSide = function (open) {
      sideToggle.setAttribute('aria-expanded', open ? 'true' : 'false');
      sideList.classList.toggle('open', open);
    };
    openSide(false);
    sideToggle.addEventListener('click', function () {
      openSide(sideToggle.getAttribute('aria-expanded') !== 'true');
    });
  }

  if (coarse) {
    var keys = document.querySelector('.agent-keys');
    if (keys) keys.hidden = true;
  }

  if (chat) {
    apply(chat);
    // Открыли чат — внизу последнее сообщение и поле ввода.
    if (chat.messages.length) window.scrollTo(0, document.documentElement.scrollHeight);
  } else {
    render();
  }
  autosize();

  // Вопрос, заданный на главной: подставляем и сразу отправляем.
  if (!chat && state.ask && !input.disabled) {
    input.value = state.ask;
    autosize();
    if (form.requestSubmit) form.requestSubmit(); else sendBtn.click();
  }
})();
