// Проверка РВ на странице результата (rv_status.php, состояние done).
// Строки формы и каталог работ приходят JSON-ом (?rows=1, их пишет агент:
// program-c/rv_form.py). Таблица повторяет форму ТКП: узлы ИСР, работы с
// объёмом, под ними строки ЛРВ с коэффициентом (объём работы на единицу
// материала), количеством и уверенностью агента. Работы свёрнуты, пока их
// не раскроют; строки одной работы с одинаковым наименованием показаны
// одной строкой с одним решением. Инженер исправляет работу
// (поиском или щелчком по строке работы в таблице) и коэффициент там, где
// агент ошибся; «Сохранить проверку» отправляет исправления в
// rv_feedback.php, остальные строки считаются подобранными верно.
// Нумерация иерархическая (1 / 1.1 / 1.1.1), как в смете. Строки, уже
// разнесённые в 1С, где агент не согласен (F-1C), — блёкло-красные с «в 1С
// было»; новые строки и работы (которых в 1С не было) помечены «новая».
(function () {
  'use strict';
  var card = document.getElementById('rv-check');
  if (!card) return;
  var body = card.querySelector('.rv-check-body');
  var token = card.getAttribute('data-token');
  var rowsUrl = card.getAttribute('data-rows-url');
  var feedbackUrl = card.getAttribute('data-feedback-url');
  var titleBase = card.getAttribute('data-title') || '';   // смета как в 1С без объекта: «система НГ / Аналитика 1» (rv_smeta_title)

  var rows = [], view = [], catalog = {}, roles = ['В', 'С-В', 'С-С', 'Р', 'Кр'], legend = {};
  var fixes = {};          // id строки ЛРВ → {code, name, role, coef}
  var collapsed = {};      // индекс строки view (узел или работа) → свёрнута
  var openGroups = {};     // индекс строки view (группа одинаковых) → раскрыта
  var filter = { q: '', only: false, unbound: false, conf: 101 };
  var ancestors = [];      // индекс view → индексы узлов, работы и заголовка над строкой
  var stats = { mats: 0, review: 0, unbound: 0, onec: 0, reduced: 0 };
  var moving = null;       // «указать работу в таблице»: цель переноса {row, index, ids}, пока не выбрали работу
  var workNotes = {};      // код работы → примечание сметчика (пустое — убрать своё); уходит в 1С полем «Примечание»
  var refreshAcceptModel = function () {};   // кнопка «Принять предложения модели» — счётчик (build)
  var addedWorks = {};     // код ИСР → объём: работа без материалов, добавленная сметчиком, или объём вручную у работы агента; 0 — убрать
  var splits = {};         // id строки ЛРВ → [{code, qty}]: строка на несколько работ (пустой список — убрать разбиение)

  function h(text) {
    return String(text == null ? '' : text).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function num(value, digits) {
    if (value == null || value === '') return '';
    var n = Number(value);
    if (isNaN(n)) return h(value);
    var s = n.toFixed(digits == null ? 3 : digits).replace(/\.?0+$/, '');
    return s.replace(/\B(?=(\d{3})+(?!\d))/g, ' ');
  }
  function confClass(conf) { return conf >= 80 ? 'is-high' : (conf >= 60 ? 'is-mid' : 'is-low'); }
  function roleTitle(role) { return (legend.roles && legend.roles[role]) ? role + ' — ' + legend.roles[role] : role; }
  // Роль строки словом: как материал участвует в работе (коды В, С-В… — в подсказке и в книге Excel).
  var ROLE_WORD = { 'В': 'ведущий', 'С-В': 'к ведущему', 'С-С': 'своя работа', 'Р': 'расходник', 'Кр': 'крепёж', '?': '—' };
  function roleWord(role) { return ROLE_WORD[role] || role || '—'; }

  // Одинаковые строки: то же наименование (без учёта регистра, «ё» и лишних пробелов). Строки, которые
  // отличаются хоть чем-то — длиной, размером, номером фланца, — не объединяются: у них свой коэффициент.
  function sameNameKey(name) {
    return String(name || '').toLowerCase().replace(/ё/g, 'е').replace(/\s+/g, ' ').trim();
  }

  var GROUP_SAME = false;   // одинаковые строки одной работы одной строкой — выключено: сметчику важнее видеть каждую строку ЛРВ
  var singleTitle = false;  // один блок (раздел · элемент): заголовок без номера, нумерация строк начинается с узлов ИСР

  // Строки формы → строки таблицы: одинаковые материалы одной работы с одной ролью — одной группой (GROUP_SAME).
  function buildView() {
    view = [];
    var i = 0;
    while (i < rows.length) {
      var row = rows[i];
      if (row.t !== 'mat' || !GROUP_SAME) { view.push(row); i++; continue; }
      var block = [];
      while (i < rows.length && rows[i].t === 'mat') { block.push(rows[i]); i++; }
      var groups = {}, order = [];
      block.forEach(function (mat) {
        // строка с уменьшением по ЛРВ в группу одинаковых не уходит — её должно быть видно
        var key = (mat.nosec ? 'nosec' : (mat.code || '')) + '|' + (mat.role || '') + '|' + sameNameKey(mat.name) + (mat.reduce ? '|reduce' + mat.id : '');
        if (!groups[key]) { groups[key] = []; order.push(key); }
        groups[key].push(mat);
      });
      order.forEach(function (key) {
        var members = groups[key];
        if (members.length === 1) { view.push(members[0]); return; }
        var sameUnit = members.every(function (m) { return m.unit === members[0].unit; });
        var qty = sameUnit ? members.reduce(function (s, m) { return s + (Number(m.qty) || 0); }, 0) : null;
        var coefs = {};
        members.forEach(function (m) { coefs[String(m.coef == null ? 0 : m.coef)] = true; });
        view.push({
          t: 'grp', lvl: members[0].lvl, members: members, id: members[0].id,
          name: members[0].name, unit: sameUnit ? members[0].unit : '', qty: qty,
          coef: Object.keys(coefs).length === 1 ? members[0].coef : null,
          conf: Math.min.apply(null, members.map(function (m) { return m.conf; })),
          role: members[0].role, review: members.some(function (m) { return m.review; }),
          code: members[0].code, section: members[0].section, sysc: members[0].sysc, nosec: members[0].nosec,
          learned: members.every(function (m) { return m.learned === 'correction'; }) ? 'correction' : '',
          why: members[0].why, flags: members[0].flags, fcodes: members[0].fcodes, src: members[0].src,
          rec: members.map(function (m) { return m.rec; }).filter(Boolean)[0] || null,
          onec_code: members[0].onec_code || '', onec_text: members[0].onec_text || '', onec_works: members[0].onec_works || [],
          onec_coef: members.every(function (m) { return m.onec_coef === members[0].onec_coef; }) ? members[0].onec_coef : null,
          coef_agent: members.every(function (m) { return m.coef_agent === members[0].coef_agent; }) ? members[0].coef_agent : null,
          agent_code: members[0].agent_code || '', agent_work: members[0].agent_work || '',
          alts: members[0].alts || [], split_of: null
        });
      });
    }
  }

  // Иерархический номер строки: заголовок 1, узлы 1.1, 1.1.1 …, работа и материалы — следующие уровни.
  var counters = {};
  function numberOf(index, parentIndex) {
    var key = parentIndex == null ? 'root' : String(parentIndex);
    counters[key] = (counters[key] || 0) + 1;
    return (parentIndex == null ? '' : view[parentIndex].num + '.') + counters[key];
  }

  function prepare() {
    buildView();
    ancestors = new Array(view.length);
    counters = {};
    var stack = [];     // [{lvl, index}] открытые узлы; заголовок — уровень 0; работа — уровень 99
    stats = { mats: 0, review: 0, unbound: 0, onec: 0, reduced: 0 };
    view.forEach(function (row, index) {
      if (row.t === 'title' || row.t === 'total') {
        stack = row.t === 'title' ? [{ lvl: 0, index: index }] : [];
        ancestors[index] = [];
        if (row.t === 'title') row.num = numberOf(index, null);
        return;
      }
      if (row.t === 'node') {
        while (stack.length && stack[stack.length - 1].lvl >= row.lvl) stack.pop();
        ancestors[index] = stack.map(function (s) { return s.index; });
        row.num = numberOf(index, stack.length ? stack[stack.length - 1].index : null);
        stack.push({ lvl: row.lvl, index: index });
        row.count = 0;
        row.onecCount = 0;
        return;
      }
      if (row.t === 'work') {
        while (stack.length && stack[stack.length - 1].lvl >= 99) stack.pop();
        ancestors[index] = stack.map(function (s) { return s.index; });
        row.num = numberOf(index, stack.length ? stack[stack.length - 1].index : null);
        stack.push({ lvl: 99, index: index });
        row.count = 0;
        row.onecCount = 0;
        // работы раскрыты сразу; сметчик сворачивает сам («Свернуть всё», «Работы»)
        return;
      }
      ancestors[index] = stack.map(function (s) { return s.index; });
      row.num = numberOf(index, stack.length ? stack[stack.length - 1].index : null);
      var members = row.t === 'grp' ? row.members : [row];
      var onecHere = 0;
      members.forEach(function (mat) {
        stats.mats++;
        if (mat.nosec || !mat.code) stats.unbound++;
        else if (mat.review) stats.review++;
        if (mat.onec_code) { stats.onec++; onecHere++; }
        if (mat.reduce) stats.reduced++;
      });
      ancestors[index].forEach(function (a) {
        if (view[a].count !== undefined) view[a].count += members.length;
        if (view[a].onecCount !== undefined) view[a].onecCount += onecHere;
      });
    });
    singleTitle = view.filter(function (r) { return r.t === 'title'; }).length === 1;
    if (singleTitle) view.forEach(function (r) { if (r.t !== 'title' && r.num) r.num = r.num.replace(/^1\./, ''); });
  }
  // Корректировка РВ: в 1С уже что-то разнесено — строки и работы, которых там не было, помечаем «новая».
  function isCorrection() { return stats.onec > 0; }

  function matMatches(row) {
    var members = row.t === 'grp' ? row.members : [row];
    return members.some(function (mat) {
      if (filter.only && !(mat.review || !mat.code || mat.nosec)) return false;
      if (filter.unbound && !(!mat.code || mat.nosec)) return false;
      if (filter.conf <= 100 && !(mat.conf < filter.conf || !mat.code)) return false;
      if (filter.q) {
        var hay = (mat.name + ' ' + (mat.code || '') + ' ' + mat.id + ' ' + (row.num || '')).toLowerCase();
        var ok = filter.q.split(/\s+/).every(function (word) { return !word || hay.indexOf(word) >= 0; });
        if (!ok) return false;
      }
      return true;
    });
  }

  function filterActive() { return !!(filter.q || filter.only || filter.unbound || filter.conf <= 100); }

  function visibleSet() {
    var show = new Array(view.length);
    if (moving) {
      // перенос: видны все узлы и работы (куда переносить) и сама переносимая строка
      view.forEach(function (row, index) { show[index] = (row.t !== 'mat' && row.t !== 'grp') || index === moving.index; });
      return show;
    }
    if (!filterActive()) {
      view.forEach(function (row, index) {
        show[index] = !ancestors[index].some(function (a) { return collapsed[a]; });
      });
      return show;
    }
    view.forEach(function (row, index) {
      if ((row.t === 'mat' || row.t === 'grp') && matMatches(row)) {
        show[index] = true;
        ancestors[index].forEach(function (a) { show[a] = true; });
      }
    });
    return show;
  }

  // Заголовок блока: смета, как её называют в 1С, без объекта — «Электромонтажные работы / Электромонтажные работы
  // в нежилой части / Основные работы»; у служебных блоков («Строки без работы») — их имя.
  function titleText(row) {
    if (!titleBase || !row.short) return row.short || row.name;
    var parts = String(row.short).split(' · ');
    return titleBase + ' / ' + parts[parts.length - 1];
  }

  // Пометки агента словами (коды F-… остаются в книге Excel и в подсказке); подсказка — что именно и какую работу
  // программа предлагает: по строке (agent_code, onec_code), иначе текст пометки агента.
  var FLAG_LABEL = {
    'F-1C': 'не как в 1С', 'F-SMETA': 'нет в смете', 'F-ALT': 'есть варианты', 'F-SYS': 'другая система',
    'F-DN': 'по диаметру', 'F-MAT': 'материал ≠ работа', 'F-KR': 'крепёж', 'F-VOL': 'объём не определён', 'F-NORM': 'не по норме',
    'F-LOCAL': 'по указаниям', 'F-KC': 'работа из 1С, нет у агента',
    'F-RVR': 'код 12: проверить работу'
  };
  // Служебные пометки (состояние справочника КЦ, замена кода, нет контекста, единица по типу) сметчику не нужны:
  // остаются в книге Excel и в «Как агент разбирал ЛРВ».
  // «Нет в смете» (F-SMETA) тоже: работа не из сметы просто добавится в 1С новой позицией.
  var HIDDEN_FLAGS = { 'F-GRP': 1, 'F-DEPR': 1, 'F-CTX': 1, 'F-UNIT': 1, 'F-SMETA': 1 };
  function flagNote(row, code) {
    var text = (row.flags || []).filter(function (f) { return String(f).indexOf(code + ':') === 0; })[0];
    return text ? String(text).slice(code.length + 1).trim() : '';
  }
  function workLabel(code, work) { return code + (work ? ' — ' + work : ''); }
  // Работа 1С без кода впереди: onec_text — «код — работа (кол-во)[; …]» (rv_audit.text_1c).
  function onecName(row) {
    return String(row.onec_text || '').replace(/^\S+\s+—\s+/, '');
  }
  // Короткое имя работы в строке: до « / » (вариант по толщине, способу прокладки — в подсказке).
  function shortWork(work) {
    var short = String(work || '').split(' / ')[0];
    return short.length > 70 ? short.slice(0, 68) + '…' : short;
  }
  function workChip(code, work) {
    return '<code title="' + h(work || '') + '">' + h(code) + '</code> ' + h(shortWork(work));
  }
  function flagTitle(row, code, i) {
    var generic = (row.why || [])[i] || '';
    if (code === 'F-1C' && row.agent_code) {
      return 'Программа предлагает исправить работу на ' + workLabel(row.agent_code, row.agent_work) + '. ' +
        'В 1С разнесено на ' + workLabel(row.onec_code, onecName(row)) + '. ' +
        'Оставить как в 1С — ничего не делать; принять — «принять агента» или «Исправить».';
    }
    var note = flagNote(row, code);
    return note ? note + (generic ? '\n' + generic : '') : (generic || code);
  }

  // ── Отрисовка ──
  function nameCell(row, inner) {
    return '<div class="rv-f-name" style="padding-left:' + (20 + Math.min(row.lvl, 6) * 10) + 'px">' + inner + '</div>';
  }
  function rowHtml(row, index) {
    if (row.t === 'title') {
      return '<tr class="rv-f-title" data-i="' + index + '"><td class="rv-f-no">' + (singleTitle ? '' : h(row.num)) + '</td><td colspan="7">' + h(titleText(row)) + '</td></tr>';
    }
    if (row.t === 'total') return '';
    if (row.t === 'node' || row.t === 'work') {
      var caret = collapsed[index] ? '▸' : '▾';
      var toggle = '<button type="button" class="rv-toggle" data-toggle="' + index + '" aria-label="Свернуть или развернуть">' + caret + '</button>';
      if (row.t === 'node') {
        return '<tr class="rv-f-node' + (row.lvl >= 5 ? ' rv-lvl-deep' : '') + '" data-i="' + index + '">' +
          '<td class="rv-f-no">' + h(row.num) + '</td><td colspan="7">' + nameCell(row, toggle + '<code>' + h(row.code) + '</code><span>' + h(row.name) + (row.count ? ' <span class="muted-dash">· ' + row.count + '</span>' : '') + '</span>') + '</td></tr>';
      }
      var pendingQty = Object.prototype.hasOwnProperty.call(addedWorks, row.code) ? addedWorks[row.code] : null;
      var qty = pendingQty != null
        ? (pendingQty ? '<span class="rv-f-qty-new" title="объём вручную; было ' + h(row.qty == null ? '0' : num(row.qty)) + '">' + num(pendingQty) + '</span>'
                      : '<s class="muted-dash" title="работа будет убрана">' + (row.qty == null ? '0' : num(row.qty)) + '</s>')
        : '<span title="' + h(row.method || '') + '">' + (row.qty == null ? '0' : num(row.qty)) + '</span>';
      var tags = '';
      if (row.auto) tags += ' <span class="rv-f-tag is-auto" title="' + h(row.note || '') + '">добавлено агентом</span>';
      if (row.manual) tags += ' <span class="rv-f-tag is-new" title="' + h(row.note || '') + '">добавлено сметчиком</span>';
      // объём вручную — у работ без строк ЛРВ (добавленных агентом или сметчиком)
      var qtyEdit = (row.manual || row.auto) && !row.nmat
        ? ' <button type="button" class="rv-link" data-work-qty="' + h(row.code) + '">объём</button>' +
          (row.manual ? ' <button type="button" class="rv-link" data-work-del="' + h(row.code) + '">убрать</button>' : '')
        : '';
      var pick = moving ? ' is-pickable' : '';
      var remark = remarkOf(row);
      var remarkHtml = remark.text
        ? '<span class="rv-f-remark" title="примечание к работе' + (remark.by ? ' — ' + h(remark.by) : '') + '">' + h(remark.text) + '</span> <button type="button" class="rv-link" data-remark="' + h(row.code) + '">изменить</button>'
        : '<button type="button" class="rv-link rv-remark-add" data-remark="' + h(row.code) + '">примечание</button>';
      var isNewWork = (isCorrection() && row.count && !row.onecCount && !row.auto) || row.manual || pendingQty != null;
      return '<tr class="rv-f-work' + (row.auto ? ' is-auto' : '') + (isNewWork ? ' is-new' : '') + pick + '" data-i="' + index + '" data-work="' + h(row.code) + '" title="' + (moving ? 'Перенести сюда' : '') + '">' +
        '<td class="rv-f-no">' + h(row.num) + '</td><td>' + nameCell(row, (row.count ? toggle : '') + '<code>' + h(row.code) + '</code><span><b>' + h(row.name) + '</b>' + tags + (row.count ? ' <span class="muted-dash">· строк ' + row.count + '</span>' : '') + '</span>') + '</td>' +
        '<td>' + h(row.unit) + '</td><td class="rv-f-num">1</td><td class="rv-f-num">' + qty + '</td><td class="rv-f-num"></td>' +
        '<td colspan="2" class="rv-f-method">' + ((row.auto || row.manual) && row.note ? '<span class="muted-dash">' + h(row.note) + '</span> ' : '') + remarkHtml + qtyEdit + '</td></tr>';
    }
    // материал или группа одинаковых
    var members = row.t === 'grp' ? row.members : [row];
    var fix = fixOf(row);
    var dispute = isDispute(row);
    var split = row.t !== 'grp' && splits[row.id] && splits[row.id].length > 1;
    var coefNow = fix && fix.coef != null ? fix.coef : row.coef;
    var coefDiff = agentCoef(row, fix) != null ||
      (row.onec_coef != null && Number(row.onec_coef) && Math.abs(Number(row.onec_coef) - (Number(coefNow) || 0)) > 1e-9);
    var cls = (row.t === 'grp' ? 'rv-f-grp' : 'rv-f-mat') + (row.nosec || !row.code ? ' is-question' : (row.review ? ' is-review' : '')) + (coefDiff ? ' is-coef-diff' : '') +
      (fix || split ? ' is-fixed' : '') + (row.learned === 'correction' ? ' is-learned' : '') + (dispute && !fix && !split ? ' is-dispute' : '') +
      ((isCorrection() && !row.onec_code && !fix) || row.reduce ? ' is-new' : '');
    var name = h(row.name);
    if (row.reduce) {
      // ЛРВ уменьшилась: под работой остаётся меньше, чем разнесено в 1С — изменение уйдёт в 1С минусом
      name += ' <span class="rv-f-tag is-new" title="ЛРВ уменьшилась: в 1С под этой работой ' + num(row.reduce.before) + ' ' + h(row.unit) +
        ', остаётся ' + num(row.qty) + ' — в 1С уйдёт −' + num(row.reduce.qty) + '">уменьшение −' + num(row.reduce.qty) + ' · было ' + num(row.reduce.before) + '</span>';
    }
    if (row.t === 'grp') {
      var variants = members.map(function (m) { return m.name; }).filter(function (n, i, a) { return a.indexOf(n) === i; });
      name += ' <button type="button" class="rv-link rv-grp-toggle" data-grp="' + index + '">' +
        (openGroups[index] ? 'свернуть' : 'одинаковых строк: ' + members.length) + '</button>' +
        (openGroups[index] ? '' : ' <span class="muted-dash rv-grp-hint" title="' + h(variants.join('\n')) + '">одно решение на все</span>');
    }
    if (row.split_of != null) name += ' <span class="rv-f-tag is-onec" title="строка ЛРВ разнесена на ' + h(row.split_n) + ' работ' + (row.split_by ? ' — ' + h(row.split_by) : '') + '; всего ' + num(row.split_total) + ' ' + h(row.unit) + '">часть ' + h((row.split_k || 0) + 1) + '/' + h(row.split_n) + '</span>';
    if (row.onec_works && row.onec_works.length > 1) {
      name += ' <span class="rv-f-tag is-onec" title="' + h(row.onec_works.map(function (w) { return w.code + ' — ' + w.name + (w.qty != null ? ' (' + num(w.qty) + ')' : ''); }).join('\n')) + '">в 1С на ' + row.onec_works.length + ' работ' + (row.onec_works.length < 5 ? 'ы' : '') + '</span>';
    }
    var qtyText = row.t === 'grp'
      ? (row.qty == null ? '<span class="muted-dash" title="у строк разные единицы">разн.</span>' : num(row.qty))
      : (row.part ? '<span title="часть строки: всего ' + num(row.qty_total) + ' ' + h(row.unit) + '">' + num(row.qty) + '</span>' : num(row.qty));
    var coefText = coefCell(row, fix, index);
    var conf = row.nosec || !row.code ? '<span class="rv-conf is-low">0%</span>'
      : '<span class="rv-conf ' + confClass(row.conf) + '" title="' + h(row.src || '') + '">' + row.conf + '%</span>';
    var out = '<tr class="' + cls + '" data-i="' + index + '" data-id="' + row.id + '"' + (row.reduce ? ' title="ЛРВ уменьшилась: количество под работой меньше, чем разнесено в 1С"' : (isCorrection() && !row.onec_code ? ' title="В 1С этой строки не было — новая"' : '')) + '>' +
      '<td class="rv-f-no">' + h(row.num) + '</td>' +
      '<td>' + nameCell(row, '<span>' + name + '</span>') + '</td>' +
      '<td>' + h(row.unit) + '</td><td class="rv-f-num rv-f-coef">' + coefText + '</td><td class="rv-f-num">' + qtyText + '</td>' +
      '<td class="rv-f-num rv-f-qty2">' + (row.qty2 == null ? '' : num(row.qty2)) + '</td>' +
      '<td>' + conf + '</td>' +
      '<td class="rv-f-check">' + checkHtml(row, fix, index) + '</td></tr>';
    if (row.t === 'grp' && openGroups[index]) {
      members.forEach(function (mat, k) {
        var mfix = fixes[mat.id];
        out += '<tr class="rv-f-mat rv-f-member' + (mfix ? ' is-fixed' : '') + '" data-i="' + index + '" data-id="' + mat.id + '">' +
          '<td class="rv-f-no">' + h(row.num + '.' + (k + 1)) + '</td><td>' + nameCell(row, '<span class="muted-dash">↳</span> ' + h(mat.name)) + '</td>' +
          '<td>' + h(mat.unit) + '</td><td class="rv-f-num rv-f-coef">' + coefCell(mat, mfix, null) + '</td>' +
          '<td class="rv-f-num">' + (mat.part ? '<span title="часть строки: всего ' + num(mat.qty_total) + '">' + num(mat.qty) + '</span>' : num(mat.qty)) + '</td>' +
          '<td class="rv-f-num rv-f-qty2">' + (mat.qty2 == null ? '' : num(mat.qty2)) + '</td>' +
          '<td><span class="rv-conf ' + confClass(mat.conf) + '">' + mat.conf + '%</span></td>' +
          '<td class="rv-f-check">' + (mfix ? '<span class="rv-fix-done">' + fixSummary(mfix, mat) + '</span> <button type="button" class="rv-link" data-fix="' + mat.id + '">изменить</button>' : '<button type="button" class="rv-link" data-fix="' + mat.id + '">исправить отдельно</button>') + '</td></tr>';
      });
    }
    return out;
  }

  // Примечание к работе: правка сметчика на этой странице, иначе из результата (1С или прежняя проверка).
  function remarkOf(row) {
    if (Object.prototype.hasOwnProperty.call(workNotes, row.code)) {
      return { text: workNotes[row.code], by: workNotes[row.code] ? 'вы' : '' };
    }
    return { text: row.remark || '', by: row.remark_by || '' };
  }
  function editRemark(tr, code) {
    var index = Number(tr.getAttribute('data-i'));
    var row = view[index];
    var cell = tr.querySelector('.rv-f-method');
    var current = remarkOf(row).text;
    cell.innerHTML = '<input type="text" class="rv-remark-input" maxlength="500" value="' + h(current) + '" placeholder="примечание к работе — уйдёт в 1С" aria-label="Примечание к работе">';
    var input = cell.querySelector('input');
    var done = false;
    function finish(save) {
      if (done) return;
      done = true;
      if (save) {
        var text = input.value.trim();
        if (text !== (row.remark || '') || Object.prototype.hasOwnProperty.call(workNotes, code)) workNotes[code] = text;
        if (text === (row.remark || '')) delete workNotes[code];
        updateBar();
      }
      rerow(tr, index);
    }
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); finish(true); }
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); finish(false); }
    });
    input.addEventListener('blur', function () { finish(true); });
    input.focus();
  }

  // Разбиение строки на работы: подпись «60 → код; 40 → код».
  function splitSummary(parts, row) {
    return 'разбить: ' + parts.map(function (p) { return num(p.qty) + ' ' + h(row.unit || '') + ' → <code>' + h(p.code) + '</code>'; }).join('; ');
  }

  // Редактор разбиения: строки «работа — количество», сумма = количеству строки ЛРВ.
  function openSplit(tr, target) {
    var row = target.row;
    var cell = tr.querySelector('.rv-f-check');
    var total = Number(row.qty) || 0;
    var current = (splits[row.id] && splits[row.id].length > 1) ? splits[row.id].map(function (p) { return { code: p.code, qty: p.qty }; })
      : [{ code: row.code || '', qty: total }, { code: '', qty: 0 }];
    function lineHtml(p, k) {
      return '<div class="rv-split-line" data-k="' + k + '">' +
        '<input type="text" class="rv-split-code" value="' + h(p.code) + '" placeholder="код или слова из названия работы" autocomplete="off">' +
        '<span class="rv-split-name muted-dash">' + h(p.code ? (workNameOf(p.code) || '') : '') + '</span>' +
        '<input type="text" class="rv-split-qty" inputmode="decimal" value="' + h(p.qty ? num(p.qty, 4) : '') + '" aria-label="Количество">' +
        '<button type="button" class="rv-link rv-split-del" aria-label="Убрать">✕</button>' +
        '<div class="rv-pick-list rv-split-list" hidden></div></div>';
    }
    cell.innerHTML = '<div class="rv-picker rv-split">' +
      '<div class="rv-split-head">Разбить «' + h(row.name) + '» — всего ' + num(total) + ' ' + h(row.unit || '') + '</div>' +
      '<div class="rv-split-lines">' + current.map(lineHtml).join('') + '</div>' +
      '<div class="rv-pick-row"><button type="button" class="rv-mini rv-split-add">+ работа</button>' +
      '<span class="muted-dash rv-split-sum"></span>' +
      '<button type="button" class="rv-mini rv-split-apply">Применить</button><button type="button" class="rv-mini rv-pick-cancel">✕</button></div></div>';
    var box = cell.querySelector('.rv-split');
    function lines() { return Array.prototype.slice.call(box.querySelectorAll('.rv-split-line')); }
    function readParts() {
      return lines().map(function (line) {
        var qty = Number(line.querySelector('.rv-split-qty').value.replace(',', '.').replace(/\s/g, ''));
        return { code: line.querySelector('.rv-split-code').value.trim(), qty: isNaN(qty) ? 0 : qty };
      });
    }
    function sumText() {
      var parts = readParts();
      var sum = parts.reduce(function (acc, p) { return acc + (p.qty > 0 ? p.qty : 0); }, 0);
      var left = Math.round((total - sum) * 10000) / 10000;
      box.querySelector('.rv-split-sum').textContent = left === 0 ? 'сумма сходится' : (left > 0 ? 'не распределено ' + num(left) : 'больше строки на ' + num(-left));
    }
    function bindLine(line) {
      var codeInput = line.querySelector('.rv-split-code');
      var list = line.querySelector('.rv-split-list');
      var nameSpan = line.querySelector('.rv-split-name');
      function refresh() {
        var found = search(row.section, row.sysc, codeInput.value);
        list.hidden = !codeInput.value;
        list.innerHTML = found.map(function (e) {
          return '<button type="button" class="rv-pick-item" data-code="' + h(e[0]) + '"><code>' + h(e[0]) + '</code> ' + h(e[1]) + '</button>';
        }).join('');
      }
      function choose(code) {
        codeInput.value = code;
        nameSpan.textContent = workNameOf(code) || '';
        list.hidden = true;
      }
      codeInput.addEventListener('input', function () { nameSpan.textContent = workNameOf(codeInput.value.trim()) || ''; refresh(); });
      codeInput.addEventListener('focus', function () { if (!workNameOf(codeInput.value.trim())) refresh(); });
      codeInput.addEventListener('blur', function () { setTimeout(function () { list.hidden = true; }, 200); });
      codeInput.addEventListener('keydown', function (e) {
        if (e.key === 'Enter') {
          e.preventDefault();
          var first = list.querySelector('.rv-pick-item');
          if (first && list.hidden === false) choose(first.getAttribute('data-code'));
        }
        if (e.key === 'Escape') { e.stopPropagation(); list.hidden = true; }
      });
      list.addEventListener('mousedown', function (e) {
        var item = e.target.closest('.rv-pick-item');
        if (!item) return;
        e.preventDefault();
        choose(item.getAttribute('data-code'));
      });
      line.querySelector('.rv-split-qty').addEventListener('input', sumText);
      line.querySelector('.rv-split-del').addEventListener('click', function () {
        if (lines().length > 1) { line.parentNode.removeChild(line); sumText(); }
      });
    }
    lines().forEach(bindLine);
    sumText();
    box.querySelector('.rv-split-add').addEventListener('click', function () {
      var wrap = box.querySelector('.rv-split-lines');
      var parts = readParts();
      var left = Math.max(0, total - parts.reduce(function (acc, p) { return acc + (p.qty > 0 ? p.qty : 0); }, 0));
      wrap.insertAdjacentHTML('beforeend', lineHtml({ code: '', qty: left }, lines().length));
      bindLine(wrap.lastElementChild);
      wrap.lastElementChild.querySelector('.rv-split-code').focus();
      sumText();
    });
    box.querySelector('.rv-split-apply').addEventListener('click', function () {
      var parts = readParts().filter(function (p) { return p.code && p.qty > 0; });
      var known = parts.every(function (p) { return !!workNameOf(p.code); });
      if (parts.length < 2 || !known) { box.querySelector('.rv-split-sum').textContent = parts.length < 2 ? 'нужно хотя бы две работы с количеством' : 'неизвестный код работы'; return; }
      splits[row.id] = parts;
      delete fixes[row.id];
      rerow(tr, target.index);
      updateBar();
    });
    box.querySelector('.rv-pick-cancel').addEventListener('click', function () { rerow(tr, target.index); });
    box.querySelector('.rv-split-code').focus();
  }

  // Строка разнесена в 1С, а агент считает, что неверно (F-1C): показываем «в 1С было» и предложение агента.
  function isDispute(row) {
    return !!(row.onec_code && (row.fcodes || []).indexOf('F-1C') >= 0 && row.agent_code && row.agent_code !== row.onec_code);
  }

  // Решение по строке или группе: у группы — общее, если у всех членов одно и то же.
  function fixOf(row) {
    if (row.t !== 'grp') return fixes[row.id];
    var first = fixes[row.members[0].id];
    if (!first) return null;
    var same = row.members.every(function (m) {
      var f = fixes[m.id];
      return f && f.code === first.code && f.role === first.role && f.coef === first.coef;
    });
    return same ? first : null;
  }

  // Коэффициент — кнопка: щелчок открывает поле ввода прямо в ячейке (у группы с разными коэффициентами — по строкам).
  function coefCell(row, fix, groupIndex) {
    if (row.nosec || !row.code) return '<span class="muted-dash">—</span>';
    if (row.t === 'grp' && row.coef == null) {
      return '<span class="muted-dash" title="у строк группы разные коэффициенты — раскройте группу и исправьте по строкам">разн.</span>';
    }
    var value = fix && fix.coef != null ? fix.coef : row.coef;
    var mine = fix && fix.coef != null;
    var cls = 'rv-coef-btn' + (mine || row.coef_user ? ' rv-f-coef-user' : '');
    var title = mine ? 'ваш коэффициент — щёлкните, чтобы изменить' : (row.coef_user ? 'исправлен инженером — щёлкните, чтобы изменить'
      : (Number(value) ? 'щёлкните, чтобы исправить коэффициент' : 'коэффициент 0 — строка объём работы не ведёт; щёлкните, чтобы задать'));
    var scope = row.t === 'grp' && groupIndex != null ? ' data-grp-i="' + groupIndex + '"' : '';
    var out = '<button type="button" class="' + cls + '" data-coef="' + row.id + '"' + scope + ' title="' + h(title) + '">' +
      (Number(value) ? num(value, 4) : '0') + '</button>';
    // Коэффициент проведён в 1С, у агента другой — предложение: щелчок принимает его (как исправление инженера).
    var suggested = agentCoef(row, fix);
    if (suggested != null) {
      out += '<button type="button" class="rv-link rv-f-coef-agent" data-coef-agent="' + row.id + '"' + scope +
        ' title="в 1С проведён коэффициент ' + h(num(row.coef, 4)) + ', агент предлагает ' + h(num(suggested, 4)) + ' — щёлкните, чтобы принять">агент: ' +
        (Number(suggested) ? num(suggested, 4) : '0') + '</button>';
    } else if (row.onec_coef != null && Math.abs(Number(row.onec_coef) - (Number(value) || 0)) > 1e-9) {
      // Коэффициент исправлен на странице — подпись, какой был в 1С
      out += '<span class="rv-f-was" title="коэффициент в 1С">в 1С: ' + num(row.onec_coef, 4) + '</span>';
    }
    return out;
  }

  // Коэффициент агента, если он отличается от проведённого в 1С и инженер ещё не задал свой; иначе null.
  function agentCoef(row, fix) {
    if (row.coef_agent == null || (fix && fix.coef != null)) return null;
    return Math.abs(Number(row.coef_agent) - (Number(row.coef) || 0)) > 1e-9 ? row.coef_agent : null;
  }

  // Принять коэффициент агента: то же, что ввести его вручную.
  function setCoef(target, n) {
    var row = target.row;
    var same = row.coef != null && Math.abs(n - Number(row.coef)) < 1e-9;
    target.ids.forEach(function (id) {
      var f = fixes[id] || { code: row.code, name: '', role: row.role, coef: null };
      f.coef = same ? null : n;
      if (f.code === row.code && f.role === row.role && f.coef == null) delete fixes[id];
      else fixes[id] = f;
    });
    updateBar();
  }

  function editCoef(button) {
    var target = targetOf(button);
    if (!target) return;
    var row = target.row;
    var current = fixes[target.ids[0]];
    var value = current && current.coef != null ? current.coef : (row.coef == null ? '' : row.coef);
    var cell = button.parentNode;
    cell.innerHTML = '<input type="text" class="rv-coef-input" inputmode="decimal" value="' + h(Number(value) ? value : '') + '" aria-label="Коэффициент">';
    var input = cell.querySelector('input');
    var done = false;
    function finish(save) {
      if (done) return;
      done = true;
      if (save) {
        var text = input.value.replace(',', '.').replace(/\s/g, '');
        var n = text === '' ? 0 : Number(text);
        if (isNaN(n) || n < 0) { done = false; input.focus(); input.select(); return; }
        setCoef(target, n);
      }
      rerow(cell.closest('tr'), target.index);
    }
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); finish(true); }
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); finish(false); }
    });
    input.addEventListener('blur', function () { finish(true); });
    input.focus();
    input.select();
  }

  function fixSummary(fix, row) {
    var changed = [];
    if (fix.code !== row.code) changed.push('<b>→ <code>' + h(fix.code) + '</code></b> ' + h(fix.name));
    if (fix.coef != null) changed.push('коэф. ' + num(fix.coef, 4));
    return changed.join(', ') || 'без изменений';
  }

  function flagTags(row) {
    var codes = row.fcodes || [];
    if (!codes.length) return '';
    return codes.map(function (code, i) {
      if (HIDDEN_FLAGS[code]) return '';
      return '<span class="rv-f-flag" data-code="' + h(code) + '" title="' + h(flagTitle(row, code, i)) + '">' + h(FLAG_LABEL[code] || code) + '</span>';
    }).join('');
  }

  function checkHtml(row, fix, index) {
    if (row.nosec) return '<span class="muted-dash">раздел и система не определены — задайте систему при загрузке ЛРВ</span>';
    var scope = row.t === 'grp' ? ' data-grp-i="' + index + '"' : '';
    var out;
    var parts = row.t !== 'grp' ? splits[row.id] : null;
    if (parts && parts.length > 1) {
      out = '<div class="rv-f-check-row"><span class="rv-fix-done">' + splitSummary(parts, row) + '</span>' +
        ' <button type="button" class="rv-link" data-split="' + row.id + '">изменить</button>' +
        ' <button type="button" class="rv-link" data-unsplit="' + row.id + '">отменить</button></div>';
      return out;
    }
    if (fix) {
      out = '<div class="rv-f-check-row"><span class="rv-fix-done">' + fixSummary(fix, row) + '</span>' +
        ' <button type="button" class="rv-link" data-fix="' + row.id + '"' + scope + '>изменить</button>' +
        ' <button type="button" class="rv-link" data-unfix="' + row.id + '"' + scope + '>отменить</button></div>';
    } else if (row.t === 'grp' && row.members.some(function (m) { return fixes[m.id]; })) {
      out = '<div class="rv-f-check-row"><span class="rv-fix-done">исправлено по строкам</span> <button type="button" class="rv-link" data-fix="' + row.id + '"' + scope + '>задать всем</button></div>';
    } else if (isDispute(row)) {
      // В 1С разнесено, агент не согласен: оставить как в 1С (ничего не делать) или принять агента.
      out = '<div class="rv-f-was-work">агент предлагает: ' + workChip(row.agent_code, row.agent_work) + '</div>' +
        '<div class="rv-f-check-row">' + flagTags(row) +
        '<button type="button" class="rv-link" data-accept-agent="' + row.id + '"' + scope + '>принять агента</button>' +
        '<button type="button" class="rv-mini" data-fix="' + row.id + '"' + scope + '>Исправить</button></div>';
    } else {
      out = '<div class="rv-f-check-row">' + flagTags(row);
      if (row.learned === 'correction') out += '<span class="rv-f-tag is-learned" title="' + h(row.src || '') + '">решение сметчика</span>';
      else if (row.learned === 'confirmed') out += '<span class="rv-f-tag is-learned" title="' + h(row.src || '') + '">проверено ранее</span>';
      out += '<button type="button" class="rv-mini" data-fix="' + row.id + '"' + scope + '>' + (row.code ? 'Исправить' : 'Указать работу') + '</button></div>';
      if (row.alts && row.alts.length) {
        out += '<div class="rv-f-alts"><span class="muted-dash">или:</span> ' + row.alts.map(function (a) {
          return '<button type="button" class="rv-link rv-alt" data-alt="' + h(a.code) + '" data-alt-id="' + row.id + '"' + scope + ' title="' + h(a.work) + ' — так разнесено в ' + Math.round((a.share || 0) * 100) + ' % РВ выборки"><code>' + h(a.code) + '</code> ' + h((a.work || '').split(' / ')[0]) + '</button>';
        }).join(' ') + '</div>';
      }
    }
    var rec = row.rec;
    if (rec && row.learned !== 'correction' && !fix) {
      if (rec.verdict === 'заменить' && rec.code) {
        out += '<div class="rv-f-rec">модель: <code>' + h(rec.code) + '</code> ' + h(rec.work) +
          (rec.reason ? ' <span class="muted-dash">— ' + h(rec.reason) + '</span>' : '') +
          ' <button type="button" class="rv-link" data-accept="' + row.id + '"' + scope + '>принять</button></div>';
      } else if (rec.verdict === 'вопрос') {
        out += '<div class="rv-f-rec muted-dash">модель: вопрос' + (rec.question ? ' — ' + h(rec.question) : (rec.reason ? ' — ' + h(rec.reason) : '')) + '</div>';
      } else if (rec.verdict === 'подтвердить') {
        out += '<div class="rv-f-rec muted-dash">модель: подтвердить' + (rec.reason ? ' — ' + h(rec.reason) : '') + '</div>';
      }
    }
    return out;
  }

  var tbody, counter;
  function render() {
    var show = visibleSet();
    var html = [];
    var shown = 0;
    view.forEach(function (row, index) {
      if (!show[index]) return;
      if (row.t === 'mat') shown++;
      if (row.t === 'grp') shown += row.members.length;
      html.push(rowHtml(row, index));
    });
    tbody.innerHTML = html.join('');
    counter.textContent = filterActive() ? 'найдено ' + shown + ' из ' + stats.mats
      : stats.mats + ' строк' + (isCorrection() ? ', в 1С разнесено ' + stats.onec : '') + (stats.reduced ? ', уменьшено по ЛРВ ' + stats.reduced : '');
    updateBar();
  }

  // Строки ЛРВ без работы, которым инженер ещё не назначил работу. Пока они есть, РВ не согласовать:
  // в 1С материал остался бы вне работ (сервер проверяет то же — rv_feedback.php).
  function unboundLeft() {
    return rows.filter(function (row) {
      return row.t === 'mat' && (!row.code || row.nosec) && !(fixes[row.id] && fixes[row.id].code) && !(splits[row.id] && splits[row.id].length > 1);
    });
  }

  function updateBar() {
    refreshAcceptModel();
    var n = Object.keys(fixes).length + Object.keys(splits).filter(function (id) { return splits[id].length > 1; }).length;
    var notesN = Object.keys(workNotes).length;
    var worksN = Object.keys(addedWorks).length;
    var left = unboundLeft().length;
    var bar = card.querySelector('.rv-savebar');
    var save = bar.querySelector('.rv-save');
    var tops = document.querySelectorAll('.rv-save-top');   // кнопка согласования в шапке страницы (в полном экране её нет)
    var block = card.querySelector('.rv-unbound-block');
    bar.querySelector('.rv-save-count').textContent = (n ? 'Исправлено строк: ' + n + '. ' : '') + (notesN ? 'Примечаний: ' + notesN + '. ' : '') +
      (worksN ? 'Работ сметчика: ' + worksN + '. ' : '');
    var topText;
    if (left) {
      save.textContent = 'Согласовать нельзя: без работы ' + left;
      topText = 'Согласовать нельзя: без работы ' + left;
    } else {
      save.textContent = 'Согласовать РВ';
      topText = n || notesN || worksN ? 'Согласовать РВ (исправлено ' + (n + notesN + worksN) + ')' : 'Согласовать РВ';
    }
    save.disabled = !!left;
    Array.prototype.forEach.call(tops, function (top) { top.textContent = topText; top.disabled = !!left; });
    if (block) {
      block.hidden = !left;
      block.querySelector('.rv-unbound-count').textContent = left;
    }
  }

  // ── Выбор работы, роли и коэффициента ──
  function search(section, sysc, query) {
    var list = catalog[section] || [];
    var words = query.toLowerCase().split(/\s+/).filter(Boolean);
    var own = function (entry) { return sysc && entry[0].split('.')[4] === sysc; };
    if (!words.length) return list.filter(own).concat(list.filter(function (e) { return !own(e); })).slice(0, 40);
    var exact = [], mine = [], rest = [];
    list.forEach(function (entry) {
      var hay = (entry[0] + ' ' + entry[1]).toLowerCase();
      if (!words.every(function (w) { return hay.indexOf(w) >= 0; })) return;
      (entry[0].indexOf(words[0]) === 0 ? exact : (own(entry) ? mine : rest)).push(entry);
    });
    return exact.concat(mine, rest).slice(0, 40);
  }

  // Цель действия: группа (кнопка с data-grp-i — решение на всех её членов) или одна строка ЛРВ по id.
  function targetOf(button) {
    if (button.hasAttribute('data-grp-i')) {
      var gi = Number(button.getAttribute('data-grp-i'));
      return { row: view[gi], index: gi, ids: view[gi].members.map(function (m) { return m.id; }) };
    }
    var id = Number(button.getAttribute('data-fix') || button.getAttribute('data-unfix') || button.getAttribute('data-accept') || button.getAttribute('data-accept-agent') || button.getAttribute('data-coef') || button.getAttribute('data-coef-agent') || button.getAttribute('data-split') || button.getAttribute('data-unsplit') || button.getAttribute('data-alt-id'));
    for (var i = 0; i < view.length; i++) {
      var row = view[i];
      if (row.t === 'mat' && row.id === id) return { row: row, index: i, ids: [id] };
      if (row.t === 'grp') {
        for (var j = 0; j < row.members.length; j++) if (row.members[j].id === id) return { row: row.members[j], index: i, ids: [id], member: true };
      }
    }
    return null;
  }

  function openPicker(tr, target) {
    var row = target.row;
    var cell = tr.querySelector('.rv-f-check');
    var current = fixes[target.ids[0]] || {};
    var coefNow = current.coef != null ? current.coef : (row.coef == null ? '' : row.coef);
    var coefField = row.t === 'grp' && row.coef == null
      ? '<span class="muted-dash" title="у строк группы разные коэффициенты — исправляйте их по строкам (раскройте группу)">коэф. — по строкам</span>'
      : '<label title="' + h(legend.coef || '') + '">коэф. <input type="text" class="rv-pick-coef" inputmode="decimal" value="' + h(coefNow) + '" size="8"></label>';
    cell.innerHTML = '<div class="rv-picker">' +
      '<input type="text" class="rv-pick-q" placeholder="код или слова из названия работы (' + h(row.section) + ')" value="' + h(current.code && current.code !== row.code ? current.code : '') + '" autocomplete="off">' +
      '<div class="rv-pick-row">' +
        '<button type="button" class="rv-mini rv-pick-move" title="Щёлкните по строке работы в таблице — материал перейдёт в неё">Указать в таблице</button>' +
        (row.t !== 'grp' && !target.member ? '<button type="button" class="rv-mini rv-pick-split" title="Разнести строку на несколько работ с количеством под каждой">Разбить</button>' : '') +
        coefField +
        '<button type="button" class="rv-mini rv-pick-apply" title="Оставить работу, сохранить коэффициент">Применить коэф.</button>' +
        '<button type="button" class="rv-mini rv-pick-cancel">✕</button>' +
      '</div>' +
      '<div class="rv-pick-list"></div></div>';
    var input = cell.querySelector('.rv-pick-q');
    var list = cell.querySelector('.rv-pick-list');
    var coefInput = cell.querySelector('.rv-pick-coef');
    function refresh() {
      var found = search(row.section, row.sysc, input.value);
      list.innerHTML = found.length ? found.map(function (e) {
        return '<button type="button" class="rv-pick-item" data-code="' + h(e[0]) + '"><code>' + h(e[0]) + '</code> ' + h(e[1]) +
          (e[2] ? ' <span class="muted-dash">' + h(e[2]) + '</span>' : '') +
          (e[3] ? '<span class="rv-pick-branch">' + h(e[3]) + '</span>' : '') + '</button>';
      }).join('') : '<div class="muted-dash rv-pick-empty">ничего не найдено — попробуйте другие слова</div>';
    }
    function coefValue() {
      if (!coefInput) return null;
      var text = coefInput.value.replace(',', '.').replace(/\s/g, '');
      if (text === '') return null;
      var n = Number(text);
      if (isNaN(n) || n < 0) { coefInput.focus(); coefInput.select(); return undefined; }
      var same = row.coef != null && Math.abs(n - Number(row.coef)) < 1e-9;
      return same ? null : n;
    }
    function commit(code, name) {
      var coef = coefValue();
      if (coef === undefined) return;
      applyFix(target, code, name, coef);
      rerow(tr, target.index);
      updateBar();
    }
    function choose(code) {
      var entry = (catalog[row.section] || []).filter(function (e) { return e[0] === code; })[0];
      if (entry) commit(entry[0], entry[1]);
    }
    input.addEventListener('input', refresh);
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { rerow(tr, target.index); }
      if (e.key === 'Enter') {
        e.preventDefault();
        var first = list.querySelector('.rv-pick-item');
        if (first) choose(first.getAttribute('data-code'));
      }
    });
    list.addEventListener('click', function (e) {
      var item = e.target.closest('.rv-pick-item');
      if (item) choose(item.getAttribute('data-code'));
    });
    cell.querySelector('.rv-pick-apply').addEventListener('click', function () {
      var name = row.code ? (workNameOf(row.code) || '') : '';
      if (!row.code) { input.focus(); return; }
      commit(row.code, name);
    });
    cell.querySelector('.rv-pick-cancel').addEventListener('click', function () { rerow(tr, target.index); });
    cell.querySelector('.rv-pick-move').addEventListener('click', function () { startMove(target, tr); });
    var splitBtn = cell.querySelector('.rv-pick-split');
    if (splitBtn) splitBtn.addEventListener('click', function () { openSplit(tr, target); });
    refresh();
    input.focus();
  }

  // Записать решение по цели: работа (код, имя), роль прежняя, коэффициент (null — как у агента).
  function applyFix(target, code, name, coef) {
    var row = target.row;
    var changed = code !== row.code || coef != null;
    target.ids.forEach(function (id) {
      if (changed) fixes[id] = { code: code, name: name, role: row.role, coef: coef };
      else delete fixes[id];
    });
  }

  // «Указать в таблице»: строки работ становятся кликабельными, щелчок по одной переносит в неё материал.
  function startMove(target, tr) {
    moving = target;
    card.classList.add('is-moving');
    var bar = card.querySelector('.rv-move-bar');
    bar.hidden = false;
    bar.querySelector('.rv-move-name').textContent = target.row.name;
    render();
  }
  function stopMove() {
    moving = null;
    card.classList.remove('is-moving');
    var bar = card.querySelector('.rv-move-bar');
    if (bar) bar.hidden = true;
    render();
  }
  function moveTo(code) {
    if (!moving) return;
    var target = moving;
    var name = workNameOf(code) || '';
    applyFix(target, code, name, null);
    stopMove();
    updateBar();
    var tr = tbody.querySelector('tr[data-i="' + target.index + '"]');
    if (tr) tr.scrollIntoView({ block: 'center' });
  }

  function workNameOf(code) {
    var all = Object.keys(catalog);
    for (var i = 0; i < all.length; i++) {
      var hit = catalog[all[i]].filter(function (e) { return e[0] === code; })[0];
      if (hit) return hit[1];
    }
    return '';
  }

  // Перерисовать строку view (у группы — вместе с раскрытыми членами).
  function rerow(tr, index) {
    var tmp = document.createElement('tbody');
    tmp.innerHTML = rowHtml(view[index], index);
    var old = tbody.querySelectorAll('tr[data-i="' + index + '"]');
    var anchor = old[0];
    for (var i = 1; i < old.length; i++) old[i].parentNode.removeChild(old[i]);
    while (tmp.firstChild) { anchor.parentNode.insertBefore(tmp.firstChild, anchor); }
    anchor.parentNode.removeChild(anchor);
  }

  // ── Добавить работу ──
  // Работа без материалов (испытания, наладка, монтаж оборудования и т. п.): сметчик выбирает её из ИСР и задаёт объём;
  // после согласования агент добавит её в РВ, в 1С она уйдёт сметной позицией с этим объёмом. Строки ЛРВ в неё можно
  // перенести как в любую работу — «Исправить». Работа, которая в РВ уже есть со строками, объём считает по строкам.
  function workRowOf(code) {
    for (var i = 0; i < rows.length; i++) if (rows[i].t === 'work' && rows[i].code === code) return rows[i];
    return null;
  }
  function unitOf(code) {
    var found = '';
    Object.keys(catalog).forEach(function (sec) { (catalog[sec] || []).forEach(function (e) { if (e[0] === code) found = e[2] || ''; }); });
    return found;
  }
  // Поле объёма на месте: Enter или уход с поля — записать (число > 0), Esc — отмена. onDone(число или null).
  function qtyInput(cell, current, onDone) {
    cell.innerHTML = '<input type="text" class="rv-coef-input rv-qty-input" inputmode="decimal" value="' + h(current == null ? '' : current) + '" aria-label="Объём работы">';
    var input = cell.querySelector('input');
    var done = false;
    function finish(save) {
      if (done) return;
      var n = null;
      if (save) {
        var text = input.value.replace(',', '.').replace(/\s/g, '');
        n = Number(text);
        if (!text || isNaN(n) || n <= 0) { input.focus(); input.select(); input.classList.add('is-bad'); return; }
        n = Math.round(n * 10000) / 10000;
      }
      done = true;
      onDone(n);
    }
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); finish(true); }
      if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); finish(false); }
    });
    input.addEventListener('blur', function () { if (input.value.trim()) finish(true); else finish(false); });
    input.focus();
    input.select();
  }
  function editWorkQty(tr, code) {
    var row = workRowOf(code);
    var current = Object.prototype.hasOwnProperty.call(addedWorks, code) && addedWorks[code] ? addedWorks[code] : (row ? row.qty : null);
    var cell = tr.querySelectorAll('td.rv-f-num')[1];       // «Кол-во» работы
    qtyInput(cell, current, function (n) {
      if (n != null) addedWorks[code] = n;
      render();
      updateBar();
      renderAdded();
    });
  }
  // Новые (ещё не в РВ) работы сметчика — списком в панели: объём, убрать.
  function renderAdded() {
    var panel = card.querySelector('.rv-add-panel');
    if (!panel) return;
    var list = panel.querySelector('.rv-added-list');
    if (!list) return;
    var fresh = Object.keys(addedWorks).filter(function (code) { return !workRowOf(code) && addedWorks[code]; });
    list.innerHTML = fresh.length
      ? '<div class="muted-dash">Будут добавлены после согласования:</div>' + fresh.map(function (code) {
          return '<div class="rv-added-item"><code>' + h(code) + '</code> ' + h(workNameOf(code) || '') +
            ' — <span class="rv-added-qty"><b>' + num(addedWorks[code]) + '</b></span> ' + h(unitOf(code)) +
            ' <button type="button" class="rv-link" data-added-qty="' + h(code) + '">объём</button>' +
            ' <button type="button" class="rv-link" data-added-del="' + h(code) + '">убрать</button></div>';
        }).join('')
      : '';
  }
  function openAddWork() {
    var panel = card.querySelector('.rv-add-panel');
    if (!panel.hidden) { panel.hidden = true; panel.innerHTML = ''; return; }
    var sections = Object.keys(catalog);
    var mats = rows.filter(function (r) { return r.t === 'mat' && r.section; });
    var section = mats.length ? mats[0].section : sections[0];
    var sysc = mats.length ? mats[0].sysc : '';
    panel.hidden = false;
    panel.innerHTML = '<div class="rv-add-head"><b>Добавить работу</b> <span class="muted-dash">без материалов — объём вручную; в 1С уйдёт сметной позицией с этим объёмом. Сохранится при согласовании РВ.</span>' +
        '<button type="button" class="rv-mini rv-add-close">✕</button></div>' +
      '<div class="rv-picker rv-add-picker">' +
        (sections.length > 1 ? '<select class="rv-add-sec">' + sections.map(function (sec) { return '<option' + (sec === section ? ' selected' : '') + '>' + h(sec) + '</option>'; }).join('') + '</select>' : '') +
        '<input type="text" class="rv-pick-q" placeholder="код или слова из названия работы (' + h(section) + ')" autocomplete="off">' +
        '<div class="rv-pick-list"></div></div>' +
      '<div class="rv-added-list"></div>';
    var input = panel.querySelector('.rv-pick-q');
    var list = panel.querySelector('.rv-pick-list');
    var secSel = panel.querySelector('.rv-add-sec');
    function refresh() {
      var found = search(section, sysc, input.value);
      list.innerHTML = found.length ? found.map(function (e) {
        var have = workRowOf(e[0]);
        var busy = have && have.nmat;
        return '<button type="button" class="rv-pick-item" data-code="' + h(e[0]) + '"' + (busy ? ' disabled title="работа уже есть в РВ со строками ЛРВ — объём считается по ним"' : '') + '>' +
          '<code>' + h(e[0]) + '</code> ' + h(e[1]) + (e[2] ? ' <span class="muted-dash">' + h(e[2]) + '</span>' : '') +
          (busy ? ' <span class="muted-dash">· уже в РВ</span>' : (have ? ' <span class="muted-dash">· в РВ без строк — задать объём</span>' : '')) +
          (e[3] ? '<span class="rv-pick-branch">' + h(e[3]) + '</span>' : '') + '</button>';
      }).join('') : '<div class="muted-dash rv-pick-empty">ничего не найдено — попробуйте другие слова</div>';
    }
    function choose(code, item) {
      var have = workRowOf(code);
      if (have && have.nmat) return;
      // объём — прямо в строке списка: «<код> имя — [объём] ед.»
      item.outerHTML = '<div class="rv-pick-item rv-add-qty-row"><code>' + h(code) + '</code> ' + h(workNameOf(code)) +
        ' — объём <span class="rv-add-qty-cell"></span> ' + h(unitOf(code)) + ' <span class="muted-dash">Enter — добавить, Esc — отмена</span></div>';
      qtyInput(list.querySelector('.rv-add-qty-cell'), addedWorks[code] || (have ? have.qty : null), function (n) {
        if (n != null) {
          addedWorks[code] = n;
          input.value = '';
          render();
          updateBar();
          renderAdded();
        }
        refresh();
        input.focus();
      });
    }
    input.addEventListener('input', refresh);
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Escape') { panel.hidden = true; panel.innerHTML = ''; }
      if (e.key === 'Enter') {
        e.preventDefault();
        var first = list.querySelector('button.rv-pick-item:not([disabled])');
        if (first) choose(first.getAttribute('data-code'), first);
      }
    });
    list.addEventListener('click', function (e) {
      var item = e.target.closest('button.rv-pick-item');
      if (item && !item.disabled) choose(item.getAttribute('data-code'), item);
    });
    if (secSel) secSel.addEventListener('change', function () {
      section = secSel.value;
      var mat = mats.filter(function (r) { return r.section === section; })[0];
      sysc = mat ? mat.sysc : '';
      input.placeholder = 'код или слова из названия работы (' + section + ')';
      refresh();
    });
    panel.querySelector('.rv-add-close').addEventListener('click', function () { panel.hidden = true; panel.innerHTML = ''; });
    panel.querySelector('.rv-added-list').addEventListener('click', function (e) {
      var q = e.target.closest('[data-added-qty]');
      if (q) {
        var code = q.getAttribute('data-added-qty');
        qtyInput(q.parentNode.querySelector('.rv-added-qty'), addedWorks[code], function (n) {
          if (n != null) addedWorks[code] = n;
          updateBar();
          renderAdded();
        });
        return;
      }
      var del = e.target.closest('[data-added-del]');
      if (del) { delete addedWorks[del.getAttribute('data-added-del')]; updateBar(); renderAdded(); }
    });
    refresh();
    renderAdded();
    input.focus();
  }

  // ── Согласование ──
  // Кнопка «Согласовать РВ» сначала спрашивает подтверждение: после согласования РВ доступна 1С для загрузки.
  function confirmSave() {
    if (unboundLeft().length) { save(); return; }   // save() сам покажет строки без работы
    var n = Object.keys(fixes).length + Object.keys(splits).filter(function (id) { return splits[id].length > 1; }).length;
    var notesN = Object.keys(workNotes).length;
    var worksN = Object.keys(addedWorks).length;
    var summary = (n ? 'Исправлено строк: ' + n + '. ' : '') + (notesN ? 'Примечаний к работам: ' + notesN + '. ' : '') +
      (worksN ? 'Работ добавлено или с объёмом вручную: ' + worksN + '. ' : '') +
      (n ? 'Остальные строки считаются верными.' : 'Все строки подтверждаются как подобранные верно.');
    var old = card.querySelector('.rv-confirm');
    if (old) old.remove();
    if (typeof HTMLDialogElement === 'undefined') {
      if (window.confirm('Согласовать РВ? После этого она уйдёт в 1С: 1С сможет загрузить её в «Сопоставление РВ и ЛРВ», агент запомнит решения. ' + summary)) save();
      return;
    }
    var dlg = document.createElement('dialog');
    dlg.className = 'kb-dialog rv-confirm';
    dlg.innerHTML = '<div class="kb-dialog__head"><strong>Согласовать РВ?</strong></div>' +
      '<div class="kb-dialog__body"><p>После согласования РВ уйдёт в 1С: 1С сможет загрузить её в «Сопоставление РВ и ЛРВ» как проверенную, ' +
      'а агент запомнит ваши решения и применит их в следующих РВ. Пока РВ не согласована, 1С её не берёт.</p>' +
      '<p class="muted">' + h(summary) + ' Согласование можно откатить на странице РВ («…» → «Откатить согласование»), пока 1С её не загрузила.</p>' +
      '<div class="kb-dialog__actions"><button type="button" class="kb-btn kb-btn--ghost rv-confirm-no">Отмена</button>' +
      '<button type="button" class="kb-btn kb-btn--primary rv-confirm-yes">Согласовать РВ</button></div></div>';
    card.appendChild(dlg);
    dlg.querySelector('.rv-confirm-no').addEventListener('click', function () { dlg.close(); });
    dlg.querySelector('.rv-confirm-yes').addEventListener('click', function () { dlg.close(); save(); });
    dlg.addEventListener('close', function () { dlg.remove(); });
    dlg.showModal();
  }

  function save() {
    var btns = Array.prototype.slice.call(document.querySelectorAll('.rv-save-top')).concat([card.querySelector('.rv-save')]);
    var btn = { set disabled(v) { btns.forEach(function (b) { b.disabled = v; }); },
                set textContent(t) { btns.forEach(function (b) { b.textContent = t; }); },
                setAttribute: function (k, v) { btns.forEach(function (b) { b.setAttribute(k, v); }); },
                removeAttribute: function (k) { btns.forEach(function (b) { b.removeAttribute(k); }); } };
    var note = card.querySelector('.rv-save-note');
    if (unboundLeft().length) {
      note.textContent = 'Сначала назначьте работу всем строкам без работы.';
      showUnbound();
      return;
    }
    var corrections = Object.keys(fixes).map(function (id) {
      var f = fixes[id];
      // Роль «?» (агент не определил) — не роль: сервер её не знает, правка роль не меняет.
      return { id: Number(id), code: f.code, role: f.role && f.role !== '?' ? f.role : '', coef: f.coef == null ? null : f.coef, via: f.via || '' };
    });
    btn.setAttribute('aria-busy', 'true');
    btn.disabled = true;
    note.textContent = 'Сохраняю…';
    fetch(feedbackUrl, {
      method: 'POST', credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ token: token, corrections: corrections, confirm_rest: true, work_notes: workNotes, splits: splits, added_works: addedWorks })
    }).then(function (r) { return r.json(); }).then(function (data) {
      if (!data.ok) throw new Error(data.error || 'ошибка сервера');
      note.textContent = 'Решения записаны, агент пересобирает РВ…';
      btn.textContent = 'Сохранено, пересобираю…';
      location.href = data.redirect;
    }).catch(function (err) {
      btn.removeAttribute('aria-busy');
      btn.disabled = false;
      note.textContent = 'Не сохранилось: ' + err.message;
    });
  }

  // Показать только строки без работы и раскрыть их узлы.
  function showUnbound() {
    filter.unbound = true;
    var box = card.querySelector('.rv-only-unbound');
    if (box) box.checked = true;
    render();
  }

  // ── Во весь экран ──
  function setFullscreen(on) {
    card.classList.toggle('is-fullscreen', on);
    document.body.classList.toggle('rv-fullscreen-open', on);
    var btn = card.querySelector('.rv-fullscreen');
    if (btn) btn.textContent = on ? 'Выйти из полного экрана' : 'Во весь экран';
  }

  // ── Запуск ──
  function build(data) {
    rows = data.rows || [];
    catalog = data.catalog || {};
    roles = data.roles || roles;
    legend = data.legend || {};
    prepare();
    body.innerHTML =
      '<div class="rv-toolbar">' +
        '<label class="rv-tool-search"><input type="search" class="rv-q" placeholder="материал, работа, код, №" aria-label="Поиск по строкам"></label>' +
        '<label class="rv-tool-inline">уверенность <select class="rv-conf-sel">' +
          '<option value="101">все строки</option><option value="95">ниже 95 %</option><option value="80">ниже 80 %</option><option value="60">ниже 60 %</option></select></label>' +
        '<label class="rv-tool-check"><input type="checkbox" class="rv-only"> только на проверку и без работы <span class="rv-cnt">' + (stats.review + stats.unbound) + '</span></label>' +
        (stats.unbound ? '<label class="rv-tool-check"><input type="checkbox" class="rv-only-unbound"> только без работы <span class="rv-cnt">' + stats.unbound + '</span></label>' : '') +
        '<span class="rv-tool-group"><button type="button" class="rv-mini rv-collapse">Свернуть всё</button>' +
        '<button type="button" class="rv-mini rv-expand">Работы</button>' +
        '<button type="button" class="rv-mini rv-expand-all">Все строки</button>' +
        '<button type="button" class="rv-mini rv-fullscreen">Во весь экран</button></span>' +
        '<button type="button" class="rv-mini rv-accept-model" style="display:none" title="Принять все замены, которые предлагает модель (строки «модель: … принять»); каждую можно отменить">Принять предложения модели</button>' +
        (Object.keys(catalog).length ? '<button type="button" class="rv-mini rv-add-work" title="Работа без материалов: объём вручную, уйдёт в 1С сметной позицией">+ Добавить работу</button>' : '') +
        '<span class="rv-counter muted-dash"></span>' +
        (stats.onec ? '<span class="rv-legend-new muted-dash" title="строки и работы, которых в 1С ещё не было' + (stats.reduced ? '; уменьшения — количество под работой стало меньше, чем разнесено в 1С (ЛРВ уменьшилась)' : '') + '"><i></i> ' + (stats.reduced ? 'изменения для 1С: новые строки и уменьшения' : 'новые строки — нет в 1С') + '</span>' : '') +
      '</div>' +
      '<div class="rv-add-panel" hidden></div>' +
      '<div class="rv-move-bar" hidden><span>Щёлкните по строке работы, в которую перенести «<b class="rv-move-name"></b>»</span><button type="button" class="rv-mini rv-move-cancel">Отмена (Esc)</button></div>' +
      '<div class="table-wrap rv-form-wrap"><table class="data-table rv-form"><thead><tr>' +
        '<th>№</th><th>Наименование</th><th>Ед.</th><th class="rv-f-num" title="' + h(legend.coef || '') + '">Коэф.</th><th class="rv-f-num" title="количество по ЛРВ (объём)">Кол-во</th>' +
        '<th class="rv-f-num" title="количество в смету — из 1С">В смету</th><th>Увер.</th><th>Проверка</th>' +
      '</tr></thead><tbody></tbody></table></div>' +
      '<div class="alert warn rv-unbound-block" hidden>Согласовать РВ нельзя, пока есть строки ЛРВ без работы — ' +
        '<b class="rv-unbound-count"></b>: в 1С такой материал остался бы вне работ. Назначьте каждой работу кнопкой «Указать работу». ' +
        '<button type="button" class="rv-mini rv-show-unbound">показать строки без работы</button></div>' +
      '<div class="rv-savebar"><span class="rv-save-count"></span><button type="button" class="rv-save"></button>' +
        '<span class="rv-save-note muted-dash">Нетронутые строки считаются верными; агент запомнит решения и применит их в следующих РВ.</span></div>';
    tbody = body.querySelector('tbody');
    counter = body.querySelector('.rv-counter');
    var toolbar = body.querySelector('.rv-toolbar');
    function toolbarHeight() { card.style.setProperty('--rv-toolbar-h', toolbar.offsetHeight + 'px'); }
    toolbarHeight();
    window.addEventListener('resize', toolbarHeight);
    render();

    body.querySelector('.rv-q').addEventListener('input', function (e) { filter.q = e.target.value.trim().toLowerCase(); render(); });
    body.querySelector('.rv-conf-sel').addEventListener('change', function (e) { filter.conf = Number(e.target.value); render(); });
    body.querySelector('.rv-move-cancel').addEventListener('click', stopMove);
    body.querySelector('.rv-only').addEventListener('change', function (e) { filter.only = e.target.checked; render(); });
    var onlyUnbound = body.querySelector('.rv-only-unbound');
    if (onlyUnbound) onlyUnbound.addEventListener('change', function (e) { filter.unbound = e.target.checked; render(); });
    body.querySelector('.rv-show-unbound').addEventListener('click', showUnbound);
    body.querySelector('.rv-collapse').addEventListener('click', function () {
      view.forEach(function (row, index) { if ((row.t === 'node' && row.lvl === 5) || row.t === 'work') collapsed[index] = true; });
      render();
    });
    body.querySelector('.rv-expand').addEventListener('click', function () {
      view.forEach(function (row, index) { collapsed[index] = row.t === 'work'; });
      render();
    });
    body.querySelector('.rv-expand-all').addEventListener('click', function () { collapsed = {}; render(); });
    body.querySelector('.rv-fullscreen').addEventListener('click', function () { setFullscreen(!card.classList.contains('is-fullscreen')); });
    var acceptModelBtn = body.querySelector('.rv-accept-model');
    var modelProposals = function () {
      return rows.filter(function (r) {
        return r.t === 'mat' && r.rec && r.rec.verdict === 'заменить' && r.rec.code && r.rec.code !== r.code &&
          r.learned !== 'correction' && !fixes[r.id] && !(splits[r.id] && splits[r.id].length > 1);
      });
    };
    refreshAcceptModel = function () {
      var n = modelProposals().length;
      acceptModelBtn.style.display = n ? '' : 'none';      // у .rv-mini свой display — атрибут hidden его не перебивает
      acceptModelBtn.textContent = 'Принять предложения модели (' + n + ')';
    };
    refreshAcceptModel();
    acceptModelBtn.addEventListener('click', function () {
      var list = modelProposals();
      if (!list.length || !window.confirm('Принять ' + list.length + ' замен, которые предлагает модель? Каждую потом можно отменить или изменить.')) return;
      list.forEach(function (r) { fixes[r.id] = { code: r.rec.code, name: r.rec.work || '', role: r.rec.role || r.role, coef: null, via: 'model' }; });
      render();
      updateBar();
      refreshAcceptModel();
    });
    var addBtn = body.querySelector('.rv-add-work');
    if (addBtn) addBtn.addEventListener('click', function () { openAddWork(); });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && moving) { stopMove(); return; }
      if (e.key === 'Escape' && card.classList.contains('is-fullscreen') && !e.target.closest('.rv-picker, .rv-coef-input')) setFullscreen(false);
    });
    body.querySelector('.rv-save').addEventListener('click', confirmSave);
    Array.prototype.forEach.call(document.querySelectorAll('.rv-save-top'), function (b) { b.addEventListener('click', confirmSave); });

    tbody.addEventListener('click', function (e) {
      if (moving) {
        var workRow = e.target.closest('tr.rv-f-work');
        if (workRow && !e.target.closest('[data-toggle]')) { moveTo(workRow.getAttribute('data-work')); return; }
      }
      var toggle = e.target.closest('[data-toggle]');
      if (toggle) {
        var index = Number(toggle.getAttribute('data-toggle'));
        collapsed[index] = !collapsed[index];
        render();
        return;
      }
      var grp = e.target.closest('[data-grp]');
      if (grp) {
        var gi = Number(grp.getAttribute('data-grp'));
        openGroups[gi] = !openGroups[gi];
        rerow(e.target.closest('tr'), gi);
        return;
      }
      var agentCoefBtn = e.target.closest('[data-coef-agent]');
      if (agentCoefBtn) {
        var tc = targetOf(agentCoefBtn);
        var proposed = tc ? agentCoef(tc.row, null) : null;
        if (proposed != null) { setCoef(tc, Number(proposed)); rerow(e.target.closest('tr'), tc.index); }
        return;
      }
      var coefBtn = e.target.closest('[data-coef]');
      if (coefBtn) { editCoef(coefBtn); return; }
      var workQty = e.target.closest('[data-work-qty]');
      if (workQty) { editWorkQty(e.target.closest('tr'), workQty.getAttribute('data-work-qty')); return; }
      var workDel = e.target.closest('[data-work-del]');
      if (workDel) { addedWorks[workDel.getAttribute('data-work-del')] = 0; render(); updateBar(); renderAdded(); return; }
      var remarkBtn = e.target.closest('[data-remark]');
      if (remarkBtn) { editRemark(e.target.closest('tr'), remarkBtn.getAttribute('data-remark')); return; }
      var splitBtn = e.target.closest('[data-split]');
      if (splitBtn) {
        var ts = targetOf(splitBtn);
        if (ts) openSplit(e.target.closest('tr'), ts);
        return;
      }
      var unsplit = e.target.closest('[data-unsplit]');
      if (unsplit) {
        var tu = targetOf(unsplit);
        if (tu) { splits[tu.row.id] = []; rerow(e.target.closest('tr'), tu.index); updateBar(); }
        return;
      }
      var altBtn = e.target.closest('[data-alt]');
      if (altBtn) {
        var talt = targetOf(altBtn);
        if (talt) {
          var altCode = altBtn.getAttribute('data-alt');
          talt.ids.forEach(function (id) { fixes[id] = { code: altCode, name: workNameOf(altCode) || '', role: talt.row.role, coef: null }; });
          rerow(e.target.closest('tr'), talt.index);
          updateBar();
        }
        return;
      }
      var tr = e.target.closest('tr');
      var fixBtn = e.target.closest('[data-fix]');
      if (fixBtn) {
        var target = targetOf(fixBtn);
        if (target) openPicker(tr, target);
        return;
      }
      var unfix = e.target.closest('[data-unfix]');
      if (unfix) {
        var t2 = targetOf(unfix);
        if (t2) { t2.ids.forEach(function (id) { delete fixes[id]; }); rerow(tr, t2.index); updateBar(); }
        return;
      }
      var acceptAgent = e.target.closest('[data-accept-agent]');
      if (acceptAgent) {
        var ta = targetOf(acceptAgent);
        if (ta && ta.row.agent_code) {
          ta.ids.forEach(function (id) { fixes[id] = { code: ta.row.agent_code, name: ta.row.agent_work || workNameOf(ta.row.agent_code) || '', role: ta.row.role, coef: null }; });
          rerow(tr, ta.index);
          updateBar();
        }
        return;
      }
      var accept = e.target.closest('[data-accept]');
      if (accept) {
        var t3 = targetOf(accept);
        var row = t3 && t3.row;
        if (row && row.rec && row.rec.code) {
          t3.ids.forEach(function (id) { fixes[id] = { code: row.rec.code, name: row.rec.work || '', role: row.rec.role || row.role, coef: null }; });
          rerow(tr, t3.index);
          updateBar();
        }
      }
    });
  }

  fetch(rowsUrl, { credentials: 'same-origin', cache: 'no-store' })
    .then(function (r) { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
    .then(build)
    .catch(function (err) {
      body.innerHTML = '<div class="alert error">Строки РВ не загрузились: ' + h(err.message) + '. Обновите страницу; полная РВ есть в книге Excel.</div>';
    });
})();
