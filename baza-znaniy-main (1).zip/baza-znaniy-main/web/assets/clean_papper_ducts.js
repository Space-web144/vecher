/* Stage 10: manual inspection of geometric duct-shaped PDF candidates. */
(function () {
  'use strict';
  var view=document.getElementById('cp-drawing-view');
  var image=document.getElementById('cp-drawing-image');
  var svg=document.getElementById('cp-duct-overlay');
  var list=document.getElementById('cp-duct-candidates');
  var detail=document.getElementById('cp-duct-detail');
  var layers=document.getElementById('cp-duct-layers');
  var status=document.getElementById('cp-duct-status');
  var inventoryBox=document.getElementById('cp-drawing-inventory');
  var modeButton=document.getElementById('cp-duct-mode');
  var methodSelect=document.getElementById('cp-duct-method');
  var colorSelect=document.getElementById('cp-duct-filter');
  var visible=document.getElementById('cp-duct-visible');
  var systemInput=document.getElementById('cp-duct-system');
  var saveSystem=document.getElementById('cp-duct-save-system');
  if(!view||!image||!svg||!list||!detail)return;
  var NS='http://www.w3.org/2000/svg';
  var model=null,selected='',assigned=Object.create(null);
  var currentCandidates=[],filteredCandidates=[];
  var usingTraces=false;
  function text(el,value){if(el)el.textContent=value;}
  function fmt(x){return Number.isFinite(Number(x))?Number(x).toFixed(2):'—';}
  function validPoint(p){return Array.isArray(p)&&p.length===2&&p.every(function(v){return Number.isFinite(Number(v))&&v>=0&&v<=1;});}
  function addLine(a,b,color,width,dashed,opacity){
    if(!validPoint(a)||!validPoint(b))return;
    var line=document.createElementNS(NS,'line');
    [['x1',a[0]*1000],['y1',a[1]*1000],['x2',b[0]*1000],['y2',b[1]*1000],
     ['stroke',color],['stroke-width',width],['stroke-linecap','round'],['opacity',opacity],
     ['stroke-dasharray',dashed?'9 6':'none']].forEach(function(pair){line.setAttribute(pair[0],pair[1]);});
    svg.appendChild(line);
  }
  function emit(){
    window.dispatchEvent(new CustomEvent('clean-papper:duct-review',{detail:{
      layer_systems:Object.keys(assigned).slice(0,12).map(function(color){
        return {stroke_color:color, system_manual:assigned[color],
                review_status:'manual_color_hypothesis_unverified'};
      })
    }}));
  }
  function renderOverlay(){
    svg.replaceChildren();
    if(!model||!visible.checked){svg.hidden=true;return;}
    svg.hidden=false;
    filteredCandidates.forEach(function(c){
      var active=c.candidate_id===selected;
      var a=c.center_start_page_norm,b=c.center_end_page_norm;
      if(active&&Array.isArray(c.source_wall_segments_page_norm)){
        c.source_wall_segments_page_norm.slice(0,2).forEach(function(pair){
          if(Array.isArray(pair)&&pair.length===2)addLine(pair[0],pair[1],'#f2ac41',2.6,false,.9);
        });
      }
      addLine(a,b,active?'#e5513e':'#00bfd4',active?4:1.7,true,active?1:.77);
    });
  }
  function findCandidate(id){
    return currentCandidates.find(function(c){return c.candidate_id===id;});
  }
  function select(id){
    selected=id;
    list.querySelectorAll('button[data-id]').forEach(function(b){
      b.setAttribute('aria-pressed',b.dataset.id===id?'true':'false');
    });
    renderOverlay();
    detail.replaceChildren();
    var c=findCandidate(id);
    if(!c){text(detail,'Выберите кандидат на схеме или в списке.');return;}
    var values=[
      c.candidate_id+' · '+(c.kind==='parallel_colored_strokes'?
        'Пара цветных линий · '+c.orientation+' (гипотеза)':
        c.kind==='rectangular_wall_pair'?'Пара геометрических стенок':
        'Пунктирная ось и две соседние линии'),
      'Длина проекции: '+fmt(c.projected_length_pt)+' PDF pt (НЕ метры).',
      'От '+(c.center_start_pdf_pt||[]).join(', ')+' до '+(c.center_end_pdf_pt||[]).join(', ')+' pt.',
      'Расстояние между стенками: '+fmt(c.width_between_strokes_pt)+' PDF pt (не размер сечения).',
      'Пространственная группа: '+(c.spatial_group_id||'не установлена')+
        ' (близость на плане; не инженерная сеть).',
      'Цвет линии: '+(c.stroke_color||'не определён')+'. Система: '+
        (assigned[c.stroke_color]||'не назначена')+'.',
      'Ближайший размер PDF: '+(c.dimension_text_nearby?c.dimension_text_nearby.text:'не найден')+
        ' (не подтверждён).',
      'Исходные линии: '+(c.source_line_ids||[]).slice(0,24).join(', '),
      'Статус: кандидат для ручной проверки, не учитывается в ведомости объёмов.'
    ];
    values.forEach(function(value){
      var p=document.createElement('p');p.textContent=value;detail.appendChild(p);
    });
    systemInput.value=assigned[c.stroke_color]||'';
  }
  function renderLayers(){
    layers.replaceChildren();
    if(!model){text(layers,'Выполните локальный предпросмотр.');return;}
    (model.layer_statistics||[]).forEach(function(l){
      var row=document.createElement('div');row.className='cp-duct-layer';
      var chip=document.createElement('span');chip.className='cp-duct-swatch';
      if(/^#[a-f0-9]{6}$/i.test(l.stroke_color||''))chip.style.backgroundColor=l.stroke_color;
      row.appendChild(chip);
      var body=document.createElement('span');
      body.textContent=(l.stroke_color||'цвет отсутствует')+
        ' · '+l.stroke_count+' штрихов · '+fmt(l.total_stroke_length_pt)+' pt'+
        (assigned[l.stroke_color]?' · '+assigned[l.stroke_color]:'');
      row.appendChild(body);layers.appendChild(row);
    });
    if(!(model.layer_statistics||[]).length)text(layers,'Цветных векторных путей не обнаружено.');
  }
  function renderCandidates(){
    currentCandidates = usingTraces && model && model.trace_network ?
      (model.trace_network.candidates||[]) : (model&&model.candidates||[]);
    var chosenColor=colorSelect?colorSelect.value:'';
    filteredCandidates=currentCandidates.filter(function(c){
      return !chosenColor||c.stroke_color===chosenColor;
    });
    list.replaceChildren();
    if(!model){text(status,'Геометрические кандидаты пока недоступны.');
      text(list,'Нужен векторный PDF с линиями.');}
    else{
      var scan=model.scanning||{};
      var ts=(model.trace_network&&model.trace_network.scanning)||{};
      text(status,usingTraces ?
        'Этап 10.2: '+currentCandidates.length+' показанных пар цветных линий, '+
        (ts.spatial_groups_returned||0)+' пространственных групп. Найдено '+
        (ts.parallel_pair_proposals||0)+' потенциальных пар. '+
        (ts.source_selection_incomplete?'Выборка PDF неполная. ':'')+
        'Линии и группы НЕ подтверждены как воздуховоды или сети.' :
        'Этап 10: '+(scan.candidate_duct_shapes_found||0)+
        ' геометрических гипотез; показано '+currentCandidates.length+
        '. Это не утверждённые воздуховоды.');
      filteredCandidates.forEach(function(c){
        var button=document.createElement('button');
        button.type='button';button.className='cp-vector-item';
        button.dataset.id=c.candidate_id;
        button.textContent=c.candidate_id+' · '+
          (c.kind==='parallel_colored_strokes'?'Цветная пара · '+c.orientation:
           c.kind==='rectangular_wall_pair'?'Пара стенок':'Ось и стенки')+
          ' · '+fmt(c.projected_length_pt)+' PDF pt'+
          (c.spatial_group_id?' · '+c.spatial_group_id:'')+
          (c.dimension_text_nearby?' · '+c.dimension_text_nearby.text:'');
        button.addEventListener('click',function(){select(c.candidate_id);});
        list.appendChild(button);
      });
      if(!filteredCandidates.length)text(list,'Нет кандидатов с выбранным фильтром. Это не доказывает отсутствие воздуховодов.');
    }
    if(!filteredCandidates.some(function(c){return c.candidate_id===selected;})){
      selected='';
    }
    select(selected);renderOverlay();
  }
  function load(geometry){
    model=geometry&&geometry.duct_geometry||null;
    var inv=geometry&&geometry.drawing_inventory;
    if(inventoryBox){
      if(!inv)text(inventoryBox,'Проверка всех PDF-путей ещё не выполнялась.');
      else text(inventoryBox,
        'Пути PDF: '+inv.source_paths_total+' всего, '+inv.region_paths_total+
        ' в области; '+inv.selected_paths+' отобрано равномерно по странице с приоритетом цветной графики'+
        (inv.sampling_truncated?' (выборка неполная)':'')+
        '. Цветные штрихи или заливки в области: '+inv.colored_paths_in_region+
        '. Цвета штрихов: '+(inv.stroke_colors_in_region||[]).slice(0,5).map(function(c){
          return c.color+' ('+c.path_count+')';}).join(', ')+
        '. Цвета заливок: '+(inv.fill_colors_in_region||[]).slice(0,5).map(function(c){
          return c.color+' ('+c.path_count+')';}).join(', ')+
        '. Встроенные растровые изображения этим подсчётом не охвачены.');
    }
    var oldOverlay=document.getElementById('cp-vector-overlay');
    if(oldOverlay)oldOverlay.style.display=(model&&(
      (model.trace_network&&model.trace_network.candidates||[]).length||
      (model.candidates||[]).length))?'none':'';
    selected='';assigned=Object.create(null);
    usingTraces=!!(model&&model.trace_network&&
      Array.isArray(model.trace_network.candidates));
    if(methodSelect)methodSelect.value=usingTraces?'traces':'outlines';
    if(colorSelect){
      colorSelect.replaceChildren();
      var all=document.createElement('option');all.value='';all.textContent='Все цвета';
      colorSelect.appendChild(all);
      var seen=Object.create(null);
      var vals=[].concat(model&&model.candidates||[],
        model&&model.trace_network&&model.trace_network.candidates||[]);
      vals.forEach(function(c){
        if(!c.stroke_color||seen[c.stroke_color])return;
        seen[c.stroke_color]=true;
        var option=document.createElement('option');
        option.value=c.stroke_color;option.textContent=c.stroke_color;
        colorSelect.appendChild(option);
      });
    }
    renderCandidates();
    renderLayers();emit();
  }
  function clickPos(e){
    var rect=image.getBoundingClientRect();if(!rect.width||!rect.height)return null;
    return [Math.max(0,Math.min(1,(e.clientX-rect.left)/rect.width)),
            Math.max(0,Math.min(1,(e.clientY-rect.top)/rect.height))];
  }
  function distTo(c,p){
    var a=c.center_start_page_norm,b=c.center_end_page_norm,r=image.getBoundingClientRect();
    if(!validPoint(a)||!validPoint(b)||!r.width||!r.height)return 1e12;
    var ax=a[0]*r.width,ay=a[1]*r.height,bx=b[0]*r.width,by=b[1]*r.height,
        x=p[0]*r.width,y=p[1]*r.height,dx=bx-ax,dy=by-ay,den=dx*dx+dy*dy;
    if(!den)return 1e12;
    var t=Math.max(0,Math.min(1,((x-ax)*dx+(y-ay)*dy)/den));
    return Math.hypot(x-ax-t*dx,y-ay-t*dy);
  }
  modeButton.addEventListener('click',function(){
    if(window.CleanPapperVector)window.CleanPapperVector.setMode('duct');
    var original=document.getElementById('cp-vector-overlay');
    if(original)original.style.display='none';
    visible.checked=true;renderOverlay();
  });
  // The old overlay stays visible when the user explicitly switches to line/crop mode.
  ['cp-vector-crop-mode','cp-vector-select-mode','cp-vector-calibrate-mode'].forEach(function(id){
    var button=document.getElementById(id);
    if(button)button.addEventListener('click',function(){
      var old=document.getElementById('cp-vector-overlay');
      if(old)old.style.display='';
      svg.hidden=true;
    });
  });
  view.addEventListener('pointerup',function(e){
    if(!model||view.hidden||!window.CleanPapperVector||
       window.CleanPapperVector.mode()!=='duct')return;
    var p=clickPos(e);if(!p)return;
    var nearest=null,threshold=16;
    filteredCandidates.forEach(function(c){
      var dist=distTo(c,p);
      if(dist<threshold){threshold=dist;nearest=c;}
    });
    if(nearest)select(nearest.candidate_id);
  });
  visible.addEventListener('change',renderOverlay);
  if(methodSelect)methodSelect.addEventListener('change',function(){
    usingTraces=methodSelect.value==='traces'&&!!(model&&model.trace_network);
    selected='';renderCandidates();
  });
  if(colorSelect)colorSelect.addEventListener('change',function(){
    selected='';renderCandidates();
  });
  saveSystem.addEventListener('click',function(){
    var c=findCandidate(selected);if(!c){text(status,'Сначала выберите участок.');return;}
    var name=(systemInput.value||'').trim().slice(0,60).replace(/[\x00-\x1f\x7f<>]/g,'');
    if(name)assigned[c.stroke_color]=name;
    else delete assigned[c.stroke_color];
    renderLayers();select(selected);emit();
    text(status,'Гипотеза соответствия цвета системе сохранена для этого листа (не подтверждена).');
  });
  window.addEventListener('clean-papper:reset',function(){load(null);});
  window.addEventListener('clean-papper:preview',function(e){load((e.detail||{}).geometry);});
  window.addEventListener('clean-papper:vision',function(e){load((e.detail||{}).geometry);});
  load(null);
})();
