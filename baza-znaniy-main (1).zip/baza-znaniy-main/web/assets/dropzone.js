// Перетаскивание файлов в поля загрузки. Каждое поле выбора файла
// (input type="file") принимает файлы не только через кнопку, но и
// перетаскиванием: блок поля (.field, а если его нет — подпись <label>
// вокруг поля) становится зоной сброса и подсвечивается, пока над ним
// держат файлы. Брошенные файлы проверяются по accept и multiple и
// кладутся в само поле — форма отправляет их как выбранные кнопкой.
// Подсказку «или перетащите файл сюда» под полем ставит этот же скрипт:
// без него перетаскивание не работает, и обещать его незачем.
//
// Подключается в <head> с defer на страницах с полями файла (area, docs,
// equipment, rv, ventspec, verrata). Чат «Альфик» (agent.php) перетаскивание обрабатывает сам (agent.js) —
// его поле здесь пропускается. Если других полей на странице нет, скрипт
// ничего не делает.
(function () {
  if (window.kbDropzone) return;
  window.kbDropzone = true;

  var zones = [];        // {zone, input, msg}
  var active = null;     // зона под курсором
  var dragDepth = 0;     // вход/выход перетаскивания по всей странице

  function el(tag, cls, text) {
    var node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text) node.textContent = text;
    return node;
  }

  // Перетаскивают именно файлы — текст и ссылки (например, в textarea)
  // не трогаем, браузер обработает их как обычно.
  function hasFiles(event) {
    var types = event.dataTransfer && event.dataTransfer.types;
    return !!types && Array.prototype.indexOf.call(types, 'Files') !== -1;
  }

  function skipped(input) {
    return input.classList.contains('agent-sr') || !!input.closest('#agent-form');
  }

  function zoneElement(input) {
    return input.closest('.field') || input.closest('label') || input;
  }

  // accept="…" → список правил: расширения (.pdf) и типы (application/pdf,
  // image/*). Пустой список — подходит любой файл.
  function acceptRules(input) {
    return (input.getAttribute('accept') || '').split(',').map(function (s) {
      return s.trim().toLowerCase();
    }).filter(Boolean);
  }

  function fits(file, rules) {
    if (!rules.length) return true;
    var name = (file.name || '').toLowerCase();
    var type = (file.type || '').toLowerCase();
    for (var i = 0; i < rules.length; i++) {
      var rule = rules[i];
      if (rule.charAt(0) === '.') {
        if (name.length > rule.length && name.slice(-rule.length) === rule) return true;
      } else if (rule.slice(-2) === '/*') {
        if (type.indexOf(rule.slice(0, -1)) === 0) return true;
      } else if (type && type === rule) {
        return true;
      }
    }
    return false;
  }

  // «.xlsx или .xls», «.pdf, .doc, .docx или .xls» — для сообщений.
  function rulesText(rules) {
    if (rules.length < 2) return rules.join('');
    return rules.slice(0, -1).join(', ') + ' или ' + rules[rules.length - 1];
  }

  function quoted(files) {
    return files.map(function (f) { return '«' + f.name + '»'; }).join(', ');
  }

  function showMessage(item, text, kind) {
    item.msg.textContent = text || '';
    item.msg.className = 'dropzone-msg' + (kind ? ' is-' + kind : '');
    item.msg.hidden = !text;
  }

  function fire(input, type) {
    var event;
    try {
      event = new Event(type, {bubbles: true});
    } catch (e) {
      event = document.createEvent('Event');
      event.initEvent(type, true, false);
    }
    input.dispatchEvent(event);
  }

  function setActive(item) {
    if (active === item) return;
    if (active) active.zone.classList.remove('is-dragover');
    active = item;
    if (active) active.zone.classList.add('is-dragover');
  }

  // Пока файл тащат над страницей, все доступные зоны чуть подсвечены —
  // видно, куда его можно бросить.
  function setReady(on) {
    zones.forEach(function (item) {
      item.zone.classList.toggle('is-dragready', on && !item.input.disabled);
    });
  }

  function reset() {
    dragDepth = 0;
    setActive(null);
    setReady(false);
  }

  function itemFor(target) {
    for (var node = target; node && node.nodeType === 1; node = node.parentNode) {
      for (var i = 0; i < zones.length; i++) {
        if (zones[i].zone === node) return zones[i].input.disabled ? null : zones[i];
      }
    }
    return null;
  }

  // Брошенные файлы → в поле. Неподходящие по формату не берутся; в поле
  // на один файл попадает только первый подходящий. Поле заменяет
  // прежний выбор — так же, как при выборе кнопкой.
  function take(item, fileList) {
    var input = item.input;
    var dropped = Array.prototype.slice.call(fileList || []);
    if (!dropped.length) return;
    var rules = acceptRules(input);
    var good = dropped.filter(function (f) { return fits(f, rules); });
    var bad = dropped.filter(function (f) { return !fits(f, rules); });
    var notes = [];

    if (bad.length) {
      notes.push((bad.length === 1 ? 'Файл ' + quoted(bad) + ' не подходит' : 'Не подходят ' + quoted(bad)) +
        ' — нужен ' + rulesText(rules) + '.');
    }
    if (!good.length) {
      showMessage(item, notes.join(' ') + (input.files && input.files.length ? ' Выбранное раньше осталось.' : ''), 'error');
      return;
    }
    if (!input.multiple && good.length > 1) {
      var extra = good.slice(1);
      good = good.slice(0, 1);
      notes.push('В это поле — только один файл: взят «' + good[0].name + '», ' +
        (extra.length === 1 ? quoted(extra) + ' не приложен.' : 'остальные (' + extra.length + ') не приложены.'));
    }

    try {
      if (good.length === dropped.length) {
        input.files = fileList;
      } else {
        var dt = new DataTransfer();
        good.forEach(function (f) { dt.items.add(f); });
        input.files = dt.files;
      }
    } catch (e) {
      showMessage(item, 'Этот браузер не умеет класть перетащенные файлы в поле — выберите их кнопкой.', 'error');
      return;
    }
    // Как при выборе кнопкой: страница узнаёт о новых файлах (например,
    // docs.php прячет «Название», если файлов несколько).
    fire(input, 'input');
    fire(input, 'change');
    showMessage(item, notes.join(' '), 'warning');
  }

  function init() {
    var inputs = document.querySelectorAll('input[type="file"]');
    for (var i = 0; i < inputs.length; i++) {
      var input = inputs[i];
      if (skipped(input)) continue;
      var zone = zoneElement(input);
      // Одна зона — одно поле: если в блоке два поля, зоной служит само поле.
      if (zone !== input && zone.querySelectorAll('input[type="file"]').length > 1) zone = input;
      zone.classList.add('dropzone');
      zone.setAttribute('data-drop-text', input.multiple ?
        'Отпустите, чтобы приложить файлы' : 'Отпустите, чтобы приложить файл');

      // Подсказка и место для сообщений — сразу под полем. Тег span: поле
      // бывает внутри <label>, а там абзацы не допускаются.
      var hint = el('span', 'hint dropzone-hint', input.multiple ?
        'или перетащите файлы сюда' : 'или перетащите файл сюда');
      var msg = el('span', 'dropzone-msg');
      msg.hidden = true;
      msg.setAttribute('role', 'status');
      input.parentNode.insertBefore(msg, input.nextSibling);
      input.parentNode.insertBefore(hint, msg);

      var item = {zone: zone, input: input, msg: msg};
      zones.push(item);
      // Новый выбор кнопкой снимает прежнее сообщение.
      input.addEventListener('change', (function (it) {
        return function () { showMessage(it, ''); };
      })(item));
    }
    if (!zones.length) return;

    document.addEventListener('dragenter', function (event) {
      if (!hasFiles(event)) return;
      event.preventDefault();
      dragDepth += 1;
      setReady(true);
      setActive(itemFor(event.target));
    });
    document.addEventListener('dragover', function (event) {
      if (!hasFiles(event)) return;
      // Без preventDefault браузер открыл бы брошенный файл вместо страницы.
      event.preventDefault();
      var item = itemFor(event.target);
      setActive(item);
      if (event.dataTransfer) event.dataTransfer.dropEffect = item ? 'copy' : 'none';
    });
    document.addEventListener('dragleave', function (event) {
      if (!hasFiles(event)) return;
      dragDepth = Math.max(0, dragDepth - 1);
      // Курсор ушёл за пределы окна.
      if (!dragDepth) reset();
    });
    document.addEventListener('drop', function (event) {
      if (!hasFiles(event)) return;
      event.preventDefault();
      var item = itemFor(event.target);
      reset();
      if (item) take(item, event.dataTransfer.files);
    });
    // Перетаскивание отменили (Esc) — подсветку снимаем.
    document.addEventListener('dragend', reset);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', init);
  } else {
    init();
  }
})();
