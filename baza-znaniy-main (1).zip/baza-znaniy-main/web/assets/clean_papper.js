(function () {
  'use strict';
  var form = document.getElementById('cp-api-form');
  var result = document.getElementById('cp-api-result');
  var model = document.getElementById('cp-api-model');
  var testStatus = document.getElementById('cp-api-test-status');
  if (!form || !result) return;

  form.addEventListener('click', async function (event) {
    var button = event.target.closest('button[data-action]');
    if (!button || !form.contains(button)) return;
    event.preventDefault();
    var buttons = Array.prototype.slice.call(form.querySelectorAll('button[data-action]'));
    buttons.forEach(function (el) { el.disabled = true; });
    result.textContent = 'Проверяем соединение на сервере…';
    result.setAttribute('role', 'status');
    try {
      var data = new FormData(form);
      data.set('action', button.getAttribute('data-action'));
      var response = await fetch('clean_papper_api.php', {
        method: 'POST', body: data, credentials: 'same-origin',
        headers: { 'Accept': 'application/json' }
      });
      var payload = await response.json();
      if (!payload || typeof payload.message !== 'string') throw new Error('bad payload');
      result.textContent = payload.message;
      if (payload.ok) {
        if (model) model.textContent = payload.model || 'Определяется сервером';
        if (testStatus) {
          testStatus.textContent = payload.live_verified
            ? 'Соединение подтверждено (' + (payload.input_tokens || 0) + ' входящих / ' +
              (payload.output_tokens || 0) + ' исходящих токенов)'
            : 'Настройки прочитаны, API пока не проверен';
        }
      } else if (testStatus) {
        testStatus.textContent = 'Проверка не пройдена';
      }
    } catch (e) {
      result.textContent = 'Не удалось получить ответ сервера. Проверьте соединение и обновите страницу.';
      if (testStatus) testStatus.textContent = 'Проверка не пройдена';
    } finally {
      buttons.forEach(function (el) { el.disabled = false; });
    }
  });
})();
