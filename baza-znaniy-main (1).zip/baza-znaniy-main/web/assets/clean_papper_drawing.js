(function () {
  'use strict';
  var form = document.getElementById('cp-drawing-form');
  if (!form) return;
  var file = document.getElementById('cp-drawing-file');
  var page = document.getElementById('cp-drawing-page');
  var crop = document.getElementById('cp-drawing-crop');
  var profile = document.getElementById('cp-profile-json');
  var consent = document.getElementById('cp-vision-consent');
  var diagnosticButton = document.getElementById('cp-diagnostic-run');
  var diagnosticResult = document.getElementById('cp-diagnostic-result');
  var previewButton = document.getElementById('cp-preview-run');
  var albumButton = document.getElementById('cp-album-run');
  var albumReview = document.getElementById('cp-album-review');
  var albumResult = document.getElementById('cp-album-result');
  var activeAlbum = null;
  var visionButton = document.getElementById('cp-vision-run');
  var clearButton = document.getElementById('cp-selection-clear');
  var image = document.getElementById('cp-drawing-image');
  var view = document.getElementById('cp-drawing-view');
  var highlight = document.getElementById('cp-drawing-selection');
  var state = document.getElementById('cp-drawing-status');
  var geo = document.getElementById('cp-drawing-geometry');
  var vision = document.getElementById('cp-drawing-vision');
  var pages = document.getElementById('cp-drawing-pages');
  var cropText = document.getElementById('cp-crop-caption');
  var lastPreview = null;
  var previewMeta = null;
  var activeOperation = null;
  var monitor = document.getElementById('cp-processing-monitor');
  var monitorTitle = document.getElementById('cp-processing-title');
  var monitorTime = document.getElementById('cp-processing-time');
  var monitorStage = document.getElementById('cp-processing-stage');
  var monitorBar = document.getElementById('cp-processing-bar');
  var monitorBeat = document.getElementById('cp-processing-heartbeat');
  var monitorStarted = 0, monitorPhaseStarted = 0, monitorTimer = null, monitorLast = 0, monitorKind = '', monitorToken = null;
  var monitorSerial = 0;
  function duration(ms) {
    var seconds = Math.max(0, Math.floor(ms / 1000));
    return String(Math.floor(seconds / 60)).padStart(2, '0') + ':' + String(seconds % 60).padStart(2, '0');
  }
  function refreshMonitor() {
    text(monitorTime, duration(Date.now() - monitorStarted));
    var age = monitorLast ? Date.now() - monitorLast : Date.now() - monitorPhaseStarted;
    if (monitorKind === 'upload') {
      text(monitorBeat, monitorLast ? 'Последняя подтверждённая часть: ' + duration(age) + ' назад.' : 'Ожидание подтверждения загрузки.');
    } else if (monitorKind === 'worker') {
      text(monitorBeat, monitorLast ? 'Последний сигнал обработчика: ' + duration(age) + ' назад.' : 'Ожидаем первый сигнал обработчика.');
    } else {
      text(monitorBeat, 'Ожидаем ответ сервера. Ход вычислений пока неизвестен.');
    }
    if (age > 20000) {
      monitor.dataset.state = 'uncertain';
      text(monitorBeat, monitorBeat.textContent + ' Сигнал задерживается; результат пока неизвестен.');
    } else {
      monitor.dataset.state = 'running';
    }
  }
  function startMonitor(title, message) {
    ++monitorSerial;
    clearInterval(monitorTimer);
    monitor.hidden = false;
    monitorStarted = Date.now(); monitorPhaseStarted = monitorStarted; monitorLast = 0; monitorKind = 'upload'; monitorToken = null;
    text(monitorTitle, title); monitorStageUpdate(message, 0);
    monitorTimer = setInterval(refreshMonitor, 1000);
    refreshMonitor();
  }
  function monitorStageUpdate(message, value) {
    text(monitorStage, message);
    monitorBar.hidden = false;
    if (typeof value === 'number' && Number.isFinite(value)) monitorBar.value = Math.min(100, Math.max(0, value));
    else monitorBar.removeAttribute('value');
  }
  function monitorSignal(kind, timestamp, serverNow) {
    monitorKind = kind;
    if (typeof timestamp === 'number' && Number.isFinite(timestamp) && timestamp > 0) monitorLast = Date.now() - Math.max(0, ((Number(serverNow) || Date.now()/1000) - timestamp) * 1000);
    refreshMonitor();
  }
  function monitorWaiting(message) {
    monitorKind = 'waiting'; monitorLast = 0; monitorPhaseStarted = Date.now();
    monitorStageUpdate(message);
    refreshMonitor();
  }
  function finishMonitor(success, message, uncertain) {
    ++monitorSerial; monitorToken = null;
    clearInterval(monitorTimer); monitorTimer = null;
    monitor.dataset.state = success ? 'done' : uncertain ? 'uncertain' : 'error';
    monitorBar.hidden = !success;
    if (success) monitorBar.value = 100;
    text(monitorTime, duration(Date.now() - monitorStarted));
    text(monitorStage, message);
    text(monitorBeat, success ? 'Получен окончательный результат сервера.' : uncertain ? 'Состояние задания неизвестно; оно может продолжаться на сервере.' : 'Операция не завершена успешно. Проверьте сообщение в соответствующем блоке.');
  }
  async function fetchStatus(url) {
    var controller = new AbortController();
    var timer = setTimeout(function () { controller.abort(); }, 8000);
    try {
      var response = await fetch(url, {credentials:'same-origin', cache:'no-store', signal:controller.signal});
      return {response:response, result:await response.json()};
    } finally { clearTimeout(timer); }
  }
  function watchPdfWorker(token, message) {
    monitorWaiting(message);
    monitorKind = 'worker'; monitorToken = token;
    var serial = monitorSerial;
    (async function () {
      while (monitorSerial === serial && monitorToken === token) {
        try {
          var reply = await fetchStatus('clean_papper_pdf.php?status=' + encodeURIComponent(token));
          if (monitorSerial !== serial || monitorToken !== token) return;
          if (reply.response.ok && reply.result.ok && reply.result.phase === 'running') {
            monitorSignal('worker', Number(reply.result.updated), reply.result.server_time);
          }
        } catch (error) { /* The main request determines success or failure. */ }
        await new Promise(function (resolve) { setTimeout(resolve, 2500); });
      }
    })();
  }
  function notifyReport(name, detail) {
    window.dispatchEvent(new CustomEvent('clean-papper:' + name, {detail: detail || {}}));
  }
  var localLabels = [];
  var start = null;

  function key() {
    var f = file.files[0];
    return f ? [f.name, f.size, f.lastModified, page.value, profile.value].join(':') : null;
  }
  function text(el, value) { if (el) el.textContent = value; }
  function clear(el) { if (el) el.replaceChildren(); }
  var problemGroups = Object.create(null);
  var problemStarted = false;
  var problemSummary = document.getElementById('cp-problem-summary');
  var problemList = document.getElementById('cp-problem-list');
  var problemDownload = document.getElementById('cp-problem-download');
  function reportProblems(group, messages) {
    problemStarted = true;
    problemGroups[group] = Array.from(new Set((messages || []).filter(Boolean).map(String)));
    renderProblems();
  }
  function problemRows() {
    var rows = [];
    Object.keys(problemGroups).forEach(function (stage) {
      problemGroups[stage].forEach(function (message) { rows.push({stage: stage, message: message}); });
    });
    return rows;
  }
  function renderProblems() {
    var rows = problemRows();
    clear(problemList);
    rows.forEach(function (row) {
      var li = document.createElement('li');
      li.textContent = row.stage + ': ' + row.message;
      problemList.appendChild(li);
    });
    text(problemSummary, !problemStarted ? 'Обработка ещё не запускалась.' :
      rows.length ? 'Замечаний: ' + rows.length : 'По текущим данным замечаний нет. Это не подтверждает завершение всех этапов.');
    problemDownload.disabled = !problemStarted;
  }
  problemDownload.addEventListener('click', function () {
    var selected = file.files[0];
    downloadAlbumJson('clean-papper-problems.json', {
      schema: 'clean-papper.processing-problems.v1',
      filename: selected ? selected.name : null,
      generated_at: new Date().toISOString(),
      stages: Object.keys(problemGroups),
      problems: problemRows()
    });
  });
  file.addEventListener('change', function () {
    problemGroups = Object.create(null);
    problemStarted = false;
    renderProblems();
    text(document.getElementById('cp-spec-register'), '');
    text(document.getElementById('cp-spec-candidates'), '');
    text(document.getElementById('cp-spec-status'), '');
    document.getElementById('cp-spec-first').value = '';
    document.getElementById('cp-spec-last').value = '';
    document.getElementById('cp-album-totals').hidden = true;
    clear(document.getElementById('cp-calculation-rows'));
  });
  function reportAlbumProblems(data) {
    var messages = [];
    var counts = data.page_kind_counts || {};
    var specRanges = (data.specification_inventory || {}).candidates || [];
    var specRange = specRanges.length === 1 ? specRanges[0] : null;
    if (counts.unclassified) {
      var pages = (data.pages || []).filter(function (item) { return item.kind === 'unclassified' && !(specRange && item.pdf_page >= specRange.first && item.pdf_page <= specRange.last); })
        .map(function (item) { return item.pdf_page; });
      if (pages.length) messages.push('Не классифицировано вне предполагаемого диапазона спецификации: ' + pages.length + ' (страницы ' + pages.join(', ') + ').');
    }
    var profileWarnings = document.getElementById('cp-project-profile-warnings');
    if (!document.getElementById('cp-project-profile').hidden) {
      Array.from(profileWarnings.children).forEach(function (li) { messages.push(li.textContent); });
      var recovery = (data.project_profile || {}).text_recovery_summary || {};
      if ((recovery.pages_without_text || []).length) messages.push('Нет извлекаемого текста на страницах: ' + recovery.pages_without_text.join(', ') + '. OCR не выполнялся.');
    }
    var rules = data.project_rules || {};
    if (rules.double_count_risk) messages.push(document.getElementById('cp-rules-risk').textContent);
    var totals = (data.calculation || {}).totals || {};
    if (totals.review_required_segments) messages.push('Участков, требующих инженерной проверки: ' + totals.review_required_segments + '.');
    reportProblems('Распознавание проекта', messages);
    var candidates = (data.specification_inventory || {}).candidates || [];
    reportProblems('Определение спецификации', candidates.length === 1 ? [] : [
      candidates.length ? 'Найдено несколько диапазонов; требуется выбор инженера.' : 'Диапазон спецификации не определён автоматически.'
    ]);
  }
  function buttonState(disabled) {
    previewButton.disabled = disabled;
    visionButton.disabled = disabled;
    clearButton.disabled = disabled;
    if (albumButton) albumButton.disabled = disabled || !file.files[0] || file.files[0].size === 0 || file.files[0].size > 100 * 1024 * 1024;
    file.disabled = disabled;
    specButtons(disabled);
  }
  function blankSelection() {
    notifyReport('reset');
    crop.value = '';
    cropText.textContent = 'Выделение не выбрано — отправится вся страница.';
    highlight.hidden = true;
    highlight.style.width = '0';
    highlight.style.height = '0';
  }
  function reset() {
    lastPreview = null;
    previewMeta = null;
    localLabels = [];
    notifyReport('reset');
    image.removeAttribute('src');
    view.hidden = true;
    text(pages, '');
    text(geo, 'Геометрический анализ появится после предпросмотра.');
    clear(vision);
    blankSelection();
    text(state, 'Выберите PDF и нажмите «Обработать альбом».');
  }
  file.addEventListener('change', reset);
  function showFileSelection() {
    activeAlbum = null;
    if (albumResult) albumResult.hidden = true;
    clear(specDownloads);
    specButtons(false);
    var chosen = file.files[0];
    text(document.getElementById('cp-selected-file'), chosen ?
      chosen.name + ' · ' + (chosen.size / (1024 * 1024)).toFixed(1) + ' МБ' : 'PDF пока не выбран.');
    if (albumButton) albumButton.disabled = !chosen || !chosen.size || chosen.size > 100 * 1024 * 1024;
    if (!activeAlbum) setStage('file');
    text(runPhase, !chosen ? 'Выберите файл, чтобы начать.' :
      chosen.size > 100 * 1024 * 1024 ? 'Размер PDF превышает 100 МБ. Выберите другой файл.' :
      'Файл выбран. Можно запустить обработку.');
    uploadProgress.hidden = true;
  }
  file.addEventListener('change', showFileSelection);
  if (albumResult) file.addEventListener('change', function () {
    activeAlbum = null;
    albumResult.hidden = true;
    albumReview.value = '';
  });
  window.addEventListener('clean-papper:profile-changed', reset);
  page.addEventListener('change', reset);
  page.addEventListener('input', reset);

  async function decodeReply(response) {
    var payload;
    try {
      payload = await response.json();
    } catch (e) {
      return {ok: false, message: response.status === 413
        ? 'Сервер отклонил большой файл (HTTP 413). Уменьшите PDF или проверьте лимиты хостинга.'
        : 'Сервер вернул не JSON (HTTP ' + response.status + '). Возможно, сессия истекла или запрос заблокирован.'};
    }
    if (!payload || typeof payload !== 'object') {
      return {ok: false, message: 'Сервер вернул пустой ответ (HTTP ' + response.status + ').'};
    }
    return payload;
  }
  if (diagnosticButton) {
    diagnosticButton.addEventListener('click', async function () {
      diagnosticButton.disabled = true;
      text(diagnosticResult, 'Проверяем серверный Python и работу PyMuPDF…');
      try {
        var payload = new FormData();
        var csrf = form.querySelector('input[name="csrf"]');
        payload.set('csrf', csrf ? csrf.value : '');
        payload.set('mode', 'diagnostic');
        var response = await fetch('clean_papper_pdf.php', {
          method: 'POST', body: payload, credentials: 'same-origin',
          headers: {Accept: 'application/json'}
        });
        var data = await decodeReply(response);
        if (data.ok) {
          text(diagnosticResult, 'Обработчик исправен: Python ' + data.python_version +
            ', PyMuPDF ' + data.pymupdf_version + ', JPEG: OK. Лимиты PHP: файл ' +
            data.php_upload_max + ', POST ' + data.php_post_max + '.');
        } else {
          text(diagnosticResult, 'Проверка обработчика: ' +
            (data.message || 'Сервер не дал подробного ответа.'));
        }
      } catch (e) {
        text(diagnosticResult, 'Нет ответа от диагностического запроса. Проверьте соединение или сессию сайта.');
      } finally {
        diagnosticButton.disabled = false;
      }
    });
  }


  function showSpatialInventory(info) {
    var s = info.spatial_inventory;
    if (!s || !Array.isArray(s.tiles)) return;
    var panel = document.createElement('details');
    panel.className = 'cp-spatial-inventory';
    panel.open = !!info.sampling_limited;
    var heading = document.createElement('summary');
    heading.textContent = 'Полная опись графики по областям';
    panel.appendChild(heading);
    var stats = document.createElement('p');
    stats.textContent = 'Просмотрено путей: ' + s.source_paths_examined.toLocaleString('ru-RU') +
      '; в области: ' + s.region_paths_located.toLocaleString('ru-RU') +
      '; вне области: ' + s.outside_paths + '; без координат: ' + s.unlocated_paths +
      '. Областей сверх порогов: ' + s.tiles_requiring_subdivision + '.';
    panel.appendChild(stats);
    var note = document.createElement('p');
    note.className = 'hint';
    note.textContent = 'Ячейки показывают пересечения ограничивающих прямоугольников путей. Один длинный путь может попасть в несколько ячеек. ' +
      'Это опись, а не полный обмер: прежние геометрические кандидаты по-прежнему ограничены выборкой и допусками.';
    panel.appendChild(note);
    if (s.legacy_detector_rotation_review_required) {
      var warning = document.createElement('p');
      warning.className = 'hint';
      warning.textContent = 'Исходная страница повёрнута на ' + s.source_page_rotation_deg +
        '°. Карта построена в исходных неповёрнутых координатах PDF. Совпадение старой геометрии с предпросмотром требует отдельной проверки.';
      panel.appendChild(warning);
    }
    var max = Math.max(1, ...s.tiles.map(function (t) { return t.intersecting_paths; }));
    var table = document.createElement('table');
    table.className = 'cp-spatial-grid';
    table.setAttribute('aria-label', 'Число пересекающих путей по ячейкам исходной области PDF');
    for (var row = 1; row <= s.grid; row++) {
      var tr = document.createElement('tr');
      s.tiles.filter(function (t) { return t.row === row; }).forEach(function (t) {
        var td = document.createElement('td');
        td.textContent = t.intersecting_paths.toLocaleString('ru-RU');
        td.style.setProperty('--cp-density', String(Math.sqrt(t.intersecting_paths / max)));
        if (t.requires_subdivision) td.classList.add('cp-spatial-over-budget');
        td.title = t.id + ': ' + t.bbox_pdf_pt.map(function(v) { return v.toFixed(1); }).join(', ') +
          ' PDF pt; уникально назначено: ' + t.owned_paths +
          '; верхняя оценка элементов: ' + t.path_items_upper_bound +
          (t.requires_subdivision ? '; требуется деление' : '');
        tr.appendChild(td);
      });
      table.appendChild(tr);
    }
    panel.appendChild(table);
    var btn = document.createElement('button');
    btn.type = 'button';
    btn.className = 'secondary';
    btn.textContent = 'Скачать карту областей JSON';
    btn.addEventListener('click', function () {
      downloadAlbumJson('clean-papper-spatial-page-' + page.value + '.json', s);
    });
    panel.appendChild(btn);
    geo.appendChild(panel);
  }

  function summaryList(info) {
    clear(geo);
    var intro = document.createElement('p');
    intro.textContent = 'Векторных графических путей в выборке: ' +
      info.vector_paths_sampled + ' (цветных: ' + info.colored_paths_sampled + ')' +
      (info.sampling_limited ? '. Выборка ограничена.' : '.');
    geo.appendChild(intro);
    showSpatialInventory(info);
    var labels = info.section_text_candidates || [];
    localLabels = labels.map(function (x) { return String(x.text || ''); });
    var heading = document.createElement('p');
    heading.textContent = 'Кандидаты подписей сечений: ' + labels.length + '.';
    geo.appendChild(heading);
    var list = document.createElement('ul');
    labels.slice(0, 25).forEach(function (item) {
      var li = document.createElement('li');
      li.textContent = String(item.text || '') + ' — PDF ' +
        (item.at_pdf_pt || []).join(', ') + ' pt';
      list.appendChild(li);
    });
    geo.appendChild(list);
    var note = document.createElement('p');
    note.className = 'hint';
    note.textContent = 'Это диагностические примитивы, не количество метров.';
    geo.appendChild(note);
  }
  function normalized(s) {
    return String(s || '').toLowerCase().replace(/\s+/g, '')
      .replace(/[xх×]/g, 'x').replace(/[ø⌀]/g, 'ø');
  }
  function displayVision(info) {
    clear(vision);
    var heading = document.createElement('p');
    heading.textContent = 'Модель: ' + (info.model || '?') + ', ' +
      (info.input_tokens || 0) + ' входящих / ' +
      (info.output_tokens || 0) + ' исходящих токенов.';
    vision.appendChild(heading);
    var elements = info.elements || [];
    if (!elements.length) {
      var empty = document.createElement('p');
      empty.textContent = 'ИИ не вернул распознанных элементов.';
      vision.appendChild(empty);
    } else {
      var table = document.createElement('table');
      table.className = 'cp-results-table';
      var head = document.createElement('thead');
      var tr = document.createElement('tr');
      ['Тип','Описание','Сечение','Система','Уверенность','Сверка PDF'].forEach(function (label) {
        var th = document.createElement('th'); th.textContent = label; tr.appendChild(th);
      });
      head.appendChild(tr); table.appendChild(head);
      var tbody = document.createElement('tbody');
      elements.forEach(function (item) {
        var row = document.createElement('tr');
        var dimension = normalized(item.dimension);
        var found = dimension && localLabels.some(function (x) { return normalized(x) === dimension; });
        [item.type, item.label, item.dimension, item.system, item.confidence,
         dimension ? (found ? 'Текст найден¹' : 'Нет текстового подтверждения') : 'Без сечения'
        ].forEach(function (v) {
          var td = document.createElement('td'); td.textContent = String(v || '—'); row.appendChild(td);
        });
        if (item.note) row.title = item.note;
        tbody.appendChild(row);
      });
      table.appendChild(tbody);
      var scroller = document.createElement('div');
      scroller.className = 'cp-results-scroll';
      scroller.appendChild(table); vision.appendChild(scroller);
    }
    var notes = document.createElement('p');
    notes.className = 'hint';
    notes.textContent = '¹ Совпадение текста в PDF — только дополнительный признак, не подтверждение объекта. Результаты ИИ требуют проверки инженера.';
    vision.appendChild(notes);
    (info.notes || []).forEach(function (line) {
      var p = document.createElement('p'); p.textContent = '• ' + String(line); vision.appendChild(p);
    });
  }

  // Each request stays below the server's 2 MB PHP upload limit.
  // The assembled file is session-owned, temporary and never web accessible.
  async function postUpload(data) {
    var response = await fetch('clean_papper_upload.php', {
      method: 'POST', body: data, credentials: 'same-origin',
      headers: { Accept: 'application/json' }
    });
    var result = await decodeReply(response);
    if (!result.ok) throw new Error(result.message || 'Не удалось загрузить PDF.');
    return result;
  }
  function authFields() {
    var data = new FormData();
    var csrf = form.querySelector('input[name="csrf"]');
    data.set('csrf', csrf ? csrf.value : '');
    return data;
  }
  async function cancelUpload(uploadId) {
    if (!uploadId) return;
    try {
      var data = authFields();
      data.set('action', 'cancel');
      data.set('upload_id', uploadId);
      await postUpload(data);
    } catch (e) {
      // Temporary incomplete files are also removed by server-side TTL cleanup.
    }
  }
  async function uploadInParts(f, initialKey, currentKey) {
    var data = authFields();
    data.set('action', 'init');
    data.set('file_name', f.name);
    data.set('file_size', String(f.size));
    var created = await postUpload(data);
    monitorSignal('upload', Date.now()/1000);
    var uploadId = created.upload_id;
    var chunkBytes = Number(created.chunk_bytes);
    if (!uploadId || !Number.isInteger(chunkBytes) || chunkBytes < 1 || chunkBytes > 1048576) {
      throw new Error('Сервер вернул неверные параметры загрузки.');
    }
    try {
      for (var offset = 0; offset < f.size;) {
        if (currentKey() !== initialKey) throw new Error('Параметры загрузки изменились. Повторите загрузку.');
        var end = Math.min(f.size, offset + chunkBytes);
        var body = authFields();
        body.set('action', 'chunk');
        body.set('upload_id', uploadId);
        body.set('offset', String(offset));
        body.set('part', f.slice(offset, end), 'part.bin');
        var answer = await postUpload(body);
        if (Number(answer.received) !== end) {
          throw new Error('Ошибка порядка частей PDF. Начните загрузку заново.');
        }
        offset = end;
        monitorSignal('upload', Date.now()/1000);
        monitorStageUpdate('Загрузка PDF: ' + Math.round(offset / f.size * 100) + '% (' +
          (offset / 1048576).toFixed(1) + ' из ' + (f.size / 1048576).toFixed(1) + ' МБ)', offset / f.size * 100);
        if (activeOperation === 'album') showRunPhase('Загрузка PDF: ' + Math.round(offset / f.size * 100) + '%', offset / f.size * 100);
        text(state, 'Загружаем PDF частями: ' +
          Math.round(offset / f.size * 100) + '% (' +
          (offset / (1024*1024)).toFixed(1) + ' из ' +
          (f.size / (1024*1024)).toFixed(1) + ' МБ).');
      }
      return uploadId;
    } catch (e) {
      await cancelUpload(uploadId);
      throw e;
    }
  }


  var statementButton = document.getElementById('cp-statement-run');
  var statementStatus = document.getElementById('cp-statement-status');
  var statementDownloads = document.getElementById('cp-statement-downloads');
  var statementStorage = 'cleanpapper-statement-job';

  async function watchStatement(job, autoDownload) {
    var url = 'clean_papper_statement.php?job=' + encodeURIComponent(job);
    var lastContact = Date.now();
    for (;;) {
      var reply;
      try { reply = await fetchStatus(url); }
      catch (error) {
        if (Date.now() - lastContact > 60000) throw new Error('Сервер не отвечает более минуты. Состояние задания неизвестно; обновите страницу для повторной проверки.');
        await new Promise(function (resolve) { setTimeout(resolve, 2500); });
        continue;
      }
      var response = reply.response, result = reply.result;
      if (response.status === 503) {
        if (Date.now() - lastContact > 60000) throw new Error('Не удалось получить статус. Обновите страницу для повторной проверки.');
        await new Promise(function (resolve) { setTimeout(resolve, 2500); });
        continue;
      }
      lastContact = Date.now();
      if (!response.ok || result.phase === 'failed') {
        sessionStorage.removeItem(statementStorage);
        throw new Error(result.message || 'Расчёт недоступен.');
      }
      if (result.started > 0) monitorStarted = Date.now() - Math.max(0, ((Number(result.server_time) || Date.now()/1000) - Number(result.started))*1000);
      monitorSignal('worker', Number(result.heartbeat), result.server_time);
      if (result.phase === 'done') {
        var issues = Array.isArray(result.issues) ? result.issues.slice() : [];
        if (!result.atlas) issues.push('Атлас с разметкой не сформирован.');
        reportProblems('Автоматический просчёт', issues);
        clear(statementDownloads);
        [['statement','Скачать ведомость Excel'], ['atlas','Скачать чертежи PDF']].forEach(function (item) {
          if (item[0] === 'atlas' && !result.atlas) return;
          var link = document.createElement('a');
          link.href = url + '&download=' + item[0];
          link.textContent = item[1];
          link.setAttribute('download', '');
          statementDownloads.appendChild(link);
          if (autoDownload && item[0] === 'statement') link.click();
        });
        finishMonitor(true, 'Ведомость сформирована.');
        if (result.started > 0 && result.updated >= result.started) text(monitorTime, duration((result.updated - result.started)*1000));
        text(statementStatus, 'Готово. Страниц в альбоме: ' + result.pages + '. ' + (typeof result.preliminary_count === 'number' ? 'Предварительных участков: ' + result.preliminary_count + '; с оценкой длины: ' + result.preliminary_measured + '. ' : '') + (typeof result.design_rows === 'number' ? 'Строк проектной спецификации: ' + result.design_rows + '. ' : '') + (typeof result.fitting_count === 'number' ? 'Кандидатов фасонки: ' + result.fitting_count + '. ' : '') + (result.claude_pages ? 'Claude проверил листов: ' + result.claude_pages + '. ' : '') + (issues.length ? 'Есть замечания в общем отчёте. ' : '') + 'Если скачивание не началось, используйте ссылку ниже.');
        return;
      }
      text(statementStatus, result.message || 'Выполняется расчёт…');
      monitorStageUpdate(statementStatus.textContent, Number(result.total) > 0 ? Number(result.completed) / Number(result.total) * 100 : undefined);
      await new Promise(function (resolve) { setTimeout(resolve, 2500); });
    }
  }
  if (statementButton) {
    var claudeOptIn = document.getElementById('cp-statement-claude');
    claudeOptIn.checked = sessionStorage.getItem('cleanpapper-claude-consent') === 'yes';
    claudeOptIn.addEventListener('change', function () { sessionStorage.setItem('cleanpapper-claude-consent', claudeOptIn.checked ? 'yes' : 'no'); });
    statementButton.addEventListener('click', async function () {
      if (activeOperation) return;
      var pdf = file.files[0], reference = document.getElementById('cp-reference-file').files[0];
      var review = document.getElementById('cp-statement-review').files[0];
      if (!pdf || !pdf.size || pdf.size > 100*1024*1024 || (reference && reference.size > 2097152) || (review && review.size > 2097152)) {
        text(statementStatus, 'Выберите PDF до 100 МБ. Дополнительные книги Excel (если выбраны) должны быть до 2 МБ каждая.');
        reportProblems('Автоматический просчёт', [statementStatus.textContent]); return;
      }
      var uploadId;
      reportProblems('Автоматический просчёт', []);
      activeOperation = 'statement'; buttonState(true); statementButton.disabled = true; claudeOptIn.disabled = true;
      startMonitor('Автоматический просчёт', 'Подготавливаем загрузку PDF…');
      clear(statementDownloads); text(statementStatus, 'Загружается альбом…');
      try {
        uploadId = await uploadInParts(pdf, pdf, function () { return file.files[0]; });
        var payload = authFields();
        payload.set('upload_id', uploadId);
        if (reference) payload.set('reference', reference);
        if (review) payload.set('review', review);
        if (document.getElementById('cp-statement-claude').checked) payload.set('claude_consent', 'yes');
        monitorWaiting('Запуск серверного расчёта…');
        var response = await fetch('clean_papper_statement.php', {method:'POST', body:payload, credentials:'same-origin'});
        var result = await response.json();
        if (!response.ok || !result.job) throw new Error(result.message || 'Не удалось запустить расчёт.');
        uploadId = null;
        sessionStorage.setItem(statementStorage, result.job);
        monitorKind = 'worker'; monitorLast = 0; monitorPhaseStarted = Date.now();
        await watchStatement(result.job, true);
      } catch (error) {
        text(statementStatus, error.message || 'Ошибка связи.');
        finishMonitor(false, statementStatus.textContent, !!sessionStorage.getItem(statementStorage));
        reportProblems('Автоматический просчёт', [statementStatus.textContent]);
      } finally {
        if (uploadId) await cancelUpload(uploadId);
        activeOperation = null; buttonState(false); statementButton.disabled = false; claudeOptIn.disabled = false;
      }
    });
    var lastJob = sessionStorage.getItem(statementStorage);
    if (lastJob) {
      statementButton.disabled = true;
      Promise.resolve().then(function () {
        activeOperation = 'statement'; buttonState(true); claudeOptIn.disabled = true;
        startMonitor('Автоматический просчёт', 'Восстанавливаем состояние задания…');
        monitorKind = 'worker';
        return watchStatement(lastJob);
      }).catch(function (error) {
        text(statementStatus, error.message); finishMonitor(false, statementStatus.textContent, !!sessionStorage.getItem(statementStorage));
        reportProblems('Автоматический просчёт', [statementStatus.textContent]);
      }).finally(function () {
        activeOperation = null; buttonState(false); statementButton.disabled = false; claudeOptIn.disabled = false;
      });
    }
  }

  function setStage(stage) {
    var sequence = ['file', 'processing', 'results'];
    var selected = sequence.indexOf(stage);
    document.querySelectorAll('[data-cp-step]').forEach(function (item) {
      var current = sequence.indexOf(item.getAttribute('data-cp-step'));
      item.classList.toggle('is-current', current === selected);
      item.classList.toggle('is-complete', current >= 0 && current < selected);
      if (current === selected) item.setAttribute('aria-current', 'step');
      else item.removeAttribute('aria-current');
    });
  }
  var uploadProgress = document.getElementById('cp-upload-progress');
  var runPhase = document.getElementById('cp-run-phase');
  var albumFilter = document.getElementById('cp-album-filter');
  var albumSearch = document.getElementById('cp-album-search');
  function showRunPhase(message, value) {
    text(runPhase, message);
    uploadProgress.hidden = false;
    if (typeof value === 'number') uploadProgress.value = Math.max(0, Math.min(100, value));
    else uploadProgress.removeAttribute('value');
  }
  function sheetTitle(item) {
    var titles = (item.title_evidence || []).filter(function (row) {
      return row.kind === 'plan' || row.kind === 'axonometry';
    });
    return titles.length ? String(titles[0].text) : 'Название не распознано';
  }
  function openAlbumPage(item) {
    document.getElementById('cp-other-tools').open = true;
        document.getElementById('cp-advanced-tools').open = true;
    document.getElementById('cp-technical-results').open = true;
    page.value = String(item.pdf_page);
    page.dispatchEvent(new Event('change', {bubbles: true}));
    previewButton.click();
  }
  function renderAlbumPages() {
    if (!activeAlbum) return;
    var list = document.getElementById('cp-album-pages');
    var kinds = {plan: 'План', axonometry: 'Аксонометрия', mixed: 'План и аксонометрия',
      other: 'Прочий лист', unclassified: 'Тип не определён'};
    var filter = albumFilter.value;
    var query = albumSearch.value.trim().toLocaleLowerCase('ru-RU');
    var count = 0;
    clear(list);
    activeAlbum.pages.forEach(function (item) {
      var known = ['plan', 'axonometry', 'mixed'].indexOf(item.kind) >= 0;
      var match = filter === 'all' || (filter === 'recognized' && known) ||
        (filter === 'plan' && (item.kind === 'plan' || item.kind === 'mixed')) ||
        (filter === 'axonometry' && (item.kind === 'axonometry' || item.kind === 'mixed')) ||
        (filter === 'unclassified' && !known);
      var title = sheetTitle(item);
      var searchable = [item.pdf_page, title].concat(item.system_hints || []).join(' ').toLocaleLowerCase('ru-RU');
      if (!match || (query && searchable.indexOf(query) === -1)) return;
      count++;
      var card = document.createElement('article');
      card.className = 'cp-sheet-card';
      var main = document.createElement('div');
      main.className = 'cp-sheet-content';
      var heading = document.createElement('h4');
      heading.textContent = 'Страница ' + item.pdf_page + ' · ' + title;
      main.appendChild(heading);
      var description = document.createElement('p');
      description.className = 'cp-sheet-meta';
      description.textContent = (kinds[item.kind] || item.kind) +
        ' · сечений: ' + (item.section_marks || []).length +
        ' · отметок: ' + (item.elevation_marks || []).length +
        ((item.system_hints || []).length ? ' · в заголовке: ' + item.system_hints.join(', ') : '');
      main.appendChild(description);
      card.appendChild(main);
      var button = document.createElement('button');
      button.type = 'button';
      button.className = 'secondary';
      button.textContent = 'Просмотреть';
      button.addEventListener('click', function () { openAlbumPage(item); });
      card.appendChild(button);
      var details = document.createElement('details');
      details.className = 'cp-sheet-evidence';
      var summary = document.createElement('summary');
      summary.textContent = 'Исходные подписи и координаты';
      details.appendChild(summary);
      details.addEventListener('toggle', function () {
        if (!details.open || details.dataset.loaded) return;
        details.dataset.loaded = 'yes';
        var observations = (item.title_evidence || []).concat(item.section_marks || [], item.elevation_marks || []);
        var listEl = document.createElement('ul');
        observations.slice(0, 30).forEach(function (observation) {
          var line = document.createElement('li');
          line.textContent = (observation.id ? observation.id + ' · ' : '') +
            (observation.raw || observation.text || '') +
            (observation.bbox_pt ? ' · ' + observation.bbox_pt.join(', ') + ' PDF pt' : '');
          listEl.appendChild(line);
        });
        details.appendChild(listEl);
        if (observations.length > 30) {
          var note = document.createElement('p');
          note.textContent = 'Показаны первые 30 наблюдений из ' + observations.length + '. Полный список есть в JSON.';
          details.appendChild(note);
        }
      });
      card.appendChild(details);
      list.appendChild(card);
    });
    text(document.getElementById('cp-album-visible-count'),
      'Показано листов: ' + count + ' из ' + activeAlbum.page_count +
      (filter === 'recognized' ? '. Остальные доступны через фильтр.' : '.'));
    if (!count) {
      var empty = document.createElement('p');
      empty.textContent = 'Листы не найдены. Измените поиск или фильтр.';
      list.appendChild(empty);
    }
  }
  albumFilter.addEventListener('change', renderAlbumPages);
  albumSearch.addEventListener('input', renderAlbumPages);


  var specFirst = document.getElementById('cp-spec-first');
  var specLast = document.getElementById('cp-spec-last');
  var specConvert = document.getElementById('cp-spec-convert');
  var specExtract = document.getElementById('cp-spec-extract');
  var specStatus = document.getElementById('cp-spec-status');
  var specDownloads = document.getElementById('cp-spec-downloads');
  function validSpecRange() {
    var a = Number(specFirst.value), b = Number(specLast.value);
    return !!activeAlbum && !!file.files[0] && Number.isInteger(a) && Number.isInteger(b) &&
      a >= 1 && b >= a && b <= activeAlbum.page_count && b - a + 1 <= 120;
  }
  function specButtons(busy) {
    specFirst.disabled = !!busy || !activeAlbum;
    specLast.disabled = !!busy || !activeAlbum;
    specConvert.disabled = !!busy || !validSpecRange();
    specExtract.disabled = specConvert.disabled;
  }
  function resetSpecRange() {
    clear(specDownloads);
    text(specStatus, 'Проверьте выбранный диапазон.');
    specButtons(!!activeOperation);
  }
  specFirst.addEventListener('input', resetSpecRange);
  specLast.addEventListener('input', resetSpecRange);
  function showSpecification(data) {
    var register = data.drawing_register || {};
    var entries = Array.isArray(register.entries) ? register.entries : [];
    text(document.getElementById('cp-spec-register'), register.status === 'verified_register'
      ? 'Реестр чертежей: ' + register.verified_count + ' из ' + entries.length + ' заголовков сверены с листами.'
      : 'Проверенный реестр чертежей не найден.');
    var inventory = data.specification_inventory || {};
    var candidates = inventory.candidates || [];
    var continuations = (inventory.observations || []).filter(function (row) { return row.method === 'aligned_columns_and_sequential_footer'; }).length;
    specFirst.max = specLast.max = String(data.page_count);
    specFirst.value = candidates.length === 1 ? String(candidates[0].first) : '';
    specLast.value = candidates.length === 1 ? String(candidates[0].last) : '';
    text(document.getElementById('cp-spec-candidates'), candidates.length
      ? 'По признакам шапки и продолжений таблицы найдены диапазоны: ' + candidates.map(function (r) {
          return r.first + '–' + r.last + ' (' + r.page_count + ' стр.)';
        }).join('; ') + (continuations ? '. Листов без шапки, связанных по колонкам и нумерации: ' + continuations : '') + '. Проверьте перед запуском.'
      : 'Диапазон не определён автоматически. Укажите границы по исходному PDF.');
    resetSpecRange();
  }
  function addSpecDownload(item) {
    var button = document.createElement('button');
    button.type = 'button';
    button.className = 'secondary';
    button.textContent = item.label;
    button.addEventListener('click', function () {
      var bytes = Uint8Array.from(atob(item.base64), function (c) { return c.charCodeAt(0); });
      var link = document.createElement('a');
      var url = URL.createObjectURL(new Blob([bytes], {type: item.mime}));
      link.href = url;
      link.download = item.filename;
      document.body.appendChild(link);
      link.click();
      link.remove();
      setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
    });
    specDownloads.appendChild(button);
  }
  async function runSpecification(action) {
    if (activeOperation || !validSpecRange()) return;
    var f = file.files[0], sha = activeAlbum.source_pdf_sha256;
    var first = Number(specFirst.value), last = Number(specLast.value);
    var uploadId = null;
    reportProblems('Конвертация спецификации', []);
    activeOperation = 'specification';
    buttonState(true);
    startMonitor(action === 'convert' ? 'Конвертация спецификации' : 'Выделение PDF', 'Подготавливаем загрузку PDF…');
    clear(specDownloads);
    text(specStatus, 'Повторно загружаем исходный PDF в защищённый обработчик…');
    try {
      uploadId = await uploadInParts(f, f, function () { return file.files[0]; });
      var payload = authFields();
      payload.set('mode', 'specification');
      payload.set('upload_id', uploadId);
      payload.set('source_pdf_sha256', sha);
      payload.set('spec_first', String(first));
      payload.set('spec_last', String(last));
      payload.set('spec_action', action);
      text(specStatus, action === 'convert' ? 'VentSpec читает и проверяет проектные позиции…' : 'Выделяем выбранные страницы PDF…');
      watchPdfWorker(uploadId, specStatus.textContent);
      var response = await fetch('clean_papper_pdf.php', {
        method: 'POST', body: payload, credentials: 'same-origin',
        headers: {Accept: 'application/json'}
      });
      var result = await decodeReply(response);
      uploadId = null;
      if (!result.ok || !response.ok) {
        text(specStatus, result.message || 'Обработка не завершена. Excel не утверждён.');
        reportProblems('Конвертация спецификации', [specStatus.textContent]);
        finishMonitor(false, specStatus.textContent);
        return;
      }
      if (result.source_pdf_sha256 !== sha || result.first !== first || result.last !== last ||
          !Array.isArray(result.downloads) || !result.downloads.length ||
          (action === 'convert' && result.status !== 'verified_native')) {
        throw new Error('Ответ не соответствует выбранному диапазону.');
      }
      text(specStatus, action === 'convert'
        ? 'Проверка VentSpec пройдена. Строк: ' + result.row_count + '; позиций с количеством: ' + result.positions_with_quantity + '. Это проектные данные, не обмер.'
        : 'PDF диапазона подготовлен. Можно скачать и открыть в VentSpec.');
      result.downloads.forEach(addSpecDownload);
      finishMonitor(true, 'Файлы подготовлены.');
    } catch (e) {
      text(specStatus, 'Не удалось завершить обработку: ' + (e.message || 'ошибка связи'));
      finishMonitor(false, specStatus.textContent);
      reportProblems('Конвертация спецификации', [specStatus.textContent]);
    } finally {
      if (uploadId) await cancelUpload(uploadId);
      activeOperation = null;
      buttonState(false);
    }
  }
  specConvert.addEventListener('click', function () { runSpecification('convert'); });
  specExtract.addEventListener('click', function () { runSpecification('extract'); });


  function showProjectProfile(data) {
    var panel = document.getElementById('cp-project-profile');
    var p = data.project_profile;
    panel.hidden = !p || p.source_pdf_sha256 !== data.source_pdf_sha256;
    if (panel.hidden) return;
    var sampling = p.sampling || {};
    var samples = sampling.pages || [];
    var warningNames = {
      ventilation_sheets_not_identified: 'Не удалось уверенно выделить листы вентиляции.',
      raster_content_requires_review: 'Есть листы с растровым изображением без векторных контуров. Нужна проверка или OCR.',
      style_sampling_incomplete: 'Сложные листы: быстрый анализ толщин и цветов выполнен не полностью.',
      neutral_strokes_only_in_inspected_drawings: 'На проверенных чертежах обнаружены только нейтральные штрихи. Цветовой обмер неприменим без проверки.',
      drawing_stroke_style_unknown: 'Стиль линий на чертежах пока не определён.',
      drawing_register_not_verified: 'Ведомость рабочих чертежей не подтверждена.',
      specification_range_requires_review: 'Диапазон спецификации требует ручной проверки.'
    };
    var types = {vector:'Векторный', mixed_vector_image:'Вектор и изображение',
      image_without_text:'Растр без текста', image_with_text:'Растр с текстом',
      text_only:'Текст', empty_or_other:'Другой', unknown:'Не определён'};
    text(document.getElementById('cp-project-profile-summary'),
      'Текстовый слой: ' + p.pages_with_text + ' из ' + p.page_count +
      ' стр. · Выборочно исследовано ' + samples.length + ' стр. ' +
      'Масштабы, соответствие цветов системам и кратность этажей ещё не утверждены.');
    var recovery = p.text_recovery_summary || {};
    var recoveredPages = recovery.recovered_pages || [];
    var emptyPages = recovery.pages_without_text || [];
    var sparsePages = recovery.pages_with_few_words || [];
    var recoveryNote = document.getElementById('cp-project-text-recovery');
    if (recoveryNote) text(recoveryNote, 'Восстановление кодировки: ' + recoveredPages.length + ' стр., ' + (recovery.changed_word_count || 0) + ' слов. ' +
      (recoveredPages.length ? 'Страницы: ' + recoveredPages.join(', ') + '. ' : '') +
      'Без извлекаемых слов: ' + emptyPages.length + '; не более 20 слов: ' + sparsePages.length + '. OCR не выполнялся. Исходные значения и координаты сохранены в JSON альбома.');
    var warnings = document.getElementById('cp-project-profile-warnings');
    clear(warnings);
    (p.compatibility_warnings || []).forEach(function (code) {
      var li = document.createElement('li');
      li.textContent = warningNames[code] || code;
      warnings.appendChild(li);
    });
    text(document.getElementById('cp-project-profile-formats'),
      (p.page_formats_mm || []).map(function (f) {
        return f.width_mm + ' × ' + f.height_mm + ' мм (' + f.count + ' стр.)';
      }).join('; '));
    var list = document.getElementById('cp-project-profile-samples');
    clear(list);
    samples.forEach(function (row) {
      var li = document.createElement('li');
      var colors = row.stroke_color_counts || {};
      li.textContent = 'Стр. ' + row.pdf_page + ' · ' + (types[row.representation] || row.representation) +
        (typeof row.painted_vector_paths === 'number' ? ' · графических операций: ' + row.painted_vector_paths : '') +
        (row.style_status === 'inspected' ? ' · цветных/нейтральных штрихов: ' +
          (colors.chromatic || 0) + '/' + (colors.neutral || 0) : ' · стиль: не определён') +
        ((row.printed_scale_candidates || []).length ? ' · надпись масштаба: ' +
          row.printed_scale_candidates.map(function (s) { return '1:' + s; }).join(', ') + ' (не проверено)' : '');
      list.appendChild(li);
    });
  }
  document.getElementById('cp-project-profile-download').addEventListener('click', function () {
    if (activeAlbum && activeAlbum.project_profile &&
        activeAlbum.project_profile.source_pdf_sha256 === activeAlbum.source_pdf_sha256) {
      downloadAlbumJson('clean-papper-project-profile.json', activeAlbum.project_profile);
    }
  });


  function showProjectRules(data) {
    var panel = document.getElementById('cp-project-rules');
    var rules = data.project_rules;
    panel.hidden = !rules || rules.source_pdf_sha256 !== data.source_pdf_sha256;
    if (panel.hidden) return;
    var labels = {
      fittings_included_in_duct_length: 'Фасонные учтены в длине воздуховодов',
      pipe_insulation: 'Запас изоляции труб',
      duct_insulation: 'Запас изоляции воздуховодов',
      straight_length: 'К длине прямых участков',
      straight_and_bent_length: 'К длине прямых и гнутых участков',
      straight_and_fittings_area: 'К площади прямых участков и фитингов',
      unresolved_row_basis: 'Основание коэффициента не определено'
    };
    text(document.getElementById('cp-rules-summary'),
      'Проверено страниц предполагаемой спецификации: ' + (rules.inspected_pdf_pages || []).length +
      '. Наблюдений: ' + rules.rule_occurrence_count +
      '; восстановлено разорванных примечаний: ' + rules.reconstructed_note_count +
      '; требуют уточнения: ' + rules.unresolved_block_count + '.' +
      (rules.status === 'no_specification_range' ? ' Диапазон не найден.' : '') +
      (rules.evidence_truncated ? ' Детальные источники ограничены по объёму.' : ''));
    text(document.getElementById('cp-rules-risk'), rules.double_count_risk
      ? 'Внимание: найдено указание об учёте металла фасонных изделий в длине воздуховодов. Не суммируйте этот запас с отдельными фасонными без проверки.'
      : 'Отсутствие обнаруженного предупреждения не доказывает, что двойной учёт исключён.');
    var list = document.getElementById('cp-rules-list');
    clear(list);
    (rules.summaries || []).forEach(function (item) {
      var row = document.createElement('li');
      var pages = item.pdf_pages || [];
      row.textContent = (item.scope === 'general_note_candidate' ? 'Общая сноска (кандидат): ' : 'Примечания строк: ') +
        (labels[item.basis] || item.basis) + ' — ' + (item.value_kind === 'factor' ? '×' : '') +
        Number(item.value).toLocaleString('ru-RU') + (item.value_kind === 'percent' ? '%' : '') +
        ' · наблюдений: ' + item.occurrence_count + ' · стр. ' + pages.slice(0, 8).join(', ') +
        (pages.length > 8 ? ' и другие (в JSON)' : '') + ' · не утверждено';
      list.appendChild(row);
    });
  }
  document.getElementById('cp-rules-download').addEventListener('click', function () {
    if (activeAlbum && activeAlbum.project_rules &&
        activeAlbum.project_rules.source_pdf_sha256 === activeAlbum.source_pdf_sha256) {
      downloadAlbumJson('clean-papper-project-rules.json', activeAlbum.project_rules);
    }
  });

  function showAlbum(data) {
    var list = document.getElementById('cp-album-pages');
    var kinds = {plan: 'План', axonometry: 'Аксонометрия', mixed: 'План и аксонометрия',
      other: 'Прочий лист', unclassified: 'Тип не определён'};
    var totals = data.calculation.totals;
    var counts = data.page_kind_counts || {};
    var metrics = document.getElementById('cp-album-kpis');
    clear(metrics);
    [
      ['Листов в PDF', data.page_count],
      ['Планы', (counts.plan || 0) + (counts.mixed || 0)],
      ['Аксонометрии', (counts.axonometry || 0)],
      ['Без классификации', counts.unclassified || 0],
      ['Найденные подписи', data.pages.reduce(function (n, item) { return n + (item.section_marks || []).length; }, 0)]
    ].forEach(function (row) {
      var box = document.createElement('div');
      box.className = 'cp-metric';
      var value = document.createElement('strong');
      value.textContent = String(row[1]);
      var label = document.createElement('span');
      label.textContent = row[0];
      box.appendChild(value);
      box.appendChild(label);
      metrics.appendChild(box);
    });
    text(document.getElementById('cp-album-review-note'), 'Подписи и найденные отметки — предварительные доказательства, а не подтверждённые воздуховоды. ' +
      (counts.unclassified ? 'Тип ' + counts.unclassified + ' страниц не определён. ' : '') +
      'Для утверждения длин и материалов необходима инженерная разметка участков.');
    function format(value, unit) { return typeof value !== 'number' || !Number.isFinite(value) ? 'не подтверждено' : value.toLocaleString('ru-RU') + ' ' + unit; }
    var calculationRows = document.getElementById('cp-calculation-rows');
    clear(calculationRows);
    [
      ['Страниц', data.page_count],
      ['Участки по планам', format(totals.approved_plan_length_m, 'м')],
      ['Вертикальные участки', format(totals.approved_vertical_length_m, 'м')],
      ['Подтверждённая длина', format(totals.approved_length_m, 'м')],
      ['Площадь прямоугольных участков', format(totals.approved_rectangular_surface_m2, 'м²')],
      ['Участков к проверке', totals.review_required_segments]
    ].forEach(function (row) {
      var tr = document.createElement('tr');
      row.forEach(function (value) {
        var cell = document.createElement('td');
        cell.textContent = value == null ? 'не определено' : String(value);
        tr.appendChild(cell);
      });
      calculationRows.appendChild(tr);
    });
    document.getElementById('cp-album-totals').hidden = false;
    clear(list);
    var suggested = document.getElementById('cp-album-suggested');
    clear(suggested);
    // Recommend a source page to inspect; this does not approve any quantity.
    var plans = data.pages.filter(function (item) { return item.kind === 'plan' || item.kind === 'mixed'; });
    plans.sort(function (a, b) {
      var countA = (a.section_marks || []).filter(function (mark) { return mark.context === 'standalone_section_label_candidate'; }).length;
      var countB = (b.section_marks || []).filter(function (mark) { return mark.context === 'standalone_section_label_candidate'; }).length;
      return countB - countA || a.pdf_page - b.pdf_page;
    });
    if (plans.length) {
      var chosen = plans[0];
      var lead = document.createElement('p');
      lead.textContent = 'Для начала проверки предлагается страница ' + chosen.pdf_page +
        ' · ' + sheetTitle(chosen) + '. Основание — отдельные подписи размеров, а не подтверждённая принадлежность системе или метраж.';
      suggested.appendChild(lead);
      var openPlan = document.createElement('button');
      openPlan.type = 'button';
      openPlan.className = 'secondary';
      openPlan.textContent = 'Открыть страницу ' + chosen.pdf_page + ' для проверки';
      openPlan.addEventListener('click', function () {
        document.getElementById('cp-other-tools').open = true;
        document.getElementById('cp-advanced-tools').open = true;
        document.getElementById('cp-technical-results').open = true;
        page.value = String(chosen.pdf_page);
        page.dispatchEvent(new Event('change', {bubbles: true}));
        previewButton.click();
      });
      suggested.appendChild(openPlan);
    } else {
      text(suggested, 'Листы планов не удалось определить по заголовкам. Проверьте список страниц и при необходимости откройте ручной просмотр.');
    }
    activeAlbum = data;
    showProjectProfile(data);
    showProjectRules(data);
    showSpecification(data);
    reportAlbumProblems(data);
    albumFilter.value = 'recognized';
    albumSearch.value = '';
    renderAlbumPages();
    albumResult.hidden = false;
    setStage('results');
  }

  function downloadAlbumJson(name, data) {
    var link = document.createElement('a');
    var url = URL.createObjectURL(new Blob([JSON.stringify(data, null, 2) + '\n'], {type: 'application/json'}));
    link.href = url;
    link.download = name;
    document.body.appendChild(link);
    link.click();
    link.remove();
    setTimeout(function () { URL.revokeObjectURL(url); }, 1000);
  }

  async function submit(mode) {
    if (activeOperation) return;
    var f = file.files[0];
    var isAlbum = mode === 'album';
    var problemStage = isAlbum ? 'Загрузка и обработка проекта' : 'Ручная проверка';
    if (!f || (!isAlbum && (!Number.isInteger(Number(page.value)) || Number(page.value) < 1))) {
      text(state, isAlbum ? 'Выберите PDF-альбом.' : 'Выберите PDF и корректный номер страницы.');
      reportProblems(problemStage, [state.textContent]);
      return;
    }
    if (f.size > 100 * 1024 * 1024) {
      text(state, 'Максимальный размер файла — 100 МБ.');
      reportProblems(problemStage, [state.textContent]);
      return;
    }
    if (mode === 'vision' && lastPreview !== key()) {
      text(state, 'Сначала выполните локальный предпросмотр этой страницы.');
      reportProblems(problemStage, [state.textContent]);
      return;
    }
    if (mode === 'vision' && !consent.checked) {
      text(state, 'Подтвердите отправку выбранной страницы или фрагмента в Anthropic.');
      reportProblems(problemStage, [state.textContent]);
      return;
    }
    var review = isAlbum ? albumReview.files[0] : null;
    if (review && review.size > 96 * 1024) {
      text(state, 'Максимальный размер разметки — 96 КиБ.');
      reportProblems(problemStage, [state.textContent]);
      return;
    }
    var currentKey = isAlbum ? function () { return file.files[0]; } : key;
    var originalKey = currentKey();
    var uploadId = null;
    reportProblems(problemStage, []);
    if (isAlbum) {
      delete problemGroups['Распознавание проекта'];
      delete problemGroups['Определение спецификации'];
      renderProblems();
    }
    activeOperation = mode;
    buttonState(true);
    startMonitor(isAlbum ? 'Обработка альбома' : mode === 'vision' ? 'Анализ Claude' : 'Предпросмотр листа', 'Подготавливаем загрузку PDF…');
    if (isAlbum) {
      setStage('processing');
      showRunPhase('Подготавливаем загрузку PDF…', 0);
    }
    if (albumReview) albumReview.disabled = true;
    if (isAlbum) {
      activeAlbum = null;
      albumResult.hidden = true;
      document.getElementById('cp-album-totals').hidden = true;
      clear(specDownloads);
    }
    text(state, mode === 'vision' ?
      'Отправляем выбранную область Claude. Ответ может занять некоторое время…' :
      isAlbum ? 'Загружаем PDF-альбом для локального анализа…' :
      'Создаём локальный предпросмотр без передачи в Claude…');
    if (mode === 'vision') clear(vision);
    try {
      uploadId = await uploadInParts(f, originalKey, currentKey);
      if (currentKey() !== originalKey) {
        throw new Error('Параметры изменились во время загрузки.');
      }
      text(state, mode === 'vision' ? 'PDF загружен. Анализируем выбранную область в Claude…'
                  : isAlbum ? 'PDF загружен. Читаем страницы альбома…' : 'PDF загружен. Строим локальный предпросмотр…');
      if (isAlbum) showRunPhase('Загрузка завершена. Сервер анализирует страницы альбома…');
      watchPdfWorker(uploadId, state.textContent);
      var data = isAlbum ? authFields() : new FormData(form);
      data.delete('pdf'); // Never transmit the entire file in one HTTP request.
      if (review) data.set('album_review', review);
      data.set('upload_id', uploadId);
      data.set('mode', mode);
      var response = await fetch('clean_papper_pdf.php', {
        method: 'POST', body: data, credentials: 'same-origin',
        headers: { Accept: 'application/json' }
      });
      var info = await decodeReply(response);
      uploadId = null; // Server consumes the session-bound upload and deletes the file.
      if (currentKey() !== originalKey) { finishMonitor(false, 'Параметры изменились.'); return; }
      if (!info || !info.ok) {
        text(state, info && info.message ? info.message : 'Не удалось выполнить анализ.');
        reportProblems(problemStage, [state.textContent]);
        finishMonitor(false, state.textContent);
        if (isAlbum) {
          uploadProgress.hidden = true;
          text(runPhase, 'Альбом не обработан. Проверьте сообщение об ошибке и повторите запуск.');
        }
        return;
      }
      text(state, info.message || 'Готово.');
      if (isAlbum) {
        showAlbum(info);
        uploadProgress.hidden = true;
        text(runPhase, 'Альбом обработан. Выберите лист для проверки.');
        text(state, 'Альбом разобран на сервере.');
        finishMonitor(true, state.textContent);
        return;
      }
      if (mode === 'preview') {
        lastPreview = key();
        previewMeta = {width: info.image_width || 0, height: info.image_height || 0};
        image.src = info.preview;
        view.hidden = false;
        text(pages, 'Страница ' + info.page + ' из ' + info.pages);
        blankSelection();
        summaryList(info.geometry || {});
        clear(vision);
        notifyReport('preview', {geometry: info.geometry || {}, page: info.page, page_count: info.pages, crop: info.crop});
      } else {
        if (info.geometry) summaryList(info.geometry);
        displayVision(info.vision || {});
        notifyReport('vision', {
          filename: f.name, size_bytes: f.size,
          page: info.page, page_count: info.pages, crop: info.crop,
          preview_image_width_px: previewMeta ? previewMeta.width : 0,
          preview_image_height_px: previewMeta ? previewMeta.height : 0,
          geometry: info.geometry || {}, vision: info.vision || {}
        });
      }
      finishMonitor(true, 'Обработка листа завершена.');
    } catch (e) {
      text(state, e && e.message ? e.message : 'Ошибка связи с сервером при загрузке PDF.');
      reportProblems(problemStage, [state.textContent]);
      finishMonitor(false, state.textContent);
      if (isAlbum) {
        uploadProgress.hidden = true;
        text(runPhase, 'Обработка прервана. Можно повторить запуск.');
      }
    } finally {
      if (uploadId) await cancelUpload(uploadId);
      activeOperation = null;
      buttonState(false);
      if (albumReview) albumReview.disabled = false;
    }
  }
  previewButton.addEventListener('click', function () { submit('preview'); });
  visionButton.addEventListener('click', function () { submit('vision'); });
  if (albumButton) {
    albumButton.addEventListener('click', function () { submit('album'); });
    document.getElementById('cp-album-download').addEventListener('click', function () {
      if (activeAlbum) downloadAlbumJson('clean-papper-album.json', activeAlbum);
    });
    document.getElementById('cp-album-template').addEventListener('click', function () {
      if (activeAlbum) downloadAlbumJson('clean-papper-album-review.json', activeAlbum.review_template);
    });
  }
  clearButton.addEventListener('click', function () {
    blankSelection();
    clear(vision);
  });

  function xy(event) {
    var rect = image.getBoundingClientRect();
    if (!rect.width || !rect.height) return null;
    return [Math.min(1, Math.max(0, (event.clientX-rect.left)/rect.width)),
            Math.min(1, Math.max(0, (event.clientY-rect.top)/rect.height))];
  }
  view.addEventListener('pointerdown', function (e) {
    if (window.CleanPapperVector && window.CleanPapperVector.mode() !== 'crop') return;
    if (!lastPreview || lastPreview !== key()) return;
    start = xy(e);
    if (!start) return;
    view.setPointerCapture(e.pointerId);
    e.preventDefault();
  });
  view.addEventListener('pointermove', function (e) {
    if (window.CleanPapperVector && window.CleanPapperVector.mode() !== 'crop') return;
    if (!start) return;
    var p = xy(e);
    if (!p) return;
    var x = Math.min(start[0],p[0]), y = Math.min(start[1],p[1]);
    var w = Math.abs(start[0]-p[0]), h = Math.abs(start[1]-p[1]);
    highlight.hidden = false;
    highlight.style.left = (x*100) + '%';
    highlight.style.top = (y*100) + '%';
    highlight.style.width = (w*100) + '%';
    highlight.style.height = (h*100) + '%';
  });
  view.addEventListener('pointerup', function (e) {
    if (window.CleanPapperVector && window.CleanPapperVector.mode() !== 'crop') {start=null;return;}
    if (!start) return;
    var p = xy(e);
    if (p) {
      var bounds = [Math.min(start[0],p[0]), Math.min(start[1],p[1]),
                    Math.max(start[0],p[0]), Math.max(start[1],p[1])];
      if (bounds[2]-bounds[0] >= 0.04 && bounds[3]-bounds[1] >= 0.04) {
        crop.value = bounds.map(function (x) { return x.toFixed(5); }).join(',');
        cropText.textContent = 'Выбран фрагмент страницы — только он будет отправлен Claude.';
        notifyReport('reset');
        clear(vision);
      } else blankSelection();
    }
    start = null;
  });
})();
