<?php
declare(strict_types=1);

// Очередь ручной проверки позиций от 1С, отклонённых автоматической
// проверкой (опечатка/дубликат/не вентиляция/длина тройника — см.
// common/nomenclature_intake.py). Заполняется фоновым процессом
// web/1c_intake.php -> common/web_1c_intake_run.py сразу после проверки
// пачки (write_pending_review), НЕ этой страницей. Отсюда позицию можно
// либо поправить (только наименование) и подтвердить — тогда она уходит
// в боевую базу сравнения (DB_FILE) через web/onec_review_submit.php, тем
// же путём, что и чистые позиции, — либо отклонить совсем (никуда не
// добавляется, просто уходит из очереди). Доступно только admin/mainadmin.

require __DIR__ . '/admin_guard.php';
require __DIR__ . '/config.php';

if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(16));
}
$csrf = $_SESSION['csrf'];

$flagLabels = [
    'catalog_review' => 'Выберите раздел',
    'missing_code' => 'Нет кода 1С',
    'code_changed' => 'Изменение существующего кода',
    'batch_code_conflict' => 'Конфликт кода в пачке',
    'batch_name_duplicate' => 'Одинаковые наименования в пачке',
    'invalid_fields' => 'Неверные реквизиты',

    'not_vent_relevant' => 'Не вентиляция?',
    'possible_duplicate' => 'Дубликат?',
    'possible_typo' => 'Опечатка?',
    'tee_length_violation' => 'Тройник: длина мала',
    'tee_length_unknown' => 'Тройник: длина не указана',
    'semantic_similarity' => 'Семантически близко',
];

// Источник истины — файлы <токен>_1c_pending.json в OUTPUT_DIR (пишет
// common/web_1c_intake_run.py). Показываем только нерешённые записи;
// решённые (resolved=true) остаются в файле как журнал, но из списка
// пропадают.
function load_pending_entries(): array {
    $files = glob(OUTPUT_DIR . '/*_1c_pending.json') ?: [];
    usort($files, fn($a, $b) => filemtime($b) <=> filemtime($a));

    $entries = [];
    foreach ($files as $path) {
        $raw = file_get_contents($path);
        $data = $raw !== false ? json_decode($raw, true) : null;
        if (!is_array($data)) {
            continue;
        }
        foreach ($data as $entry) {
            if (!is_array($entry) || !empty($entry['resolved'])) {
                continue;
            }
            $entries[] = $entry;
        }
    }
    return $entries;
}

// Карточка тяжелее строки таблицы (поле ввода, список флагов, две кнопки)
// — при очереди в тысячи позиций без постраничного вывода страница рендерит
// их все разом и перестаёт отвечать и в браузере, и на сервере. 50 на
// страницу — компромисс между числом кликов "вперёд" и весом страницы.
const PER_PAGE = 50;

function matches_entry_query(array $entry, string $q): bool {
    if ($q === '') {
        return true;
    }
    $needle = mb_strtolower($q, 'UTF-8');
    $item = $entry['raw_item'] ?? [];
    foreach (['Наименование', 'Код'] as $field) {
        $val = (string) ($item[$field] ?? '');
        if ($val !== '' && mb_strpos(mb_strtolower($val, 'UTF-8'), $needle) !== false) {
            return true;
        }
    }
    return false;
}

$allEntries = load_pending_entries();
$totalAll = count($allEntries);
$q = trim((string) ($_GET['q'] ?? ''));
$entries = $q === '' ? $allEntries : array_values(array_filter($allEntries, fn($e) => matches_entry_query($e, $q)));
$totalEntries = count($entries);

$page = max(1, (int) ($_GET['page'] ?? 1));
$totalPages = max(1, (int) ceil($totalEntries / PER_PAGE));
$page = min($page, $totalPages);
$offset = ($page - 1) * PER_PAGE;
$pageEntries = array_slice($entries, $offset, PER_PAGE);

function review_page_url(int $page, string $q): string {
    $params = ['page' => $page];
    if ($q !== '') {
        $params['q'] = $q;
    }
    return 'onec_review.php?' . http_build_query($params);
}

$added = isset($_GET['added']) ? (int) $_GET['added'] : null;
$err = $_GET['err'] ?? null;
$bulkAction = $_GET['bulk'] ?? null;
$bulkCount = isset($_GET['count']) ? (int) $_GET['count'] : 0;
$bulkErrCount = isset($_GET['errCount']) ? (int) $_GET['errCount'] : 0;
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Проверка отклонённых позиций — Номенклатура 1С</title>
<link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
<script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
</head>
<body>
<div class="shell">
  <?php require __DIR__ . '/sidebar.php'; ?>

  <div class="dashboard-main">
  <div class="page-wide">

  <a class="back-link" href="onec_intake.php">← К списку пачек</a>

  <div class="card">
    <h1>Ручная проверка</h1>
    <p class="subtitle">
      Позиции, которые автоматическая проверка отклонила хотя бы по одной причине.
      Поправьте наименование и выберите раздел: «Вентиляция» или «ВК».
      После подтверждения позиция попадёт в выбранную номенклатуру. Ничего не подтверждённое здесь в базу
      не попадает.
    </p>

    <?php if ($added !== null): ?>
    <div class="alert success">Позиция добавлена в номенклатуру.</div>
    <?php endif; ?>
    <?php if (isset($_GET['rejected'])): ?>
    <div class="alert success">Позиция отклонена — в базу не добавлена.</div>
    <?php endif; ?>
    <?php if ($bulkAction === 'approve'): ?>
    <div class="alert success">
      Добавлено в номенклатуру: <?= $bulkCount ?>.
      <?php if ($bulkErrCount > 0): ?>Не удалось обработать: <?= $bulkErrCount ?> — позиции остались в очереди. Проверьте их отдельно и выберите раздел, если он не определён.<?php endif; ?>
    </div>
    <?php elseif ($bulkAction === 'reject'): ?>
    <div class="alert success">
      Отклонено: <?= $bulkCount ?>.
      <?php if ($bulkErrCount > 0): ?>Не удалось обработать: <?= $bulkErrCount ?> — позиции остались в очереди. Проверьте их отдельно и выберите раздел, если он не определён.<?php endif; ?>
    </div>
    <?php endif; ?>
    <?php if ($err): ?>
    <div class="alert error" style="white-space: pre-wrap; font-family: ui-monospace, monospace; font-size: 0.85rem;"><?= htmlspecialchars((string) $err, ENT_QUOTES, 'UTF-8') ?></div>
    <?php endif; ?>

    <form method="get" action="onec_review.php" style="display:flex; gap:10px; margin-bottom:14px;">
      <input type="search" name="q" value="<?= htmlspecialchars($q, ENT_QUOTES, 'UTF-8') ?>"
             placeholder="Поиск по коду или наименованию…"
             style="flex:1; padding:10px 12px; border-radius:8px; border:1px solid var(--border); font:inherit;">
      <button type="submit" class="btn-small">Найти</button>
      <?php if ($q !== ''): ?>
      <a class="btn-small btn-outline" href="onec_review.php">Сбросить</a>
      <?php endif; ?>
    </form>

    <?php if (!$totalAll): ?>
    <p class="empty-state">Очередь пуста — нечего проверять.</p>
    <?php elseif (!$entries): ?>
    <p class="subtitle">По запросу «<?= htmlspecialchars($q, ENT_QUOTES, 'UTF-8') ?>» ничего не найдено — всего в очереди: <?= $totalAll ?>.</p>
    <?php else: ?>
    <p class="subtitle">
      <?php if ($q !== ''): ?>Найдено: <?= $totalEntries ?> из <?= $totalAll ?><?php else: ?>В очереди: <?= $totalEntries ?><?php endif; ?><?php if ($totalPages > 1): ?>, страница <?= $page ?> из <?= $totalPages ?><?php endif; ?>
    </p>

    <p class="subtitle">При массовом подтверждении раздел определяется для каждой позиции отдельно.
      Позиции без определённого раздела останутся в очереди до ручного выбора.</p>
    <?php if ($totalEntries > PER_PAGE): ?>
    <form method="post" action="onec_review_approve_all.php" style="margin-bottom:16px;"
          onsubmit="return confirm('Подтвердить и добавить ВСЕ <?= $totalEntries ?> позиций<?= $q !== '' ? ' (по текущему поиску)' : ' в очереди' ?> КАК ЕСТЬ, без правки и без ручной проверки? '
            + 'Сюда войдут и позиции, отмеченные «Опечатка?»/«Не вентиляция?»/«Семантически близко», не только «Дубликат?». '
            + 'Инструмент удаления дублей на странице «База» такие случаи не ловит — он ищет только полностью одинаковый текст. Действие необратимо без ручного поиска в базе потом.');">
      <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
      <input type="hidden" name="q" value="<?= htmlspecialchars($q, ENT_QUOTES, 'UTF-8') ?>">
      <button type="submit" class="btn-small btn-danger">Подтвердить ВСЕ <?= $totalEntries ?> позиций<?= $q !== '' ? ' по поиску' : ' в очереди' ?> (без правки)</button>
    </form>
    <?php endif; ?>

    <form id="bulk-review-form" method="post" action="onec_review_bulk.php"
          style="display:flex; align-items:center; gap:10px; margin-bottom:16px; flex-wrap:wrap;"
          onsubmit="return onecReviewBulkConfirm(event);">
      <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
      <input type="hidden" name="page" value="<?= $page ?>">
      <input type="hidden" name="q" value="<?= htmlspecialchars($q, ENT_QUOTES, 'UTF-8') ?>">
      <label style="display:flex; align-items:center; gap:6px; margin:0;">
        <input type="checkbox" id="bulk-select-all">
        <span class="subtitle" style="margin:0;">Выбрать все на странице</span>
      </label>
      <span class="subtitle" style="margin:0;">Выбрано: <span id="bulk-selected-count">0</span></span>
      <label style="flex:1 1 220px; min-width:0;">Раздел для выбранных
        <select name="catalog" aria-label="Раздел для выбранных позиций">
          <option value="">По разделу каждой позиции</option>
          <option value="ventilation">Вентиляция</option>
          <option value="vk">ВК</option>
        </select>
      </label>
      <button type="submit" name="action" value="approve" class="btn-small" id="bulk-approve-btn" disabled>Подтвердить выбранные</button>
      <button type="submit" name="action" value="reject" class="btn-small btn-danger" id="bulk-reject-btn" disabled>Отклонить выбранные</button>
    </form>

    <?php if ($totalPages > 1): ?>
    <div style="display:flex; align-items:center; gap:10px; margin-bottom:16px;">
      <?php if ($page > 1): ?>
      <a class="btn-small" href="<?= htmlspecialchars(review_page_url($page - 1, $q), ENT_QUOTES, 'UTF-8') ?>">← Назад</a>
      <?php endif; ?>
      <?php if ($page < $totalPages): ?>
      <a class="btn-small" href="<?= htmlspecialchars(review_page_url($page + 1, $q), ENT_QUOTES, 'UTF-8') ?>">Вперёд →</a>
      <?php endif; ?>
    </div>
    <?php endif; ?>

    <div class="review-list">
      <?php foreach ($pageEntries as $entry):
        $item = $entry['raw_item'] ?? [];
        $name = (string) ($item['Наименование'] ?? '');
        $code = (string) ($item['Код'] ?? '');
        $kind = (string) ($item['ВидНоменклатуры'] ?? '');
      ?>
      <form class="review-item" method="post" action="onec_review_submit.php">
        <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
        <input type="hidden" name="token" value="<?= htmlspecialchars((string) $entry['token'], ENT_QUOTES, 'UTF-8') ?>">
        <input type="hidden" name="id" value="<?= (int) $entry['id'] ?>">
        <input type="hidden" name="page" value="<?= $page ?>">

        <div class="review-item-meta" style="display:flex; align-items:center; gap:10px;">
          <input type="checkbox" class="bulk-select-checkbox" form="bulk-review-form" name="selected[]"
                 value="<?= htmlspecialchars((string) $entry['token'] . ':' . (int) $entry['id'], ENT_QUOTES, 'UTF-8') ?>">
          <span class="subtitle" style="margin:0;">Код: <?= htmlspecialchars($code, ENT_QUOTES, 'UTF-8') ?><?= $kind !== '' ? ' · ' . htmlspecialchars($kind, ENT_QUOTES, 'UTF-8') : '' ?></span>
        </div>

        <div class="field">
          <label class="field-label">Наименование</label>
          <input type="text" name="name" value="<?= htmlspecialchars($name, ENT_QUOTES, 'UTF-8') ?>" required>
        </div>

        <?php $suggestedCatalog = $entry['routing']['catalog'] ?? ''; ?>
        <div class="field">
          <label class="field-label">Раздел номенклатуры
            <select name="catalog" aria-label="Раздел номенклатуры">
              <option value="">Выберите раздел</option>
              <option value="ventilation" <?= $suggestedCatalog === 'ventilation' ? 'selected' : '' ?>>Вентиляция</option>
              <option value="vk" <?= $suggestedCatalog === 'vk' ? 'selected' : '' ?>>ВК</option>
            </select>
          </label>
          <?php if (!empty($entry['routing']['reason'])): ?>
          <p class="subtitle"><?= htmlspecialchars((string) $entry['routing']['reason'], ENT_QUOTES, 'UTF-8') ?></p>
          <?php endif; ?>
        </div>

        <ul class="review-flags">
          <?php foreach (($entry['flags'] ?? []) as $flag): ?>
          <li><b><?= htmlspecialchars($flagLabels[$flag['type']] ?? $flag['type'], ENT_QUOTES, 'UTF-8') ?>:</b>
            <?= htmlspecialchars((string) ($flag['detail'] ?? ''), ENT_QUOTES, 'UTF-8') ?></li>
          <?php endforeach; ?>
        </ul>

        <div class="review-item-actions">
          <button type="submit" name="action" value="approve" class="btn-small">Подтвердить и добавить</button>
          <button type="submit" name="action" value="reject" class="btn-small btn-danger" formnovalidate
                  onclick="return confirm('Отклонить позицию «<?= htmlspecialchars(addslashes($name), ENT_QUOTES, 'UTF-8') ?>»? Она не будет добавлена в базу.');">Отклонить</button>
        </div>
      </form>
      <?php endforeach; ?>
    </div>

    <?php if ($totalPages > 1): ?>
    <div style="display:flex; align-items:center; gap:10px; margin-top:16px;">
      <?php if ($page > 1): ?>
      <a class="btn-small" href="<?= htmlspecialchars(review_page_url($page - 1, $q), ENT_QUOTES, 'UTF-8') ?>">← Назад</a>
      <?php endif; ?>
      <span class="subtitle" style="margin:0;">Страница <?= $page ?> из <?= $totalPages ?></span>
      <?php if ($page < $totalPages): ?>
      <a class="btn-small" href="<?= htmlspecialchars(review_page_url($page + 1, $q), ENT_QUOTES, 'UTF-8') ?>">Вперёд →</a>
      <?php endif; ?>
    </div>
    <?php endif; ?>
    <?php endif; ?>
  </div>

  </div>
  </div>
</div>
<script>
// Массовое подтверждение/отклонение (см. web/onec_review_bulk.php) —
// счётчик выбранного, "выбрать все на странице" и разные подтверждения
// для подтвердить/отклонить перед отправкой одной и той же формы.
(function () {
  var checkboxes = document.querySelectorAll('.bulk-select-checkbox');
  var selectAll = document.getElementById('bulk-select-all');
  var counter = document.getElementById('bulk-selected-count');
  var approveBtn = document.getElementById('bulk-approve-btn');
  var rejectBtn = document.getElementById('bulk-reject-btn');
  if (!checkboxes.length || !approveBtn || !rejectBtn) return;

  function update() {
    var n = 0;
    checkboxes.forEach(function (cb) { if (cb.checked) n++; });
    counter.textContent = n;
    approveBtn.disabled = n === 0;
    rejectBtn.disabled = n === 0;
    if (selectAll) {
      selectAll.checked = n === checkboxes.length;
      selectAll.indeterminate = n > 0 && n < checkboxes.length;
    }
  }

  checkboxes.forEach(function (cb) { cb.addEventListener('change', update); });
  if (selectAll) {
    selectAll.addEventListener('change', function () {
      checkboxes.forEach(function (cb) { cb.checked = selectAll.checked; });
      update();
    });
  }
  update();

  window.onecReviewBulkConfirm = function (event) {
    var n = 0;
    checkboxes.forEach(function (cb) { if (cb.checked) n++; });
    if (n === 0) {
      return false;
    }
    var action = event.submitter && event.submitter.value;
    var message = action === 'reject'
      ? 'Отклонить выбранные позиции (' + n + ')? Они не будут добавлены в базу.'
      : 'Подтвердить и добавить выбранные позиции (' + n + ') как есть, без правки наименования?';
    return confirm(message);
  };
})();
</script>
</body>
</html>
