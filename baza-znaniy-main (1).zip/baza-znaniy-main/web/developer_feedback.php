<?php
declare(strict_types=1);

require __DIR__ . '/auth_guard.php';
require_once __DIR__ . '/design.php';
require_once __DIR__ . '/developer_feedback_lib.php';

const DEVELOPER_FEEDBACK_MAX_LENGTH = 4000;

$error = null;
$message = '';
$sent = !empty($_SESSION['developer_feedback_sent']);
unset($_SESSION['developer_feedback_sent']);
$_SESSION['developer_feedback_token'] ??= bin2hex(random_bytes(32));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $token = $_POST['csrf'] ?? null;
    $raw = $_POST['message'] ?? null;
    if (is_string($raw) && strlen($raw) <= DEVELOPER_FEEDBACK_MAX_LENGTH * 4) {
        $message = trim($raw);
    }
    if (!is_string($token) || !hash_equals($_SESSION['developer_feedback_token'], $token)) {
        http_response_code(400);
        $error = 'Форма устарела. Отправьте предложение ещё раз.';
    } elseif ($message === '' || preg_match('/\S/u', $message) !== 1
        || mb_strlen($message, 'UTF-8') > DEVELOPER_FEEDBACK_MAX_LENGTH) {
        http_response_code(422);
        $error = 'Введите предложение длиной до ' . DEVELOPER_FEEDBACK_MAX_LENGTH . ' символов.';
    } else {
        try {
            developer_feedback_save($message);
            unset($_SESSION['developer_feedback_token']);
            $_SESSION['developer_feedback_sent'] = true;
            header('Location: developer_feedback.php', true, 303);
            exit;
        } catch (RuntimeException | JsonException $exception) {
            error_log($exception->getMessage());
            http_response_code(500);
            $error = 'Не удалось отправить обращение. Попробуйте ещё раз.';
        }
    }
}
?>
<!doctype html>
<html lang="ru">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Обращения к разработчику — База знаний</title>
  <link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
  <link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
  <?= design_refresh_css() ?>
  <script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
</head>
<body>
<div class="shell">
  <?php require __DIR__ . '/sidebar.php'; ?>
  <main class="dashboard-main">
    <div class="page">
      <div class="card">
        <h1>Обращения к разработчику</h1>
        <?php if ($sent): ?>
          <div class="alert success" role="status">Обращение отправлено.</div>
        <?php endif; ?>
        <?php if ($error !== null): ?>
          <div class="alert error" role="alert"><?= kb_e($error) ?></div>
        <?php endif; ?>
        <form method="post" action="developer_feedback.php">
          <input type="hidden" name="csrf" value="<?= kb_e($_SESSION['developer_feedback_token']) ?>">
          <div class="field">
            <label class="field-label" for="developer-message">Напишите ваше предложение</label>
            <textarea id="developer-message" name="message" rows="6" maxlength="<?= DEVELOPER_FEEDBACK_MAX_LENGTH ?>" required><?= kb_e($message) ?></textarea>
          </div>
          <button class="btn" type="submit">Отправить</button>
        </form>
      </div>
    </div>
  </main>
</div>
</body>
</html>
