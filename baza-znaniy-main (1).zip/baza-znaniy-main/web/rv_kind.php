<?php
declare(strict_types=1);

// Сменить код работ готовой РВ: заказ-наряд бывает ДР (работы кода 6) или РВР (работы кода 12 — не предусмотренные
// основным проектом). Обычно вид выбирают до сборки (страница подтверждения, rv_confirm.php) или он известен из 1С
// (1c_rv.php); здесь — если выбрали не тот. Работы в другом коде другие, поэтому РВ собирается с нуля по сохранённой
// разметке: согласование, исправления сметчика по этой РВ, разбивки строк и добавленные работы сбрасываются
// (в памяти агента решения остаются — у каждого кода память своя). Указания для этой РВ (ТЗ) остаются, модель
// применит их заново. РВ, уже загруженную в 1С, и сверку не трогаем.
//
// POST (csrf, token, code_root = 6 | 12).

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require_once __DIR__ . '/users.php';
require_once __DIR__ . '/lib.php';
require_once __DIR__ . '/rv_lib.php';

rv_guard();

$token = (string) ($_POST['token'] ?? '');
if (!rv_token_valid($token)) {
    header('Location: rv.php');
    exit;
}
$back = 'rv_status.php?token=' . urlencode($token);
$go = static function (string $message) use ($back): never {
    header('Location: ' . $back . '&err=' . rawurlencode($message));
    exit;
};
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !hash_equals(rv_csrf(), (string) ($_POST['csrf'] ?? ''))) {
    $go('Форма устарела — обновите страницу и повторите.');
}
$paths = rv_paths($token);
$job = rv_read_json($paths['job']);
if ($job === null || !rv_can_access($job)) {
    $go('Задача не найдена или принадлежит другому пользователю.');
}
$root = rv_code_root_of($_POST['code_root'] ?? '');
if ($root === '') {
    $go('Выберите код работ: ДР (код 6) или РВР (код 12).');
}
if (($job['mode'] ?? '') === 'audit') {
    $go('У сверки РВ код работ берётся из работ РВ в 1С.');
}
if (rv_onec_loaded($job)) {
    $go('РВ уже загружена в 1С — менять код работ поздно. Отправьте смету из 1С заново.');
}
[$state] = rv_state($token, $job);
if ($state !== 'done' || !is_file($paths['work'])) {
    $go($state !== 'done' ? 'РВ сейчас строится — сменить код работ можно, когда она будет готова.'
        : 'Разметка этой РВ не найдена на сервере — загрузите ЛРВ заново.');
}
$me = (string) ($_SESSION['kb_user'] ?? '');
$now = time();
if ($root === rv_code_root_of(($job['code_root'] ?? '') !== '' ? $job['code_root'] : '6')) {
    // РВ уже в этом коде (заказ-наряд, собранный до выбора ДР / РВР, — в коде 6): только запомнить выбор, без пересборки.
    if (rv_code_root_of($job['code_root'] ?? '') === '') {
        $job['code_root'] = $root;
        $job['code_root_by'] = $me;
        $job['code_root_at'] = $now;
        file_put_contents($paths['job'], json_encode($job, JSON_UNESCAPED_UNICODE));
    }
    header('Location: ' . $back);
    exit;
}

$job['code_root'] = $root;
$job['code_root_by'] = $me;
$job['code_root_at'] = $now;
unset($job['feedback'], $job['rebuilt']);
file_put_contents($paths['job'], json_encode($job, JSON_UNESCAPED_UNICODE));

// Решения по работам прежнего кода к новой РВ не подходят: ответ сметчика и его правки в указаниях этой РВ убираем.
@unlink($paths['feedback']);
$local = rv_read_json(rv_local_path($token));
if (is_array($local)) {
    unset($local['agent'], $local['fixes']);
    file_put_contents(rv_local_path($token), json_encode($local, JSON_UNESCAPED_UNICODE));
}
// Прежний результат — тоже: иначе сборка перенесла бы из него разбивки строк и добавленные работы в старых кодах.
foreach (['json', 'form', 'onec'] as $key) {
    @unlink($paths[$key]);
}

file_put_contents($paths['status'], json_encode([
    'state' => 'running',
    'stage' => 'собираю РВ заново: ' . rv_code_root_label($root) . '…',
    'started' => $now,
    'updated' => $now,
    'launched' => false,
], JSON_UNESCAPED_UNICODE));

rv_launch(['--phase', 'bind', '--status-file', $paths['status'], '--work-file', $paths['work'],
           '--out-xlsx', $paths['xlsx'], '--out-json', RV_OUTPUT_DIR . '/' . $token . '_rv.json.gz',
           '--credentials', ANTHROPIC_CREDENTIALS_FILE, '--learning-file', RV_LEARNING_FILE, '--notes-file', RV_NOTES_FILE,
           '--user', $me, '--source-name', (string) ($job['source_name'] ?? '')]);

header('Location: ' . $back);
exit;
