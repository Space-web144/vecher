<?php
declare(strict_types=1);

/**
 * Вопрос инженера по одной строке готового отчёта — ответ агента.
 *
 * Агент получает факты ТОЛЬКО этой строки (раздел и система, наименование,
 * единица, тип, количества по редакциям, посчитанные дельты и легенду
 * отчёта) и ничего не пересчитывает: числа уже посчитаны детерминированным
 * кодом. Ни чертежей, ни остальной таблицы он не видит.
 *
 * Отвечает JSON: {"ok":true,"answer":"…"} или {"ok":false,"error":"…"}.
 */

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';

header('Content-Type: application/json; charset=utf-8');

/** @return never */
function ask_fail(string $message, int $code = 400) {
    http_response_code($code);
    echo json_encode(['ok' => false, 'error' => $message], JSON_UNESCAPED_UNICODE);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    ask_fail('Ожидался POST-запрос.', 405);
}

$token = (string) ($_POST['token'] ?? '');
if (!preg_match('/^[a-f0-9]{16}$/', $token)) {
    ask_fail('Неверный номер задачи.');
}
$jobPath = VERRATA_OUTPUT_DIR . '/' . $token . '_job.json';
$job = is_file($jobPath) ? json_decode((string) file_get_contents($jobPath), true) : null;
if (!is_array($job)) {
    ask_fail('Задача не найдена или устарела.', 404);
}
// Отчёты живут по токену, а токен можно подобрать перебором — чужую
// строку спросить нельзя.
if ((string) ($job['user'] ?? '') !== (string) ($_SESSION['kb_user'] ?? '')) {
    ask_fail('Эта задача принадлежит другому пользователю.', 403);
}

$xlsxPath = VERRATA_OUTPUT_DIR . '/' . $token . '_verrata.xlsx';
if (!is_file($xlsxPath)) {
    ask_fail('Отчёт по спецификации для этой задачи не найден.', 404);
}

$row = (string) ($_POST['row'] ?? '');
if (!preg_match('/^\d{1,6}$/', $row)) {
    ask_fail('Номер строки задан неверно.');
}
$question = trim((string) ($_POST['question'] ?? ''));
if ($question === '') {
    ask_fail('Вопрос не задан.');
}
// Длинный вопрос — это не вопрос, а пересказ; и каждый входной токен
// оплачивается. Обрезаем явно, а не молча.
if (mb_strlen($question) > 500) {
    ask_fail('Вопрос слишком длинный — уложите его в 500 знаков.');
}
if (!is_file(ANTHROPIC_CREDENTIALS_FILE)) {
    ask_fail('Агент не настроен на этом сервере.', 503);
}

// Файл с ключом читает сам Python: здесь передаётся ПУТЬ, не секрет.
$cmd = escapeshellarg(PYTHON_BIN) . ' ' . escapeshellarg(VERRATA_ASK_SCRIPT)
    . ' --xlsx ' . escapeshellarg($xlsxPath)
    . ' --row ' . escapeshellarg($row)
    . ' --question ' . escapeshellarg($question)
    . ' --credentials ' . escapeshellarg(ANTHROPIC_CREDENTIALS_FILE)
    . ' 2>> ' . escapeshellarg(VERRATA_OUTPUT_DIR . '/verrata_errors.log');

$output = shell_exec($cmd);
$answer = is_string($output) ? json_decode(trim($output), true) : null;
if (!is_array($answer) || !array_key_exists('ok', $answer)) {
    ask_fail('Агент не ответил — попробуйте ещё раз.', 502);
}
if (!$answer['ok']) {
    http_response_code(502);
}
echo json_encode($answer, JSON_UNESCAPED_UNICODE);
