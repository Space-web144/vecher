<?php
declare(strict_types=1);

// Чтение структуры направлений (structure.php) для меню, главной,
// страниц направлений и карты автоматизации. Сами данные — в
// structure.php, здесь только выборки и общие кусочки разметки.

require_once __DIR__ . '/users.php';

const KB_STATUSES = [
    'done' => 'Готово',
    'progress' => 'В работе',
    'todo' => 'Не начато',
];

function kb_e(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

/** Все модули схемы, без учёта доступа. */
function kb_structure_all(): array
{
    static $sections = null;
    if ($sections === null) {
        $data = require __DIR__ . '/structure.php';
        $sections = is_array($data) ? $data : [];
    }
    return $sections;
}

/** Модули, которые видит текущий пользователь, в порядке схемы. */
function kb_structure(): array
{
    static $sections = null;
    if ($sections === null) {
        $sections = array_values(array_filter(kb_structure_all(), fn(array $s) => kb_can_open_module($s)));
    }
    return $sections;
}

/** Отделы с ограниченным набором общих инструментов; административные роли независимы. */
function kb_limited_department(?string $login = null, ?string $role = null): ?string
{
    $current = $login === null;
    $login = $login ?? (string) ($_SESSION['kb_user'] ?? '');
    $role = $role ?? ($current ? (string) ($_SESSION['kb_role'] ?? '') : role_of_login($login));
    if (is_admin_tier_role($role)) {
        return null;
    }
    $department = $current ? current_department() : department_of_login($login);
    return in_array($department, ['BA', 'KZ', 'SK'], true) ? $department : null;
}

/** Сохранённый признак строгого доступа BA только к Альфику. */
function kb_alfik_only(?string $login = null, ?string $role = null): bool
{
    return kb_limited_department($login, $role) === 'BA';
}

/**
 * Доступ к модулю: модули своего отдела (отдел учётки, задаётся на странице «Пользователи») и общие
 * (без отделов, Альфик); все модули — логинам из KB_PLAN_VIEWERS и администраторам (admin, mainadmin).
 * 'private' — только им. Без $login — текущий пользователь.
 */
function kb_can_open_module(array $module, ?string $login = null, ?string $role = null): bool
{
    $current = $login === null;
    $login = $login ?? (string) ($_SESSION['kb_user'] ?? '');
    $role = $role ?? (string) ($_SESSION['kb_role'] ?? '');
    if (is_admin_tier_role($role)) {
        return true;
    }
    if (kb_limited_department($current ? null : $login, $role) !== null) {
        return ($module['id'] ?? '') === 'alfik';
    }
    $profile = $current ? current_department_profile() : department_profile_of_login($login);
    if ($profile === 'DR') {
        return empty($module['private']);
    }
    if ($profile !== 'NO' && kb_can_see_plans($login)) {
        return true;
    }
    if (!empty($module['private'])) {
        return false;
    }
    $departments = array_map('mb_strtoupper', (array) ($module['departments'] ?? []));
    if (!$departments) {
        return true;
    }
    $mine = $current ? current_department() : department_of_login($login);
    return $mine !== null && in_array($mine, $departments, true);
}

/** Модули, к которым относится страница: файлы инструментов и шаблоны 'pages'. */
function kb_page_modules(string $file): array
{
    $found = [];
    foreach (kb_structure_all() as $module) {
        $files = (array) ($module['pages'] ?? []);
        foreach ($module['tools'] as $tool) {
            $files = array_merge($files, (array) ($tool['files'] ?? [$tool['href']]));
        }
        foreach ($files as $pattern) {
            if ($pattern !== '' && fnmatch((string) $pattern, $file)) {
                $found[] = $module;
                break;
            }
        }
    }
    return $found;
}

/** Общая форма обращений доступна во всех профилях, включая BA, KZ и SK. */
function kb_can_open_page(string $file, ?string $login = null, ?string $role = null): bool
{
    if ($file === 'developer_feedback.php' || $file === 'admin_developer_feedback.php') {
        $account = $login ?? (string) ($_SESSION['kb_user'] ?? '');
        return $file === 'developer_feedback.php' ? $account !== '' : $account === 'veryhardlogin';
    }
    $limitedDepartment = kb_limited_department($login, $role);
    if ($limitedDepartment !== null) {
        return in_array($file, ['agent.php', 'agent_api.php', 'agent_file.php'], true)
            || ($limitedDepartment !== 'BA' && in_array($file, ['docs.php', 'doc_file.php'], true));
    }
    $modules = kb_page_modules($file);
    if (!$modules) {
        return true;
    }
    foreach ($modules as $module) {
        if (kb_can_open_module($module, $login, $role)) {
            return true;
        }
    }
    return false;
}

/** Инструмент, к которому относится запрос общего обработчика спецификаций. */
function kb_spec_target_page(string $file): ?string
{
    if ($file === 'process.php') {
        return ($_POST['mode'] ?? 'full') === 'area' ? 'area.php' : 'ventspec.php';
    }
    if ($file === 'process_pdf.php') {
        return ['area' => 'area.php', 'equipment' => 'equipment.php', 'ventspec' => 'ventspec.php']
            [is_string($_POST['format'] ?? null) ? $_POST['format'] : 'ventspec'] ?? 'ventspec.php';
    }
    if (!in_array($file, ['status.php', 'download.php'], true)) {
        return null;
    }
    // У ПТО и администраторов прежний доступ ко всем результатам.
    if (kb_can_open_page('ventspec.php') && kb_can_open_page('equipment.php')) {
        return null;
    }
    $token = $_GET['token'] ?? '';
    if ($file === 'download.php') {
        $name = $_GET['file'] ?? '';
        if (!is_string($name) || !preg_match('/^([a-f0-9]{16})_(result|spec_otch|1c_report)\.xlsx$/', $name, $match)) {
            return null; // Некорректное имя отклонит сам обработчик.
        }
        $token = $match[1];
    }
    if (!is_string($token) || !preg_match('/^[a-f0-9]{16}$/', $token)) {
        return null;
    }
    $path = defined('OUTPUT_DIR') ? OUTPUT_DIR . '/' . $token . '_status.json' : '';
    if ($path === '' || !is_file($path)) {
        // Страница ожидания доступна, пока результат ещё не создан.
        return $file === 'status.php' ? null : 'ventspec.php';
    }
    $raw = file_get_contents($path);
    $status = $raw !== false ? json_decode($raw, true) : null;
    $mode = is_array($status) && is_string($status['mode'] ?? null) ? $status['mode'] : '';
    return $mode === 'area' ? 'area.php' : ($mode === 'equipment' ? 'equipment.php' : 'ventspec.php');
}

/** Страница модуля чужого отдела — отказ с объяснением (вызывается из auth_guard.php). */
function kb_guard_page(): void
{
    $file = basename((string) ($_SERVER['SCRIPT_NAME'] ?? ''));
    $limitedAccess = kb_limited_department() !== null;
    if ($limitedAccess && $file === 'index.php') {
        header('Location: agent.php');
        exit;
    }
    $canOpen = ($file === '' && !$limitedAccess) || kb_can_open_page($file);
    $target = $canOpen ? kb_spec_target_page($file) : null;
    if ($canOpen && ($target === null || kb_can_open_page($target))) {
        return;
    }
    $modules = kb_page_modules($target ?? $file);
    $names = [];
    foreach ($modules as $module) {
        foreach ((array) ($module['departments'] ?? []) as $code) {
            $names[] = 'отдела «' . department_label(mb_strtoupper((string) $code)) . '»';
        }
    }
    $who = $names ? 'сотрудникам ' . implode(' и ', array_unique($names)) : 'по отдельному доступу';
    $title = (string) ($modules[0]['nav'] ?? 'Модуль');
    http_response_code(403);
    header('Content-Type: text/html; charset=utf-8');
    $css = filemtime(__DIR__ . '/assets/style.css');
    echo '<!doctype html><html lang="ru"><head><meta charset="utf-8">'
        . '<meta name="viewport" content="width=device-width, initial-scale=1">'
        . '<link rel="icon" type="image/svg+xml" href="assets/favicon.svg">'
        . '<title>Модуль другого отдела — База знаний</title>'
        . '<link rel="stylesheet" href="assets/style.css?v=' . $css . '"></head><body><div class="page"><div class="card">'
        . '<h1>Модуль другого отдела</h1>'
        . '<div class="alert warn">Модуль «' . kb_e($title) . '» открыт ' . kb_e($who) . '. '
        . 'Ваш отдел в учётной записи: ' . kb_e(department_label(current_department())) . '. '
        . 'Если модуль нужен вам для работы — попросите администратора сайта открыть его (отдел задаётся на странице «Пользователи»).</div>'
        . '<a class="back-link" href="index.php">На главную</a>'
        . '</div></div></body></html>';
    exit;
}

function kb_section(string $id): ?array
{
    foreach (kb_structure() as $section) {
        if ($section['id'] === $id) {
            return $section;
        }
    }
    return null;
}

/** Направление, к которому относится страница-инструмент (по имени файла). */
function kb_section_of_page(string $file): ?array
{
    foreach (kb_structure() as $section) {
        foreach ($section['tools'] as $tool) {
            if (in_array($file, $tool['files'] ?? [$tool['href']], true)) {
                return $section;
            }
        }
    }
    return null;
}

/** Задачи направления одним списком: [название, статус, пометка, группа]. */
function kb_items(array $section): array
{
    $items = [];
    foreach ($section['plan'] as $group) {
        foreach ($group['items'] as $item) {
            $items[] = [(string) $item[0], (string) $item[1], (string) ($item[2] ?? ''), $group['title'] ?? null];
        }
    }
    return $items;
}

/** Видит ли пользователь план модулей (KB_PLAN_VIEWERS в config.php). */
function kb_can_see_plans(string $login): bool
{
    $accountLogin = trim($login);
    $login = mb_strtolower($accountLogin);
    if ($login === '') {
        return false;
    }
    // Администраторы (admin, mainadmin) видят весь интерфейс: все модули, планы, «Схему направлений», все РВ.
    if (is_admin_tier_role(role_of_login($accountLogin))) {
        return true;
    }
    // ДР, НО, BA, KZ и SK с ролью user не получают управляющие права через старый список фамилий.
    if (in_array(department_profile_of_login($accountLogin), ['DR', 'NO', 'BA', 'KZ', 'SK'], true)) {
        return false;
    }
    $surname = explode('.', $login, 2)[0];
    foreach (defined('KB_PLAN_VIEWERS') ? (array) KB_PLAN_VIEWERS : [] as $entry) {
        $entry = mb_strtolower(trim((string) $entry));
        if ($entry !== '' && ($login === $entry || $surname === $entry)) {
            return true;
        }
    }
    return false;
}

/** Сколько задач в каком статусе; готовый инструмент — выполненная задача. */
function kb_counts(array $sections): array
{
    $counts = ['done' => 0, 'progress' => 0, 'todo' => 0];
    foreach ($sections as $section) {
        foreach ($section['tools'] as $tool) {
            if (($tool['count'] ?? true) !== false) {
                $counts['done']++;
            }
        }
        foreach (kb_items($section) as $item) {
            $status = isset($counts[$item[1]]) ? $item[1] : 'todo';
            $counts[$status]++;
        }
    }
    $counts['total'] = $counts['done'] + $counts['progress'] + $counts['todo'];
    return $counts;
}

/** Направления отдела пользователя — по отделу учётки. */
function kb_user_sections(string $login): array
{
    if (user_has_all_tools($login)) {
        return kb_structure();
    }
    $department = $login === (string) ($_SESSION['kb_user'] ?? '') ? current_department() : department_of_login($login);
    if ($department === null) {
        return [];
    }
    return array_values(array_filter(kb_structure(),
        fn(array $s) => in_array($department, array_map('mb_strtoupper', $s['departments'] ?? []), true)));
}

function kb_owners(array $owners): string
{
    if (!$owners) {
        return 'Ответственный уточняется';
    }
    return (count($owners) > 1 ? 'Ответственные: ' : 'Ответственный: ') . implode(', ', $owners);
}

/** Полоса состояния задач: готово, в работе, не начато. */
function kb_bar(array $counts, bool $withLegend = true): string
{
    $label = 'Задач: ' . $counts['total'] . '. Готово ' . $counts['done'] . ', в работе ' . $counts['progress']
        . ', не начато ' . $counts['todo'] . '.';
    // Без легенды рядом всегда есть подпись словами — полосу читалке не отдаём.
    $html = $withLegend
        ? '<div class="kb-bar" role="img" aria-label="' . kb_e($label) . '">'
        : '<div class="kb-bar" aria-hidden="true">';
    foreach (['done', 'progress', 'todo'] as $status) {
        if ($counts[$status] > 0) {
            $html .= '<span class="kb-bar-part is-' . $status . '" style="flex-grow:' . $counts[$status] . '"></span>';
        }
    }
    $html .= '</div>';
    if ($withLegend) {
        $html .= '<p class="kb-bar-legend" aria-hidden="true">';
        foreach (['done', 'progress', 'todo'] as $status) {
            $html .= '<span class="kb-legend-item"><span class="kb-mark is-' . $status . '"></span>'
                . KB_STATUSES[$status] . ' <b>' . $counts[$status] . '</b></span>';
        }
        $html .= '</p>';
    }
    return $html;
}

/** Строки задач направления с отметкой статуса — для страницы направления и карты. */
function kb_plan_html(array $section, bool $compact = false): string
{
    $html = '';
    foreach ($section['plan'] as $group) {
        $html .= '<div class="kb-plan-group">';
        if (!empty($group['title'])) {
            $html .= '<h3 class="kb-plan-title">' . kb_e($group['title'])
                . (!empty($group['owner']) ? ' <span class="kb-plan-owner">' . kb_e($group['owner']) . '</span>' : '')
                . '</h3>';
        }
        // Как внедряем: что даёт группа задач, с чего начинается и что нужно от 1С (structure.php, 'about' группы).
        if (!$compact && !empty($group['about'])) {
            $html .= '<p class="kb-plan-about">' . kb_e((string) $group['about']) . '</p>';
        }
        $html .= '<ul class="kb-plan' . ($compact ? ' is-compact' : '') . '">';
        foreach ($group['items'] as $item) {
            $status = isset(KB_STATUSES[$item[1]]) ? $item[1] : 'todo';
            $note = (string) ($item[2] ?? '');
            $html .= '<li class="kb-plan-item is-' . $status . '" data-status="' . $status . '">'
                . '<span class="kb-mark is-' . $status . '" aria-hidden="true"></span>'
                . '<span class="kb-plan-text">' . kb_e((string) $item[0])
                . ($note !== '' ? ' <span class="kb-plan-note">' . kb_e($note) . '</span>' : '') . '</span>'
                . '<span class="kb-plan-status">' . KB_STATUSES[$status] . '</span>'
                . '</li>';
        }
        $html .= '</ul></div>';
    }
    return $html;
}

/** Иконки направлений и инструментов — линейные, толщина 1,7, как в меню. */
function kb_icon(string $name, int $size = 24): string
{
    static $paths = [
        'home' => '<path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V20a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1V9.5"/>',
        'assistant' => '<path d="M5 4h14a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-8l-5 4v-4H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z"/><path d="M8 9h8M8 12.5h5"/>',
        'docs' => '<path d="M4 19.5V5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2.5z"/><path d="M4 19.5A2.5 2.5 0 0 0 6.5 22H19v-3"/><path d="M8 8h7M8 12h5"/>',
        'roadmap' => '<path d="M9 4 3 6v14l6-2 6 2 6-2V4l-6 2z"/><path d="M9 4v14M15 6v14"/>',
        'fact' => '<path d="M5 21V4"/><path d="M5 4h12l-2.5 4L17 12H5"/>',
        'rv' => '<path d="M3 3v18h18"/><path d="M7 7h7M9 11h9M7 15h6"/>',
        'drawings' => '<path d="M4 20V4l16 16z"/><path d="M8 16v-4.5l4.5 4.5z"/>',
        'id' => '<path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v8a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><path d="m9 13 2 2 4-4"/>',
        'sdo' => '<rect x="5" y="4" width="14" height="17" rx="2"/><path d="M9 4V3h6v1"/><path d="m9 13 2 2 4-4"/>',
        'co' => '<rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 7h8M8 11h.01M12 11h.01M16 11h.01M8 14.5h.01M12 14.5h.01M16 14.5h.01M8 18h8"/>',
        'mapping' => '<path d="M4 8h14l-3-3M20 16H6l3 3"/>',
        'hr' => '<path d="M17 21v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2"/><circle cx="10" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75"/>',
        'omts' => '<path d="M3 6h11v10H3z"/><path d="M14 10h4l3 3v3h-7"/><circle cx="7" cy="18" r="2"/><circle cx="17" cy="18" r="2"/>',
        'buh' => '<path d="M9 21V3h5a4.5 4.5 0 0 1 0 9H6M6 16.5h9"/>',
        'law' => '<path d="M12 4v16M8 20h8M5 7h14"/><path d="M5 7 2.5 13a2.5 2.5 0 0 0 5 0zM19 7l-2.5 6a2.5 2.5 0 0 0 5 0z"/>',
        'verrata' => '<path d="M8 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h3"/><path d="M16 3h3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-3"/><path d="M9 8h2M9 12h4M9 16h2"/>',
        'equipment' => '<circle cx="12" cy="12" r="3.2"/><path d="M12 4.2V6M12 18v1.8M4.2 12H6M18 12h1.8M6.5 6.5 7.8 7.8M16.2 16.2l1.3 1.3M17.5 6.5 16.2 7.8M7.8 16.2l-1.3 1.3"/>',
        'area' => '<rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/>',
        'water' => '<path d="M12 3s7 7.5 7 12a7 7 0 0 1-14 0c0-4.5 7-12 7-12z"/>',
        'ventspec' => '<rect x="3" y="5" width="18" height="14" rx="3"/><path d="M6 9h12M6 12h12M6 15h12"/>',
        'users' => '<path d="M17 21v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2"/><circle cx="10" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/>',
        'log' => '<path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/><path d="M8 8h8M8 12h5"/>',
        'onec' => '<path d="M21 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h6"/><path d="M7 8h6M7 12h4"/><path d="M16 15.5 21 20.5"/><circle cx="16.5" cy="15.5" r="3.5"/>',
        'base' => '<ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v14c0 1.66 3.58 3 8 3s8-1.34 8-3V5"/><path d="M4 12c0 1.66 3.58 3 8 3s8-1.34 8-3"/>',
    ];
    return '<svg width="' . $size . '" height="' . $size . '" viewBox="0 0 24 24" fill="none" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'
        . ($paths[$name] ?? $paths['docs']) . '</svg>';
}

/** Плитка готового инструмента — главная и страница направления. */
function kb_tool_tile(array $tool, ?string $sectionName = null): string
{
    $tags = '';
    if ($sectionName !== null || !empty($tool['tags'])) {
        $tags = '<span class="kb-tags">'
            . ($sectionName !== null ? '<span class="kb-tag is-section">' . kb_e($sectionName) . '</span>' : '')
            . implode('', array_map(fn($t) => '<span class="kb-tag">' . kb_e((string) $t) . '</span>', $tool['tags'] ?? []))
            . '</span>';
    }
    return '<a class="home-tile" href="' . kb_e($tool['href']) . '">' . kb_icon($tool['icon'] ?? 'docs')
        . '<span class="home-tile-name">' . kb_e($tool['name']) . '</span>'
        . '<span class="home-tile-text">' . kb_e($tool['text']) . '</span>' . $tags . '</a>';
}

/** «готово 1 из 4» — для подписи к полосе. */
function kb_done_text(array $counts): string
{
    if ($counts['total'] === 0) {
        return 'задач нет';
    }
    $text = 'готово ' . $counts['done'] . ' из ' . $counts['total'];
    return $counts['progress'] > 0 ? $text . ', в работе ' . $counts['progress'] : $text;
}

function kb_cap(string $text): string
{
    return mb_strtoupper(mb_substr($text, 0, 1)) . mb_substr($text, 1);
}
