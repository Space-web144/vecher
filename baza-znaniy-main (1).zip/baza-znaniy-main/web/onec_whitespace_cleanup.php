<?php
declare(strict_types=1);

// Разовая нормализация пробелов в уже накопленной номенклатуре 1С —
// заказчик попросил привести DB_FILE (боевая база сравнения) и
// ONEC_NOMENCLATURE_FILE (снимок для проверки дублей) "к нормальному
// виду": между словами максимум один пробел, без пробелов по краям. Для
// НОВЫХ позиций это больше не нужно делать вручную — common/
// nomenclature_intake.py чистит их сам при приёме от 1С (см.
// _append_to_bases/clean_whitespace). Эта страница — только для того,
// что уже накопилось ДО этого исправления. Доступно только
// admin/mainadmin (см. admin_guard.php).
//
// GET без параметров — всегда свежий сухой прогон (--apply не передаётся,
// на диске ничего не меняется): показывает, сколько позиций затронет, и
// примеры "было → стало". POST — тот же скрипт, но с --apply: перед
// записью скрипт сам делает резервную копию каждого файла (.bak-<время>
// рядом с оригиналом), поэтому отдельного бэкапа здесь не делаем.

require __DIR__ . '/admin_guard.php';
require __DIR__ . '/config.php';

if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(16));
}
$csrf = $_SESSION['csrf'];

function run_whitespace_cleanup(bool $apply): array {
    $cmd = implode(' ', [
        escapeshellarg(PYTHON_BIN),
        escapeshellarg(WEB_DB_WHITESPACE_CLEANUP_SCRIPT),
        '--db', escapeshellarg(DB_FILE),
        '--existing', escapeshellarg(ONEC_NOMENCLATURE_FILE),
        $apply ? '--apply' : '',
    ]) . ' 2>&1';
    $output = shell_exec($cmd);
    if ($output === null || trim($output) === '') {
        return ['ok' => false, 'error' => 'команда не выполнилась (shell_exec недоступен на сервере, '
            . 'или путь PYTHON_BIN в config.php неверный).'];
    }
    $result = json_decode($output, true);
    if (!is_array($result) || empty($result['ok'])) {
        // Admin-only страница — показываем реальный вывод скрипта (traceback
        // и т.п.), как и на onec_database.php, иначе причину не понять без
        // доступа к серверу. Обрезаем с начала — конец длинного traceback
        // обычно содержательнее.
        $detail = is_array($result) ? (string) ($result['error'] ?? 'неизвестная ошибка') : trim($output);
        if (mb_strlen($detail, 'UTF-8') > 2000) {
            $detail = '…' . mb_substr($detail, -2000, null, 'UTF-8');
        }
        return ['ok' => false, 'error' => $detail];
    }
    return $result;
}

$applyError = null;
$applyResult = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (empty($_SESSION['csrf']) || !hash_equals((string) $_SESSION['csrf'], (string) ($_POST['csrf'] ?? ''))) {
        header('Location: onec_whitespace_cleanup.php?err=' . urlencode('Сессия истекла, обновите страницу и попробуйте снова.'));
        exit;
    }
    $result = run_whitespace_cleanup(true);
    if (empty($result['ok'])) {
        header('Location: onec_whitespace_cleanup.php?err=' . urlencode((string) ($result['error'] ?? 'неизвестная ошибка')));
        exit;
    }
    $dbChanged = (int) ($result['db_file']['changed'] ?? 0);
    $existingChanged = (int) ($result['existing_file']['changed'] ?? 0);
    header('Location: onec_whitespace_cleanup.php?applied=1&dbChanged=' . $dbChanged . '&existingChanged=' . $existingChanged);
    exit;
}

$err = isset($_GET['err']) ? (string) $_GET['err'] : null;
$applied = isset($_GET['applied']);
$appliedDbChanged = (int) ($_GET['dbChanged'] ?? 0);
$appliedExistingChanged = (int) ($_GET['existingChanged'] ?? 0);

$report = $err === null ? run_whitespace_cleanup(false) : ['ok' => false, 'error' => $err];
$reportError = empty($report['ok']) ? (string) ($report['error'] ?? 'неизвестная ошибка') : null;
$dbInfo = $report['db_file'] ?? null;
$existingInfo = $report['existing_file'] ?? null;
$totalChanged = (int) ($dbInfo['changed'] ?? 0) + (int) ($existingInfo['changed'] ?? 0);
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Нормализация пробелов — База знаний</title>
<link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
<script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
</head>
<body>
<div class="shell">
  <?php require __DIR__ . '/sidebar.php'; ?>

  <div class="dashboard-main">
  <div class="page-wide">

  <a class="back-link" href="onec_database.php">← К базе номенклатуры</a>

  <div class="card">
    <h1>Нормализация пробелов в номенклатуре</h1>
    <p class="subtitle">
      Приводит наименования в DB_FILE и в снимке для проверки дублей к единому виду: между словами
      максимум один пробел, без пробелов по краям. Проверяется автоматически при каждом открытии
      страницы — ничего на диске не меняется, пока не нажата кнопка «Применить». Перед применением
      каждый файл сохраняется в резервную копию рядом с оригиналом (<code>.bak-ГГГГММДДЧЧММСС</code>).
    </p>

    <?php if ($applied): ?>
    <div class="alert success">
      Готово: исправлено наименований — в базе сравнения (DB_FILE): <?= $appliedDbChanged ?>,
      в снимке для проверки дублей: <?= $appliedExistingChanged ?>.
    </div>
    <?php endif; ?>

    <?php if ($reportError !== null): ?>
    <div class="alert error" style="white-space: pre-wrap; font-family: ui-monospace, monospace; font-size: 0.85rem;"><?= htmlspecialchars($reportError, ENT_QUOTES, 'UTF-8') ?></div>
    <?php else: ?>

    <div class="table-wrap" style="margin-bottom: 18px;">
      <table class="data-table">
        <thead>
          <tr>
            <th>Файл</th>
            <th>Всего позиций</th>
            <th>С лишними пробелами</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td data-label="Файл">База сравнения (DB_FILE)</td>
            <td data-label="Всего позиций"><?= (int) ($dbInfo['total'] ?? 0) ?></td>
            <td data-label="С лишними пробелами"><?= (int) ($dbInfo['changed'] ?? 0) ?></td>
          </tr>
          <tr>
            <td data-label="Файл">Снимок для проверки дублей</td>
            <td data-label="Всего позиций"><?= (int) ($existingInfo['total'] ?? 0) ?></td>
            <td data-label="С лишними пробелами"><?= (int) ($existingInfo['changed'] ?? 0) ?></td>
          </tr>
        </tbody>
      </table>
    </div>

    <?php if ($totalChanged === 0): ?>
    <p class="subtitle">Лишних пробелов не найдено — обе базы уже в нормальном виде.</p>
    <?php else: ?>

    <?php foreach ([['База сравнения (DB_FILE)', $dbInfo], ['Снимок для проверки дублей', $existingInfo]] as [$label, $info]): ?>
      <?php $examples = $info['examples'] ?? []; ?>
      <?php if ($examples): ?>
      <h3 style="margin-top: 18px;"><?= htmlspecialchars($label, ENT_QUOTES, 'UTF-8') ?> — примеры</h3>
      <div class="table-wrap">
        <table class="data-table">
          <thead>
            <tr>
              <th>Код</th>
              <th>Было</th>
              <th>Станет</th>
            </tr>
          </thead>
          <tbody>
            <?php foreach ($examples as $ex): ?>
            <tr>
              <td data-label="Код"><?= htmlspecialchars((string) ($ex['Код'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
              <td data-label="Было" style="font-family: ui-monospace, monospace;"><?= htmlspecialchars((string) ($ex['было'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
              <td data-label="Станет" style="font-family: ui-monospace, monospace;"><?= htmlspecialchars((string) ($ex['стало'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
            </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
      <?php if ((int) ($info['changed'] ?? 0) > count($examples)): ?>
      <p class="subtitle">Показаны первые <?= count($examples) ?> из <?= (int) $info['changed'] ?>.</p>
      <?php endif; ?>
      <?php endif; ?>
    <?php endforeach; ?>

    <form method="post" action="onec_whitespace_cleanup.php" style="margin-top: 18px;"
          onsubmit="return confirm('Исправить пробелы в <?= $totalChanged ?> наименованиях? Перед записью будут сделаны резервные копии файлов.')">
      <input type="hidden" name="csrf" value="<?= htmlspecialchars((string) $csrf, ENT_QUOTES, 'UTF-8') ?>">
      <button type="submit" class="btn-small">Применить (<?= $totalChanged ?>)</button>
    </form>

    <?php endif; ?>
    <?php endif; ?>
  </div>

  </div>
  </div>
</div>
</body>
</html>
