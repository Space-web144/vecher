<?php
declare(strict_types=1);

// Приём ЛРВ от 1С для агента РВ. Как и 1c_intake.php, сюда обращается не
// браузер, а 1С: вместо входа по логину — общий ключ в заголовке X-API-Key
// (файл ONEC_API_KEY_FILE: поле rv_api_key, если задано, иначе api_key),
// ответ — JSON для скрипта 1С. Инструкция для программиста 1С —
// docs/1С_выгрузка_ЛРВ_на_сайт.md.
//
// POST (application/json) — прислать ЛРВ:
//   {"ИдентификаторЛРВ": "…", "Объект": "…", "Версия": "…", "ТипОбъекта": "жилой",
//    "ПапкаНГ", "ПапкаНГGUID", "НоменклатурнаяГруппа", "НоменклатурнаяГруппаGUID", "Смета", "СметаGUID",
//    "СистемаСметы", "СистемаСметыGUID", "НомерЗН" — для дерева объектов (необязательны),
//    "Отправил" (кто в 1С отправил на сайт; пусто — регламентное задание) — показывается на сайте,
//    "РаботыСметы": [{"Код", "Наименование", "ЕдиницаИзмерения", "ЕдиницаИзмеренияGUID", "Количество", "СметнаяПозицияGUID"}] — работы сметы,
//    у строк "РаботыВ1С": [{"Код", "Наименование", "Количество", "Коэффициент"}] — как строку уже разнесли в 1С;
//    пакет из обработки шлёт то и другое одним блоком, как лежит в 1С: "СметныеПозиции": [{"СметнаяПозиция",
//    "СметнаяПозицияGUID", "Код", "Работа", "РаботаGUID", "КодИерархии", "ЕдиницаИзмерения", "Количество",
//    "Материалы": [{…как строка, "Колво", "КолвоВСмету", "ВесовойКоэф"}]}] — сайт сам выводит из них работы сметы
//    и строки разнесённого (rv1c_expand_positions); обработка шлёт позиции с полями 1С (сити_…НаименованиеРаботы,
//    УИДУзлаДерева) и разнесённое плоским деревом "МассивРабот" (строки материалов: "КолвоМатериала",
//    "СметаКодИерархия") — принимается так же,
//    "Раздел": "ВК", "Система": "ВК|В1", "Ответственный": "логин на сайте",
//    "Строки": [{"ИдентификаторСтроки", "Номенклатура", "Код", "ЕдиницаИзмерения", "Количество", "Система", "Аналитика",
//               …любые другие поля 1С (GUID номенклатуры, субконто) — вернутся в РВ как есть}]}
//   либо вместо «Строк» — отчёт «Остатки по ЛРВ» файлом: "Файл": base64, "ИмяФайла": "….xlsx".
//   Принимается и выгрузка обработки «Соответствие РВ и ЛРВ» (шапка «Сопоставление», «СметаGUID», «Аналитика1..4»,
//   строки «Колво», «НоменклатураGUID», «СпецОсновнаяСметнаяПозицияНоменклатура»…) — приводится к этому же виду
//   (rv1c_normalize_sopost), в том числе в обёртке ЗначениеВСтрокуВнутр {"S","…"} (rv1c_unwrap).
//   Та же ЛРВ с тем же содержимым второй раз не обрабатывается (ответ duplicate: true);
//   изменилась — новая РВ, прежняя помечается «есть новая версия».
//   Присланное встаёт в очередь: агент разбирает ЛРВ по одной (на общем хостинге
//   несколько сразу не помещаются), ответ приходит сразу — 202 и номер задачи.
// POST {"Событие": "РВЗагружена", "token", "Успех", "Сообщение", "Документ", "Номер", "Дата", "Проведен"} — 1С сообщает, что РВ загружена
//   (или нет) — для дерева «Объекты и ЛРВ из 1С» (rv_registry.php).
// POST {"Событие": "Эталон", "Сметы": [...], "БезСметы": [...]} — эталон смет с ЛРВ для контроля полноты;
// POST {"Событие": "ФактЛРВ", "СметаGUID", "Строки": [...]} — факт по строкам ЛРВ (документ ЛРВ, поступило);
// POST {"Событие": "ЗапросВыполнен", "СметаGUID", "Успех", "Сообщение", "token"} — ответ на запрос сметы
//   (rv_onec_lib.php).
// GET ?token=… или ?id=<ИдентификаторЛРВ> — состояние РВ; &file=xlsx — книга; &file=json — РВ для 1С
// (работы ИСР с объёмами, под ними строки ЛРВ с идентификаторами 1С — для связей и сквозных аналитик).
// GET ?action=requests — сметы, которые на сайте запросили у 1С (rv_request.php); взятые помечаются.
// GET ?action=ready — согласованные РВ, которые 1С ещё не загрузила (токены и ссылки; 1С токены не хранит).
//
// РВ из 1С видны на странице «РВ по ЛРВ» всем, у кого есть доступ к РВ.

require __DIR__ . '/config.php';
require_once __DIR__ . '/lib.php';
require_once __DIR__ . '/structure_lib.php';
require_once __DIR__ . '/rv_lib.php';
require_once __DIR__ . '/rv_onec_lib.php';

if (PHP_SAPI === 'cli' && getenv('RV1C_FUNCTIONS_ONLY') === '1') {
    return;     // только функции — для тестов (program-c/tests/test_rv.py, нормализация пакета из обработки)
}

function rv1c_fail(string $message, int $code = 400): never
{
    rv_json(['ok' => false, 'error' => $message], $code);
}

// ── Ключ ──
if (!is_file(ONEC_API_KEY_FILE)) {
    rv1c_fail('Приём ЛРВ от 1С не настроен на сервере (нет файла ключа). Обратитесь к администратору.', 500);
}
$keyConfig = require ONEC_API_KEY_FILE;
$expected = is_array($keyConfig) ? (string) ($keyConfig['rv_api_key'] ?? $keyConfig['api_key'] ?? '') : '';
$provided = (string) ($_SERVER['HTTP_X_API_KEY'] ?? '');
if ($expected === '' || $provided === '' || !hash_equals($expected, $provided)) {
    rv1c_fail('Неверный или отсутствующий X-API-Key.', 401);
}

/** Ссылка на страницу РВ на сайте (для ответа 1С и для письма ответственному). */
function rv1c_url(string $token): string
{
    $https = (string) ($_SERVER['HTTPS'] ?? '') !== '' && (string) ($_SERVER['HTTPS'] ?? '') !== 'off';
    $host = (string) ($_SERVER['HTTP_HOST'] ?? 'alfastroi.info');
    $dir = rtrim(str_replace('\\', '/', dirname((string) ($_SERVER['SCRIPT_NAME'] ?? '/'))), '/');
    return ($https ? 'https' : 'http') . '://' . $host . $dir . '/rv_status.php?token=' . $token;
}

/** Индекс присланных ЛРВ: ИдентификаторЛРВ → [{token, hash, version, received}]. Читать и писать под блокировкой. */
function rv1c_index(callable $change)
{
    $dir = dirname(RV_1C_INDEX_FILE);
    if (!is_dir($dir)) {
        @mkdir($dir, 0775, true);
    }
    $fh = fopen(RV_1C_INDEX_FILE, 'c+');
    if ($fh === false) {
        rv1c_fail('Не удалось открыть журнал присланных ЛРВ на сервере.', 500);
    }
    flock($fh, LOCK_EX);
    $raw = stream_get_contents($fh);
    $index = json_decode((string) $raw, true);
    $index = is_array($index) ? $index : [];
    [$index, $result] = $change($index);
    ftruncate($fh, 0);
    rewind($fh);
    fwrite($fh, json_encode($index, JSON_UNESCAPED_UNICODE));
    fflush($fh);
    flock($fh, LOCK_UN);
    fclose($fh);
    return $result;
}

/**
 * Задача по идентификатору из 1С (GET ?id=…): последняя версия ЛРВ. Принимается не только ИдентификаторЛРВ как его
 * прислали («Смета-<GUID>», «Сверка-<GUID>», «Сопоставление-<GUID>»), но и без приставки или в другом регистре, GUID в
 * фигурных скобках, GUID сметы или документа «Сопоставление РВ и ЛРВ», УИДСайта и КодСайта (token) из РВ для 1С — что
 * 1С проще передать. Несколько ЛРВ с тем же GUID — сначала рабочая («Смета-», «Сопоставление-»), сверка — последней.
 * Не нашлась — ''.
 */
function rv1c_find_token(array $index, string $id): string
{
    $id = trim($id, " \t\n\r\0\x0B{}");
    if ($id === '') {
        return '';
    }
    $last = static fn (array $versions): string => $versions ? (string) (end($versions)['token'] ?? '') : '';
    if (isset($index[$id])) {
        return $last((array) $index[$id]);
    }
    if (rv_token_valid($id) && is_file(rv_paths($id)['job'])) {
        return $id;                                                     // КодСайта
    }
    $lower = mb_strtolower($id);
    $guid = mb_strtolower(rv_clean_guid($id) !== '' ? rv_clean_guid($id) : $id);
    $rank = static function (string $key): int {
        $key = mb_strtolower($key);
        return str_starts_with($key, 'смета-') ? 0 : (str_starts_with($key, 'сопоставление-') ? 1 : (str_starts_with($key, 'сверка-') ? 3 : 2));
    };
    $found = [];
    foreach ($index as $key => $versions) {
        $key = (string) $key;
        if (mb_strtolower($key) === $lower || ($guid !== '' && mb_strtolower(rv_clean_guid($key)) === $guid)) {
            $found[$key] = $rank($key);
        }
    }
    if ($found) {
        asort($found);
        return $last((array) $index[array_key_first($found)]);
    }
    if (rv_clean_guid($id) === '') {
        return '';
    }
    // УИДСайта — у каждой версии свой; GUID сметы или «Сопоставления» — из задачи (последняя версия ЛРВ).
    $byJob = [];
    foreach ($index as $key => $versions) {
        foreach ((array) $versions as $version) {
            $token = (string) ($version['token'] ?? '');
            if ($token !== '' && rv_site_uuid($token) === $guid) {
                return $token;
            }
        }
        $token = $last((array) $versions);
        $job = $token !== '' && rv_token_valid($token) ? rv_read_json(rv_paths($token)['job']) : null;
        if (is_array($job)) {
            $ids = [(string) ($job['meta']['smeta_id'] ?? ''), (string) ($job['sopost']['doc_id'] ?? '')];
            if (in_array($guid, array_map('mb_strtolower', array_map('trim', $ids)), true)) {
                $byJob[(string) $key] = $rank((string) $key);
            }
        }
    }
    if ($byJob) {
        asort($byJob);
        return $last((array) $index[array_key_first($byJob)]);
    }
    return '';
}

/**
 * РВ, готовые к загрузке в 1С (GET ?action=ready): по каждой ЛРВ из 1С — её последняя версия, если РВ готова,
 * согласована на сайте, ещё не загружена в 1С и для неё есть РВ для 1С; не сверка. Загрузка в 1С не удалась —
 * РВ остаётся в списке с load_error. 1С не нужно хранить token: она берёт список, забирает каждую РВ
 * (?file=json&token=…) и сообщает результат событием «РВЗагружена» — после успеха РВ из списка уходит.
 */
function rv1c_ready_list(): array
{
    $raw = is_file(RV_1C_INDEX_FILE) ? (string) file_get_contents(RV_1C_INDEX_FILE) : '';
    $index = json_decode($raw, true);
    $ready = [];
    foreach (is_array($index) ? $index : [] as $lrvId => $versions) {
        $versions = (array) $versions;
        $token = $versions ? (string) (end($versions)['token'] ?? '') : '';
        if (!rv_token_valid($token)) {
            continue;
        }
        $paths = rv_paths($token);
        $job = rv_read_json($paths['job']);
        if ($job === null || ($job['mode'] ?? '') === 'audit' || !empty($job['superseded_by']) || rv_onec_loaded($job)
                || !is_file($paths['onec'])) {
            continue;
        }
        [$state, $status] = rv_state($token, $job);
        $approval = $state === 'done' ? rv_approval($job, $status) : null;
        if ($approval === null) {
            continue;
        }
        $url = rv1c_url($token);
        $onec = is_array($job['onec'] ?? null) ? $job['onec'] : null;
        $meta = is_array($job['meta'] ?? null) ? $job['meta'] : [];
        $ready[] = [
            'token' => $token,
            'lrv_id' => (string) $lrvId,
            'smeta_id' => (string) ($meta['smeta_id'] ?? '') !== '' ? (string) $meta['smeta_id'] : rv_clean_guid((string) $lrvId),
            'smeta' => (string) ($meta['smeta'] ?? ''),
            'sopost_id' => (string) ($job['sopost']['doc_id'] ?? ''),
            'object' => (string) ($job['object'] ?? ''),
            'version' => (string) ($job['version'] ?? ''),
            'code_root' => rv_code_root_of($job['code_root'] ?? '') === '12' ? '12' : '6',
            'site_uid' => rv_site_uuid($token),
            'checked' => ['user' => $approval['user'], 'when' => date('c', $approval['when']),
                          'corrected' => $approval['corrected'], 'confirmed' => $approval['confirmed']],
            'load_error' => $onec !== null ? ['message' => (string) ($onec['message'] ?? ''),
                                              'when' => date('c', (int) ($onec['at'] ?? 0))] : null,
            'json' => preg_replace('~/rv_status\.php\?token=~', '/1c_rv.php?file=json&token=', $url),
            'xlsx' => preg_replace('~/rv_status\.php\?token=~', '/1c_rv.php?file=xlsx&token=', $url),
            'url' => $url,
        ];
    }
    usort($ready, static fn (array $a, array $b): int => strcmp($a['checked']['when'], $b['checked']['when']));
    return $ready;
}

/** Состояние задачи для ответа 1С. */
function rv1c_state(string $token): array
{
    $paths = rv_paths($token);
    $job = rv_read_json($paths['job']);
    if ($job === null) {
        return ['ok' => false, 'token' => $token, 'state' => 'deleted', 'smeta_status' => 'deleted',
                'smeta_status_text' => 'РВ удалена на сайте', 'error' => 'РВ удалена или устарела.'];
    }
    [$state, $status] = rv_state($token, $job);
    // Смета и её статус на сайте — тот же, что в дереве «Объекты и ЛРВ из 1С» (rv_registry_state):
    // queued, running, awaiting, ready (готова, не согласована), approved (согласована), loaded (загружена в 1С),
    // load_error, error. GUID сметы — из шапки пакета (СметаGUID), у старых задач — из «Смета-<GUID>».
    $lrvId = (string) ($job['lrv_id'] ?? '');
    $meta = rv_registry_meta($job, rv_objects());
    $smetaId = $meta['smeta_id'] !== '' ? $meta['smeta_id']
        : (preg_match('/^смета-(.+)$/iu', $lrvId, $m) ? $m[1] : '');
    [$statusCode, $statusText] = rv_registry_state($job, $state, $status);
    if (($job['mode'] ?? '') === 'audit') {
        // Сверка РВ из 1С — не рабочая ЛРВ: согласования и загрузки в 1С у неё нет.
        [$statusCode, $statusText] = $state === 'done' ? ['audit', 'Сверка готова'] : [$statusCode, $statusText];
    }
    $out = ['ok' => true, 'token' => $token, 'lrv_id' => $lrvId,
            'smeta_id' => $smetaId, 'smeta' => $meta['smeta'], 'smeta_status' => $statusCode, 'smeta_status_text' => $statusText,
            'state' => $state, 'stage' => (string) ($status['stage'] ?? ''), 'url' => rv1c_url($token)];
    if (!empty($job['superseded_by'])) {
        $out['superseded_by'] = (string) $job['superseded_by'];
    }
    $summary = is_array($status['summary'] ?? null) ? $status['summary'] : null;
    if ($summary) {
        $out['summary'] = ['rows' => (int) ($summary['rows'] ?? 0), 'works' => (int) ($summary['works'] ?? 0),
                           'review' => (int) ($summary['review'] ?? 0), 'unbound' => (int) ($summary['unbound'] ?? 0),
                           'sections' => array_values((array) ($summary['sections'] ?? []))];
    }
    if ($state === 'done') {
        $out['xlsx'] = preg_replace('~/rv_status\.php\?token=~', '/1c_rv.php?file=xlsx&token=', $out['url']);
        $out['json'] = preg_replace('~/rv_status\.php\?token=~', '/1c_rv.php?file=json&token=', $out['url']);
        $out['version'] = (string) ($job['version'] ?? '');
        // Проверка инженером («Согласовать РВ» на сайте): кто и сколько строк исправил и подтвердил.
        // 1С по умолчанию грузит РВ только после неё (СайтРВ_Обмен в репозитории alfa-1c).
        // Согласованной считается только целиком разнесённая РВ (rv_feedback.php не даёт сохранить
        // проверку, пока есть строки без работы; здесь — на случай, если пересборка что-то не привязала).
        $approval = rv_approval($job, $status);
        $out['checked'] = $approval ? ['user' => $approval['user'], 'when' => date('c', $approval['when']),
                                       'corrected' => $approval['corrected'], 'confirmed' => $approval['confirmed']] : null;
    }
    if (in_array($state, ['error', 'stalled', 'missing'], true)) {
        $out['error'] = (string) ($status['error'] ?? 'РВ не построена.');
    }
    return $out;
}

// ── GET: состояние и книга ──
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    if ((string) ($_GET['action'] ?? '') === 'requests') {
        rv_json(['ok' => true, 'requests' => rv_requests_take()]);
    }
    if ((string) ($_GET['action'] ?? '') === 'ready') {
        // Согласованные РВ, которые ещё не загружены в 1С (rv1c_ready_list): 1С не хранит token у себя.
        $ready = rv1c_ready_list();
        rv_json(['ok' => true, 'count' => count($ready), 'ready' => $ready]);
    }
    $token = (string) ($_GET['token'] ?? '');
    if ($token === '' && isset($_GET['id'])) {
        $id = trim((string) $_GET['id']);
        $token = (string) rv1c_index(static fn (array $index): array => [$index, rv1c_find_token($index, $id)]);
        if ($token === '') {
            rv1c_fail('ЛРВ «' . mb_substr($id, 0, 80) . '» на сайт не присылали: не нашлась ни по ИдентификаторЛРВ (в т. ч. '
                . 'без приставки «Смета-»), ни по GUID сметы или «Сопоставления», ни по УИДСайта или КодСайта. Проверьте, '
                . 'что ЛРВ отправлялась именно на этот сайт, или запросите РВ по token из ответа на её приём.', 404);
        }
    }
    if (!rv_token_valid($token)) {
        rv1c_fail('Нужен параметр token (номер задачи из ответа на приём), id (ИдентификаторЛРВ) или action=ready '
            . '(список РВ, готовых к загрузке в 1С).');
    }
    if ((string) ($_GET['file'] ?? '') === 'json') {
        // РВ для 1С: работы с объёмами, под ними строки ЛРВ со всеми идентификаторами, что прислала 1С.
        $paths = rv_paths($token);
        $job = rv_read_json($paths['job']);
        if ($job === null || !is_file($paths['onec'])) {
            rv1c_fail('РВ для 1С ещё не готова или удалена.', 404);
        }
        header('Content-Type: application/json; charset=utf-8');
        header('Cache-Control: no-store');
        // РВ, собранная до появления полей связи (КодСайта, УИДСайта, ЛРВGUID, Смета, СметаGUID), дополняется ими из задачи.
        $enriched = rv_onec_json_enriched($paths['onec'], $job);
        if ($enriched !== null) {
            header('Content-Length: ' . (string) strlen($enriched));
            echo $enriched;
            exit;
        }
        if (substr($paths['onec'], -3) === '.gz') {
            if (strpos((string) ($_SERVER['HTTP_ACCEPT_ENCODING'] ?? ''), 'gzip') !== false && !ini_get('zlib.output_compression')) {
                header('Content-Encoding: gzip');
                header('Content-Length: ' . (string) filesize($paths['onec']));
                readfile($paths['onec']);
            } else {
                readgzfile($paths['onec']);
            }
        } else {
            header('Content-Length: ' . (string) filesize($paths['onec']));
            readfile($paths['onec']);
        }
        exit;
    }
    if ((string) ($_GET['file'] ?? '') === 'xlsx') {
        $paths = rv_paths($token);
        $job = rv_read_json($paths['job']);
        if ($job === null || !is_file($paths['xlsx'])) {
            rv1c_fail('Книга ещё не готова или удалена.', 404);
        }
        $name = 'РВ ' . sanitize_display_base(pathinfo((string) ($job['source_name'] ?? 'ЛРВ'), PATHINFO_FILENAME)) . '.xlsx';
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Length: ' . (string) filesize($paths['xlsx']));
        header('Content-Disposition: attachment; filename="rv.xlsx"; filename*=UTF-8\'\'' . rawurlencode($name));
        readfile($paths['xlsx']);
        exit;
    }
    $state = rv1c_state($token);
    rv_json($state, $state['ok'] ? 200 : 404);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    rv1c_fail('Ожидался POST (прислать ЛРВ) или GET (узнать состояние).', 405);
}

// ── POST: приём ЛРВ ──
if ((int) ($_SERVER['CONTENT_LENGTH'] ?? 0) > RV_1C_MAX_BYTES) {
    rv1c_fail('Слишком большой пакет (максимум ' . intdiv(RV_1C_MAX_BYTES, 1024 * 1024) . ' МБ).', 413);
}
$body = file_get_contents('php://input', false, null, 0, RV_1C_MAX_BYTES + 1);
if ($body === false || $body === '') {
    rv1c_fail('Пустое тело запроса — ожидался JSON с ЛРВ.');
}
if (strlen($body) > RV_1C_MAX_BYTES) {
    rv1c_fail('Слишком большой пакет (максимум ' . intdiv(RV_1C_MAX_BYTES, 1024 * 1024) . ' МБ).', 413);
}
if (strncmp($body, "\xEF\xBB\xBF", 3) === 0) {
    $body = substr($body, 3);          // ЗаписьJSON 1С может поставить BOM
}
$body = rv1c_unwrap($body);
$data = json_decode($body, true);
if (!is_array($data) || array_is_list($data)) {
    rv1c_fail('Ожидался JSON-объект с полями «ИдентификаторЛРВ» и «Строки» (или «Файл»).');
}

// ── События контроля полноты (rv_onec_lib.php): эталон смет, факт по строкам ЛРВ, ответ на запрос сметы ──
$onecEvent = mb_strtolower(trim((string) ($data['Событие'] ?? $data['event'] ?? '')));
if ($onecEvent === 'эталон') {
    if (!is_array($data['Сметы'] ?? null)) {
        rv1c_fail('Эталон: нужен список «Сметы».');
    }
    rv_json(['ok' => true] + rv_catalog_save($data));
}
if ($onecEvent === 'фактлрв') {
    try {
        rv_json(['ok' => true] + rv_fact_save($data));
    } catch (InvalidArgumentException $e) {
        rv1c_fail('Факт ЛРВ: ' . $e->getMessage());
    }
}
if ($onecEvent === 'запросвыполнен') {
    $done = rv_request_done((string) ($data['СметаGUID'] ?? ''), !empty($data['Успех']),
        trim((string) ($data['Сообщение'] ?? '')), (string) ($data['token'] ?? ''));
    rv_json(['ok' => true, 'found' => $done]);
}
$unknownFields = rv1c_unknown_fields($data);
$data = rv1c_normalize_sopost($data);
if (rv1c_field($data, 'СметныеПозиции') !== null && is_array(rv1c_field($data, 'Строки', 'rows') ?? [])) {
    // Пакет раздела 2 со сметными позициями (модуль СайтРВ_Обмен): работы сметы и разнесённое — из них же.
    [$data, $rows] = rv1c_expand_positions($data, (array) (rv1c_field($data, 'Строки', 'rows') ?? []),
        trim((string) (rv1c_field($data, 'СистемаСметы', 'Аналитика1') ?? '')), trim((string) (rv1c_field($data, 'Аналитика4') ?? '')));
    $data['Строки'] = $rows;
    unset($rows);
}

/** Поле по имени без учёта регистра, пробелов и подчёркиваний. */
/**
 * Тело, сохранённое 1С через ЗначениеВСтрокуВнутр: {"S","<JSON с удвоенными кавычками>"} — внутренняя
 * сериализация строки. Снимаем обёртку; обычный JSON возвращается как есть.
 */
function rv1c_unwrap(string $body): string
{
    $trimmed = trim($body);
    if (strncmp($trimmed, '{"S","', 6) === 0 && substr($trimmed, -2) === '"}') {
        return str_replace('""', '"', substr($trimmed, 6, -2));
    }
    return $body;
}

/**
 * «СметныеПозиции» — сметные позиции сметы как в 1С: в каждой зашита работа (номенклатура-работа с кодом
 * иерархии ИСР), объём и материалы, уже разнесённые под неё (регистр «Соответствие сметных позиций»).
 * Из них сайт берёт и работы сметы («РаботыСметы»), и разнесённое: материалы позиций становятся строками
 * с «РаботыВ1С» (материал под несколькими позициями — крепёж — одна строка со всеми работами и количествами).
 * Принимается в любом пакете — из обработки и в формате раздела 2 инструкции (модуль СайтРВ_Обмен);
 * у строки материала без «Система»/«Аналитика» — $system и $group4 из шапки. Возвращает [$data, $rows].
 */
function rv1c_expand_positions(array $data, array $rows, string $system, string $group4): array
{
    $positions = rv1c_field($data, 'СметныеПозиции');
    if (!is_array($positions) || !$positions || rv1c_field($data, 'РаботыСметы') !== null) {
        return [$data, $rows];
    }
    $str = static fn($v): string => is_scalar($v) ? trim((string) $v) : '';
    $num = static fn($v): float => (float) str_replace([',', ' '], ['.', ''], (string) ($v ?? 0));
    // Обработка «Соответствие РВ и ЛРВ» шлёт разнесённое не под позициями, а отдельным плоским деревом
    // «МассивРабот» (строки формы: позиция → материал-родитель → материал; у строки материала «Номенклатура»
    // заполнена, «КолвоМатериала» — сколько разнесено, «СметаКодИерархия» — код ИСР работы позиции).
    // Собираем материалы по GUID позиции; код позиции без своего — из её материалов.
    $byPosition = [];
    $codeByPosition = [];
    foreach ((array) (rv1c_field($data, 'МассивРабот', 'ДеревоСоответствия') ?? []) as $line) {
        if (!is_array($line) || $str(rv1c_field($line, 'Номенклатура')) === '') {
            continue;
        }
        $positionId = $str(rv1c_field($line, 'СметнаяПозицияGUID'));
        $byPosition[$positionId][] = $line;
        $lineCode = $str(rv1c_field($line, 'СметаКодИерархия', 'КодИерархии'));
        if ($lineCode !== '' && empty($codeByPosition[$positionId])) {
            $codeByPosition[$positionId] = $lineCode;
        }
    }
    unset($data['МассивРабот'], $data['ДеревоСоответствия']);
    $works = [];
    $bound = [];            // GUID номенклатуры → строка с разнесённым
    foreach ($positions as $position) {
        if (!is_array($position)) {
            continue;
        }
        $positionId = $str(rv1c_field($position, 'СметнаяПозицияGUID'));
        $code = $str(rv1c_field($position, 'КодИерархии', 'КодИСР', 'СИТИ_КодИерархия', 'СметаКодИерархия', 'КодРаботы'));
        if ($code === '' && $positionId !== '') {
            $code = (string) ($codeByPosition[$positionId] ?? '');
        }
        $workName = $str(rv1c_field($position, 'Работа', 'сити_ВнутреннееНаименованиеРаботы', 'сити_СметноеНаименованиеРаботы',
                                    'НоменклатураРаботы', 'Наименование', 'СметнаяПозиция'));
        $works[] = ['Код' => $code, 'Наименование' => $workName,
                    'СметнаяПозиция' => $str(rv1c_field($position, 'СметнаяПозиция', 'Наименование')),
                    'КодПозиции' => $str(rv1c_field($position, 'Код', 'КодПозиции')),
                    'ЕдиницаИзмерения' => $str(rv1c_field($position, 'ЕдиницаИзмерения')),
                    'ЕдиницаИзмеренияGUID' => $str(rv1c_field($position, 'ЕдиницаИзмеренияGUID', 'ЕдиницаИзмерения_GUID')),
                    'Количество' => rv1c_field($position, 'Количество', 'КоличествоПоСмете'),
                    'СметнаяПозицияGUID' => $positionId,
                    'РаботаGUID' => $str(rv1c_field($position, 'РаботаGUID', 'сити_ВнутреннееНаименованиеРаботыGUID',
                                                     'сити_СметноеНаименованиеРаботыGUID', 'НоменклатураРаботыGUID')),
                    'УИДУзлаДерева' => $str(rv1c_field($position, 'УИДУзлаДерева')),
                    'Примечание' => mb_substr($str(rv1c_field($position, 'Примечание', 'ПримечаниеРаботы', 'Комментарий')), 0, 500)];
        $materials = rv1c_field($position, 'Материалы');
        if (!is_array($materials) || !$materials) {
            $materials = $byPosition[$positionId] ?? [];
        }
        foreach ($materials as $material) {
            if (!is_array($material)) {
                continue;
            }
            $guid = $str(rv1c_field($material, 'НоменклатураGUID', 'Номенклатура_GUID'));
            $key = $guid !== '' ? $guid : mb_strtolower($str(rv1c_field($material, 'Номенклатура')));
            if ($key === '') {
                continue;
            }
            $qty = $num(rv1c_field($material, 'КолвоМатериала', 'Колво', 'Количество'));     // в «МассивРабот» «Колво» всегда 0
            if ($qty <= 0) {
                continue;       // материал в дереве есть, но на позицию ничего не разнесено
            }
            if (!isset($bound[$key])) {
                $row = $material;
                unset($row['Колво'], $row['КолвоВСмету'], $row['КолвоМатериала'], $row['КолвоМатериалаВСмету'], $row['КолвоРабот'],
                      $row['КолвоРаботВСмету'], $row['КоличествоСметныхПозиций'], $row['НоменклатураРодитель'], $row['НоменклатураРодительGUID'],
                      $row['СметнаяПозиция'], $row['СметнаяПозицияGUID'], $row['сити_СметноеНаименованиеРаботы'],
                      $row['сити_ВнутреннееНаименованиеРаботы'], $row['Сумма'], $row['СуммаВСмету']);
                $row['Количество'] = 0;
                $row['КоличествоВСмету'] = 0;
                $row['Сумма'] = 0;           // суммы, как и количества, — по всем позициям материала
                $row['СуммаВСмету'] = 0;
                $row['РазнесеноВ1С'] = 0;
                $row['РаботыВ1С'] = [];
                $row['ИдентификаторСтроки'] = ($guid !== '' ? $guid : $key) . '|разнесено';
                if ($system !== '' && rv1c_field($row, 'Система') === null) {
                    $row['Система'] = $system;
                }
                if ($group4 !== '' && rv1c_field($row, 'Аналитика') === null) {
                    $row['Аналитика'] = $group4;
                }
                $bound[$key] = $row;
            }
            $bound[$key]['Количество'] += $qty;
            $bound[$key]['КоличествоВСмету'] += $num(rv1c_field($material, 'КолвоМатериалаВСмету', 'КолвоВСмету', 'КоличествоВСмету'));
            $sum = $num(rv1c_field($material, 'Сумма', 'СуммаМатериала'));
            $sumSmeta = $num(rv1c_field($material, 'СуммаВСмету', 'СуммаМатериалаВСмету'));
            $bound[$key]['Сумма'] = round($bound[$key]['Сумма'] + $sum, 2);
            $bound[$key]['СуммаВСмету'] = round($bound[$key]['СуммаВСмету'] + $sumSmeta, 2);
            $bound[$key]['РазнесеноВ1С'] += $qty;
            $bound[$key]['РаботыВ1С'][] = ['Код' => $code, 'Наименование' => $workName, 'Количество' => $qty,
                                           'Коэффициент' => rv1c_field($material, 'ВесовойКоэф', 'Коэффициент'),
                                           'Сумма' => $sum, 'СуммаВСмету' => $sumSmeta,
                                           'СметнаяПозицияGUID' => $positionId];
        }
    }
    $data['РаботыСметы'] = $works;
    foreach ($bound as $row) {
        $rows[] = $row;
    }
    return [$data, $rows];
}

/**
 * Поля верхнего уровня пакета, которых сайт не знает (например, блок с другим именем вместо «СметныеПозиции»):
 * такие поля сайт молча пропускает, поэтому их список уходит в ответ («НеизвестныеПоля») и показывается на странице
 * РВ — чтобы с обеих сторон было видно, что именно не прочиталось. Сравнение без учёта регистра, пробелов и «_».
 */
function rv1c_unknown_fields(array $data): array
{
    static $known = ['ИдентификаторЛРВ', 'Идентификатор', 'lrv_id', 'id', 'Режим', 'mode', 'Объект', 'Проект', 'object',
        'Версия', 'ДатаИзменения', 'version', 'ТипОбъекта', 'object_type', 'Раздел', 'section', 'Система', 'system',
        'Ответственный', 'user', 'Строки', 'rows', 'Файл', 'file', 'ИмяФайла', 'file_name', 'СметныеПозиции', 'РаботыСметы',
        'МассивРабот', 'ДеревоСоответствия', 'РаботыРВ', 'ДокументРВ', 'ДокументРВGUID', 'Сопоставление1С', 'Событие', 'event', 'token', 'Токен', 'НомерЗадачи',
        'Успех', 'ok', 'Сообщение', 'message', 'Документ', 'document',
        'Сопоставление', 'СопоставлениеGUID', 'Номер', 'Дата', 'Смета', 'СметаGUID', 'НоменклатурнаяГруппа',
        'НоменклатурнаяГруппаGUID', 'ОбъектСтроительства', 'ОбъектСтроительстваGUID', 'Аналитика1', 'Аналитика2',
        'Аналитика3', 'Аналитика4', 'Аналитика_1', 'Аналитика_2', 'Аналитика_3', 'Аналитика_4', 'РесурснаяВедомость', 'РесурснаяВедомостьGUID',
        'Источник', 'СистемаСметы', 'СистемаСметыGUID', 'ПапкаНГ', 'Папка', 'ПапкаНГGUID', 'ПапкаGUID', 'НомерЗН',
        'НомерЗаказНаряда', 'Аналитика1GUID', 'Отправил', 'ВидЗаказНаряда', 'ВидЗН', 'КодРабот',
        // шапка обработки «Отправить на сопоставление»: служебные, сайту не нужны
        'ОтветственныйGUID', 'ОтправилGUID', 'ДатаОтправки'];
    static $wanted = null;
    if ($wanted === null) {
        $wanted = array_map(static fn(string $n): string => mb_strtolower(str_replace([' ', '_'], '', $n)), $known);
    }
    $unknown = [];
    foreach ($data as $key => $value) {
        if (!in_array(mb_strtolower(str_replace([' ', '_'], '', (string) $key)), $wanted, true)) {
            $unknown[] = mb_substr((string) $key, 0, 80);
        }
    }
    return array_slice($unknown, 0, 30);
}

/**
 * Пакет из обработки «Соответствие РВ и ЛРВ» (документ «Сопоставление РВ и ЛРВ», таблица непривязанных
 * МПЗ) — поля не как в разделе 2 инструкции: шапка «Сопоставление», «СопоставлениеGUID», «Смета», «СметаGUID»,
 * «НоменклатурнаяГруппа(GUID)», «Аналитика1..4», «РесурснаяВедомость(GUID)»; строки «Номенклатура»,
 * «НоменклатураGUID», «Код», «Артикул», «ЕдиницаИзмерения(GUID)», «ЕстьВЛРВ», «Колво», «КолвоВСмету»,
 * «КолВоСпец», «СпецОсновнаяСметнаяПозицияНоменклатура», «ОсновнаяСпецификация», «ВесовойКоэф», «Сумма»,
 * «СуммаВСмету». Приводится к обычному пакету: ИдентификаторЛРВ = «Смета-<GUID>», система всех строк —
 * Аналитика 1 сметы, «Аналитика» — Аналитика 4 (основные работы / З/Н), идентификатор строки — GUID
 * номенклатуры (разнос в 1С идёт по материалу), «Артикул» → «АртикулНоменклатуры» (иначе сочтётся кодом).
 * Остальные поля строк остаются как есть и возвращаются в РВ для 1С; спецификацию номенклатуры 1С
 * («СпецОсновнаяСметнаяПозицияНоменклатура») агент не применяет — он учится на решениях сметчиков на сайте.
 * Сопоставление и РВ — в шапке «Сопоставление1С» для ответа 1С (web_rv_run.export_1c).
 * «СметныеПозиции» (сметная позиция с зашитой работой и разнесёнными под неё материалами) — см. ниже.
 */
function rv1c_normalize_sopost(array $data): array
{
    $rows = rv1c_field($data, 'Строки', 'rows');
    $first = is_array($rows) && $rows && is_array($rows[0]) ? $rows[0] : [];
    $isSopost = rv1c_field($data, 'СопоставлениеGUID', 'Сопоставление') !== null
        || (rv1c_field($data, 'СметаGUID') !== null && rv1c_field($first, 'Колво') !== null
            && rv1c_field($first, 'Количество') === null && rv1c_field($data, 'ИдентификаторЛРВ') === null);
    if (!$isSopost) {
        return $data;
    }
    if (!is_array($rows)) {
        $rows = [];          // только сметные позиции с материалами — непривязанных нет
    }
    $str = static fn($v): string => is_scalar($v) ? trim((string) $v) : '';
    $smetaId = $str(rv1c_field($data, 'СметаGUID'));
    $system = $str(rv1c_field($data, 'Аналитика1', 'Аналитика_1', 'СистемаСметы'));
    $group4 = $str(rv1c_field($data, 'Аналитика4', 'Аналитика_4'));
    $ng = $str(rv1c_field($data, 'НоменклатурнаяГруппа'));
    if (rv1c_field($data, 'ИдентификаторЛРВ') === null) {
        $data['ИдентификаторЛРВ'] = $smetaId !== '' ? 'Смета-' . $smetaId
            : 'Сопоставление-' . $str(rv1c_field($data, 'СопоставлениеGUID'));
    }
    if (rv1c_field($data, 'Объект') === null) {
        $data['Объект'] = trim($ng . ($system !== '' ? ' / ' . $system : ''), ' /');
    }
    if (rv1c_field($data, 'СистемаСметы') === null && $system !== '') {
        $data['СистемаСметы'] = $system;
    }
    $data['Сопоставление1С'] = [
        'Сопоставление' => $str(rv1c_field($data, 'Сопоставление')),
        'СопоставлениеGUID' => $str(rv1c_field($data, 'СопоставлениеGUID')),
        'Номер' => $str(rv1c_field($data, 'Номер')), 'Дата' => $str(rv1c_field($data, 'Дата')),
        'РесурснаяВедомость' => $str(rv1c_field($data, 'РесурснаяВедомость')),
        'РесурснаяВедомостьGUID' => $str(rv1c_field($data, 'РесурснаяВедомостьGUID')),
        'Смета' => $str(rv1c_field($data, 'Смета')), 'СметаGUID' => $smetaId,
        'НоменклатурнаяГруппа' => $str(rv1c_field($data, 'НоменклатурнаяГруппа')),
        'НоменклатурнаяГруппаGUID' => $str(rv1c_field($data, 'НоменклатурнаяГруппаGUID')),
        'Аналитика1' => $system, 'Аналитика2' => $str(rv1c_field($data, 'Аналитика2')),
        'Аналитика3' => $str(rv1c_field($data, 'Аналитика3')), 'Аналитика4' => $group4,
    ];
    [$data, $rows] = rv1c_expand_positions($data, $rows, $system, $group4);
    foreach ($rows as $i => $row) {
        if (!is_array($row)) {
            continue;
        }
        if (rv1c_field($row, 'Количество', 'КоличествоПлан') === null && rv1c_field($row, 'Колво') !== null) {
            $row['Количество'] = rv1c_field($row, 'Колво');
        }
        if (rv1c_field($row, 'КоличествоВСмету') === null && rv1c_field($row, 'КолвоВСмету') !== null) {
            $row['КоличествоВСмету'] = rv1c_field($row, 'КолвоВСмету');
        }
        if (rv1c_field($row, 'Система') === null && $system !== '') {
            $row['Система'] = $system;
        }
        if (rv1c_field($row, 'Аналитика') === null && $group4 !== '') {
            $row['Аналитика'] = $group4;
        }
        if (rv1c_field($row, 'ИдентификаторСтроки') === null) {
            $guid = $str(rv1c_field($row, 'НоменклатураGUID', 'Номенклатура_GUID'));
            if ($guid !== '') {
                $row['ИдентификаторСтроки'] = $guid;
            }
        }
        if (array_key_exists('Артикул', $row)) {
            $row['АртикулНоменклатуры'] = $row['Артикул'];
            unset($row['Артикул']);
        }
        $rows[$i] = $row;
    }
    $written = false;
    foreach (array_keys($data) as $key) {
        if (mb_strtolower(str_replace([' ', '_'], '', (string) $key)) === 'строки') {
            $data[$key] = $rows;
            $written = true;
        }
    }
    if (!$written) {
        $data['Строки'] = $rows;
    }
    return $data;
}

function rv1c_field(array $data, string ...$names)
{
    // Имена — в порядке предпочтения: «КодИерархии» раньше «Код», если в данных есть оба.
    $keys = [];
    foreach ($data as $key => $value) {
        $keys[mb_strtolower(str_replace([' ', '_'], '', (string) $key))] = $key;
    }
    foreach ($names as $name) {
        $want = mb_strtolower(str_replace([' ', '_'], '', $name));
        if (isset($keys[$want])) {
            return $data[$keys[$want]];
        }
    }
    return null;
}

// ── Событие от 1С: РВ загружена в документ «Ресурсная ведомость» (или загрузка не удалась) ──
// {"Событие": "РВЗагружена", "token": "…", "Успех": true, "Сообщение": "…", "Документ": "…"} — для реестра
// ЛРВ из 1С (rv_registry.php): последний шаг пути «пришла → строится → согласована → загружена в 1С».
$event = trim((string) rv1c_field($data, 'Событие', 'event'));
if ($event !== '') {
    if (mb_strtolower($event) !== 'рвзагружена') {
        rv1c_fail('Неизвестное событие «' . mb_substr($event, 0, 40) . '». Известны: РВЗагружена, Эталон, ФактЛРВ, ЗапросВыполнен.');
    }
    $token = (string) rv1c_field($data, 'token', 'Токен', 'НомерЗадачи');
    if (!rv_token_valid($token)) {
        rv1c_fail('Нужен token — номер задачи на сайте.');
    }
    $jobPath = rv_paths($token)['job'];
    $job = rv_read_json($jobPath);
    if ($job === null) {
        rv1c_fail('Задача не найдена или удалена.', 404);
    }
    $job['onec'] = [
        'ok' => (bool) rv1c_field($data, 'Успех', 'ok'),
        'message' => mb_substr(trim((string) rv1c_field($data, 'Сообщение', 'message')), 0, 2000),
        'document' => mb_substr(trim((string) rv1c_field($data, 'Документ', 'document')), 0, 200),
        'number' => mb_substr(trim((string) rv1c_field($data, 'Номер', 'number')), 0, 20),
        'date' => mb_substr(trim((string) rv1c_field($data, 'Дата', 'date')), 0, 25),
        'posted' => rv1c_field($data, 'Проведен', 'posted') === null ? null : (bool) rv1c_field($data, 'Проведен', 'posted'),
        'at' => time(),
    ];
    file_put_contents($jobPath, json_encode($job, JSON_UNESCAPED_UNICODE));
    rv_json(['ok' => true, 'token' => $token]);
}

$lrvId = trim((string) rv1c_field($data, 'ИдентификаторЛРВ', 'Идентификатор', 'lrv_id', 'id'));
if ($lrvId === '' || mb_strlen($lrvId) > 120) {
    rv1c_fail('Нужно поле «ИдентификаторЛРВ» — уникальный идентификатор ЛРВ в 1С (до 120 символов).');
}
// «Режим»: «Сверка» — не рабочая ЛРВ, а РВ, уже сделанная в 1С, на сверку с агентом (rv_audit.php): у строк
// «РаботыВ1С» — как их разнесли в 1С, в шапке «РаботыРВ» — сметные позиции документа с объёмами. Агент разносит
// строки заново и сравнивает; в дерево объектов и в загрузку в 1С такие задачи не попадают.
$audit = in_array(mb_strtolower(trim((string) rv1c_field($data, 'Режим', 'mode'))), ['сверка', 'audit'], true);
if ($audit && !preg_match('/^сверка-/iu', $lrvId)) {
    $lrvId = mb_substr('Сверка-' . $lrvId, 0, 120);
}
$object = mb_substr(trim((string) rv1c_field($data, 'Объект', 'Проект', 'object')), 0, 150);
$version = mb_substr(trim((string) rv1c_field($data, 'Версия', 'ДатаИзменения', 'version')), 0, 60);
$objectType = trim((string) rv1c_field($data, 'ТипОбъекта', 'object_type'));
if (!array_key_exists($objectType, RV_OBJECT_TYPES)) {
    $objectType = 'жилой';
}
$section = trim((string) rv1c_field($data, 'Раздел', 'section'));
if (!in_array($section, RV_SECTIONS, true)) {
    $section = 'авто';
}
$system = trim((string) rv1c_field($data, 'Система', 'system'));
if ($system !== '' && rv_system_split($system) === null) {
    rv1c_fail('Поле «Система» — в виде «ВК|В1» (раздел|система по словарю агента) или пусто, чтобы взять системы из строк.');
}
$responsible = trim((string) rv1c_field($data, 'Ответственный', 'user'));
$owner = ($responsible !== '' && kb_can_see_plans($responsible)) ? $responsible : '';

$rows = rv1c_field($data, 'Строки', 'rows');
$file = rv1c_field($data, 'Файл', 'file');
$fileName = trim((string) rv1c_field($data, 'ИмяФайла', 'file_name'));
if (is_array($rows)) {
    if (!$rows || !array_is_list($rows)) {
        rv1c_fail('«Строки» — непустой список строк ЛРВ.');
    }
    foreach ($rows as $i => $row) {
        if (!is_array($row) || trim((string) rv1c_field($row, 'Номенклатура', 'Наименование')) === '') {
            rv1c_fail('Строка ' . ($i + 1) . ': нужна «Номенклатура» (наименование материала).');
        }
        $qty = rv1c_field($row, 'Количество', 'КоличествоПлан');
        if ($qty === null || !is_numeric(str_replace([',', ' '], ['.', ''], (string) $qty))) {
            rv1c_fail('Строка ' . ($i + 1) . ' («' . mb_substr((string) rv1c_field($row, 'Номенклатура', 'Наименование'), 0, 60)
                . '»): «Количество» должно быть числом.');
        }
    }
    $payload = json_encode(['Строки' => $rows], JSON_UNESCAPED_UNICODE);
    $ext = 'json';
    $hash = hash('sha256', $payload);
    $count = count($rows);
} elseif (is_string($file) && $file !== '') {
    $bytes = base64_decode($file, true);
    if ($bytes === false || $bytes === '') {
        rv1c_fail('«Файл» — содержимое отчёта в base64 (Base64Строка(ДвоичныеДанные) в 1С).');
    }
    $ext = strtolower(pathinfo($fileName !== '' ? $fileName : 'lrv.xlsx', PATHINFO_EXTENSION));
    if (!in_array($ext, ['xlsx', 'xls', 'csv'], true)) {
        rv1c_fail('«ИмяФайла» — с расширением .xlsx, .xls или .csv.');
    }
    if ($ext === 'xlsx' && strncmp($bytes, "PK", 2) !== 0) {
        rv1c_fail('«Файл» не похож на книгу Excel (.xlsx).');
    }
    $payload = $bytes;
    $hash = hash('sha256', $bytes);
    $count = null;
} else {
    rv1c_fail('Нужны «Строки» (список строк ЛРВ) или «Файл» (отчёт «Остатки по ЛРВ» в base64).');
}

foreach ([RV_UPLOAD_DIR, RV_OUTPUT_DIR] as $dir) {
    if (!is_dir($dir) && !mkdir($dir, 0775, true) && !is_dir($dir)) {
        rv1c_fail('Рабочая папка агента РВ недоступна на сервере.', 500);
    }
}

// Объект (папка номенклатурных групп), номенклатурная группа, система (Аналитика 1), смета и номер ЗН —
// для дерева «Объекты и ЛРВ из 1С» (rv_registry.php). С 1С приходят в шапке пакета; НГ и систему, если их нет, —
// из первой строки и самой частой «Системы» строк. Папку и номер ЗН — только из шапки: поле, которого 1С
// не прислала (старая версия модуля), в meta не пишется, и известное по другим ЛРВ не затирается.
$first = is_array($rows) && $rows ? (array) $rows[0] : [];
$systemCounts = [];
foreach (is_array($rows) ? $rows : [] as $row) {
    $name = trim((string) rv1c_field((array) $row, 'Система'));
    if ($name !== '') {
        $systemCounts[$name] = ($systemCounts[$name] ?? 0) + 1;
    }
}
arsort($systemCounts);
$meta = [
    'obj' => mb_substr(trim((string) (rv1c_field($data, 'НоменклатурнаяГруппа', 'ОбъектСтроительства')
        ?? rv1c_field($first, 'НоменклатурнаяГруппа') ?? '')), 0, 150),
    'obj_id' => mb_substr(trim((string) (rv1c_field($data, 'НоменклатурнаяГруппаGUID', 'ОбъектСтроительстваGUID')
        ?? rv1c_field($first, 'НоменклатурнаяГруппа_GUID') ?? '')), 0, 60),
    'system' => mb_substr(trim((string) (rv1c_field($data, 'СистемаСметы') ?? (string) array_key_first($systemCounts))), 0, 150),
    'system_id' => mb_substr(trim((string) (rv1c_field($data, 'СистемаСметыGUID') ?? rv1c_field($first, 'Система_GUID') ?? '')), 0, 60),
    'smeta' => mb_substr(trim((string) (rv1c_field($data, 'Смета') ?? '')), 0, 150),
    'smeta_id' => mb_substr(trim((string) (rv1c_field($data, 'СметаGUID') ?? '')), 0, 60),
];
// Кто в 1С отправил на сайт («Отправил»: пусто — регламентное задание).
foreach (['folder' => ['ПапкаНГ', 'Папка'], 'folder_id' => ['ПапкаНГGUID', 'ПапкаGUID'], 'zn' => ['НомерЗН', 'НомерЗаказНаряда'],
          'sender' => ['Отправил', 'Ответственный']] as $key => $names) {
    $value = rv1c_field($data, ...$names);
    if ($value !== null && !is_array($value)) {
        $meta[$key] = mb_substr(trim((string) $value), 0, $key === 'folder_id' ? 60 : 150);
    }
}
// Аналитика 2 и 3 сметы (если 1С прислала): уточняют систему, когда НГ говорит лишь «сантехнические работы».
$analytics = array_filter([trim((string) (rv1c_field($data, 'Аналитика2', 'Аналитика_2') ?? '')), trim((string) (rv1c_field($data, 'Аналитика3', 'Аналитика_3') ?? ''))]);
if ($analytics) {
    $meta['analytics'] = mb_substr(implode(' / ', $analytics), 0, 300);
}
// Теплоснабжение (калориферы приточных установок, воздушно-тепловые завесы): в КЦ у него отдельный раздел 6.2.3.2.7
// (ОВ1, система «ПУ»). Аналитика 1 «Теплоснабжение…» распознаётся по строкам сама (rv_input.SYSTEM_1C); если же она
// общая или пустая, а теплоснабжение названо в смете или аналитиках 2–3 — к нему относятся все строки ЛРВ.
if ($system === '' && $section === 'авто' && rv_heat_supply((string) $meta['system'], (string) $meta['smeta'], (string) ($meta['analytics'] ?? ''))) {
    $system = 'ОВ1|ПУ';
}
// Вид работ сметы (осн / НЗ) — по «Аналитике 4» («Основные работы» / «Работы по З/Н №…»), иначе по номеру ЗН
// и имени сметы: по нему справочник объектов выбирает сметчика (rv_table_responsible).
$analytic4 = rv1c_field($data, 'Аналитика4', 'Аналитика_4');
$meta['kind'] = rv_kind_of($meta['smeta'], (string) ($meta['zn'] ?? ''), is_scalar($analytic4) ? trim((string) $analytic4) : '');
// ЛРВ по БНР и накладным расходам агенту не нужны: это не материалы работ (1С их и не отправляет).
foreach ([$meta['obj'], $meta['system'], $meta['smeta'], $object] as $name) {
    if (preg_match('/(^|[^а-яёa-z])бнр([^а-яёa-z]|$)|накладн[а-яё]*\s+расход/iu', (string) $name)) {
        rv1c_fail('ЛРВ по БНР и накладным расходам на сайт не принимаются («' . mb_substr((string) $name, 0, 80) . '»).', 422);
    }
}
$auditWorks = [];
if ($audit) {
    foreach ((array) (rv1c_field($data, 'РаботыРВ') ?? []) as $work) {
        if (is_array($work)) {
            $auditWorks[] = array_map(static fn($v) => is_scalar($v) ? $v : null, $work);
        }
    }
    $hash = hash('sha256', $hash . json_encode($auditWorks, JSON_UNESCAPED_UNICODE));   // изменились объёмы в 1С — сверка заново
}
// «РаботыСметы» — сметные позиции сметы в 1С с кодами ИСР и объёмами: агент предпочитает их, в загрузке
// 1С отличает работы сметы от новых. Входят в хеш: изменился состав работ (как и разнесённое в строках,
// «РаботыВ1С») — строится новая версия РВ.
$smetaWorks = [];
foreach ((array) (rv1c_field($data, 'РаботыСметы') ?? []) as $work) {
    if (is_array($work)) {
        $smetaWorks[] = array_map(static fn($v) => is_scalar($v) ? $v : null, $work);
    }
}
if ($smetaWorks) {
    // GUID единицы работы (с 13.11.2026) в хеш не входит: тот же пакет, что и раньше, не строит РВ заново
    $hashWorks = array_map(static function (array $work): array {
        unset($work['ЕдиницаИзмеренияGUID']);
        return $work;
    }, $smetaWorks);
    $hash = hash('sha256', $hash . json_encode($hashWorks, JSON_UNESCAPED_UNICODE));
}
// Код работ РВ: 6 — основные работы и заказ-наряды ДР, 12 — заказ-наряды РВР (работы, не предусмотренные основным
// проектом). Известен заранее, если 1С прислала вид заказ-наряда («ВидЗаказНаряда»: «ДР» / «РВР» или «КодРабот»: 6 / 12)
// либо работы сметы (у сверки — работы РВ) в 1С уже есть и все одного кода. Иначе у заказ-наряда сайт спросит сметчика
// перед сборкой (web_rv_run.run_mark → страница подтверждения); прежний выбор по этой же ЛРВ переносится ниже.
$codeRoot = rv_code_root_of(rv1c_field($data, 'ВидЗаказНаряда', 'ВидЗН', 'КодРабот'));
$codeRootBy = $codeRoot !== '' ? '1С' : '';
if ($codeRoot !== '') {
    $hash = hash('sha256', $hash . '|код работ ' . $codeRoot);      // сменился вид заказ-наряда в 1С — РВ строится заново
} else {
    $codeRoot = rv_code_root_of_works($audit ? $auditWorks : $smetaWorks);      // работы уже входят в хеш
    $codeRootBy = $codeRoot !== '' ? ($audit ? 'работы РВ в 1С' : 'работы сметы в 1С') : '';
}

// Та же ЛРВ с тем же содержимым — не строим заново.
$token = bin2hex(random_bytes(8));
$previous = rv1c_index(static function (array $index) use ($lrvId, $hash, $token, $version): array {
    $versions = array_values(array_filter((array) ($index[$lrvId] ?? []), static function ($v): bool {
        return is_array($v) && is_file(rv_paths((string) ($v['token'] ?? ''))['job']);
    }));
    $last = $versions ? end($versions) : null;
    if ($last && (string) ($last['hash'] ?? '') === $hash) {
        $index[$lrvId] = $versions;
        return [$index, ['duplicate' => (string) $last['token']]];
    }
    $versions[] = ['token' => $token, 'hash' => $hash, 'version' => $version, 'received' => time()];
    $index[$lrvId] = array_slice($versions, -20);
    return [$index, ['previous' => $last ? (string) $last['token'] : '']];
});
if (!empty($previous['duplicate'])) {
    // Та же ЛРВ с тем же содержимым: новой РВ нет, отвечаем состоянием прежней. Повтор отмечается у прежней
    // задачи (job['resent']) — его видно в «РВ по ЛРВ», в дереве объектов и на странице РВ.
    $dupPath = rv_paths($previous['duplicate'])['job'];
    $dupJob = rv_read_json($dupPath);
    if ($dupJob !== null) {
        $dupJob['resent'] = ['count' => (int) ($dupJob['resent']['count'] ?? 0) + 1, 'at' => time(), 'version' => $version];
        file_put_contents($dupPath, json_encode($dupJob, JSON_UNESCAPED_UNICODE));
    }
    // Строки те же, но шапка могла измениться (папка НГ, номер ЗН, переименование) — справочник объектов обновляем.
    if (!$audit) {
        rv_objects_register([['lrv_id' => $lrvId, 'token' => $previous['duplicate'], 'created' => time(), 'object' => $object, 'meta' => $meta]]);
    }
    $state = rv1c_state($previous['duplicate']);
    $state['duplicate'] = true;
    rv_json($state, 200);
}

$inputPath = RV_UPLOAD_DIR . '/' . $token . '.' . $ext;
if (file_put_contents($inputPath, $payload) === false) {
    rv1c_fail('Не удалось сохранить ЛРВ на сервере.', 500);
}
// Пакет, как его прислала 1С (после снятия BOM и обёртки ЗначениеВСтрокуВнутр), — рядом с результатом, сжатый:
// скачать со страницы РВ (rv_download.php?kind=in), чтобы разбирать, что именно пришло. Сам файл ЛРВ после
// чтения удаляется (web_rv_run.py), а этот живёт вместе с задачей.
$paths = rv_paths($token);
@file_put_contents($paths['in'], gzencode($body, 6));
$idLabel = preg_match('/^(лрв|сверка)/iu', $lrvId) ? $lrvId : 'ЛРВ ' . $lrvId;
$display = $object !== '' ? $object . ' (' . $idLabel . ')' : $idLabel;
$now = time();
$job = [
    'token' => $token,
    'user' => $owner,
    'origin' => '1c',
    'lrv_id' => $lrvId,
    'version' => $version,
    'object' => $object,
    'meta' => $meta,
    'section' => $section,
    'object_type' => $objectType,
    'default_system' => $system,
    'source_name' => sanitize_display_base($display) . '.' . $ext,
    'input' => $inputPath,
    'created' => $now,
];
if ($unknownFields) {
    $job['unknown_fields'] = $unknownFields;
}
if ($codeRoot === '' && !empty($previous['previous'])) {
    // Прежняя версия этой ЛРВ уже собиралась: заказ-наряд тот же — тот же и код работ.
    $before = rv_read_json(rv_paths($previous['previous'])['job']);
    $codeRoot = rv_code_root_of($before['code_root'] ?? '');
    $codeRootBy = $codeRoot !== '' ? 'как у прежней версии ЛРВ' : '';
}
if ($codeRoot !== '') {
    $job['code_root'] = $codeRoot;
    $job['code_root_by'] = $codeRootBy;
}
if (!$smetaWorks) {
    $job['no_positions'] = true;      // работ сметы нет: подсказка на странице РВ, что их ждут в «СметныеПозиции»
}
if ($smetaWorks) {
    file_put_contents($paths['smeta'], json_encode(['works' => $smetaWorks], JSON_UNESCAPED_UNICODE));
}
// Шапка 1С для ответа: документ «Сопоставление РВ и ЛРВ», РВ, GUID сметы и НГ — вернутся в РВ для 1С как есть
// (web_rv_run.export_1c), чтобы загрузка в 1С знала, в какой документ класть подбор.
$head = rv1c_field($data, 'Сопоставление1С');
if (is_array($head) && array_filter($head, static fn($v): bool => $v !== '' && $v !== null)) {
    $job['sopost'] = ['doc' => (string) ($head['Сопоставление'] ?? ''), 'doc_id' => (string) ($head['СопоставлениеGUID'] ?? '')];
    file_put_contents($paths['head'], json_encode($head, JSON_UNESCAPED_UNICODE));
}
if ($audit) {
    $job['mode'] = 'audit';
    $job['audit_doc'] = mb_substr(trim((string) (rv1c_field($data, 'ДокументРВ') ?? '')), 0, 150);
    $job['audit_doc_id'] = mb_substr(trim((string) (rv1c_field($data, 'ДокументРВGUID') ?? '')), 0, 60);
    // Сметные позиции РВ из 1С с объёмами — для сверки объёмов работ (web_rv_run.py, rv_audit.py).
    file_put_contents($paths['audit'], json_encode(['doc' => $job['audit_doc'], 'doc_id' => $job['audit_doc_id'],
                                                    'works' => $auditWorks], JSON_UNESCAPED_UNICODE));
}
file_put_contents($paths['job'], json_encode($job, JSON_UNESCAPED_UNICODE));
if (!$audit) {
    rv_objects_register([$job]);     // новый объект, НГ или смета появляются в дереве с первой ЛРВ
}
file_put_contents($paths['status'], json_encode([
    'state' => 'queued',
    'stage' => 'в очереди агента РВ…',
    'started' => $now,
    'updated' => $now,
], JSON_UNESCAPED_UNICODE));
if (!empty($previous['previous'])) {
    $oldPath = rv_paths($previous['previous'])['job'];
    $old = rv_read_json($oldPath);
    if ($old !== null) {
        $old['superseded_by'] = $token;
        file_put_contents($oldPath, json_encode($old, JSON_UNESCAPED_UNICODE));
    }
}
rv_queue_kick();

$answer = rv1c_state($token);
$answer['duplicate'] = false;
$answer['rows'] = $count;
if ($unknownFields) {
    $answer['НеизвестныеПоля'] = $unknownFields;     // сайт их не читает — проверить имена полей в 1С
}
if (!empty($previous['previous'])) {
    $answer['replaces'] = $previous['previous'];
}
rv_json($answer, 202);
