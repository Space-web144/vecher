<?php
declare(strict_types=1);

// Хранилище учётных записей — файл AUTH_CREDENTIALS_FILE (см. config.php),
// не в репозитории, создаётся один раз вручную на сервере. Формат —
// список пользователей, а не один общий логин/пароль:
//   <?php
//   return [
//       ['login' => 'ivanov', 'password_hash' => '$2y$...', 'role' => 'mainadmin', 'department' => 'CO'],
//       ['login' => 'petrov', 'password_hash' => '$2y$...', 'role' => 'admin', 'department' => 'PTO'],
//       ['login' => 'sidorov', 'password_hash' => '$2y$...', 'role' => 'user', 'department' => 'BUH'],
//   ];
// 'department' — отдел сотрудника (код из KB_DEPARTMENT_NAMES), задаётся при
// регистрации на странице «Пользователи» и определяет, какие модули сайта
// открыты. У старых учёток без поля отдел берётся из логина (см.
// login_department) — пока администратор не задаст его явно.
// Три роли, по возрастанию прав:
//   'user'      — обычный доступ, без раздела «Пользователи»;
//   'admin'     — доступ к разделу «Пользователи», но только для управления
//                 учётками с ролью 'user' (создание/пароль/роль/удаление);
//                 учётки с ролью admin/mainadmin для него только на чтение
//                 (кроме сброса собственного пароля);
//   'mainadmin' — то же, что admin, плюс полное управление учётками admin и
//                 mainadmin (единственная роль, которая может выдавать роли
//                 admin/mainadmin). Первую учётку mainadmin нужно завести
//                 вручную в этом файле на сервере — так же, как заводили
//                 самую первую учётку admin.
// Любое другое/отсутствующее значение роли трактуется как 'user'.

// Отделы: код → название. Код хранится в учётке ('department') и в
// 'departments' модулей (structure.php).
const KB_DEPARTMENT_NAMES = [
    'RN' => 'Выполнение', 'CO' => 'ЦО', 'PTO' => 'ПТО', 'DIR' => 'ГПР', 'SDO' => 'СДО',
    'OK' => 'Отдел кадров', 'OMTS' => 'ОМТС', 'BUH' => 'Бухгалтерия', 'YUR' => 'Юристы',
    'DR' => 'Дирекция', 'NO' => 'Начальник отдела', 'BA' => 'BA',
    'KZ' => 'Казначейство', 'SK' => 'Секретариат',
];

const ROLE_MAINADMIN = 'mainadmin';
const ROLE_ADMIN = 'admin';
const ROLE_USER = 'user';
const VALID_ROLES = [ROLE_MAINADMIN, ROLE_ADMIN, ROLE_USER];
// Роли, которым открыт вход в admin_users.php ('user' туда не попадает).
const ADMIN_TIER_ROLES = [ROLE_MAINADMIN, ROLE_ADMIN];

function is_admin_tier_role(string $role): bool
{
    return in_array($role, ADMIN_TIER_ROLES, true);
}

function role_label(string $role): string
{
    if ($role === ROLE_MAINADMIN) {
        return 'MainAdmin';
    }
    return $role === ROLE_ADMIN ? 'admin' : 'user';
}

function role_badge_class(string $role): string
{
    if ($role === ROLE_MAINADMIN) {
        return 'mainadmin';
    }
    return $role === ROLE_ADMIN ? 'admin' : 'user';
}

function load_users(): array
{
    if (!is_file(AUTH_CREDENTIALS_FILE)) {
        return [];
    }
    $users = require AUTH_CREDENTIALS_FILE;
    if (!is_array($users)) {
        return [];
    }
    // Приводим к предсказуемому виду и сортируем по логину — чтобы порядок
    // строк на странице администрирования не прыгал между сохранениями.
    $out = [];
    foreach ($users as $u) {
        if (!is_array($u) || empty($u['login']) || empty($u['password_hash'])) {
            continue;
        }
        $entry = [
            'login' => (string) $u['login'],
            'password_hash' => (string) $u['password_hash'],
            'role' => in_array($u['role'] ?? null, VALID_ROLES, true) ? $u['role'] : ROLE_USER,
        ];
        $department = department_code((string) ($u['department'] ?? ''));
        if ($department !== null) {
            $entry['department'] = $department;
        }
        $out[] = $entry;
    }
    usort($out, fn($a, $b) => strcasecmp($a['login'], $b['login']));
    return $out;
}

function save_users(array $users): void
{
    $php = "<?php\ndeclare(strict_types=1);\nreturn " . var_export($users, true) . ";\n";
    $tmp = AUTH_CREDENTIALS_FILE . '.tmp';
    if (file_put_contents($tmp, $php) === false) {
        throw new RuntimeException('Не удалось записать файл учётных записей.');
    }
    if (!rename($tmp, AUTH_CREDENTIALS_FILE)) {
        @unlink($tmp);
        throw new RuntimeException('Не удалось сохранить файл учётных записей.');
    }
    // Без этого при включённом OPcache (обычная настройка на хостинге)
    // следующий require AUTH_CREDENTIALS_FILE ещё пару секунд (см.
    // opcache.revalidate_freq) может отдавать закэшированную версию ДО
    // этого сохранения — например, только что сброшенный пароль ещё не
    // сработает при входе сразу после сброса.
    if (function_exists('opcache_invalidate')) {
        opcache_invalidate(AUTH_CREDENTIALS_FILE, true);
    }
}

function find_user(array $users, string $login): ?array
{
    foreach ($users as $u) {
        if (hash_equals($u['login'], $login)) {
            return $u;
        }
    }
    return null;
}

function user_login_valid(string $login): bool
{
    return (bool) preg_match('/^[a-zA-Zа-яА-ЯёЁ0-9_.\-]{2,40}$/u', $login);
}

/** Код отдела из любого написания («co», «ЦО», «PTO») или null. */
function department_code(string $value): ?string
{
    $value = mb_strtoupper(trim($value));
    if ($value === '') {
        return null;
    }
    $value = ['ДР' => 'DR', 'НО' => 'NO'][$value] ?? $value;
    if (isset(KB_DEPARTMENT_NAMES[$value])) {
        return $value;
    }
    foreach (KB_DEPARTMENT_NAMES as $code => $name) {
        if (mb_strtoupper($name) === $value) {
            return $code;
        }
    }
    return preg_match('/^[A-ZА-ЯЁ0-9]{1,12}$/u', $value) ? $value : null;
}

function department_label(?string $code): string
{
    if ($code === null || $code === '') {
        return 'без отдела';
    }
    return KB_DEPARTMENT_NAMES[$code] ?? $code;
}

/** Выбранный в учётке отдел/профиль: НО сохраняется отдельно от рабочего отдела. */
function user_department_profile(array $user): ?string
{
    $stored = department_code((string) ($user['department'] ?? ''));
    return $stored ?? department_code((string) (login_department((string) ($user['login'] ?? '')) ?? ''));
}

/** Для НО рабочий отдел определяется только известным суффиксом логина. */
function head_department_from_login(string $login): ?string
{
    $department = department_code((string) (login_department($login) ?? ''));
    // Обозначения НО в логинах; остальные отделы сохраняют свои коды.
    $aliases = ['BY' => 'BUH', 'MTO' => 'OMTS', 'VP' => 'RN',
                'UR' => 'YUR', 'KD' => 'OK', 'PTO' => 'PTO'];
    $department = $aliases[$department ?? ''] ?? $department;
    return $department !== null && isset(KB_DEPARTMENT_NAMES[$department])
        && !in_array($department, ['DR', 'NO'], true) ? $department : null;
}

function department_assignment_error(string $login, ?string $profile): ?string
{
    if ($profile === 'NO' && head_department_from_login($login) === null) {
        return 'Для начальника отдела укажите отдел в конце логина: например grigorian.g_CO или employee_PTO.';
    }
    return null;
}

/** Рабочий отдел: у НО — из логина, у остальных — выбранный в учётке. */
function user_department(array $user): ?string
{
    $profile = user_department_profile($user);
    return $profile === 'NO' ? head_department_from_login((string) ($user['login'] ?? '')) : $profile;
}

/** Отдел пользователя по логину (из файла учёток). */
/** Роль учётки по логину (для проверок доступа к чужому логину); текущего пользователя — из сессии. '' — учётки нет. */
function role_of_login(string $login): string
{
    static $cache = [];
    $login = trim($login);
    if ($login === '') {
        return '';
    }
    if (session_status() === PHP_SESSION_ACTIVE && strcasecmp((string) ($_SESSION['kb_user'] ?? ''), $login) === 0 && !empty($_SESSION['kb_role'])) {
        return (string) $_SESSION['kb_role'];
    }
    if (!array_key_exists($login, $cache)) {
        $user = find_user(load_users(), $login);
        $cache[$login] = $user !== null ? (string) ($user['role'] ?? ROLE_USER) : '';
    }
    return $cache[$login];
}

function department_of_login(string $login): ?string
{
    if ($login === '') {
        return null;
    }
    $user = find_user(load_users(), $login);
    return $user !== null ? user_department($user) : login_department($login);
}

/** Профиль из серверной учётки; смена отдела обновляет и уже открытую сессию. */
function current_department_profile(): ?string
{
    if (session_status() !== PHP_SESSION_ACTIVE) {
        return null;
    }
    $login = (string) ($_SESSION['kb_user'] ?? '');
    if ($login === '') {
        return null;
    }
    clearstatcache(true, AUTH_CREDENTIALS_FILE);
    $revision = is_file(AUTH_CREDENTIALS_FILE)
        ? (hash_file('sha256', AUTH_CREDENTIALS_FILE) ?: 'unreadable') : 'missing';
    $sameUser = ($_SESSION['kb_dept_for'] ?? '') === $login;
    if (!$sameUser || !array_key_exists('kb_dept', $_SESSION)
        || ($_SESSION['kb_dept_revision'] ?? '') !== $revision) {
        if (function_exists('opcache_invalidate')) {
            opcache_invalidate(AUTH_CREDENTIALS_FILE, true);
        }
        $user = find_user(load_users(), $login);
        // Старые серверные сессии без найденной записи сохраняют прежнее поведение.
        $fallback = $sameUser ? ($_SESSION['kb_dept'] ?? null) : login_department($login);
        $_SESSION['kb_dept'] = $user !== null ? user_department_profile($user) : department_code((string) $fallback);
        $_SESSION['kb_dept_for'] = $login;
        $_SESSION['kb_dept_revision'] = $revision;
    }
    return department_code((string) ($_SESSION['kb_dept'] ?? ''));
}

function department_profile_of_login(string $login): ?string
{
    if ($login !== '' && strcasecmp($login, (string) ($_SESSION['kb_user'] ?? '')) === 0 && session_status() === PHP_SESSION_ACTIVE) {
        return current_department_profile();
    }
    $user = find_user(load_users(), $login);
    return $user !== null ? user_department_profile($user)
        : department_code((string) (login_department($login) ?? ''));
}

function current_department(): ?string
{
    $profile = current_department_profile();
    return $profile === 'NO' ? head_department_from_login((string) ($_SESSION['kb_user'] ?? '')) : $profile;
}

/** Полный доступ к инструментам ДР не даёт административную роль. */
function user_has_all_tools(?string $login = null): bool
{
    return department_profile_of_login($login ?? (string) ($_SESSION['kb_user'] ?? '')) === 'DR';
}

// Старое правило для учёток без поля отдела: формат "фамилия.инициал_ОТДЕЛ"
// (например "andreeva.o_SDO" — код отдела после последнего "_"). Если
// распознать не получилось — null, «без отдела».
function login_department(string $login): ?string
{
    $pos = strrpos($login, '_');
    if ($pos === false || $pos === strlen($login) - 1) {
        return null;
    }
    $dept = substr($login, $pos + 1);
    return $dept !== '' ? mb_strtoupper($dept) : null;
}
