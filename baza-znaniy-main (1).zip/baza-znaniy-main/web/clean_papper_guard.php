<?php
declare(strict_types=1);

// Must be the first include in every Clean Papper page and future endpoint.
require __DIR__ . '/auth_guard.php';
require_once __DIR__ . '/clean_papper_access.php';

if (!clean_papper_allowed((string) ($_SESSION['kb_user'] ?? ''))) {
    http_response_code(403);
    header('Content-Type: text/plain; charset=utf-8');
    header('Cache-Control: private, no-store, max-age=0');
    header('X-Robots-Tag: noindex, nofollow, noarchive');
    exit('Доступ запрещён.');
}

header('Cache-Control: private, no-store, max-age=0');
header('X-Robots-Tag: noindex, nofollow, noarchive');
