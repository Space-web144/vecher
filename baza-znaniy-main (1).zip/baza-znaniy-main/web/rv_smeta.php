<?php
declare(strict_types=1);

// Карточка сметы из 1С (?id=<ИдентификаторЛРВ>): где она в дереве — объект (папка НГ) → номенклатурная
// группа → смета, — номер ЗН, ответственный, все версии РВ и по последней готовой версии:
//   основные работы — работы ИСР с объёмами под строками ЛРВ без номера ЗН;
//   наряд-заказы — то же по каждому наряд-заказу строк ЛРВ: поле 1С «НомерЗН» или Аналитика 4
//   вида «Работы по З/Н №…» (rv_zn_of).
// Работа, под которой есть строки разных ЗН, делится между ними пропорционально вкладу строк в объём
// (количество × коэффициент), а если вклада нет — по числу строк; такой объём помечен «≈».
// Источник — РВ для 1С (`_rv_1c.json.gz`), которую 1С и загружает. Доступ — как к модулю ЦО (rv_guard).

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require_once __DIR__ . '/users.php';
require_once __DIR__ . '/lib.php';
require_once __DIR__ . '/rv_lib.php';

rv_guard();

$id = (string) ($_GET['id'] ?? '');
if ($id === '' || mb_strlen($id) > 120) {
    rv_fail('Неверная смета.');
}
$row = null;
foreach (rv_registry_rows() as $candidate) {
    if ($candidate['id'] === $id) {
        $row = $candidate;
        break;
    }
}
if ($row === null) {
    rv_fail('Смета не найдена: 1С её не присылала или она удалена.', 404);
}
$versions = rv_onec_jobs($id)[$id] ?? [];

/** Число для таблицы: до трёх знаков после запятой, без хвостовых нулей. */
function rv_smeta_num(?float $value): string
{
    if ($value === null) {
        return '—';
    }
    $text = number_format($value, 3, ',', ' ');
    return rtrim(rtrim($text, '0'), ',');
}

// ── Версии ──
$versionRows = [];
$source = null;        // версия, по которой показаны работы: последняя готовая
foreach ($versions as $job) {
    [$state, $status] = rv_state($job['token'], $job);
    [$code, $label, $kind] = rv_registry_state($job, $state, $status);
    $summary = is_array($status['summary'] ?? null) ? $status['summary'] : [];
    $versionRows[] = ['job' => $job, 'code' => $code, 'label' => $label, 'kind' => $kind, 'summary' => $summary,
                      'approval' => rv_approval($job, $status)];
    if ($source === null && $state === 'done' && is_file(rv_paths($job['token'])['onec'])) {
        $source = end($versionRows);
    }
}

// ── Основные работы и наряд-заказы ──
$groups = [];          // '' — основные работы, иначе номер ЗН => [работы]
$unboundByZn = [];
$hasElements = false;
$data = $source !== null ? rv_read_packed(rv_paths($source['job']['token'])['onec']) : null;
if ($data !== null) {
    foreach ((array) ($data['Работы'] ?? []) as $work) {
        if (!is_array($work)) {
            continue;
        }
        $parts = [];
        foreach ((array) ($work['Материалы'] ?? []) as $material) {
            $zn = rv_zn_of((array) $material);
            $parts[$zn] = $parts[$zn] ?? ['weight' => 0.0, 'rows' => 0];
            $parts[$zn]['weight'] += (float) ($material['Количество'] ?? 0) * (float) ($material['Коэффициент'] ?? 0);
            $parts[$zn]['rows']++;
        }
        if (!$parts) {
            $parts[''] = ['weight' => 0.0, 'rows' => 0];      // работа, добавленная агентом без строк ЛРВ
        }
        $totalWeight = array_sum(array_column($parts, 'weight'));
        $totalRows = array_sum(array_column($parts, 'rows'));
        $volume = isset($work['Объем']) && is_numeric($work['Объем']) ? (float) $work['Объем'] : null;
        $element = trim((string) ($work['Элемент'] ?? ''));
        $hasElements = $hasElements || $element !== '';
        foreach ($parts as $zn => $part) {
            $share = count($parts) === 1 ? 1.0
                : ($totalWeight > 0 ? $part['weight'] / $totalWeight : ($totalRows > 0 ? $part['rows'] / $totalRows : 0.0));
            $groups[(string) $zn][] = [
                'code' => (string) ($work['КодИСР'] ?? ''), 'name' => (string) ($work['Наименование'] ?? ''),
                'unit' => (string) ($work['ЕдиницаИзмерения'] ?? ''), 'volume' => $volume !== null ? $volume * $share : null,
                'split' => count($parts) > 1, 'element' => $element, 'rows' => $part['rows'], 'auto' => !empty($work['ДобавленоАгентом']),
            ];
        }
    }
    foreach ((array) ($data['БезРаботы'] ?? []) as $material) {
        $zn = rv_zn_of((array) $material);
        $unboundByZn[$zn] = ($unboundByZn[$zn] ?? 0) + 1;
    }
}
$main = $groups[''] ?? [];
unset($groups['']);
uksort($groups, 'strnatcasecmp');
foreach (array_keys($unboundByZn) as $zn) {
    if ($zn !== '' && !isset($groups[$zn])) {
        $groups[$zn] = [];
    }
}
$headerZn = trim($row['zn']);
$resp = $row['responsible'];
$levelText = ['folder' => 'за объект', 'object' => 'за номенклатурную группу', 'system' => 'за смету'];
$latest = $versions[0] ?? null;

/** Таблица работ группы. */
function rv_smeta_works(array $works, bool $hasElements): string
{
    if (!$works) {
        return '<p class="hint">Работ нет.</p>';
    }
    $html = '<div class="table-wrap"><table class="data-table rv-smeta-works"><thead><tr><th>Код ИСР</th><th>Работа</th>'
        . ($hasElements ? '<th>Элемент</th>' : '') . '<th>Ед.</th><th class="num">Объём</th><th class="num">Строк ЛРВ</th></tr></thead><tbody>';
    foreach ($works as $work) {
        $html .= '<tr><td class="rv-smeta-code">' . rv_h($work['code']) . '</td><td>' . rv_h($work['name'])
            . ($work['auto'] ? ' <span class="muted-dash">(добавлена агентом)</span>' : '') . '</td>'
            . ($hasElements ? '<td>' . rv_h($work['element']) . '</td>' : '')
            . '<td>' . rv_h($work['unit']) . '</td>'
            . '<td class="num">' . ($work['split'] && $work['volume'] !== null ? '≈ ' : '') . rv_h(rv_smeta_num($work['volume'])) . '</td>'
            . '<td class="num">' . (int) $work['rows'] . '</td></tr>';
    }
    return $html . '</tbody></table></div>';
}
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= rv_h($row['system'] . ($row['smeta'] !== '' && $row['smeta'] !== $row['system'] ? ' — ' . $row['smeta'] : '')) ?> — База знаний</title>
<link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
<script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
</head>
<body>
<div class="shell">
  <?php require __DIR__ . '/sidebar.php'; ?>

  <div class="dashboard-main">
  <div class="page-wide">

  <div class="card">
    <p class="rv-crumbs">
      <a href="rv_registry.php">Объекты и ЛРВ из 1С</a> ›
      <?php if ($row['folder_key'] !== ''): ?><a href="rv_registry.php?q=<?= rv_h(rawurlencode($row['folder'])) ?>"><?= rv_h($row['folder']) ?></a><?php else: ?><span class="muted-dash">объект не указан</span><?php endif; ?> ›
      <a href="rv_registry.php?q=<?= rv_h(rawurlencode($row['obj'])) ?>"><?= rv_h($row['obj']) ?></a>
    </p>
    <h1><?= rv_h($row['system']) ?></h1>
    <p class="subtitle">
      <?php if ($row['smeta'] !== '' && $row['smeta'] !== $row['system']): ?><?= preg_match('/^смета/iu', $row['smeta']) ? rv_h($row['smeta']) : 'Смета «' . rv_h($row['smeta']) . '»' ?>. <?php endif; ?>
      <?php if ($headerZn !== ''): ?>Наряд-заказ сметы: № <?= rv_h($headerZn) ?>. <?php endif; ?>
      Ответственный: <?= $resp ? '<b>' . rv_h((string) $resp['user']) . '</b> <span class="muted-dash">(' . rv_h($levelText[$resp['level']] ?? '') . ')</span>' : 'не назначен' ?>.
    </p>

    <div class="rv-figures">
      <div><b><?= rv_h($row['label']) ?></b><span>состояние последней версии</span></div>
      <div><b><?= count($versions) ?></b><span>версий ЛРВ на сайте</span></div>
      <div><b><?= count($main) ?></b><span>основных работ</span></div>
      <div><b><?= count($groups) ?></b><span>наряд-заказов в ЛРВ</span></div>
    </div>

    <?php if ($latest !== null): ?>
    <div class="links">
      <a class="btn" href="rv_status.php?token=<?= rv_h($latest['token']) ?>">Открыть РВ (последняя версия)</a>
      <?php if ($source !== null): ?><a class="btn secondary" href="rv_download.php?token=<?= rv_h($source['job']['token']) ?>&amp;kind=xlsx">Скачать РВ (Excel, по форме ТКП)</a><?php endif; ?>
    </div>
    <?php else: ?>
    <div class="alert warn">РВ этой сметы на сайте удалены. Смета остаётся в дереве объектов; новая ЛРВ из 1С построит РВ заново.</div>
    <?php endif; ?>
  </div>

  <div class="card">
    <h2>Основные работы</h2>
    <?php if ($source === null): ?>
    <p class="hint"><?= $latest !== null ? 'Готовой РВ пока нет — работы появятся, когда агент её построит.' : 'РВ нет.' ?></p>
    <?php else: ?>
    <p class="subtitle">Работы ИСР с объёмами по строкам ЛРВ основных работ (без наряд-заказа) — по РВ от <?= rv_h(rv_when((int) ($source['job']['created'] ?? 0))) ?> (<?= rv_h(mb_strtolower(mb_substr($source['label'], 0, 1)) . mb_substr($source['label'], 1)) ?>)<?= $source['job']['token'] !== ($latest['token'] ?? '') ? '; более новая версия ещё не готова' : '' ?>. Объём «≈» — часть работы, под которой есть строки и других наряд-заказов.</p>
    <?= rv_smeta_works($main, $hasElements) ?>
    <?php if (!empty($unboundByZn[''])): ?><p class="hint">Строк ЛРВ без работы: <?= (int) $unboundByZn[''] ?> — их нужно разнести в РВ.</p><?php endif; ?>
    <?php endif; ?>
  </div>

  <div class="card">
    <h2>Наряд-заказы</h2>
    <?php if ($source === null): ?>
    <p class="hint">Появятся вместе с готовой РВ.</p>
    <?php elseif (!$groups): ?>
    <p class="hint">В строках ЛРВ этой сметы номеров ЗН нет<?= $headerZn !== '' ? ' (у самой сметы указан ЗН № ' . rv_h($headerZn) . ')' : '' ?> — все работы основные.</p>
    <?php else: ?>
    <?php foreach ($groups as $zn => $works): ?>
    <details class="rv-smeta-zn" open>
      <summary><b>ЗН № <?= rv_h((string) $zn) ?></b> <span class="muted-dash">работ: <?= count($works) ?>, строк ЛРВ: <?= array_sum(array_column($works, 'rows')) ?><?= !empty($unboundByZn[$zn]) ? ', без работы: ' . (int) $unboundByZn[$zn] : '' ?></span></summary>
      <?= rv_smeta_works($works, $hasElements) ?>
    </details>
    <?php endforeach; ?>
    <?php endif; ?>
  </div>

  <div class="card">
    <h2>Версии ЛРВ</h2>
    <?php if (!$versionRows): ?>
    <p class="hint">На сайте версий нет.</p>
    <?php else: ?>
    <div class="table-wrap">
    <table class="data-table">
      <thead><tr><th>Получена</th><th>Состояние</th><th>РВ</th><th>Согласовал</th><th></th></tr></thead>
      <tbody>
      <?php foreach ($versionRows as $i => $v): ?>
        <tr>
          <td><?= rv_h(rv_when((int) ($v['job']['created'] ?? 0))) ?><?= $i === 0 ? ' <span class="muted-dash">последняя</span>' : '' ?><?php if (rv_resent_text($v['job']) !== ''): ?><br><span class="muted-dash"><?= rv_h(rv_resent_text($v['job'])) ?></span><?php endif; ?></td>
          <td><span class="home-status is-<?= $v['kind'] ?>"><?= rv_h($v['label']) ?></span></td>
          <td><?php if (!empty($v['summary']['rows'])): ?>строк <?= (int) $v['summary']['rows'] ?>, работ <?= (int) ($v['summary']['works'] ?? 0) ?><?php endif; ?></td>
          <td><?= $v['approval'] ? rv_h((string) $v['approval']['user']) . ', ' . rv_h(rv_when((int) $v['approval']['when'])) : '' ?></td>
          <td><a class="btn secondary btn-small" href="rv_status.php?token=<?= rv_h($v['job']['token']) ?>">Открыть</a></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    </div>
    <?php endif; ?>
  </div>

  <p><a href="rv_registry.php">← Объекты и ЛРВ из 1С</a></p>
  </div>
  </div>
</div>
</body>
</html>
