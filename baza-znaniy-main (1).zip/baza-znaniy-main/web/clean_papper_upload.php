<?php
declare(strict_types=1);

require __DIR__ . '/clean_papper_guard.php';
require_once __DIR__ . '/clean_papper_upload_lib.php';

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: private, no-store, max-age=0');
header('X-Content-Type-Options: nosniff');

function cp_upload_json(array $data, int $status = 200): void
{
    http_response_code($status);
    echo json_encode($data, JSON_UNESCAPED_UNICODE | JSON_INVALID_UTF8_SUBSTITUTE);
    exit;
}
if (($_SERVER['REQUEST_METHOD'] ?? '') !== 'POST') {
    header('Allow: POST');
    cp_upload_json(['ok' => false, 'message' => 'Используйте POST.'], 405);
}
if (!isset($_SESSION['clean_papper_csrf']) ||
    !is_string($_SESSION['clean_papper_csrf']) ||
    !hash_equals($_SESSION['clean_papper_csrf'], (string) ($_POST['csrf'] ?? ''))) {
    cp_upload_json(['ok' => false, 'message' => 'Сессия устарела. Обновите страницу.'], 403);
}
$action = (string) ($_POST['action'] ?? '');
if (!in_array($action, ['init', 'chunk', 'cancel'], true)) {
    cp_upload_json(['ok' => false, 'message' => 'Неизвестный режим загрузки.'], 400);
}
try {
    if ($action === 'init') {
        $totalText = (string) ($_POST['file_size'] ?? '');
        if (!preg_match('/^[1-9]\d{0,8}$/D', $totalText)) {
            throw new InvalidArgumentException('Некорректный размер PDF.');
        }
        // Only one temporary PDF per authenticated session.
        cp_pdf_upload_discard($_SESSION['clean_papper_upload'] ?? null);
        unset($_SESSION['clean_papper_upload']);
        $meta = cp_pdf_upload_begin((string) ($_POST['file_name'] ?? ''), (int) $totalText);
        $_SESSION['clean_papper_upload'] = $meta;
        cp_upload_json(['ok' => true, 'upload_id' => $meta['id'],
                        'chunk_bytes' => CP_PDF_CHUNK_BYTES, 'received' => 0]);
    }
    $meta = $_SESSION['clean_papper_upload'] ?? null;
    $id = (string) ($_POST['upload_id'] ?? '');
    if (!is_array($meta) || !is_string($meta['id'] ?? null) ||
        !hash_equals($meta['id'], $id)) {
        throw new InvalidArgumentException('Загрузка не найдена. Начните заново.');
    }
    if ($action === 'cancel') {
        cp_pdf_upload_discard($meta);
        unset($_SESSION['clean_papper_upload']);
        cp_upload_json(['ok' => true, 'message' => 'Временная загрузка удалена.']);
    }
    $offsetText = (string) ($_POST['offset'] ?? '');
    if (!preg_match('/^(0|[1-9]\d{0,8})$/D', $offsetText)) {
        throw new InvalidArgumentException('Неверное смещение части PDF.');
    }
    $part = $_FILES['part'] ?? null;
    if (!is_array($part) || (int) ($part['error'] ?? -1) !== UPLOAD_ERR_OK ||
        !is_string($part['tmp_name'] ?? null) ||
        !is_uploaded_file($part['tmp_name'])) {
        throw new InvalidArgumentException('Сервер не получил часть PDF. Лимит части — 1 МБ.');
    }
    $size = (int) ($part['size'] ?? 0);
    if ($size < 1 || $size > CP_PDF_CHUNK_BYTES) {
        throw new InvalidArgumentException('Часть PDF должна быть не больше 1 МБ.');
    }
    $bytes = @file_get_contents($part['tmp_name']);
    if (!is_string($bytes) || strlen($bytes) !== $size) {
        throw new RuntimeException('Could not read uploaded part');
    }
    $received = cp_pdf_upload_append($meta, $bytes, (int) $offsetText);
    $_SESSION['clean_papper_upload'] = $meta;
    cp_upload_json(['ok' => true, 'received' => $received,
                    'size' => (int) $meta['size'],
                    'complete' => $meta['complete'] === true]);
} catch (InvalidArgumentException $e) {
    cp_upload_json(['ok' => false, 'message' => $e->getMessage()], 400);
} catch (Throwable $e) {
    // Do not display filesystem paths, raw uploaded bytes or stack traces.
    cp_upload_json(['ok' => false, 'message' =>
        'Не удалось записать PDF во временное защищённое хранилище.'], 503);
}
