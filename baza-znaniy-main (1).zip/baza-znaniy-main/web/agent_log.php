<?php
declare(strict_types=1);

// Журнал вопросов Альфика (ассистента) — для анализа: что спрашивают, кто,
// с какими файлами, сколько ждали ответа, где были ошибки. Только для
// администраторов. Данные — AGENT_LOG_DIR (пишут agent_api.php и
// common/web_agent_chat.py), файл на месяц. Выгрузка месяца в CSV — для
// Excel или для анализа тем же Альфиком.

require __DIR__ . '/admin_guard.php';
require __DIR__ . '/config.php';
require_once __DIR__ . '/users.php';
require __DIR__ . '/agent_lib.php';
require_once __DIR__ . '/design.php';

const LOG_PAGE_ROWS = 300;

function lg(string $value): string
{
    return htmlspecialchars($value, ENT_QUOTES, 'UTF-8');
}

function lg_status(array $row): string
{
    $answer = $row['answer'] ?? null;
    if (!is_array($answer)) {
        return 'none';
    }
    return !empty($answer['ok']) ? 'ok' : 'error';
}

function lg_tokens(?array $answer): int
{
    $usage = (array) (($answer ?? [])['usage'] ?? []);
    return (int) ($usage['input_tokens'] ?? 0) + (int) ($usage['output_tokens'] ?? 0)
        + (int) ($usage['cache_read_input_tokens'] ?? 0) + (int) ($usage['cache_creation_input_tokens'] ?? 0);
}

$name = design_refresh() ? 'Альфика' : 'ассистента';
$months = agent_log_months();
$month = (string) ($_GET['month'] ?? ($months[0] ?? date('Y-m')));
if (!preg_match('/^\d{4}-\d{2}$/', $month)) {
    $month = date('Y-m');
}
$all = agent_log_rows($month);

$filterUser = (string) ($_GET['user'] ?? '');
$filterDept = (string) ($_GET['dept'] ?? '');
$filterStatus = (string) ($_GET['status'] ?? '');
$query = trim((string) ($_GET['q'] ?? ''));

$rows = array_values(array_filter($all, static function (array $row) use ($filterUser, $filterDept, $filterStatus, $query): bool {
    if ($filterUser !== '' && (string) ($row['user'] ?? '') !== $filterUser) {
        return false;
    }
    if ($filterDept !== '' && (string) ($row['dept'] ?? '') !== $filterDept) {
        return false;
    }
    if ($filterStatus !== '' && lg_status($row) !== $filterStatus) {
        return false;
    }
    if ($query !== '') {
        $hay = (string) ($row['text'] ?? '') . ' ' . implode(' ', array_column((array) ($row['files'] ?? []), 'name'));
        if (mb_stripos($hay, $query) === false) {
            return false;
        }
    }
    return true;
}));

// ── Выгрузка CSV (с учётом фильтров): «;» и BOM — откроется в Excel. ──
if (($_GET['export'] ?? '') === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    header("Content-Disposition: attachment; filename=\"agent_log_$month.csv\"; filename*=UTF-8''"
        . rawurlencode('Журнал ' . $name . ' ' . $month . '.csv'));
    header('Cache-Control: no-store');
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, ['Дата и время', 'Пользователь', 'Отдел', 'Чат', 'Тема чата', '№ вопроса в чате', 'Повтор',
                   'Вопрос', 'Файлы', 'Итог', 'Ошибка', 'Секунд до ответа', 'Модель', 'Токенов', 'Знаков ответа',
                   'Созданные файлы', 'Источников', 'Начало ответа'], ';');
    foreach (array_reverse($rows) as $row) {
        $answer = is_array($row['answer'] ?? null) ? $row['answer'] : null;
        $status = lg_status($row);
        fputcsv($out, [
            date('Y-m-d H:i:s', (int) ($row['time'] ?? 0)),
            (string) ($row['user'] ?? ''),
            (string) ($row['dept'] ?? ''),
            (string) ($row['chat'] ?? ''),
            (string) ($row['title'] ?? ''),
            (int) ($row['n'] ?? 0),
            ($row['action'] ?? '') === 'retry' ? 'да' : '',
            (string) ($row['text'] ?? ''),
            implode(', ', array_column((array) ($row['files'] ?? []), 'name')),
            $status === 'ok' ? 'ответ' : ($status === 'error' ? 'ошибка' : 'нет данных'),
            (string) ($answer['error'] ?? ''),
            $answer['seconds'] ?? '',
            (string) ($answer['model'] ?? ''),
            $answer ? lg_tokens($answer) : '',
            $answer['answer_chars'] ?? '',
            implode(', ', (array) ($answer['files'] ?? [])),
            $answer['sources'] ?? '',
            (string) ($answer['answer'] ?? ''),
        ], ';');
    }
    fclose($out);
    exit;
}

// ── Сводка по выбранным записям ──
$users = [];
$depts = [];
$errors = 0;
$noAnswer = 0;
$seconds = [];
$tokens = 0;
$withFiles = 0;
foreach ($rows as $row) {
    $users[(string) ($row['user'] ?? '')] = ($users[(string) ($row['user'] ?? '')] ?? 0) + 1;
    $dept = (string) ($row['dept'] ?? '') ?: '—';
    $depts[$dept] = ($depts[$dept] ?? 0) + 1;
    $status = lg_status($row);
    $errors += $status === 'error' ? 1 : 0;
    $noAnswer += $status === 'none' ? 1 : 0;
    if ($status === 'ok' && isset($row['answer']['seconds'])) {
        $seconds[] = (int) $row['answer']['seconds'];
    }
    $tokens += lg_tokens(is_array($row['answer'] ?? null) ? $row['answer'] : null);
    $withFiles += !empty($row['files']) ? 1 : 0;
}
arsort($users);
arsort($depts);
sort($seconds);
$median = $seconds ? $seconds[intdiv(count($seconds), 2)] : null;

// Списки для фильтров — по всему месяцу.
$allUsers = array_values(array_unique(array_map(static fn(array $r): string => (string) ($r['user'] ?? ''), $all)));
sort($allUsers);
$allDepts = array_values(array_filter(array_unique(array_map(static fn(array $r): string => (string) ($r['dept'] ?? ''), $all))));
sort($allDepts);

$monthNames = ['01' => 'январь', '02' => 'февраль', '03' => 'март', '04' => 'апрель', '05' => 'май', '06' => 'июнь',
               '07' => 'июль', '08' => 'август', '09' => 'сентябрь', '10' => 'октябрь', '11' => 'ноябрь', '12' => 'декабрь'];
$monthLabel = static fn(string $m): string => ($monthNames[substr($m, 5, 2)] ?? substr($m, 5, 2)) . ' ' . substr($m, 0, 4);
$params = array_filter(['month' => $month, 'user' => $filterUser, 'dept' => $filterDept, 'status' => $filterStatus, 'q' => $query],
    static fn($v): bool => $v !== '');
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Журнал <?= lg($name) ?> — База знаний</title>
<link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
<script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
</head>
<body>
<div class="shell">
  <?php require __DIR__ . '/sidebar.php'; ?>

  <div class="dashboard-main">
  <div class="page-wide">

  <div class="card">
    <h1>Журнал <?= lg($name) ?></h1>
    <p class="subtitle">Вопросы сотрудников: кто, когда, что спросил, какие файлы приложил и чем кончилось — для анализа, что нужно людям и где <?= lg(design_refresh() ? 'Альфик' : 'ассистент') ?> не справляется. Файлы сюда не попадают, только имена; начало ответа — до <?= (int) AGENT_LOG_ANSWER_CHARS ?> знаков. Журнал не зависит от чатов (удаление чата его не трогает) и хранится <?= (int) AGENT_LOG_KEEP_MONTHS ?> мес.</p>

    <form class="log-filters" method="get" action="agent_log.php">
      <label>Месяц
        <select name="month">
          <?php foreach ($months ?: [$month] as $m): ?>
          <option value="<?= lg($m) ?>"<?= $m === $month ? ' selected' : '' ?>><?= lg($monthLabel($m)) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <label>Пользователь
        <select name="user">
          <option value="">все</option>
          <?php foreach ($allUsers as $u): ?>
          <option value="<?= lg($u) ?>"<?= $u === $filterUser ? ' selected' : '' ?>><?= lg($u) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <label>Отдел
        <select name="dept">
          <option value="">все</option>
          <?php foreach ($allDepts as $d): ?>
          <option value="<?= lg($d) ?>"<?= $d === $filterDept ? ' selected' : '' ?>><?= lg($d) ?></option>
          <?php endforeach; ?>
        </select>
      </label>
      <label>Итог
        <select name="status">
          <option value="">все</option>
          <option value="ok"<?= $filterStatus === 'ok' ? ' selected' : '' ?>>ответ</option>
          <option value="error"<?= $filterStatus === 'error' ? ' selected' : '' ?>>ошибка</option>
          <option value="none"<?= $filterStatus === 'none' ? ' selected' : '' ?>>нет данных</option>
        </select>
      </label>
      <label class="log-search">Текст или файл
        <input type="search" name="q" value="<?= lg($query) ?>" placeholder="например, спецификация">
      </label>
      <button type="submit" class="secondary">Показать</button>
    </form>

    <?php if (!$all): ?>
      <p class="hint">За <?= lg($monthLabel($month)) ?> записей нет. Журнал начинает заполняться с первого вопроса после обновления сайта.</p>
    <?php else: ?>
    <div class="rv-figures">
      <div><b><?= count($rows) ?></b><span>вопросов<?= count($rows) !== count($all) ? ' из ' . count($all) : '' ?>, с файлами <?= $withFiles ?></span></div>
      <div><b><?= count($users) ?></b><span>сотрудников</span></div>
      <div class="is-question"><b><?= $errors ?></b><span>ошибок<?= $noAnswer ? ', без итога ' . $noAnswer : '' ?></span></div>
      <div><b><?= $median !== null ? $median . ' с' : '—' ?></b><span>медиана ожидания ответа</span></div>
      <div><b><?= number_format($tokens, 0, ',', ' ') ?></b><span>токенов</span></div>
      <div><b><?= count($depts) ?></b><span>отделов: <?= lg(implode(', ', array_map(static fn($d, $n) => $d . ' ' . $n, array_keys(array_slice($depts, 0, 6, true)), array_slice($depts, 0, 6, true)))) ?></span></div>
    </div>
    <div class="links">
      <a class="btn secondary" href="agent_log.php?<?= lg(http_build_query($params + ['export' => 'csv'])) ?>">Скачать CSV (<?= count($rows) ?>)</a>
    </div>
    <?php endif; ?>
  </div>

  <?php if ($rows): ?>
  <div class="card">
    <h2><?= count($rows) > LOG_PAGE_ROWS ? 'Последние ' . LOG_PAGE_ROWS . ' из ' . count($rows) : 'Вопросы' ?></h2>
    <div class="table-wrap">
    <table class="data-table log-table">
      <thead><tr><th>Когда</th><th>Кто</th><th>Вопрос</th><th>Файлы</th><th>Итог</th></tr></thead>
      <tbody>
      <?php foreach (array_slice($rows, 0, LOG_PAGE_ROWS) as $row): ?>
        <?php
          $answer = is_array($row['answer'] ?? null) ? $row['answer'] : null;
          $status = lg_status($row);
          $text = (string) ($row['text'] ?? '');
        ?>
        <tr>
          <td><?= lg(date('d.m H:i', (int) ($row['time'] ?? 0))) ?></td>
          <td><?= lg((string) ($row['user'] ?? '')) ?><?php if (!empty($row['dept'])): ?><br><span class="muted-dash"><?= lg((string) $row['dept']) ?></span><?php endif; ?></td>
          <td>
            <?php if ($text === ''): ?><span class="muted-dash">только файлы</span>
            <?php elseif (mb_strlen($text) <= 280): ?><?= nl2br(lg($text)) ?>
            <?php else: ?><details class="log-more"><summary><?= lg(mb_substr($text, 0, 280)) ?>…</summary><?= nl2br(lg($text)) ?></details><?php endif; ?>
            <div class="muted-dash log-meta">
              чат «<?= lg(mb_strimwidth((string) ($row['title'] ?? ''), 0, 60, '…')) ?>», вопрос № <?= (int) ($row['n'] ?? 0) ?><?= ($row['action'] ?? '') === 'retry' ? ', повтор' : '' ?>
            </div>
            <?php if ($answer && !empty($answer['answer'])): ?>
            <details class="log-more log-answer"><summary>Ответ (<?= number_format((int) ($answer['answer_chars'] ?? 0), 0, ',', ' ') ?> зн.)</summary><?= nl2br(lg((string) $answer['answer'])) ?><?= (int) ($answer['answer_chars'] ?? 0) > mb_strlen((string) $answer['answer']) ? '…' : '' ?></details>
            <?php endif; ?>
          </td>
          <td><?php foreach ((array) ($row['files'] ?? []) as $file): ?><div><?= lg((string) ($file['name'] ?? '')) ?></div><?php endforeach; ?></td>
          <td>
            <?php if ($status === 'ok'): ?>
              <span class="home-status is-done">ответ</span>
              <div class="muted-dash"><?= isset($answer['seconds']) ? (int) $answer['seconds'] . ' с' : '' ?><?= lg_tokens($answer) ? ', ' . number_format(lg_tokens($answer), 0, ',', ' ') . ' ток.' : '' ?><?= !empty($answer['files']) ? ', файлов ' . count((array) $answer['files']) : '' ?></div>
            <?php elseif ($status === 'error'): ?>
              <span class="home-status is-error">ошибка</span>
              <div class="muted-dash" title="<?= lg((string) ($answer['error'] ?? '')) ?>"><?= lg(mb_strimwidth((string) ($answer['error'] ?? ''), 0, 110, '…')) ?></div>
            <?php else: ?>
              <span class="muted-dash">нет данных</span>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    </div>
  </div>
  <?php endif; ?>

  </div>
  </div>
</div>
</body>
</html>
