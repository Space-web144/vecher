<?php
declare(strict_types=1);

// Массовое подтверждение ИЛИ отклонение позиций из очереди ручной
// проверки (web/onec_review.php), отмеченных галочками — при очереди в
// тысячи позиций кликать по одной непрактично. В отличие от
// web/onec_review_submit.php (одна позиция, можно поправить наименование)
// здесь позиции добавляются КАК ЕСТЬ: это инструмент для явно понятных
// случаев (например, "отклонить все найденные дубликаты"), а не замена
// одиночной проверки с правкой. Доступно только admin/mainadmin.

require __DIR__ . '/admin_guard.php';
require __DIR__ . '/config.php';

if (is_file(__DIR__ . '/data/.catalog-routing-deploying')) {
    http_response_code(503);
    header('Retry-After: 30');
    exit('Обновляется приём номенклатуры. Повторите действие через 30 секунд.');
}

function back_with(array $params): never {
    header('Location: onec_review.php?' . http_build_query($params));
    exit;
}

function back_with_error(string $message, int $page, string $q): never {
    back_with(['page' => $page, 'q' => $q, 'err' => $message]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: onec_review.php');
    exit;
}

$page = max(1, (int) ($_POST['page'] ?? 1));
$q = trim((string) ($_POST['q'] ?? ''));

if (empty($_SESSION['csrf']) || !hash_equals((string) $_SESSION['csrf'], (string) ($_POST['csrf'] ?? ''))) {
    back_with_error('Сессия истекла, обновите страницу и попробуйте снова.', $page, $q);
}

$action = (string) ($_POST['action'] ?? 'approve');
$catalog = (string) ($_POST['catalog'] ?? '');
if ($catalog !== '' && !in_array($catalog, ['ventilation', 'vk'], true)) {
    back_with_error('Некорректный раздел номенклатуры.', $page, $q);
}
if (!in_array($action, ['approve', 'reject'], true)) {
    back_with_error('Некорректное действие.', $page, $q);
}

$rawSelected = $_POST['selected'] ?? [];
if (!is_array($rawSelected) || !$rawSelected) {
    back_with_error('Не выбрано ни одной позиции.', $page, $q);
}

// Каждая галочка — "<токен>:<id>" одной строкой (см. onec_review.php).
// Токен — тот же формат, что генерирует 1c_intake.php
// (bin2hex(random_bytes(8))); id — целое число, индекс внутри файла
// очереди этого токена. Ни то, ни другое не должно попадать в путь к
// файлу непроверенным (см. download.php за тем же приёмом) — молча
// пропускаем некорректные значения, а не падаем на всей пачке.
$selections = [];
foreach ($rawSelected as $raw) {
    if (!is_string($raw) || !preg_match('/^([a-f0-9]{16}):(\d+)$/', $raw, $m)) {
        continue;
    }
    $selections[] = ['token' => $m[1], 'id' => (int) $m[2]];
}
if (!$selections) {
    back_with_error('Не выбрано ни одной корректной позиции.', $page, $q);
}

if ($action === 'approve' && !is_file(ONEC_NOMENCLATURE_FILE)) {
    back_with_error('Нет эталонного снимка базы номенклатуры для сравнения.', $page, $q);
}

if (!is_dir(OUTPUT_DIR) || !is_writable(OUTPUT_DIR)) {
    back_with_error('Папка для результатов недоступна на сервере.', $page, $q);
}

// Список выбранного может быть в тысячи строк — через файл, не argv (argv
// виден всем в `ps aux` на общем хостинге и всё равно ограничен по длине).
$selectionsPath = OUTPUT_DIR . '/bulk_selections_' . bin2hex(random_bytes(8)) . '.json';
if (file_put_contents($selectionsPath, json_encode($selections, JSON_UNESCAPED_UNICODE)) === false) {
    back_with_error('Не удалось сохранить список выбранных позиций на сервере.', $page, $q);
}

$cmdParts = [
    escapeshellarg(PYTHON_BIN),
    escapeshellarg(WEB_1C_REVIEW_BULK_SCRIPT),
    '--selections-file', escapeshellarg($selectionsPath),
    '--pending-dir', escapeshellarg(OUTPUT_DIR),
];
if ($action === 'reject') {
    $cmdParts[] = '--reject';
} else {
    if ($catalog !== '') {
        $cmdParts[] = '--catalog';
        $cmdParts[] = escapeshellarg($catalog);
    }
    $cmdParts[] = '--existing';
    $cmdParts[] = escapeshellarg(ONEC_NOMENCLATURE_FILE);
    if (is_file(DB_FILE)) {
        $cmdParts[] = '--db-file';
        $cmdParts[] = escapeshellarg(DB_FILE);
    }
}

$cmd = implode(' ', $cmdParts) . ' 2>&1';
$output = shell_exec($cmd);
@unlink($selectionsPath);

$verb = $action === 'reject' ? 'отклонить' : 'добавить';

if ($output === null || trim($output) === '') {
    back_with_error("Не удалось {$verb} выбранные позиции: команда не выполнилась (shell_exec "
        . 'недоступен на сервере, или путь PYTHON_BIN в config.php неверный).', $page, $q);
}

$result = json_decode($output, true);
if (!is_array($result) || empty($result['ok'])) {
    // Admin-only страница — показываем реальный вывод скрипта, как и на
    // onec_database.php/onec_whitespace_cleanup.php/onec_review_submit.php,
    // иначе причину не понять без доступа к серверу.
    $detail = is_array($result) ? (string) ($result['error'] ?? 'неизвестная ошибка') : trim($output);
    if (mb_strlen($detail, 'UTF-8') > 2000) {
        $detail = '…' . mb_substr($detail, -2000, null, 'UTF-8');
    }
    back_with_error("Не удалось {$verb} выбранные позиции: {$detail}", $page, $q);
}

$countKey = $action === 'reject' ? 'rejected' : 'promoted';
back_with([
    'page' => $page,
    'q' => $q,
    'bulk' => $action,
    'count' => (int) ($result[$countKey] ?? 0),
    'errCount' => count($result['errors'] ?? []),
]);
