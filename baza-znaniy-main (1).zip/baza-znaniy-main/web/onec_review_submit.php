<?php
declare(strict_types=1);

// Приём формы из web/onec_review.php — подтверждение ИЛИ отклонение одной
// позиции (action=approve|reject), доступно только admin/mainadmin (см.
// admin_guard.php). Запускает common/web_1c_review_submit_run.py
// СИНХРОННО (без nohup, в отличие от 1c_intake.php) — это одна позиция,
// не пачка, PHP успевает дождаться результата в рамках обычного запроса
// и сразу показать статус на onec_review.php (редирект с ?added=1,
// ?rejected=1 или ?err=...).

require __DIR__ . '/admin_guard.php';
require __DIR__ . '/config.php';

if (is_file(__DIR__ . '/data/.catalog-routing-deploying')) {
    http_response_code(503);
    header('Retry-After: 30');
    exit('Обновляется приём номенклатуры. Повторите действие через 30 секунд.');
}

// Страница очереди постранична (см. onec_review.php) — без возврата на ту
// же страницу администратор после каждого клика улетал бы на страницу 1
// и терял место в многотысячной очереди.
$page = max(1, (int) ($_POST['page'] ?? 1));

function back_with_error(string $message, int $page): never {
    header('Location: onec_review.php?page=' . $page . '&err=' . urlencode($message));
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: onec_review.php');
    exit;
}

if (empty($_SESSION['csrf']) || !hash_equals((string) $_SESSION['csrf'], (string) ($_POST['csrf'] ?? ''))) {
    back_with_error('Сессия истекла, обновите страницу и попробуйте снова.', $page);
}

$token = (string) ($_POST['token'] ?? '');
$id = (string) ($_POST['id'] ?? '');
$action = (string) ($_POST['action'] ?? 'approve');
$catalog = (string) ($_POST['catalog'] ?? '');
if ($catalog !== '' && !in_array($catalog, ['ventilation', 'vk'], true)) {
    back_with_error('Некорректный раздел номенклатуры.', $page);
}
$name = trim((string) ($_POST['name'] ?? ''));

if (!in_array($action, ['approve', 'reject'], true)) {
    back_with_error('Некорректное действие.', $page);
}

// Токен — ровно тот же формат, что генерирует 1c_intake.php
// (bin2hex(random_bytes(8))); id — целое число, индекс внутри файла
// очереди. Ни то, ни другое не должно попадать в путь к файлу
// непроверенным (см. download.php за тем же приёмом).
if (!preg_match('/^[a-f0-9]{16}$/', $token)) {
    back_with_error('Некорректный токен пачки.', $page);
}
if (!ctype_digit($id)) {
    back_with_error('Некорректный идентификатор позиции.', $page);
}
if ($action === 'approve' && $name === '') {
    back_with_error('Наименование не может быть пустым.', $page);
}

$pendingPath = OUTPUT_DIR . "/{$token}_1c_pending.json";
if (!is_file($pendingPath)) {
    back_with_error('Файл очереди этой пачки не найден на сервере.', $page);
}

$cmdParts = [
    escapeshellarg(PYTHON_BIN),
    escapeshellarg(WEB_1C_REVIEW_SUBMIT_SCRIPT),
    '--pending-file', escapeshellarg($pendingPath),
    '--id', escapeshellarg($id),
];

if ($action === 'reject') {
    $cmdParts[] = '--reject';
} else {
    if (!is_file(ONEC_NOMENCLATURE_FILE)) {
        back_with_error('Нет эталонного снимка базы номенклатуры для сравнения.', $page);
    }
    $cmdParts[] = '--name';
    $cmdParts[] = escapeshellarg($name);
    if ($catalog !== '') {
        $cmdParts[] = '--catalog';
        $cmdParts[] = escapeshellarg($catalog);
    }
    $cmdParts[] = '--existing';
    $cmdParts[] = escapeshellarg(ONEC_NOMENCLATURE_FILE);
    if (is_file(DB_FILE)) {
        $cmdParts[] = '--db-file';
        $cmdParts[] = escapeshellarg(DB_FILE);
    }
}

$cmd = implode(' ', $cmdParts) . ' 2>&1';
$output = shell_exec($cmd);
$verb = $action === 'reject' ? 'отклонить' : 'добавить';

if ($output === null || trim($output) === '') {
    back_with_error("Не удалось {$verb} позицию: команда не выполнилась (shell_exec недоступен на "
        . 'сервере, или путь PYTHON_BIN в config.php неверный).', $page);
}

$result = json_decode($output, true);
if (!is_array($result) || empty($result['ok'])) {
    // Admin-only страница — показываем реальный вывод скрипта (например,
    // traceback Python), как и на onec_database.php/onec_whitespace_
    // cleanup.php, иначе причину не понять без доступа к серверу.
    $detail = is_array($result) ? (string) ($result['error'] ?? 'неизвестная ошибка') : trim($output);
    if (mb_strlen($detail, 'UTF-8') > 2000) {
        $detail = '…' . mb_substr($detail, -2000, null, 'UTF-8');
    }
    back_with_error("Не удалось {$verb} позицию: {$detail}", $page);
}

$param = $action === 'reject' ? 'rejected=1' : 'added=1';
header('Location: onec_review.php?page=' . $page . '&' . $param);
