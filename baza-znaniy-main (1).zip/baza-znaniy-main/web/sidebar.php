<?php
declare(strict_types=1);

// Общий сайдбар — подключается на всех страницах после программ (VentSpec,
// Area, админка), чтобы навигация оставалась видимой при переходе в любой
// блок, а не только на главном экране (web/index.php).
//
// Требует $role/$isAdminTier в области видимости вызывающей страницы (или
// определяет их сама из $_SESSION, если их ещё нет) и users.php с
// is_admin_tier_role()/role_label().

if (!isset($isAdminTier)) {
    $role = (string) ($_SESSION['kb_role'] ?? '');
    $isAdminTier = is_admin_tier_role($role);
}

// Обновлённое оформление меню — отдельный файл (см. design.php); прежнее
// меню ниже не изменилось.
require_once __DIR__ . '/alfik.php';
require_once __DIR__ . '/clean_papper_access.php';
$kbCleanPapperAllowed = clean_papper_allowed((string) ($_SESSION['kb_user'] ?? ''));
require_once __DIR__ . '/design.php';
if (design_refresh()) {
    require __DIR__ . '/sidebar_refresh.php';
    return;
}

$__navCurrent = basename((string) ($_SERVER['SCRIPT_NAME'] ?? ''));
// Пункты модулей — только своего отдела (structure.php, kb_can_open_page).
require_once __DIR__ . '/structure_lib.php';
$__navVent = kb_can_open_page('ventspec.php');
$__navEquip = kb_can_open_page('equipment.php');
$__navFeedbackInbox = kb_can_open_page('admin_developer_feedback.php');

function nav_current_class(string $file, string $current): string {
    return $file === $current ? ' current' : '';
}

// Раздел с несколькими пунктами — выпадающий список (<details>). Открыт
// сразу, если текущая страница — один из его пунктов, иначе свёрнут.
function nav_group_open(array $files, string $current): string {
    return in_array($current, $files, true) ? ' open' : '';
}
?>
  <?php /* Страховка для страниц, где ui.js не подключён в <head>: тема и
           переключатель всё равно заработают (повторное подключение
           ничего не делает). */ ?>
  <script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
  <div class="sidebar">
    <div class="sidebar-brand">
      <svg class="mark" width="30" height="27" viewBox="0 0 1100.0 1002.58" aria-hidden="true" focusable="false">
        <path fill-rule="evenodd" d="M546.73,50.0 L439.33,243.12 L400.43,307.83 L376.33,355.34 L285.11,518.5 L258.26,561.88 L170.14,724.01 L171.51,727.45 L175.99,729.17 L642.08,728.83 L653.1,730.21 L659.64,734.34 L670.65,755.34 L671.0,761.19 L664.8,764.63 L632.79,764.97 L154.65,764.63 L145.35,768.07 L140.53,778.74 L143.63,782.87 L149.14,784.25 L678.92,783.22 L687.52,787.35 L693.72,795.61 L699.91,810.41 L699.23,817.3 L692.0,820.74 L124.01,820.4 L114.37,823.15 L108.18,835.89 L113.34,840.36 L707.14,839.67 L716.44,842.43 L725.04,852.41 L731.24,865.15 L730.9,872.03 L722.63,875.82 L92.0,875.82 L83.05,878.23 L77.88,889.93 L83.39,894.75 L741.57,894.41 L748.45,897.16 L758.78,911.27 L761.53,920.57 L760.15,926.42 L755.34,929.86 L59.29,930.55 L50.34,936.4 L50.0,947.07 L54.13,952.58 L711.96,950.17 L752.24,952.58 L761.53,949.83 L793.89,952.58 L796.64,945.01 L794.23,936.06 L566.35,528.83 L563.6,520.22 L564.63,510.93 L574.61,493.03 L582.53,490.28 L592.86,500.6 L838.3,940.53 L847.93,952.58 L857.92,952.58 L860.67,945.35 L857.92,936.06 L595.96,467.21 L595.96,453.1 L606.63,434.85 L613.51,432.1 L619.71,436.23 L899.57,937.78 L909.55,948.45 L920.22,948.11 L922.98,943.29 L921.94,938.12 L628.66,414.89 L626.25,405.59 L628.66,394.58 L638.3,379.43 L645.87,376.33 L652.75,381.15 L745.01,549.14 L767.73,585.97 L963.25,938.47 L975.65,952.58 L982.19,952.58 L987.69,943.98 L978.4,923.67 L929.86,841.05 L859.64,710.93 L842.43,683.73 L660.33,356.37 L658.61,345.35 L667.56,325.04 L671.69,320.91 L677.88,319.54 L685.11,325.04 L1027.62,940.19 L1038.3,952.58 L1046.56,952.58 L1050.0,945.7 L1049.66,940.19 L930.55,728.49 L857.92,593.55 L762.22,426.94 L684.42,282.36 L678.92,276.51 L675.13,277.19 L668.24,285.46 L437.26,698.88 L431.07,706.45 L424.87,709.21 L402.84,709.21 L397.33,706.11 L398.02,695.09 L409.38,672.72 L429.0,641.39 L484.77,536.75 L649.31,245.18 L652.75,233.82 L646.56,220.74 L640.36,223.49 L375.3,696.82 L368.07,706.11 L361.53,708.86 L339.16,709.21 L333.99,706.11 L333.3,697.5 L619.02,185.28 L621.77,174.96 L614.54,162.91 L608.0,166.01 L586.32,206.97 L566.01,239.33 L496.82,367.38 L308.18,703.36 L302.67,707.83 L276.16,709.21 L269.62,705.77 L271.0,694.41 L582.53,138.47 L589.41,117.81 L586.66,109.9 L581.84,105.77 L577.02,107.83 L514.37,222.46 L402.15,419.02 L244.49,703.7 L234.85,709.21 L214.2,709.21 L207.31,706.11 L206.97,696.13 L357.75,423.84 L372.89,400.43 L483.05,199.4 L548.8,86.83 L558.78,61.7 L552.93,50.69 Z M545.7,545.7 L550.52,545.35 L560.84,558.78 L600.09,630.38 L618.33,658.26 L637.26,693.72 L638.98,704.04 L636.23,707.83 L467.56,709.21 L461.36,705.42 L461.02,696.47 L467.9,681.33 Z"/>
      </svg>
      <div class="wordmark">
        <span class="co">Альфастрой</span>
        <span class="kb">База знаний</span>
      </div>
      <button type="button" class="sidebar-toggle" aria-expanded="false" aria-controls="sidebar-menu">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke-width="2" stroke-linecap="round" aria-hidden="true"><line x1="4" y1="7" x2="20" y2="7"/><line x1="4" y1="12" x2="20" y2="12"/><line x1="4" y1="17" x2="20" y2="17"/></svg>
        <span>Меню</span>
      </button>
    </div>

    <div class="sidebar-menu" id="sidebar-menu">

    <nav class="sidebar-nav">
      <?php if (kb_can_open_page('index.php')): ?>
      <a class="nav-item available<?= nav_current_class('index.php', $__navCurrent) ?>" href="index.php">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M3 10.5 12 3l9 7.5"/><path d="M5 9.5V20a1 1 0 0 0 1 1h4v-6h4v6h4a1 1 0 0 0 1-1V9.5"/></svg>
        <span>Главная</span>
      </a>
      <?php endif; ?>

      <?php if ($__navVent || $__navEquip): ?>
      <details class="nav-group"<?= nav_group_open(['ventspec.php', 'equipment.php'], $__navCurrent) ?>>
        <summary class="nav-group-label">Вентиляция</summary>
        <?php if ($__navVent): ?>
        <a class="nav-item available<?= nav_current_class('ventspec.php', $__navCurrent) ?>" href="ventspec.php">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="5" width="18" height="14" rx="3"/><line x1="6" y1="9" x2="18" y2="9"/><line x1="6" y1="12" x2="18" y2="12"/><line x1="6" y1="15" x2="18" y2="15"/></svg>
          <span>VentSpec</span>
        </a>
        <?php endif; ?>
        <?php if ($__navEquip): ?>
        <a class="nav-item available<?= nav_current_class('equipment.php', $__navCurrent) ?>" href="equipment.php">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3.2"/><path d="M12 4.2V6M12 18v1.8M4.2 12H6M18 12h1.8M6.5 6.5 7.8 7.8M16.2 16.2l1.3 1.3M17.5 6.5 16.2 7.8M7.8 16.2l-1.3 1.3"/></svg>
          <span>Оборудование</span>
        </a>
        <?php endif; ?>
      </details>
      <?php endif; ?>

      <?php if (kb_limited_department() === null): ?>
      <div class="nav-section">
        <div class="nav-section-label">Вода</div>
        <div class="nav-item soon">
          <span class="nav-item-label">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M12 3s7 7.5 7 12a7 7 0 0 1-14 0c0-4.5 7-12 7-12z"/></svg>
            <span class="label">WasserSpec</span>
          </span>
          <span class="nav-badge">скоро</span>
        </div>
      </div>

      <?php endif; ?>

      <?php if (kb_can_open_page('verrata.php')): ?>
      <a class="nav-item available<?= nav_current_class('verrata.php', $__navCurrent) . nav_current_class('verrata_status.php', $__navCurrent) ?>" href="verrata.php">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M8 3H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h3"/><path d="M16 3h3a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-3"/><path d="M9 8h2M9 12h4M9 16h2"/></svg>
        <span>Verrata</span>
      </a>
      <?php endif; ?>

      <?php if (kb_can_open_page('rv.php')): ?>
      <?php require_once __DIR__ . '/rv_lib.php'; $__rvQueue = rv_can_take() ? rv_my_queue_count((string) ($_SESSION['kb_user'] ?? '')) : 0; ?>
      <a class="nav-item available<?= nav_current_class('rv.php', $__navCurrent) . nav_current_class('rv_status.php', $__navCurrent) . nav_current_class('rv_registry.php', $__navCurrent) . nav_current_class('rv_responsibles.php', $__navCurrent) . nav_current_class('rv_smeta.php', $__navCurrent) ?>" href="rv.php">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h12l4 4v12H4z"/><path d="M16 4v4h4"/><line x1="8" y1="12" x2="16" y2="12"/><line x1="8" y1="16" x2="13" y2="16"/></svg>
        <span>РВ по ЛРВ</span>
        <?php if ($__rvQueue > 0): ?><span class="nav-badge is-count" title="РВ из 1С ждут вашей проверки"><?= $__rvQueue ?></span><?php endif; ?>
      </a>
      <?php endif; ?>

      <?php if (kb_can_open_page('tkp_customer.php')): ?>
      <a class="nav-item available<?= nav_current_class('tkp_customer.php', $__navCurrent) ?>" href="tkp_customer.php">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M3 5h8v14H3z"/><path d="M13 5h8v14h-8z"/><path d="M6 9h2M6 13h2M16 9h2M16 13h2"/></svg>
        <span>ТКП заказчика</span>
      </a>
      <?php endif; ?>

      <a class="nav-item available<?= nav_current_class('agent.php', $__navCurrent) ?>" href="agent.php">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M5 4h14a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2h-8l-5 4v-4H5a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2z"/><path d="M8 9h8M8 12.5h5"/></svg>
        <span>Ассистент</span>
      </a>

      <?php if (kb_can_open_page('area.php')): ?>
      <a class="nav-item available<?= nav_current_class('area.php', $__navCurrent) ?>" href="area.php">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg>
        <span>Area</span>
      </a>
      <?php endif; ?>

      <?php if (kb_can_open_page('docs.php')): ?>
      <a class="nav-item available<?= nav_current_class('docs.php', $__navCurrent) ?>" href="docs.php">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19.5V5a2 2 0 0 1 2-2h13v16H6a2 2 0 0 0-2 2.5z"/><path d="M4 19.5A2.5 2.5 0 0 0 6.5 22H19v-3"/><line x1="8" y1="8" x2="15" y2="8"/><line x1="8" y1="12" x2="13" y2="12"/></svg>
        <span>Документация</span>
      </a>
      <?php endif; ?>

      <a class="nav-item available<?= nav_current_class('developer_feedback.php', $__navCurrent) ?>" href="developer_feedback.php">
        <?= kb_icon('log', 18) ?><span>Обращения к разработчику</span>
      </a>

      <?php if ($isAdminTier || $__navFeedbackInbox): ?>
      <details class="nav-group"<?= nav_group_open(['admin_users.php', 'onec_intake.php', 'onec_review.php', 'onec_database.php', 'onec_whitespace_cleanup.php', 'agent_log.php', 'admin_developer_feedback.php', 'clean_papper.php'], $__navCurrent) ?>>
        <summary class="nav-group-label">Администрирование</summary>
        <?php if ($isAdminTier): ?>
        <a class="nav-item available<?= nav_current_class('admin_users.php', $__navCurrent) ?>" href="admin_users.php">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H7a4 4 0 0 0-4 4v2"/><circle cx="10" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
          <span>Пользователи</span>
        </a>
        <a class="nav-item available<?= nav_current_class('onec_intake.php', $__navCurrent) . nav_current_class('onec_review.php', $__navCurrent) ?>" href="onec_intake.php">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M21 8V5a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h6"/><path d="M7 8h6M7 12h4"/><path d="M16 15.5 21 20.5"/><circle cx="16.5" cy="15.5" r="3.5"/></svg>
          <span>Номенклатура от 1С</span>
        </a>
        <a class="nav-item available<?= nav_current_class('onec_database.php', $__navCurrent) ?>" href="onec_database.php">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><ellipse cx="12" cy="5" rx="8" ry="3"/><path d="M4 5v14c0 1.66 3.58 3 8 3s8-1.34 8-3V5"/><path d="M4 12c0 1.66 3.58 3 8 3s8-1.34 8-3"/></svg>
          <span>База</span>
        </a>
        <a class="nav-item available<?= nav_current_class('agent_log.php', $__navCurrent) ?>" href="agent_log.php">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/><path d="M8 8h8M8 12h5"/></svg>
          <span>Журнал ассистента</span>
        </a>
        <?php endif; ?>
        <?php if ($kbCleanPapperAllowed): ?>
        <a class="nav-item available<?= nav_current_class('clean_papper.php', $__navCurrent) ?>" href="clean_papper.php">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="2"/><path d="M7 9h10M7 13h6M7 17h4"/></svg>
          <span>Clean Papper</span>
        </a>
        <?php endif; ?>
        <?php if ($__navFeedbackInbox): ?>
        <a class="nav-item available<?= nav_current_class('admin_developer_feedback.php', $__navCurrent) ?>" href="admin_developer_feedback.php">
          <?= kb_icon('log', 18) ?><span>Обращения</span>
        </a>
        <?php endif; ?>
      </details>
      <?php endif; ?>
    </nav>

    <div class="sidebar-footer">
      <span><?= htmlspecialchars((string) ($_SESSION['kb_user'] ?? ''), ENT_QUOTES, 'UTF-8') ?> · <?= htmlspecialchars(role_label($role), ENT_QUOTES, 'UTF-8') ?></span>
      <button type="button" class="theme-toggle" role="switch" aria-checked="false" data-theme-toggle>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M20 14.5A8 8 0 0 1 9.5 4 8 8 0 1 0 20 14.5z"/></svg>
        <span>Тёмная тема</span>
        <span class="theme-switch" aria-hidden="true"></span>
      </button>
      <a href="logout.php">Выйти</a>
    </div>
    </div>
  </div>
  <script>
  // На узком экране меню свёрнуто под кнопку «Меню» (см. .sidebar.collapsible
  // в style.css). Класс ставит скрипт: без JS меню просто остаётся раскрытым.
  (function () {
    var sidebar = document.currentScript.previousElementSibling;
    var toggle = sidebar.querySelector('.sidebar-toggle');
    sidebar.classList.add('collapsible');
    toggle.addEventListener('click', function () {
      var open = sidebar.classList.toggle('open');
      toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
    });
  })();
  </script>
