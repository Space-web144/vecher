<?php
declare(strict_types=1);

// Указания для одной РВ (блок «Указания для этой РВ» на rv_status.php): ТЗ агенту — текст сметчика и/или файлы
// (смета, спецификация, ТЗ: PDF, Excel, Word, CSV, TXT, картинки), по которым агент пересобирает ТОЛЬКО эту РВ.
// Хранятся в <токен>_local.json и папке <токен>_local/ рядом с задачей; агент читает их при каждой привязке этой РВ
// (web_rv_run.local_input): при сохранении модель смотрит все строки с ТЗ и меняет работы, где ТЗ этого требует
// (запоминается в agent того же файла). В общий журнал замечаний и в общую память агента указания не попадают;
// при согласовании такой РВ в память идут только ручные исправления сметчика.
//
// POST (csrf, token): action=save — сохранить и пересобрать (text, files[] — новые файлы, remove[] — убрать прежние);
// action=clear — убрать указания и пересобрать как обычно. Согласование остаётся, только если РВ для 1С не изменилась.
// РВ, уже загруженную в 1С, не пересобираем. GET (token, file) — скачать приложенный файл.

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require_once __DIR__ . '/users.php';
require_once __DIR__ . '/lib.php';
require_once __DIR__ . '/rv_lib.php';

rv_guard();

$token = (string) ($_POST['token'] ?? $_GET['token'] ?? '');
if (!rv_token_valid($token)) {
    header('Location: rv.php');
    exit;
}
$back = 'rv_status.php?token=' . urlencode($token);
$go = static function (string $message) use ($back): never {
    header('Location: ' . $back . '&err=' . rawurlencode($message) . '#rv-local');
    exit;
};
$paths = rv_paths($token);
$job = rv_read_json($paths['job']);
if ($job === null || !rv_can_access($job)) {
    $go('Задача не найдена или принадлежит другому пользователю.');
}
$localPath = rv_local_path($token);
$localDir = rv_local_dir($token);
$current = rv_local_read($token);

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    // Скачать файл из указаний: только из списка этой РВ.
    $want = (string) ($_GET['file'] ?? '');
    foreach ($current['files'] ?? [] as $entry) {
        $path = $localDir . '/' . $entry['file'];
        if ($entry['file'] === $want && is_file($path)) {
            header('Content-Type: application/octet-stream');
            header("Content-Disposition: attachment; filename*=UTF-8''" . rawurlencode((string) $entry['name']));
            header('Content-Length: ' . (string) filesize($path));
            header('X-Content-Type-Options: nosniff');
            readfile($path);
            exit;
        }
    }
    http_response_code(404);
    exit('Файл не найден.');
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !hash_equals(rv_csrf(), (string) ($_POST['csrf'] ?? ''))) {
    $go('Форма устарела — обновите страницу и повторите.');
}
if (($job['mode'] ?? '') === 'audit') {
    $go('Для сверки РВ указания не задаются.');
}
if (rv_onec_loaded($job)) {
    $go('РВ уже загружена в 1С — пересборка туда не попадёт, а повторная загрузка задвоила бы привязки. '
        . 'Отправьте смету из 1С заново и задайте указания у новой РВ.');
}
[$state] = rv_state($token, $job);
if ($state !== 'done' || !is_file($paths['work']) || !is_file($paths['json'])) {
    $go($state !== 'done' ? 'РВ сейчас строится — задать указания можно, когда она будет готова.'
        : 'Разметка или результат этой РВ не найдены на сервере — пересобрать нельзя, загрузите ЛРВ заново.');
}
$status = rv_read_json($paths['status']) ?? [];
$me = (string) ($_SESSION['kb_user'] ?? '');
$now = time();
$action = (string) ($_POST['action'] ?? '');

if ($action === 'clear') {
    foreach (glob($localDir . '/*') ?: [] as $path) {
        @unlink($path);
    }
    @rmdir($localDir);
    @unlink($localPath);
    unset($job['local']);
    $stage = 'убираю указания и пересобираю РВ…';
} elseif ($action === 'save') {
    $text = trim(str_replace("\r\n", "\n", (string) ($_POST['text'] ?? '')));
    $text = mb_substr($text, 0, RV_LOCAL_MAX_CHARS);
    $remove = array_map('strval', is_array($_POST['remove'] ?? null) ? $_POST['remove'] : []);
    $files = array_values(array_filter($current['files'] ?? [], static fn (array $f): bool => !in_array($f['file'], $remove, true)));

    // Новые файлы: проверить все, потом переносить.
    $uploads = $_FILES['files'] ?? null;
    $new = [];
    if (is_array($uploads) && is_array($uploads['name'] ?? null)) {
        foreach ($uploads['name'] as $i => $originalName) {
            $name = mb_substr(trim(str_replace(["\0", '/', '\\'], '', (string) $originalName)), 0, 200);
            $error = (int) ($uploads['error'][$i] ?? UPLOAD_ERR_NO_FILE);
            if ($error === UPLOAD_ERR_NO_FILE) {
                continue;
            }
            if ($error === UPLOAD_ERR_INI_SIZE || $error === UPLOAD_ERR_FORM_SIZE
                || (int) ($uploads['size'][$i] ?? 0) > RV_LOCAL_MAX_BYTES) {
                $go('Файл «' . $name . '» больше ' . megabytes(RV_LOCAL_MAX_BYTES) . ' МБ (или больше, чем принимает сервер).');
            }
            $tmp = (string) ($uploads['tmp_name'][$i] ?? '');
            if ($error !== UPLOAD_ERR_OK || !is_uploaded_file($tmp)) {
                $go('Файл «' . $name . '» не загрузился — прикрепите его снова.');
            }
            $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            if (!in_array($ext, RV_LOCAL_TYPES, true)) {
                $go('Файлы .' . ($ext !== '' ? $ext : '(без расширения)') . ' агент не читает — «' . $name . '». Подходят: '
                    . implode(', ', RV_LOCAL_TYPES) . ' (.doc — сохраните как .docx).');
            }
            $new[] = ['name' => $name, 'tmp' => $tmp, 'ext' => $ext, 'size' => (int) ($uploads['size'][$i] ?? 0)];
        }
    }
    if (count($files) + count($new) > RV_LOCAL_MAX_FILES) {
        $go('Файлов в указаниях — не больше ' . RV_LOCAL_MAX_FILES . '. Уберите лишние.');
    }
    if ($text === '' && !$files && !$new) {
        $go('Напишите задание агенту или приложите файл.');
    }
    if ($new && !is_dir($localDir) && !mkdir($localDir, 0775, true) && !is_dir($localDir)) {
        $go('Не удалось создать папку для файлов на сервере.');
    }
    foreach ($new as $file) {
        $stored = bin2hex(random_bytes(6)) . '.' . $file['ext'];
        if (!move_uploaded_file($file['tmp'], $localDir . '/' . $stored)) {
            $go('Не удалось сохранить файл «' . $file['name'] . '» на сервере.');
        }
        $files[] = ['name' => $file['name'], 'file' => $stored, 'size' => $file['size'], 'by' => $me, 'at' => $now];
    }
    foreach ($current['files'] ?? [] as $entry) {
        if (in_array($entry['file'], $remove, true)) {
            @unlink($localDir . '/' . $entry['file']);
        }
    }
    // agent не переносим: указания изменились — модель посмотрит РВ заново. fixes — решения сметчика, остаются.
    $local = ['text' => $text, 'files' => $files, 'by' => $me, 'at' => $now,
              'fixes' => is_array($current['fixes'] ?? null) ? $current['fixes'] : new stdClass()];
    if (file_put_contents($localPath, json_encode($local, JSON_UNESCAPED_UNICODE)) === false) {
        $go('Не удалось сохранить указания на сервере.');
    }
    $job['local'] = ['by' => $me, 'at' => $now, 'text' => mb_substr($text, 0, 300),
                     'files' => array_map(static fn (array $f): string => (string) $f['name'], $files)];
    $stage = 'пересобираю РВ по указаниям: модель смотрит строки с вашим ТЗ…';
} else {
    $go('Неизвестное действие.');
}

$job['rebuilt'] = ['by' => $me, 'at' => $now, 'onec_loaded' => false, 'local' => $action === 'save'];
file_put_contents($paths['job'], json_encode($job, JSON_UNESCAPED_UNICODE));
file_put_contents($paths['status'], json_encode([
    'state' => 'running',
    'stage' => $stage,
    'started' => $now,
    'updated' => $now,
    'launched' => false,
    'feedback' => is_array($status['feedback'] ?? null) ? $status['feedback'] : null,
], JSON_UNESCAPED_UNICODE));

// С проверкой моделью (без --no-review): по свежим указаниям модель смотрит все строки этой РВ.
rv_launch(['--phase', 'bind', '--status-file', $paths['status'], '--work-file', $paths['work'],
           '--out-xlsx', $paths['xlsx'], '--out-json', $paths['json'],
           '--credentials', ANTHROPIC_CREDENTIALS_FILE, '--learning-file', RV_LEARNING_FILE, '--notes-file', RV_NOTES_FILE,
           '--rebuild', '--user', $me, '--source-name', (string) ($job['source_name'] ?? '')]);

header('Location: ' . $back);
exit;
