<?php
declare(strict_types=1);

// Откат согласования РВ (кнопка на rv_status.php): например, РВ согласовали для пробы.
// Проверка инженера удаляется, РВ снова «готова, не согласована», а агент запускается заново
// с --forget-learning: решения этой РВ убираются из памяти (RV_LEARNING_FILE) — где до них
// было другое решение, оно возвращается, — и РВ пересобирается без них (проверка моделью
// переносится прежняя). Старые записи памяти, сделанные до того, как запись стала помнить номер
// задачи, узнаются по имени файла ЛРВ (source_name).
// Откатить может руководитель (rv_can_assign) или тот, кто согласовал. Данные, уже загруженные
// в 1С, не меняются.

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require_once __DIR__ . '/users.php';
require_once __DIR__ . '/lib.php';
require_once __DIR__ . '/rv_lib.php';

rv_guard();

$token = (string) ($_POST['token'] ?? '');
if (!rv_token_valid($token)) {
    header('Location: rv.php');
    exit;
}
$back = 'rv_status.php?token=' . urlencode($token);
$go = static function (string $message) use ($back): never {
    header('Location: ' . $back . '&err=' . rawurlencode($message));
    exit;
};
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !hash_equals(rv_csrf(), (string) ($_POST['csrf'] ?? ''))) {
    $go('Форма устарела — обновите страницу и повторите.');
}
$paths = rv_paths($token);
$job = rv_read_json($paths['job']);
if ($job === null || !rv_can_access($job)) {
    $go('Задача не найдена или принадлежит другому пользователю.');
}
[$state, $status] = rv_state($token, $job);
if ($state !== 'done') {
    $go('РВ сейчас строится — откатить согласование можно, когда она будет готова.');
}
$feedback = is_array($status['feedback'] ?? null) ? $status['feedback'] : null;
if (empty($job['feedback']) && $feedback === null && !is_file($paths['feedback'])) {
    $go('Эту РВ не согласовывали — откатывать нечего.');
}
if (rv_onec_loaded($job)) {
    $go('РВ уже загружена в 1С — согласование не откатывается: изменения вносите в 1С или новой загрузкой.');
}
$me = (string) ($_SESSION['kb_user'] ?? '');
$approver = (string) ($feedback['user'] ?? '');
if (!rv_can_assign() && ($approver === '' || $approver !== $me)) {
    $go('Откатить согласование может руководитель или тот, кто согласовал РВ.');
}

if (is_file($paths['feedback']) && !@unlink($paths['feedback'])) {
    $go('Не удалось удалить проверку на сервере.');
}
$now = time();
unset($job['feedback'], $job['audit_decisions']);      // у сверки РВ из 1С откатываются и решения «кто прав»
$job['rollback'] = ['by' => $me, 'at' => $now, 'approved_by' => $approver];
file_put_contents($paths['job'], json_encode($job, JSON_UNESCAPED_UNICODE));
file_put_contents($paths['status'], json_encode([
    'state' => 'running',
    'stage' => 'откатываю согласование: убираю решения этой РВ из памяти агента и строю РВ заново…',
    'started' => $now,
    'updated' => $now,
    'launched' => false,
], JSON_UNESCAPED_UNICODE));

rv_launch(['--phase', 'bind', '--status-file', $paths['status'], '--work-file', $paths['work'],
           '--out-xlsx', $paths['xlsx'], '--out-json', $paths['json'],
           '--credentials', ANTHROPIC_CREDENTIALS_FILE, '--learning-file', RV_LEARNING_FILE,
           '--forget-learning', '--no-review', '--user', $me,
           '--source-name', (string) ($job['source_name'] ?? '')]);

header('Location: ' . $back);
exit;
