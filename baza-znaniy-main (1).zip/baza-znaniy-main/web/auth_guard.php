<?php
declare(strict_types=1);

// Подключается первой строкой в каждой защищённой странице
// (index.php/ventspec.php/process.php/process_pdf.php/status.php/download.php).
// Если сессии нет — редирект на login.php с адресом возврата; сам вход и
// проверка пароля — там же, в login.php. Вошедшего пользователя пускает
// только на страницы модулей своего отдела и общие (kb_guard_page).

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

if (empty($_SESSION['kb_user'])) {
    $next = $_SERVER['REQUEST_URI'] ?? '';
    $target = 'login.php';
    if ($next !== '' && $next !== '/' && strpos($next, 'login.php') === false) {
        $target .= '?next=' . urlencode($next);
    }
    header('Location: ' . $target);
    exit;
}

// Модули — по отделам (structure.php, 'departments'): страница модуля чужого отдела не открывается
// и по прямой ссылке. config.php подключается повторно без вреда (сам проверяет, загружен ли).
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/structure_lib.php';
kb_guard_page();
