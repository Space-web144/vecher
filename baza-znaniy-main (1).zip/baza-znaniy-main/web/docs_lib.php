<?php
declare(strict_types=1);

// Хранилище библиотеки документов (docs.php — список и загрузка,
// doc_file.php — отдача файла). Сами файлы — DOCS_DIR/<file>.<расширение>,
// где file — случайные 16 hex-символов (как токены в process.php), а
// исходное имя, название и категория хранятся только в DOCS_DIR/docs.json:
// так на диск никогда не попадает имя файла от пользователя.
//
// У документа постоянный id (на него ведут ссылки) и отдельный id текущего
// файла: при загрузке новой редакции меняется только file, а прежний файл
// уходит в versions — ссылка на документ всегда отдаёт актуальную редакцию.
// Записи, сохранённые до появления редакций, без поля file: у них id файла
// совпадает с id документа.

const DOC_TYPES = [
    'pdf'  => ['mime' => 'application/pdf', 'label' => 'PDF', 'inline' => true],
    'doc'  => ['mime' => 'application/msword', 'label' => 'Word', 'inline' => false],
    'docx' => ['mime' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document', 'label' => 'Word', 'inline' => false],
    'xls'  => ['mime' => 'application/vnd.ms-excel', 'label' => 'Excel', 'inline' => false],
    'xlsx' => ['mime' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'label' => 'Excel', 'inline' => false],
    'ppt'  => ['mime' => 'application/vnd.ms-powerpoint', 'label' => 'PowerPoint', 'inline' => false],
    'pptx' => ['mime' => 'application/vnd.openxmlformats-officedocument.presentationml.presentation', 'label' => 'PowerPoint', 'inline' => false],
    'dwg'  => ['mime' => 'application/acad', 'label' => 'DWG', 'inline' => false],
    'txt'  => ['mime' => 'text/plain; charset=utf-8', 'label' => 'Текст', 'inline' => false],
    'rtf'  => ['mime' => 'application/rtf', 'label' => 'RTF', 'inline' => false],
    'zip'  => ['mime' => 'application/zip', 'label' => 'Архив', 'inline' => false],
    'rar'  => ['mime' => 'application/vnd.rar', 'label' => 'Архив', 'inline' => false],
    '7z'   => ['mime' => 'application/x-7z-compressed', 'label' => 'Архив', 'inline' => false],
    'jpg'  => ['mime' => 'image/jpeg', 'label' => 'Изображение', 'inline' => true],
    'jpeg' => ['mime' => 'image/jpeg', 'label' => 'Изображение', 'inline' => true],
    'png'  => ['mime' => 'image/png', 'label' => 'Изображение', 'inline' => true],
];

function docs_index_file(): string
{
    return DOCS_DIR . '/docs.json';
}

function doc_id_valid(string $id): bool
{
    return (bool) preg_match('/^[a-f0-9]{16}$/', $id);
}

function doc_file_path(string $fileId, string $ext): string
{
    return DOCS_DIR . '/' . $fileId . '.' . $ext;
}

// Файл текущей редакции документа.
function doc_path(array $doc): string
{
    return doc_file_path($doc['file'], $doc['ext']);
}

function normalize_doc_file(array $f): ?array
{
    $file = (string) ($f['file'] ?? '');
    $ext = (string) ($f['ext'] ?? '');
    if (!doc_id_valid($file) || !isset(DOC_TYPES[$ext])) {
        return null;
    }
    return [
        'file' => $file,
        'ext' => $ext,
        'original_name' => (string) ($f['original_name'] ?? ''),
        'size' => (int) ($f['size'] ?? 0),
        'uploaded_at' => (int) ($f['uploaded_at'] ?? 0),
        'uploaded_by' => (string) ($f['uploaded_by'] ?? ''),
    ];
}

// Порядок вывода — по категориям (по алфавиту, «без категории» в конце),
// внутри категории — по названию; цифры сравниваются как числа, чтобы
// «СП 7» шёл раньше «СП 60».
function doc_sort_cmp(array $a, array $b): int
{
    if (($a['category'] === '') !== ($b['category'] === '')) {
        return $a['category'] === '' ? 1 : -1;
    }
    return strnatcasecmp($a['category'], $b['category'])
        ?: strnatcasecmp($a['title'], $b['title']);
}

function load_docs(): array
{
    $file = docs_index_file();
    if (!is_file($file)) {
        return [];
    }
    $raw = file_get_contents($file);
    $data = $raw !== false ? json_decode($raw, true) : null;
    if (!is_array($data)) {
        return [];
    }
    $out = [];
    foreach ($data as $d) {
        if (!is_array($d) || !doc_id_valid((string) ($d['id'] ?? ''))) {
            continue;
        }
        $current = normalize_doc_file(['file' => $d['file'] ?? $d['id']] + $d);
        if ($current === null) {
            continue;
        }
        $versions = [];
        foreach ((array) ($d['versions'] ?? []) as $v) {
            if (is_array($v) && ($v = normalize_doc_file($v)) !== null) {
                $versions[] = $v;
            }
        }
        // Новые редакции сверху.
        usort($versions, fn($x, $y) => $y['uploaded_at'] <=> $x['uploaded_at']);
        $out[] = $current + [
            'id' => (string) $d['id'],
            'title' => (string) ($d['title'] ?? ''),
            'category' => (string) ($d['category'] ?? ''),
            'description' => (string) ($d['description'] ?? ''),
            'created_at' => (int) ($d['created_at'] ?? $current['uploaded_at']),
            'versions' => $versions,
        ];
    }
    usort($out, 'doc_sort_cmp');
    return $out;
}

function save_docs(array $docs): void
{
    $file = docs_index_file();
    $tmp = $file . '.tmp';
    $json = json_encode(array_values($docs), JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    if ($json === false || file_put_contents($tmp, $json, LOCK_EX) === false) {
        throw new RuntimeException('Не удалось записать список документов.');
    }
    if (!rename($tmp, $file)) {
        @unlink($tmp);
        throw new RuntimeException('Не удалось сохранить список документов.');
    }
}

// Изменение списка под эксклюзивной блокировкой — два администратора,
// одновременно загружающие файлы, иначе перезатёрли бы записи друг друга.
function update_docs(callable $fn): void
{
    if (!is_dir(DOCS_DIR) && !mkdir(DOCS_DIR, 0775, true) && !is_dir(DOCS_DIR)) {
        throw new RuntimeException('Не удалось создать папку документов.');
    }
    $lock = fopen(DOCS_DIR . '/docs.lock', 'c');
    if ($lock === false || !flock($lock, LOCK_EX)) {
        throw new RuntimeException('Не удалось заблокировать список документов.');
    }
    try {
        save_docs($fn(load_docs()));
    } finally {
        flock($lock, LOCK_UN);
        fclose($lock);
    }
}

// Документы, сгруппированные по категориям в порядке вывода:
// ['категория' => [документ, ...]], «без категории» — ключ ''.
function group_docs(array $docs): array
{
    $groups = [];
    foreach ($docs as $d) {
        $groups[$d['category']][] = $d;
    }
    return $groups;
}

function find_doc(array $docs, string $id): ?array
{
    foreach ($docs as $d) {
        if (hash_equals($d['id'], $id)) {
            return $d;
        }
    }
    return null;
}

// $_FILES['поле'] при <input multiple name="поле[]"> приходит
// «вывернутым» (name/tmp_name/... — массивы) — приводим к списку файлов.
function uploaded_files_list(?array $field): array
{
    if (!$field || !isset($field['name'])) {
        return [];
    }
    // Пустое поле файла тоже приходит — с кодом UPLOAD_ERR_NO_FILE.
    $list = [];
    if (!is_array($field['name'])) {
        $list = [$field];
    } else {
        foreach (array_keys($field['name']) as $i) {
            $list[] = [
                'name' => $field['name'][$i],
                'tmp_name' => $field['tmp_name'][$i],
                'error' => $field['error'][$i],
                'size' => $field['size'][$i],
            ];
        }
    }
    return array_values(array_filter($list, fn($f) => (int) $f['error'] !== UPLOAD_ERR_NO_FILE));
}

// Проверяет один загруженный файл и сохраняет его под новым случайным id.
// Возвращает описание файла для docs.json или бросает RuntimeException с
// понятным пользователю текстом (с именем файла — при пакетной загрузке
// иначе непонятно, какой из них не прошёл).
function store_uploaded_doc_file(array $upload, string $uploadedBy): array
{
    $origName = trim(preg_replace('/[\x00-\x1F\x7F]+/u', ' ', basename((string) $upload['name'])) ?? '');
    $origName = mb_substr($origName, 0, 200);
    $ext = strtolower(pathinfo($origName, PATHINFO_EXTENSION));
    $label = $origName !== '' ? "«{$origName}»: " : '';
    $err = (int) $upload['error'];

    if ($err === UPLOAD_ERR_INI_SIZE || $err === UPLOAD_ERR_FORM_SIZE) {
        throw new RuntimeException($label . 'файл слишком большой для настроек сервера (upload_max_filesize).');
    }
    if ($err !== UPLOAD_ERR_OK || !is_uploaded_file((string) $upload['tmp_name'])) {
        throw new RuntimeException($label . 'файл не загрузился, попробуйте ещё раз.');
    }
    if (!isset(DOC_TYPES[$ext])) {
        throw new RuntimeException($label . 'этот тип файла не поддерживается. Допустимы: ' . implode(', ', array_keys(DOC_TYPES)) . '.');
    }
    if ((int) $upload['size'] > MAX_DOC_UPLOAD_BYTES) {
        throw new RuntimeException($label . 'файл слишком большой (максимум ' . intdiv(MAX_DOC_UPLOAD_BYTES, 1024 * 1024) . ' МБ).');
    }
    if (!is_dir(DOCS_DIR) && !mkdir(DOCS_DIR, 0775, true) && !is_dir(DOCS_DIR)) {
        throw new RuntimeException('Не удалось создать папку документов.');
    }
    $file = [
        'file' => bin2hex(random_bytes(8)),
        'ext' => $ext,
        'original_name' => $origName,
        'size' => (int) $upload['size'],
        'uploaded_at' => time(),
        'uploaded_by' => $uploadedBy,
    ];
    if (!move_uploaded_file((string) $upload['tmp_name'], doc_file_path($file['file'], $ext))) {
        throw new RuntimeException($label . 'не удалось сохранить файл на сервере.');
    }
    return $file;
}

function format_size(int $bytes): string
{
    if ($bytes >= 1024 * 1024) {
        return number_format($bytes / (1024 * 1024), 1, ',', ' ') . ' МБ';
    }
    return max(1, (int) round($bytes / 1024)) . ' КБ';
}

// Реальный предел загрузки: меньшее из MAX_DOC_UPLOAD_BYTES и настроек PHP
// хостинга (upload_max_filesize/post_max_size) — показываем его в форме,
// чтобы администратор не упирался в ограничение сервера вслепую.
function ini_bytes(string $value): int
{
    $value = trim($value);
    $num = (int) $value;
    switch (strtolower(substr($value, -1))) {
        case 'g': return $num * 1024 * 1024 * 1024;
        case 'm': return $num * 1024 * 1024;
        case 'k': return $num * 1024;
    }
    return $num;
}

function effective_doc_upload_limit(): int
{
    $limits = [MAX_DOC_UPLOAD_BYTES];
    foreach (['upload_max_filesize', 'post_max_size'] as $key) {
        $bytes = ini_bytes((string) ini_get($key));
        if ($bytes > 0) {
            $limits[] = $bytes;
        }
    }
    return min($limits);
}
