<?php
declare(strict_types=1);

// Приём ЛРВ и запуск первой фазы агента РВ (чтение и разметка систем,
// program-c/web_rv_run.py --phase mark). Вторую фазу — привязку — запускает
// rv_confirm.php после того, как инженер подтвердит разметку.
// Карточка задачи и статус пишутся до запуска процесса: страница статуса
// по ним понимает, что задача поставлена, даже если процесс умер на старте.

require __DIR__ . '/auth_guard.php';
require __DIR__ . '/config.php';
require_once __DIR__ . '/users.php';
require_once __DIR__ . '/lib.php';
require_once __DIR__ . '/rv_lib.php';

rv_guard();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    rv_fail('Ожидался POST-запрос.', 405);
}

$contentLength = (int) ($_SERVER['CONTENT_LENGTH'] ?? 0);
$postLimit = ini_bytes('post_max_size');
if ($contentLength > 0 && $postLimit > 0 && $contentLength > $postLimit) {
    rv_fail('Файл весит ' . megabytes($contentLength) . ' МБ — больше, чем сервер принимает за раз ('
        . megabytes($postLimit) . ' МБ).');
}

$section = (string) ($_POST['section'] ?? 'авто');
if ($section !== 'авто' && !in_array($section, RV_SECTIONS, true)) {
    rv_fail('Не выбран раздел.');
}
$objectType = (string) ($_POST['object_type'] ?? 'жилой');
if (!array_key_exists($objectType, RV_OBJECT_TYPES)) {
    rv_fail('Неизвестный тип объекта.');
}
$defaultSystem = trim((string) ($_POST['default_system'] ?? ''));
if ($defaultSystem !== '' && rv_system_split($defaultSystem) === null) {
    rv_fail('Система для строк без группы выбрана неверно.');
}

$upload = $_FILES['lrv_file'] ?? null;
if (!is_array($upload) || ($upload['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
    $error = (int) ($upload['error'] ?? UPLOAD_ERR_NO_FILE);
    if (in_array($error, [UPLOAD_ERR_INI_SIZE, UPLOAD_ERR_FORM_SIZE], true)) {
        rv_fail('Файл больше, чем принимает сервер.');
    }
    rv_fail('Файл ЛРВ не получен — выберите файл и повторите.');
}
if ((int) $upload['size'] > RV_MAX_UPLOAD_BYTES) {
    rv_fail('Файл весит ' . megabytes((int) $upload['size']) . ' МБ — предел ' . megabytes(RV_MAX_UPLOAD_BYTES) . ' МБ.');
}
$originalName = (string) ($upload['name'] ?? 'ЛРВ');
$ext = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
if (!in_array($ext, ['xlsx', 'xlsm', 'xls', 'csv'], true)) {
    rv_fail('Подходят файлы .xlsx, .xls или .csv.');
}
if (!is_uploaded_file((string) $upload['tmp_name'])) {
    rv_fail('Файл не загружен.', 400);
}

foreach ([RV_UPLOAD_DIR, RV_OUTPUT_DIR] as $dir) {
    if (!is_dir($dir) && !mkdir($dir, 0775, true) && !is_dir($dir)) {
        rv_fail('Не удалось создать рабочую папку на сервере.', 500);
    }
}

$token = bin2hex(random_bytes(8));
$inputPath = RV_UPLOAD_DIR . '/' . $token . '.' . $ext;
if (!move_uploaded_file((string) $upload['tmp_name'], $inputPath)) {
    rv_fail('Не удалось сохранить загруженный файл.', 500);
}

$paths = rv_paths($token);
$now = time();
$job = [
    'token' => $token,
    'user' => (string) ($_SESSION['kb_user'] ?? ''),
    'section' => $section,
    'object_type' => $objectType,
    'default_system' => $defaultSystem,
    'source_name' => sanitize_display_base(pathinfo($originalName, PATHINFO_FILENAME)) . '.' . $ext,
    'created' => $now,
];
file_put_contents($paths['job'], json_encode($job, JSON_UNESCAPED_UNICODE));
file_put_contents($paths['status'], json_encode([
    'state' => 'running',
    'stage' => 'задача поставлена…',
    'started' => $now,
    'updated' => $now,
    // Признак «писал PHP»: процесс перепишет статус своим и этого ключа не оставит.
    'launched' => false,
], JSON_UNESCAPED_UNICODE));

// Пути книги и JSON — сразу: если подтверждать нечего (система выбрана при загрузке или вся есть в
// файле), агент строит РВ без остановки на странице «Проверьте системы».
$args = ['--phase', 'mark', '--status-file', $paths['status'], '--work-file', $paths['work'],
         '--out-xlsx', $paths['xlsx'], '--out-json', $paths['json'],
         '--section', $section, '--object-type', $objectType, '--source-name', $job['source_name'],
         '--credentials', ANTHROPIC_CREDENTIALS_FILE, '--learning-file', RV_LEARNING_FILE, '--notes-file', RV_NOTES_FILE];
if ($defaultSystem !== '') {
    $args[] = '--default-system';
    $args[] = $defaultSystem;
}
$args[] = '--';
$args[] = $inputPath;
rv_launch($args);

header('Location: rv_status.php?token=' . urlencode($token));
exit;
