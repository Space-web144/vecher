# -*- coding: utf-8 -*-
"""Вложения чата «Ассистент»: из файла пользователя — то, что можно отдать
модели через Files API (см. common/web_agent_chat.py).

Модель напрямую читает PDF, простой текст и картинки (JPEG, PNG, GIF,
WebP). Остальное приводим к ним здесь же, на сервере:

* PDF до PDF_DIRECT_MAX_BYTES уходит как есть. Больше — не влезет в
  запрос (предел API — 32 МБ на запрос, и большие PDF, по документации,
  срываются даже через Files API): страницы перерисовываются картинками
  того размера, который модель всё равно видит (длинная сторона
  RASTER_LONG_SIDE), а текст страниц идёт рядом отдельным документом —
  в картинке он остался бы только «на глаз».
  PDF-сканы без текста и восстановленные MuPDF документы также
  пересобираются в изображения страниц даже при небольшом размере.
* Excel (.xlsx) и Word (.docx) — в текст: листы и строки таблицы, абзацы
  и таблицы документа.
* Картинка больше IMAGE_DIRECT_MAX_BYTES — уменьшается до того же размера.

Объём для модели оценивается здесь же (estimate_* — в токенах): большой
альбом это сотни тысяч токенов на КАЖДЫЙ вопрос в чате, и чат не должен
незаметно перерасти окно модели.

Кроме того, каждый файл в исходном виде уходит в контейнер исполнения
кода (блок container_upload, см. common/web_agent_chat.py): там модель
открывает его кодом — считает по таблице, достаёт таблицы из PDF,
собирает из него новый файл. Файлы, которые модель напрямую не читает
(старые .xls и .doc, PowerPoint, архивы, JSON, XML…), доступны ТОЛЬКО
так — prepare для них возвращает пустой список частей.

Код работает на сервере с PyMuPDF 1.24.11 и Python 3.8.
"""
import os
import re
import zipfile
import xml.etree.ElementTree as ET

# PDF больше этого перерисовывается картинками (см. шапку).
PDF_DIRECT_MAX_BYTES = 30 * 1024 * 1024
# Предел API — 600 страниц на запрос; на один файл берём с запасом.
PDF_MAX_PAGES = 500
# Модель видит страницу картинкой с длинной стороной около 1568 px:
# рисовать крупнее — платить за размер файла, а не за качество.
RASTER_LONG_SIDE = 1568
RASTER_JPEG_QUALITY = 70

# Картинка больше — уменьшается (предел API на картинку — 5 МБ и 8000 px).
IMAGE_DIRECT_MAX_BYTES = 5 * 1024 * 1024

# Текст сверх этого — не вопрос к модели, а выгрузка базы целиком.
TEXT_MAX_CHARS = 1500000

# Оценка объёма для модели. Страница PDF — картинка (~2300 токенов при
# 1568 px) плюс её текст; для кириллицы токен — около 2,5 знака.
TOKENS_PER_PAGE_IMAGE = 2400
TOKENS_PER_IMAGE = 1600
CHARS_PER_TOKEN = 2.5

IMAGE_MIME = {"png": "image/png", "jpg": "image/jpeg", "jpeg": "image/jpeg",
              "gif": "image/gif", "webp": "image/webp"}
TEXT_EXT = ("txt", "csv", "md")
TABLE_EXT = ("xlsx", "xlsm")
WORD_EXT = ("docx",)
DIRECT_EXT = ("pdf",) + tuple(IMAGE_MIME) + TEXT_EXT + TABLE_EXT + WORD_EXT
# Только для кода в контейнере: модель открывает их библиотеками Python
# (xlrd, python-pptx, zipfile/7z, json, xml…). Должен совпадать с
# AGENT_FILE_TYPES в web/config.php (вместе с DIRECT_EXT).
CONTAINER_EXT = ("xls", "doc", "rtf", "odt", "ods", "pptx", "ppt", "tsv", "json", "xml",
                 "html", "htm", "dxf", "bmp", "tif", "tiff", "zip", "rar", "7z")
ALLOWED_EXT = DIRECT_EXT + CONTAINER_EXT

# Что сказать модели о файле, который она видит только из кода.
CONTAINER_NOTES = {
    "xls": "старый формат Excel — открывай кодом (pandas/xlrd)",
    "doc": "старый формат Word — готовой библиотеки для него в контейнере нет; попробуй "
           "достать текст кодом, а если не выйдет — попроси сохранить файл как .docx или PDF",
    "rtf": "RTF — текст с разметкой, читай кодом",
    "pptx": "презентация — открывай кодом (python-pptx)",
    "ppt": "старый формат PowerPoint — готовой библиотеки нет; если текст не достаётся, "
           "попроси сохранить как .pptx или PDF",
}

MIME_BY_EXT = {
    "pdf": "application/pdf", "txt": "text/plain", "csv": "text/csv", "md": "text/markdown",
    "tsv": "text/tab-separated-values", "json": "application/json", "xml": "application/xml",
    "html": "text/html", "htm": "text/html", "rtf": "application/rtf",
    "xlsx": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "xlsm": "application/vnd.ms-excel.sheet.macroEnabled.12",
    "xls": "application/vnd.ms-excel",
    "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "doc": "application/msword",
    "pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    "ppt": "application/vnd.ms-powerpoint",
    "odt": "application/vnd.oasis.opendocument.text",
    "ods": "application/vnd.oasis.opendocument.spreadsheet",
    "zip": "application/zip", "rar": "application/vnd.rar", "7z": "application/x-7z-compressed",
    "dxf": "image/vnd.dxf", "bmp": "image/bmp", "tif": "image/tiff", "tiff": "image/tiff",
}
MIME_BY_EXT.update(IMAGE_MIME)


class AttachmentError(Exception):
    """Файл не подходит модели; текст — для пользователя."""


class DirectAttachmentLimit(AttachmentError):
    """Файл превышает предел прямого чтения, но его можно обработать кодом."""


def container_info():
    return {"kind": "container", "pages": 0, "tokens": 0,
            "note": "доступен ассистенту для обработки кодом"}


def text_tokens(text):
    return int(len(text) / CHARS_PER_TOKEN) + 1


def _part(path, mime, block, title):
    return {"path": path, "mime": mime, "block": block, "title": title}


def extension(name):
    return os.path.splitext(name)[1].lower().lstrip(".")


def mime_type(name):
    return MIME_BY_EXT.get(extension(name), "application/octet-stream")


# Запрещено в имени файла Files API: < > : " | ? * \ / и управляющие символы.
_BAD_NAME_RE = re.compile(r'[<>:"|?*\\/\x00-\x1f\x7f]')


def container_name(name):
    """Имя файла в контейнере исполнения кода: исходное, без символов,
    запрещённых в Files API, не длиннее 200 знаков (с расширением)."""
    base, ext = os.path.splitext(name)
    base = _BAD_NAME_RE.sub("_", base).strip(" .") or "file"
    ext = _BAD_NAME_RE.sub("", ext)[:12]
    return base[:200 - len(ext)] + ext


def prepare(path, name, workdir):
    """Готовит файл для загрузки в Files API.

    Возвращает (parts, info): parts — что загрузить для чтения моделью
    напрямую (путь, MIME, вид блока сообщения — "document" или "image",
    название для модели), info — {"kind", "pages", "tokens", "note"} для
    чата. Для файлов, которые модель видит только из кода, parts пустой,
    kind — "container". Временные файлы — в workdir, его удаляет
    вызывающий."""
    ext = extension(name)
    if ext == "pdf":
        return _prepare_pdf(path, name, workdir)
    if ext in IMAGE_MIME:
        return _prepare_image(path, name, ext, workdir)
    if ext in TEXT_EXT:
        return _text_result(_read_text(path), name, workdir, "text")
    if ext in TABLE_EXT:
        return _text_result(_xlsx_text(path), name, workdir, "table")
    if ext in WORD_EXT:
        return _text_result(_docx_text(path), name, workdir, "word")
    if ext in CONTAINER_EXT:
        if os.path.getsize(path) == 0:
            raise AttachmentError("Файл пустой.")
        return [], container_info()
    raise AttachmentError("Файлы .%s ассистент не принимает." % (ext or "без расширения"))


# ── PDF ──

def _prepare_pdf(path, name, workdir):
    import fitz

    try:
        doc = fitz.open(path)
    except Exception:                             # noqa: BLE001
        raise AttachmentError("PDF не открывается — файл повреждён или это не PDF.")
    try:
        if doc.needs_pass:
            raise AttachmentError("PDF защищён паролем — снимите защиту и прикрепите снова.")
        pages = doc.page_count
        if pages == 0:
            raise AttachmentError("В PDF нет страниц.")
        if pages > PDF_MAX_PAGES:
            raise DirectAttachmentLimit(
                "В PDF %d страниц — модель за раз читает не больше %d. Разделите файл "
                "или оставьте нужные листы." % (pages, PDF_MAX_PAGES))

        texts = []
        for number, page in enumerate(doc, 1):
            text = page.get_text().strip()
            if text:
                texts.append("=== Страница %d ===\n%s" % (number, text))
        all_text = "\n\n".join(texts)
        tokens = pages * TOKENS_PER_PAGE_IMAGE + text_tokens(all_text)
        info = {"kind": "pdf", "pages": pages, "tokens": tokens, "note": ""}

        # Скан (текста нет ни на одной странице) и PDF, который MuPDF смог
        # открыть только с починкой, пересобираются картинками страниц
        # всегда: такие файлы (поворот страниц, необычное сжатие картинок
        # сканера, битая структура) API иногда не читает и отвечает
        # ошибкой — так было со сканом УПД 20.11.2026. Текста в скане нет,
        # так что модель ничего не теряет, а файл чаще и меньше.
        scan = not all_text
        repaired = bool(getattr(doc, "is_repaired", False))
        small = os.path.getsize(path) <= PDF_DIRECT_MAX_BYTES
        if small and not scan and not repaired:
            return [_part(path, "application/pdf", "document", name)], info

        raster_path = os.path.join(workdir, "pages.pdf")
        try:
            _rasterize(doc, raster_path)
        except Exception:                         # noqa: BLE001
            if not small:
                raise
            # Не пересобрался — пусть модель попробует исходный.
            return [_part(path, "application/pdf", "document", name)], info
        if scan:
            info["note"] = "скан: страницы подготовлены для чтения"
            return [_part(raster_path, "application/pdf", "document", name)], info
        parts = [_part(raster_path, "application/pdf", "document",
                       "%s (страницы картинками)" % name)]
        text_path = os.path.join(workdir, "pages.txt")
        with open(text_path, "w", encoding="utf-8") as handle:
            handle.write(all_text)
        parts.append(_part(text_path, "text/plain", "document",
                           "%s (текст страниц)" % name))
        info["note"] = "сжат: страницы картинками и текст отдельно" if not small \
            else "страницы подготовлены для чтения, текст отдельно"
        return parts, info
    finally:
        doc.close()


def _render(page, long_side=RASTER_LONG_SIDE):
    import fitz

    rect = page.rect
    zoom = long_side / max(rect.width, rect.height, 1.0)
    pix = page.get_pixmap(matrix=fitz.Matrix(zoom, zoom), alpha=False)
    return pix.tobytes("jpg", jpg_quality=RASTER_JPEG_QUALITY)


def _rasterize(doc, out_path):
    import fitz

    out = fitz.open()
    try:
        for number, page in enumerate(doc, 1):
            image = _render(page)
            new_page = out.new_page(width=page.rect.width, height=page.rect.height)
            new_page.insert_image(new_page.rect, stream=image)
            if number % 10 == 0:
                # Кэш MuPDF растёт с каждым листом; на хостинге лимит памяти.
                fitz.TOOLS.store_shrink(100)
        out.save(out_path, garbage=3, deflate=True)
    finally:
        out.close()


# ── картинки ──

def _prepare_image(path, name, ext, workdir):
    info = {"kind": "image", "pages": 0, "tokens": TOKENS_PER_IMAGE, "note": ""}
    if os.path.getsize(path) <= IMAGE_DIRECT_MAX_BYTES:
        return [_part(path, IMAGE_MIME[ext], "image", name)], info

    import fitz

    try:
        doc = fitz.open(path)
        image = _render(doc[0])
        doc.close()
    except Exception:                             # noqa: BLE001
        raise AttachmentError("Картинку не удалось прочитать — сохраните её как JPEG или PNG "
                              "и прикрепите снова.")
    out_path = os.path.join(workdir, "image.jpg")
    with open(out_path, "wb") as handle:
        handle.write(image)
    info["note"] = "уменьшена"
    return [_part(out_path, "image/jpeg", "image", name)], info


# ── текст ──

def _text_result(text, name, workdir, kind):
    text = text.strip()
    if not text:
        raise AttachmentError("В файле нет текста.")
    if len(text) > TEXT_MAX_CHARS:
        raise DirectAttachmentLimit(
            "В файле около %d тыс. знаков — для модели это слишком много. Оставьте нужную "
            "часть (листы, разделы) и прикрепите снова." % (len(text) // 1000))
    out_path = os.path.join(workdir, "text.txt")
    with open(out_path, "w", encoding="utf-8") as handle:
        handle.write(text)
    info = {"kind": kind, "pages": 0, "tokens": text_tokens(text),
            "note": "" if kind == "text" else "переведён в текст"}
    return [_part(out_path, "text/plain", "document", name)], info


def _read_text(path):
    if os.path.getsize(path) > TEXT_MAX_CHARS * 4:
        raise DirectAttachmentLimit("Текстовый файл слишком большой для прямого чтения моделью.")
    with open(path, "rb") as handle:
        raw = handle.read()
    for encoding in ("utf-8-sig", "cp1251"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", "replace")


def _cell(value):
    if value is None:
        return ""
    if isinstance(value, float):
        return ("%.10g" % value)
    if hasattr(value, "isoformat"):
        text = value.isoformat()
        return text[:-9] if text.endswith("T00:00:00") else text
    return " ".join(str(value).split())


def _xlsx_text(path):
    """Листы книги — строками через табуляцию, с номером строки Excel:
    инженер спрашивает «что в строке 13», модель должна его понять."""
    import openpyxl

    try:
        book = openpyxl.load_workbook(path, read_only=True, data_only=True)
    except Exception:                             # noqa: BLE001
        raise AttachmentError("Книга Excel не открывается — файл повреждён или это не .xlsx.")
    lines = []
    total = 0
    try:
        for sheet in book.worksheets:
            lines.append("=== Лист «%s» ===" % sheet.title)
            for number, row in enumerate(sheet.iter_rows(values_only=True), 1):
                cells = [_cell(value) for value in row]
                while cells and not cells[-1]:
                    cells.pop()
                if not cells:
                    continue
                line = "%d\t%s" % (number, "\t".join(cells))
                total += len(line)
                if total > TEXT_MAX_CHARS:
                    raise DirectAttachmentLimit(
                        "Таблица слишком большая для модели (больше %d тыс. знаков). Оставьте "
                        "нужные листы или строки и прикрепите снова." % (TEXT_MAX_CHARS // 1000))
                lines.append(line)
            lines.append("")
    finally:
        book.close()
    return "\n".join(lines)


_W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"
# Распакованный document.xml больше этого — не документ, а «zip-бомба».
DOCX_MAX_XML_BYTES = 200 * 1024 * 1024


def _paragraph_text(element):
    parts = []
    for node in element.iter():
        if node.tag == _W + "t" and node.text:
            parts.append(node.text)
        elif node.tag == _W + "tab":
            parts.append("\t")
        elif node.tag in (_W + "br", _W + "cr"):
            parts.append("\n")
    return "".join(parts).strip()


def _docx_text(path):
    """Абзацы и таблицы документа Word по порядку; картинки пропускаются."""
    try:
        with zipfile.ZipFile(path) as archive:
            info = archive.getinfo("word/document.xml")
            if info.file_size > DOCX_MAX_XML_BYTES:
                raise DirectAttachmentLimit("Документ Word слишком большой для прямого чтения моделью.")
            raw = archive.read(info)
    except (zipfile.BadZipFile, KeyError):
        raise AttachmentError("Документ Word не открывается — файл повреждён или это не .docx.")
    # В настоящем .docx объявлений DOCTYPE нет; с ними XML может
    # «раздуться» при разборе.
    if b"<!DOCTYPE" in raw[:4096].upper():
        raise AttachmentError("Документ Word не открывается — файл повреждён.")
    try:
        root = ET.fromstring(raw)
    except ET.ParseError:
        raise AttachmentError("Документ Word не открывается — файл повреждён.")
    body = root.find(_W + "body")
    lines = []
    for element in (body if body is not None else []):
        if element.tag == _W + "p":
            text = _paragraph_text(element)
            if text:
                lines.append(text)
        elif element.tag == _W + "tbl":
            for row in element.iter(_W + "tr"):
                cells = [re.sub(r"\s+", " ", _paragraph_text(cell))
                         for cell in row.findall(_W + "tc")]
                if any(cells):
                    lines.append("\t".join(cells))
            lines.append("")
    return "\n".join(lines)
