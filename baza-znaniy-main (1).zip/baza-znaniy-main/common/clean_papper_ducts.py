"""Stage 10: evidence-only grouping of vector PDF strokes into duct-shaped candidates.

This is NOT a physical quantity takeoff. Uses page-local PDF point coordinates;
a pair of strokes may be a wall, grille or architectural line. Scale, system,
material, length in metres and quantity require independent verification.

Heuristics are initially based on the supplied ventilation-algorithm document:
coaxial tolerance 0.06pt, merge gap 0.05pt, 1:100 rectangular wall separation
5..32pt, dashed centerline gaps 1.2..6.5pt with median >=3.6pt.
These thresholds are PROVISIONAL, not safe defaults for every drawing scale.
"""
from __future__ import annotations
import bisect
import collections
import math
import statistics

from common.clean_papper_vector import _clip_line, _color, _on_page, _point, _distance_to_segment

MAX_PATHS = 50000
MAX_STROKES = 130000
MAX_FAMILIES = 50000
MAX_CANDIDATES = 35
MAX_LAYERS = 12
AXIS_TOL_PT = 0.05
COAXIAL_TOL_PT = 0.06
JOIN_GAP_PT = 0.05
RECT_SEPARATION_PT = (5., 32.)
ROUND_WALL_SEPARATION_PT = (1.8, 10.5)
DASH_GAP_PT = (1.2, 6.5)
DASH_MIN_MEDIAN_GAP_PT = 3.6


def _f(v, default=0.0):
    try:
        v = float(v)
        return v if math.isfinite(v) else default
    except (ValueError, TypeError, OverflowError):
        return default


def _view(p, axis, along, across):
    if axis == 'h':
        return (along, across)
    return (across, along)


def _as_pt(p):
    return [round(p[0], 3), round(p[1], 3)]


def _source_ids(group):
    return group['ids'][:12]


def _overlap(a, b):
    low, high = max(a['lo'], b['lo']), min(a['hi'], b['hi'])
    return low, high, max(0., high - low)


def _near_text(start, end, labels, radius):
    found = None
    for label in labels or []:
        coords = label.get('at_pdf_pt')
        if not isinstance(coords, (tuple, list)) or len(coords) != 2:
            continue
        p = _f(coords[0], None), _f(coords[1], None)
        if None in p:
            continue
        dist = _distance_to_segment(p, start, end)
        if dist <= radius and (found is None or dist < found[0]):
            found = (dist, str(label.get('text') or '')[:50])
    return {'text': found[1], 'distance_pdf_pt': round(found[0], 2)} if found else None


def _normal(start, end, page_rect):
    return [_on_page(start, page_rect), _on_page(end, page_rect)]


def extract_duct_geometry(page, region, section_labels=None, drawings=None,
                          max_paths=MAX_PATHS, max_strokes=MAX_STROKES,
                          settings=None):
    """Find near-parallel wall pairs and dashed axial chains.

    Complexity is dominated by sorting, not quadratic comparison of all PDF strokes.
    Returned IDs are evidence references, not verified airduct identification.
    """
    rect = [float(v) for v in region]
    page_rect = [float(v) for v in page.rect]
    if len(rect) != 4 or any(not math.isfinite(v) for v in rect) or not (
        page_rect[0] <= rect[0] < rect[2] <= page_rect[2] and
        page_rect[1] <= rect[1] < rect[3] <= page_rect[3]
    ):
        raise ValueError("Invalid PDF page region")
    geom = dict(settings or {})
    rect_min = float(geom.get("rect_min_pt", RECT_SEPARATION_PT[0]))
    rect_max = float(geom.get("rect_max_pt", RECT_SEPARATION_PT[1]))
    coaxial = float(geom.get("coaxial_tol_pt", COAXIAL_TOL_PT))
    join_gap = float(geom.get("join_gap_pt", JOIN_GAP_PT))
    dash_min = float(geom.get("dash_gap_min_pt", DASH_GAP_PT[0]))
    dash_max = float(geom.get("dash_gap_max_pt", DASH_GAP_PT[1]))
    dash_median = float(geom.get("dash_median_min_pt", DASH_MIN_MEDIAN_GAP_PT))
    paths = drawings if drawings is not None else (
        page.get_cdrawings() if hasattr(page, 'get_cdrawings') else page.get_drawings()
    )
    buckets = collections.defaultdict(list)
    layer_stats = collections.defaultdict(lambda: [0, 0., 0])
    non_axis_count, total_strokes, scanned_paths, hit_limit = 0, 0, 0, False
    for sampled_index, entry in enumerate(paths):
        if sampled_index >= max_paths:
            hit_limit = True
            break
        if isinstance(entry, tuple) and len(entry)==2 and isinstance(entry[0], int):
            pi, drawing = entry
        else:
            pi, drawing = sampled_index, entry
        scanned_paths += 1
        color, saturated = _color(drawing.get('color'))
        color = color or "#unavailable"
        width = round(max(0., _f(drawing.get('width'))), 2)
        dash = str(drawing.get('dashes') or 'solid')[:45]
        if dash.strip() in ('[] 0', '[]0', 'solid', ''):
            dash = 'solid'
        layer_key = (color, width, dash)
        count_for_path = 0
        for ii, item in enumerate(drawing.get('items') or []):
            if total_strokes >= max_strokes:
                hit_limit = True
                break
            if not item or item[0] != 'l' or len(item) < 3:
                continue
            a, b = _point(item[1]), _point(item[2])
            if not a or not b or not all(math.isfinite(v) for v in a + b):
                continue
            clipped = _clip_line(a, b, rect)
            if clipped is None:
                continue
            a, b = clipped
            length = math.dist(a, b)
            if length < .35:
                continue
            total_strokes += 1
            count_for_path += 1
            layer_stats[layer_key][0] += 1
            layer_stats[layer_key][1] += length
            dx, dy = abs(a[0]-b[0]), abs(a[1]-b[1])
            if dy <= AXIS_TOL_PT:
                axis, position, lo, hi = 'h', (a[1]+b[1])/2, min(a[0],b[0]), max(a[0],b[0])
            elif dx <= AXIS_TOL_PT:
                axis, position, lo, hi = 'v', (a[0]+b[0])/2, min(a[1],b[1]), max(a[1],b[1])
            else:
                non_axis_count += 1
                continue
            # Bucket by coordinate, later merge neighbor positions within 0.06pt.
            cell = round(position / coaxial)
            buckets[(axis, color, cell)].append((
                position, lo, hi, 'pdf_path_%d_line_%d' % (pi,ii),width,dash
            ))
        if count_for_path:
            layer_stats[layer_key][2] += 1
        if hit_limit:
            break

    groups = []
    # Each color+direction uses a sorted local position space, avoiding O(N^2).
    axis_color = collections.defaultdict(list)
    for (axis,color,cell), data in buckets.items():
        axis_color[(axis,color)].extend(data)
    for (axis,color), entries in axis_color.items():
        entries.sort(key=lambda x: (x[0],x[1],x[2]))
        rows = []
        for item in entries:
            if not rows or abs(item[0]-rows[-1]['pos']) > coaxial:
                rows.append({'pos':item[0], 'entries':[item]})
            else:
                rows[-1]['entries'].append(item)
        for row in rows:
            pieces = sorted(row['entries'],key=lambda x:(x[1],x[2]))
            families = []
            for item in pieces:
                if not families or item[1] > families[-1]['hi']+join_gap:
                    families.append({'lo':item[1],'hi':item[2], 'ids':[item[3]],
                                     'pieces':[(item[1],item[2])], 'widths':[item[4]],
                                     'dashes':[item[5]]})
                else:
                    f = families[-1]
                    f['hi']=max(f['hi'],item[2])
                    f['ids'].append(item[3])
                    f['pieces'].append((item[1],item[2]))
                    f['widths'].append(item[4])
                    f['dashes'].append(item[5])
            # For dashed chains, separate continuous families need to be examined.
            dashed = []
            for fam in families:
                if not dashed or fam['lo']-dashed[-1][-1]['hi'] > dash_max:
                    dashed.append([fam])
                else:
                    dashed[-1].append(fam)
            dashed_ids = set()
            for chain in dashed:
                if len(chain)<3:
                    continue
                gaps = [chain[j+1]['lo']-chain[j]['hi'] for j in range(len(chain)-1)]
                if (all(dash_min <= g <= dash_max for g in gaps)
                    and all(2.5<=part['hi']-part['lo']<=24 for part in chain)):
                    # Neither a dashed axis nor insulation outline may also
                    # masquerade as a continuous rectangular duct wall.
                    dashed_ids.update(id for f in chain for id in f['ids'])
                    if statistics.median(gaps)>=dash_median:
                        groups.append({'axis':axis,'color':color,'pos':row['pos'],
                                       'lo':chain[0]['lo'],'hi':chain[-1]['hi'],
                                       'kind':'dashed_axis',
                                       'ids':[id for f in chain for id in f['ids']],
                                       'piece_count':len(chain),
                                       'median_gap_pt':round(statistics.median(gaps),3)})
            for f in families:
                if (f['hi']-f['lo'] >= 4. and
                    not any(id in dashed_ids for id in f['ids'])):
                    groups.append({'axis':axis,'color':color,'pos':row['pos'],
                                   'lo':f['lo'],'hi':f['hi'],'kind':'solid_wall',
                                   'ids':f['ids'],'piece_count':len(f['pieces'])})
            if len(groups)>MAX_FAMILIES:
                hit_limit = True
                break
        if len(groups)>MAX_FAMILIES:
            break

    by_color_axis = collections.defaultdict(list)
    for g in groups:
        by_color_axis[(g['axis'],g['color'])].append(g)
    for arr in by_color_axis.values():
        arr.sort(key=lambda v:(v['pos'],v['lo']))

    proposals = []
    def add(kind, axis, color, start, end, wall_gap, families, gap=None):
        distance=math.dist(start,end)
        if distance <4.:
            return
        color_saturated = (color not in ('#unavailable','#000000','#ffffff')
                           and len(color)==7)
        source=[]
        for f in families:
            for item in f['ids']:
                if item not in source and len(source)<24:
                    source.append(item)
        line = {
            'status':'unverified_duct_geometry', 'kind':kind,
            'orientation': 'horizontal' if axis=='h' else 'vertical',
            'stroke_color':color,'center_start_pdf_pt':_as_pt(start),
            'center_end_pdf_pt':_as_pt(end),
            'center_start_page_norm':_on_page(start,page_rect),
            'center_end_page_norm':_on_page(end,page_rect),
            'projected_length_pt':round(distance,3),
            'width_between_strokes_pt':round(wall_gap,3) if wall_gap else None,
            'source_line_ids':source,'source_line_count':sum(len(f['ids']) for f in families),
            'dimension_text_nearby':_near_text(start,end,section_labels,65),
            'physical_length_m':None,'scale_verified':False,
            'system_verified':False,'section_verified':False,
            'manual_review_required':True,
            'confidence':'low',
        }
        if gap:
            line['dash_median_gap_pt']=gap
        if kind=='rectangular_wall_pair':
            lo_axis = start[0] if axis == 'h' else start[1]
            hi_axis = end[0] if axis == 'h' else end[1]
            line['source_wall_segments_page_norm'] = [
                _normal(_view(None, axis, lo_axis, f['pos']),
                        _view(None, axis, hi_axis, f['pos']), page_rect)
                for f in families
            ]
        # Shorter, colorized candidates are ranked after longer geometry with dimensions.
        score=distance+(450 if line['dimension_text_nearby'] else 0)+(85 if color_saturated else 0)
        proposals.append((score,line))

    for (axis,color), vals in by_color_axis.items():
        walls=[g for g in vals if g['kind']=='solid_wall']
        axes=[g for g in vals if g['kind']=='dashed_axis']
        positions=[g['pos'] for g in walls]
        used=set()
        # Near-neighbor wall pairing. Adjacency and one-to-one selection
        # suppress the most obvious duplicate pairs and nested outlines.
        possible=[]
        for k in range(len(walls)-1):
            a,b=walls[k],walls[k+1]
            gap=b['pos']-a['pos']
            if not rect_min<=gap<=rect_max:
                continue
            lo,hi,overlap=_overlap(a,b)
            if overlap<4:
                continue
            # Do not make a rectangle from a dashed axial candidate.
            if any(ax['lo']<hi and ax['hi']>lo and
                   a['pos']<ax['pos']<b['pos'] for ax in axes):
                continue
            possible.append((overlap,-gap,k,k+1,lo,hi))
        possible.sort(reverse=True)
        for overlap,negative_gap,i,j,lo,hi in possible:
            if i in used or j in used:
                continue
            a,b=walls[i],walls[j]
            center=(a['pos']+b['pos'])/2
            start,end=_view(None,axis,lo,center),_view(None,axis,hi,center)
            add('rectangular_wall_pair',axis,color,start,end,b['pos']-a['pos'],[a,b])
            used.update((i,j))

        # Candidate round axis: a dashed chain, with one wall each side.
        for ax in axes:
            pos=bisect.bisect_left(positions,ax['pos'])
            left=walls[max(0,pos-10):pos]
            right=walls[pos:pos+10]
            def find_side(candidates):
                values=[]
                for g in candidates:
                    sep=abs(ax['pos']-g['pos'])
                    if not ROUND_WALL_SEPARATION_PT[0]<=sep<=ROUND_WALL_SEPARATION_PT[1]:
                        continue
                    lo,hi,overlap=_overlap(ax,g)
                    if overlap>=min(.3*(ax['hi']-ax['lo']),6):
                        values.append((sep,g))
                return min(values,key=lambda v:v[0])[1] if values else None
            a,b=find_side(left),find_side(right)
            if a is None or b is None:
                continue
            lo=max(ax['lo'],a['lo'],b['lo'])
            hi=min(ax['hi'],a['hi'],b['hi'])
            if hi-lo<4:
                continue
            start,end=_view(None,axis,lo,ax['pos']),_view(None,axis,hi,ax['pos'])
            add('round_dashed_axis_with_walls',axis,color,start,end,
                (abs(ax['pos']-a['pos'])+abs(ax['pos']-b['pos'])),[ax,a,b],
                ax.get('median_gap_pt'))

    proposals.sort(key=lambda entry:(-entry[0],entry[1]['stroke_color'],
                                      entry[1]['center_start_pdf_pt']))
    chosen=[]
    for i,(score,item) in enumerate(proposals[:MAX_CANDIDATES],1):
        item['candidate_id']='D%03d'%i
        chosen.append(item)

    layers=[]
    for (color,width,dash),(count,total,path_count) in sorted(
        layer_stats.items(),key=lambda kv:-kv[1][1]
    )[:MAX_LAYERS]:
        layers.append({
            'stroke_color':color, 'stroke_width_pt':width,
            'dash_signature':dash,'stroke_count':count,
            'pdf_path_count':path_count,'total_stroke_length_pt':round(total,2),
            'system':'unassigned',
        })
    return {
        'status':'unverified_geometry_candidates',
        'source_page_rect_pdf_pt':page_rect,
        'region_pdf_pt':rect,
        'scanning':{
            'pdf_paths_scanned':scanned_paths,'segments_scanned':total_strokes,
            'inclined_segments_excluded':non_axis_count,
            'scan_truncated':hit_limit,
            'line_families_found':len(groups),
            'candidate_duct_shapes_found':len(proposals),
            'candidates_returned':len(chosen),
        },
        'layer_statistics':layers,
        'candidates':chosen,
        'assumptions':{
            'rect_separation_pt_range':[rect_min, rect_max],
            'coaxial_tolerance_pt':coaxial,
            'merge_gap_pt':join_gap,
            'dash_gap_pt_range':[dash_min, dash_max],
            'dash_median_min_pt':dash_median,
            'nominal_pdf_scale':"unknown (unverified)",
        },
        'limitations':[
            'Individual wall pairs may be walls, equipment or architecture',
            'Color grouping is not system classification',
            'Width in PDF points is not yet a verified duct section',
            'PDF projection does not prove centerline path or vertical extent',
            'Algorithm handles axis-aligned pairs only; inclined duct geometry is not inferred',
            'No metres, areas, fittings or equipment quantities are calculated',
        ],
    }
