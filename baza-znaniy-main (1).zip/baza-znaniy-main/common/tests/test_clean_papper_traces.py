"""Stage 10.2: synthetic colored vector trace geometry. No vision or project PDF."""
from __future__ import annotations
import math
import unittest

from common.clean_papper_traces import extract_trace_network


class Page:
    rect = (0., 0., 500., 400.)


def path(a,b,color=(0.,0.,1.),width=1.08):
    return {"color":color,"width":width,
            "items":[("l",a,b)],"rect":(
                min(a[0],b[0]),min(a[1],b[1]),
                max(a[0],b[0]),max(a[1],b[1])
            )}


def extract(paths,**kwargs):
    return extract_trace_network(Page(),(0,0,500,400),
                                 drawings=paths,**kwargs)


class ColoredTraceTests(unittest.TestCase):
    def test_long_inclined_parallel_strokes(self):
        direction=(math.cos(math.pi/6),math.sin(math.pi/6))
        normal=(-direction[1],direction[0])
        a=(25.,35.)
        b=(a[0]+direction[0]*130,a[1]+direction[1]*130)
        c=(a[0]+normal[0]*3,a[1]+normal[1]*3)
        d=(b[0]+normal[0]*3,b[1]+normal[1]*3)
        report=extract([path(a,b),path(c,d)])
        self.assertEqual(len(report["candidates"]),1)
        item=report["candidates"][0]
        self.assertEqual(item["orientation"],"inclined")
        self.assertAlmostEqual(item["angle_deg"],30)
        self.assertAlmostEqual(item["projected_length_pt"],130,delta=.5)
        self.assertAlmostEqual(item["width_between_strokes_pt"],3,delta=.1)
        self.assertIsNone(item["physical_length_m"])
        self.assertFalse(item["scale_verified"])
        self.assertEqual(item["status"],"unverified_trace_candidate")
        self.assertEqual(item["spatial_group_id"],"G001")

    def test_thin_outlines_below_old_five_point_minimum(self):
        report=extract([
            (51220,path((20,20),(20,200),color=(1,0,0))),
            (83991,path((22.88,20),(22.88,200),color=(1,0,0))),
        ])
        self.assertEqual(len(report["candidates"]),1)
        c=report["candidates"][0]
        self.assertAlmostEqual(c["width_between_strokes_pt"],2.88,places=2)
        self.assertEqual(set(c["source_line_ids"]),
                         {"pdf_path_51220_line_0","pdf_path_83991_line_0"})

    def test_equal_length_square_edges_not_long_duct(self):
        report=extract([
            path((20,20),(40,20)),path((20,40),(40,40))
        ])
        self.assertEqual(report["candidates"],[])

    def test_different_colors_not_joined(self):
        report=extract([
            path((20,20),(220,20),color=(1,0,0)),
            path((20,23),(220,23),color=(0,0,1))
        ])
        self.assertFalse(report["candidates"])

    def test_architecture_black_not_classified_as_colored_trace(self):
        report=extract([
            path((20,20),(220,20),color=(0,0,0)),
            path((20,23),(220,23),color=(0,0,0))
        ])
        self.assertFalse(report["candidates"])

    def test_fragmented_line_recombined_before_pairing(self):
        report=extract([
            path((20,100),(110,100),color=(1,0,0)),
            path((111.9,100),(210,100),color=(1,0,0)),
            path((20,102.88),(210,102.88),color=(1,0,0)),
        ])
        c=report["candidates"][0]
        self.assertAlmostEqual(c["projected_length_pt"],190,delta=.1)
        self.assertEqual(c["source_line_count"],3)

    def test_two_orthogonal_pairs_share_one_spatial_hint(self):
        report=extract([
            path((50,20),(50,100),color=(1,0,0)),
            path((53,20),(53,100),color=(1,0,0)),
            path((50,98),(140,98),color=(1,0,0)),
            path((50,101),(140,101),color=(1,0,0)),
        ])
        self.assertEqual(len(report["candidates"]),2)
        self.assertEqual(len(report["spatial_groups"]),1)
        self.assertEqual(report["spatial_groups"][0]["candidate_count"],2)
        self.assertEqual({c["spatial_group_id"] for c in report["candidates"]},{"G001"})
        self.assertEqual(report["spatial_groups"][0]["status"],"spatial_hint_unverified")

    def test_far_pairs_not_networked(self):
        report=extract([
            path((20,20),(200,20),color=(1,0,0)),
            path((20,23),(200,23),color=(1,0,0)),
            path((20,300),(200,300),color=(1,0,0)),
            path((20,303),(200,303),color=(1,0,0)),
        ])
        self.assertEqual(len(report["candidates"]),2)
        self.assertEqual(len(report["spatial_groups"]),2)

    def test_scan_limit_explicit(self):
        report=extract([
            path((20,20),(200,20),color=(1,0,0)),
            path((20,23),(200,23),color=(1,0,0)),
            path((20,40),(200,40),color=(1,0,0)),
        ],max_lines=2)
        self.assertTrue(report["scanning"]["trace_scan_truncated"])
        with self.assertRaises(ValueError):
            extract([],max_lines=1000000)

    def test_invalid_region_rejected(self):
        with self.assertRaises(ValueError):
            extract_trace_network(Page(),(-1,0,200,200),drawings=[])

    def test_no_material_or_physical_quantities(self):
        report=extract([
            path((20,20),(200,20),color=(1,0,0)),
            path((20,23),(200,23),color=(1,0,0))
        ])
        self.assertNotIn("total_length_m",report)
        self.assertNotIn("fittings_count",report)
        for candidate in report["candidates"]:
            self.assertIsNone(candidate["physical_length_m"])
            self.assertFalse(candidate["system_verified"])
            self.assertFalse(candidate["section_verified"])


if __name__=="__main__":
    unittest.main()
