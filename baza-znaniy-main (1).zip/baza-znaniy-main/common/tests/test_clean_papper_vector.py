"""Stage 9 PDF-line source evidence: synthetic vector pages, no Claude/API."""
from __future__ import annotations

import math
import unittest

import fitz
from common.clean_papper_vector import extract_vector_candidates, _clip_line


class PDFVectorEvidenceTests(unittest.TestCase):
    def setUp(self):
        self.doc = fitz.open()
        self.page = self.doc.new_page(width=500, height=300)
        self.page.insert_text((90, 72), "200x450", fontsize=13)
        self.page.draw_line((40, 95), (240, 95), color=(0.1, .9, .1), width=.5)
        self.page.draw_line((40, 115), (240, 115), color=(0.1, .9, .1), width=.5)
        self.labels=[{"text":"200x450","at_pdf_pt":[90,72]}]

    def tearDown(self):
        self.doc.close()

    def test_source_line_ids_and_coordinates_trace_to_pdf(self):
        data=extract_vector_candidates(self.page, [0,0,500,300], self.labels)
        self.assertEqual(len(data["candidates"]),2)
        a,b=data["candidates"]
        self.assertTrue(a["source_id"].startswith("pdf_path_"))
        self.assertEqual(a["status"], "unverified_pdf_line")
        self.assertIsNone(a["physical_length_m"])
        self.assertFalse(a["scale_verified"])
        self.assertAlmostEqual(a["projected_length_pt"],200)
        self.assertAlmostEqual(a["start_page_norm"][0],.08)
        self.assertAlmostEqual(a["end_page_norm"][0],.48)
        self.assertEqual(a["dimension_text_nearby"]["text"],"200x450")
        self.assertTrue(a["colored_stroke"])
        self.assertGreaterEqual(data["path_scanning"]["colored_paths_encountered"],2)

    def test_crop_clips_stroke_without_inventing_length(self):
        data=extract_vector_candidates(self.page, [100,85,170,120], self.labels)
        self.assertEqual(len(data["candidates"]),2)
        for cand in data["candidates"]:
            self.assertEqual(cand["start_pdf_pt"][0],100)
            self.assertEqual(cand["end_pdf_pt"][0],170)
            self.assertAlmostEqual(cand["projected_length_pt"],70)
            self.assertIsNone(cand["physical_length_m"])
            self.assertAlmostEqual(cand["start_page_norm"][0],.2)
            self.assertAlmostEqual(cand["end_page_norm"][0],.34)

    def test_crop_outside_page_rejected(self):
        with self.assertRaises(ValueError):
            extract_vector_candidates(self.page,[-1,0,400,200],self.labels)

    def test_scanning_limit_explicitly_reported(self):
        result=extract_vector_candidates(self.page,[0,0,500,300],self.labels,max_paths=1)
        self.assertTrue(result["path_scanning"]["scan_truncated"])
        self.assertEqual(result["path_scanning"]["scanned_paths"],1)
        self.assertLessEqual(len(result["candidates"]),1)

    def test_drawing_non_line_not_misclassified(self):
        doc=fitz.open()
        try:
            p=doc.new_page(width=300,height=200)
            p.draw_circle((100,100),50,color=(0,1,0))
            data=extract_vector_candidates(p,[0,0,300,200])
            self.assertEqual(len(data["candidates"]),0)
        finally:doc.close()

    def test_segment_clipping_rejects_outside(self):
        self.assertIsNone(_clip_line((2,2),(5,5),(50,50,100,100)))
        a,b=_clip_line((0,40),(120,40),(20,10,60,60))
        self.assertAlmostEqual(a[0],20)
        self.assertAlmostEqual(b[0],60)


if __name__=="__main__":
    unittest.main()
