"""Business routing, storage isolation, recovery and real CLI entry points (no API calls)."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from openpyxl import Workbook, load_workbook
from common.catalog_store import CatalogStore, json_bytes, read_json
from common.nomenclature_routing import route_item
from common.routed_intake import check_batch, process_intake, review_items, bulk_selections

ROOT = Path(__file__).resolve().parents[2]
TOKEN = '0123456789abcdef'


def item(code, name, **extra):
    return {'Код': code, 'Наименование': name, **extra}


class KeywordsTest(unittest.TestCase):
    def test_contrasts(self):
        examples = {
            'Вентиль пожарный Ду50 Ру16': 'vk', 'Пожарный вентилятор дымоудаления': 'ventilation',
            'Вентилятор канальный': 'ventilation', 'Воздухоотводчик автоматический Ду15': 'vk',
            'Воздуховод круглый Ø160': 'ventilation', 'Фильтр сетчатый муфтовый PN16 Ду15': 'vk',
            'Фильтр воздушный кассетный': 'ventilation', 'Тройник PP-R белый 25х20х25': 'vk',
            'Тройник для воздуховода 250х150': 'ventilation', 'Трап с чугунной решёткой DN110': 'vk',
            'Решетка вентиляционная': 'ventilation', 'Шкаф управления дренажными насосами': 'vk',
            'Шкаф управления вентиляцией': 'ventilation', 'Сифон для кондиционера': 'vk',
            'Водорозетка 20х1/2': 'vk', 'Болт М10х100': None, 'Труба профильная квадратная 50х50': None,
            'Труба гофрированная с зондом FRHF 20': None, 'Клапан обратный для воздуховода PN16': None,
            'Отвод сталь бесшовный 90 гр ГОСТ 17375-2001': 'vk',
            'Труба дренажная ПВХ для отвода конденсата из систем кондиционирования': 'vk',
            'Фланец латунный для канального датчика d6': None,
            'Отвод': None, 'Переход': None, 'Фильтр': None, 'Вентиль': None, 'Решетка': None,
            'Клапан огнезадерживающий': None, 'Тройник 100х100': None,
            'Материал марки VentSpecPro': None,
        }
        for name, expected in examples.items():
            with self.subTest(name=name):
                self.assertEqual(route_item(item('new', name))['catalog'], expected)

    def test_metadata_and_existing_code_priority(self):
        known = {'water': {'vk'}, 'air': {'ventilation'}, 'both': {'vk', 'ventilation'}}
        self.assertEqual(route_item(item('water', 'Болт'), known)['catalog'], 'vk')
        self.assertEqual(route_item(item('air', 'Унитаз'), known)['catalog'], 'ventilation')
        self.assertIsNone(route_item(item('both', 'Унитаз'), known)['catalog'])
        self.assertEqual(route_item(item('new', 'Болт', Направление='ВК'))['catalog'], 'vk')
        self.assertIsNone(route_item(item('new', 'Болт', ВидНоменклатуры='ВК'))['catalog'])
        self.assertIsNone(route_item(item('new', 'Болт', Направление='ВК', Раздел='VentSpec'))['catalog'])
        self.assertIsNone(route_item(item('air', 'Унитаз', Направление='ВК'), known)['catalog'])
        self.assertEqual(route_item(item('both', 'Болт', Раздел='ВК'), known)['catalog'], 'vk')
        self.assertEqual(route_item(item('both', 'Болт'), known, {'both': 'vk'})['catalog'], 'vk')


class IntakeTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        (self.root/'outputs').mkdir()
        self.existing = self.root/'1c_full_nomenclature.json'
        self.db = self.root/'1c_base.xlsx'
        self.vk = self.root/'1c_vk_catalog.json'
        self.pending = self.root/'outputs'/(TOKEN + '_1c_pending.json')
        self.output = self.root/'report.xlsx'
        # The snapshot contains a water row: it is NOT ventilation membership.
        self.existing.write_bytes(json_bytes([item('air', 'Воздуховод круглый Ø160'), item('water', 'Сифон')]))
        book = Workbook(); book.active.append(['Код', 'Наименование'])
        book.active.append(['air', 'Воздуховод круглый Ø160']); book.save(self.db); book.close()
        self.vk.write_bytes(json_bytes({'schema_version': 1, 'catalog': 'vk', 'item_count': 1,
            'missing_units': 0, 'repeated_names': 0, 'source': {'filename': 'initial.xlsx'},
            'import_payload_sha256': 'initial', 'items': [item('water', 'Сифон', ЕдиницаИзмерения='шт')]}))
        self.store = CatalogStore(self.existing, self.db)

    def run_batch(self, items):
        return process_intake(items, self.store, self.pending, TOKEN, self.output)

    def air_rows(self):
        book = load_workbook(self.db, read_only=True, data_only=True)
        try:
            return list(book.active.values)
        finally:
            book.close()

    def cli(self, script, *args):
        env = {**os.environ, 'OPENBLAS_NUM_THREADS': '1'}
        result = subprocess.run([sys.executable, str(ROOT/'common'/script), *map(str,args)],
                                capture_output=True, text=True, env=env)
        return result.returncode, json.loads(result.stdout)

    def test_separate_additions_and_manual_queue(self):
        before_air = self.db.read_bytes()
        stats = self.run_batch([item('w-new', 'Смеситель настенный', ЕдиницаИзмерения='компл'),
            item('shared', 'Болт М10'), item('unknown', 'Модель Q721'),
            item('group', 'Вентилятор', ЭтоГруппа=True), item('gone', 'Унитаз', ПометкаУдаления=True)])
        self.assertEqual(stats['auto_added'], 1)
        self.assertEqual(stats['by_catalog'], {'vk':1,'review':2})
        self.assertEqual(stats['pending_review'], 2)
        self.assertEqual(self.db.read_bytes(), before_air)
        self.assertNotIn('w-new', [it['Код'] for it in read_json(self.existing)])
        water = read_json(self.vk)
        self.assertEqual(water['item_count'], 2)
        self.assertEqual(water['source'], {'filename':'initial.xlsx'})
        self.assertNotIn('import_payload_sha256', water)
        self.assertTrue(all('routing' in e for e in read_json(self.pending)))
        book = load_workbook(self.output, read_only=True)
        self.assertEqual(book.active.cell(2,8).value,'ВК'); book.close()

    def test_vent_adds_to_snapshot_and_excel_only(self):
        before_water = self.vk.read_bytes()
        self.run_batch([item('v-new', 'Вентилятор крышный ВКР-99')])
        self.assertEqual(self.vk.read_bytes(), before_water)
        self.assertEqual(self.air_rows()[-1], ('v-new','Вентилятор крышный ВКР-99'))
        self.assertIn('v-new', [it['Код'] for it in read_json(self.existing)])

    def test_snapshot_code_can_link_to_local_excel_id_by_confirmed_name(self):
        snapshot=read_json(self.existing)
        snapshot.append(item('BP-air','Воздуховод круглый Ø160',ЕдиницаИзмерения='м'))
        self.existing.write_bytes(json_bytes(snapshot))
        self.run_batch([item('BP-air','Воздуховод круглый Ø160',ЕдиницаИзмерения='шт')])
        self.assertEqual(len(self.air_rows()),2)  # no duplicated workbook row
        self.run_batch([item('BP-air','Воздуховод круглый Ø200')])
        result=review_items(self.store,[(self.pending,0,None)],'ventilation')
        self.assertEqual(result['promoted'],1)
        self.assertEqual(self.air_rows()[1],('air','Воздуховод круглый Ø200'))
        self.store.load()
        self.assertEqual(self.store.memberships['BP-air'],{'ventilation'})

    def test_ambiguous_local_ids_cannot_be_renamed_together(self):
        book=load_workbook(self.db);book.active.append(['other-id','Воздуховод круглый Ø160']);book.save(self.db);book.close()
        snapshot=read_json(self.existing);snapshot.append(item('BP-air','Воздуховод круглый Ø160'))
        self.existing.write_bytes(json_bytes(snapshot))
        self.run_batch([item('BP-air','Воздуховод круглый Ø200')])
        before=self.db.read_bytes()
        with self.assertRaisesRegex(ValueError,'несколькими строками'):
            review_items(self.store,[(self.pending,0,None)],'ventilation')
        self.assertEqual(self.db.read_bytes(),before)
        self.assertFalse(read_json(self.pending)[0]['resolved'])

    def test_vent_changes_invalidate_same_second_view_cache(self):
        cache=self.root/'outputs/db_file_dump.json'
        cache.write_bytes(json_bytes({'schema_version':3,'items':[]}))
        self.run_batch([item('v-new','Вентилятор крышный ВКР-99')])
        self.assertEqual(read_json(cache)['schema_version'],0)

    def test_known_water_code_and_unit_update_are_idempotent(self):
        before_air = self.db.read_bytes()
        stats = self.run_batch([item('water','Сифон', ЕдиницаИзмерения='компл')])
        self.assertEqual(stats['pending_review'],0)
        self.assertEqual(stats['auto_updated'],1)
        self.assertEqual(read_json(self.vk)['items'][0]['ЕдиницаИзмерения'],'компл')
        stats = self.run_batch([item('water','Сифон', ЕдиницаИзмерения='компл')])
        self.assertEqual(stats['auto_added'],0); self.assertEqual(stats['auto_unchanged'],1)
        self.run_batch([item('water','Сифон')])
        self.assertEqual(read_json(self.vk)['items'][0]['ЕдиницаИзмерения'],'компл')
        self.assertEqual(self.db.read_bytes(), before_air)

    def test_renames_need_review_and_can_update_same_branch(self):
        self.run_batch([item('water','Сифон бутылочный')])
        self.assertEqual(read_json(self.pending)[0]['flags'][0]['type'],'code_changed')
        result = review_items(self.store, [(self.pending,0,'Сифон бутылочный')], 'vk')
        self.assertEqual(result['promoted'],1)
        self.assertEqual(read_json(self.vk)['items'][0]['Наименование'],'Сифон бутылочный')
        self.assertTrue(read_json(self.pending)[0]['resolved'])

    def test_dupes_checked_within_branch_and_water_skips_air_geometry(self):
        # The same descriptive name in the other branch isn't a water duplicate.
        self.store.load()
        self.store.items['ventilation'].append(item('some-air','Унитаз напольный'))
        _, results, _ = check_batch([item('new','Унитаз напольный'),item('dup','Сифон')],self.store)
        self.assertTrue(results[0]['ok'])
        self.assertEqual(results[1]['flags'][0]['type'],'possible_duplicate')
        # This air-duct tee would require length; plumbing must not use that rule.
        with patch('common.nomenclature_intake.check_tee_min_length',side_effect=AssertionError('air check called')):
            _, results, _ = check_batch([item('tee','Тройник PP-R 100х100')],self.store)
        self.assertTrue(results[0]['ok'])

    def test_repeated_or_missing_codes_and_invalid_units_stay_pending(self):
        self.run_batch([item('same','Унитаз'),item('same','Смеситель'),item('','Вентилятор'),
                        item('bad','Смеситель',ЕдиницаИзмерения={'id':1})])
        self.assertEqual(len(read_json(self.pending)),4)
        self.assertEqual(read_json(self.vk)['item_count'],1)

    def test_bulk_does_not_guess_unknowns_and_single_choice_is_remembered(self):
        self.run_batch([item('w-new','Смеситель'),item('shared','Болт М10')])
        # Put the water entry in a legacy pending file without routing metadata.
        pending=read_json(self.pending)
        pending.append({'id':10,'raw_item':item('legacy','Унитаз'),'resolved':False})
        self.pending.write_bytes(json_bytes(pending))
        result=review_items(self.store,[(self.pending,1,None),(self.pending,10,None)])
        self.assertEqual(result['promoted'],1); self.assertEqual(len(result['errors']),1)
        self.assertFalse(read_json(self.pending)[0]['resolved'])
        result=review_items(self.store,[(self.pending,1,None)],'vk')
        self.assertEqual(result['promoted'],1)
        self.assertEqual(read_json(self.store.assignments_file)['shared'],'vk')
        stats=self.run_batch([item('shared','Болт М10')])
        self.assertEqual(stats['pending_review'],0)

    def test_existing_code_cannot_be_moved_by_review(self):
        self.run_batch([item('air','Унитаз',Направление='ВК')])
        result=review_items(self.store,[(self.pending,0,None)],'vk')
        self.assertEqual(result['promoted'],0)
        self.assertFalse(read_json(self.pending)[0]['resolved'])
        self.assertEqual(read_json(self.vk)['item_count'],1)

    def test_storage_failure_rolls_back_catalog_and_queue(self):
        self.run_batch([item('shared','Болт М10')])
        before={p:p.read_bytes() for p in (self.vk,self.pending,self.db,self.existing)}
        replace=os.replace
        failed=[]
        def fail_once(src,dst):
            if Path(dst)==self.pending.resolve() and not failed:
                failed.append(True); raise OSError('simulated disk failure')
            return replace(src,dst)
        with patch('common.catalog_store.os.replace',side_effect=fail_once):
            with self.assertRaises(OSError): review_items(self.store,[(self.pending,0,None)],'vk')
        for path,data in before.items(): self.assertEqual(path.read_bytes(),data)
        self.assertFalse(self.store.assignments_file.exists())
        self.assertFalse(self.store.journal.exists())

    def test_interrupted_transaction_recovered_on_next_lock(self):
        from common.catalog_store import staged
        before=self.vk.read_bytes()
        backup=staged(self.vk,before)
        self.vk.write_text('partial')
        self.store.journal.write_bytes(json_bytes([{'target':str(self.vk),'backup':str(backup),'temporary':None}]))
        with self.store.locked(): self.store.load()
        self.assertEqual(self.vk.read_bytes(),before)
        self.assertFalse(backup.exists())

    def test_missing_or_corrupt_vk_fails_closed(self):
        before=self.db.read_bytes(); self.vk.write_text('{}')
        with self.assertRaises(ValueError): self.run_batch([item('new','Вентилятор')])
        self.assertEqual(self.db.read_bytes(),before)
        self.assertFalse(self.pending.exists())

    def test_real_cli_intake_single_bulk_and_reject(self):
        incoming=self.root/'input.json'; incoming.write_bytes(json_bytes([item('water-new','Унитаз'),
             item('a','Болт М10'),item('b','Клей'),item('c','Крепление')]))
        status=self.root/'status.json'
        code,result=self.cli('web_1c_intake_run.py','--input',incoming,'--existing',self.existing,
           '--db-file',self.db,'--pending-file',self.pending,'--token',TOKEN,'--output',self.output,'--status-file',status)
        self.assertEqual(code,0,result); self.assertTrue(read_json(status)['ok'])
        code,result=self.cli('web_1c_review_submit_run.py','--pending-file',self.pending,'--id',1,
            '--name','Болт М10','--catalog','vk','--existing',self.existing,'--db-file',self.db)
        self.assertEqual(code,0,result); self.assertEqual(result['item']['resolved_catalog'],'vk')
        selections=self.root/'selections.json'; selections.write_bytes(json_bytes([{'token':TOKEN,'id':2}]))
        code,result=self.cli('web_1c_review_bulk_run.py','--selections-file',selections,'--pending-dir',self.pending.parent,
           '--existing',self.existing,'--db-file',self.db)
        self.assertEqual(code,0,result); self.assertEqual(result['promoted'],0)
        code,result=self.cli('web_1c_review_bulk_run.py','--selections-file',selections,'--pending-dir',self.pending.parent,
           '--existing',self.existing,'--db-file',self.db,'--catalog','ventilation')
        self.assertEqual(code,0,result); self.assertEqual(result['promoted'],1)
        code,result=self.cli('web_1c_review_submit_run.py','--pending-file',self.pending,'--id',3,'--reject')
        self.assertEqual(code,0,result); self.assertTrue(result['rejected'])
        self.assertIn(('b','Клей'),self.air_rows())
        self.assertNotIn('b',[it['Код'] for it in read_json(self.vk)['items']])

    def test_simultaneous_intakes_do_not_lose_updates(self):
        processes=[]
        for number,name in enumerate(('Унитаз напольный','Смеситель настенный')):
            incoming=self.root/('input%d.json'%number)
            incoming.write_bytes(json_bytes([item('parallel%d'%number,name)]))
            command=[sys.executable,str(ROOT/'common/web_1c_intake_run.py'),'--input',str(incoming),
                '--existing',str(self.existing),'--db-file',str(self.db),'--token',TOKEN,
                '--pending-file',str(self.root/'outputs'/('parallel%d.json'%number)),
                '--output',str(self.root/('report%d.xlsx'%number))]
            processes.append(subprocess.Popen(command,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True))
        for process in processes:
            stdout,stderr=process.communicate(timeout=30)
            self.assertEqual(process.returncode,0,(stdout,stderr))
        codes={it['Код'] for it in read_json(self.vk)['items']}
        self.assertEqual(codes,{'water','parallel0','parallel1'})

    def test_token_paths_validated(self):
        with self.assertRaises(ValueError): bulk_selections([('../escape',0)],self.pending.parent)


if __name__=='__main__': unittest.main()
