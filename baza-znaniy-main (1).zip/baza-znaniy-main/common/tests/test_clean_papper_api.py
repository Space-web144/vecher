"""No real Claude API requests, credentials, or private data in these tests."""
import json
import tempfile
import unittest
from pathlib import Path

from common.web_clean_papper_api import (MAX_TEST_TOKENS, probe, safe_error, selected_model)
from common.anthropic_client import AnthropicConfigError, AnthropicConnectionError, AnthropicError


def config_file(folder, **fields):
    path = Path(folder) / "anthropic.json"
    path.write_text(json.dumps({"api_key": "sk-" + "A" * 75,
                                "model": "claude-sonnet-5",
                                "model_chat": "claude-opus-5",
                                **fields}), encoding="utf-8")
    path.chmod(0o600)
    return str(path)


class ClientDouble:
    instances = []
    def __init__(self, **kwargs):
        self.kwargs = kwargs
        self.calls = []
        self.instances.append(self)

    def messages(self, turns, **kwargs):
        self.calls.append((turns, kwargs))
        return {"type": "message", "model": self.kwargs["model"],
                "usage": {"input_tokens": 19, "output_tokens": 7}}


class CleanPapperApiTests(unittest.TestCase):
    def setUp(self):
        ClientDouble.instances.clear()

    def test_status_does_not_call_provider(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = probe(config_file(tmp), "status", ClientDouble)
            self.assertTrue(result["configured"])
            self.assertFalse(result["live_verified"])
            self.assertEqual(result["model"], "claude-opus-5")
            self.assertFalse(ClientDouble.instances)

    def test_ping_makes_one_bounded_request_without_fallback(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = probe(config_file(tmp), "ping", ClientDouble)
            self.assertTrue(result["live_verified"])
            self.assertEqual(result["input_tokens"], 19)
            self.assertEqual(result["output_tokens"], 7)
            client = ClientDouble.instances[0]
            self.assertEqual(len(client.calls), 1)
            self.assertEqual(client.kwargs["max_requests"], 1)
            self.assertEqual(client.kwargs["max_retries"], 1)
            self.assertFalse(client.kwargs["fallbacks"])
            self.assertEqual(client.calls[0][1]["max_tokens"], MAX_TEST_TOKENS)
            self.assertNotIn("api_key", str(result))

    def test_dedicated_model_takes_priority_without_touching_chat(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = config_file(tmp, model_clean_papper="claude-haiku-5-5")
            result = probe(path, "status", ClientDouble)
            self.assertEqual(result["model"], "claude-haiku-5-5")

    def test_invalid_model_is_not_forwarded(self):
        with tempfile.TemporaryDirectory() as tmp:
            path = config_file(tmp, model_clean_papper="https://evil.invalid/my-key")
            with self.assertRaises(AnthropicConfigError):
                probe(path, "ping", ClientDouble)
            self.assertFalse(ClientDouble.instances)

    def test_missing_key_fails_without_provider_call(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(AnthropicConfigError):
                probe(str(Path(tmp) / "not-found.json"), "ping", ClientDouble)

    def test_errors_are_redacted(self):
        for exc in (AnthropicConnectionError("proxy://secret:password@host"),
                    AnthropicError("sk-SECRET / internal prompt"),
                    AnthropicConfigError("secret path sk-SECRET"),
                    RuntimeError("sk-SECRET")):
            msg = str(safe_error(exc))
            self.assertNotIn("SECRET", msg)
            self.assertNotIn("password", msg)

    def test_unknown_action_fails(self):
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(ValueError):
                probe(config_file(tmp), "analyze", ClientDouble)


if __name__ == "__main__":
    unittest.main()
