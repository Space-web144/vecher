"""Synthetic, offline material-report tests; never send a project or call Claude."""
from __future__ import annotations
import io
import json
import unittest
import xml.etree.ElementTree as ET
from zipfile import ZipFile

from common.clean_papper_reports import (
    build_xlsx, list_sheets, safe_text, verify_payload, FORMS
)

NS = {"s": "http://schemas.openxmlformats.org/spreadsheetml/2006/main"}


def example():
    return {
        "schema": "clean-papper.evidence.v1", "created_at": "2026-11-23T10:00:00Z",
        "source": {
            "filename": "user-provided-synthetic.pdf", "page": 15,
            "page_count": 36, "size_bytes": 20000000,
            "crop_normalized": [0, 0, 1, 1],
        },
        "geometry": {
            "vector_paths_sampled": 8000, "colored_paths_sampled": 0,
            "sampling_limited": True,
            "section_text_candidates": [
                {"text": "600x500", "at_pdf_pt": [140.3, 270.1]},
                {"text": "Ø125", "at_pdf_pt": [240, 270]},
            ]
        },
        "vision": {
            "model": "claude-sonnet-5", "input_tokens": 4129,
            "output_tokens": 1281,
            "elements": [
                {"evidence_id": "AI-001", "type": "duct",
                 "label": "Прямой вертикальный воздуховод",
                 "dimension": "600x500", "system": "ДП7-1",
                 "confidence": "medium", "pdf_dimension_text_match": True,
                 "note": "по цветному контуру"},
                {"evidence_id": "AI-002", "type": "fan",
                 "label": "=HYPERLINK(\"https://evil.invalid\", \"click\")",
                 "dimension": "", "system": "ДП7-1",
                 "confidence": "low", "pdf_dimension_text_match": False,
                 "note": "наименование требует проверки"},
                {"evidence_id": "AI-003", "type": "label",
                 "label": "Обозначение помещения", "dimension": "",
                 "system": "", "confidence": "low",
                 "pdf_dimension_text_match": False, "note": "не материал"},
            ],
            "notes": ["Размер может относиться к соседнему помещению."]
        }
    }


class MaterialReportTests(unittest.TestCase):
    def test_eleven_sheets_and_all_source_items(self):
        names = [name for name, _, _, _, _ in list_sheets(example())]
        self.assertEqual(names, list(FORMS))
        sheets = list_sheets(example())
        self.assertEqual(len(sheets[1][3]), 2)  # excludes label from materials
        self.assertEqual(len(sheets[3][3]), 3)  # keeps all model items
        self.assertEqual(len(sheets[4][3]), 2)  # PDF source positions
        self.assertEqual(next(row[1] for row in sheets[0][3]
            if row[0] == "Достигнут лимит выборки"), "Да")

    def test_material_quantities_never_invented(self):
        materials = list_sheets(example())[1][3]
        for row in materials:
            self.assertEqual(row[9], "")  # quantity
            self.assertEqual(row[10], "")  # length in meters
            self.assertEqual(row[11], "")  # area
            self.assertEqual(row[12], "не установлен")  # no metal grade
            self.assertIn("проверки", row[13])
        self.assertEqual(list_sheets(example())[2][3][0][7], "Нет")
        self.assertIn('H5="Да"', list_sheets(example())[2][3][0][8]["formula"])

    def test_xlsx_ooxml_well_formed_with_styles_and_formula(self):
        b = build_xlsx(example())
        self.assertTrue(b.startswith(b"PK"))
        with ZipFile(io.BytesIO(b)) as z:
            files = z.namelist()
            self.assertIn("xl/styles.xml", files)
            self.assertIn("xl/workbook.xml", files)
            self.assertEqual(sum(p.startswith("xl/worksheets/sheet") for p in files), 11)
            for path in (p for p in files if p.endswith(".xml")):
                ET.fromstring(z.read(path))
            book = ET.fromstring(z.read("xl/workbook.xml"))
            names = [el.attrib["name"] for el in book.findall(".//s:sheet", NS)]
            self.assertEqual(names, list(FORMS))
            materials = ET.fromstring(z.read("xl/worksheets/sheet2.xml"))
            for cell_name in ("J5", "K5", "L5"):
                c = materials.find('.//s:c[@r="%s"]' % cell_name, NS)
                self.assertIsNotNone(c)
                t = c.find(".//s:t", NS)
                self.assertTrue(t is not None and (t.text or "") == "")
            formulas = ET.fromstring(z.read("xl/worksheets/sheet3.xml"))
            f = formulas.find('.//s:c[@r="I5"]/s:f', NS)
            self.assertIsNotNone(f)
            self.assertIn('ISNUMBER(E5)', f.text)
            self.assertIn('H5="Да"', f.text)

    def test_pdf_line_coordinates_and_manual_calibration_stay_unverified(self):
        data=example()
        data["geometry"]["vector_trace"]={
            "candidates":[{
                "candidate_id":"L001", "source_id":"pdf_path_100_line_0",
                "start_pdf_pt":[100.0,200.0],"end_pdf_pt":[200.0,200.0],
                "projected_length_pt":100.0, "dimension_text_nearby":{"text":"200x450"},
                "system_text_nearby":{"text":"В4.1-1"}
            }],
            "path_scanning":{"scanned_paths":9000}
        }
        data["geometry"]["vector_review"]={
            "calibration":{"method":"two_user_points_known_distance",
                           "mm_per_pdf_pt":40.0,"known_distance_mm":4000.0},
            "manual_links":[{
                "source_id":"pdf_path_100_line_0","ai_evidence_id":"AI-001",
                "system_manual":"В4.1-1","review_status":"manual_link_unverified"
            }]
        }
        sheets=list_sheets(data)
        self.assertEqual(sheets[5][0],"Линии PDF")
        row=sheets[5][3][0]
        self.assertEqual(row[0],"L001")
        self.assertEqual(row[1],"pdf_path_100_line_0")
        self.assertEqual(row[9],"В4.1-1")
        self.assertEqual(row[10],"AI-001")
        self.assertAlmostEqual(row[11],4.0)
        self.assertIn("не подтверждено",row[12])
        materials=sheets[1][3]
        self.assertTrue(all(x[10]=="" and x[11]=="" for x in materials))
        with ZipFile(io.BytesIO(build_xlsx(data))) as workbook:
            ET.fromstring(workbook.read("xl/worksheets/sheet6.xml"))

    def test_stage10_geometry_candidates_and_color_stats_not_billed(self):
        data=example()
        data["geometry"]["duct_geometry"]={
            "status":"unverified_geometry_candidates",
            "candidates":[{
                "candidate_id":"D001","kind":"rectangular_wall_pair",
                "stroke_color":"#ff0000","orientation":"horizontal",
                "center_start_pdf_pt":[10,20],"center_end_pdf_pt":[100,20],
                "projected_length_pt":90,"width_between_strokes_pt":15,
                "dimension_text_nearby":{"text":"200x450"},
                "source_line_ids":["pdf_path_1_line_0","pdf_path_2_line_0"],
                "physical_length_m":None
            }],
            "layer_statistics":[{
                "stroke_color":"#ff0000","stroke_width_pt":0.5,
                "dash_signature":"solid","stroke_count":2,
                "pdf_path_count":2,"total_stroke_length_pt":180
            }]
        }
        data["geometry"]["duct_review"]={
            "layer_systems":[{"stroke_color":"#ff0000","system_manual":"П1",
                              "review_status":"manual_color_hypothesis_unverified"}]
        }
        sheets=list_sheets(data)
        self.assertEqual(sheets[6][0],"Геометрия PDF")
        self.assertEqual(sheets[7][0],"Цвета PDF")
        row=sheets[6][3][0]
        self.assertEqual(row[0],"D001")
        self.assertEqual(row[10],"200x450")
        self.assertEqual(row[11],"П1")
        self.assertIn("pdf_path_2_line_0",row[12])
        self.assertIn("не подтверждено",row[13].lower())
        self.assertEqual(row[14:17],["","",""])
        self.assertEqual(sheets[7][3][0][6],"П1")
        self.assertTrue(all(x[10]=="" and x[11]=="" for x in sheets[1][3]))
        with ZipFile(io.BytesIO(build_xlsx(data))) as book:
            ET.fromstring(book.read("xl/worksheets/sheet7.xml"))
            ET.fromstring(book.read("xl/worksheets/sheet8.xml"))

    def test_stage102_trace_groups_and_no_physical_quantities(self):
        data=example()
        data["geometry"]["duct_geometry"] = {"trace_network": {
            "status": "unverified_colored_trace_candidates",
            "scanning": {
                "trace_candidates_returned": 1,
                "spatial_groups_returned": 1,
                "source_selection_incomplete": True,
                "parallel_pair_proposals": 2
            },
            "candidates": [{
                "candidate_id": "T001", "kind": "parallel_colored_strokes",
                "status": "unverified_trace_candidate",
                "orientation": "inclined", "angle_deg": 30,
                "stroke_color": "#0000ff", "spatial_group_id": "G001",
                "center_start_pdf_pt": [10, 20],
                "center_end_pdf_pt": [100, 70],
                "projected_length_pt": 103.0,
                "width_between_strokes_pt": 2.88,
                "source_line_ids": ["pdf_path_152000_line_0", "pdf_path_152001_line_0"],
                "physical_length_m": None
            }],
            "spatial_groups": [{
                "group_id": "G001", "stroke_color": "#0000ff",
                "candidate_count": 1, "bounds_pdf_pt": [10, 20, 100, 70],
                "status": "spatial_hint_unverified"
            }]
        }}
        sheets = list_sheets(data)
        self.assertEqual(sheets[8][0], "Цветные трассы")
        self.assertEqual(sheets[9][0], "Пространственные группы")
        row=sheets[8][3][0]
        self.assertEqual(row[0], "T001")
        self.assertEqual(row[1], "G001")
        self.assertEqual(row[2], "inclined")
        self.assertEqual(row[10], 2.88)
        self.assertIn("pdf_path_152000_line_0", row[13])
        self.assertEqual(row[15:18], ["", "", ""])
        self.assertEqual(sheets[9][3][0][0], "G001")
        with ZipFile(io.BytesIO(build_xlsx(data))) as book:
            ET.fromstring(book.read("xl/worksheets/sheet9.xml"))
            ET.fromstring(book.read("xl/worksheets/sheet10.xml"))
        self.assertTrue(all(x[10] == "" and x[11] == "" for x in sheets[1][3]))

    def test_formula_injection_is_rendered_as_text(self):
        b = build_xlsx(example())
        with ZipFile(io.BytesIO(b)) as z:
            text = z.read("xl/worksheets/sheet2.xml").decode("utf-8")
            self.assertIn("&apos;=HYPERLINK", text)
            self.assertNotIn("<f>HYPERLINK", text)
        self.assertTrue(safe_text("+SYSTEM").startswith("'"))

    def test_reject_invalid_or_excessive_payload(self):
        for change in ("schema", "elements", "labels", "page", "vectors", "manual_links", "ducts", "colors", "traces", "trace_groups"):
            data = example()
            if change == "schema": data["schema"] = "wrong"
            if change == "elements": data["vision"]["elements"] = [{}] * 17
            if change == "labels": data["geometry"]["section_text_candidates"] = [{}] * 46
            if change == "page": data["source"]["page"] = 0
            if change == "vectors": data["geometry"]["vector_trace"]={"candidates":[{}]*56}
            if change == "manual_links": data["geometry"]["vector_review"]={"manual_links":[{}]*56}
            if change == "ducts": data["geometry"]["duct_geometry"]={"candidates":[{}]*36}
            if change == "colors": data["geometry"]["duct_geometry"]={"layer_statistics":[{}]*13}
            if change == "traces": data["geometry"]["duct_geometry"]={"trace_network":{"candidates":[{}]*101}}
            if change == "trace_groups": data["geometry"]["duct_geometry"]={"trace_network":{"spatial_groups":[{}]*101}}
            with self.subTest(change=change):
                with self.assertRaises(ValueError):
                    verify_payload(data)


class ProjectControlWorkbookTests(unittest.TestCase):
    def test_variable_fact_columns_and_sheet_names(self):
        from pathlib import Path
        from tempfile import TemporaryDirectory
        from openpyxl import Workbook
        from common.clean_papper_statement.modules.compare.control_workbook import reference_rows
        with TemporaryDirectory() as tmp:
            path = Path(tmp)/'reference.xlsx'
            book = Workbook()
            sheet = book.active
            sheet.title = 'Вентиляция'
            sheet.append(['Позиция','Наименование и тех. хар-ка'] + [None]*8 +
                         ['Наименование системы',None,'ФАКТ','Кол-во шт.','Кол-во кв.м.'])
            sheet.append([None,'Воздуховод 250x150']+[None]*8+['В1',None,12,8,9.6])
            book.create_sheet('Содержание')
            book.save(path)
            warnings = []
            rows = list(reference_rows(path, warnings=warnings))
            self.assertEqual(len(rows),1)
            self.assertEqual(rows[0]['actual'], [12,8,9.6])
            self.assertEqual(rows[0]['system'],'В1')
            self.assertEqual(rows[0]['cells'],'M2, N2, O2')
            self.assertTrue(warnings)

    def test_unknown_fact_layout_warns_instead_of_failing(self):
        from pathlib import Path
        from tempfile import TemporaryDirectory
        from openpyxl import Workbook
        from common.clean_papper_statement.modules.compare.control_workbook import reference_rows
        with TemporaryDirectory() as tmp:
            path = Path(tmp)/'reference.xlsx'
            book = Workbook()
            book.active.append(['Неизвестная структура'])
            book.save(path)
            warnings = []
            self.assertEqual(list(reference_rows(path, warnings=warnings)), [])
            self.assertGreaterEqual(len(warnings),2)


class ProjectClaudeEvidenceTests(unittest.TestCase):
    def test_opt_in_vision_preserves_local_calculation(self):
        from pathlib import Path
        from tempfile import TemporaryDirectory
        from unittest.mock import patch
        import time
        import fitz
        from common.clean_papper_statement.run_job import claude_pages
        with TemporaryDirectory() as tmp:
            folder = Path(tmp)
            credentials = folder/'credentials.json'
            credentials.write_text('{}')
            source = folder/'album.pdf'
            with fitz.open() as doc:
                doc.new_page()
                doc.new_page()
                doc.save(source)
            album = {'pages': [
                {'pdf_page':1, 'kind':'plan','section_marks':[{'raw':'250×150'}]},
                {'pdf_page':2, 'kind':'unclassified','section_marks':[{'raw':'250×150'}]}],
                'calculation':{'segments':[]}}
            answer = {'model':'test-model','elements':[{'dimension':'250x150'}], 'notes':[]}
            with patch('common.clean_papper_pipeline.inspect_specification', return_value={'candidates':[{'first':2,'last':2}]}), patch('common.web_clean_papper_pdf.vision_request',return_value=answer) as vision:
                claude_pages(album, source, str(credentials), folder, time.monotonic())
            self.assertEqual(vision.call_count,1)
            self.assertEqual(album['claude_evidence'][0]['page'],1)
            self.assertEqual(album['claude_evidence'][0]['elements'][0]['pdf_dimension_match'],'Да')
            self.assertEqual(album['calculation']['segments'],[])


class ProjectAutomaticTakeoffTests(unittest.TestCase):
    def test_preliminary_plan_is_not_approved(self):
        from common.clean_papper_statement.modules.compare.preliminary import provisional_segments
        page={'pdf_page':7,'floor_scope':{'floors':[1,2], 'source':'printed_range'},
              'system_marks':[{'system':'В1','bbox_pt':[10,0,15,5]}],
              'section_marks':[{'id':'S007-001','raw':'250x150','width_mm':250,'height_mm':150,
                   'bbox_pt':[10,5,15,10],'context':'standalone_section_label_candidate'}],
              'geometry':{'source_role':'floor_plan','automatic_profile':{'nominal_scale':'1:100',
                   'evidence':{'scale_source':'horizontal_dimension_ticks'}}, 'candidates':[
                   {'candidate_id':'T001','source':{'bbox_pt':[0,0,100,10]},'projected_length_pt':72}]}}
        row=provisional_segments([page])[0]
        self.assertEqual(row['status'],'preliminary')
        self.assertEqual(row['system'],'В1')
        self.assertAlmostEqual(row['unit_length_m'],2.54)
        self.assertAlmostEqual(row['length_m'],5.08)
        self.assertAlmostEqual(row['surface_m2'],4.064)
        self.assertIsNone(row['pieces'])
        self.assertEqual(provisional_segments([page],[{'segment_id':'manual','plan_page':7,'plan_candidate_id':'T001'}],[{'segment_id':'manual','sources':[]}]),[])
        page['floor_scope']={}
        self.assertIsNone(provisional_segments([page])[0]['length_m'])

    def test_zero_reference_rows_is_reported(self):
        from tempfile import TemporaryDirectory
        from pathlib import Path
        from openpyxl import Workbook
        from common.clean_papper_statement.modules.compare.control_workbook import reference_rows
        with TemporaryDirectory() as tmp:
            p=Path(tmp)/'reference.xlsx'
            b=Workbook()
            b.active.append(['Позиция','Наименование','ФАКТ','Кол-во шт.','Кол-во кв.м.'])
            b.save(p)
            warnings=[]
            self.assertEqual(list(reference_rows(p,warnings=warnings)),[])
            self.assertTrue(any('ни одной строки' in w for w in warnings))

    def test_reference_positions_without_fact_headers(self):
        from tempfile import TemporaryDirectory
        from pathlib import Path
        from openpyxl import Workbook
        from common.clean_papper_statement.modules.compare.control_workbook import reference_rows
        with TemporaryDirectory() as tmp:
            p=Path(tmp)/'reference.xlsx'
            b=Workbook()
            b.active.append(['Позиция','Наименование','Система'])
            b.active.append([1,'Воздуховод 250x150','В1'])
            b.save(p)
            warnings=[]
            rows=list(reference_rows(p,warnings=warnings))
            self.assertEqual(len(rows),1)
            self.assertEqual(rows[0]['actual'],[None,None,None])
            self.assertTrue(warnings)


class ProjectOptionalReferenceTests(unittest.TestCase):
    def test_pdf_only_statement_worker(self):
        import json
        import subprocess
        import sys
        from pathlib import Path
        from tempfile import TemporaryDirectory
        import fitz
        from openpyxl import load_workbook
        worker = Path(__file__).resolve().parents[1] / 'clean_papper_statement' / 'run_job.py'
        with TemporaryDirectory() as tmp:
            folder = Path(tmp)
            with fitz.open() as doc:
                doc.new_page()
                doc.save(folder/'album.pdf')
            result = subprocess.run([sys.executable, str(worker), str(folder)], capture_output=True, text=True, timeout=90)
            state = json.loads((folder/'state.json').read_text(encoding='utf-8'))
            self.assertEqual(state['phase'], 'done', (state, result.stderr))
            self.assertTrue((folder/'statement.xlsx').is_file())
            self.assertFalse((folder/'reference.xlsx').exists())
            from contextlib import closing
            with closing(load_workbook(folder/'statement.xlsx', read_only=True)) as book:
                self.assertIn('Ведомость',book.sheetnames)
                self.assertNotIn('Сверка с эталоном',book.sheetnames)
                summary=dict(book['Сводка'].values)
                self.assertIn('Не запрошена',summary['Сверка с эталоном'])

    def test_preliminary_rows_without_reference(self):
        from common.clean_papper_statement.modules.compare.project_statement import workbook
        page={'pdf_page':1,'kind':'plan','title_evidence':[], 'floor_scope':{'floors':[1], 'source':'printed_floor'},
              'system_marks':[{'system':'В1','bbox_pt':[10,0,15,5]}], 'section_marks':[], 'elevation_marks':[],
              'geometry':{'status':'inspected','source_role':'floor_plan','automatic_profile':{'nominal_scale':'1:100',
                   'evidence':{'scale_source':'horizontal_dimension_ticks'}},'candidates':[
                   {'candidate_id':'T001','source':{'bbox_pt':[0,0,100,10]},'source_stroke_ids':['a','b'],'projected_length_pt':72}]}}
        data={'source_pdf_sha256':'a'*64,'page_count':1,'pages':[page], 'calculation':{'segments':[]}}
        book=workbook(data,None,None,'test.pdf')
        self.assertEqual(book['Ведомость'].max_row,2)
        self.assertAlmostEqual(book['Ведомость']['G2'].value,2.54)
        self.assertNotIn('Сверка с эталоном',book.sheetnames)
        self.assertNotIn('Предварительная сверка',book.sheetnames)
        self.assertIn('По системам',book.sheetnames)
        self.assertEqual(data.get('processing_issues'),[])
        book.close()


class ProjectConnectedTakeoffTests(unittest.TestCase):
    def test_propagation_and_conflicting_seeds(self):
        from common.clean_papper_statement.modules.compare.connectivity import propagated, topology
        def row(cid,a,b,width=5):
            return {'candidate_id':cid,'center_start_pdf_pt':a,'center_end_pdf_pt':b,
                    'stroke_color':'#ff0000','width_between_strokes_pt':width}
        a=row('A',[0,0],[50,0]); b=row('B',[50,0],[100,0]); c=row('C',[100,0],[150,0])
        crossing=row('X',[75,-20],[75,20])
        rows=[a,b,c,crossing]
        self.assertEqual(len(topology(rows)),2)
        self.assertEqual(propagated(rows,{'A':'В1'},str),{'B':'В1','C':'В1'})
        self.assertEqual(propagated(rows,{'A':'В1','C':'В2'},str),{})
        self.assertEqual(propagated(rows,{'A':'В1'},str,blocked={'B'}),{})
        c['width_between_strokes_pt']=10
        self.assertEqual(propagated(rows,{'A':'250x150'},str,section=True),{'B':'250x150'})

    def test_fitting_counts_only_explicit_floors(self):
        from common.clean_papper_statement.modules.compare.connectivity import fitting_candidates
        a={'candidate_id':'A','center_start_pdf_pt':[0,0],'center_end_pdf_pt':[50,0],'stroke_color':'#f00','width_between_strokes_pt':5}
        b={'candidate_id':'B','center_start_pdf_pt':[50,0],'center_end_pdf_pt':[50,50],'stroke_color':'#f00','width_between_strokes_pt':5}
        p={'pdf_page':1,'kind':'plan','geometry':{'candidates':[a,b]},'floor_scope':{'source':'printed_range','floors':[1,2,3]}}
        s=[{'system':'В1','sources':[{'pdf_page':1,'candidate_id':cid}]} for cid in ('A','B')]
        result=fitting_candidates([p],s)
        self.assertEqual(result[0]['kind'],'Отвод')
        self.assertEqual(result[0]['quantity'],3)
        p['floor_scope']['source']='inferred_between_plans'
        self.assertIsNone(fitting_candidates([p],s)[0]['quantity'])

    def test_printed_scale_and_no_inferred_multiplier(self):
        from common.clean_papper_statement.modules.compare.preliminary import provisional_segments
        p={'pdf_page':1,'floor_scope':{'source':'inferred_between_plans','floors':list(range(1,21))},
           'geometry':{'source_role':'floor_plan','automatic_profile':{'nominal_scale':'1:100','evidence':{'scale_source':'printed_scale'}},
                       'candidates':[{'candidate_id':'T001','source':{'bbox_pt':[0,0,72,8]},'projected_length_pt':72}]}}
        s=provisional_segments([p])[0]
        self.assertAlmostEqual(s['unit_length_m'],2.54)
        self.assertIsNone(s['length_m'])
        self.assertEqual(s['sources'][0]['possible_floor_count'],20)

    def test_claude_permanent_error_is_safe_and_stops(self):
        from pathlib import Path
        from tempfile import TemporaryDirectory
        from unittest.mock import patch
        from common.anthropic_client import AnthropicError
        from common.clean_papper_statement.run_job import claude_pages
        import fitz, time
        with TemporaryDirectory() as tmp:
            folder=Path(tmp); source=folder/'album.pdf'; creds=folder/'creds.json'
            creds.write_text('{}')
            with fitz.open() as doc:
                doc.new_page(); doc.new_page(); doc.save(source)
            data={'pages':[{'pdf_page':i,'kind':'plan'} for i in (1,2)],
                  'specification_inventory':{'candidates':[]}}
            with patch('common.web_clean_papper_pdf.vision_request',side_effect=AnthropicError('private text',status=401)) as mock:
                claude_pages(data,source,str(creds),folder,time.monotonic())
            self.assertEqual(mock.call_count,1)
            self.assertIn('401',data['claude_diagnostics'][0]['message'])
            self.assertNotIn('private text',str(data['processing_issues']))

    def test_design_category(self):
        from common.clean_papper_statement.modules.compare.design_specification import category
        self.assertEqual(category('Клапан противопожарный'),'Оборудование')
        self.assertEqual(category('Отвод 90°'),'Фасонные изделия')
        self.assertEqual(category('Воздуховод прямоугольный'),'Воздуховоды')

if __name__ == "__main__":
    unittest.main()
