"""Regression tests for reconciled PDF handling and assistant fallback contracts."""
import os
from pathlib import Path
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest.mock import patch

from common import agent_files


class PdfReconciliationTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.path = Path(self.tmp.name) / "sample.pdf"
        self.path.write_bytes(b"%PDF-1.4 test")
        self.workdir = self.tmp.name

    def document(self, text="Text", repaired=False, pages=1):
        doc = SimpleNamespace(
            needs_pass=False,
            page_count=pages,
            is_repaired=repaired,
            close=lambda: None,
        )
        page = SimpleNamespace(get_text=lambda: text)
        # _prepare_pdf calls enumerate(doc), so use an iterable wrapper.
        class Document:
            def __init__(self):
                self.needs_pass = doc.needs_pass
                self.page_count = doc.page_count
                self.is_repaired = doc.is_repaired
                self.closed = False

            def __iter__(self):
                return iter([page] * pages)

            def close(self):
                self.closed = True
        return Document()

    def prepare(self, doc, size=None, raster_failure=None):
        def rasterize(_doc, destination):
            if raster_failure:
                raise raster_failure
            Path(destination).write_bytes(b"%PDF-1.4 raster")
        fake_fitz = SimpleNamespace(open=lambda _: doc)
        with patch.dict(sys.modules, {"fitz": fake_fitz}):
            with patch.object(agent_files.os.path, "getsize",
                              return_value=size if size is not None else 1024):
                with patch.object(agent_files, "_rasterize", side_effect=rasterize) as raster:
                    result = agent_files._prepare_pdf(
                        str(self.path), self.path.name, self.workdir)
        return result, raster

    def test_regular_small_pdf_remains_direct(self):
        (parts, info), raster = self.prepare(self.document("readable text"))
        self.assertEqual(parts[0]["path"], str(self.path))
        self.assertEqual(info["kind"], "pdf")
        raster.assert_not_called()

    def test_small_scan_is_rasterized(self):
        (parts, info), raster = self.prepare(self.document(""))
        self.assertEqual(len(parts), 1)
        self.assertTrue(parts[0]["path"].endswith("pages.pdf"))
        self.assertIn("скан", info["note"])
        raster.assert_called_once()

    def test_repaired_pdf_preserves_page_text(self):
        (parts, info), raster = self.prepare(self.document("Recovered", repaired=True))
        self.assertEqual(len(parts), 2)
        self.assertTrue(parts[0]["path"].endswith("pages.pdf"))
        self.assertIn("Recovered", Path(parts[1]["path"]).read_text())
        raster.assert_called_once()

    def test_large_pdf_is_rasterized(self):
        (parts, info), raster = self.prepare(
            self.document("Readable"), size=agent_files.PDF_DIRECT_MAX_BYTES + 1)
        self.assertEqual(len(parts), 2)
        self.assertIn("сжат", info["note"])
        raster.assert_called_once()

    def test_small_failed_rasterization_falls_back_to_original(self):
        (parts, _), _raster = self.prepare(
            self.document(""), raster_failure=RuntimeError("render failure"))
        self.assertEqual(parts[0]["path"], str(self.path))

    def test_large_failed_rasterization_propagates(self):
        with self.assertRaisesRegex(RuntimeError, "render failure"):
            self.prepare(self.document(""), size=agent_files.PDF_DIRECT_MAX_BYTES + 1,
                         raster_failure=RuntimeError("render failure"))

    def test_page_limit_uses_container_fallback_exception(self):
        with patch.dict(sys.modules, {"fitz": SimpleNamespace(
                open=lambda _: self.document("Text", pages=agent_files.PDF_MAX_PAGES + 1))}):
            with self.assertRaises(agent_files.DirectAttachmentLimit):
                agent_files._prepare_pdf(str(self.path), self.path.name, self.workdir)

    def test_main_attachment_contract_preserved(self):
        self.assertTrue(issubclass(agent_files.DirectAttachmentLimit,
                                   agent_files.AttachmentError))
        self.assertEqual(agent_files.container_info()["kind"], "container")
        with patch.object(agent_files, "_read_text", return_value="x" * (
                agent_files.TEXT_MAX_CHARS + 1)):
            with self.assertRaises(agent_files.DirectAttachmentLimit):
                agent_files.prepare(str(self.path), "huge.txt", self.workdir)


if __name__ == "__main__":
    unittest.main()
