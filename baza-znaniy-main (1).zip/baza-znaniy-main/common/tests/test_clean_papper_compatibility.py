"""Regression tests for alternative PDF encoding and headerless specification sheets."""
import unittest
from types import SimpleNamespace
from common.clean_papper_album_worker.modules.pdf.text_recovery import recover_words
from common.clean_papper_pipeline import inspect_specification, header_evidence, HEADER_TOKENS


def word(text, x=10, y=10, w=20, n=0):
    return (x, y, x+w, y+10, text, 0, 0, n)


class FakePage:
    rotation = 0
    def __init__(self, text, words, width=1000):
        import fitz
        self.rect = fitz.Rect(0, 0, width, 800)
        self.derotation_matrix = fitz.Matrix(1, 1)
        self.text, self.words = text, words

    def get_text(self, kind):
        return self.words if kind == 'words' else self.text


HEADER = 'Наименование и техническая характеристика\nЕд. измерения\nКол-во\nТип, марка, обозначение'


def header():
    return FakePage(HEADER, [word('Ед.', 740, 40), word('Кол-во', 790, 40)])


def continuation(n, qty_x=790, width=1000, rows=2):
    words = [word(str(n), 960, 770)]
    for i in range(rows):
        words += [word('м.', 740, 100+30*i), word('12,5', qty_x, 100+30*i)]
    return FakePage('Continuation', words, width)


class CompatibilityTests(unittest.TestCase):
    def test_recovery_keeps_source_and_coordinates(self):
        raw = ['Ïëàí', 'âåíòèëÿöèè', 'ÂÄ1', '300õ300', 'Ø125', 'ROOF-H', 'В3']
        words = [word(v, n=i) for i,v in enumerate(raw)]
        fixed, report = recover_words(words)
        self.assertEqual([w[4] for w in fixed], ['План', 'вентиляции', 'ВД1', '300х300', 'Ø125', 'ROOF-H', 'В3'])
        self.assertEqual(report['changed_word_count'], 4)
        self.assertEqual(report['corrections'][0]['raw'], raw[0])
        self.assertEqual(report['corrections'][0]['word_id'], [0,0,0])
        self.assertEqual([w[:4] for w in fixed], [w[:4] for w in words])

    def test_no_unanchored_repair(self):
        for raw in [['café', 'Müller', 'Ø100'], ['Â1', '300õ300'], ['План', 'вентиляции', '300х300']]:
            words = [word(v) for v in raw]
            self.assertEqual(recover_words(words)[0], words)
            self.assertEqual(recover_words(words)[1]['changed_word_count'], 0)

    def test_alias_and_headerless_continuation(self):
        self.assertEqual(header_evidence(HEADER), list(HEADER_TOKENS))
        out = inspect_specification([header(), continuation(2), continuation(3), continuation(4, width=500)])
        self.assertEqual(out['candidates'], [{'first':1, 'last':3, 'page_count':3}])
        self.assertEqual(out['observations'][-1]['printed_sheet_number'], 3)

    def test_wrong_number_or_columns_or_missing_rows_stop(self):
        for page in [continuation(5), continuation(2, qty_x=700), continuation(2, rows=1)]:
            self.assertEqual(inspect_specification([header(), page])['candidates'][0]['last'], 1)

    def test_does_not_merge_separate_header_runs(self):
        result = inspect_specification([header(), continuation(2), header(), continuation(2)])
        self.assertEqual([(r['first'],r['last']) for r in result['candidates']], [(1,2),(3,4)])


if __name__ == '__main__':
    unittest.main()