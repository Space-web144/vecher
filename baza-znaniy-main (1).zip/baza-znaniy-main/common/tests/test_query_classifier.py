# -*- coding: utf-8 -*-
"""Тесты common.query_classifier."""

import unittest

from common.query_classifier import classify_query


class ClassifyQueryTests(unittest.TestCase):

    def test_ventilation_duct(self):
        system, _confidence = classify_query("Воздуховод круглый Ø200")
        self.assertEqual(system, "Вентиляция")

    def test_krestovina_recognized_as_ventilation(self):
        # Добавлено при слиянии номенклатур — оригинал matching_system это
        # слово не знал, и такие позиции уходили в "default".
        system, _confidence = classify_query(
            "Крестовина прямоугольная из оцинк. стали кл.В (400х300)-(250х200)-(150х200)-(400х300)")
        self.assertEqual(system, "Вентиляция")

    def test_heating_radiator(self):
        system, _confidence = classify_query("Радиатор стальной панельный")
        self.assertEqual(system, "Отопление")

    def test_unrecognized_returns_default(self):
        system, confidence = classify_query("Совершенно неизвестная позиция XYZ")
        self.assertEqual(system, "default")
        self.assertEqual(confidence, 0.0)


if __name__ == "__main__":
    unittest.main()
