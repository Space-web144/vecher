# -*- coding: utf-8 -*-
"""Тесты common.merge_nomenclature."""

import unittest

from common.merge_nomenclature import merge_nomenclature


BASE = [
    {"id": 1, "code": "БП-001", "name": "Воздуховод круглый Ø200", "search_text": "Воздуховод круглый Ø200",
     "system": "Вентиляция", "systems": "Вентиляция", "unit": "шт"},
    {"id": 2, "code": "БП-002", "name": "Гайка М8", "search_text": "Гайка М8",
     "system": "Вентиляция", "systems": "Вентиляция", "unit": "шт"},
]


class MergeNomenclatureTests(unittest.TestCase):

    def test_existing_name_not_duplicated(self):
        merged, stats = merge_nomenclature(BASE, ["Воздуховод круглый Ø200"])
        self.assertEqual(len(merged), 2)
        self.assertEqual(stats["added_count"], 0)

    def test_existing_name_with_extra_whitespace_not_duplicated(self):
        merged, stats = merge_nomenclature(BASE, ["Воздуховод   круглый Ø200 "])
        self.assertEqual(stats["added_count"], 0)

    def test_new_name_added_with_generated_id_and_code(self):
        merged, stats = merge_nomenclature(BASE, ["Отвод 90° Ø200"], code_prefix="VS")
        self.assertEqual(stats["added_count"], 1)
        new_item = merged[-1]
        self.assertEqual(new_item["id"], 3)
        self.assertEqual(new_item["code"], "VS-00000001")
        self.assertEqual(new_item["name"], "Отвод 90° Ø200")
        self.assertEqual(new_item["search_text"], "Отвод 90° Ø200")

    def test_new_name_gets_classified_system(self):
        merged, _stats = merge_nomenclature(BASE, ["Радиатор стальной панельный"])
        self.assertEqual(merged[-1]["system"], "Отопление")

    def test_duplicate_within_input_batch_added_once(self):
        merged, stats = merge_nomenclature(BASE, ["Отвод 90° Ø200", "Отвод 90° Ø200"])
        self.assertEqual(stats["added_count"], 1)
        self.assertEqual(stats["skipped_count"], 1)

    def test_base_items_unmodified(self):
        merge_nomenclature(BASE, ["Отвод 90° Ø200"])
        self.assertEqual(len(BASE), 2)


if __name__ == "__main__":
    unittest.main()
