import unittest
from pathlib import Path
import sys
import fitz

# Import the isolated album worker in repository CI or the standalone local fixture.
worker = Path(__file__).resolve().parents[1] / 'clean_papper_album_worker'
if worker.is_dir():
    sys.path.insert(0, str(worker))
    from modules.pdf.project_profiler import build_project_profile, representative_pages
else:
    from project_profiler import build_project_profile, representative_pages


class ProjectProfilerTests(unittest.TestCase):
    def profile(self, colors, kinds, image=False):
        with fitz.open() as doc:
            pages = []
            for i, (color, kind) in enumerate(zip(colors, kinds), 1):
                page = doc.new_page(width=595 if i % 2 else 842, height=842)
                if image:
                    pix = fitz.Pixmap(fitz.csRGB, fitz.IRect(0, 0, 10, 10), False)
                    pix.clear_with(220)
                    page.insert_image(fitz.Rect(20,20,300,300), pixmap=pix)
                else:
                    page.draw_line((20, 50), (200, 50), color=color, width=.7)
                    page.insert_text((30, 40), 'Scale 1:75')
                pages.append({'pdf_page': i, 'kind': kind, 'has_extracted_text': not image,
                              'page_bounds_pt': list(page.rect)})
            return build_project_profile(doc, pages, {'status':'not_found'}, {'candidates':[]}, 'a'*64)

    def test_monochrome_not_declared_color_mapping(self):
        p = self.profile([(0,0,0)], ['plan'])
        self.assertIn('neutral_strokes_only_in_inspected_drawings', p['compatibility_warnings'])
        self.assertIsNone(p['measurement_profile']['system_color_mapping'])
        self.assertEqual(p['sampling']['pages'][0]['printed_scale_candidates'], [75])
        self.assertFalse(p['measurement_profile']['scale_verified'])

    def test_chromatic_different_formats(self):
        p = self.profile([(1,0,0), (0,0,1)], ['plan','axonometry'])
        self.assertEqual(p['sampling']['drawing_sample_stroke_colors']['chromatic'], 2)
        self.assertEqual(len(p['page_formats_mm']), 2)
        self.assertFalse(p['measurement_profile']['automatic_takeoff_ready'])

    def test_image_only_is_not_treated_as_vector(self):
        p = self.profile([(0,0,0)], ['unclassified'], image=True)
        self.assertEqual(p['sampling']['representation_counts'], {'image_without_text':1})
        self.assertIn('raster_content_requires_review', p['compatibility_warnings'])
        self.assertIn('ventilation_sheets_not_identified', p['compatibility_warnings'])

    def test_sampling_bounded_and_not_fixed_to_reference_album(self):
        pages = [{'pdf_page':i, 'kind':'plan' if i%2 else 'axonometry'} for i in range(1,81)]
        sample = representative_pages(pages)
        self.assertLessEqual(len(sample), 6)
        self.assertEqual(len(sample), len(set(sample)))
        self.assertTrue(any(i%2 for i in sample))
        self.assertTrue(any(not i%2 for i in sample))

    def test_unknown_plan_is_not_assumed_from_colored_graphics(self):
        p = self.profile([(1,0,0)], ['unclassified'])
        self.assertIn('ventilation_sheets_not_identified', p['compatibility_warnings'])
        self.assertEqual(p['sampling']['drawing_sample_stroke_colors'], {})

if __name__ == '__main__':
    unittest.main()