"""Stage 10: deterministic PDF-stroke grouping tests, without user projects or AI."""
import unittest
from common.clean_papper_ducts import extract_duct_geometry


class FakePage:
    rect = (0.0, 0.0, 500.0, 400.0)


def drawing(lines, rgb=(0, 0, 1), width=.5, dash='solid'):
    return {'items':[('l', a, b) for a,b in lines], 'color':rgb,
            'width':width, 'dashes':dash}


def horizontal(y, lo, hi):
    return ((lo, y), (hi, y))


def vertical(x, lo, hi):
    return ((x, lo), (x, hi))


def scan(drawings, rect=(0, 0, 500, 400), labels=None, **kwargs):
    return extract_duct_geometry(FakePage(), rect, labels or [],
                                 drawings=drawings, **kwargs)


class DuctGeometryTests(unittest.TestCase):
    def test_pair_of_rectangular_walls_with_coaxial_merge(self):
        drawings=[
            drawing([horizontal(60,20,100),horizontal(60,100.03,210)],rgb=(1,0,0)),
            drawing([horizontal(80,30,210)],rgb=(1,0,0))
        ]
        got=scan(drawings, labels=[{'text':'400x200','at_pdf_pt':[120,69]}])
        matches=[x for x in got['candidates'] if x['kind']=='rectangular_wall_pair']
        self.assertEqual(len(matches),1)
        c=matches[0]
        self.assertEqual(c['candidate_id'],'D001')
        self.assertAlmostEqual(c['projected_length_pt'],180,places=1)
        self.assertAlmostEqual(c['width_between_strokes_pt'],20)
        self.assertEqual(c['stroke_color'],'#ff0000')
        self.assertEqual(c['center_start_pdf_pt'],[30,70])
        self.assertEqual(c['center_end_pdf_pt'],[210,70])
        self.assertTrue(c['dimension_text_nearby'])
        self.assertEqual(len(c['source_line_ids']),3)
        self.assertEqual(len(c['source_wall_segments_page_norm']),2)
        self.assertIsNone(c['physical_length_m'])
        self.assertFalse(c['scale_verified'])
        self.assertFalse(c['section_verified'])
        self.assertTrue(c['manual_review_required'])
        self.assertTrue(got['layer_statistics'])
        self.assertEqual(got['layer_statistics'][0]['system'],'unassigned')

    def test_different_colored_lines_do_not_form_duct(self):
        got=scan([
            drawing([horizontal(40,30,180)],rgb=(1,0,0)),
            drawing([horizontal(55,30,180)],rgb=(0,0,1)),
        ])
        self.assertEqual(got['candidates'], [])
        self.assertEqual(len(got['layer_statistics']),2)

    def test_rectangular_pair_requires_overlap_and_separation(self):
        got=scan([
            drawing([horizontal(40,20,90),horizontal(80,20,90)]),
            drawing([horizontal(48,100,155),horizontal(55,170,220)]),
        ])
        self.assertFalse(got['candidates'])

    def test_dash_chain_with_two_walls_identifies_round_candidate(self):
        drawings=[
            drawing([horizontal(100,10,15),horizontal(100,20,25),
                     horizontal(100,30,35)],rgb=(0,0,1),dash='[5 5] 0'),
            drawing([horizontal(95,10,35), horizontal(105,10,35)],rgb=(0,0,1))
        ]
        got=scan(drawings)
        kinds=[x['kind'] for x in got['candidates']]
        self.assertIn('round_dashed_axis_with_walls',kinds)
        self.assertNotIn('rectangular_wall_pair',kinds)
        round_item=next(x for x in got['candidates'] if x['kind']=='round_dashed_axis_with_walls')
        self.assertAlmostEqual(round_item['dash_median_gap_pt'],5)
        self.assertEqual(round_item['width_between_strokes_pt'],10)
        self.assertIsNone(round_item['physical_length_m'])

    def test_short_dash_gaps_are_not_round_axis(self):
        got=scan([
            drawing([horizontal(100,10,15),horizontal(100,17.5,22.5),
                     horizontal(100,25,30)]),
            drawing([horizontal(95,10,30),horizontal(105,10,30)])
        ])
        self.assertNotIn('round_dashed_axis_with_walls',[x['kind'] for x in got['candidates']])

    def test_does_not_infer_diagonal_duct(self):
        got=scan([
            drawing([((10,10),(140,100)), ((20,20),(150,110))])
        ])
        self.assertEqual(got['candidates'], [])
        self.assertEqual(got['scanning']['inclined_segments_excluded'],2)

    def test_vertical_wall_pair(self):
        got=scan([
            drawing([vertical(70,40,150),vertical(85,45,170)]),
        ])
        c=got['candidates'][0]
        self.assertEqual(c['orientation'],'vertical')
        self.assertEqual(c['center_start_pdf_pt'],[77.5,45])
        self.assertEqual(c['center_end_pdf_pt'],[77.5,150])
        self.assertAlmostEqual(c['projected_length_pt'],105)

    def test_crop_clips_source_segments(self):
        got=scan([drawing([horizontal(50,0,300),horizontal(70,0,300)])],
                 rect=(80,35,160,90))
        c=got['candidates'][0]
        self.assertEqual(c['center_start_pdf_pt'],[80,60])
        self.assertEqual(c['center_end_pdf_pt'],[160,60])
        self.assertAlmostEqual(c['center_start_page_norm'][0],.16)
        self.assertAlmostEqual(c['center_end_page_norm'][0],.32)

    def test_explicit_truncation_on_path_budget(self):
        got=scan([
            drawing([horizontal(60,20,150)]),
            drawing([horizontal(75,20,150)]),
        ],max_paths=1)
        self.assertTrue(got['scanning']['scan_truncated'])
        self.assertEqual(got['scanning']['pdf_paths_scanned'],1)

    def test_no_quantities_and_documented_assumptions(self):
        got=scan([
            drawing([horizontal(60,20,150),horizontal(75,20,150)]),
        ])
        self.assertEqual(got['status'],'unverified_geometry_candidates')
        self.assertEqual(got['assumptions']['nominal_pdf_scale'],'unknown (unverified)')
        self.assertNotIn('total_length_m',got)
        self.assertNotIn('duct_count',got)
        self.assertNotIn('material_surface_m2',got)
        self.assertTrue(got['limitations'])


if __name__=='__main__':
    unittest.main()
