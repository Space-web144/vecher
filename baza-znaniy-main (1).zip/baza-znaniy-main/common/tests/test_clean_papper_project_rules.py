import unittest
from pathlib import Path
import sys
from types import SimpleNamespace

worker = Path(__file__).resolve().parents[1] / 'clean_papper_album_worker'
if worker.is_dir():
    sys.path.insert(0, str(worker))
    from modules.pdf.project_rules import block_rules, inspect_project_rules
else:
    from project_rules import block_rules, inspect_project_rules


def page(*texts):
    return SimpleNamespace(get_text=lambda mode: [(1, i*20, 100, i*20+10, text, i, 0) for i, text in enumerate(texts)])


def inventory(first, last):
    return {'candidates': [{'first': first, 'last': last}]}


class ProjectRulesTests(unittest.TestCase):
    def test_general_note_three_distinct_scopes(self):
        raw = ('Металл на фасонные изделия воздуховодов учтены в длинне воздуховодов запасом 10%,\n'
               'по материалам изоляции труб 10%, по материалам изоляции воздуховодов 30%')
        out = inspect_project_rules([page(raw)], inventory(1,1), 'a'*64)
        self.assertEqual({(r['basis'], r['value']) for r in out['summaries']},
                         {('fittings_included_in_duct_length',10), ('pipe_insulation',10), ('duct_insulation',30)})
        self.assertTrue(out['double_count_risk'])
        self.assertFalse(out['automatic_application'])
        self.assertTrue(all(not r['approved'] and not r['applied'] for r in out['evidence']))
        self.assertEqual(out['evidence'][0]['source']['raw_text'], raw)
        self.assertEqual(out['evidence'][0]['source']['bbox_pt'], [1,0,100,10])

    def test_row_factors_not_combined_or_global(self):
        out = inspect_project_rules([page('с запасом 1,1 к длине прямых участков', 'с запасом 1.1 к длине прямых участков', 'с запасом 1.4 к площади прямых участков и фитингов')], inventory(1,1), 'b'*64)
        groups = {r['basis']:r for r in out['summaries']}
        self.assertEqual(groups['straight_length']['occurrence_count'], 2)
        self.assertEqual(groups['straight_length']['value'], 1.1)
        self.assertEqual(groups['straight_and_fittings_area']['value'],1.4)
        self.assertTrue(all(r['scope']=='row_note_candidate' for r in out['summaries']))
        self.assertFalse(out['double_count_risk'])

    def test_excludes_passport_and_no_range(self):
        doc=[page('с запасом 1.1 к длине прямых участков'), page('Запас по поверхности теплообмена 18.19 %')]
        self.assertEqual(inspect_project_rules(doc, inventory(1,1),'x')['allowance_block_count'],1)
        self.assertEqual(inspect_project_rules(doc, {'candidates':[]},'x')['status'],'no_specification_range')

    def test_incomplete_row_basis_and_unrelated_percent(self):
        out=inspect_project_rules([page('с запасом 1.1 к', 'Запас по поверхности теплообмена 18.19 %', 'Материал изоляции труб 10%')], inventory(1,1),'x')
        self.assertEqual(out['unresolved_block_count'],2)
        self.assertEqual(out['summaries'][0]['basis'],'unresolved_row_basis')
        self.assertEqual(out['rule_occurrence_count'],1)

    def test_distinct_basis_and_no_percent_as_factor(self):
        self.assertEqual(block_rules('с запасом 1.1 к длине прямых и гнутых участков')[0]['basis'],'straight_and_bent_length')
        self.assertEqual(block_rules('с запасом 10% к длине прямых участков'),[])
        self.assertEqual(block_rules('с запасом 0.1 к длине прямых участков'),[])

    def test_split_native_note_requires_unique_aligned_blocks(self):
        blocks = [(100,100,170,112,'с запасом 1.1 к',0,0),
                  (105,116,165,128,'длине прямых',1,0),
                  (115,132,155,144,'участков',2,0)]
        def run(rows):
            return inspect_project_rules([SimpleNamespace(get_text=lambda mode: rows)], inventory(1,1), 'x')
        good = run(blocks)
        self.assertEqual(good['reconstructed_note_count'],1)
        self.assertEqual(good['summaries'][0]['basis'],'straight_length')
        self.assertEqual(len(good['evidence'][0]['source']['fragments']),3)
        ambiguous = run(blocks + [(100,116,170,128,'другой текст',3,0)])
        self.assertEqual(ambiguous['reconstructed_note_count'],0)
        self.assertEqual(ambiguous['unresolved_block_count'],1)
        bad = run([blocks[0],(205,116,265,128,'длине прямых',1,0),blocks[2]])
        self.assertEqual(bad['reconstructed_note_count'],0)

    def test_overlapping_ranges_do_not_duplicate_pages(self):
        out=inspect_project_rules([page('с запасом 1.1 к длине прямых участков')], {'candidates':[{'first':1,'last':1},{'first':1,'last':1}]},'x')
        self.assertEqual(out['rule_occurrence_count'],1)

if __name__=='__main__': unittest.main()