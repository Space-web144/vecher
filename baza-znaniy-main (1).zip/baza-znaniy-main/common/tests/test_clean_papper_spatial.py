import unittest
try:
    from common.clean_papper_spatial import spatial_inventory
except ModuleNotFoundError:
    from clean_papper_spatial import spatial_inventory


def p(box, n=1):
    return {'rect':box,'items':[None]*n}


class SpatialTests(unittest.TestCase):
    def test_conservation_and_late_path(self):
        records=[p((1,1,2,2))]*60000+[p((90,90,91,91))]
        out=spatial_inventory(records,(0,0,100,100),2)
        self.assertEqual(out['source_paths_examined'],60001)
        self.assertEqual(sum(t['owned_paths'] for t in out['tiles']),60001)
        self.assertEqual(out['tiles'][-1]['owned_paths'],1)
        self.assertTrue(out['tiles'][0]['requires_subdivision'])

    def test_crossing_and_boundary(self):
        out=spatial_inventory([p((0,50,100,50),2)],(0,0,100,100),2)
        self.assertEqual(sum(t['owned_paths'] for t in out['tiles']),1)
        self.assertEqual([t['intersecting_paths'] for t in out['tiles']],[1]*4)
        self.assertEqual([t['path_items_upper_bound'] for t in out['tiles']],[2]*4)

    def test_invalid_and_outside_are_not_silently_dropped(self):
        out=spatial_inventory([p(None),p((1,1,float('nan'),2)),p((110,110,120,120)),p((1,1,2,2))],(0,0,100,100))
        self.assertEqual(out['unlocated_paths'],2)
        self.assertEqual(out['outside_paths'],1)
        self.assertEqual(out['region_paths_located'],1)
        self.assertNotEqual(out['status'],'complete_bbox_inventory')

    def test_crop_and_large_multi_item_path(self):
        out=spatial_inventory([p((-10,-10,110,110),35001)],(20,20,80,80),2)
        self.assertEqual(out['region_path_items'],35001)
        self.assertEqual(out['tiles_requiring_subdivision'],4)

    def test_invalid_arguments(self):
        for grid in (0,17,True):
            with self.assertRaises(ValueError): spatial_inventory([], (0,0,1,1),grid)
        with self.assertRaises(ValueError): spatial_inventory([], (1,0,0,1))

if __name__=='__main__': unittest.main()