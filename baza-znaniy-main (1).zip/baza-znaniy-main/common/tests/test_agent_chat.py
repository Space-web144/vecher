# -*- coding: utf-8 -*-
"""Тесты чата «Ассистент»: поток ответа, цикл с инструментами, файлы на
выходе, свои инструменты (Документация, Verrata), прогон main() на файле
чата. Сеть не нужна: клиент Anthropic подменяется.

Только unittest и стандартная библиотека — чтобы гонять и на Python 3.8,
как на хостинге:  python3 -m unittest common.tests.test_agent_chat
"""
import copy
import io
import json
import os
import shutil
import tempfile
import time
import threading
import unittest
from concurrent.futures import ThreadPoolExecutor
from contextlib import contextmanager
from pathlib import Path
from unittest import mock

from common import agent_files, agent_heavy, agent_heavy_worker, agent_tools, web_agent_chat
from common.anthropic_client import (
    AnthropicClient, AnthropicConnectionError, AnthropicError, StreamAccumulator, read_stream,
)


def sse(*events):
    """Поток SSE из событий, как его отдаёт API."""
    out = []
    for event in events:
        out.append("event: %s\ndata: %s\n\n" % (event["type"], json.dumps(event, ensure_ascii=False)))
    return io.BytesIO("".join(out).encode("utf-8"))


def text_response(text, stop="end_turn", extra=None, container=None):
    response = {"role": "assistant", "model": "claude-opus-5-5", "stop_reason": stop,
                "content": (extra or []) + ([{"type": "text", "text": text}] if text else []),
                "usage": {"input_tokens": 10, "output_tokens": 5}}
    if container:
        response["container"] = {"id": container, "expires_at": "2026-11-01T00:00:00Z"}
    return response


class FakeClient:
    model_chat = None
    effort_chat = None

    def __init__(self, responses, created=None):
        self.responses = list(responses)
        self.calls = []
        self.uploads = []
        self.deleted = []
        self.created = created or {}          # file_id -> (имя, байты)

    def messages(self, turns, **kwargs):
        self.calls.append(dict(kwargs, turns=copy.deepcopy(turns)))
        item = self.responses.pop(0)
        if isinstance(item, Exception):
            raise item
        on_event = kwargs.get("on_event")
        if on_event:
            # Тот же порядок событий, что в настоящем потоке.
            accumulator = StreamAccumulator()
            events = [{"type": "message_start", "message": {"model": item.get("model")}}]
            for index, block in enumerate(item["content"]):
                if block.get("type") == "text":
                    events.append({"type": "content_block_start", "index": index,
                                   "content_block": {"type": "text", "text": ""}})
                    events.append({"type": "content_block_delta", "index": index,
                                   "delta": {"type": "text_delta", "text": block["text"]}})
                else:
                    events.append({"type": "content_block_start", "index": index,
                                   "content_block": block})
                events.append({"type": "content_block_stop", "index": index})
            for event in events:
                accumulator.apply(event)
                on_event(event, accumulator)
        return copy.deepcopy(item)

    def upload_file(self, path, mime, expires_in_seconds=None, filename=None):
        file_id = "file_%d" % (len(self.uploads) + 1)
        self.uploads.append({"id": file_id, "path": path, "mime": mime, "filename": filename})
        return file_id

    def upload_file_named(self, path, mime, filename, expires_in_seconds=None):
        return self.upload_file(path, mime, filename=filename), filename

    def delete_file(self, file_id):
        self.deleted.append(file_id)
        return True

    def file_metadata(self, file_id):
        if file_id not in self.created:
            # Загруженный нами файл: есть в хранилище, но скачать нельзя.
            return {"id": file_id, "filename": "file.pdf", "size_bytes": 1, "downloadable": False}
        name, data = self.created[file_id]
        return {"id": file_id, "filename": name, "size_bytes": len(data), "downloadable": True}

    def download_file(self, file_id, dest_path, max_bytes):
        data = self.created[file_id][1]
        with open(dest_path, "wb") as handle:
            handle.write(data)
        return len(data)


class StreamTest(unittest.TestCase):
    def test_full_message_with_tools_thinking_and_citations(self):
        citation = {"type": "web_search_result_location", "url": "https://example.ru/sp60",
                    "title": "СП 60", "cited_text": "…", "encrypted_index": "x"}
        resp = sse(
            {"type": "message_start", "message": {"id": "msg_1", "model": "claude-opus-5-5",
                                                  "usage": {"input_tokens": 100}}},
            {"type": "content_block_start", "index": 0,
             "content_block": {"type": "thinking", "thinking": ""}},
            {"type": "content_block_delta", "index": 0,
             "delta": {"type": "thinking_delta", "thinking": "думаю"}},
            {"type": "content_block_delta", "index": 0,
             "delta": {"type": "signature_delta", "signature": "sig"}},
            {"type": "content_block_stop", "index": 0},
            {"type": "ping"},
            {"type": "content_block_start", "index": 1,
             "content_block": {"type": "server_tool_use", "id": "srv_1", "name": "web_search",
                               "input": {}}},
            {"type": "content_block_delta", "index": 1,
             "delta": {"type": "input_json_delta", "partial_json": "{\"query\": \"СП 60"}},
            {"type": "content_block_delta", "index": 1,
             "delta": {"type": "input_json_delta", "partial_json": " редакция\"}"}},
            {"type": "content_block_stop", "index": 1},
            {"type": "content_block_start", "index": 2,
             "content_block": {"type": "web_search_tool_result", "tool_use_id": "srv_1",
                               "content": [{"type": "web_search_result", "url": "https://example.ru"}]}},
            {"type": "content_block_stop", "index": 2},
            {"type": "content_block_start", "index": 3,
             "content_block": {"type": "text", "text": ""}},
            {"type": "content_block_delta", "index": 3,
             "delta": {"type": "text_delta", "text": "Действует "}},
            {"type": "content_block_delta", "index": 3,
             "delta": {"type": "citations_delta", "citation": citation}},
            {"type": "content_block_delta", "index": 3,
             "delta": {"type": "text_delta", "text": "редакция 2024 г."}},
            {"type": "content_block_stop", "index": 3},
            {"type": "message_delta", "delta": {"stop_reason": "end_turn"},
             "usage": {"output_tokens": 42}},
            {"type": "message_stop"},
        )
        seen = []
        message = read_stream(resp, lambda event, acc: seen.append(event["type"]))
        self.assertEqual(message["stop_reason"], "end_turn")
        self.assertEqual(message["usage"], {"input_tokens": 100, "output_tokens": 42})
        blocks = message["content"]
        self.assertEqual([b["type"] for b in blocks],
                         ["thinking", "server_tool_use", "web_search_tool_result", "text"])
        self.assertEqual(blocks[0], {"type": "thinking", "thinking": "думаю", "signature": "sig"})
        self.assertEqual(blocks[1]["input"], {"query": "СП 60 редакция"})
        self.assertEqual(blocks[3]["text"], "Действует редакция 2024 г.")
        self.assertEqual(blocks[3]["citations"], [citation])
        self.assertIn("ping", seen)
        self.assertEqual(seen[-1], "message_stop")

    def test_error_event_carries_status(self):
        resp = sse({"type": "message_start", "message": {}},
                   {"type": "error", "error": {"type": "overloaded_error", "message": "Overloaded"}})
        with self.assertRaises(AnthropicError) as caught:
            read_stream(resp)
        self.assertEqual(caught.exception.status, 529)

    def test_stream_cut_before_end(self):
        resp = sse({"type": "message_start", "message": {}},
                   {"type": "content_block_start", "index": 0,
                    "content_block": {"type": "text", "text": ""}})
        with self.assertRaises(AnthropicConnectionError):
            read_stream(resp)

    def test_callback_can_abort(self):
        resp = sse({"type": "message_start", "message": {}}, {"type": "ping"},
                   {"type": "message_stop"})

        class Stop(Exception):
            pass

        def boom(event, accumulator):
            if event["type"] == "ping":
                raise Stop()
        with self.assertRaises(Stop):
            read_stream(resp, boom)


class StreamFailuresTest(unittest.TestCase):
    def test_callback_error_is_not_reported_as_connection_loss(self):
        resp = sse({"type": "message_start", "message": {}}, {"type": "message_stop"})

        def disk_full(event, accumulator):
            raise OSError(28, "No space left on device")
        with self.assertRaises(OSError) as caught:
            read_stream(resp, disk_full)
        self.assertNotIsInstance(caught.exception, AnthropicConnectionError)

    def test_tool_call_cut_by_max_tokens_keeps_the_answer(self):
        resp = sse(
            {"type": "message_start", "message": {}},
            {"type": "content_block_start", "index": 0, "content_block": {"type": "text", "text": "Считаю."}},
            {"type": "content_block_stop", "index": 0},
            {"type": "content_block_start", "index": 1,
             "content_block": {"type": "server_tool_use", "id": "s", "name": "code_execution", "input": {}}},
            {"type": "content_block_delta", "index": 1,
             "delta": {"type": "input_json_delta", "partial_json": "{\"code\": \"impo"}},
            {"type": "content_block_stop", "index": 1},
            {"type": "message_delta", "delta": {"stop_reason": "max_tokens"}},
            {"type": "message_stop"})
        message = read_stream(resp)
        self.assertEqual(message["stop_reason"], "max_tokens")
        self.assertEqual(message["content"][1]["input"], {})

    def test_overload_before_first_block_is_retried_once(self):
        client = AnthropicClient(api_key="sk-test", fallbacks=False)
        streams = [
            sse({"type": "message_start", "message": {}},
                {"type": "error", "error": {"type": "overloaded_error", "message": "Overloaded"}}),
            sse({"type": "message_start", "message": {}},
                {"type": "content_block_start", "index": 0, "content_block": {"type": "text", "text": "Ок"}},
                {"type": "content_block_stop", "index": 0},
                {"type": "message_delta", "delta": {"stop_reason": "end_turn"}},
                {"type": "message_stop"})]
        with mock.patch.object(client, "_open_stream", side_effect=streams), \
                mock.patch("time.sleep"):
            message = client.messages([{"role": "user", "content": "привет"}],
                                      on_event=lambda event, acc: None)
        self.assertEqual(message["content"][0]["text"], "Ок")

    def test_overload_after_content_is_not_retried(self):
        client = AnthropicClient(api_key="sk-test", fallbacks=False)
        stream = sse({"type": "message_start", "message": {}},
                     {"type": "content_block_start", "index": 0, "content_block": {"type": "text", "text": "Час"}},
                     {"type": "error", "error": {"type": "overloaded_error", "message": "Overloaded"}})
        with mock.patch.object(client, "_open_stream", side_effect=[stream]):
            with self.assertRaises(AnthropicError) as caught:
                client.messages([{"role": "user", "content": "привет"}],
                                on_event=lambda event, acc: None)
        self.assertEqual(caught.exception.status, 529)


class CredentialsModelTest(unittest.TestCase):
    def _client(self, extra):
        import tempfile
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "anthropic.json")
            with open(path, "w", encoding="utf-8") as handle:
                json.dump(dict({"api_key": "sk-ant-" + "x" * 101}, **extra), handle)
            os.chmod(path, 0o600)
            return AnthropicClient(credentials_file=path)

    def test_rv_model_and_effort_from_file(self):
        client = self._client({"model_rv": "claude-fable-5-1", "effort_rv": "xhigh", "effort_rv_mark": "low"})
        self.assertEqual((client.model_rv, client.effort_rv, client.effort_rv_mark), ("claude-fable-5-1", "xhigh", "low"))
        client = self._client({})
        self.assertEqual((client.model_rv, client.effort_rv, client.effort_rv_mark), (None, None, None))

    def test_bad_rv_effort_rejected(self):
        from common.anthropic_client import AnthropicConfigError
        for field in ("effort_rv", "effort_rv_mark"):
            with self.assertRaises(AnthropicConfigError):
                self._client({field: "extra"})

    def test_equipment_client_model_and_effort(self):
        from common import claude_client
        sent = []

        def post(body):
            sent.append(body)
            return {"stop_reason": "end_turn", "content": [{"type": "text", "text": "{}"}]}

        with mock.patch.dict(os.environ, {"ANTHROPIC_API_KEY": "sk-test"}, clear=False):
            os.environ.pop("ANTHROPIC_MODEL", None)
            os.environ.pop("ANTHROPIC_EFFORT", None)
            client = claude_client.client_from_environment()
            with mock.patch.object(client, "_post", post):
                client.extract_json("system", "text", {"type": "object"})
            self.assertEqual(sent[0]["model"], "claude-opus-5-5")
            self.assertEqual(sent[0]["output_config"]["effort"], "high")
            self.assertEqual(sent[0]["output_config"]["format"]["type"], "json_schema")
            with mock.patch.dict(os.environ, {"ANTHROPIC_EFFORT": "medium"}):
                self.assertEqual(claude_client.client_from_environment().effort, "medium")
            with mock.patch.dict(os.environ, {"ANTHROPIC_EFFORT": "экстра"}), \
                    mock.patch("sys.stderr", io.StringIO()):
                self.assertEqual(claude_client.client_from_environment().effort, "high")

    def test_verrata_formulaic_work_on_opus_5_5(self):
        import importlib
        import sys
        sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "program-b"))
        try:
            narrative = importlib.import_module("narrative")
        finally:
            sys.path.pop(0)
        self.assertEqual(narrative.SHEETS_MODEL, "claude-opus-5-5")


class UploadNameTest(unittest.TestCase):
    def test_falls_back_to_latin_name(self):
        client = AnthropicClient(api_key="sk-test", fallbacks=False)
        names = []

        def upload(path, mime, expires, filename):
            names.append(filename)
            if len(names) == 1:
                raise AnthropicError("invalid file name", status=400)
            return "file_ok"
        with mock.patch.object(client, "_upload", side_effect=upload):
            file_id, used = client.upload_file_named("/tmp/x.xlsx", "application/x", "Смета №1.xlsx")
        self.assertEqual(file_id, "file_ok")
        self.assertEqual(names[0], "Смета №1.xlsx")
        # Уникальное латинское имя — и именно его надо сказать модели.
        self.assertRegex(used, r"^file_[0-9a-f]{8}\.xlsx$")
        self.assertEqual(used, names[1])

    def test_other_errors_are_not_retried(self):
        client = AnthropicClient(api_key="sk-test", fallbacks=False)
        with mock.patch.object(client, "_upload",
                               side_effect=AnthropicError("file too large", status=400)) as upload:
            with self.assertRaises(AnthropicError):
                client.upload_file_named("/tmp/x.pdf", "application/pdf", "Альбом.pdf")
        self.assertEqual(upload.call_count, 1)


class AnswerLoopTest(unittest.TestCase):
    MESSAGES = [{"role": "user", "text": "Посчитай расход воздуха", "time": 1}]

    def test_plain_answer_uses_high_and_all_server_tools(self):
        client = FakeClient([text_response("Ответ", container="cnt_1")])
        result = web_agent_chat.answer(self.MESSAGES, client=client)
        self.assertEqual(result["text"], "Ответ")
        self.assertEqual(result["container"], "cnt_1")
        call = client.calls[0]
        self.assertEqual(call["effort"], "high")
        self.assertEqual(call["max_tokens"], 64000)
        types = [tool["type"] for tool in call["tools"]]
        self.assertIn("code_execution_20260521", types)
        self.assertIn("web_search_20260318", types)
        self.assertIn("web_fetch_20260318", types)
        # Дата — в последнем вопросе, а не в системном промте.
        self.assertTrue(call["turns"][-1]["content"][0]["text"].startswith("[Сегодня "))
        self.assertNotIn("Сегодня", call["system"])

    def test_effort_from_credentials_wins(self):
        client = FakeClient([text_response("Ответ")])
        client.effort_chat = "xhigh"
        web_agent_chat.answer(self.MESSAGES, client=client)
        self.assertEqual(client.calls[0]["effort"], "xhigh")

    def test_mcp_uses_only_configured_tools(self):
        activity = []
        client = FakeClient([text_response("Найдено", extra=[
            {"type": "mcp_tool_use", "id": "mc1", "name": "search", "server_name": "catalog"},
            {"type": "mcp_tool_result", "tool_use_id": "mc1", "content": []},
        ])])
        client.chat_mcp_servers = [
            {"name": "bad", "url": "http://example.com", "tools": ["search"]},
            {"name": "catalog", "url": "https://example.com/mcp", "tools": ["search"],
             "authorization_token": "test-token"},
        ]
        progress = web_agent_chat.Progress(lambda step, partial: activity.append(step) or True)
        result = web_agent_chat.answer(self.MESSAGES, client=client, progress=progress)
        self.assertEqual(result["text"], "Найдено")
        self.assertIn("Обращается к внешнему сервису", activity)
        call = client.calls[0]
        self.assertEqual(call["mcp_servers"], [{"type": "url", "name": "catalog",
                                               "url": "https://example.com/mcp",
                                               "authorization_token": "test-token"}])
        self.assertEqual(call["tools"][-1], {"type": "mcp_toolset", "mcp_server_name": "catalog",
                                           "default_config": {"enabled": False},
                                           "configs": {"search": {"enabled": True}}})

    def test_mcp_request_preserves_existing_beta(self):
        client = AnthropicClient(api_key="sk-test")
        servers = [{"type": "url", "name": "catalog", "url": "https://example.com/mcp"}]
        response = io.BytesIO(json.dumps(text_response("Готово")).encode())
        with mock.patch.object(client._opener, "open", return_value=response) as send:
            client.messages([{"role": "user", "content": "Поиск"}], mcp_servers=servers)
        request = send.call_args[0][0]
        self.assertEqual(json.loads(request.data)["mcp_servers"], servers)
        self.assertEqual(request.get_header("Anthropic-beta"),
                         "server-side-fallback-2026-06-01,mcp-client-2025-11-20")

    def test_pause_turn_is_continued_with_same_content(self):
        paused = text_response("Ищу…", stop="pause_turn",
                               extra=[{"type": "server_tool_use", "id": "s1", "name": "web_search",
                                       "input": {"query": "q"}}])
        client = FakeClient([paused, text_response("Нашёл.")])
        result = web_agent_chat.answer(self.MESSAGES, client=client)
        self.assertEqual(len(client.calls), 2)
        self.assertEqual(client.calls[1]["turns"][-1],
                         {"role": "assistant", "content": paused["content"]})
        self.assertEqual(result["text"], "Ищу…\n\nНашёл.")

    def test_client_tool_round_trip(self):
        call = {"type": "tool_use", "id": "tu_1", "name": "search_documents", "input": {"query": "СП"}}
        first = text_response("Посмотрю в библиотеке.", stop="tool_use", extra=[])
        first["content"].append(call)
        client = FakeClient([first, text_response("В библиотеке есть СП 60.")])
        tools = mock.Mock()
        tools.definitions.return_value = [agent_tools.DEFINITIONS["search_documents"]]
        tools.run.return_value = ([{"type": "text", "text": "- id …"}],
                                  [{"type": "container_upload", "file_id": "file_doc"}], False)
        result = web_agent_chat.answer(self.MESSAGES, client=client, tools=tools)
        tools.run.assert_called_once_with("search_documents", {"query": "СП"})
        reply = client.calls[1]["turns"][-1]
        self.assertEqual(reply["role"], "user")
        self.assertEqual(reply["content"][0]["type"], "tool_result")
        self.assertEqual(reply["content"][0]["tool_use_id"], "tu_1")
        self.assertEqual(reply["content"][1], {"type": "container_upload", "file_id": "file_doc"})
        self.assertEqual(result["text"], "Посмотрю в библиотеке.\n\nВ библиотеке есть СП 60.")

    def test_rejected_container_upload_in_tool_result_is_dropped(self):
        call = {"type": "tool_use", "id": "tu_1", "name": "open_document", "input": {}}
        first = text_response("", stop="tool_use", extra=[call])
        client = FakeClient([first, AnthropicError("container_upload not allowed here", status=400),
                             text_response("Готово")])
        tools = mock.Mock()
        tools.definitions.return_value = []
        tools.run.return_value = ([{"type": "text", "text": "док"}],
                                  [{"type": "container_upload", "file_id": "f"}], False)
        result = web_agent_chat.answer(self.MESSAGES, client=client, tools=tools)
        self.assertEqual(result["text"], "Готово")
        last = client.calls[2]["turns"][-1]["content"]
        self.assertEqual([b["type"] for b in last], ["tool_result"])

    def test_expired_container_is_replaced(self):
        client = FakeClient([AnthropicError("container cnt_old expired", status=400),
                             text_response("Ок", container="cnt_new")])
        result = web_agent_chat.answer(self.MESSAGES, client=client, container="cnt_old")
        self.assertEqual(client.calls[0]["container"], "cnt_old")
        self.assertIsNone(client.calls[1]["container"])
        self.assertEqual(result["container"], "cnt_new")

    def test_api_error_becomes_chat_error(self):
        client = FakeClient([AnthropicError("overloaded", status=529)])
        result = web_agent_chat.answer(self.MESSAGES, client=client)
        self.assertIn("перегружен", result["error"])

    def test_output_files_and_sources_are_collected(self):
        code_result = {"type": "bash_code_execution_tool_result", "tool_use_id": "s2",
                       "content": {"type": "bash_code_execution_result", "stdout": "ok",
                                   "stderr": "", "return_code": 0,
                                   "content": [{"type": "bash_code_execution_output",
                                                "file_id": "file_out_1"}]}}
        text = {"type": "text", "text": "Таблица готова.", "citations": [
            {"type": "web_search_result_location", "url": "https://a.ru", "title": "A"},
            {"type": "web_search_result_location", "url": "https://a.ru", "title": "A"}]}
        response = {"role": "assistant", "stop_reason": "end_turn", "content": [code_result, text],
                    "usage": {"input_tokens": 1, "output_tokens": 1,
                              "server_tool_use": {"web_search_requests": 2}}}
        client = FakeClient([response])
        result = web_agent_chat.answer(self.MESSAGES, client=client)
        self.assertEqual(result["file_ids"], ["file_out_1"])
        self.assertEqual(result["sources"], [{"url": "https://a.ru", "title": "A"}])
        self.assertEqual(result["usage"]["web_search_requests"], 2)

    def test_runaway_loop_is_stopped(self):
        paused = text_response("…", stop="pause_turn")
        client = FakeClient([paused] * (web_agent_chat.MAX_STEPS + 1))
        result = web_agent_chat.answer(self.MESSAGES, client=client)
        self.assertEqual(len(client.calls), web_agent_chat.MAX_STEPS)
        self.assertIn("продолжи", result["text"])

    def test_progress_sees_activity_and_partial_text(self):
        written = []
        progress = web_agent_chat.Progress(lambda activity, partial: written.append(
            (activity, partial)) or True, clock=iter(range(0, 1000, 5)).__next__)
        response = text_response("Ответ готов", extra=[
            {"type": "server_tool_use", "id": "s", "name": "web_search", "input": {"query": "СП 60"}}])
        client = FakeClient([response])
        web_agent_chat.answer(self.MESSAGES, client=client, progress=progress)
        self.assertIn(("Ищет в интернете: «СП 60»", ""), written)
        self.assertEqual(written[-1][1], "Ответ готов")

    def test_cancel_reports_created_files(self):
        code_result = {"type": "bash_code_execution_tool_result", "tool_use_id": "s",
                       "content": {"type": "bash_code_execution_result",
                                   "content": [{"file_id": "gen_1"}]}}
        first = text_response("", stop="pause_turn", extra=[code_result])
        client = FakeClient([first, text_response("готово")])
        writes = []

        def write(activity, partial):
            writes.append(1)
            return len(writes) < 2          # второй записи чат уже не принимает
        with self.assertRaises(web_agent_chat.Cancelled) as caught:
            web_agent_chat.answer(self.MESSAGES, client=client,
                                  progress=web_agent_chat.Progress(write))
        self.assertEqual(caught.exception.file_ids, ["gen_1"])

    def test_progress_cancels_when_chat_is_gone(self):
        progress = web_agent_chat.Progress(lambda activity, partial: False)
        with self.assertRaises(web_agent_chat.Cancelled):
            progress.update(activity="Думает", force=True)


class TurnsTest(unittest.TestCase):
    def test_attachments_go_for_reading_and_into_container(self):
        now = int(time.time())
        messages = [{"role": "user", "text": "Посчитай", "attachments": [
            {"name": "Смета.xlsx", "status": "ok", "kind": "table", "uploaded": now,
             "container_name": "Смета.xlsx",
             "files": [{"id": "f_text", "block": "document", "title": "Смета.xlsx"},
                       {"id": "f_raw", "block": "container", "title": "Смета.xlsx"}]},
            {"name": "старый.xls", "status": "ok", "kind": "container", "uploaded": now,
             "container_name": "старый.xls",
             "files": [{"id": "f_xls", "block": "container", "title": "старый.xls"}]}]}]
        content = web_agent_chat.build_turns(messages)[0]["content"]
        self.assertEqual(content[0]["type"], "text")
        self.assertIn("«Смета.xlsx»", content[0]["text"])
        self.assertIn("pandas/xlrd", content[0]["text"])
        self.assertIn({"type": "container_upload", "file_id": "f_raw"}, content)
        self.assertIn({"type": "container_upload", "file_id": "f_xls"}, content)
        self.assertIn({"type": "document", "source": {"type": "file", "file_id": "f_text"},
                       "title": "Смета.xlsx"}, content)
        self.assertEqual(content[-1], {"type": "text", "text": "Посчитай"})

    def test_history_mentions_delivered_files(self):
        messages = [{"role": "user", "text": "Сделай таблицу"},
                    {"role": "assistant", "text": "Готово.", "files": [{"name": "Итог.xlsx"}]},
                    {"role": "user", "text": "Добавь столбец"}]
        turns = web_agent_chat.build_turns(messages)
        self.assertIn("Итог.xlsx", turns[1]["content"])

    def test_text_assembly(self):
        blocks = [{"type": "text", "text": "Начало "}, {"type": "text", "text": "абзаца."},
                  {"type": "server_tool_use"}, {"type": "text", "text": "Итог."}]
        self.assertEqual(web_agent_chat.assemble_text(blocks), "Начало абзаца.\n\nИтог.")


class SaveOutputsTest(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.mkdtemp()

    def tearDown(self):
        shutil.rmtree(self.dir)

    def test_newest_version_wins_and_storage_is_cleaned(self):
        client = FakeClient([], created={"f1": ("Расчёт.xlsx", b"one"),
                                         "f2": ("../../etc/passwd", b"two"),
                                         "f3": ("Расчёт.xlsx", b"three")})
        out = os.path.join(self.dir, "chat")
        records, problems = web_agent_chat.save_outputs(client, ["f1", "f2", "f3", "file_uploaded"],
                                                        out, print)
        self.assertEqual(problems, [])
        self.assertEqual([r["name"] for r in records], ["passwd", "Расчёт.xlsx"])
        newest = records[1]
        self.assertEqual(newest["size"], 5)                       # последняя версия
        self.assertEqual(sorted(os.listdir(out)),
                         sorted(r["id"] + "." + r["ext"] for r in records))
        # Созданное моделью удалено из хранилища всё, загруженное нами — нет.
        self.assertEqual(sorted(client.deleted), ["f1", "f2", "f3"])

    def test_limits_keep_latest_and_delete_everything(self):
        created = {"f%02d" % i: ("файл_%02d.txt" % i, b"x") for i in range(25)}
        client = FakeClient([], created=created)
        ids = sorted(created)
        records, problems = web_agent_chat.save_outputs(client, ids, os.path.join(self.dir, "c"), print)
        self.assertEqual(len(records), web_agent_chat.OUTPUT_MAX_FILES)
        self.assertEqual(records[-1]["name"], "файл_24.txt")        # свежие не теряются
        self.assertNotIn("файл_00.txt", [r["name"] for r in records])
        self.assertTrue(problems)
        self.assertEqual(sorted(client.deleted), ids)                # и лишние не остаются

    def test_cancel_while_saving_cleans_up(self):
        client = FakeClient([], created={"f1": ("a.txt", b"1"), "f2": ("b.txt", b"2")})
        calls = []

        def alive():
            calls.append(1)
            return len(calls) < 2
        out = os.path.join(self.dir, "chat")
        with self.assertRaises(web_agent_chat.Cancelled):
            web_agent_chat.save_outputs(client, ["f1", "f2"], out, print, alive=alive)
        self.assertFalse(os.path.exists(out))
        self.assertEqual(sorted(client.deleted), ["f1", "f2"])

    def test_without_folder_files_are_reported(self):
        client = FakeClient([], created={"f1": ("a.txt", b"x")})
        records, problems = web_agent_chat.save_outputs(client, ["f1"], None, print)
        self.assertEqual(records, [])
        self.assertTrue(problems)


class ToolsTest(unittest.TestCase):
    def setUp(self):
        self.root = tempfile.mkdtemp()
        self.docs = os.path.join(self.root, "docs")
        self.verrata = os.path.join(self.root, "verrata")
        os.makedirs(self.docs)
        os.makedirs(self.verrata)
        docs = [
            {"id": "a" * 16, "file": "b" * 16, "ext": "txt", "title": "СП 60.13330.2020 Отопление",
             "category": "Нормативы", "description": "Вентиляция и кондиционирование",
             "original_name": "sp60.txt", "size": 2048, "uploaded_at": 1700000000},
            {"id": "c" * 16, "ext": "txt", "title": "Регламент закупок", "category": "",
             "original_name": "zakupki.txt", "size": 10, "uploaded_at": 1700000000},
        ]
        with open(os.path.join(self.docs, "docs.json"), "w", encoding="utf-8") as handle:
            json.dump(docs, handle, ensure_ascii=False)
        with open(os.path.join(self.docs, "b" * 16 + ".txt"), "w", encoding="utf-8") as handle:
            handle.write("п. 6.1 Воздухообмен…")
        self.client = FakeClient([])
        self.tools = agent_tools.AgentTools(
            self.client, docs_dir=self.docs, verrata_dir=self.verrata,
            owner_key=agent_tools.user_key("ivanov"), user_texts=["вопрос"],
            shared=agent_tools.SharedUploads(os.path.join(self.root, "shared.json")))

    def tearDown(self):
        shutil.rmtree(self.root)

    def _job(self, token, user):
        with open(os.path.join(self.verrata, token + "_job.json"), "w", encoding="utf-8") as handle:
            json.dump({"user": user, "section": "ОВ", "mode": "spec", "files": ["ОВ изм1.pdf"],
                       "created": 1700000000}, handle, ensure_ascii=False)
        with open(os.path.join(self.verrata, token + "_verrata.xlsx"), "wb") as handle:
            handle.write(b"xlsx")

    def test_search_finds_by_number_and_word(self):
        content, extra, is_error = self.tools.run("search_documents", {"query": "сп 60"})
        self.assertFalse(is_error)
        self.assertIn("a" * 16, content[0]["text"])
        self.assertNotIn("c" * 16, content[0]["text"])
        everything, _, _ = self.tools.run("search_documents", {"query": ""})
        self.assertIn("(2)", everything[0]["text"])

    def test_open_document_uploads_once(self):
        content, extra, is_error = self.tools.run("open_document", {"document_id": "a" * 16})
        self.assertFalse(is_error)
        self.assertEqual(content[1]["type"], "document")
        self.assertEqual(extra[0]["type"], "container_upload")
        self.assertEqual(self.client.uploads[-1]["filename"], "sp60.txt")
        uploads = len(self.client.uploads)
        self.tools.run("open_document", {"document_id": "a" * 16})
        self.assertEqual(len(self.client.uploads), uploads)          # из кэша

    def test_unknown_document(self):
        _, _, is_error = self.tools.run("open_document", {"document_id": "f" * 16})
        self.assertTrue(is_error)

    def test_verrata_rights(self):
        self._job("1" * 16, "ivanov")
        self._job("2" * 16, "petrov")
        listing, _, _ = self.tools.run("list_verrata_reports", {})
        self.assertIn("1" * 16, listing[0]["text"])
        self.assertNotIn("2" * 16, listing[0]["text"])
        fake_prepare = mock.patch.object(
            agent_files, "prepare", return_value=([], {"kind": "table", "pages": 0,
                                                      "tokens": 10, "note": ""}))
        with fake_prepare:
            _, extra, is_error = self.tools.run("open_verrata_report",
                                                {"report_id": "1" * 16, "kind": "xlsx"})
            self.assertFalse(is_error)
            self.assertEqual(extra[0]["type"], "container_upload")
            _, _, is_error = self.tools.run("open_verrata_report",
                                            {"report_id": "2" * 16, "kind": "xlsx"})
            self.assertTrue(is_error)
            # Чужой отчёт — только по ссылке, которую прислал сам пользователь.
            self.tools.user_texts = "посмотри verrata_status.php?token=" + "2" * 16
            _, _, is_error = self.tools.run("open_verrata_report",
                                            {"report_id": "2" * 16, "kind": "xlsx"})
            self.assertFalse(is_error)
            _, _, is_error = self.tools.run("open_verrata_report",
                                            {"report_id": "2" * 16, "kind": "pdf"})
            self.assertTrue(is_error)                                 # PDF не собран

    def test_tools_offered_only_for_existing_folders(self):
        tools = agent_tools.AgentTools(self.client, docs_dir=self.docs, verrata_dir=None)
        self.assertEqual([d["name"] for d in tools.definitions()],
                         ["search_documents", "open_document"])
        _, _, is_error = tools.run("list_verrata_reports", {})
        self.assertTrue(is_error)


class ContainerOnlyFilesTest(unittest.TestCase):
    def test_large_files_go_directly_to_code(self):
        client = FakeClient([])
        with tempfile.TemporaryDirectory() as directory:
            path = os.path.join(directory, "attachment.pdf")
            with open(path, "wb") as handle:
                handle.truncate(200 * 1024 * 1024)
            record = web_agent_chat._process_one({}, {}, "attachment.pdf", path, client, None)
        self.assertEqual(record["status"], "ok")
        self.assertEqual(record["kind"], "container")
        self.assertEqual([part["block"] for part in record["files"]], ["container"])
        self.assertEqual(len(client.uploads), 1)

    def test_text_above_context_budget_can_still_be_opened(self):
        with tempfile.TemporaryDirectory() as directory:
            path = os.path.join(directory, "attachment.txt")
            with open(path, "w", encoding="utf-8") as handle:
                handle.write("Текст вне бюджета")
            with mock.patch.object(web_agent_chat, "CHAT_MAX_ATTACHMENT_TOKENS", 1):
                parts, info = web_agent_chat._prepare_chat_attachment({}, path, "attachment.txt", directory)
        self.assertEqual(parts, [])
        self.assertEqual(info["kind"], "container")

    def test_old_formats_go_to_container(self):
        workdir = tempfile.mkdtemp()
        try:
            path = os.path.join(workdir, "a.bin")
            with open(path, "wb") as handle:
                handle.write(b"data")
            parts, info = agent_files.prepare(path, "Смета.xls", workdir)
            self.assertEqual(parts, [])
            self.assertEqual(info["kind"], "container")
            with self.assertRaises(agent_files.AttachmentError):
                agent_files.prepare(path, "virus.exe", workdir)
        finally:
            shutil.rmtree(workdir)

    def test_site_accepts_exactly_what_python_handles(self):
        """AGENT_FILE_TYPES в web/config.php == ALLOWED_EXT в agent_files.py:
        иначе сайт примет файл, который ассистент потом отвергнет, или
        наоборот."""
        import re
        config = os.path.join(os.path.dirname(__file__), "..", "..", "web", "config.php")
        with open(config, encoding="utf-8") as handle:
            text = handle.read()
        listed = re.search(r"define\('AGENT_FILE_TYPES',\s*\[(.*?)\]\);", text, re.S).group(1)
        self.assertEqual(set(re.findall(r"'([a-z0-9]+)'", listed)), set(agent_files.ALLOWED_EXT))

    def test_container_name(self):
        self.assertEqual(agent_files.container_name('ОВ: изм "1".pdf'), "ОВ_ изм _1_.pdf")
        # Ни путей, ни скрытых файлов: точки в начале имени срезаются.
        self.assertEqual(agent_files.container_name("../секрет.txt"), "_секрет.txt")


@contextmanager
def heavy_worker(folder, run):
    workspace = Path(folder, "worker")
    workspace.mkdir()
    socket_path = str(Path(folder, "worker.sock"))
    with agent_heavy_worker.Worker(socket_path, workspace, runner=run) as worker:
        thread = threading.Thread(target=worker.serve_forever)
        thread.start()
        try:
            yield socket_path
        finally:
            worker.shutdown()
            thread.join()


class HeavyWorkerTest(unittest.TestCase):
    def test_jobs_wait_in_order_and_keep_user_files_separate(self):
        release = threading.Event()
        first_running = threading.Event()
        second_queued = threading.Event()
        third_queued = threading.Event()
        runs = []

        def run(job, status):
            data = (job / "input/1.txt").read_text()
            runs.append(data)
            if data == "first":
                first_running.set()
                if not release.wait(5):
                    raise agent_heavy.HeavyError("Timed out waiting for test")
            (job / "output/result.txt").write_text(data)
            return data

        def make_job(folder, name, queued):
            attachment = Path(folder, name + ".txt")
            attachment.write_text(name)
            return agent_heavy.HeavyJob(
                [{"name": attachment.name, "size": len(name), "path": attachment}],
                Path(folder, name),
                lambda activity: queued.set() if activity == agent_heavy.ACTIVITY["queued"] else None,
                socket_path=socket_path,
            )

        with tempfile.TemporaryDirectory() as folder, heavy_worker(folder, run) as socket_path:
            first = make_job(folder, "first", threading.Event())
            second = make_job(folder, "second", second_queued)
            third = make_job(folder, "third", third_queued)
            with ThreadPoolExecutor(max_workers=3) as pool:
                try:
                    first_run = pool.submit(first.run, {"script": "print('first')"})
                    self.assertTrue(first_running.wait(3))
                    second_run = pool.submit(second.run, {"script": "print('second')"})
                    self.assertTrue(second_queued.wait(3))
                    third_run = pool.submit(third.run, {"script": "print('third')"})
                    self.assertTrue(third_queued.wait(3))
                    self.assertEqual(runs, ["first"])
                finally:
                    release.set()
                for job, result, expected in ((first, first_run, "first"), (second, second_run, "second"),
                                              (third, third_run, "third")):
                    self.assertFalse(result.result(timeout=5)[2])
                    path = next(job.out_dir.iterdir())
                    self.assertEqual(path.read_text(), expected)
            self.assertEqual(runs, ["first", "second", "third"])

    def test_worker_rejects_paths_and_broker_cannot_return_symlinks(self):
        with self.assertRaises(agent_heavy.HeavyError):
            agent_heavy_worker.input_manifest({"script": "pass", "files": [{"name": "../1.pdf", "size": 1}]})

        def run(job, status):
            (job / "output/link.txt").symlink_to(job / "input/1.txt")
            return "Готово"

        with tempfile.TemporaryDirectory() as folder, heavy_worker(folder, run) as socket_path:
            path = Path(folder, "source")
            path.write_bytes(b"a")
            job = agent_heavy.HeavyJob([{"name": "input.txt", "size": 1, "path": path}],
                                       Path(folder, "out"), lambda activity: None, socket_path=socket_path)
            self.assertFalse(job.run({"script": "pass"})[2])
            self.assertEqual(job.records, [])


class MainRunTest(unittest.TestCase):
    """main() на настоящем файле чата: вложение, ответ с файлом, итог в чате."""

    def setUp(self):
        self.root = tempfile.mkdtemp()
        self.user_dir = os.path.join(self.root, "chats", agent_tools.user_key("ivanov"))
        os.makedirs(self.user_dir)
        self.upload = os.path.join(self.root, "upload.txt")
        with open(self.upload, "w", encoding="utf-8") as handle:
            handle.write("исходные данные")
        self.chat_path = os.path.join(self.user_dir, "0123456789abcdef.json")
        self.lock_path = os.path.join(self.user_dir, ".lock")
        chat = {"id": "0123456789abcdef", "title": "t", "created": 1, "updated": 1,
                "pending": {"id": "req1", "since": int(time.time())},
                "messages": [{"role": "user", "text": "Сделай Excel", "time": 1, "attachments": [
                    {"name": "данные.txt", "size": 30, "status": "new", "path": self.upload}]}]}
        with open(self.chat_path, "w", encoding="utf-8") as handle:
            json.dump(chat, handle, ensure_ascii=False)

    def tearDown(self):
        shutil.rmtree(self.root)

    def test_heavy_request_keeps_original_on_vps_and_returns_result(self):
        with open(self.chat_path, encoding="utf-8") as handle:
            chat = json.load(handle)
        chat["messages"][0]["processing"] = "vps"
        chat["messages"][0]["attachments"][0]["size"] = os.path.getsize(self.upload)
        web_agent_chat.write_chat(self.chat_path, chat)

        def runner(job, status):
            self.assertEqual((job / "input/1.txt").read_text(), "исходные данные")
            (job / "output/Итог.csv").write_text("ответ\n42\n", encoding="utf-8")
            return "Готово"

        name = agent_heavy.TOOL["name"]
        tool = {"type": "tool_use", "id": "tu_local", "name": name, "input": {"script": "print(42)"}}
        client = FakeClient([text_response("", stop="tool_use", extra=[tool]),
                             text_response("Расчёт выполнен.")])
        outputs = os.path.join(self.root, "outputs")
        original = agent_heavy.HeavyJob
        with heavy_worker(self.root, runner) as socket_path, \
                mock.patch.object(web_agent_chat, "make_client", return_value=client), \
                mock.patch.object(agent_heavy, "HeavyJob",
                                  side_effect=lambda *args: original(*args, socket_path=socket_path)):
            result = web_agent_chat.main(["--chat", self.chat_path, "--lock", self.lock_path,
                                          "--request", "req1", "--outputs", outputs])

        self.assertEqual(result, 0)
        self.assertEqual(client.uploads, [])
        self.assertIn(name, [item["name"] for item in client.calls[0]["tools"]])
        with open(self.chat_path, encoding="utf-8") as handle:
            chat = json.load(handle)
        self.assertIsNone(chat["pending"])
        self.assertFalse(os.path.exists(self.upload))
        self.assertNotIn("path", chat["messages"][0]["attachments"][0])
        record = chat["messages"][-1]["files"][0]
        self.assertEqual(record["name"], "Итог.csv")
        result_path = Path(outputs, "0123456789abcdef", record["id"] + ".csv")
        self.assertEqual(result_path.read_text(), "ответ\n42\n")

    def test_answer_with_generated_file(self):
        code_result = {"type": "bash_code_execution_tool_result", "tool_use_id": "s",
                       "content": {"type": "bash_code_execution_result", "return_code": 0,
                                   "stdout": "", "stderr": "",
                                   "content": [{"file_id": "gen_1"}]}}
        response = text_response("Файл готов.", extra=[code_result], container="cnt_9")
        client = FakeClient([response], created={"gen_1": ("Итог.xlsx", b"PK...")})
        outputs = os.path.join(self.root, "outputs", "user")
        with mock.patch.object(web_agent_chat, "make_client", return_value=client):
            code = web_agent_chat.main(["--chat", self.chat_path, "--lock", self.lock_path,
                                        "--request", "req1", "--outputs", outputs])
        self.assertEqual(code, 0)
        with open(self.chat_path, encoding="utf-8") as handle:
            chat = json.load(handle)
        self.assertIsNone(chat["pending"])
        self.assertEqual(chat["container"]["id"], "cnt_9")
        attachment = chat["messages"][0]["attachments"][0]
        self.assertEqual(attachment["status"], "ok")
        self.assertEqual(attachment["container_name"], "данные.txt")
        self.assertEqual([f["block"] for f in attachment["files"]], ["document", "container"])
        self.assertFalse(os.path.exists(self.upload))             # копии у нас не хранятся
        answer_message = chat["messages"][1]
        self.assertEqual(answer_message["text"], "Файл готов.")
        saved = answer_message["files"][0]
        self.assertEqual(saved["name"], "Итог.xlsx")
        self.assertTrue(os.path.isfile(os.path.join(outputs, chat["id"],
                                                    saved["id"] + ".xlsx")))
        # Вопрос ушёл модели вместе с файлом для чтения и копией в контейнер.
        sent = client.calls[0]["turns"][-1]["content"]
        self.assertIn({"type": "container_upload", "file_id": "file_2"}, sent)

    def test_superseded_request_writes_nothing(self):
        with open(self.chat_path, encoding="utf-8") as handle:
            chat = json.load(handle)
        chat["pending"]["id"] = "другой"
        with open(self.chat_path, "w", encoding="utf-8") as handle:
            json.dump(chat, handle, ensure_ascii=False)
        client = FakeClient([])
        with mock.patch.object(web_agent_chat, "make_client", return_value=client):
            code = web_agent_chat.main(["--chat", self.chat_path, "--lock", self.lock_path,
                                        "--request", "req1"])
        self.assertEqual(code, 0)
        self.assertEqual(client.calls, [])



class RequestLogTest(unittest.TestCase):
    def test_answer_event_and_append(self):
        result = {"text": "Ответ " * 100, "model": "claude-x", "usage": {"input_tokens": 10, "output_tokens": 5},
                  "files": [{"name": "расчёт.xlsx", "id": "f1", "ext": "xlsx"}], "sources": [{"url": "u"}]}
        event = web_agent_chat.answer_event({"id": "c1"}, "r1", result, time.time() - 7, 50)
        self.assertEqual(event["t"], "answer")
        self.assertTrue(event["ok"])
        self.assertGreaterEqual(event["seconds"], 7)
        self.assertEqual(event["files"], ["расчёт.xlsx"])
        self.assertEqual(event["sources"], 1)
        self.assertEqual(len(event["answer"]), 50)
        failed = web_agent_chat.answer_event({"id": "c1"}, "r2", {"error": "Сбой"}, None, 0)
        self.assertFalse(failed["ok"])
        self.assertEqual(failed["error"], "Сбой")
        self.assertNotIn("answer", failed)
        tmp = tempfile.mkdtemp()
        try:
            log_dir = os.path.join(tmp, "agent_log")
            self.assertTrue(web_agent_chat.log_answer(log_dir, event))
            self.assertTrue(web_agent_chat.log_answer(log_dir, failed))
            path = os.path.join(log_dir, time.strftime("%Y-%m") + ".jsonl")
            with open(path, encoding="utf-8") as handle:
                lines = [json.loads(line) for line in handle]
            self.assertEqual([line["request"] for line in lines], ["r1", "r2"])
            self.assertEqual(oct(os.stat(path).st_mode & 0o777), "0o600")
            self.assertFalse(web_agent_chat.log_answer(None, event))
        finally:
            shutil.rmtree(tmp)


if __name__ == "__main__":
    unittest.main()
