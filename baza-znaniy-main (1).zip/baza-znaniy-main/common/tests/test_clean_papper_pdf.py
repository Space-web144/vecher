"""Synthetic PDF and fake Claude tests; no API keys, external requests or client files."""
import base64
import json
import tempfile
import unittest
from pathlib import Path

import fitz

from common.web_clean_papper_pdf import (
    MAX_OUTPUT_TOKENS, PDFInputError, inspect, normalized_crop,
    structured_response, vision_request, diagnostic, main,
)


def make_pdf(path):
    d = fitz.open()
    a = d.new_page(width=680, height=420)
    a.insert_text((30, 70), "500x300", fontsize=13)
    a.draw_line((35, 130), (450, 130), color=(0, 0.7, 0), width=1)
    b = d.new_page(width=680, height=420)
    b.insert_text((30, 70), "800x600", fontsize=13)
    d.save(path)
    d.close()


def fake_credentials(folder):
    p = Path(folder)/"test-creds.json"
    p.write_text(json.dumps({
        "api_key": "sk-" + "A"*75,
        "model": "claude-sonnet-5",
        "model_clean_papper": "claude-sonnet-5",
    }), encoding="utf-8")
    return str(p)


class ClientDouble:
    calls = []
    kwargs = []
    def __init__(self, **kwargs):
        self.kwargs.append(kwargs)

    def messages(self, turns, **kwargs):
        self.calls.append((turns, kwargs))
        return {
            "type": "message", "model": "claude-sonnet-5",
            "stop_reason": "end_turn",
            "content": [{"type": "text", "text": json.dumps({
                "elements": [
                    {"type": "duct", "label": "Прямой участок",
                     "dimension": "500x300", "system": "",
                     "confidence": "medium", "note": "Геометрия"}
                ],
                "notes": ["Нужна проверка инженера"]
            }, ensure_ascii=False)}],
            "usage": {"input_tokens": 120, "output_tokens": 50},
        }


class CleanPapperPDFTests(unittest.TestCase):
    def setUp(self):
        ClientDouble.calls.clear()
        ClientDouble.kwargs.clear()

    def test_server_diagnostic_without_user_pdf_or_network(self):
        result = diagnostic()
        self.assertTrue(result["ok"], result)
        self.assertEqual(result["mode"], "diagnostic")
        self.assertEqual(result["jpeg_test"], "ok")
        self.assertTrue(result["python_version"])
        self.assertFalse(ClientDouble.calls)

    def test_cli_diagnostic_without_document(self):
        import contextlib
        import io
        captured = io.StringIO()
        with contextlib.redirect_stdout(captured):
            code = main(["--mode", "diagnostic"])
        self.assertEqual(code, 0)
        result = json.loads(captured.getvalue())
        self.assertTrue(result["ok"])
        self.assertNotIn("preview", result)

    def test_local_preview_never_calls_ai(self):
        with tempfile.TemporaryDirectory() as tmp:
            pdf = Path(tmp)/"synthetic.pdf"
            make_pdf(pdf)
            result = inspect(pdf, 1, mode="preview", client_factory=ClientDouble)
            self.assertTrue(result["ok"])
            self.assertEqual(result["pages"], 2)
            self.assertEqual(result["mode"], "preview")
            self.assertTrue(result["preview"].startswith("data:image/jpeg;base64,"))
            self.assertLess(len(base64.b64decode(result["preview"].split(",")[1])), 1_350_001)
            self.assertEqual(result["image_width"] > 0, True)
            self.assertGreaterEqual(result["geometry"]["vector_paths_sampled"], 1)
            self.assertTrue(any(x["text"] == "500x300"
                                for x in result["geometry"]["section_text_candidates"]))
            self.assertFalse(ClientDouble.calls)
            ducts=result["geometry"]["duct_geometry"]
            self.assertIn("scanning",ducts)
            self.assertIn("layer_statistics",ducts)
            self.assertIn("trace_network",ducts)
            self.assertIn("scanning",ducts["trace_network"])
            self.assertNotIn("total_length_m",ducts["trace_network"])
            self.assertNotIn("total_length_m",ducts)
            self.assertNotIn("material_surface_m2",ducts)
            trace = result["geometry"]["vector_trace"]
            self.assertGreaterEqual(len(trace["candidates"]), 1)
            line = trace["candidates"][0]
            self.assertTrue(line["source_id"].startswith("pdf_path_"))
            self.assertIsNone(line["physical_length_m"])
            self.assertIn("start_pdf_pt", line)
            self.assertGreater(line["projected_length_pt"], 0)
            self.assertGreaterEqual(trace["path_scanning"]["colored_paths_encountered"], 1)

    def test_spatial_inventory_uses_unrotated_page_coordinates(self):
        with tempfile.TemporaryDirectory() as tmp:
            pdf = Path(tmp) / "rotated.pdf"
            with fitz.open() as doc:
                pg = doc.new_page(width=400, height=700)
                pg.draw_line((20, 30), (150, 30), color=(1,0,0))
                pg.set_rotation(90)
                doc.save(pdf)
            result = inspect(pdf, 1)
            spatial = result["geometry"]["spatial_inventory"]
            self.assertEqual(spatial["region_pdf_pt"], [0, 0, 400, 700])
            self.assertEqual(spatial["source_paths_examined"], 1)
            self.assertEqual(spatial["region_paths_located"], 1)
            self.assertTrue(spatial["legacy_detector_rotation_review_required"])
            self.assertEqual(sum(t["owned_paths"] for t in spatial["tiles"]), 1)

    def test_page_isolation_in_preview(self):
        with tempfile.TemporaryDirectory() as tmp:
            pdf = Path(tmp)/"synthetic.pdf"
            make_pdf(pdf)
            result = inspect(pdf, 2, mode="preview")
            labels = [x["text"] for x in result["geometry"]["section_text_candidates"]]
            self.assertIn("800x600", labels)
            self.assertNotIn("500x300", labels)

    def test_crop_validation(self):
        self.assertEqual(normalized_crop(None), [0.,0.,1.,1.])
        self.assertEqual(normalized_crop("0.2,0.2,0.8,0.8"), [.2,.2,.8,.8])
        for bad in ("0.1,0.1,0.11,0.2", "0,0,2,1", "nan,0,1,1",
                    "0,1,0,0", "nope", "0,0,0,0"):
            with self.subTest(bad=bad):
                with self.assertRaises(PDFInputError):
                    normalized_crop(bad)

    def test_wrong_pdf_magic_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            file = Path(tmp)/"fake.pdf"
            file.write_bytes(b"hello")
            with self.assertRaises(PDFInputError):
                inspect(file, 1)

    def test_out_of_range_page_rejected(self):
        with tempfile.TemporaryDirectory() as tmp:
            pdf = Path(tmp)/"synthetic.pdf"; make_pdf(pdf)
            with self.assertRaises(PDFInputError):
                inspect(pdf, 3)

    def test_vision_submits_only_one_jpeg_request_with_cap(self):
        with tempfile.TemporaryDirectory() as tmp:
            creds = fake_credentials(tmp)
            pdf = Path(tmp)/"synthetic.pdf"; make_pdf(pdf)
            result = inspect(pdf, 1, mode="vision", credentials_path=creds,
                             client_factory=ClientDouble)
            self.assertTrue(result["ok"])
            self.assertEqual(result["mode"], "vision")
            self.assertNotIn("preview", result)
            self.assertEqual(len(ClientDouble.calls), 1)
            content = ClientDouble.calls[0][0][0]["content"]
            self.assertEqual(len(content), 2)
            self.assertEqual(content[1]["type"], "image")
            self.assertEqual(content[1]["source"]["media_type"], "image/jpeg")
            self.assertTrue(base64.b64decode(content[1]["source"]["data"]).startswith(b"\xff\xd8"))
            self.assertEqual(ClientDouble.calls[0][1]["max_tokens"], MAX_OUTPUT_TOKENS)
            self.assertFalse(ClientDouble.kwargs[0]["fallbacks"])
            self.assertEqual(ClientDouble.kwargs[0]["max_requests"], 1)
            self.assertEqual(result["vision"]["elements"][0]["status"], "unverified_ai_suggestion")
            self.assertEqual(result["vision"]["input_tokens"], 120)

    def test_model_response_sanitization(self):
        result=structured_response(json.dumps({
            "elements": [{"type":"unrecognized",
                          "label":"L"*700,
                          "confidence":"excellent",
                          "note":"N"*800}],
            "notes":["Q"*700]}))
        self.assertEqual(result["elements"][0]["type"], "other")
        self.assertEqual(result["elements"][0]["confidence"], "low")
        self.assertEqual(len(result["elements"][0]["label"]), 150)
        self.assertEqual(len(result["notes"][0]), 260)

    def test_no_geometry_implied_as_length(self):
        with tempfile.TemporaryDirectory() as tmp:
            pdf=Path(tmp)/"synthetic.pdf";make_pdf(pdf)
            data=inspect(pdf,1)
            self.assertNotIn("duct_length_m", data["geometry"])
            self.assertNotIn("approved_m2", data["geometry"])

    def test_missing_credentials_rejected_in_vision(self):
        with tempfile.TemporaryDirectory() as tmp:
            pdf=Path(tmp)/"synthetic.pdf";make_pdf(pdf)
            with self.assertRaises(PDFInputError):
                inspect(pdf,1,mode="vision",credentials_path=None)
            self.assertFalse(ClientDouble.calls)


if __name__ == "__main__":
    unittest.main()
