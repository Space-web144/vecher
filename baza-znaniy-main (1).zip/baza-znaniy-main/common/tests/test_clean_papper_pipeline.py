"""Synthetic pipeline checks; one full native integration test uses repository fixture."""
from pathlib import Path
import json
import base64
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

import fitz

from common import clean_papper_pipeline as p


class PipelineTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.pdf = self.root / 'album.pdf'
        self.workspace = self.root / 'private'

    def make_pdf(self, pages=4):
        with fitz.open() as doc:
            for i in range(pages):
                page = doc.new_page()
                page.insert_text((30, 40), 'Page %d' % (i + 1))
                if i == 2:
                    page.set_rotation(90)
            doc.save(self.pdf)

    def test_header_normalization_and_runs(self):
        header = 'Наименование и техническая характеристика\nЕд. измерения\nКоли-\nчество\nТип, марка, обозначение'
        self.assertEqual(p.header_evidence(header), list(p.HEADER_TOKENS))
        self.assertNotEqual(len(p.header_evidence('Наименование и техническая характеристика')), 4)
        self.assertEqual(p.contiguous_runs([2, 3, 5, 6, 7]), [[2, 3], [5, 6, 7]])

    def test_ambiguous_candidate_requires_explicit_range(self):
        with self.assertRaises(p.PipelineError):
            p.choose_range({'candidates': [{'first': 1, 'last': 2}, {'first': 4, 'last': 5}]}, 6)
        self.assertEqual(p.choose_range({'candidates': []}, 6, [2, 4]), (2, 4, 'operator_selected'))
        for invalid in [[0, 3], [3, 2], [1, 7], [True, 3]]:
            with self.assertRaises(p.PipelineError):
                p.choose_range({'candidates': []}, 6, invalid)

    def test_extract_and_page_map(self):
        self.make_pdf()
        stage = p.prepare(self.pdf, self.workspace, [2, 3])
        selection = p.validate_selection(stage)
        self.assertEqual([x['album_pdf_page'] for x in selection['page_map']], [2, 3])
        with fitz.open(stage / 'specification.pdf') as doc:
            self.assertEqual(len(doc), 2)
            self.assertEqual(doc[0].get_text().strip(), 'Page 2')
            self.assertEqual(doc[1].rotation, 90)
        self.assertEqual(p.read_json(stage / 'conversion.json')['status'], 'not_run')
        self.assertEqual(p.prepare(self.pdf, self.workspace, [2, 3]), stage)

    def test_web_extract_and_source_hash(self):
        self.make_pdf()
        script = p.REPO / 'common' / 'web_clean_papper_specification.py'
        args = [sys.executable, str(script), '--file', str(self.pdf), '--first', '2',
                '--last', '3', '--action', 'extract', '--sha']
        bad = subprocess.run(args + ['0' * 64], capture_output=True, text=True, timeout=60)
        self.assertNotEqual(bad.returncode, 0)
        self.assertFalse(json.loads(bad.stdout)['ok'])
        good = subprocess.run(args + [p.digest(self.pdf)], capture_output=True, text=True, timeout=60)
        self.assertEqual(good.returncode, 0, good.stderr)
        response = json.loads(good.stdout)
        self.assertEqual(response['status'], 'extracted')
        with fitz.open(stream=base64.b64decode(response['downloads'][0]['base64']), filetype='pdf') as doc:
            self.assertEqual(len(doc), 2)
            self.assertEqual(doc[0].get_text().strip(), 'Page 2')

    def test_web_rejects_non_specification(self):
        self.make_pdf()
        script = p.REPO / 'common' / 'web_clean_papper_specification.py'
        run = subprocess.run([sys.executable, str(script), '--file', str(self.pdf),
                              '--first', '1', '--last', '2', '--sha', p.digest(self.pdf),
                              '--action', 'convert'], capture_output=True, text=True, timeout=120)
        self.assertNotEqual(run.returncode, 0)
        result = json.loads(run.stdout)
        self.assertFalse(result['ok'])
        self.assertNotIn('downloads', result)

    def test_tampered_pdf_rejected(self):
        self.make_pdf()
        stage = p.prepare(self.pdf, self.workspace, [2, 3])
        with (stage / 'specification.pdf').open('ab') as f:
            f.write(b'tamper')
        with self.assertRaises(p.PipelineError):
            p.validate_selection(stage)

    def test_row_provenance_includes_continuation(self):
        rows = [{'NAME': 'Duct', 'QTY': '1.25', '_PAGE': 1, '_SOURCE_PAGES': [0, 1]}]
        mapping = [{'specification_page': 1, 'album_pdf_page': 49},
                   {'specification_page': 2, 'album_pdf_page': 50}]
        result = p.source_rows(rows, mapping)[0]
        self.assertEqual(result['album_pdf_pages'], [49, 50])
        self.assertEqual(result['quantity_source_album_page'], 50)
        self.assertEqual(result['fields']['QTY'], '1.25')
        self.assertEqual(result['workbook_row'], 2)
        for bad in [{'NAME': 'Duct'}, {'_PAGE': 3}, {'_PAGE': 1, '_SOURCE_PAGES': [0]}]:
            with self.assertRaises(p.PipelineError):
                p.source_rows([bad], mapping)

    def test_failed_conversion_has_no_approved_result(self):
        self.make_pdf()
        stage = p.prepare(self.pdf, self.workspace, [2, 3])
        with patch.object(p.subprocess, 'run', return_value=subprocess.CompletedProcess([], 1, '', 'review needed')):
            with self.assertRaises(p.PipelineError):
                p.convert_stage(stage)
        self.assertEqual(p.read_json(stage / 'conversion.json')['status'], 'failed')
        self.assertFalse((stage / 'specification.xlsx').exists())

    def test_success_publishes_manifest_last(self):
        self.make_pdf()
        stage = p.prepare(self.pdf, self.workspace, [2, 3])
        selection = p.validate_selection(stage)
        def fake_run(args, **kwargs):
            dest = Path(args[-1])
            sha = selection['specification_sha256']
            (dest / 'specification.xlsx').write_bytes(b'synthetic workbook')
            p.write_json(dest / 'specification_rows.json', {'specification_sha256': sha, 'row_count': 1, 'rows': [{}]})
            p.write_json(dest / 'verification.json', {'specification_sha256': sha, 'engine': 'native', 'protocol': {'ok': True, 'positions_parsed': 1}})
            return subprocess.CompletedProcess(args, 0, '', '')
        with patch.object(p.subprocess, 'run', side_effect=fake_run):
            result = p.convert_stage(stage)
        self.assertEqual(result['status'], 'verified_native')
        self.assertEqual(result['outputs_sha256']['specification.xlsx'], p.digest(stage / 'specification.xlsx'))
        self.assertEqual(result['quantity_scope'], 'design_specification_only_not_measured')

    @unittest.skipUnless((p.REPO / 'program-a' / 'tests' / 'test_pdf_systems.py').is_file(), 'requires repository converter fixture')
    def test_native_converter_from_existing_fixture(self):
        from openpyxl import load_workbook
        for directory in (p.REPO / 'program-a', p.REPO / 'program-a' / 'tests'):
            sys.path.insert(0, str(directory))
            self.addCleanup(sys.path.remove, str(directory))
        from test_pdf_systems import make_system_pdf
        spec = self.root / 'source_spec.pdf'
        make_system_pdf(spec)
        with fitz.open() as doc, fitz.open(spec) as source:
            doc.new_page().insert_text((30, 40), 'Cover')
            doc.insert_pdf(source)
            doc.new_page().insert_text((30, 40), 'Appendix')
            doc.save(self.pdf)
        stage = p.prepare(self.pdf, self.workspace, [2, 3])
        result = p.convert_stage(stage, timeout=120)
        self.assertEqual(result['status'], 'verified_native')
        self.assertGreater(result['positions_with_quantity'], 0)
        book = load_workbook(stage / 'specification.xlsx', data_only=True)
        self.addCleanup(book.close)
        self.assertEqual(book.active['K2'].value, 'П1-1')
        rows = p.read_json(stage / 'specification_rows.json')['rows']
        self.assertTrue(all(set(r['album_pdf_pages']) <= {2, 3} for r in rows))
        self.assertEqual(len(rows), result['row_count'])
        script = p.REPO / 'common' / 'web_clean_papper_specification.py'
        response = subprocess.run([sys.executable, str(script), '--file', str(self.pdf), '--first', '2', '--last', '3', '--sha', p.digest(self.pdf), '--action', 'convert'], capture_output=True, text=True, timeout=120)
        self.assertEqual(response.returncode, 0, response.stderr + response.stdout[:300])
        web = json.loads(response.stdout)
        self.assertEqual(web['status'], 'verified_native')
        self.assertEqual(web['row_count'], result['row_count'])
        self.assertEqual(len(web['downloads']), 3)
        from io import BytesIO
        with BytesIO(base64.b64decode(web['downloads'][0]['base64'])) as stream:
            check_book = load_workbook(stream, data_only=True)
            self.assertEqual(check_book.active['K2'].value, 'П1-1')
            check_book.close()


if __name__ == '__main__':
    unittest.main()