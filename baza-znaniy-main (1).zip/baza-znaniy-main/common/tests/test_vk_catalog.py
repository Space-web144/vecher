import json
from pathlib import Path
import tempfile
import unittest

from openpyxl import Workbook
from common.vk_catalog import encode_catalog, read_export, validate_catalog


class VKCatalogTest(unittest.TestCase):
    def export(self, root, rows):
        path = Path(root) / 'vk.xlsx'
        book = Workbook()
        sheet = book.active
        sheet.append(['Отбор:', 'Только ВК'])
        sheet.append([])
        sheet.append(['Ссылка.Код', None, None, 'Ссылка.Наименование', None, 'Ссылка.ЕдиницаИзмерения'])
        sheet.merge_cells('A3:C3')
        sheet.merge_cells('D3:E3')
        for code, name, unit in rows:
            sheet.append([code, None, None, name, None, unit])
        book.save(path)
        book.close()
        return path

    def test_preserve_codes_names_units_and_source_rows(self):
        import gzip
        with tempfile.TemporaryDirectory() as root:
            path = self.export(root, [('001', '  Муфта Ø20  ', 'шт'), ('002', '  Муфта Ø20  ', None)])
            data = read_export(path)
            self.assertEqual(data['item_count'], 2)
            self.assertEqual(data['missing_units'], 1)
            self.assertEqual(data['repeated_names'], 1)
            self.assertEqual(data['source']['header_row'], 3)
            self.assertEqual(data['items'][0], {'Код':'001', 'Наименование':'  Муфта Ø20  ',
                                               'ЕдиницаИзмерения':'шт', 'СтрокаИсточника':4})
            self.assertIsNone(data['items'][1]['ЕдиницаИзмерения'])
            self.assertEqual(json.loads(gzip.decompress(encode_catalog(data))), data)

    def test_duplicate_code_is_rejected_without_name_deduplication(self):
        with tempfile.TemporaryDirectory() as root:
            path = self.export(root, [('001','Муфта','шт'), ('001','Другая муфта','шт')])
            with self.assertRaisesRegex(ValueError, 'Duplicate VK code'):
                read_export(path)

    def test_missing_name_is_rejected(self):
        with tempfile.TemporaryDirectory() as root:
            with self.assertRaisesRegex(ValueError, 'missing Наименование'):
                read_export(self.export(root, [('001',None,'шт')]))

    def test_formula_is_not_executed_or_silently_imported(self):
        with tempfile.TemporaryDirectory() as root:
            with self.assertRaisesRegex(ValueError, 'Formula'):
                read_export(self.export(root, [('001','=1+1','шт')]))

    def test_wrong_schema_count_and_missing_unit_count(self):
        with tempfile.TemporaryDirectory() as root:
            data = read_export(self.export(root, [('001','Муфта',None)]))
            with self.assertRaisesRegex(ValueError, 'reviewed import'):
                validate_catalog(data, 2)
            data['missing_units'] = 0
            with self.assertRaisesRegex(ValueError, 'missing-unit count'):
                validate_catalog(data)


if __name__ == '__main__':
    unittest.main()
