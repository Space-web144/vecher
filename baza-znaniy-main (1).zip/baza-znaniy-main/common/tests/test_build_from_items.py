# -*- coding: utf-8 -*-
"""
Тесты сборки Tier 2 из списка в памяти (без файла/кэша) — нужно источникам
вроде VentSpec, у которых нет стабильного файла-справочника номенклатуры.
"""

import unittest

from common.keyword_search import KeywordMatcher
from common.fuzzy_search import FuzzyMatcher
from common.hybrid_matcher import build_hybrid_matcher_from_items
from common.query_processor import QueryProcessor


ITEMS = [
    {"code": "0", "name": "Отвод 90° Ø200 δ=0.8", "search_text": "Отвод 90° Ø200 δ=0.8"},
    {"code": "1", "name": "Клапан воздушный КВ-100", "search_text": "Клапан воздушный КВ-100"},
    {"code": "2", "name": "Решетка декоративная РКДК 600х400 Виктория",
     "search_text": "Решетка декоративная РКДК 600х400 Виктория"},
]


class KeywordMatcherFromItemsTests(unittest.TestCase):

    def test_search_finds_relevant_item(self):
        km = KeywordMatcher(query_processor=QueryProcessor())
        km.build_from_items(ITEMS)
        results = km.search("Отвод 90 Ø200", top_k=3)
        self.assertTrue(results)
        self.assertEqual(results[0][0]["code"], "0")


class FuzzyMatcherFromItemsTests(unittest.TestCase):

    def test_search_tolerates_typo(self):
        fm = FuzzyMatcher()
        fm.build_from_items(ITEMS)
        # опечатка: "Клапен" вместо "Клапан"
        results = fm.search("Клапен воздушный КВ-100", top_k=3, score_cutoff=50.0)
        self.assertTrue(results)
        self.assertEqual(results[0][0]["code"], "1")


class BuildHybridMatcherFromItemsTests(unittest.TestCase):

    def test_returns_usable_matcher(self):
        hm = build_hybrid_matcher_from_items(ITEMS)
        self.assertIsNotNone(hm.keyword_matcher)
        self.assertIsNotNone(hm.fuzzy_matcher)

        results = hm.search("Решетка РКДК 600х400", top_k=3)
        self.assertTrue(results)
        self.assertEqual(results[0][0]["code"], "2")


if __name__ == "__main__":
    unittest.main()
