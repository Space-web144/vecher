"""Clean Papper 10.1: whole-region sampling, original PDF IDs and album profiles."""
from __future__ import annotations

import unittest
from common.clean_papper_sampling import sample_drawings
from common.clean_papper_profile import normalized_profile, DEFAULTS, SCHEMA
from common.clean_papper_vector import extract_vector_candidates
from common.clean_papper_ducts import extract_duct_geometry


class Page:
    rect = (0.0, 0.0, 1000.0, 1000.0)

    def get_text(self, kind, **kwargs):
        return []


def path(*lines, color=(.5, .5, .5), fill=None):
    return {
        'rect': (0, 0, 500, 500),
        'color': color, 'fill': fill,
        'width': .5, 'dashes': 'solid',
        'items': [('l', a, b) for a, b in lines],
    }


class SelectionTests(unittest.TestCase):
    def test_late_colored_paths_never_lost_to_gray_prefix(self):
        gray = path(((20, 20), (30, 20)))
        red = path(((100, 100), (300, 100)), color=(1, 0, 0))
        drawing_list = [gray] * 60000 + [red]
        chosen, meta = sample_drawings(drawing_list, (0, 0, 500, 500), budget=200)
        self.assertEqual(len(chosen), 200)
        self.assertEqual(meta['source_paths_total'], 60001)
        self.assertEqual(meta['region_paths_total'], 60001)
        self.assertEqual(meta['colored_paths_in_region'], 1)
        self.assertEqual(meta['selected_paths'], 200)
        self.assertTrue(meta['sampling_truncated'])
        self.assertIn(60000, [original for original, _ in chosen])
        self.assertTrue(any(original > 50000 for original, _ in chosen))
        self.assertEqual(meta['stroke_colors_in_region'][0]['color'], '#808080')

    def test_fill_only_color_is_inventory_evidence(self):
        drawings = [path(((5, 5), (30, 5)), fill=(0, 0, 1))]
        chosen, meta = sample_drawings(drawings, (0, 0, 400, 400))
        self.assertEqual(len(chosen), 1)
        self.assertEqual(meta['colored_paths_in_region'], 1)
        self.assertEqual(meta['fill_colors_in_region'][0]['color'], '#0000ff')

    def test_crop_excludes_outside_paths_and_preserves_original_id(self):
        outside = dict(path(((400, 400), (500, 400))), rect=(400, 400, 500, 400))
        inside = dict(path(((10, 10), (50, 10))), rect=(10, 10, 50, 10))
        paths = [outside] * 400 + [inside]
        chosen, meta = sample_drawings(paths, (0, 0, 100, 100))
        self.assertEqual(len(chosen), 1)
        self.assertEqual(chosen[0][0], 400)
        self.assertEqual(meta['region_paths_total'], 1)
        vector = extract_vector_candidates(Page(), (0, 0, 100, 100), drawings=chosen)
        self.assertEqual(vector['candidates'][0]['source_id'], 'pdf_path_400_line_0')

    def test_duct_source_ids_keep_original_indices(self):
        selected = [
            (50211, path(((10, 50), (160, 50)), color=(1, 0, 0))),
            (77899, path(((10, 70), (160, 70)), color=(1, 0, 0))),
        ]
        out = extract_duct_geometry(Page(), (0, 0, 500, 300), drawings=selected)
        self.assertEqual(len(out['candidates']), 1)
        self.assertEqual(set(out['candidates'][0]['source_line_ids']),
                         {'pdf_path_50211_line_0', 'pdf_path_77899_line_0'})
        self.assertIsNone(out['candidates'][0]['physical_length_m'])

    def test_budget_must_stay_bounded(self):
        with self.assertRaises(ValueError):
            sample_drawings([], (0, 0, 100, 100), budget=1000000)


class ProfileTests(unittest.TestCase):
    def test_default_is_unverified(self):
        p=normalized_profile(None)
        self.assertEqual(p['region_kind'], 'unknown')
        self.assertEqual(p['nominal_scale'], 'unknown')
        self.assertEqual(p['geometry'], DEFAULTS)

    def test_custom_profile_changes_detection_without_calculating_metres(self):
        lines = [
            path(((20, 50), (190, 50))),
            path(((20, 90), (190, 90))),
        ]
        normal=extract_duct_geometry(Page(), (0, 0, 500, 300), drawings=lines)
        self.assertEqual(normal['candidates'], [])
        profile=normalized_profile({
            'schema':SCHEMA,'album':{'name':'project-a.pdf','size_bytes':100},
            'region_kind':'plan','nominal_scale':'1:100',
            'geometry':{'rect_min_pt':35,'rect_max_pt':45}
        })
        out=extract_duct_geometry(Page(), (0, 0, 500, 300), drawings=lines,
                                  settings=profile['geometry'])
        self.assertEqual(len(out['candidates']),1)
        self.assertEqual(out['candidates'][0]['width_between_strokes_pt'],40)
        self.assertIsNone(out['candidates'][0]['physical_length_m'])
        self.assertFalse(out['candidates'][0]['scale_verified'])

    def test_inconsistent_profiles_rejected(self):
        examples = [
            {'rect_min_pt':50,'rect_max_pt':20},
            {'coaxial_tol_pt':1000},
            {'dash_gap_min_pt':7,'dash_gap_max_pt':3},
            {'another_parameter':3}
        ]
        for geometry in examples:
            with self.subTest(geometry=geometry),self.assertRaises(ValueError):
                normalized_profile({'schema':SCHEMA,'geometry':geometry})

    def test_nan_and_invalid_album_rejected(self):
        with self.assertRaises(ValueError):
            normalized_profile({'schema':SCHEMA,'geometry':{'rect_min_pt':float('nan')}})
        with self.assertRaises(ValueError):
            normalized_profile({'schema':SCHEMA,'album':{'name':'x','size_bytes':True}})


if __name__ == '__main__':
    unittest.main()
