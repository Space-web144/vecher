"""Synthetic register tests without committing a customer's drawing."""
import unittest
from types import SimpleNamespace
from pathlib import Path
import sys

# The PDF worker is an isolated package; tests import it through its own root.
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'clean_papper_album_worker'))

from modules.pdf.drawing_register import (drawing_kind, extract_drawing_register,
                                          normalized_system, system_codes)


class FakePage:
    rect = SimpleNamespace(width=720)

    def __init__(self, text, words=None):
        self.text = text
        self.words = words or []

    def get_text(self, mode, sort=False):
        return self.words if mode == 'words' else self.text


def register_fixture(titles, match=True):
    words = [(85, 39, 160, 50, 'Ведомость', 0, 0, 0)]
    for n, title in enumerate(titles, 1):
        y = 100 + n * 28
        words.append((87, y, 101, y+10, str(n), n, 0, 0))
        x = 115
        for order, token in enumerate(title.split(' ')):
            words.append((x, y, x+len(token)*6, y+10, token, n, 1, order))
            x += len(token)*6+3
    doc = [FakePage('Ведомость рабочих чертежей основного комплекта', words)]
    doc.extend(FakePage(title if match else 'Другой документ') for title in titles[1:])
    if match:
        doc[0].text += ' ' + titles[0]
    return doc


class DrawingRegisterTests(unittest.TestCase):
    def test_systems_include_ve_and_normalize_separators(self):
        self.assertEqual(normalized_system('ВЕ 1'), 'ВЕ1')
        self.assertEqual(system_codes('ВЕ 1, П 1-1, ДК 2–3, ДП 5.2-1'),
                         ['ВЕ1', 'ДК2-3', 'ДП5.2-1', 'П1-1'])

    def test_misspelled_plan_and_conditioning_are_classified(self):
        self.assertEqual(drawing_kind('Планн технадстройки и кровли (нижния)'), 'plan')
        self.assertEqual(drawing_kind('Технадстрйка (вехняя)'), 'plan')
        self.assertEqual(drawing_kind('Кровля (вехняя)'), 'plan')
        self.assertEqual(drawing_kind('План 3-го этажа. Кондиционирование.'), 'conditioning_plan')

    def test_verified_sheet_register_with_contiguous_number_column(self):
        titles = ['Общие данные', 'Планн технадстройки и кровли (нижния)',
                  'Кровля (вехняя)', 'Схема системы ВЕ 1, ДП 2-1',
                  'План 2-го этажа. Кондиционирование.']
        result = extract_drawing_register(register_fixture(titles))
        self.assertEqual(result['status'], 'verified_register')
        self.assertEqual(result['verified_count'], 5)
        self.assertEqual(len(result['entries']), 5)
        self.assertEqual(result['entries'][1]['kind'], 'plan')
        self.assertEqual(result['entries'][3]['systems_in_title'], ['ВЕ1', 'ДП2-1'])
        self.assertFalse(result['entries'][2]['floor_multiplicity_approved'])

    def test_no_register_does_not_invent_sheets(self):
        result = extract_drawing_register([FakePage('План 3-го этажа вентиляция')])
        self.assertEqual(result['status'], 'not_found')
        self.assertEqual(result['entries'], [])

    def test_unverified_register_never_approves_page_classification(self):
        titles = ['План '+str(n)+'-го этажа вентиляция' for n in range(1, 7)]
        result = extract_drawing_register(register_fixture(titles, match=False))
        self.assertEqual(result['status'], 'unverified_register')
        self.assertEqual(result['verified_count'], 0)

if __name__ == '__main__':
    unittest.main()