<?php
declare(strict_types=1);

// Удаление дублей ВО ВСЕХ группах разом с web/onec_db_duplicates.php — в
// отличие от web/onec_db_duplicates_remove.php (отмеченные галочками
// позиции, максимум GROUPS_PER_PAGE групп за раз — ограничение
// постраничного вывода) здесь список кодов на удаление строится НА
// СЕРВЕРЕ из полного кэшированного отчёта (DB_DUPLICATES_CACHE), а не из
// чекбоксов в браузере: при тысячах групп кликать по страницам, отмечая
// каждую, непрактично. Применяется тот же умолчательный выбор, что
// показан в браузере по умолчанию на каждой странице — оставить первую
// позицию группы, удалить остальные.
//
// Сам список кодов — всего лишь предложение; окончательное решение,
// какие коды реально удалять, принимает common/web_db_duplicates_remove_
// run.py, заново пересчитывая группы дублей по текущему DB_FILE
// (--codes-file может сильно устареть, если кто-то поменял базу между
// открытием страницы и этим действием). Доступно только admin/mainadmin.

require __DIR__ . '/admin_guard.php';
require __DIR__ . '/config.php';

function back_with(array $params): never {
    header('Location: onec_db_duplicates.php?' . http_build_query($params));
    exit;
}

function back_with_error(string $message, int $page): never {
    back_with(['page' => $page, 'err' => $message]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: onec_db_duplicates.php');
    exit;
}

$page = max(1, (int) ($_POST['page'] ?? 1));

if (empty($_SESSION['csrf']) || !hash_equals((string) $_SESSION['csrf'], (string) ($_POST['csrf'] ?? ''))) {
    back_with_error('Сессия истекла, обновите страницу и попробуйте снова.', $page);
}

if (!is_file(DB_DUPLICATES_CACHE)) {
    back_with_error('Нет посчитанного отчёта о дублях — откройте страницу «Дубли номенклатуры» ещё раз.', $page);
}

$raw = file_get_contents(DB_DUPLICATES_CACHE);
$report = $raw !== false ? json_decode($raw, true) : null;
if (!is_array($report) || !is_array($report['groups'] ?? null)) {
    back_with_error('Кэш отчёта о дублях повреждён — откройте страницу «Дубли номенклатуры» ещё раз.', $page);
}

// Тот же умолчательный выбор, что в браузере: первая позиция группы
// остаётся, остальные — на удаление.
$codes = [];
foreach ($report['groups'] as $group) {
    if (!is_array($group) || count($group) < 2) {
        continue;
    }
    foreach (array_slice($group, 1) as $it) {
        $code = (string) ($it['Код'] ?? '');
        if ($code !== '') {
            $codes[] = $code;
        }
    }
}
$codes = array_values(array_unique($codes));
if (!$codes) {
    back_with_error('В отчёте не нашлось позиций на удаление.', $page);
}

if (!is_file(DB_FILE)) {
    back_with_error('Боевая база сравнения (DB_FILE) ещё не положена на сервер.', $page);
}
if (!is_dir(OUTPUT_DIR) || !is_writable(OUTPUT_DIR)) {
    back_with_error('Папка для результатов недоступна на сервере.', $page);
}

$codesPath = OUTPUT_DIR . '/dup_remove_codes_' . bin2hex(random_bytes(8)) . '.json';
if (file_put_contents($codesPath, json_encode($codes, JSON_UNESCAPED_UNICODE)) === false) {
    back_with_error('Не удалось сохранить список выбранных позиций на сервере.', $page);
}

$cmdParts = [
    escapeshellarg(PYTHON_BIN),
    escapeshellarg(WEB_DB_DUPLICATES_REMOVE_SCRIPT),
    '--db', escapeshellarg(DB_FILE),
    '--codes-file', escapeshellarg($codesPath),
];
if (is_file(ONEC_NOMENCLATURE_FILE)) {
    $cmdParts[] = '--existing';
    $cmdParts[] = escapeshellarg(ONEC_NOMENCLATURE_FILE);
}

$cmd = implode(' ', $cmdParts) . ' 2>&1';
$output = shell_exec($cmd);
@unlink($codesPath);

if ($output === null || trim($output) === '') {
    back_with_error('Не удалось удалить дубли: команда не выполнилась (shell_exec недоступен на '
        . 'сервере, или путь PYTHON_BIN в config.php неверный).', $page);
}

$result = json_decode($output, true);
if (!is_array($result) || empty($result['ok'])) {
    // Admin-only страница — показываем реальный вывод скрипта, как и на
    // onec_db_duplicates_remove.php/onec_review_bulk.php.
    $detail = is_array($result) ? (string) ($result['error'] ?? 'неизвестная ошибка') : trim($output);
    if (mb_strlen($detail, 'UTF-8') > 2000) {
        $detail = '…' . mb_substr($detail, -2000, null, 'UTF-8');
    }
    back_with_error('Не удалось удалить дубли: ' . $detail, $page);
}

back_with([
    'page' => $page,
    'removed' => 1,
    'dbRemoved' => (int) ($result['db_removed'] ?? 0),
    'skippedCount' => count($result['skipped'] ?? []),
]);
