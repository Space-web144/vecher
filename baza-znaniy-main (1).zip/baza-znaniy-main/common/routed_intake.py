"""Catalog-aware intake and every review approval path, sharing one storage lock."""
from collections import Counter
from pathlib import Path
import re

from common import nomenclature_intake as legacy
from common.catalog_store import CatalogStore, json_bytes, read_json
from common.nomenclature_routing import CATALOGS, code_of, normalize_name, route_item




class WaterChecker(legacy.IntakeChecker):
    """Text checks only; air-duct geometry must never compare plumbing fittings."""
    def __init__(self, items, name_key, code_key):
        self.name_key, self.code_key = name_key, code_key
        self._existing_items = [it for it in items if it.get(name_key)]
        self._existing_names_norm = [legacy.normalize(it[name_key]) for it in self._existing_items]
        self._by_exact_norm = {}
        for it in self._existing_items:
            self._by_exact_norm.setdefault(legacy.normalize(it[name_key]), it)

    def find_tier1_duplicate(self, name):
        return None

    def check(self, item, semantic):
        name = item[self.name_key]
        flags = []
        duplicate = self.find_exact_text_duplicate(name)
        if duplicate is not None:
            flags.append({'type': 'possible_duplicate', 'detail': 'Совпадение наименования в ВК: код ' +
                          code_of(duplicate, self.code_key), 'existing_code': duplicate.get(self.code_key)})
        else:
            typo = self.find_typo_candidate(name)
            if typo:
                candidate, score = typo
                flags.append({'type': 'possible_typo', 'detail': 'Похожее наименование в ВК: «' +
                              candidate[self.name_key] + '»', 'similarity': score})
            similar = semantic.get(name)
            if similar and legacy.normalize(similar) != legacy.normalize(name):
                flags.append({'type': 'semantic_similarity', 'detail': 'Возможный дубль в ВК: «' + similar + '»'})
        return flags


def flag(result, kind, detail):
    result['flags'].append({'type': kind, 'detail': detail})


def check_batch(raw_items, store, credentials=None, client=None, log=None):
    items, skipped = legacy.filter_processable(raw_items, store.name_key)
    results, groups = [], {catalog: [] for catalog in CATALOGS}
    codes = Counter(code_of(it, store.code_key) for it in items)
    batch_names = Counter()
    for i, item in enumerate(items):
        routing = route_item(item, store.memberships, store.assignments, store.name_key, store.code_key)
        result = {'code': item.get(store.code_key), 'name': item.get(store.name_key),
                  'kind': item.get('ВидНоменклатуры'), 'category': 'vk' if routing['catalog'] == 'vk' else 0,
                  'flags': [], 'routing': routing}
        results.append(result)
        code = code_of(item, store.code_key)
        catalog = routing['catalog']
        if not isinstance(item.get(store.name_key), str) or not isinstance(item.get(store.code_key), str):
            flag(result, 'invalid_fields', 'Код и наименование должны быть строками')
        if item.get('ЕдиницаИзмерения') is not None and not isinstance(item['ЕдиницаИзмерения'], str):
            flag(result, 'invalid_fields', 'Единица измерения должна быть строкой или null')
        if not code:
            flag(result, 'missing_code', 'Нет кода 1С: карточку нужно исправить в источнике')
        if codes[code] > 1:
            flag(result, 'batch_code_conflict', 'Этот код несколько раз встречается в пачке; проверьте записи')
        if not catalog:
            flag(result, 'catalog_review', routing['reason'])
            continue
        key = (catalog, normalize_name(item.get(store.name_key)))
        batch_names[key] += 1
        existing = store.by_code[catalog].get(code)
        if existing:
            if normalize_name(existing.get(store.name_key)) != normalize_name(item.get(store.name_key)):
                flag(result, 'code_changed', 'Код уже существует с другим наименованием; проверьте обновление карточки')
            # An unchanged known code is an idempotent update, not a duplicate of itself.
        elif not result['flags']:
            groups[catalog].append(i)
    for result in results:
        catalog = result['routing']['catalog']
        if catalog and batch_names[(catalog, normalize_name(result['name']))] > 1:
            flag(result, 'batch_name_duplicate', 'Одинаковое наименование встречается в пачке более одного раза')
    # Share the request budget across both departments.
    semantic_status, semantic_ran = [], False
    if client is None and credentials:
        try:
            client = legacy.AnthropicClient(credentials_file=credentials, log=log,
                                             max_requests=legacy.DUPLICATE_MAX_REQUESTS)
        except legacy.AnthropicError as exc:
            semantic_status.append('не выполнена: ' + str(exc))
    for catalog, indices in groups.items():
        indices = [i for i in indices if not results[i]['flags']]
        if not indices:
            continue
        checker = (WaterChecker if catalog == 'vk' else legacy.IntakeChecker)(
            store.items[catalog], name_key=store.name_key, code_key=store.code_key)
        names = [items[i][store.name_key] for i in indices
                 if checker.find_exact_text_duplicate(items[i][store.name_key]) is None
                 and checker.find_tier1_duplicate(items[i][store.name_key]) is None]
        semantic, status, ran = legacy.resolve_duplicate_candidates(names, checker, client=client, log=log)
        semantic_ran |= ran
        if status:
            semantic_status.append(CATALOGS[catalog] + ': ' + status)
        for i in indices:
            if catalog == 'vk':
                results[i]['flags'].extend(checker.check(items[i], semantic))
            else:
                checked = legacy.check_item(items[i], checker, semantic)
                results[i]['category'] = checked['category']
                results[i]['flags'].extend(f for f in checked['flags'] if f['type'] != 'not_vent_relevant')
    for result in results:
        result['ok'] = not result['flags']
    stats = {'total_input': len(raw_items), 'total_checked': len(items), **skipped,
             'ok': sum(r['ok'] for r in results), 'flagged': sum(not r['ok'] for r in results),
             'by_flag_type': dict(Counter(f['type'] for r in results for f in r['flags'])),
             'by_catalog': dict(Counter(r['routing']['catalog'] or 'review' for r in results)),
             'semantic_check_enabled': semantic_ran, 'semantic_check_status': '; '.join(semantic_status) or None}
    return items, results, stats


def process_intake(raw_items, store, pending_path, token, output, credentials=None, log=None):
    if not pending_path or not token:
        raise ValueError('Для приёма обязательна очередь ручной проверки')
    with store.locked():
        store.load()
        revision = store.revision()
    items, results, stats = check_batch(raw_items, store, credentials, log=log)
    with store.locked():
        if store.revision() != revision:
            store.load()
            # Recheck against concurrent approvals; reuse only department-matching AI flags.
            previous = results
            previous_semantic_ran = stats['semantic_check_enabled']
            items, results, stats = check_batch(raw_items, store)
            for old, new in zip(previous, results):
                if old['routing']['catalog'] == new['routing']['catalog']:
                    new['flags'].extend(f for f in old['flags'] if f['type'] == 'semantic_similarity')
                    new['ok'] = not new['flags']
            stats['semantic_check_enabled'] = previous_semantic_ran
            stats['semantic_check_status'] = 'База обновилась во время проверки; выполнена повторная проверка'
        clean = [(item, result['routing']['catalog']) for item, result in zip(items, results) if result['ok']]
        writes, counts = store.upserts(clean)
        pending = [{'id': i, 'token': token, 'raw_item': item, 'flags': result['flags'],
                    'routing': result['routing'], 'resolved': False}
                   for i, (item, result) in enumerate(zip(items, results)) if not result['ok']]
        writes[Path(pending_path)] = json_bytes(pending)
        store.commit(writes)
    stats.update({'ok': sum(r['ok'] for r in results), 'flagged': len(pending),
                  'by_flag_type': dict(Counter(f['type'] for r in results for f in r['flags'])),
                  'auto_added': counts.get('added', 0), 'auto_updated': counts.get('updated', 0),
                  'auto_unchanged': counts.get('unchanged', 0), 'auto_by_catalog': {c: counts.get(c, 0) for c in CATALOGS},
                  'pending_review': len(pending)})
    write_report(results, stats, output)
    return stats


def write_report(results, stats, output):
    # Keep the existing seven columns and append routing evidence.
    legacy.write_intake_report(results, stats, output)
    from openpyxl import load_workbook
    book = load_workbook(output)
    try:
        sheet = book.worksheets[0]
        sheet.cell(1, 8, 'Раздел'); sheet.cell(1, 9, 'Основание распределения')
        sheet.column_dimensions['H'].width = 20; sheet.column_dimensions['I'].width = 70
        for row, result in enumerate(results, 2):
            routing = result['routing']
            sheet.cell(row, 8, CATALOGS.get(routing['catalog'], 'Ручной выбор'))
            sheet.cell(row, 9, routing['reason'])
            if routing['catalog'] == 'vk':
                sheet.cell(row, 4, 'ВК')
            # All received names/codes/details are text, even if starting with '='.
            for cell in sheet[row]:
                if isinstance(cell.value, str):
                    cell.data_type = 's'
        summary = book.worksheets[1]
        for catalog, count in stats['by_catalog'].items():
            summary.append(['Раздел: ' + CATALOGS.get(catalog, 'Ручной выбор'), count])
        book.save(output)
    finally:
        book.close()


def review_items(store, selections, catalog=None, reject=False):
    """selections=(pending_path,id,edited_name_or_None). Ambiguous bulk rows stay pending."""
    if catalog is not None and catalog not in CATALOGS:
        raise ValueError('Некорректный раздел')
    with store.locked():
        if not reject:
            store.load()
        loaded, approved, errors, entries = {}, [], [], []
        seen = set()
        for path, item_id, edited_name in selections:
            path = Path(path).resolve()
            key = (path, item_id)
            if key in seen:
                continue
            seen.add(key)
            try:
                if path not in loaded:
                    loaded[path] = read_json(path)
                entry = next((e for e in loaded[path] if e.get('id') == item_id), None)
                if entry is None or entry.get('resolved'):
                    raise ValueError('Позиция отсутствует или уже обработана')
                raw = dict(entry['raw_item'])
                if edited_name is not None:
                    raw[store.name_key] = edited_name
                if not reject:
                    routing = route_item(raw, store.memberships, store.assignments, store.name_key, store.code_key)
                    target = catalog or routing['catalog']
                    if target not in CATALOGS:
                        raise ValueError('Выберите раздел: Вентиляция или ВК')
                    code = code_of(raw, store.code_key)
                    if not code or not isinstance(raw.get(store.name_key), str) or not raw[store.name_key].strip():
                        raise ValueError('Нет кода или наименования; исправьте карточку в 1С')
                    if raw.get('ЕдиницаИзмерения') is not None and not isinstance(raw['ЕдиницаИзмерения'], str):
                        raise ValueError('Неверная единица измерения; исправьте карточку в 1С')
                    known = store.memberships.get(code, set())
                    if known and target not in known:
                        raise ValueError('Код закреплён за другим разделом; перенос не выполняется')
                    # Multiple conflicting versions of one code cannot overwrite each other in one approval.
                    if any(code_of(other, store.code_key) == code for other, _ in entries):
                        raise ValueError('Код уже выбран в этой операции; согласуйте версии отдельно')
                    entries.append((raw, target))
                    entry['resolved_catalog'] = target
                    entry['resolution_method'] = 'manual' if catalog else routing['method']
                    entry['resolved_name'] = raw[store.name_key]
                else:
                    entry['rejected'] = True
                entry['resolved'] = True
                approved.append(entry)
            except (ValueError, OSError, TypeError) as exc:
                errors.append({'token': path.name[:-len('_1c_pending.json')], 'id': item_id, 'error': str(exc)})
        writes = {}
        if entries:
            writes, _ = store.upserts(entries, manual=True)
        for path, data in loaded.items():
            if any(e in approved for e in data):
                writes[path] = json_bytes(data)
        store.commit(writes)
        return {'rejected' if reject else 'promoted': len(approved), 'errors': errors, 'items': approved}


def bulk_selections(raw_selections, directory):
    result = []
    for token, item_id in raw_selections:
        if not re.fullmatch(r'[a-f0-9]{16}', token) or item_id < 0:
            raise ValueError('Некорректный токен или идентификатор')
        result.append((Path(directory) / (token + '_1c_pending.json'), item_id, None))
    return result
