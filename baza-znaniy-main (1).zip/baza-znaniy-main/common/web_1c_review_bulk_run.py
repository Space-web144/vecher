# -*- coding: utf-8 -*-
"""Синхронное массовое согласование очереди 1С.
Список token/id передаётся файлом. Неопределённые разделы остаются в очереди,
если администратор не передал общий --catalog для выбранных позиций."""

import os

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import sys
import json
import argparse

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pathlib import Path
from common.nomenclature_intake import load_json_items  # noqa: E402
from common.catalog_store import CatalogStore  # noqa: E402
from common.routed_intake import bulk_selections, review_items  # noqa: E402



def main():
    parser = argparse.ArgumentParser(description="Массовое подтверждение/отклонение позиций из очереди ручной проверки 1С")
    parser.add_argument("--selections-file", required=True,
                         help='JSON-файл со списком [{"token": "...", "id": N}, ...]')
    parser.add_argument("--pending-dir", required=True,
                         help="папка с файлами очереди <токен>_1c_pending.json (обычно OUTPUT_DIR)")
    parser.add_argument("--reject", action="store_true",
                        help="отклонить позиции вместо добавления — никуда не попадают, просто уходят из очереди")
    parser.add_argument("--existing", default=None, help="путь к эталонному снимку номенклатуры — не нужно при --reject")
    parser.add_argument("--db-file", default=None, help="боевая база сравнения (DB_FILE), опционально")
    parser.add_argument("--name-key", default="Наименование")
    parser.add_argument("--code-key", default="Код")
    parser.add_argument("--catalog", choices=("ventilation", "vk"), default=None)
    args = parser.parse_args()

    if not args.reject and not args.existing:
        parser.error("--existing обязателен, если не указан --reject")

    try:
        raw_selections = load_json_items(args.selections_file)
        selections = [(str(s["token"]), int(s["id"])) for s in raw_selections]

        existing = args.existing or str(Path(args.pending_dir).parent / '1c_full_nomenclature.json')
        store = CatalogStore(existing, args.db_file, args.name_key, args.code_key)
        result = review_items(store, bulk_selections(selections, args.pending_dir), args.catalog, args.reject)
        result.pop('items', None)
        # "rejected" в result — ЧИСЛО отклонённых (от reject_reviewed_items_bulk),
        # а не признак действия, поэтому его не дублируем отдельным булевым
        # полем под тем же именем: PHP и так знает, какое действие само
        # запросило — через --reject.
        print(json.dumps({"ok": True, "action": "reject" if args.reject else "promote", **result},
                          ensure_ascii=False))
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False))
        sys.exit(1)


if __name__ == "__main__":
    main()
