# -*- coding: utf-8 -*-
"""
Дамп DB_FILE (боевая база сравнения VentSpec, Excel: колонка A = Код,
колонка B = Наименование, строка 1 — заголовок) в JSON для
web/onec_database.php — PHP в этом проекте никогда не парсит .xlsx сам,
везде, где нужен Excel, PHP шлёт запрос в Python (см.
program-a/web_run.py и соседние скрипты).

Наименования читаются ЧЕРЕЗ ТУ ЖЕ функцию (_load_names_from_file), что и
сама матчинг-логика (program-a/vent_processor.py::_build_indexes) — не
отдельная копия парсинга формата, чтобы страница гарантированно
показывала именно те позиции (и в том же порядке), которые видит
сопоставление. Код (колонка A) сам матчер вообще не читает (индекс
строится только по именам, см. _build_indexes: items = [{"original": n}
for n in names]) — здесь он читается отдельно, только для показа
администратору, не потому что участвует в сравнении. Если построчное
сопоставление кода с именем вдруг разойдётся с авторитетным списком имён
(например, кто-то поправит один из парсеров и забудет другой) — отдаём
имена БЕЗ кодов, а не рискуем подписать код не той позиции.

Каждая позиция дополнительно несёт категорию/толщину/длину/сечение (см.
_enrich_item) — для дерева категорий на web/onec_database.php (воздуховоды
сгруппированы по толщине металла, внутри группы упорядочены по сечению и
длине). Эти поля считаются ТЕМИ ЖЕ функциями common.matcher/common.
parameters и с ТЕМИ ЖЕ аргументами, что использует сам
NomenclatureIndex._build при индексации базы — группировка на странице
гарантированно совпадает с тем, как сопоставление само видит эти позиции.

Пример вызова:
  python3 web_db_file_dump.py --db /path/1c_base.xlsx --out /path/db_file_dump.json
"""
import os

# Обязательно ДО любого импорта, который тянет vent_processor (а через
# него — numpy) — см. program-a/web_run.py за той же историей: на этом
# хостинге жёсткий лимит процессов (RLIMIT_NPROC) на аккаунт, и OpenBLAS,
# не ограниченный заранее, пытается завести поток на каждое ядро сервера
# (а не аккаунта) и падает с
# "pthread_create failed... Resource temporarily unavailable"
# — воспроизведено вживую на проде именно в этом скрипте (забыла
# поставить при первой версии, в отличие от всех остальных web_*_run.py).
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import sys
import json
import argparse

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "program-a"))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from openpyxl import load_workbook  # noqa: E402
from vent_processor import _load_names_from_file  # noqa: E402
from common.matcher import determine_category  # noqa: E402
from common.parameters import extract_geometry, extract_sections  # noqa: E402

# Меняется при любом изменении состава полей ниже — web/onec_database.php
# сверяет его с уже посчитанным кэшем и, если не совпало, пересчитывает
# заново независимо от времени изменения DB_FILE (иначе старый кэш,
# оставшийся с прошлой версии схемы, просто молча показывался бы дальше —
# DB_FILE-то не менялся).
SCHEMA_VERSION = 3


def _format_section(section):
    """Сечение для показа человеку: Ø100 (круглое) или 350x200
    (прямоугольное) — тот же порядок величин, что хранит extract_sections,
    ничего не переставляем и не сортируем."""
    if not section:
        return None
    if len(section) == 1:
        return f"Ø{section[0]}"
    return "x".join(str(v) for v in section)


def _enrich_item(code, name):
    """Категория/геометрия — ТЕМИ ЖЕ функциями и с ТЕМИ ЖЕ аргументами,
    что строит индекс сам матчер (common.matcher.NomenclatureIndex._build:
    determine_category(name, is_spec_row=True), extract_geometry(name,
    is_spec_row=True), extract_sections(name, geom["kw"], False) для
    категорий 2/3) — чтобы группировка на странице «База» совпадала с
    тем, что видит сопоставление, а не была отдельной, потенциально
    расходящейся интерпретацией той же строки.

    "Вид" (geom["kw"]) — конкретный тип внутри категории 3 "Фасонные изделия"
    (ОТВОД/ПЕРЕХОД/ТРОЙНИК/ВРЕЗКА/ЗАГЛУШКА/КРЕСТОВИНА) или "ВОЗДУХОВОД"
    для категории 2 — нужен, чтобы на странице «База» различать, скажем,
    отводы от тройников внутри одной категории "Фасонные изделия"."""
    geom = extract_geometry(name, is_spec_row=True)
    category = determine_category(name, is_spec_row=True)
    section = None
    if category in (2, 3) and geom["kw"] is not None:
        sections = extract_sections(name, geom["kw"], False)
        if sections:
            section = list(sections[0])
    return {
        "Код": code,
        "Наименование": name,
        "Категория": category,
        "Вид": geom["kw"],
        "Толщина": geom["thickness"],
        "Длина": geom["length"],
        "Сечение": _format_section(section),
        "СечениеКлюч": section,
    }


def _load_items_with_codes(path):
    authoritative_names = _load_names_from_file(path)

    names, codes = [], []
    if not path.lower().endswith(".csv"):
        wb = load_workbook(path, data_only=True, read_only=True)
        try:
            ws = wb.active
            first = True
            for row in ws.iter_rows(min_row=1, values_only=True):
                if first:
                    first = False
                    continue
                if len(row) >= 2 and row[1]:
                    name = str(row[1]).strip()
                    if name:
                        names.append(name)
                        codes.append(str(row[0]).strip() if row[0] else "")
        finally:
            wb.close()

    if names != authoritative_names:
        codes = [""] * len(authoritative_names)
        names = authoritative_names

    return [_enrich_item(c, n) for c, n in zip(codes, names)]


def main():
    parser = argparse.ArgumentParser(description="Дамп DB_FILE в JSON для web/onec_database.php")
    parser.add_argument("--db", required=True, help="путь к DB_FILE (.xlsx/.csv)")
    parser.add_argument("--out", required=True, help="куда сохранить JSON-дамп")
    args = parser.parse_args()

    if not os.path.isfile(args.db):
        print(json.dumps({"ok": False, "error": f"Файл не найден: {args.db}"}, ensure_ascii=False))
        sys.exit(1)

    try:
        items = _load_items_with_codes(args.db)
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False))
        sys.exit(1)

    tmp_path = args.out + ".tmp"
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump({"schema_version": SCHEMA_VERSION, "items": items}, f, ensure_ascii=False)
    os.replace(tmp_path, args.out)
    print(json.dumps({"ok": True, "count": len(items)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
