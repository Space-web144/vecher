"""Trace reviewable PDF vector LINE strokes; not proven duct centerlines.

IDs identify the PDF drawing path/item on this page, not original DWG handles.
No PDF coordinate is converted to meters by this module.
"""
from __future__ import annotations

import math
import re

MAX_PATHS = 50000
MAX_OUTPUT = 55
MIN_SEGMENT_PT = 9.0
SYSTEM_RE = re.compile(
    r"(?<!\w)(?:ДП|ДВ|ДК|В|П|ПД)\s*\d+(?:[.,]\d+)?(?:\s*[-–]\s*\d+)?", re.I
)


def _point(value):
    try:
        return float(value.x), float(value.y)
    except AttributeError:
        try:
            return float(value[0]), float(value[1])
        except (TypeError, ValueError, IndexError):
            return None


def _clip_line(a, b, bounds):
    """Liang-Barsky clipping in PDF-point coordinates."""
    x0, y0, x1, y1 = bounds
    dx, dy = b[0] - a[0], b[1] - a[1]
    p = (-dx, dx, -dy, dy)
    q = (a[0] - x0, x1 - a[0], a[1] - y0, y1 - a[1])
    t0, t1 = 0.0, 1.0
    for pi, qi in zip(p, q):
        if abs(pi) < 1e-9:
            if qi < 0:
                return None
            continue
        u = qi / pi
        if pi < 0:
            t0 = max(t0, u)
        else:
            t1 = min(t1, u)
        if t0 > t1:
            return None
    return (a[0] + dx * t0, a[1] + dy * t0), (a[0] + dx * t1, a[1] + dy * t1)


def _on_page(point, page_rect):
    return [
        round((point[0] - page_rect[0]) / (page_rect[2] - page_rect[0]), 6),
        round((point[1] - page_rect[1]) / (page_rect[3] - page_rect[1]), 6),
    ]


def _distance_to_segment(p, a, b):
    dx, dy = b[0] - a[0], b[1] - a[1]
    den = dx * dx + dy * dy
    if not den:
        return math.dist(p, a)
    t = min(1.0, max(0.0, ((p[0] - a[0]) * dx + (p[1] - a[1]) * dy) / den))
    return math.dist(p, (a[0] + t * dx, a[1] + t * dy))


def _color(value):
    if not isinstance(value, (list, tuple)) or len(value) != 3:
        return None, False
    try:
        rgb = [float(v) for v in value]
    except (TypeError, ValueError):
        return None, False
    if not all(math.isfinite(v) and 0 <= v <= 1 for v in rgb):
        return None, False
    return '#%02x%02x%02x' % tuple(round(v * 255) for v in rgb), (
        max(rgb) - min(rgb) > .32
    )


def _system_labels(page, bounds, max_labels=100):
    """System text is a spatial hint only, never a verified association."""
    import fitz

    result, seen = [], set()
    for block in page.get_text('blocks', clip=fitz.Rect(bounds))[:550]:
        if len(block) < 5 or not isinstance(block[4], str):
            continue
        for match in SYSTEM_RE.finditer(block[4]):
            name = re.sub(r'\s+', '', match.group(0)).replace(',', '.')[:40]
            position = (
                (float(block[0]) + float(block[2])) / 2,
                (float(block[1]) + float(block[3])) / 2,
            )
            key = name, round(position[0]), round(position[1])
            if key not in seen:
                seen.add(key)
                result.append({
                    'label': name,
                    'at_pdf_pt': [round(position[0], 2), round(position[1], 2)],
                })
            if len(result) >= max_labels:
                return result
    return result


def extract_vector_candidates(page, region, section_labels=None, max_paths=MAX_PATHS, drawings=None):
    """Return ranked *individual* visible LINE segments for manual review."""
    bounds = tuple(float(x) for x in region)
    page_rect = tuple(float(x) for x in page.rect)
    if not (bounds[0] < bounds[2] and bounds[1] < bounds[3]) or any(
        not math.isfinite(x) for x in bounds
    ):
        raise ValueError('Invalid region')
    if not (page_rect[0] <= bounds[0] < bounds[2] <= page_rect[2] and
            page_rect[1] <= bounds[1] < bounds[3] <= page_rect[3]):
        raise ValueError('Region outside PDF page')
    text_candidates = []
    for i, item in enumerate(section_labels or []):
        try:
            coords = item['at_pdf_pt']
            position = (float(coords[0]), float(coords[1]))
            if all(math.isfinite(v) for v in position):
                text_candidates.append((
                    str(item.get('text', ''))[:50], position, 'T%02d' % (i + 1)
                ))
        except (KeyError, ValueError, TypeError, IndexError):
            continue

    sys_labels = _system_labels(page, bounds)
    count, colored, limited, sampled, seen = 0, 0, False, [], set()
    paths = drawings if drawings is not None else (page.get_cdrawings() if hasattr(page, 'get_cdrawings') else page.get_drawings())
    for sampled_index, entry in enumerate(paths):
        if sampled_index >= max_paths:
            limited = True
            break
        if isinstance(entry, tuple) and len(entry)==2 and isinstance(entry[0], int):
            path_index, drawing = entry
        else:
            path_index, drawing = sampled_index, entry
        count += 1
        hex_color, saturated = _color(drawing.get('color'))
        if saturated:
            colored += 1
        for item_index, item in enumerate(drawing.get('items') or []):
            if item[0] != 'l' or len(item) < 3:
                continue
            a, b = _point(item[1]), _point(item[2])
            if a is None or b is None or not all(math.isfinite(v) for v in a + b):
                continue
            clipped = _clip_line(a, b, bounds)
            if clipped is None:
                continue
            start, end = clipped
            length = math.dist(start, end)
            if length < MIN_SEGMENT_PT:
                continue
            key = tuple(sorted((
                (round(start[0], 1), round(start[1], 1)),
                (round(end[0], 1), round(end[1], 1))
            )))
            if key in seen:
                continue
            seen.add(key)
            nearest = None
            if text_candidates:
                distance, label_id, label = min(
                    (_distance_to_segment(position, start, end), ident, text)
                    for text, position, ident in text_candidates
                )
                if distance <= 68:
                    nearest = {
                        'label_id': label_id, 'text': label,
                        'distance_pdf_pt': round(distance, 2)
                    }
            sys_hint = None
            if sys_labels:
                distance, label = min(
                    (_distance_to_segment(tuple(item['at_pdf_pt']), start, end),
                     item['label']) for item in sys_labels
                )
                if distance <= 90:
                    sys_hint = {
                        'text': label, 'distance_pdf_pt': round(distance, 2)
                    }
            score = (
                (5000 if nearest else 0) + (800 if saturated else 0)
                + min(length, 350) + (65 if sys_hint else 0)
            )
            sampled.append((score, {
                'source_id': 'pdf_path_%d_line_%d' % (path_index, item_index),
                'status': 'unverified_pdf_line',
                'start_pdf_pt': [round(start[0], 3), round(start[1], 3)],
                'end_pdf_pt': [round(end[0], 3), round(end[1], 3)],
                'start_page_norm': _on_page(start, page_rect),
                'end_page_norm': _on_page(end, page_rect),
                'projected_length_pt': round(length, 3),
                'stroke_color': hex_color,
                'colored_stroke': saturated,
                'dimension_text_nearby': nearest,
                'system_text_nearby': sys_hint,
                'scale_verified': False,
                'physical_length_m': None,
            }))
    sampled.sort(key=lambda row: (-row[0], row[1]['source_id']))
    selected = []
    for idx, (score, candidate) in enumerate(sampled[:MAX_OUTPUT], 1):
        candidate['candidate_id'] = 'L%03d' % idx
        selected.append(candidate)
    return {
        'source_page_rect_pdf_pt': list(page_rect),
        'region_pdf_pt': list(bounds),
        'path_scanning': {
            'scanned_paths': count,
            'max_scanned_paths': max_paths,
            'scan_truncated': limited,
            'candidate_lines_found': len(sampled),
            'candidates_returned': len(selected),
            'colored_paths_encountered': colored,
        },
        'candidates': selected,
        'limitations': [
            'PDF strokes are not proven duct centerlines',
            'Near text is not a verified object-system or object-size association',
            'Source IDs are specific to this exact PDF page and drawing order',
            'PDF points require independent calibration before any meter conversion',
            'Manual planar calibration does not prove actual duct length or vertical rise',
            'Candidate discovery may truncate dense PDF drawings',
        ],
    }
