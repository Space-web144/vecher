"""Stage 10.2: angled colored PDF stroke pairs and spatial hints.

Evidence only. A parallel pair is not a verified ventilation duct. Every ID
refers to the source PDF page/drawing order; physical quantities stay null.
"""
from __future__ import annotations

import collections
import math

from common.clean_papper_profile import DEFAULTS
from common.clean_papper_vector import (
    _clip_line, _color, _point, _on_page, _distance_to_segment
)

MIN_STROKE_PT = 2.5
MIN_OVERLAP_PT = 9.0
MAX_CANDIDATES = 100
MAX_SOURCE_IDS = 24
MAX_LINE_ITEMS = 35000
ANGLE_STEP_DEG = 1.0
LATERAL_TOL_PT = .14
MAX_JOIN_GAP_PT = 2.6
MIN_PAIR_GAP_PT = .8
MAX_PAIR_GAP_PT = 32.
CONNECT_PT = 3.5


def _pt(p):
    return [round(x, 3) for x in p]


def _nearest_label(a, b, labels):
    best = None
    for label in labels or []:
        pos = label.get('at_pdf_pt')
        if not isinstance(pos, (list, tuple)) or len(pos) != 2:
            continue
        try:
            point = float(pos[0]), float(pos[1])
        except (ValueError, TypeError, OverflowError):
            continue
        if not all(math.isfinite(x) for x in point):
            continue
        dist = _distance_to_segment(point, a, b)
        if dist <= 45 and (best is None or dist < best[0]):
            best = dist, str(label.get('text', ''))[:50]
    return {'text': best[1], 'distance_pdf_pt': round(best[0], 2)} if best else None


def extract_trace_network(page, region, section_labels=None, drawings=None,
                          max_lines=MAX_LINE_ITEMS, settings=None, automatic=False):
    """Group colored LINEs irrespective of orientation; no verified quantities.

    First merge almost collinear strokes, then seek elongated parallel outlines
    and group nearby candidate centers for visual review only.
    """
    box = [float(x) for x in region]
    pr = [float(x) for x in page.rect]
    if len(box) != 4 or any(not math.isfinite(x) for x in box) or not (
        pr[0] <= box[0] < box[2] <= pr[2] and
        pr[1] <= box[1] < box[3] <= pr[3]
    ):
        raise ValueError('Invalid PDF region')
    if not isinstance(max_lines, int) or not 1 <= max_lines <= MAX_LINE_ITEMS:
        raise ValueError('Invalid stroke budget')
    if drawings is None:
        drawings = page.get_cdrawings() if hasattr(page, 'get_cdrawings') else page.get_drawings()
    thresholds = {
        'rect_min_pt': MIN_PAIR_GAP_PT, 'rect_max_pt': MAX_PAIR_GAP_PT,
        'coaxial_tol_pt': LATERAL_TOL_PT, 'join_gap_pt': MAX_JOIN_GAP_PT,
    }
    for name in thresholds.keys() & (settings or {}).keys():
        value = settings[name]
        if automatic:
            if name == 'rect_min_pt':
                value = min(value, thresholds[name])
            else:
                value = round(thresholds[name] + max(0., value - DEFAULTS[name]), 4)
        thresholds[name] = value
    strokes, bins = 0, collections.defaultdict(list)
    limited = False
    for position, entry in enumerate(drawings):
        if isinstance(entry, tuple) and len(entry) == 2 and isinstance(entry[0], int):
            path_id, path = entry
        else:
            path_id, path = position, entry
        color, saturated = _color(path.get('color'))
        if not saturated:
            continue
        width = round(float(path.get('width') or 0), 2)
        for index, item in enumerate(path.get('items') or []):
            if not item or item[0] != 'l' or len(item) < 3:
                continue
            a, b = _point(item[1]), _point(item[2])
            if a is None or b is None or not all(math.isfinite(x) for x in a+b):
                continue
            clipped = _clip_line(a, b, box)
            if clipped is None:
                continue
            a, b = clipped
            if math.dist(a,b) < MIN_STROKE_PT:
                continue
            if strokes >= max_lines:
                limited = True
                break
            strokes += 1
            angle = math.degrees(math.atan2(b[1]-a[1],b[0]-a[0])) % 180
            if angle > 179.5:
                angle -= 180
            direction = round(angle / ANGLE_STEP_DEG)
            theta = math.radians(direction * ANGLE_STEP_DEG)
            ux, uy = math.cos(theta), math.sin(theta)
            rho = -uy*(a[0]+b[0])/2 + ux*(a[1]+b[1])/2
            t0, t1 = ux*a[0]+uy*a[1], ux*b[0]+uy*b[1]
            lo, hi = sorted((t0,t1))
            bins[(color,direction,width)].append((
                rho, lo, hi, 'pdf_path_%d_line_%d' % (path_id,index)
            ))
        if limited:
            break

    families = []
    for (color,direction,width),entries in bins.items():
        entries.sort(key=lambda z:(z[0],z[1]))
        rows = []
        for item in entries:
            if not rows or abs(item[0]-rows[-1][0]) > thresholds['coaxial_tol_pt']:
                rows.append([item[0],[item]])
            else:
                rows[-1][1].append(item)
        for rho,parts in rows:
            parts.sort(key=lambda p:p[1])
            current = None
            for position,lo,hi,identity in parts:
                if current is None or lo > current['hi']+thresholds['join_gap_pt']:
                    if current is not None:
                        families.append(current)
                    current = {
                        'rho':rho,'lo':lo,'hi':hi,'color':color,'angle':direction,
                        'width':width,'source':[identity],'count':1
                    }
                else:
                    current['hi'] = max(current['hi'],hi)
                    current['count'] += 1
                    if len(current['source']) < MAX_SOURCE_IDS and identity not in current['source']:
                        current['source'].append(identity)
            if current is not None:
                families.append(current)

    buckets = collections.defaultdict(list)
    for family in families:
        if family['hi']-family['lo'] >= MIN_OVERLAP_PT:
            buckets[(family['color'],family['angle'],family['width'])].append(family)
    possibilities = []
    for (color,angle,width),arr in buckets.items():
        arr.sort(key=lambda x:x['rho'])
        for i,a in enumerate(arr):
            for j in range(i+1,len(arr)):
                b=arr[j]
                gap=b['rho']-a['rho']
                if gap > thresholds['rect_max_pt']:
                    break
                if gap < thresholds['rect_min_pt']:
                    continue
                lo,hi=max(a['lo'],b['lo']),min(a['hi'],b['hi'])
                overlap=hi-lo
                if overlap < max(MIN_OVERLAP_PT,2.4*gap):
                    continue
                if overlap/max(a['hi']-a['lo'],b['hi']-b['lo']) < .38:
                    continue
                score=overlap+min(80,(overlap/gap)*3)
                possibilities.append((score,color,angle,width,a,b,lo,hi,gap))
    possibilities.sort(key=lambda x:-x[0])
    picked, occupied = [], set()
    for score,color,angle,width,a,b,lo,hi,gap in possibilities:
        if id(a) in occupied or id(b) in occupied:
            continue
        occupied.update((id(a),id(b)))
        th=math.radians(angle*ANGLE_STEP_DEG)
        ux,uy=math.cos(th),math.sin(th)
        rho=(a['rho']+b['rho'])/2
        start=(ux*lo-uy*rho,uy*lo+ux*rho)
        end=(ux*hi-uy*rho,uy*hi+ux*rho)
        sources=list(dict.fromkeys(a['source']+b['source']))[:MAX_SOURCE_IDS]
        orientation = ('inclined' if abs(math.sin(th))>.02 and
                       abs(math.cos(th))>.02 else
                       ('vertical' if abs(math.cos(th))<=.02 else 'horizontal'))
        picked.append({
            'status':'unverified_trace_candidate',
            'kind':'parallel_colored_strokes', 'orientation':orientation,
            'angle_deg':round(angle*ANGLE_STEP_DEG,2), 'stroke_color':color,
            'center_start_pdf_pt':_pt(start), 'center_end_pdf_pt':_pt(end),
            'center_start_page_norm':_on_page(start,pr),
            'center_end_page_norm':_on_page(end,pr),
            'projected_length_pt':round(hi-lo,3),
            'width_between_strokes_pt':round(gap,3),
            'source_line_ids':sources,'source_line_count':a['count']+b['count'],
            'dimension_text_nearby':_nearest_label(start,end,section_labels),
            'physical_length_m':None,'scale_verified':False,
            'system_verified':False,'section_verified':False,
            'manual_review_required':True,'confidence':'low',
            '_points':(start,end),
        })
        if len(picked) >= MAX_CANDIDATES:
            break

    # Touching the same colored path is only a spatial hint, not proof of a
    # junction, fitting, shared height, or common ventilation system.
    parent=list(range(len(picked)))
    def root(i):
        while parent[i]!=i:
            parent[i]=parent[parent[i]]
            i=parent[i]
        return i
    for i,a in enumerate(picked):
        for j in range(i+1,len(picked)):
            b=picked[j]
            if a['stroke_color']!=b['stroke_color']:
                continue
            a0,a1=a['_points']
            b0,b1=b['_points']
            if min(
                _distance_to_segment(p,b0,b1) for p in (a0,a1)
            ) <= CONNECT_PT or min(
                _distance_to_segment(p,a0,a1) for p in (b0,b1)
            ) <= CONNECT_PT:
                parent[root(i)]=root(j)
    groups=collections.defaultdict(list)
    for i in range(len(picked)):
        groups[root(i)].append(i)
    groups_sorted=sorted(groups.values(),
                         key=lambda g:-sum(picked[i]['projected_length_pt'] for i in g))
    summaries=[]
    for n,ids in enumerate(groups_sorted,1):
        gid='G%03d'%n
        xs=[p[0] for i in ids for p in picked[i]['_points']]
        ys=[p[1] for i in ids for p in picked[i]['_points']]
        summaries.append({
            'group_id':gid,'stroke_color':picked[ids[0]]['stroke_color'],
            'candidate_count':len(ids),
            'bounds_pdf_pt':_pt((min(xs),min(ys)))+_pt((max(xs),max(ys))),
            'status':'spatial_hint_unverified',
        })
        for i in ids:
            picked[i]['spatial_group_id']=gid
    for i,item in enumerate(picked,1):
        item.pop('_points')
        item['candidate_id']='T%03d'%i
    return {
        'status':'unverified_colored_trace_candidates',
        'parameters': thresholds,
        'scanning':{
            'colored_line_strokes_scanned':strokes,
            'trace_scan_truncated':limited,
            'collinear_families':len(families),
            'parallel_pair_proposals':len(possibilities),
            'trace_candidates_returned':len(picked),
            'spatial_groups_returned':len(summaries),
        },
        'candidates':picked,
        'spatial_groups':summaries,
        'limitations':[
            'Parallel colored strokes are not verified duct centerlines',
            'Spatial groups are proximity hints, not proven ventilation networks',
            'Widths and projected lengths are PDF points, never physical lengths',
            'Color does not identify a system without manual review',
            'Unpaired and curved strokes are omitted; sampling may be incomplete',
        ],
    }
