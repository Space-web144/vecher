"""Safe per-album geometry profile. User settings are hypotheses, not measurements."""
from __future__ import annotations
import math

SCHEMA = "clean-papper.profile.v1"
DEFAULTS = {
    "rect_min_pt": 5.0,
    "rect_max_pt": 32.0,
    "coaxial_tol_pt": 0.06,
    "join_gap_pt": 0.05,
    "dash_gap_min_pt": 1.2,
    "dash_gap_max_pt": 6.5,
    "dash_median_min_pt": 3.6,
}
BOUNDS = {
    "rect_min_pt": (0.5, 60.0),
    "rect_max_pt": (2.0, 150.0),
    "coaxial_tol_pt": (0.01, 0.5),
    "join_gap_pt": (0.01, 1.5),
    "dash_gap_min_pt": (0.2, 15.0),
    "dash_gap_max_pt": (0.5, 30.0),
    "dash_median_min_pt": (0.2, 20.0),
}
KINDS = ("plan", "axonometry", "fragment", "section", "unknown")
SCALES = ("unknown", "1:50", "1:100", "1:200", "custom")


def normalized_profile(data):
    if data is None:
        return {
            "schema": SCHEMA, "album": {"name": "", "size_bytes": 0},
            "region_kind": "unknown", "nominal_scale": "unknown",
            "geometry": dict(DEFAULTS), "review_status": "unverified_defaults"
        }
    if not isinstance(data, dict) or data.get("schema") != SCHEMA:
        raise ValueError("Invalid Clean Papper profile schema")
    album = data.get("album", {})
    if not isinstance(album, dict):
        raise ValueError("Invalid album identity")
    name = album.get("name", "")
    size = album.get("size_bytes", 0)
    if not isinstance(name, str) or len(name) > 200 or "\x00" in name:
        raise ValueError("Invalid album title")
    if isinstance(size, bool) or not isinstance(size, int) or not 0 <= size <= 62914560:
        raise ValueError("Invalid album size")
    region = data.get("region_kind", "unknown")
    scale = data.get("nominal_scale", "unknown")
    if region not in KINDS or scale not in SCALES:
        raise ValueError("Unsupported page region or scale")
    user_geometry = data.get("geometry", {})
    if not isinstance(user_geometry, dict) or len(user_geometry) > len(DEFAULTS):
        raise ValueError("Unsupported geometry profile")
    if any(key not in DEFAULTS for key in user_geometry):
        raise ValueError("Unknown geometry profile field")
    geom = dict(DEFAULTS)
    for key, value in user_geometry.items():
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            raise ValueError("Invalid geometry threshold")
        v = float(value)
        lo, hi = BOUNDS[key]
        if not math.isfinite(v) or v < lo or v > hi:
            raise ValueError("Geometry threshold outside safe range")
        geom[key] = round(v, 4)
    if not (geom["rect_min_pt"] < geom["rect_max_pt"] and
            geom["dash_gap_min_pt"] < geom["dash_gap_max_pt"] and
            geom["dash_gap_min_pt"] <= geom["dash_median_min_pt"] <= geom["dash_gap_max_pt"]):
        raise ValueError("Inconsistent PDF geometry thresholds")
    return {
        "schema": SCHEMA, "album": {"name": name, "size_bytes": size},
        "region_kind": region, "nominal_scale": scale,
        "geometry": geom, "review_status": "manual_unverified"
    }
