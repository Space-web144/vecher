# -*- coding: utf-8 -*-
"""
Нормализация пробелов в уже накопленной номенклатуре — и в DB_FILE
(боевая база сравнения, xlsx, колонка B = наименование), и в
ONEC_NOMENCLATURE_FILE (эталонный снимок для проверки дублей, JSON).
Разовый проход по уже имеющимся данным — заказчик попросил "привести
файл номенклатуры к нормальному виду": между словами максимум один
пробел, без пробелов по краям. Для НОВЫХ позиций то же самое теперь
делается автоматически при записи (common.nomenclature_intake.
_append_to_bases), см. common/parameters.py::clean_whitespace — тот же
самый помощник, не отдельная копия правила.

Без --apply — только отчёт (сколько позиций в каждом файле затронет,
примеры "было/стало"), НИЧЕГО не меняет на диске. С --apply — перед
перезаписью делает резервную копию каждого файла (с меткой времени в
имени, рядом с оригиналом) и правит на месте — это запись в боевую базу
сравнения VentSpec, резервная копия обязательна, не опциональна.

Пример вызова:
  python3 web_db_whitespace_cleanup.py --db /path/1c_base.xlsx \\
      --existing /path/1c_full_nomenclature.json --out /path/report.json
  python3 web_db_whitespace_cleanup.py --db ... --existing ... --out ... --apply
"""
import os

# Обязательно ДО любого импорта common/openpyxl — см. common/
# web_db_file_dump.py за той же историей (RLIMIT_NPROC на хостинге).
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import sys
import json
import shutil
import datetime
import argparse

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from openpyxl import load_workbook  # noqa: E402
from common.parameters import clean_whitespace  # noqa: E402

MAX_EXAMPLES = 30


def _backup(path):
    stamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
    backup_path = f"{path}.bak-{stamp}"
    shutil.copy2(path, backup_path)
    return backup_path


def _clean_db_file(path, apply_changes):
    """DB_FILE: колонка A = Код, колонка B = Наименование, строка 1 —
    заголовок (та же раскладка, что пишет _append_to_bases и читает
    program-a/vent_processor.py::_load_names_from_file)."""
    if not path or not os.path.isfile(path):
        return None
    wb = load_workbook(path)
    ws = wb.active
    total = 0
    changed = 0
    examples = []
    first = True
    for row_cells in ws.iter_rows(min_row=1):
        if first:
            first = False
            continue
        if len(row_cells) < 2:
            continue
        name_cell = row_cells[1]
        original = name_cell.value
        if not original:
            continue
        total += 1
        original_str = str(original)
        cleaned = clean_whitespace(original_str)
        if cleaned != original_str:
            changed += 1
            if len(examples) < MAX_EXAMPLES:
                code_cell = row_cells[0]
                examples.append({
                    "Код": str(code_cell.value) if code_cell.value else "",
                    "было": original_str,
                    "стало": cleaned,
                })
            if apply_changes:
                name_cell.value = cleaned

    backup_path = None
    if apply_changes and changed:
        backup_path = _backup(path)
        # Через временный файл + os.replace — DB_FILE читают параллельно
        # (сравнение спецификаций, дамп для "База", проверка дублей),
        # wb.save() поверх существующего файла не атомарен сам по себе
        # ("File is not a zip file" у конкурентного читателя во время
        # записи — та же история, что в common.nomenclature_intake.
        # _append_to_bases).
        tmp_path = path + ".tmp"
        wb.save(tmp_path)
        os.replace(tmp_path, path)
    return {"total": total, "changed": changed, "examples": examples, "backup": backup_path}


def _clean_existing_file(path, name_key, code_key, apply_changes):
    """ONEC_NOMENCLATURE_FILE: JSON-список словарей, тот же формат полей
    1С, что принимает web/1c_intake.php."""
    if not path or not os.path.isfile(path):
        return None
    with open(path, encoding="utf-8") as f:
        items = json.load(f)
    if not isinstance(items, list):
        return None

    total = 0
    changed = 0
    examples = []
    for it in items:
        if not isinstance(it, dict):
            continue
        original = it.get(name_key)
        if not original:
            continue
        total += 1
        original_str = str(original)
        cleaned = clean_whitespace(original_str)
        if cleaned != original_str:
            changed += 1
            if len(examples) < MAX_EXAMPLES:
                examples.append({
                    "Код": str(it.get(code_key, "")),
                    "было": original_str,
                    "стало": cleaned,
                })
            if apply_changes:
                it[name_key] = cleaned

    backup_path = None
    if apply_changes and changed:
        backup_path = _backup(path)
        tmp_path = path + ".tmp"
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(items, f, ensure_ascii=False, indent=2)
        os.replace(tmp_path, path)
    return {"total": total, "changed": changed, "examples": examples, "backup": backup_path}


def main():
    parser = argparse.ArgumentParser(description="Нормализация пробелов в накопленной номенклатуре 1С")
    parser.add_argument("--db", default=None, help="путь к DB_FILE (.xlsx)")
    parser.add_argument("--existing", default=None, help="путь к ONEC_NOMENCLATURE_FILE (.json)")
    parser.add_argument("--name-key", default="Наименование")
    parser.add_argument("--code-key", default="Код")
    parser.add_argument("--apply", action="store_true",
                         help="реально переписать файлы (с резервной копией); без флага — только отчёт")
    args = parser.parse_args()

    try:
        db_result = _clean_db_file(args.db, args.apply)
        existing_result = _clean_existing_file(args.existing, args.name_key, args.code_key, args.apply)
        print(json.dumps({
            "ok": True,
            "applied": args.apply,
            "db_file": db_result,
            "existing_file": existing_result,
        }, ensure_ascii=False))
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False))
        sys.exit(1)


if __name__ == "__main__":
    main()
