"""Deterministic 1C routing. Generic fittings/fasteners never default to VentSpec."""
import json
from pathlib import Path
import re
import unicodedata

CATALOGS = {'ventilation': 'Вентиляция', 'vk': 'ВК'}
RULES = json.loads((Path(__file__).parent / 'config/nomenclature_routing.json').read_text(encoding='utf-8'))
VK_RULES = [(r['id'], r['label'], [re.compile(p) for p in r['all']]) for r in RULES['vk_rules']]
VENT = re.compile(RULES['strong_vent_pattern'])
EXCLUSIONS = [re.compile(RULES[k]) for k in ('other_pattern', 'sensor_accessory_pattern')]
SHARED = re.compile(RULES['shared_pattern'])
# Only explicit department metadata, not arbitrary text from kinds/brands/groups.
DIRECTION_FIELDS = ('Направление', 'РазделНоменклатуры', 'Раздел')
DIRECTIONS = {'вк': 'vk', 'vk': 'vk', 'wasserspec': 'vk',
              'водоснабжение и канализация': 'vk', 'вентиляция': 'ventilation',
              'ventilation': 'ventilation', 'ventspec': 'ventilation'}


def normalize_name(value):
    return re.sub(r'\s+', ' ', unicodedata.normalize('NFKC', str(value or '')).casefold()
                  .replace('ё', 'е').replace('–', '-').replace('—', '-')).strip()


def code_of(item, code_key='Код'):
    value = item.get(code_key)
    return str(value).strip() if value is not None else ''


def decision(catalog, method, reason, evidence=()):
    return {'catalog': catalog, 'method': method, 'reason': reason, 'evidence': list(evidence),
            'rules_version': RULES['version']}


def route_item(item, memberships=None, assignments=None, name_key='Наименование', code_key='Код'):
    code = code_of(item, code_key)
    known = (memberships or {}).get(code, set())
    explicit = {DIRECTIONS[normalize_name(item[k])] for k in DIRECTION_FIELDS
                if isinstance(item.get(k), str) and normalize_name(item[k]) in DIRECTIONS}
    saved = (assignments or {}).get(code)
    if len(explicit) > 1:
        return decision(None, 'metadata_conflict', 'Поля направления 1С указывают разные разделы')
    if saved in CATALOGS:
        if explicit and saved not in explicit:
            return decision(None, 'assignment_conflict', 'Направление 1С противоречит ручному выбору раздела')
        return decision(saved, 'manual_code', 'Раздел ранее выбран администратором для этого кода')
    if len(known) == 1:
        catalog = next(iter(known))
        if explicit and catalog not in explicit:
            return decision(None, 'code_conflict', 'Направление 1С противоречит разделу существующего кода')
        return decision(catalog, 'existing_code', 'Код уже есть в этом разделе; автоматический перенос запрещён')
    if len(known) > 1:
        if explicit:
            return decision(next(iter(explicit)), 'explicit', 'Код есть в двух разделах; выбрано явное направление 1С')
        return decision(None, 'shared_code', 'Код есть в обоих разделах — выберите, какую карточку обновить')
    if explicit:
        return decision(next(iter(explicit)), 'explicit', 'Явное направление в реквизитах 1С')
    name = normalize_name(item.get(name_key))
    vk = [(ident, label) for ident, label, patterns in VK_RULES if all(p.search(name) for p in patterns)]
    vent = bool(VENT.search(name))
    evidence = [ident for ident, _ in vk] + (['ventilation-purpose'] if vent else [])
    if any(p.search(name) for p in EXCLUSIONS):
        return decision(None, 'other', 'Изделие другого назначения или общий аксессуар', evidence)
    if vk and vent:
        return decision(None, 'keywords_conflict', 'Найдены признаки ВК и вентиляции', evidence)
    if vk:
        return decision('vk', 'keywords', '; '.join(label for _, label in vk), evidence)
    if vent:
        return decision('ventilation', 'keywords', 'Явное вентиляционное назначение', evidence)
    return decision(None, 'shared' if SHARED.search(name) else 'unknown',
                    'Недостаточно признаков для выбора раздела', evidence)
