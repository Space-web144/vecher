# -*- coding: utf-8 -*-
"""
Слияние номенклатур: добавляет позиции из внешнего списка наименований
(например, собственной выгрузки 1С) в основную базу (формат
nomenclature_alfastroy.json — id/code/name/search_text/system/systems/unit),
не дублируя уже существующие по имени.

Совпадением считается точное имя после нормализации пробелов (без учёта
регистра формулировки и т.п. — это НЕ fuzzy-слияние, только защита от
явных дублей: та же строка, что уже есть в базе, не добавляется второй раз).
Для новых позиций система определяется через common.query_classifier
(тот же классификатор, что использует Tier 2) — эвристика, не 100% точная,
особенно для позиций без явных ключевых слов (уходят в "default").

Использование:
    from common.merge_nomenclature import merge_nomenclature, load_names_from_column

    base = json.load(open("nomenclature_alfastroy.json", encoding="utf-8"))
    new_names = load_names_from_column("выгрузка.xlsx", name_col_index=1)  # 0-based
    merged, stats = merge_nomenclature(base, new_names, code_prefix="VS")
"""

import re

from common.query_classifier import classify_query

_WS_RE = re.compile(r"\s+")


def _norm_key(name):
    return _WS_RE.sub(" ", name.strip()) if name else ""


def load_names_from_column(xlsx_path, name_col_index=1, header_rows=1):
    """Читает наименования из колонки Excel-файла (0-based индекс колонки)."""
    from openpyxl import load_workbook
    wb = load_workbook(xlsx_path, read_only=True)
    ws = wb.active
    names = []
    for i, row in enumerate(ws.iter_rows(values_only=True)):
        if i < header_rows:
            continue
        if len(row) > name_col_index and row[name_col_index]:
            names.append(str(row[name_col_index]).strip())
    wb.close()
    return names


def merge_nomenclature(base_items, new_names, code_prefix="VS", code_digits=8, default_unit=""):
    """
    Возвращает (merged_items, stats). merged_items — base_items + новые
    записи для имён из new_names, которых в base_items ещё нет (по точному
    совпадению после нормализации пробелов). Порядок и содержимое
    существующих записей base_items не меняются.
    """
    existing_keys = {_norm_key(it["name"]) for it in base_items if it.get("name")}
    max_id = max((it.get("id", 0) for it in base_items), default=0)

    merged = list(base_items)
    added = []
    seen_in_batch = set()
    next_id = max_id + 1
    next_code_num = 1

    for name in new_names:
        key = _norm_key(name)
        if not key or key in existing_keys or key in seen_in_batch:
            continue
        seen_in_batch.add(key)

        system, _confidence = classify_query(name)
        code = f"{code_prefix}-{next_code_num:0{code_digits}d}"
        next_code_num += 1

        item = {
            "id": next_id,
            "code": code,
            "name": name,
            "search_text": name,
            "system": system,
            "systems": system,
            "unit": default_unit,
        }
        merged.append(item)
        added.append(item)
        next_id += 1

    stats = {
        "base_count": len(base_items),
        "input_count": len(new_names),
        "added_count": len(added),
        "skipped_count": len(new_names) - len(added),
        "final_count": len(merged),
    }
    return merged, stats


def write_ventspec_excel(items, output_path, name_key="name"):
    """Пишет Excel в формате, который понимает VentSpec (загрузка номенклатуры
    1С): строка 1 — заголовок (пропускается), наименование — в колонке B."""
    from openpyxl import Workbook
    wb = Workbook()
    ws = wb.active
    ws["A1"] = "Код"
    ws["B1"] = "Наименование"
    for i, it in enumerate(items, start=2):
        ws.cell(row=i, column=1, value=it.get("code"))
        ws.cell(row=i, column=2, value=it.get(name_key))
    wb.save(output_path)
