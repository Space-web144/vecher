#!/usr/bin/env python3
"""Clean Papper: bounded, read-only Anthropic connectivity probe.

Only reads server-owned credentials; does not upload documents or print secrets.
An explicit --check call performs exactly one small Messages API request.
"""
from __future__ import annotations

import argparse
import json
import re
import sys
import time
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from common.anthropic_client import (  # noqa: E402
    AnthropicClient, AnthropicConfigError, AnthropicConnectionError,
    AnthropicError, load_credentials,
)

MODEL_PATTERN = re.compile(r"^[a-zA-Z0-9][a-zA-Z0-9._:-]{1,100}$")
MAX_TEST_TOKENS = 128
PROMPT = "Это проверка API Clean Papper. Ответь только словом OK."


def selected_model(credentials_file: str, creds: dict) -> str:
    # model_clean_papper is a dedicated *optional* field in the existing,
    # server-private JSON. Do not modify other modules' models.
    with open(credentials_file, "r", encoding="utf-8") as fh:
        config = json.load(fh)
    name = (config.get("model_clean_papper") or creds.get("model_chat")
            or creds.get("model") or "claude-sonnet-5")
    if not isinstance(name, str) or not MODEL_PATTERN.fullmatch(name):
        raise AnthropicConfigError("Invalid Clean Papper model configuration")
    return name


def probe(credentials_file: str, action: str, client_factory=AnthropicClient) -> dict:
    if action not in ("status", "ping"):
        raise ValueError("Unsupported action")
    creds = load_credentials(credentials_file)
    model = selected_model(credentials_file, creds)
    if action == "status":
        return {"ok": True, "configured": True, "provider": "Anthropic",
                "model": model, "live_verified": False,
                "message": "Настройки ключа прочитаны. Связь с API ещё не проверена."}

    started = time.monotonic()
    client = client_factory(
        credentials_file=credentials_file,
        model=model,
        effort="low",
        max_tokens=MAX_TEST_TOKENS,
        timeout=18,
        max_retries=1,
        max_requests=1,
        fallbacks=False,
        log=None,
    )
    result = client.messages(
        [{"role": "user", "content": PROMPT}],
        system="Ты тестируешь соединение приложения с Anthropic. Не выполняй никаких других задач.",
        model=model,
        max_tokens=MAX_TEST_TOKENS,
        effort="low",
    )
    if not isinstance(result, dict) or result.get("type") != "message":
        raise AnthropicError("Unexpected API response type")
    tokens = result.get("usage") or {}
    served = result.get("model") or model
    if not isinstance(served, str) or not MODEL_PATTERN.fullmatch(served):
        served = model
    return {"ok": True, "configured": True, "provider": "Anthropic",
            "model": served, "live_verified": True,
            "input_tokens": max(0, int(tokens.get("input_tokens") or 0)),
            "output_tokens": max(0, int(tokens.get("output_tokens") or 0)),
            "duration_ms": max(0, round((time.monotonic() - started) * 1000)),
            "message": "Claude API ответил. Соединение подтверждено."}


def safe_error(exc: Exception) -> dict:
    # Errors coming from the provider or a proxy may contain sensitive URLs.
    # NEVER send repr(exc) or credentials to the website or server logs.
    if isinstance(exc, AnthropicConfigError):
        code = "configuration"
        msg = "Не удалось прочитать корректные серверные настройки Anthropic."
    elif isinstance(exc, AnthropicConnectionError):
        code = "connection"
        msg = "Не удалось связаться с Claude API через сервер."
    elif isinstance(exc, AnthropicError):
        code = "api"
        status = getattr(exc, "status", None)
        if status == 401:
            msg = "Claude API отклонил ключ (401). Проверьте ключ в серверной консоли."
        elif status == 402:
            msg = "Claude API сообщает о проблеме с балансом или оплатой (402)."
        elif status == 403:
            msg = "Claude API запретил доступ к модели или ключу (403)."
        elif status == 400:
            msg = "Claude API отклонил параметры запроса (400). Проверьте совместимость выбранной модели и режима вывода."
        elif status == 404:
            msg = "Claude API не нашёл выбранную модель или endpoint (404). Проверьте model_clean_papper."
        elif status == 413:
            msg = "Claude API отклонил слишком большой запрос (413)."
        elif status in (500,502,503,504,529):
            msg = f"Claude API временно недоступен (HTTP {status})."
        elif status == 429:
            msg = "Claude API ограничил частоту запросов (429)."
        else:
            msg = "Claude API отклонил тест. Проверьте доступность модели и настройки."
    else:
        code = "internal"
        msg = "Не удалось выполнить тест API на сервере."
    return {"ok": False, "live_verified": False, "code": code, "message": msg}


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Clean Papper API probe")
    parser.add_argument("--credentials", required=True, help="Private server config path, never key text")
    parser.add_argument("--action", required=True, choices=("status", "ping"))
    args = parser.parse_args(argv)
    try:
        response = probe(args.credentials, args.action)
    except (AnthropicError, ValueError, TypeError, OSError, KeyError) as exc:
        response = safe_error(exc)
    except Exception as exc:
        response = safe_error(exc)
    print(json.dumps(response, ensure_ascii=False, separators=(",", ":")))
    return 0 if response["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
