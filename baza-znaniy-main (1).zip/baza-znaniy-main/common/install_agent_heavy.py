#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Установка отдельной службы Альфика на Ubuntu VPS. Запускает администратор."""
import os
import shutil
import subprocess
import tempfile
from pathlib import Path

WORKSPACE = Path("/var/lib/alfik-worker")
IMAGE = WORKSPACE.with_suffix(".img")
LIMIT = 15 * 1024 ** 3
LIB = Path("/usr/local/lib/alfik-worker")
SYSTEMD = Path("/etc/systemd/system")
SERVICE = "alfik-worker.service"
IMAGE_TAG = "alfik-heavy:1"

DOCKERFILE = """\
FROM python:3.12-slim
RUN python -m pip install --no-cache-dir numpy pandas pyarrow openpyxl xlsxwriter xlrd \\
    pymupdf pypdf python-docx python-pptx pillow matplotlib reportlab
"""

MOUNT_UNIT = """\
[Unit]
Description=Alfik job workspace

[Mount]
What=/var/lib/alfik-worker.img
Where=/var/lib/alfik-worker
Type=ext4
Options=loop,nosuid,nodev,noexec

[Install]
WantedBy=local-fs.target
"""

SERVICE_UNIT = """\
[Unit]
Description=Alfik heavy jobs worker
Requires=docker.service
After=docker.service
RequiresMountsFor=/var/lib/alfik-worker

[Service]
Type=simple
User=root
Group=www-data
UMask=0022
RuntimeDirectory=alfik-worker
RuntimeDirectoryMode=0750
ExecStart=/usr/bin/python3 /usr/local/lib/alfik-worker/agent_heavy_worker.py
ExecStopPost=/usr/bin/python3 /usr/local/lib/alfik-worker/agent_heavy_worker.py --cleanup
Restart=on-failure
RestartSec=5
TimeoutStopSec=60
NoNewPrivileges=yes
PrivateTmp=yes
ProtectHome=yes
ProtectSystem=strict
ReadWritePaths=/var/lib/alfik-worker /run/alfik-worker

[Install]
WantedBy=multi-user.target
"""

RESOURCE_CHECK = """\
from pathlib import Path
import openpyxl
import pymupdf

root = Path("/sys/fs/cgroup")
memory = (root / "memory.max").read_text().strip()
quota, period = (root / "cpu.max").read_text().split()
if not memory.isdigit() or int(memory) > 6 * 1024 ** 3:
    raise SystemExit("Docker не применил лимит памяти 6 ГиБ.")
if not quota.isdigit() or int(quota) > 2 * int(period):
    raise SystemExit("Docker не применил лимит 2 CPU.")
"""


def run(*args, **kwargs):
    return subprocess.run(args, check=True, **kwargs)


def write_private(path, data, mode):
    fd, name = tempfile.mkstemp(dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as handle:
            handle.write(data)
        os.chmod(name, mode)
        os.replace(name, path)
    finally:
        Path(name).unlink(missing_ok=True)


def prepare_disk():
    if IMAGE.is_symlink() or WORKSPACE.is_symlink():
        raise SystemExit("Пути рабочего диска не должны быть ссылками.")
    WORKSPACE.mkdir(mode=0o755, exist_ok=True)
    if IMAGE.exists():
        if not IMAGE.is_file() or IMAGE.stat().st_size != LIMIT:
            raise SystemExit("Существующий образ диска имеет неожиданный размер.")
        return
    if any(WORKSPACE.iterdir()):
        raise SystemExit("Каталог будущей точки монтирования уже содержит файлы.")
    fd, temporary = tempfile.mkstemp(prefix=".alfik-worker-", dir=IMAGE.parent)
    os.close(fd)
    try:
        run("fallocate", "-l", str(LIMIT), temporary)
        run("mkfs.ext4", "-F", "-m", "0", "-E", "nodiscard", temporary)
        os.replace(temporary, IMAGE)
    finally:
        Path(temporary).unlink(missing_ok=True)


def main():
    if os.geteuid() != 0:
        raise SystemExit("Запустите установщик от администратора через sudo.")
    if not Path("/usr/bin/docker").is_file():
        raise SystemExit("Установите пакет docker.io и повторите запуск.")
    sources = Path(__file__).resolve().parent
    for name in ("agent_heavy.py", "agent_heavy_worker.py"):
        if not (sources / name).is_file():
            raise SystemExit("Рядом с установщиком отсутствует " + name)
    run("systemctl", "start", "docker.service")
    with tempfile.TemporaryDirectory(prefix="alfik-image-") as build_dir:
        Path(build_dir, "Dockerfile").write_text(DOCKERFILE, encoding="utf-8")
        run("/usr/bin/docker", "build", "-t", IMAGE_TAG, build_dir)
    run("/usr/bin/docker", "run", "--rm", "--network", "none", "--read-only",
        "--memory", "6g", "--memory-swap", "6g", "--cpus", "2", IMAGE_TAG,
        "python", "-I", "-B", "-c", RESOURCE_CHECK)
    prepare_disk()

    LIB.mkdir(mode=0o755, parents=True, exist_ok=True)
    for name in ("agent_heavy.py", "agent_heavy_worker.py"):
        write_private(LIB / name, (sources / name).read_bytes(), 0o644)
    mount_name = run("systemd-escape", "--path", "--suffix=mount", str(WORKSPACE),
                     capture_output=True, text=True).stdout.strip()
    write_private(SYSTEMD / mount_name, MOUNT_UNIT.encode(), 0o644)
    write_private(SYSTEMD / SERVICE, SERVICE_UNIT.encode(), 0o644)
    run("systemctl", "daemon-reload")
    run("systemctl", "enable", "--now", mount_name)
    run("systemctl", "enable", SERVICE)
    run("systemctl", "restart", SERVICE)
    run("systemctl", "is-active", SERVICE)
    print("Служба Альфика установлена. Проверьте режим «Обработать файлы на VPS» в чате.")


if __name__ == "__main__":
    main()
