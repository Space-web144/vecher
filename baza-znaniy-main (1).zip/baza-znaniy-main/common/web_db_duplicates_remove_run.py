# -*- coding: utf-8 -*-
"""
Удаление выбранных администратором дублей номенклатуры из боевой базы
(DB_FILE) и, если передан, из снимка для проверки дублей при приёме от 1С
(ONEC_NOMENCLATURE_FILE) — держатся в синхроне по "Код", как и везде в
проекте (см. common.nomenclature_intake._append_to_bases). Вызывается
web/onec_db_duplicates_remove.php после подтверждения на web/
onec_db_duplicates.php (common.matcher.find_text_duplicate_groups).

Список кодов на удаление передаётся файлом (--codes-file), не аргументами
командной строки — то же соображение, что и у web_1c_review_bulk_run.py
(может быть много кодов, argv виден в `ps aux` и ограничен по длине).
Формат файла: ["код1", "код2", ...].

ВАЖНО — перед удалением скрипт САМ заново строит группы дублей
(common.matcher.find_text_duplicate_groups — лёгкая, НЕ через
NomenclatureIndex, см. её докстринг: полная сборка индекса здесь не
нужна и на крупной базе стоила бы секунды впустую на каждый запрос) по
текущему DB_FILE и принимает только коды, которые:
  1) реально входят в какую-то НАЙДЕННУЮ СЕЙЧАС группу дублей (страница
     могла быть открыта раньше, чем кто-то ещё изменил базу — не
     удаляем код просто потому, что его прислали в запросе);
  2) не опустошают группу целиком (хотя бы одна позиция группы должна
     остаться — иначе это стирание позиции без замены, не чистка дублей).
Остальные коды возвращаются в "skipped" с причиной, не блокируя удаление
остальных.

Перед записью — резервная копия каждого изменённого файла (как
common/web_db_whitespace_cleanup.py), с меткой времени в имени.

Пример вызова:
  python3 web_db_duplicates_remove_run.py --db /path/1c_base.xlsx \\
      --existing /path/1c_full_nomenclature.json \\
      --codes-file /path/codes.json
"""
import os

# Обязательно ДО любого импорта common/openpyxl — см. common/
# web_db_file_dump.py за той же историей (RLIMIT_NPROC на хостинге).
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import sys
import json
import shutil
import datetime
import argparse

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "program-a"))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from openpyxl import Workbook  # noqa: E402
from common.matcher import find_text_duplicate_groups  # noqa: E402
from common.web_db_file_dump import _load_items_with_codes  # noqa: E402


def _backup(path):
    stamp = datetime.datetime.now().strftime("%Y%m%d%H%M%S")
    backup_path = f"{path}.bak-{stamp}"
    shutil.copy2(path, backup_path)
    return backup_path


def _validate_codes(requested_codes, items):
    """Возвращает (allowed_codes, skipped) — allowed_codes только те,
    что реально входят в текущую группу дублей и не опустошают её
    (см. модульный докстринг)."""
    groups = find_text_duplicate_groups(items, name_key="Наименование")

    code_to_group = {}
    for gi, group in enumerate(groups):
        for it in group:
            code = it.get("Код")
            if code:
                code_to_group.setdefault(code, []).append(gi)

    requested = set(requested_codes)
    allowed = set()
    skipped = []
    for code in requested_codes:
        group_idxs = code_to_group.get(code)
        if not group_idxs:
            skipped.append(f"{code}: сейчас не входит ни в одну группу дублей "
                            "(база могла измениться — обновите страницу)")
            continue
        allowed.add(code)

    # Проверка "не опустошать группу целиком" — после удаления всех
    # allowed-кодов в группе должна остаться хотя бы одна позиция.
    for group in groups:
        group_codes = [it.get("Код") for it in group if it.get("Код")]
        remaining = [c for c in group_codes if c not in allowed]
        if not remaining:
            # Вся группа попала в запрос — откатываем удаление последней
            # (по порядку в группе) позиции, чтобы хоть одна осталась.
            last = group_codes[-1]
            allowed.discard(last)
            skipped.append(f"{last}: не удалена — иначе группа дублей осталась бы совсем без позиций")

    return allowed, skipped


def main():
    parser = argparse.ArgumentParser(description="Удаление дублей номенклатуры из DB_FILE")
    parser.add_argument("--db", required=True, help="путь к DB_FILE (.xlsx)")
    parser.add_argument("--existing", default=None, help="путь к ONEC_NOMENCLATURE_FILE (.json), опционально")
    parser.add_argument("--codes-file", required=True, help='JSON-файл со списком кодов ["код1", "код2", ...]')
    args = parser.parse_args()

    if not os.path.isfile(args.db):
        print(json.dumps({"ok": False, "error": f"Файл не найден: {args.db}"}, ensure_ascii=False))
        sys.exit(1)

    try:
        with open(args.codes_file, encoding="utf-8") as f:
            requested_codes = [str(c) for c in json.load(f)]
        if not requested_codes:
            print(json.dumps({"ok": False, "error": "Не передано ни одного кода на удаление"}, ensure_ascii=False))
            sys.exit(1)

        items = _load_items_with_codes(args.db)
        allowed, skipped = _validate_codes(requested_codes, items)

        db_removed = 0
        if allowed:
            kept_items = [it for it in items if it.get("Код") not in allowed]
            db_removed = len(items) - len(kept_items)
            if db_removed:
                _backup(args.db)
                # Пересобираем файл целиком (новая книга + все оставшиеся
                # строки), а не ws.delete_rows() по одной строке на
                # удаляемый код: delete_rows на каждый вызов сдвигает все
                # нижележащие строки, так что N разбросанных по файлу
                # удалений на базе в десятки тысяч строк — это порядка
                # N×(размер файла) работы, не N. При удалении "по 50 за
                # раз" это ещё терпимо, но при удалении сразу по многим
                # группам неприемлемо медленно (не воспроизвелось как
                # ошибка — просто не укладывалось в разумное время при
                # проверке). Пересборка — один проход, O(размер файла)
                # независимо от того, сколько строк удаляется.
                new_wb = Workbook()
                new_ws = new_wb.active
                new_ws.append(["Код", "Наименование"])
                for it in kept_items:
                    new_ws.append([it.get("Код", ""), it.get("Наименование", "")])
                # Через временный файл + os.replace — DB_FILE читают
                # параллельно (сравнение спецификаций, дамп для "База",
                # сама проверка дублей), прямая запись поверх
                # существующего файла не атомарна (см. common.
                # nomenclature_intake._append_to_bases за тем же фиксом).
                db_tmp_path = args.db + ".tmp"
                new_wb.save(db_tmp_path)
                os.replace(db_tmp_path, args.db)

        existing_removed = 0
        if allowed and args.existing and os.path.isfile(args.existing):
            with open(args.existing, encoding="utf-8") as f:
                existing_items = json.load(f)
            if isinstance(existing_items, list):
                kept = [it for it in existing_items
                        if not (isinstance(it, dict) and it.get("Код") in allowed)]
                existing_removed = len(existing_items) - len(kept)
                if existing_removed:
                    _backup(args.existing)
                    tmp_path = args.existing + ".tmp"
                    with open(tmp_path, "w", encoding="utf-8") as f:
                        json.dump(kept, f, ensure_ascii=False, indent=2)
                    os.replace(tmp_path, args.existing)

        print(json.dumps({
            "ok": True,
            "db_removed": db_removed,
            "existing_removed": existing_removed,
            "skipped": skipped,
        }, ensure_ascii=False))
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False))
        sys.exit(1)


if __name__ == "__main__":
    main()
