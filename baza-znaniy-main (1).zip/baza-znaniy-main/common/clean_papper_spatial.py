"""Full bounding-box inventory, not a duct detector or a geometry takeoff.

Every source path is examined, regardless of drawing order or color. Tile
intersections are deliberately conservative (a path may touch several tiles).
No clipping, joining or quantity approval is performed by this index.
"""
from __future__ import annotations

from bisect import bisect_left, bisect_right
import math

GRID = 8
PATH_BUDGET = 50_000
ITEM_BUDGET = 35_000


def spatial_inventory(paths, region, grid=GRID):
    if type(grid) is not int or not 1 <= grid <= 16:
        raise ValueError('Invalid grid')
    box = tuple(map(float, region))
    if len(box) != 4 or not all(map(math.isfinite, box)) or not (box[0] < box[2] and box[1] < box[3]):
        raise ValueError('Invalid region')
    x0, y0, x1, y1 = box
    xs = [x0 + (x1-x0)*i/grid for i in range(grid+1)]
    ys = [y0 + (y1-y0)*i/grid for i in range(grid+1)]
    xs[-1], ys[-1] = x1, y1
    # Rectangle difference arrays: O(paths + grid^2), including long paths.
    diff = [[[0]*(grid+1) for _ in range(grid+1)] for _ in range(2)]
    owners = [[0]*grid for _ in range(grid)]
    total = inside = outside = unknown = items = 0
    def add(a, l, t, r, b, v):
        a[t][l] += v; a[t][r+1] -= v
        a[b+1][l] -= v; a[b+1][r+1] += v
    for path in paths:
        total += 1
        try:
            a,b,c,d = map(float, path.get('rect'))
            if not all(map(math.isfinite, (a,b,c,d))) or a>c or b>d:
                raise ValueError('Invalid bbox')
        except (ValueError, TypeError, OverflowError):
            unknown += 1
            continue
        if c<x0 or a>x1 or d<y0 or b>y1:
            outside += 1
            continue
        inside += 1
        n = len(path.get('items') or [])
        items += n
        a,b,c,d = max(a,x0),max(b,y0),min(c,x1),min(d,y1)
        l=max(0,bisect_left(xs,a)-1); r=min(grid-1,bisect_right(xs,c)-1)
        t=max(0,bisect_left(ys,b)-1); z=min(grid-1,bisect_right(ys,d)-1)
        add(diff[0],l,t,r,z,1); add(diff[1],l,t,r,z,n)
        col=min(grid-1,bisect_right(xs,(a+c)/2)-1)
        row=min(grid-1,bisect_right(ys,(b+d)/2)-1)
        owners[row][col] += 1
    cells=[]
    for row in range(grid):
        for col in range(grid):
            for arr in diff:
                arr[row][col] += (arr[row-1][col] if row else 0)+(arr[row][col-1] if col else 0)-(arr[row-1][col-1] if row and col else 0)
            count, upper = diff[0][row][col], diff[1][row][col]
            cells.append({'id':f'R{row+1}C{col+1}', 'row':row+1,'column':col+1,
                          'bbox_pdf_pt':[xs[col],ys[row],xs[col+1],ys[row+1]],
                          'owned_paths':owners[row][col], 'intersecting_paths':count,
                          'path_items_upper_bound':upper,
                          'requires_subdivision':count>PATH_BUDGET or upper>ITEM_BUDGET})
    return {'status':'complete_bbox_inventory' if not unknown else 'bbox_inventory_with_unlocated_paths',
            'coordinate_space':'unrotated_pdf_points','region_pdf_pt':list(box),'grid':grid,
            'source_paths_examined':total,'region_paths_located':inside,'outside_paths':outside,
            'unlocated_paths':unknown,'region_path_items':items,
            'tiles_requiring_subdivision':sum(c['requires_subdivision'] for c in cells),
            'tiles':cells,'quantity_scope':'diagnostic_only_no_duct_detection'}