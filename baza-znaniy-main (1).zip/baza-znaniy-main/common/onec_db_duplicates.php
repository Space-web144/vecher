<?php
declare(strict_types=1);

// Дополнительная проверка для страницы «База»: дубли номенклатуры ВНУТРИ
// самого DB_FILE — две (или больше) карточки на одну и ту же позицию под
// разными кодами. В отличие от проверки на приёме от 1С (web/onec_intake.
// php — НОВАЯ позиция против уже накопленной базы), здесь база сверяется
// сама с собой: такие пары могли накопиться до того, как заработала
// проверка на приёме, или из-за ручной правки в 1С. Критерий — жёсткий
// текстовый (полностью совпадающий normalize() наименования, БЕЗ разбора
// геометрии — см. докстринг common.matcher.find_text_duplicate_groups за
// тем, почему: геометрический разбор дважды дал ложные совпадения на
// реальной базе, заказчик явно попросил точность важнее полноты).
//
// Список может быть в тысячи групп — как и в web/onec_review.php, рендерим
// постранично (иначе страница перестаёт отвечать, тот же урок) и не
// пересчитываем группы на каждый клик "вперёд": отчёт кэшируется в
// DB_DUPLICATES_CACHE и пересчитывается только когда DB_FILE новее кэша
// (та же схема, что у DB_FILE_DUMP_CACHE на web/onec_database.php).
//
// Удаление выбранных дублей — отдельная форма (web/
// onec_db_duplicates_remove.php), с подтверждением в браузере и ещё одной
// проверкой на сервере (что код всё ещё реально дубль и группа не
// опустошается целиком). Доступно только admin/mainadmin (см.
// admin_guard.php).

require __DIR__ . '/admin_guard.php';
require __DIR__ . '/config.php';

const GROUPS_PER_PAGE = 50;
// Должно совпадать с SCHEMA_VERSION в common/web_db_duplicates_run.py.
const EXPECTED_DUPLICATES_SCHEMA_VERSION = 4;

if (empty($_SESSION['csrf'])) {
    $_SESSION['csrf'] = bin2hex(random_bytes(16));
}
$csrf = $_SESSION['csrf'];

function duplicates_cache_schema_is_current(): bool {
    $raw = file_get_contents(DB_DUPLICATES_CACHE);
    $data = $raw !== false ? json_decode($raw, true) : null;
    return is_array($data) && (int) ($data['schema_version'] ?? 0) >= EXPECTED_DUPLICATES_SCHEMA_VERSION;
}

function refresh_duplicates_cache_if_stale(): ?string {
    if (!is_file(DB_FILE)) {
        return 'Боевая база сравнения (DB_FILE) ещё не положена на сервер.';
    }
    $cacheFresh = is_file(DB_DUPLICATES_CACHE) && filemtime(DB_DUPLICATES_CACHE) >= filemtime(DB_FILE);
    if ($cacheFresh && duplicates_cache_schema_is_current()) {
        return null;
    }
    $cmd = implode(' ', [
        escapeshellarg(PYTHON_BIN),
        escapeshellarg(WEB_DB_DUPLICATES_SCRIPT),
        '--db', escapeshellarg(DB_FILE),
        '--out', escapeshellarg(DB_DUPLICATES_CACHE),
    ]) . ' 2>&1';
    $output = shell_exec($cmd);
    if ($output === null || trim($output) === '') {
        return 'Не удалось проверить базу: команда не выполнилась (shell_exec недоступен на сервере, '
            . 'или путь PYTHON_BIN в config.php неверный).';
    }
    $result = json_decode($output, true);
    if (!is_array($result) || empty($result['ok'])) {
        // Admin-only страница — показываем реальный вывод скрипта, как и на
        // onec_database.php/onec_whitespace_cleanup.php.
        $detail = is_array($result) ? (string) ($result['error'] ?? 'неизвестная ошибка') : trim($output);
        if (mb_strlen($detail, 'UTF-8') > 2000) {
            $detail = '…' . mb_substr($detail, -2000, null, 'UTF-8');
        }
        return 'Не удалось проверить базу: ' . $detail;
    }
    return null;
}

function duplicates_page_url(int $page): string {
    return 'onec_db_duplicates.php?' . http_build_query(['page' => $page]);
}

$cacheError = refresh_duplicates_cache_if_stale();
$report = null;
if ($cacheError === null) {
    $raw = file_get_contents(DB_DUPLICATES_CACHE);
    $report = $raw !== false ? json_decode($raw, true) : null;
    if (!is_array($report)) {
        $cacheError = 'Кэш отчёта повреждён — обновите страницу ещё раз.';
    }
}

$totalItems = (int) ($report['total_items'] ?? 0);
$allGroups = $report['groups'] ?? [];
$groupCount = count($allGroups);

$page = max(1, (int) ($_GET['page'] ?? 1));
$totalPages = max(1, (int) ceil($groupCount / GROUPS_PER_PAGE));
$page = min($page, $totalPages);
$offset = ($page - 1) * GROUPS_PER_PAGE;
$pageGroups = array_slice($allGroups, $offset, GROUPS_PER_PAGE);
$duplicateItemCount = (int) ($report['duplicate_item_count'] ?? 0);

$removed = $_GET['removed'] ?? null;
$dbRemoved = isset($_GET['dbRemoved']) ? (int) $_GET['dbRemoved'] : 0;
$skippedCount = isset($_GET['skippedCount']) ? (int) $_GET['skippedCount'] : 0;
$err = isset($_GET['err']) ? (string) $_GET['err'] : null;
?>
<!doctype html>
<html lang="ru">
<head>
<meta charset="utf-8">
<link rel="icon" type="image/svg+xml" href="assets/favicon.svg">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Дубли номенклатуры — База знаний</title>
<link rel="stylesheet" href="assets/style.css?v=<?= filemtime(__DIR__ . '/assets/style.css') ?>">
<script src="assets/ui.js?v=<?= filemtime(__DIR__ . '/assets/ui.js') ?>"></script>
</head>
<body>
<div class="shell">
  <?php require __DIR__ . '/sidebar.php'; ?>

  <div class="dashboard-main">
  <div class="page-wide">

  <a class="back-link" href="onec_database.php">← К базе номенклатуры</a>

  <div class="card">
    <h1>Дубли номенклатуры в базе</h1>
    <p class="subtitle">
      Дополнительная проверка: ищет в DB_FILE позиции с полностью совпадающим наименованием
      (без учёта пробелов, регистра и запятой/точки в десятичных числах), но записанные
      под разными кодами. По умолчанию отмечены на удаление все позиции группы, кроме первой — проверьте перед удалением, при
      необходимости снимите/поставьте галочки вручную. Хотя бы одна позиция в группе
      остаётся всегда, даже если отметить все.
    </p>

    <?php if ($removed !== null): ?>
    <div class="alert success">
      Удалено позиций: <?= $dbRemoved ?>.
      <?php if ($skippedCount > 0): ?>Пропущено: <?= $skippedCount ?> (например, база уже изменилась — обновите страницу и проверьте список).<?php endif; ?>
    </div>
    <?php endif; ?>
    <?php if ($err): ?>
    <div class="alert error" style="white-space: pre-wrap; font-family: ui-monospace, monospace; font-size: 0.85rem;"><?= htmlspecialchars($err, ENT_QUOTES, 'UTF-8') ?></div>
    <?php endif; ?>

    <?php if ($cacheError !== null): ?>
    <div class="alert error" style="white-space: pre-wrap; font-family: ui-monospace, monospace; font-size: 0.85rem;"><?= htmlspecialchars($cacheError, ENT_QUOTES, 'UTF-8') ?></div>
    <?php else: ?>

    <div class="table-wrap" style="margin-bottom: 18px;">
      <table class="data-table">
        <thead>
          <tr>
            <th>Всего позиций в базе</th>
            <th>Групп дублей</th>
            <th>Позиций в них</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td data-label="Всего позиций в базе"><?= $totalItems ?></td>
            <td data-label="Групп дублей"><?= $groupCount ?></td>
            <td data-label="Позиций в них"><?= $duplicateItemCount ?></td>
          </tr>
        </tbody>
      </table>
    </div>

    <?php if ($groupCount === 0): ?>
    <p class="subtitle">Дублей не найдено.</p>
    <?php else: ?>

    <p class="subtitle">Групп на странице: <?= count($pageGroups) ?> из <?= $groupCount ?><?php if ($totalPages > 1): ?>, страница <?= $page ?> из <?= $totalPages ?><?php endif; ?></p>

    <?php if ($groupCount > GROUPS_PER_PAGE): ?>
    <form method="post" action="onec_db_duplicates_remove_all.php" style="margin-bottom:16px;"
          onsubmit="return confirm('Удалить дубли во ВСЕХ <?= $groupCount ?> группах — в каждой группе останется только первая позиция, '
            + 'остальные (<?= $duplicateItemCount - $groupCount ?>) будут удалены из боевой базы сравнения. '
            + 'Это затронет VentSpec — удалённые коды перестанут находиться при сопоставлении. '
            + 'Перед записью будет сделана резервная копия файла. Продолжить?');">
      <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
      <input type="hidden" name="page" value="<?= $page ?>">
      <button type="submit" class="btn-small btn-danger">Удалить дубли во ВСЕХ <?= $groupCount ?> группах (кроме первой позиции в каждой)</button>
    </form>
    <?php endif; ?>

    <form id="bulk-remove-form" method="post" action="onec_db_duplicates_remove.php"
          style="display:flex; align-items:center; gap:10px; margin-bottom:16px; flex-wrap:wrap;"
          onsubmit="return onecDupRemoveConfirm(event);">
      <input type="hidden" name="csrf" value="<?= htmlspecialchars($csrf, ENT_QUOTES, 'UTF-8') ?>">
      <input type="hidden" name="page" value="<?= $page ?>">
      <span class="subtitle" style="margin:0;">Выбрано на удаление: <span id="bulk-selected-count">0</span></span>
      <button type="submit" class="btn-small btn-danger" id="bulk-remove-btn" disabled>Удалить выбранные</button>
    </form>

    <?php if ($totalPages > 1): ?>
    <div style="display:flex; align-items:center; gap:10px; margin-bottom:16px;">
      <?php if ($page > 1): ?>
      <a class="btn-small" href="<?= htmlspecialchars(duplicates_page_url($page - 1), ENT_QUOTES, 'UTF-8') ?>">← Назад</a>
      <?php endif; ?>
      <?php if ($page < $totalPages): ?>
      <a class="btn-small" href="<?= htmlspecialchars(duplicates_page_url($page + 1), ENT_QUOTES, 'UTF-8') ?>">Вперёд →</a>
      <?php endif; ?>
    </div>
    <?php endif; ?>

    <?php foreach ($pageGroups as $group): ?>
    <div class="table-wrap" style="margin-bottom: 14px;">
      <table class="data-table">
        <thead>
          <tr>
            <th></th>
            <th>Код</th>
            <th>Наименование</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($group as $i => $it): ?>
          <tr>
            <td data-label="">
              <input type="checkbox" class="bulk-select-checkbox" form="bulk-remove-form" name="remove[]"
                     value="<?= htmlspecialchars((string) ($it['Код'] ?? ''), ENT_QUOTES, 'UTF-8') ?>"
                     <?= $i > 0 ? 'checked' : '' ?>>
            </td>
            <td data-label="Код"><?= htmlspecialchars((string) ($it['Код'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
            <td data-label="Наименование"><?= htmlspecialchars((string) ($it['Наименование'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <?php endforeach; ?>

    <?php if ($totalPages > 1): ?>
    <div style="display:flex; align-items:center; gap:10px; margin-top:16px;">
      <?php if ($page > 1): ?>
      <a class="btn-small" href="<?= htmlspecialchars(duplicates_page_url($page - 1), ENT_QUOTES, 'UTF-8') ?>">← Назад</a>
      <?php endif; ?>
      <span class="subtitle" style="margin:0;">Страница <?= $page ?> из <?= $totalPages ?></span>
      <?php if ($page < $totalPages): ?>
      <a class="btn-small" href="<?= htmlspecialchars(duplicates_page_url($page + 1), ENT_QUOTES, 'UTF-8') ?>">Вперёд →</a>
      <?php endif; ?>
    </div>
    <?php endif; ?>

    <?php endif; ?>
    <?php endif; ?>
  </div>

  </div>
  </div>
</div>
<script>
// Счётчик выбранного и подтверждение перед удалением (см. web/
// onec_db_duplicates_remove.php) — похоже на web/onec_review.php, но
// действие одно (удалить), без "выбрать все на странице": чекбоксы уже
// стоят по умолчанию на всех, кроме первой позиции в каждой группе.
(function () {
  var checkboxes = document.querySelectorAll('.bulk-select-checkbox');
  var counter = document.getElementById('bulk-selected-count');
  var removeBtn = document.getElementById('bulk-remove-btn');
  if (!checkboxes.length || !removeBtn) return;

  function update() {
    var n = 0;
    checkboxes.forEach(function (cb) { if (cb.checked) n++; });
    counter.textContent = n;
    removeBtn.disabled = n === 0;
  }
  checkboxes.forEach(function (cb) { cb.addEventListener('change', update); });
  update();

  window.onecDupRemoveConfirm = function (event) {
    var n = 0;
    checkboxes.forEach(function (cb) { if (cb.checked) n++; });
    if (n === 0) {
      return false;
    }
    return confirm('Удалить выбранные позиции (' + n + ') из боевой базы сравнения? '
      + 'Это затронет VentSpec — удалённые коды перестанут находиться при сопоставлении. '
      + 'Перед удалением будет сделана резервная копия файла.');
  };
})();
</script>
</body>
</html>
