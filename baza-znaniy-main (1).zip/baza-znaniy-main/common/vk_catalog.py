"""Read a 1C VK nomenclature export without changing source names or units.

Catalog data is written to ignored runtime storage, never to the source tree.
"""
import argparse
from collections import Counter
import gzip
import hashlib
import json
from pathlib import Path


SCHEMA_VERSION = 1
MAX_ITEMS = 100000
FIELDS = {'Код': 'Код', 'Наименование': 'Наименование',
          'ЕдиницаИзмерения': 'ЕдиницаИзмерения'}


def text(value):
    return '' if value is None else str(value)


def validate_catalog(data, expected_count=None):
    if (not isinstance(data, dict) or data.get('schema_version') != SCHEMA_VERSION
            or data.get('catalog') != 'vk' or not isinstance(data.get('items'), list)):
        raise ValueError('Invalid VK catalog schema')
    items = data['items']
    if not items or len(items) > MAX_ITEMS or data.get('item_count') != len(items):
        raise ValueError('Invalid VK item count')
    if expected_count is not None and len(items) != expected_count:
        raise ValueError('VK item count differs from reviewed import')
    codes = set()
    for item in items:
        if not isinstance(item, dict):
            raise ValueError('Invalid VK item')
        for key in ('Код', 'Наименование'):
            if not isinstance(item.get(key), str) or not item[key].strip():
                raise ValueError('VK item is missing ' + key)
        if item['Код'] in codes:
            raise ValueError('Duplicate VK code: ' + item['Код'])
        codes.add(item['Код'])
        if item.get('ЕдиницаИзмерения') is not None and not isinstance(item['ЕдиницаИзмерения'], str):
            raise ValueError('Invalid VK unit')
    missing_units = sum(not item.get('ЕдиницаИзмерения') for item in items)
    if data.get('missing_units') != missing_units:
        raise ValueError('Invalid VK missing-unit count')
    return data


def read_export(path):
    from openpyxl import load_workbook
    path = Path(path)
    book = load_workbook(path, read_only=True, data_only=False)
    try:
        found = []
        for sheet in book:
            for number, row in enumerate(sheet.iter_rows(max_row=min(sheet.max_row, 20)), 1):
                headers = {}
                for index, cell in enumerate(row):
                    label = text(cell.value).strip().split('.')[-1].replace(' ', '')
                    if label in FIELDS:
                        headers[FIELDS[label]] = index
                if set(headers) == set(FIELDS):
                    found.append((sheet, number, headers))
                    break
        if len(found) != 1:
            raise ValueError('Expected one sheet with code, name and unit headers')
        sheet, header_row, headers = found[0]
        items = []
        for number, row in enumerate(sheet.iter_rows(min_row=header_row + 1), header_row + 1):
            if not any(cell.value is not None for cell in row):
                continue
            selected = {key: row[index] for key, index in headers.items()}
            if any(cell.data_type == 'f' for cell in selected.values()):
                raise ValueError('Formula in nomenclature fields, row %s' % number)
            item = {key: text(cell.value) for key, cell in selected.items()}
            item['ЕдиницаИзмерения'] = item['ЕдиницаИзмерения'] or None
            item['СтрокаИсточника'] = number
            items.append(item)
        names = Counter(item['Наименование'] for item in items)
        data = {
            'schema_version': SCHEMA_VERSION, 'catalog': 'vk',
            'source': {'filename': path.name, 'sha256': hashlib.sha256(path.read_bytes()).hexdigest(),
                       'sheet': sheet.title, 'header_row': header_row},
            'item_count': len(items),
            'missing_units': sum(not item['ЕдиницаИзмерения'] for item in items),
            'repeated_names': sum(count > 1 for count in names.values()),
            'items': items,
        }
        return validate_catalog(data)
    finally:
        book.close()


def encode_catalog(data):
    validate_catalog(data)
    raw = json.dumps(data, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    return gzip.compress(raw, mtime=0)


def main():
    parser = argparse.ArgumentParser(description='Prepare a separate VK catalog from a 1C Excel export')
    parser.add_argument('--input', required=True)
    parser.add_argument('--output', required=True)
    args = parser.parse_args()
    data = read_export(args.input)
    output = Path(args.output)
    output.parent.mkdir(parents=True, exist_ok=True)
    payload = encode_catalog(data)
    output.write_bytes(payload)
    print(json.dumps({'items': data['item_count'], 'missing_units': data['missing_units'],
                      'repeated_names': data['repeated_names'],
                      'payload_sha256': hashlib.sha256(payload).hexdigest(),
                      'source_sha256': data['source']['sha256']}, ensure_ascii=False))


if __name__ == '__main__':
    main()
