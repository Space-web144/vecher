# -*- coding: utf-8 -*-
"""Веб-приём номенклатуры 1С: распределение по каталогам, проверки, отчёт и очередь.
Статус фонового процесса записывается атомарно; stdout содержит итоговый JSON."""

import os

# Обязательно ДО импорта common.nomenclature_intake (на случай, если что-то
# из common/ транзитивно потянет numpy) — см. program-a/web_run.py за той же
# историей: на этом хостинге жёсткий лимит процессов/потоков на аккаунт.
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import sys
import json
import argparse
import traceback

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from common.nomenclature_intake import load_json_items  # noqa: E402
from common.catalog_store import CatalogStore  # noqa: E402
from common.routed_intake import process_intake  # noqa: E402



def _write_status(status_file, payload):
    """Атомарная запись статуса — этот скрипт запускается в фоне (PHP не
    ждёт его в самом HTTP-запросе), поэтому единственный надёжный способ
    узнать результат — файл на диске, а не то, что скрипт напечатает в
    stdout (см. web_run.py::_write_status, тот же приём)."""
    if not status_file:
        return
    tmp_path = status_file + ".tmp"
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False)
    os.replace(tmp_path, status_file)


def main():
    parser = argparse.ArgumentParser(description="Веб-запуск проверки входящей номенклатуры 1С")
    parser.add_argument("--input", required=True, help="путь к сохранённому JSON от 1С (новая/обновлённая номенклатура)")
    parser.add_argument("--existing", required=True, help="путь к JSON-снимку текущей базы номенклатуры (тот же формат полей 1С)")
    parser.add_argument("--output", required=True, help="куда сохранить Excel-отчёт с флагами")
    parser.add_argument("--status-file", default=None,
                        help="куда записать итоговый JSON-статус (для фонового запуска из PHP)")
    parser.add_argument("--claude-credentials", default=None,
                        help="путь к JSON с ключом Anthropic (см. common/anthropic_client.py) "
                             "для проверки дублей через Claude — передаётся путь, не ключ. "
                             "Не указано — эта проверка пропускается, остальные работают "
                             "как обычно")
    parser.add_argument("--name-key", default="Наименование")
    parser.add_argument("--code-key", default="Код")
    parser.add_argument("--db-file", default=None,
                         help="боевая база сравнения (DB_FILE) — если указана, позиции без "
                              "единого замечания дописываются в неё же, не только в --existing")
    parser.add_argument("--pending-file", default=None,
                         help="куда записать очередь позиций с замечаниями для ручной проверки "
                              "в браузере (web/onec_review.php) — без этого параметра очередь "
                              "просто не пишется, остаётся только Excel-отчёт")
    parser.add_argument("--token", default=None,
                         help="токен этой пачки (тот же, что в именах файлов) — обязателен "
                              "вместе с --pending-file, чтобы web/onec_review_submit.php знал, "
                              "какой файл очереди перечитывать при подтверждении правки")
    args = parser.parse_args()

    try:
        new_items = load_json_items(args.input)
        store = CatalogStore(args.existing, args.db_file, args.name_key, args.code_key)
        stats = process_intake(
            new_items, store, args.pending_file, args.token, args.output,
            credentials=args.claude_credentials,
            log=lambda msg: print(msg, file=sys.stderr),
        )

        result = {"ok": True, "output_file": args.output, "stats": stats}
        print(json.dumps(result, ensure_ascii=False))
        _write_status(args.status_file, result)
    except Exception as exc:
        result = {"ok": False, "error": str(exc), "trace": traceback.format_exc()}
        print(json.dumps(result, ensure_ascii=False))
        _write_status(args.status_file, result)
        sys.exit(1)


if __name__ == "__main__":
    main()
