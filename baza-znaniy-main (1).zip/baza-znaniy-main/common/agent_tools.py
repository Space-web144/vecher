# -*- coding: utf-8 -*-
"""Свои инструменты чата «Ассистент»: данные сайта, которые модель может
запросить сама (см. common/web_agent_chat.py).

* «Документация» (web/docs.php) — библиотека нормативов и регламентов:
  search_documents ищет по названиям и описаниям, open_document отдаёт
  модели сам документ.
* Verrata (web/verrata.php) — отчёты сравнения ревизий РД:
  list_verrata_reports — отчёты этого пользователя, open_verrata_report —
  таблица сравнения (xlsx) или отчёт по чертежам (pdf).

Права те же, что у страниц сайта: «Документация» открыта всем вошедшим,
отчёт Verrata — своему автору; чужой отчёт открывается, только если
пользователь сам прислал в чат его номер (ссылку на страницу отчёта) —
так же, как ссылка открывает его и на сайте.

Документ уходит модели через Files API: в результат инструмента — блоком
для чтения (PDF, текст таблицы), и в контейнер исполнения кода — исходным
файлом (container_upload), чтобы его можно было обработать кодом.
Загруженное запоминается в общем кэше (SharedUploads): один и тот же
норматив на 300 страниц не грузится заново для каждого вопроса. Кэш общий
для всех пользователей — документы библиотеки и так видны всем, а отчёт
Verrata из кэша отдаётся только после той же проверки прав.

Python 3.8, только стандартная библиотека (PDF и Excel готовит
common/agent_files.py).
"""
import contextlib
import fcntl
import glob
import hashlib
import json
import os
import re
import shutil
import tempfile
import time

from common import agent_files, agent_heavy

# Файл в хранилище Anthropic живёт 90 дней (FILE_EXPIRES_MAX_SEC); за
# сутки до конца срока из кэша уже не берём.
SHARED_USABLE_SEC = 89 * 86400
# Документ больше этого целиком модели не отдаём: каждый такой вызов —
# сотни тысяч токенов. Он остаётся в контейнере, и модель достаёт кодом
# только нужные страницы.
OPEN_MAX_TOKENS = 250000
SEARCH_LIMIT = 25
LIST_ALL_LIMIT = 200
VERRATA_LIST_LIMIT = 30

_ID_RE = re.compile(r"^[a-f0-9]{16}$")
_WORD_RE = re.compile(r"[\w.\-]+", re.UNICODE)

STATE_LABELS = {"running": "ещё обрабатывается", "error": "завершился с ошибкой"}

DEFINITIONS = {
    "search_documents": {
        "name": "search_documents",
        "description": (
            "Поиск в библиотеке «Документация» на сайте компании: нормативы (СП, ГОСТ, "
            "СанПиН), внутренние регламенты, стандарты, шаблоны — то, что загрузили "
            "администраторы. Возвращает документы с id, названием, категорией, описанием и "
            "типом файла. Пустой запрос — весь список. Смотри сюда, когда вопрос касается "
            "норматива, регламента или шаблона: если документ есть в библиотеке, опирайся на "
            "него, а не на память, и открой его через open_document."),
        "input_schema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Слова для поиска в названии, категории, описании и имени "
                                   "файла, например «СП 60» или «вентиляция». Пусто — все "
                                   "документы."},
            },
            "required": [],
        },
    },
    "open_document": {
        "name": "open_document",
        "description": (
            "Открывает документ из библиотеки «Документация» по id из search_documents: "
            "PDF и текст приходят для чтения, а исходный файл кладётся в контейнер исполнения "
            "кода (имя файла — в ответе инструмента). Очень большой документ приходит только "
            "в контейнер — тогда найди нужные страницы кодом и прочитай их."),
        "input_schema": {
            "type": "object",
            "properties": {
                "document_id": {"type": "string",
                                "description": "id документа (16 символов) из search_documents"},
            },
            "required": ["document_id"],
        },
    },
    "list_verrata_reports": {
        "name": "list_verrata_reports",
        "description": (
            "Список отчётов Verrata (сравнение ревизий рабочей документации) этого "
            "пользователя за последние 90 дней: номер отчёта, дата, раздел, файлы редакций, "
            "какие отчёты готовы. Нужен, когда спрашивают про «мой отчёт», «последнее "
            "сравнение» и т. п."),
        "input_schema": {"type": "object", "properties": {}, "required": []},
    },
    "open_verrata_report": {
        "name": "open_verrata_report",
        "description": (
            "Открывает готовый отчёт Verrata по номеру: kind=xlsx — таблица сравнения "
            "спецификаций (позиции, количества по редакциям, дельты; приходит текстом и "
            "исходным файлом в контейнер), kind=pdf — отчёт по чертежам. Числа в отчёте уже "
            "посчитаны программой — объясняй и анализируй их, а не пересчитывай заново. Чужой "
            "отчёт открывается, только если пользователь сам прислал его номер или ссылку."),
        "input_schema": {
            "type": "object",
            "properties": {
                "report_id": {"type": "string",
                              "description": "номер отчёта (16 символов) — из "
                                             "list_verrata_reports или из ссылки "
                                             "verrata_status.php?token=…"},
                "kind": {"type": "string", "enum": ["xlsx", "pdf"]},
            },
            "required": ["report_id", "kind"],
        },
    },
}

ACTIVITY = {
    "search_documents": "Ищет в «Документации»",
    "open_document": "Открывает документ из «Документации»",
    "list_verrata_reports": "Смотрит ваши отчёты Verrata",
    "open_verrata_report": "Открывает отчёт Verrata",
    agent_heavy.TOOL["name"]: "Готовит тяжёлую задачу",
}


class ToolError(Exception):
    """Ошибка для модели: уходит в tool_result с is_error, модель её видит
    и может сказать пользователю или попробовать иначе."""


def user_key(login):
    """Имя папки пользователя — как в web/agent_lib.php (agent_user_dir)."""
    return hashlib.sha256(login.encode("utf-8")).hexdigest()[:24]


def _normalize(text):
    return text.lower().replace("ё", "е")


def _size_text(size):
    if size >= 1024 * 1024:
        return "%.1f МБ" % (size / 1024.0 / 1024.0)
    return "%d КБ" % max(1, size // 1024)


def _date(timestamp):
    return time.strftime("%d.%m.%Y", time.localtime(timestamp)) if timestamp else "?"


class SharedUploads:
    """Кэш загруженного в Files API: ключ -> {"parts", "raw", "info", "uploaded"}.
    Файл общий для всех процессов чата, пишется под flock целиком."""

    def __init__(self, path):
        self.path = path

    @contextlib.contextmanager
    def _locked(self):
        with open(self.path + ".lock", "a") as handle:
            fcntl.flock(handle, fcntl.LOCK_EX)
            try:
                yield
            finally:
                fcntl.flock(handle, fcntl.LOCK_UN)

    def _read(self):
        try:
            with open(self.path, "r", encoding="utf-8") as handle:
                data = json.load(handle)
        except (OSError, ValueError):
            return {}
        return data if isinstance(data, dict) else {}

    def get(self, key, now=None):
        now = int(time.time()) if now is None else now
        with self._locked():
            record = self._read().get(key)
        if isinstance(record, dict) and now - int(record.get("uploaded") or 0) < SHARED_USABLE_SEC:
            return record
        return None

    def put(self, key, record, now=None):
        now = int(time.time()) if now is None else now
        with self._locked():
            data = self._read()
            data[key] = record
            # Записи с истёкшим сроком больше не нужны: файлов уже нет.
            data = {k: v for k, v in data.items()
                    if isinstance(v, dict) and now - int(v.get("uploaded") or 0) < SHARED_USABLE_SEC}
            tmp = "%s.%d.tmp" % (self.path, os.getpid())
            with open(tmp, "w", encoding="utf-8") as handle:
                json.dump(data, handle, ensure_ascii=False)
            os.replace(tmp, self.path)


class AgentTools:
    """Набор инструментов для одного ответа в чате.

    docs_dir / verrata_dir — папки сайта (DOCS_DIR, VERRATA_OUTPUT_DIR);
    без папки соответствующие инструменты модели не предлагаются.
    owner_key — папка пользователя (хэш логина), user_texts — тексты его
    вопросов в этом чате (для проверки прав на чужой отчёт Verrata)."""

    def __init__(self, client, docs_dir=None, verrata_dir=None, owner_key="",
                 user_texts=(), shared=None, log=None, heavy=None):
        self.client = client
        self.docs_dir = docs_dir if docs_dir and os.path.isdir(docs_dir) else None
        self.verrata_dir = verrata_dir if verrata_dir and os.path.isdir(verrata_dir) else None
        self.owner_key = owner_key
        self.user_texts = "\n".join(user_texts)
        self.shared = shared
        self.log = log or (lambda message: None)
        self.heavy = heavy
        self.opened = []                  # что открывали: для журнала и чата

    def definitions(self):
        names = []
        if self.docs_dir:
            names += ["search_documents", "open_document"]
        if self.verrata_dir:
            names += ["list_verrata_reports", "open_verrata_report"]
        definitions = [DEFINITIONS[name] for name in names]
        if self.heavy is not None:
            definitions.append(agent_heavy.TOOL)
        return definitions

    def handles(self, name):
        return name in DEFINITIONS and DEFINITIONS[name] in self.definitions()

    def run(self, name, tool_input):
        """-> (content, extra_blocks, is_error). content — содержимое
        tool_result (список блоков), extra_blocks — блоки container_upload
        для того же сообщения пользователя."""
        tool_input = tool_input if isinstance(tool_input, dict) else {}
        if self.heavy is not None and name == agent_heavy.TOOL["name"]:
            return self.heavy.run(tool_input)
        try:
            if not self.handles(name):
                raise ToolError("Инструмент %s недоступен." % name)
            if name == "search_documents":
                return self._search(str(tool_input.get("query") or "")), [], False
            if name == "open_document":
                content, extra = self._open_document(str(tool_input.get("document_id") or ""))
                return content, extra, False
            if name == "list_verrata_reports":
                return self._list_reports(), [], False
            content, extra = self._open_report(str(tool_input.get("report_id") or ""),
                                               str(tool_input.get("kind") or ""))
            return content, extra, False
        except ToolError as exc:
            return [{"type": "text", "text": str(exc)}], [], True
        except agent_files.AttachmentError as exc:
            return [{"type": "text", "text": "Файл не удалось подготовить: %s" % exc}], [], True

    # ── «Документация» ──

    def _load_docs(self):
        try:
            with open(os.path.join(self.docs_dir, "docs.json"), "r", encoding="utf-8") as handle:
                data = json.load(handle)
        except (OSError, ValueError):
            return []
        docs = []
        for item in data if isinstance(data, list) else []:
            if not isinstance(item, dict) or not _ID_RE.match(str(item.get("id") or "")):
                continue
            file_id = str(item.get("file") or item.get("id"))
            ext = str(item.get("ext") or "").lower()
            if not _ID_RE.match(file_id) or not re.match(r"^[a-z0-9]{1,5}$", ext):
                continue
            docs.append({
                "id": item["id"], "file": file_id, "ext": ext,
                "title": str(item.get("title") or item.get("original_name") or "без названия"),
                "category": str(item.get("category") or ""),
                "description": str(item.get("description") or ""),
                "original_name": str(item.get("original_name") or ""),
                "size": int(item.get("size") or 0),
                "uploaded_at": int(item.get("uploaded_at") or 0),
            })
        return docs

    def _search(self, query):
        docs = self._load_docs()
        if not docs:
            return [{"type": "text", "text": "Библиотека «Документация» пуста."}]
        words = [w for w in _WORD_RE.findall(_normalize(query)) if len(w) >= 2]
        if words:
            scored = []
            for doc in docs:
                haystack = _normalize(" ".join((doc["title"], doc["category"],
                                                doc["description"], doc["original_name"])))
                score = sum(1 for w in words if w in haystack)
                if score:
                    scored.append((-score, doc["title"].lower(), doc))
            scored.sort(key=lambda item: item[:2])
            found = [item[2] for item in scored[:SEARCH_LIMIT]]
            head = ("По запросу «%s» найдено документов: %d%s." % (
                query.strip(), len(scored),
                " (показаны первые %d)" % SEARCH_LIMIT if len(scored) > SEARCH_LIMIT else ""))
            if not found:
                head += (" Попробуй другие слова или пустой запрос — весь список (%d документов)."
                         % len(docs))
        else:
            found = sorted(docs, key=lambda d: (d["category"] == "", d["category"].lower(),
                                                d["title"].lower()))[:LIST_ALL_LIMIT]
            head = "Все документы библиотеки (%d):" % len(docs)
        lines = [head]
        for doc in found:
            line = "- id %s · %s · категория: %s · %s, %s, загружен %s" % (
                doc["id"], doc["title"], doc["category"] or "без категории",
                doc["ext"].upper(), _size_text(doc["size"]), _date(doc["uploaded_at"]))
            if doc["description"]:
                line += "\n  " + doc["description"][:300]
            lines.append(line)
        return [{"type": "text", "text": "\n".join(lines)}]

    def _open_document(self, doc_id):
        if not _ID_RE.match(doc_id):
            raise ToolError("Неверный id документа — возьми его из search_documents.")
        doc = next((d for d in self._load_docs() if d["id"] == doc_id), None)
        if doc is None:
            raise ToolError("Документа с таким id в библиотеке нет — возможно, его удалили.")
        path = os.path.join(self.docs_dir, "%s.%s" % (doc["file"], doc["ext"]))
        if not os.path.isfile(path):
            raise ToolError("Файл документа не найден на сервере.")
        name = doc["original_name"] or "%s.%s" % (doc["title"], doc["ext"])
        if not name.lower().endswith("." + doc["ext"]):
            name += "." + doc["ext"]
        record = self._uploaded("doc:%s.%s" % (doc["file"], doc["ext"]), path, name)
        self.opened.append(doc["title"])
        header = "Документ «%s» из «Документации» (категория: %s)." % (
            doc["title"], doc["category"] or "без категории")
        return self._as_tool_result(header, record)

    # ── Verrata ──

    def _jobs(self):
        jobs = []
        for path in glob.glob(os.path.join(self.verrata_dir, "*_job.json")):
            token = os.path.basename(path)[:-len("_job.json")]
            if not _ID_RE.match(token):
                continue
            try:
                with open(path, "r", encoding="utf-8") as handle:
                    job = json.load(handle)
            except (OSError, ValueError):
                continue
            if isinstance(job, dict):
                job["token"] = token
                jobs.append(job)
        jobs.sort(key=lambda job: -int(job.get("created") or 0))
        return jobs

    def _report_files(self, token):
        return {kind: os.path.join(self.verrata_dir, "%s_verrata.%s" % (token, kind))
                for kind in ("xlsx", "pdf")}

    def _state(self, token):
        try:
            with open(os.path.join(self.verrata_dir, token + "_status.json"), "r",
                      encoding="utf-8") as handle:
                status = json.load(handle)
        except (OSError, ValueError):
            return ""
        return str(status.get("state") or "") if isinstance(status, dict) else ""

    def _list_reports(self):
        own = [job for job in self._jobs()
               if user_key(str(job.get("user") or "")) == self.owner_key][:VERRATA_LIST_LIMIT]
        if not own:
            return [{"type": "text", "text": "У пользователя нет отчётов Verrata за последние "
                                             "90 дней."}]
        lines = ["Отчёты Verrata пользователя (свежие первыми):"]
        for job in own:
            files = self._report_files(job["token"])
            ready = [kind for kind, path in files.items() if os.path.isfile(path)]
            state = STATE_LABELS.get(self._state(job["token"]), "")
            lines.append("- номер %s · %s · раздел %s · режим %s · редакции: %s · готово: %s%s" % (
                job["token"], _date(int(job.get("created") or 0)), job.get("section") or "?",
                job.get("mode") or "?", ", ".join(str(f) for f in job.get("files") or []) or "?",
                ", ".join(ready) or "ничего", " · " + state if state else ""))
        return [{"type": "text", "text": "\n".join(lines)}]

    def _open_report(self, token, kind):
        if not _ID_RE.match(token):
            raise ToolError("Неверный номер отчёта — 16 символов из list_verrata_reports "
                            "или из ссылки на отчёт.")
        if kind not in ("xlsx", "pdf"):
            raise ToolError("kind — xlsx (таблица спецификаций) или pdf (отчёт по чертежам).")
        job = next((j for j in self._jobs() if j["token"] == token), None)
        own = job is not None and user_key(str(job.get("user") or "")) == self.owner_key
        if not own and token not in self.user_texts:
            raise ToolError("Это не отчёт пользователя. Чужой отчёт можно открыть, только если "
                            "пользователь сам пришлёт его номер или ссылку.")
        path = self._report_files(token)[kind]
        if not os.path.isfile(path):
            raise ToolError("Отчёта %s по этому сравнению нет: он не готов, не собран или "
                            "срок хранения истёк." % kind.upper())
        files = ", ".join(str(f) for f in (job or {}).get("files") or [])
        name = "Verrata %s %s.%s" % ((job or {}).get("section") or "", token[:6], kind)
        record = self._uploaded("verrata:%s.%s:%d" % (token, kind, int(os.path.getmtime(path))),
                                path, name)
        self.opened.append("отчёт Verrata " + token)
        header = "Отчёт Verrata %s (%s) от %s, раздел %s, редакции: %s." % (
            token, "таблица спецификаций" if kind == "xlsx" else "отчёт по чертежам",
            _date(int((job or {}).get("created") or 0)), (job or {}).get("section") or "?",
            files or "?")
        return self._as_tool_result(header, record)

    # ── загрузка ──

    def _uploaded(self, key, path, name):
        record = self.shared.get(key) if self.shared else None
        if record:
            return record
        workdir = tempfile.mkdtemp(prefix="agent-tool-")
        uploaded = []
        try:
            try:
                parts, info = agent_files.prepare(path, name, workdir)
            except agent_files.AttachmentError as exc:
                # Напрямую не читается (норматив на 700 страниц, PDF с
                # паролем…) — но в контейнере кодом его можно разобрать.
                parts, info = [], {"kind": "unreadable", "pages": 0, "tokens": 0,
                                   "note": str(exc)}
            if info["tokens"] <= OPEN_MAX_TOKENS:
                for part in parts:
                    file_id = self.client.upload_file(part["path"], part["mime"])
                    uploaded.append({"id": file_id, "block": part["block"], "title": part["title"]})
            raw, raw_name = self.client.upload_file_named(
                path, agent_files.mime_type(name), agent_files.container_name(name))
        except Exception:
            for part in uploaded:
                try:
                    self.client.delete_file(part["id"])
                except Exception:                     # noqa: BLE001
                    pass
            raise
        finally:
            shutil.rmtree(workdir, ignore_errors=True)
        record = {"parts": uploaded, "raw": raw, "raw_name": raw_name,
                  "info": info, "uploaded": int(time.time())}
        if self.shared:
            try:
                self.shared.put(key, record)
            except OSError as exc:
                self.log("кэш загруженных документов не записан: %s" % exc)
        return record

    def _as_tool_result(self, header, record):
        info = record.get("info") or {}
        text = [header]
        if info.get("pages"):
            text.append("Страниц: %d." % info["pages"])
        if record.get("parts"):
            text.append("Содержимое — ниже.")
        elif info.get("kind") == "container":
            text.append("Напрямую этот тип файла не читается.")
        elif info.get("kind") == "unreadable":
            text.append("Целиком сюда документ не отдан (%s) — открой его кодом и прочитай "
                        "нужные страницы." % (info.get("note") or "не читается напрямую"))
        else:
            text.append("Документ большой (около %d тыс. токенов) — целиком он сюда не "
                        "отдан. Открой его кодом и прочитай только нужные страницы "
                        "(поиск по тексту — pdfplumber/pypdf)." % (int(info.get("tokens") or 0)
                                                                   // 1000))
        text.append("Исходный файл лежит в контейнере исполнения кода под именем «%s» "
                    "(найди его командой find, если понадобится обработать кодом)."
                    % record.get("raw_name"))
        content = [{"type": "text", "text": " ".join(text)}]
        for part in record.get("parts") or []:
            source = {"type": "file", "file_id": part["id"]}
            if part.get("block") == "image":
                content.append({"type": "image", "source": source})
            else:
                content.append({"type": "document", "source": source,
                                "title": part.get("title") or header[:100]})
        extra = [{"type": "container_upload", "file_id": record["raw"]}] if record.get("raw") else []
        return content, extra
