"""Local, evidence-first album pipeline. No web exposure, model calls or quantity approval.

Run with Python >=3.11. The existing VentSpec converter may run under a separate
Python interpreter via --converter-python. Only explicitly private directories
outside the public web root should be used for --workspace.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import tempfile

SCHEMA = 1
MAX_PDF_BYTES = 100 * 1024 * 1024
MAX_PAGES = 600
REPO = Path(__file__).resolve().parents[1]
HEADER_TOKENS = ('наименованиеитехническаяхарактеристика', 'едизмерения',
                 'количество', 'типмаркаобозначение')
SPEC_FIELDS = ('POS', 'NAME', 'TYPE', 'CODE', 'VENDOR', 'UNIT', 'QTY', 'MASS', 'NOTE', 'SECTION')


class PipelineError(RuntimeError):
    pass


def digest(path):
    result = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            result.update(block)
    return result.hexdigest()


def write_json(path, obj):
    path = Path(path)
    tmp = None
    try:
        with tempfile.NamedTemporaryFile('w', encoding='utf-8', dir=path.parent, delete=False) as f:
            tmp = Path(f.name)
            json.dump(obj, f, ensure_ascii=False, indent=2, allow_nan=False)
            f.write('\n')
        os.replace(tmp, path)
    finally:
        if tmp is not None:
            tmp.unlink(missing_ok=True)


def read_json(path):
    with Path(path).open(encoding='utf-8') as f:
        return json.load(f)


def header_evidence(text):
    """Text evidence for the conventional Russian specification table header.

    The heuristic is intentionally conservative; unfamiliar layouts require an
    explicit range. It must not treat a detected header as an approved quantity.
    """
    normalized = re.sub(r'[^а-яa-z0-9]', '', text.casefold().replace('ё', 'е'))
    return [token for token in HEADER_TOKENS if token in normalized or
            (token == 'количество' and 'колво' in normalized)]


def contiguous_runs(pages):
    groups = []
    for page in pages:
        if groups and page == groups[-1][-1] + 1:
            groups[-1].append(page)
        else:
            groups.append([page])
    return groups


def _center(word):
    return (word[0] + word[2]) / 2, (word[1] + word[3]) / 2


def _continuation_anchor(page):
    """Use actual header coordinates, not hard-coded columns or sheet numbers."""
    bounds = page.rect * page.derotation_matrix
    words = page.get_text('words')
    unit = [w for w in words if w[4].casefold().rstrip('.') == 'ед' and w[1] < bounds.height * .2]
    qty = [w for w in words if re.sub(r'[^а-я]', '', w[4].casefold()) in ('колво', 'количество')
           and w[1] < bounds.height * .2]
    if len(unit) != 1 or len(qty) != 1:
        return None
    ux, uy = _center(unit[0]); qx, qy = _center(qty[0])
    if not ux < qx or abs(uy - qy) > bounds.height * .05:
        return None
    return {'width_pt': bounds.width, 'height_pt': bounds.height,
            'rotation': page.rotation, 'unit_x_pt': ux, 'qty_x_pt': qx}


def _continuation_evidence(page, anchor, expected):
    bounds = page.rect * page.derotation_matrix
    if (page.rotation != anchor['rotation'] or abs(bounds.width - anchor['width_pt']) > 2 or
            abs(bounds.height - anchor['height_pt']) > 2):
        return None
    words = page.get_text('words')
    footer = [w for w in words if w[0] > bounds.width * .94 and w[1] > bounds.height * .94
              and re.fullmatch(r'[1-9]\d{0,2}', w[4].strip())]
    if len(footer) != 1 or int(footer[0][4]) != expected:
        return None
    ux, qx = anchor['unit_x_pt'], anchor['qty_x_pt']
    tolerance = min(16., (qx - ux) / 4)
    units = [w for w in words if abs(_center(w)[0] - ux) <= tolerance and w[1] < bounds.height * .9
             and re.fullmatch(r'(?:шт|м[²³23]?|кг|т|л|компл|комплект|упак|пог\.?м)\.?', w[4], re.I)]
    quantities = [w for w in words if abs(_center(w)[0] - qx) <= tolerance and w[1] < bounds.height * .9
                  and re.fullmatch(r'\d+(?:[.,]\d+)?', w[4])]
    rows = [(u, q) for u in units for q in quantities if abs(_center(u)[1] - _center(q)[1]) <= 3]
    # Two different quantity rows plus printed sequence and matching format.
    if len({round(_center(u)[1], 1) for u, _ in rows}) < 2:
        return None
    return {'method': 'aligned_columns_and_sequential_footer', 'printed_sheet_number': expected,
            'footer_bbox_pt': [round(x, 2) for x in footer[0][:4]],
            'unit_x_pt': round(ux, 2), 'quantity_x_pt': round(qx, 2),
            'aligned_quantity_rows': len(rows)}


def inspect_specification(document):
    observed = []
    for i, page in enumerate(document, 1):
        marks = header_evidence(page.get_text('text'))
        if len(marks) == len(HEADER_TOKENS):
            observed.append({'pdf_page': i, 'header_tokens': marks})
    runs = contiguous_runs([row['pdf_page'] for row in observed])
    candidates = []
    # Only extend a proven header run through consecutive independently supported
    # continuation sheets. Never cross into the next independently detected run.
    for index, run in enumerate(runs):
        first, last = run[0], run[-1]
        anchor = _continuation_anchor(document[first - 1])
        limit = runs[index + 1][0] - 1 if index + 1 < len(runs) else len(document)
        while anchor and last < limit:
            evidence = _continuation_evidence(document[last], anchor, last - first + 2)
            if evidence is None:
                break
            last += 1
            observed.append({'pdf_page': last, 'header_tokens': [], **evidence})
        candidates.append({'first': first, 'last': last, 'page_count': last - first + 1})
    return {'candidates': candidates, 'observations': sorted(observed, key=lambda r: r['pdf_page'])}


def choose_range(inventory, page_count, explicit=None):
    if explicit is not None:
        first, last = explicit
        if type(first) is not int or type(last) is not int or not 1 <= first <= last <= page_count:
            raise PipelineError('Invalid explicit specification page range')
        return first, last, 'operator_selected'
    candidates = inventory['candidates']
    if len(candidates) != 1:
        raise PipelineError('Specification range not unique; review inventory.json and select --pages FIRST LAST')
    first, last = candidates[0]['first'], candidates[0]['last']
    method = ('unique_header_and_continuation_candidate' if any(row.get('method') == 'aligned_columns_and_sequential_footer' for row in inventory.get('observations', []))
              else 'unique_contiguous_header_candidate')
    return first, last, method


def _safe_workspace(workspace):
    root = Path(workspace).expanduser().resolve()
    public = (REPO / 'web').resolve()
    if root == public or public in root.parents:
        raise PipelineError('Workspace must not be inside the public web directory')
    root.mkdir(mode=0o700, parents=True, exist_ok=True)
    return root


def prepare(pdf, workspace, pages=None):
    import fitz
    pdf = Path(pdf).expanduser().resolve(strict=True)
    if not pdf.is_file() or not 10 <= pdf.stat().st_size <= MAX_PDF_BYTES:
        raise PipelineError('PDF exceeds the supported size or is not a file')
    with pdf.open('rb') as f:
        if f.read(5) != b'%PDF-':
            raise PipelineError('Expected a PDF file')
    sha = digest(pdf)
    project = _safe_workspace(workspace) / sha
    project.mkdir(mode=0o700, exist_ok=True)
    with fitz.open(pdf) as doc:
        if doc.needs_pass or not 1 <= len(doc) <= MAX_PAGES:
            raise PipelineError('Expected an unencrypted PDF with 1–600 pages')
        inventory = {'schema_version': SCHEMA, 'source_pdf_sha256': sha,
                     'page_count': len(doc), **inspect_specification(doc)}
        write_json(project / 'inventory.json', inventory)
        first, last, method = choose_range(inventory, len(doc), pages)
        stage = project / ('specification-%03d-%03d' % (first, last))
        stage.mkdir(mode=0o700, exist_ok=True)
        with tempfile.TemporaryDirectory(dir=stage) as folder:
            candidate = Path(folder) / 'specification.pdf'
            with fitz.open() as out:
                out.insert_pdf(doc, from_page=first - 1, to_page=last - 1)
                out.save(candidate, garbage=4, deflate=True)
            with fitz.open(candidate) as check:
                if len(check) != last - first + 1:
                    raise PipelineError('Extracted PDF page count mismatch')
                # Preserve the text and orientation of each source page.
                for i, extracted in enumerate(check):
                    source = doc[first - 1 + i]
                    if extracted.rotation != source.rotation or extracted.get_text('text') != source.get_text('text'):
                        raise PipelineError('Extracted page text or orientation differs from source')
            if digest(pdf) != sha:
                raise PipelineError('Source PDF changed during preparation')
            spec_sha = digest(candidate)
            previous = stage / 'selection.json'
            # Reusing a stage is allowed only when its source and extracted bytes
            # are still valid. PDF generators may assign different file IDs.
            if previous.exists() and (stage / 'specification.pdf').exists():
                old = read_json(previous)
                if (old.get('schema_version') == SCHEMA and old.get('source_pdf_sha256') == sha
                        and old.get('first') == first and old.get('last') == last
                        and old.get('specification_sha256') == digest(stage / 'specification.pdf')):
                    if method == 'operator_selected' and old.get('selection_method') != method:
                        old.update(selection_method=method, selection_requires_review=False)
                        write_json(previous, old)
                    return stage
            write_json(stage / 'conversion.json', {'schema_version': SCHEMA, 'status': 'not_run'})
            os.replace(candidate, stage / 'specification.pdf')
            write_json(stage / 'selection.json', {
                'schema_version': SCHEMA, 'source_pdf_sha256': sha,
                'specification_sha256': spec_sha, 'first': first, 'last': last,
                'selection_method': method, 'selection_requires_review': method != 'operator_selected',
                'page_count': last - first + 1,
                'page_map': [{'specification_page': p, 'album_pdf_page': first + p - 1}
                             for p in range(1, last - first + 2)],
            })
    return stage


def index_album(pdf, workspace, timeout=300):
    """Reuse the existing read-only album analyzer in its isolated worker package."""
    import fitz
    pdf = Path(pdf).expanduser().resolve(strict=True)
    if not pdf.is_file() or not 10 <= pdf.stat().st_size <= MAX_PDF_BYTES:
        raise PipelineError('Invalid PDF size')
    sha = digest(pdf)
    project = _safe_workspace(workspace) / sha
    project.mkdir(mode=0o700, exist_ok=True)
    worker = REPO / 'common' / 'clean_papper_album_worker'
    with fitz.open(pdf) as doc:
        if doc.needs_pass or not 1 <= len(doc) <= MAX_PAGES:
            raise PipelineError('Expected an unencrypted PDF with 1–600 pages')
        count = len(doc)
    manifest = project / 'album_stage.json'
    write_json(manifest, {'schema_version': SCHEMA, 'source_pdf_sha256': sha, 'status': 'running'})
    try:
        proc = subprocess.run([sys.executable, '-m', 'modules.pdf.project_album', '--file', str(pdf)],
                              cwd=str(worker), capture_output=True, text=True, timeout=timeout)
        if proc.returncode:
            raise PipelineError('Existing album worker failed')
        result = json.loads(proc.stdout)
        if (result.get('ok') is not True or result.get('source_pdf_sha256') != sha
                or result.get('page_count') != count or digest(pdf) != sha):
            raise PipelineError('Album result does not match source PDF')
        write_json(project / 'album.json', result)
        write_json(manifest, {'schema_version': SCHEMA, 'source_pdf_sha256': sha,
                              'status': 'indexed', 'album_sha256': digest(project / 'album.json')})
        return project / 'album.json'
    except Exception:
        write_json(manifest, {'schema_version': SCHEMA, 'source_pdf_sha256': sha, 'status': 'failed'})
        raise


def validate_selection(stage):
    stage = Path(stage).resolve(strict=True)
    selection = read_json(stage / 'selection.json')
    first, last = selection['first'], selection['last']
    if type(first) is not int or type(last) is not int or not 1 <= first <= last <= MAX_PAGES:
        raise PipelineError('Invalid selection range')
    count = last - first + 1
    expected = [{'specification_page': p, 'album_pdf_page': first + p - 1}
                for p in range(1, count + 1)]
    if (selection.get('schema_version') != SCHEMA or selection.get('page_count') != count
            or selection.get('page_map') != expected
            or not re.fullmatch(r'[a-f0-9]{64}', selection.get('source_pdf_sha256', ''))
            or selection['source_pdf_sha256'] != stage.parent.name
            or digest(stage / 'specification.pdf') != selection.get('specification_sha256')):
        raise PipelineError('Specification stage is inconsistent; prepare the album again')
    return selection


def source_rows(rows, page_map):
    mapped = {row['specification_page'] - 1: row['album_pdf_page'] for row in page_map}
    result = []
    for i, row in enumerate(rows, 1):
        indices = row.get('_SOURCE_PAGES', [row.get('_PAGE')])
        if (not isinstance(indices, list) or not indices or any(type(x) is not int or x not in mapped for x in indices)
                or type(row.get('_PAGE')) is not int or row['_PAGE'] not in indices):
            raise PipelineError('Converter row has missing or invalid source pages')
        result.append({'row_id': 'SPEC-%06d' % i, 'workbook_row': i + 1,
                       'album_pdf_pages': [mapped[x] for x in indices],
                       'quantity_source_album_page': mapped[row['_PAGE']],
                       'fields': {name: row.get(name) for name in SPEC_FIELDS}})
    return result


def native_worker(pdf, output, selection):
    """Use the exact native route of the existing converter and its verification gate.

    No Claude client is constructed/configured by this adapter. Any page that the
    existing converter would send to a model blocks the entire conversion.
    """
    import fitz
    for folder in (str(REPO), str(REPO / 'program-a'), str(REPO / 'program-b')):
        if folder not in sys.path:
            sys.path.insert(0, folder)
    from pdf_to_spec import extract_spec_rows, convert
    from spec_conversion import _assess_native
    from verify_so import verify_spec

    rows, rotated, gost = extract_spec_rows(str(pdf))
    with fitz.open(pdf) as doc:
        needed, blank = _assess_native(doc, str(pdf), rows)
    check = verify_spec(str(pdf), rows)
    if (needed or not rows or check.get('ok') is not True
            or not isinstance(check.get('positions_parsed'), int) or check['positions_parsed'] <= 0):
        raise PipelineError('Native conversion did not pass all page and quantity checks; no workbook approved')
    normalized = source_rows(rows, selection['page_map'])
    out = output / 'specification.xlsx'
    _, count = convert(str(pdf), str(out), rows_data=(rows, rotated, gost), editable_systems=True)
    if count != len(normalized):
        raise PipelineError('Workbook row count differs from native rows')
    write_json(output / 'specification_rows.json', {
        'schema_version': SCHEMA, 'source_pdf_sha256': selection['source_pdf_sha256'],
        'specification_sha256': selection['specification_sha256'],
        'quantity_scope': 'design_specification_only_not_measured',
        'row_count': count, 'rows': normalized,
    })
    write_json(output / 'verification.json', {'schema_version': SCHEMA,
               'specification_sha256': selection['specification_sha256'], 'engine': 'native',
               'blank_album_pages': [selection['page_map'][i]['album_pdf_page'] for i in sorted(blank)],
               'protocol': check, 'protocol_page_numbers': 'extracted_specification',
               'page_map': selection['page_map']})


def convert_stage(stage, converter_python=None, timeout=900):
    stage = Path(stage).resolve(strict=True)
    selection = validate_selection(stage)
    manifest = stage / 'conversion.json'
    base = {'schema_version': SCHEMA, 'source_pdf_sha256': selection['source_pdf_sha256'],
            'specification_sha256': selection['specification_sha256']}
    write_json(manifest, {**base, 'status': 'running'})
    try:
        with tempfile.TemporaryDirectory(dir=stage) as folder:
            output = Path(folder)
            proc = subprocess.run([str(converter_python or sys.executable), str(Path(__file__).resolve()),
                                   '_native-worker', str(stage), str(output)],
                                  cwd=str(REPO), capture_output=True, text=True, timeout=timeout)
            if proc.returncode:
                # The worker emits diagnostics locally, never to an external service.
                detail = (proc.stderr or '').strip()[-1200:]
                raise PipelineError('Native converter failed or requires review; no new workbook accepted. ' + detail)
            protocol = read_json(output / 'verification.json')
            rows = read_json(output / 'specification_rows.json')
            if (protocol.get('engine') != 'native' or protocol.get('protocol', {}).get('ok') is not True
                    or protocol.get('protocol', {}).get('positions_parsed', 0) <= 0
                    or protocol.get('specification_sha256') != selection['specification_sha256']
                    or rows.get('specification_sha256') != selection['specification_sha256']
                    or rows.get('row_count') != len(rows.get('rows', [])) or not rows['rows']):
                raise PipelineError('Invalid converter result')
            if validate_selection(stage) != selection:
                raise PipelineError('Selection changed during conversion')
            names = ('specification.xlsx', 'specification_rows.json', 'verification.json')
            hashes = {name: digest(output / name) for name in names}
            for name in names:
                os.replace(output / name, stage / name)
            result = {**base, 'status': 'verified_native', 'row_count': rows['row_count'],
                      'positions_with_quantity': protocol['protocol']['positions_parsed'],
                      'outputs_sha256': hashes, 'quantity_scope': 'design_specification_only_not_measured'}
            write_json(manifest, result)
            return result
    except Exception:
        write_json(manifest, {**base, 'status': 'failed', 'outputs_approved': False})
        raise


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    subs = parser.add_subparsers(dest='command', required=True)
    p = subs.add_parser('prepare')
    p.add_argument('--pdf', type=Path, required=True)
    p.add_argument('--workspace', type=Path, required=True)
    p.add_argument('--pages', type=int, nargs=2, metavar=('FIRST', 'LAST'))
    i = subs.add_parser('index-album')
    i.add_argument('--pdf', type=Path, required=True)
    i.add_argument('--workspace', type=Path, required=True)
    i.add_argument('--timeout', type=int, default=300)
    c = subs.add_parser('convert')
    c.add_argument('--stage', type=Path, required=True)
    c.add_argument('--converter-python')
    c.add_argument('--timeout', type=int, default=900)
    w = subs.add_parser('_native-worker', help=argparse.SUPPRESS)
    w.add_argument('stage', type=Path)
    w.add_argument('output', type=Path)
    a = parser.parse_args(argv)
    try:
        if a.command == 'prepare':
            print(prepare(a.pdf, a.workspace, a.pages))
        elif a.command == 'index-album':
            print(index_album(a.pdf, a.workspace, a.timeout))
        elif a.command == 'convert':
            print(json.dumps(convert_stage(a.stage, a.converter_python, a.timeout), ensure_ascii=False))
        else:
            native_worker(a.stage / 'specification.pdf', a.output, validate_selection(a.stage))
    except (PipelineError, OSError, ValueError, RuntimeError, ImportError, subprocess.TimeoutExpired) as exc:
        print(str(exc), file=sys.stderr)
        return 1
    return 0


if __name__ == '__main__':
    sys.exit(main())