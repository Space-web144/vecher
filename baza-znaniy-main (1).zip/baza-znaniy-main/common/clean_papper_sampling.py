"""Deterministic whole-region PDF drawing sampling for Clean Papper 10.1.

The caller already retrieved the page's drawing list from PyMuPDF.
We inventory the entire list and pick at most budget original paths.
A late colored path must not be excluded just because architecture appears first.
This is still a sample, NOT a proof of complete object detection.
"""
from __future__ import annotations

from collections import Counter
import math

DEFAULT_BUDGET = 50000
MAX_COLOR_GROUPS = 12


def _rgb(value):
    if not isinstance(value, (list, tuple)) or len(value) != 3:
        return None
    try:
        channels = tuple(float(x) for x in value)
    except (TypeError, ValueError, OverflowError):
        return None
    if not all(math.isfinite(x) and 0 <= x <= 1 for x in channels):
        return None
    return channels


def _hex(value):
    rgb = _rgb(value)
    return "#%02x%02x%02x" % tuple(round(x * 255) for x in rgb) if rgb else None


def _colored(value):
    rgb = _rgb(value)
    return rgb is not None and max(rgb) - min(rgb) >= .27


def _intersects(path, box):
    rect = path.get("rect")
    if rect is None:
        return True
    try:
        x0, y0, x1, y1 = map(float, rect)
    except (ValueError, TypeError):
        return True
    if not all(math.isfinite(x) for x in (x0, y0, x1, y1)):
        return True
    # A LINE rect can have zero width or height.
    return not (x1 < box[0] - .5 or x0 > box[2] + .5 or
                y1 < box[1] - .5 or y0 > box[3] + .5)


def _even_subset(items, maximum):
    n = len(items)
    if maximum >= n:
        return items[:]
    if maximum <= 0:
        return []
    return [items[min(n - 1, (2 * i + 1) * n // (2 * maximum))]
            for i in range(maximum)]


def sample_drawings(paths, rect, budget=DEFAULT_BUDGET):
    """Return [(original_path_index, drawing), ...], diagnostics.

    Consider stroke and fill separately. The full inventory counts PDF drawing
    records, not individual items, and is independent of ordering.
    """
    if not isinstance(budget, int) or budget < 1 or budget > DEFAULT_BUDGET:
        raise ValueError("Invalid scan budget")
    if len(rect) != 4:
        raise ValueError("Invalid region")
    region = tuple(map(float, rect))
    if not all(math.isfinite(x) for x in region) or not (
        region[0] < region[2] and region[1] < region[3]
    ):
        raise ValueError("Invalid region")
    total = len(paths)
    tinted, neutral = [], []
    strokes = Counter()
    fills = Counter()
    for index, path in enumerate(paths):
        if not _intersects(path, region):
            continue
        stroke, fill = path.get("color"), path.get("fill")
        stroke_hex, fill_hex = _hex(stroke), _hex(fill)
        if stroke_hex is not None:
            strokes[stroke_hex] += 1
        if fill_hex is not None:
            fills[fill_hex] += 1
        if _colored(stroke) or _colored(fill):
            tinted.append(index)
        else:
            neutral.append(index)
    eligible = len(tinted) + len(neutral)
    if eligible <= budget:
        chosen = tinted + neutral
    else:
        # Guarantee coverage for rare colored paths, while sampling all
        # noncolored positions too. Split the budget when both are plentiful.
        colored_take = min(len(tinted), max(budget // 2, budget - len(neutral)))
        neutral_take = min(len(neutral), budget - colored_take)
        spare = budget - colored_take - neutral_take
        colored_take += min(spare, len(tinted) - colored_take)
        chosen = _even_subset(tinted, colored_take) + _even_subset(neutral, neutral_take)
    chosen.sort()
    metadata = {
        "strategy": "full_region_inventory_stratified_color_priority_v1",
        "source_paths_total": total,
        "region_paths_total": eligible,
        "selected_paths": len(chosen),
        "sampling_truncated": len(chosen) < eligible,
        "colored_paths_in_region": len(tinted),
        "gray_or_unspecified_paths_in_region": len(neutral),
        "stroke_colors_in_region": [
            {"color": key, "path_count": count}
            for key, count in strokes.most_common(MAX_COLOR_GROUPS)
        ],
        "fill_colors_in_region": [
            {"color": key, "path_count": count}
            for key, count in fills.most_common(MAX_COLOR_GROUPS)
        ],
        "note": "Stroke/fill inventory does not inspect rasterized or nested image contents",
    }
    return [(i, paths[i]) for i in chosen], metadata
