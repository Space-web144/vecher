# -*- coding: utf-8 -*-
"""Служба очереди Альфика. Запускается на VPS из каталога, принадлежащего root."""
import argparse
import collections
import contextlib
import fcntl
import os
import re
import select
import shutil
import socketserver
import stat
import subprocess
import tempfile
import threading
import time
import uuid
from pathlib import Path

if __package__:
    from .agent_heavy import (
        HeavyError, MAX_INPUTS, MAX_INPUT_BYTES, MAX_LOG_BYTES, MAX_SCRIPT_BYTES,
        copy_bytes, output_metadata, read_frame, send_frame,
    )
else:
    from agent_heavy import (
        HeavyError, MAX_INPUTS, MAX_INPUT_BYTES, MAX_LOG_BYTES, MAX_SCRIPT_BYTES,
        copy_bytes, output_metadata, read_frame, send_frame,
    )

ROOT = Path("/var/lib/alfik-worker")
SOCKET = "/run/alfik-worker/worker.sock"
IMAGE = "alfik-heavy:1"
LABEL = "info.alfastroi.alfik-heavy=1"
DOCKER = "/usr/bin/docker"
MAX_JOBS = 6
HEARTBEAT = 5
JOB_TIMEOUT = 30 * 60
INPUT_NAME = re.compile(r"[1-5]\.[a-z0-9]{1,8}\Z")
CONTAINER_UID = 65534


def input_manifest(frame):
    script = frame.get("script")
    files = frame.get("files")
    if (not isinstance(script, str) or not script.strip()
            or len(script.encode("utf-8")) > MAX_SCRIPT_BYTES
            or not isinstance(files, list) or not 1 <= len(files) <= MAX_INPUTS):
        raise HeavyError("Некорректный скрипт или список входных файлов.")
    names = set()
    for item in files:
        if not isinstance(item, dict):
            raise HeavyError("Некорректная запись входного файла.")
        name, size = item.get("name"), item.get("size")
        if (not isinstance(name, str) or not INPUT_NAME.fullmatch(name)
                or name in names or type(size) is not int or not 0 < size <= MAX_INPUT_BYTES):
            raise HeavyError("Некорректное имя или размер входного файла.")
        names.add(name)
    return script, files


def remove_container(name):
    subprocess.run([DOCKER, "rm", "-f", name], timeout=30, check=False,
                   stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


def clean_containers():
    cmd = [DOCKER, "ps", "-aq", "--filter", "label=" + LABEL]
    ids = subprocess.check_output(cmd, text=True, timeout=30).split()
    for name in ids:
        remove_container(name)
    if ids and subprocess.check_output(cmd, text=True, timeout=30).strip():
        raise HeavyError("Docker не завершил предыдущую задачу. Повторите позже.")


def docker_command(job, name):
    return [
        DOCKER, "create", "--rm", "--name", name, "--label", LABEL, "--pull=never",
        "--network", "none", "--read-only", "--log-driver", "none",
        "--cap-drop", "ALL", "--security-opt", "no-new-privileges",
        "--user", "%d:%d" % (CONTAINER_UID, CONTAINER_UID), "--pids-limit", "128",
        "--cpus", "2", "--memory", "6g", "--memory-swap", "6g",
        "--env", "HOME=/work", "--env", "TMPDIR=/work",
        "--env", "OPENBLAS_NUM_THREADS=2", "--env", "OMP_NUM_THREADS=2",
        "--mount", "type=bind,source=%s/input,target=/input,readonly" % job,
        "--mount", "type=bind,source=%s/output,target=/output" % job,
        "--mount", "type=bind,source=%s/work,target=/work" % job,
        "--workdir", "/work", IMAGE, "python", "-I", "-B", "/input/task.py",
    ]


def run_container(job, status):
    clean_containers()
    for name in ("output", "work"):
        os.chown(job / name, CONTAINER_UID, CONTAINER_UID)
    name = "alfik-heavy-" + uuid.uuid4().hex
    try:
        subprocess.run(docker_command(job, name), timeout=30, check=True,
                       stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL)
        return collect_result(name, status)
    finally:
        remove_container(name)


def collect_result(name, status):
    log = bytearray()
    truncated = threading.Event()

    def drain(stream):
        with stream:
            for block in iter(lambda: stream.read(4096), b""):
                keep = max(0, MAX_LOG_BYTES - len(log))
                log.extend(block[:keep])
                if keep < len(block):
                    truncated.set()

    with subprocess.Popen([DOCKER, "start", "--attach", name], stdin=subprocess.DEVNULL,
                          stdout=subprocess.PIPE, stderr=subprocess.STDOUT) as process:
        reader = threading.Thread(target=drain, args=(process.stdout,), daemon=True)
        reader.start()
        deadline = time.monotonic() + JOB_TIMEOUT
        try:
            while process.poll() is None:
                status("running")
                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    raise HeavyError("Обработка превысила 30 минут.")
                try:
                    process.wait(timeout=min(HEARTBEAT, remaining))
                except subprocess.TimeoutExpired:
                    continue
        finally:
            if process.poll() is None:
                process.kill()
            reader.join(timeout=5)
        text = log.decode("utf-8", errors="replace")
        if truncated.is_set():
            text += "\n[Консольный вывод сокращён.]"
        if process.returncode != 0:
            if process.returncode == 137:
                raise HeavyError("Обработка прервана. Возможно, исчерпан лимит памяти 6 ГиБ.")
            raise HeavyError("Код завершился с ошибкой (%d).\n%s" % (process.returncode, text))
        return text


class JobQueue:
    """Очередь готовых заданий. Единственное активное задание на весь VPS."""

    def __init__(self):
        self.condition = threading.Condition()
        self.waiting = collections.deque()
        self.active = False

    @contextlib.contextmanager
    def turn(self, status):
        ticket = object()
        with self.condition:
            self.waiting.append(ticket)
        started = False
        try:
            while not started:
                with self.condition:
                    if not self.active and self.waiting[0] is ticket:
                        self.waiting.popleft()
                        self.active = started = True
                        break
                status("queued")
                with self.condition:
                    self.condition.wait_for(
                        lambda: not self.active and self.waiting[0] is ticket, timeout=HEARTBEAT)
            yield
        finally:
            with self.condition:
                if started:
                    self.active = False
                else:
                    self.waiting.remove(ticket)
                self.condition.notify_all()


class Worker(socketserver.ThreadingUnixStreamServer):
    daemon_threads = True

    def __init__(self, socket_path, root, runner=run_container):
        self.root = Path(root)
        self.runner = runner
        self.queue = JobQueue()
        self.slots = threading.BoundedSemaphore(MAX_JOBS)
        super().__init__(str(socket_path), Handler)

    def server_bind(self):
        super().server_bind()
        os.chmod(self.server_address, 0o660)


class Handler(socketserver.StreamRequestHandler):
    timeout = 120

    def handle(self):
        if not self.server.slots.acquire(blocking=False):
            send_frame(self.request, {"status": "error", "message": "Очередь заполнена. Повторите позже."})
            return
        try:
            send_frame(self.request, {"status": "ready"})
            script, inputs = input_manifest(read_frame(self.rfile))
            with tempfile.TemporaryDirectory(dir=self.server.root, prefix="job-") as folder:
                job = Path(folder)
                for name in ("input", "output", "work"):
                    (job / name).mkdir(mode=0o755)
                    (job / name).chmod(0o755)
                script_path = job / "input" / "task.py"
                script_path.write_text(script, encoding="utf-8")
                script_path.chmod(0o644)
                for item in inputs:
                    input_path = job / "input" / item["name"]
                    with input_path.open("xb") as handle:
                        copy_bytes(self.rfile, handle.write, item["size"])
                    input_path.chmod(0o644)

                with self.server.queue.turn(self.status):
                    self.status("running")
                    text = self.server.runner(job, self.status)
                self.send_results(job / "output", text)
        except HeavyError as exc:
            self.error(str(exc))
        except (OSError, subprocess.SubprocessError):
            self.error("На сервере не удалось завершить обработку.")
        finally:
            self.server.slots.release()

    def status(self, value):
        # После отправки исходников клиент только читает. Закрытие сокета
        # останавливает контейнер и освобождает место в очереди.
        if select.select([self.request], [], [], 0)[0]:
            raise BrokenPipeError
        send_frame(self.request, {"status": value})

    def error(self, message):
        with contextlib.suppress(OSError):
            send_frame(self.request, {"status": "error", "message": message})

    def send_results(self, folder, text):
        items = []
        for path in sorted(folder.iterdir()):
            info = path.lstat()
            if not stat.S_ISREG(info.st_mode):
                continue
            items.append({"name": path.name, "size": info.st_size})
        output_metadata(items)
        send_frame(self.request, {"status": "result", "stdout": text, "files": items})
        for item in items:
            fd = os.open(folder / item["name"], os.O_RDONLY | os.O_NOFOLLOW | os.O_NONBLOCK)
            with os.fdopen(fd, "rb") as handle:
                copy_bytes(handle, self.request.sendall, item["size"])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--cleanup", action="store_true")
    args = parser.parse_args()
    if args.cleanup:
        clean_containers()
        return
    if not ROOT.is_mount():
        raise SystemExit("The worker requires its mounted 15 GiB workspace")
    with (ROOT / ".worker.lock").open("a") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        clean_containers()
        for path in ROOT.glob("job-*"):
            shutil.rmtree(path)
        Path(SOCKET).unlink(missing_ok=True)
        try:
            with Worker(SOCKET, ROOT) as worker:
                worker.serve_forever()
        finally:
            Path(SOCKET).unlink(missing_ok=True)


if __name__ == "__main__":
    main()
