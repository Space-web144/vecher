# -*- coding: utf-8 -*-
"""Синхронное подтверждение или отклонение одной позиции очереди 1С.
Распределение и запись выполняет common.routed_intake с общей блокировкой каталогов."""

import os

os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import sys
import json
import argparse

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from pathlib import Path
from common.catalog_store import CatalogStore  # noqa: E402
from common.routed_intake import review_items  # noqa: E402


def main():
    parser = argparse.ArgumentParser(description="Подтверждение или отклонение одной позиции из очереди ручной проверки 1С")
    parser.add_argument("--pending-file", required=True, help="файл очереди <токен>_1c_pending.json")
    parser.add_argument("--id", required=True, type=int, help="id позиции внутри файла очереди")
    parser.add_argument("--reject", action="store_true",
                        help="отклонить позицию вместо добавления — никуда не попадает, просто уходит из очереди")
    parser.add_argument("--name", default=None, help="итоговое (возможно, поправленное) наименование — не нужно при --reject")
    parser.add_argument("--existing", default=None, help="путь к эталонному снимку номенклатуры — не нужно при --reject")
    parser.add_argument("--db-file", default=None, help="боевая база сравнения (DB_FILE), опционально")
    parser.add_argument("--name-key", default="Наименование")
    parser.add_argument("--code-key", default="Код")
    parser.add_argument("--catalog", choices=("ventilation", "vk"), default=None)
    args = parser.parse_args()

    if not args.reject and not args.name:
        parser.error("--name обязателен, если не указан --reject")
    if not args.reject and not args.existing:
        parser.error("--existing обязателен, если не указан --reject")

    try:
        existing = args.existing or str(Path(args.pending_file).parent.parent / '1c_full_nomenclature.json')
        store = CatalogStore(existing, args.db_file, args.name_key, args.code_key)
        result = review_items(store, [(args.pending_file, args.id, args.name)], args.catalog, args.reject)
        if result['errors']:
            raise ValueError(result['errors'][0]['error'])
        item = result['items'][0]
        print(json.dumps({"ok": True, "item": item, "rejected": args.reject}, ensure_ascii=False))
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False))
        sys.exit(1)


if __name__ == "__main__":
    main()
