"""Separate runtime catalogs, serialized writers and recoverable multi-file updates.

The transaction journal is in protected web/data. Recovery rolls back an
interrupted update, including queue resolution, before another writer starts.
"""
from collections import Counter
from contextlib import contextmanager
from datetime import datetime, timezone
import fcntl
import io
import json
import os
from pathlib import Path
import tempfile

from openpyxl import load_workbook
from common.nomenclature_routing import CATALOGS, code_of, normalize_name
from common.vk_catalog import validate_catalog


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


def read_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))


def staged(path, data):
    fd, name = tempfile.mkstemp(prefix='.routing-', dir=str(path.parent))
    with os.fdopen(fd, 'wb') as stream:
        stream.write(data)
        stream.flush()
        os.fsync(stream.fileno())
    return Path(name)


class CatalogStore:
    def __init__(self, existing, db_file=None, name_key='Наименование', code_key='Код'):
        self.existing = Path(existing).resolve()
        self.root = self.existing.parent
        self.db_file = Path(db_file).resolve() if db_file else None
        self.vk_file = self.root / '1c_vk_catalog.json'
        self.assignments_file = self.root / '1c_catalog_assignments.json'
        self.journal = self.root / '.routing-transaction.json'
        self.name_key, self.code_key = name_key, code_key

    @contextmanager
    def locked(self):
        self.root.mkdir(parents=True, exist_ok=True)
        with open(self.root / '.routing.lock', 'a') as handle:
            fcntl.flock(handle, fcntl.LOCK_EX)
            self.recover()
            try:
                yield self
            finally:
                fcntl.flock(handle, fcntl.LOCK_UN)

    def recover(self):
        if not self.journal.exists():
            return
        records = read_json(self.journal)
        for record in records:
            target, backup = Path(record['target']), record['backup']
            if backup:
                # Do not consume backups: recovery itself can be interrupted.
                os.replace(staged(target, Path(backup).read_bytes()), target)
            else:
                target.unlink(missing_ok=True)
        self.journal.unlink()
        self.cleanup(records)

    @staticmethod
    def cleanup(records):
        for record in records:
            for key in ('backup', 'temporary'):
                if record.get(key):
                    Path(record[key]).unlink(missing_ok=True)

    def commit(self, writes):
        """Call under locked(); stage every file before replacing any target."""
        records = []
        try:
            for target, data in writes.items():
                target = Path(target).resolve()
                target.parent.mkdir(parents=True, exist_ok=True)
                if target.exists() and target.read_bytes() == data:
                    continue
                backup = staged(target, target.read_bytes()) if target.exists() else None
                temporary = staged(target, data)
                records.append({'target': str(target), 'backup': str(backup) if backup else None,
                                'temporary': str(temporary)})
            if not records:
                return
            os.replace(staged(self.journal, json_bytes(records)), self.journal)
            for record in records:
                os.replace(record['temporary'], record['target'])
            self.journal.unlink()  # Commit point; after this, cleanup is optional.
        except BaseException:
            if self.journal.exists():
                self.recover()
            else:
                self.cleanup(records)
            raise
        self.cleanup(records)

    def load(self):
        self.snapshot = read_json(self.existing)
        if not isinstance(self.snapshot, list):
            raise ValueError('Неверный формат снимка 1С')
        # Fail closed: an unavailable VK base must never turn known water codes into Vent.
        self.vk = validate_catalog(read_json(self.vk_file))
        if not self.db_file or not self.db_file.is_file():
            raise ValueError('База вентиляции недоступна; приём остановлен без изменения каталогов')
        book = load_workbook(self.db_file, read_only=True, data_only=True)
        try:
            self.vent = [{self.code_key: str(row[0]).strip(), self.name_key: str(row[1])}
                         for row in book.active.iter_rows(min_row=2, max_col=2, values_only=True)
                         if row[0] is not None and row[1] is not None]
        finally:
            book.close()
        self.items = {'ventilation': self.vent, 'vk': self.vk['items']}
        self.by_code = {catalog: {} for catalog in CATALOGS}
        self.memberships = {}
        for catalog, items in self.items.items():
            for item in items:
                code = code_of(item, self.code_key)
                if code:
                    self.memberships.setdefault(code, set()).add(catalog)
                    self.by_code[catalog].setdefault(code, item)
        # Older ventilation workbooks may use local row IDs instead of 1C
        # codes. A snapshot code is confirmed only when its exact normalized
        # name also exists in the working workbook; never admit the whole snapshot.
        self.vent_targets = {code_of(it, self.code_key): {code_of(it, self.code_key)} for it in self.vent}
        vent_names = {}
        for it in self.vent:
            vent_names.setdefault(normalize_name(it[self.name_key]), set()).add(code_of(it, self.code_key))
        for it in self.snapshot:
            code = code_of(it, self.code_key)
            targets = vent_names.get(normalize_name(it.get(self.name_key)))
            if code and targets and code not in self.by_code['ventilation']:
                self.by_code['ventilation'][code] = dict(it)
                self.vent_targets[code] = targets
                self.memberships.setdefault(code, set()).add('ventilation')
        self.assignments = read_json(self.assignments_file) if self.assignments_file.exists() else {}
        if not isinstance(self.assignments, dict) or any(v not in CATALOGS for v in self.assignments.values()):
            raise ValueError('Неверный формат ручных назначений раздела')
        return self

    def revision(self):
        return tuple((str(p), p.stat().st_mtime_ns, p.stat().st_size) if p.exists() else (str(p), None)
                     for p in (self.existing, self.vk_file, self.db_file, self.assignments_file) if p)

    def upserts(self, entries, manual=False):
        """Build writes without publishing. entries=(raw, catalog); no historic moves."""
        writes, touched, counts = {}, set(), Counter()
        snapshots = {code_of(item, self.code_key): item for item in self.snapshot}
        for raw, catalog in entries:
            if catalog not in CATALOGS:
                raise ValueError('Сначала выберите раздел: Вентиляция или ВК')
            code = code_of(raw, self.code_key)
            name = raw.get(self.name_key)
            if not code or not isinstance(name, str) or not name.strip():
                raise ValueError('Для добавления обязательны код 1С и наименование')
            raw = dict(raw, **{self.code_key: code, self.name_key: ' '.join(name.split())})
            unit = raw.get('ЕдиницаИзмерения')
            if unit is not None and not isinstance(unit, str):
                raise ValueError('Единица измерения должна быть строкой или null')
            known = self.memberships.get(code, set())
            if known and catalog not in known:
                raise ValueError('Код уже закреплён за другим разделом; перенос существующей карточки не выполняется')
            previous = self.by_code[catalog].get(code)
            if (catalog == 'ventilation' and len(self.vent_targets.get(code, ())) > 1 and previous
                    and normalize_name(previous[self.name_key]) != normalize_name(raw[self.name_key])):
                raise ValueError('Код связан с несколькими строками Excel; сначала уточните дубли в базе вентиляции')
            combined = {**(previous or {}), **raw}
            if previous == combined:
                counts['unchanged'] += 1
            else:
                counts['updated' if previous else 'added'] += 1
                counts[catalog] += 1
                if previous:
                    previous.update(combined)
                else:
                    self.items[catalog].append(combined)
                    self.by_code[catalog][code] = combined
                touched.add(catalog)
            self.memberships.setdefault(code, set()).add(catalog)
            if manual and self.assignments.get(code) != catalog:
                self.assignments[code] = catalog
                writes[self.assignments_file] = json_bytes(self.assignments)
            if catalog == 'ventilation':
                if code in snapshots:
                    snapshots[code].update(raw)
                else:
                    self.snapshot.append(dict(raw))
                    snapshots[code] = self.snapshot[-1]
        if 'vk' in touched:
            self.vk.pop('import_payload_sha256', None)
            self.vk['item_count'] = len(self.vk['items'])
            self.vk['missing_units'] = sum(not it.get('ЕдиницаИзмерения') for it in self.vk['items'])
            self.vk['repeated_names'] = sum(n > 1 for n in Counter(it['Наименование'] for it in self.vk['items']).values())
            self.vk['updated_from_1c_at'] = datetime.now(timezone.utc).isoformat()
            validate_catalog(self.vk)
            writes[self.vk_file] = json_bytes(self.vk)
        if 'ventilation' in touched:
            writes[self.existing] = json_bytes(self.snapshot)
            # PHP filemtime is second-resolution; force a refresh even if an
            # update and a cached view were created during the same second.
            cache = self.root / 'outputs/db_file_dump.json'
            if cache.exists():
                writes[cache] = json_bytes({'schema_version': 0})
            book = load_workbook(self.db_file)
            try:
                sheet = book.active
                rows = {}
                for row in sheet.iter_rows(min_row=2, max_col=2):
                    rows.setdefault(str(row[0].value).strip(), []).append(row[0].row)
                for raw, catalog in entries:
                    if catalog != 'ventilation':
                        continue
                    code = code_of(raw, self.code_key)
                    name = self.by_code[catalog][code][self.name_key]
                    numbers = [number for target in self.vent_targets.get(code, {code})
                               for number in rows.get(target, [])]
                    if not numbers:
                        numbers = [sheet.max_row + 1]
                        rows[code] = numbers
                        cell = sheet.cell(numbers[0], 1, code)
                        cell.data_type = 's'
                    for number in numbers:
                        cell = sheet.cell(number, 2, name)
                        cell.data_type = 's'  # 1C text is not an Excel formula.
                stream = io.BytesIO()
                book.save(stream)
                writes[self.db_file] = stream.getvalue()
            finally:
                book.close()
        return writes, dict(counts)
