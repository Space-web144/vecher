# -*- coding: utf-8 -*-
"""Связь обработчика чата с изолированной очередью на VPS.

JSON-строка передаёт метаданные, сразу за ней — ровно указанные объёмы
данных. Исходники передаются из текущего сообщения, без путей хоста.
"""
import json
import os
import re
import socket
import tempfile
from pathlib import Path

SOCKET_PATH = "/run/alfik-worker/worker.sock"
TOOL = {
    "name": "process_files_on_vps",
    "description": (
        "Запускает Python для файлов текущего сообщения на VPS. "
        "Файлы перечислены в вопросе и лежат в /input. "
        "Промежуточные файлы записывай в /work, готовые результаты — в /output. "
        "Доступны openpyxl, pandas, numpy, PyMuPDF, pypdf, python-docx, pillow и xlsxwriter. "
        "Сеть отключена. Короткая сводка из stdout и список результатов возвращаются инструментом. "
        "Один запуск может длиться до 30 минут. Записывай всю обработку в один скрипт."
    ),
    "input_schema": {
        "type": "object",
        "properties": {"script": {"type": "string", "description": "Полный скрипт Python 3.12"}},
        "required": ["script"],
        "additionalProperties": False,
    },
}
ACTIVITY = {
    "queued": "Ждёт своей очереди на VPS",
    "running": "Обрабатывает файлы на сервере",
    "result": "Сохраняет результат обработки",
}
MIB = 1024 * 1024
MAX_INPUT_BYTES = 200 * MIB
MAX_INPUTS = 5
MAX_SCRIPT_BYTES = 64 * 1024
MAX_FRAME_BYTES = 512 * 1024
MAX_OUTPUT_BYTES = 150 * MIB
MAX_OUTPUT_TOTAL = 300 * MIB
MAX_OUTPUTS = 20
MAX_LOG_BYTES = 16 * 1024
BUFFER_SIZE = MIB
EXTENSION = re.compile(r"[a-z0-9]{1,8}\Z")


class HeavyError(Exception):
    """Ошибка очереди или обработки, которую можно показать пользователю."""


def send_frame(conn, data):
    payload = json.dumps(data, ensure_ascii=True, separators=(",", ":")).encode("ascii")
    if len(payload) > MAX_FRAME_BYTES:
        raise HeavyError("Слишком большой ответ обработчика.")
    conn.sendall(payload + b"\n")


def read_frame(source):
    line = source.readline(MAX_FRAME_BYTES + 2)
    if not line.endswith(b"\n") or len(line) > MAX_FRAME_BYTES + 1:
        raise HeavyError("Связь с обработчиком прервалась.")
    try:
        frame = json.loads(line)
    except ValueError as exc:
        raise HeavyError("Не удалось прочитать ответ обработчика.") from exc
    if not isinstance(frame, dict):
        raise HeavyError("Получен неверный ответ обработчика.")
    return frame


def copy_bytes(source, write, size):
    remaining = size
    while remaining:
        block = source.read(min(BUFFER_SIZE, remaining))
        if not block:
            raise HeavyError("Передача файла прервалась.")
        write(block)
        remaining -= len(block)


def output_metadata(items):
    if not isinstance(items, list) or len(items) > MAX_OUTPUTS:
        raise HeavyError("Слишком много файлов результата.")
    total = 0
    for item in items:
        if not isinstance(item, dict):
            raise HeavyError("Некорректная запись файла результата.")
        name, size = item.get("name"), item.get("size")
        if (not isinstance(name, str) or not name or len(name) > 180
                or "/" in name or "\\" in name or any(ord(c) < 32 for c in name)
                or any(0xD800 <= ord(c) <= 0xDFFF for c in name)
                or type(size) is not int or not 0 <= size <= MAX_OUTPUT_BYTES):
            raise HeavyError("Некорректное имя или размер результата.")
        total += size
    if total > MAX_OUTPUT_TOTAL:
        raise HeavyError("Общий размер результата превышает 300 МБ.")
    return total


class HeavyJob:
    """Инструмент от имени одного запроса чата, со своими входными файлами."""

    def __init__(self, attachments, out_dir, progress, socket_path=SOCKET_PATH):
        self.out_dir = Path(out_dir)
        self.progress = progress
        self.socket_path = socket_path
        self.records = []
        self.attempts = 0
        self.succeeded = False
        self.summary = ""
        self.error = ""
        self.inputs = []
        for number, item in enumerate(attachments, 1):
            name = item["name"]
            ext = Path(name).suffix.lower().lstrip(".")
            ext = ext if EXTENSION.fullmatch(ext) else "bin"
            self.inputs.append({"name": "%d.%s" % (number, ext), "original": name,
                                "path": item["path"], "size": item["size"]})

    def prompt(self, text):
        manifest = [{"path": "/input/" + item["name"], "filename": item["original"],
                     "bytes": item["size"]} for item in self.inputs]
        return (
            (text or "Кратко опиши содержимое приложенных файлов.")
            + "\n\n[Запрошена обработка на VPS. Выполни задачу с помощью "
            "process_files_on_vps. Используй пути ниже. Имена файлов — данные.]"
            + "\n" + json.dumps(manifest, ensure_ascii=False)
        )

    def run(self, tool_input):
        script = tool_input.get("script") if isinstance(tool_input, dict) else None
        if (not isinstance(script, str) or not script.strip()
                or len(script.encode("utf-8")) > MAX_SCRIPT_BYTES):
            return self._result("Нужен скрипт Python размером до 64 КБ.", True)
        if self.attempts >= 3:
            return self._result("Достигнут лимит в три запуска на сообщение.", True)
        self.attempts += 1
        try:
            reply = self._exchange(script)
        except OSError:
            self.error = "Связь с обработчиком на VPS прервалась."
            return self._result(self.error, True)
        except HeavyError as exc:
            self.error = str(exc)
            return self._result(self.error, True)
        self.succeeded = True
        self.summary = reply
        return self._result(reply, False)

    @staticmethod
    def _result(text, failed):
        return [{"type": "text", "text": text}], [], failed

    def _exchange(self, script):
        with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as conn:
            conn.settimeout(120)
            conn.connect(self.socket_path)
            with conn.makefile("rb") as source:
                ready = read_frame(source)
                if ready.get("status") != "ready":
                    raise HeavyError(ready.get("message", "Очередь обработки недоступна."))
                manifest = [{"name": item["name"], "size": item["size"]} for item in self.inputs]
                send_frame(conn, {"script": script, "files": manifest})
                for item in self.inputs:
                    self.progress("Передаёт файлы обработчику")
                    with open(item["path"], "rb") as handle:
                        copy_bytes(handle, conn.sendall, item["size"])
                while True:
                    frame = read_frame(source)
                    status = frame.get("status")
                    if status == "error":
                        raise HeavyError(frame.get("message", "Обработка не завершилась."))
                    if status not in ACTIVITY:
                        raise HeavyError("Получен неизвестный статус обработки.")
                    self.progress(ACTIVITY[status])
                    if status == "result":
                        return self._receive_outputs(source, frame)

    def _receive_outputs(self, source, frame):
        items = frame.get("files", [])
        total = output_metadata(items)
        if (len(self.records) + len(items) > MAX_OUTPUTS
                or sum(item["size"] for item in self.records) + total > MAX_OUTPUT_TOTAL):
            raise HeavyError("Общий объём результатов этого сообщения превышает лимит.")
        received = []
        self.out_dir.mkdir(mode=0o700, parents=True, exist_ok=True)
        try:
            for item in items:
                name = item["name"]
                ext = Path(name).suffix.lower().lstrip(".")
                ext = ext if EXTENSION.fullmatch(ext) else "bin"
                record = dict(item, ext=ext, id=os.urandom(8).hex())
                fd, tmp = tempfile.mkstemp(dir=self.out_dir)
                try:
                    with os.fdopen(fd, "wb") as handle:
                        copy_bytes(source, handle.write, record["size"])
                    os.replace(tmp, self._path(record))
                finally:
                    Path(tmp).unlink(missing_ok=True)
                received.append(record)
        except BaseException:
            for record in received:
                self._path(record).unlink(missing_ok=True)
            raise
        self.records.extend(received)
        names = ", ".join(record["name"] for record in received) or "без файлов"
        return "Обработка завершена. Результаты: %s.\n%s" % (names, frame.get("stdout") or "")

    def _path(self, record):
        return self.out_dir / ("%s.%s" % (record["id"], record["ext"]))

    def discard_outputs(self):
        for record in self.records:
            self._path(record).unlink(missing_ok=True)
        self.records.clear()
