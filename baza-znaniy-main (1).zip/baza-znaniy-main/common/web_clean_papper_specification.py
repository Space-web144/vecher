"""Bounded, private web adapter for native VentSpec. No AI or network calls."""
from __future__ import annotations

import argparse
import base64
import json
from pathlib import Path
import re
import signal
import sys
import tempfile

from clean_papper_pipeline import (PipelineError, digest, native_worker, prepare,
                                   read_json, validate_selection)

MAX_WEB_PAGES = 120
MAX_DOWNLOAD_BYTES = 5 * 1024 * 1024


class OutputLimit(PipelineError):
    pass


def package_downloads(files):
    total = sum(path.stat().st_size for path, _, _, _ in files)
    if total <= 0 or total > MAX_DOWNLOAD_BYTES:
        raise OutputLimit('Download limit')
    return [{'filename': name, 'label': label, 'mime': mime,
             'base64': base64.b64encode(path.read_bytes()).decode('ascii')}
            for path, name, label, mime in files]


def process(pdf, first, last, sha, action):
    if (type(first) is not int or type(last) is not int or
            not 1 <= first <= last <= 600 or last - first + 1 > MAX_WEB_PAGES or
            not re.fullmatch(r'[a-f0-9]{64}', sha) or action not in ('extract', 'convert')):
        raise PipelineError('Invalid specification request')
    if not pdf.is_file() or not 10 <= pdf.stat().st_size <= 100 * 1024 * 1024 or digest(pdf) != sha:
        raise PipelineError('Source changed or invalid')
    with tempfile.TemporaryDirectory(prefix='cp-spec-') as workspace:
        stage = prepare(pdf, workspace, [first, last])
        selection = validate_selection(stage)
        if selection['source_pdf_sha256'] != sha:
            raise PipelineError('Source changed')
        result = {'ok': True, 'source_pdf_sha256': sha, 'first': first, 'last': last,
                  'quantity_scope': 'design_specification_only_not_measured'}
        if action == 'extract':
            result.update(status='extracted', downloads=package_downloads([
                (stage / 'specification.pdf', 'clean-papper-specification.pdf', 'Скачать выделенный PDF', 'application/pdf'),
                (stage / 'selection.json', 'clean-papper-specification-pages.json', 'Скачать карту страниц JSON', 'application/json')]))
        else:
            # Same bounded process: no child left running after timeout.
            native_worker(stage / 'specification.pdf', stage, selection)
            protocol = read_json(stage / 'verification.json')
            rows = read_json(stage / 'specification_rows.json')
            count = protocol['protocol']['positions_parsed']
            if (protocol['protocol'].get('ok') is not True or type(count) is not int or count <= 0 or
                    rows.get('row_count') != len(rows.get('rows', [])) or not rows['rows'] or
                    protocol.get('specification_sha256') != selection['specification_sha256'] or
                    rows.get('specification_sha256') != selection['specification_sha256']):
                raise PipelineError('Verification not passed')
            result.update(status='verified_native', row_count=rows['row_count'], positions_with_quantity=count,
                          downloads=package_downloads([
                (stage / 'specification.xlsx', 'clean-papper-design-specification.xlsx', 'Скачать проектную спецификацию Excel', 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'),
                (stage / 'specification_rows.json', 'clean-papper-specification-rows.json', 'Скачать строки и источники JSON', 'application/json'),
                (stage / 'verification.json', 'clean-papper-specification-verification.json', 'Скачать протокол проверки JSON', 'application/json')]))
        return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--file', required=True, type=Path)
    parser.add_argument('--first', required=True, type=int)
    parser.add_argument('--last', required=True, type=int)
    parser.add_argument('--sha', required=True)
    parser.add_argument('--action', required=True, choices=('extract', 'convert'))
    args = parser.parse_args(argv)
    def terminate(_signal, _frame):
        raise SystemExit(143)
    signal.signal(signal.SIGTERM, terminate)
    try:
        result = process(args.file, args.first, args.last, args.sha, args.action)
    except OutputLimit:
        result = {'ok': False, 'code': 'specification_output_limit',
                  'message': 'Файлы превышают лимит выгрузки. Выберите меньший диапазон.'}
    except (PipelineError, ValueError, OSError, ImportError, RuntimeError, KeyError, TypeError):
        result = {'ok': False, 'code': 'specification_review_required' if args.action == 'convert' else 'specification_input_error',
                  'message': ('VentSpec не прошёл проверку чтения. Excel не сформирован; скачайте PDF диапазона для отдельной проверки.'
                              if args.action == 'convert' else 'Не удалось выделить страницы. Проверьте диапазон и исходный PDF.')}
    print(json.dumps(result, ensure_ascii=False, allow_nan=False, separators=(',', ':')))
    return 0 if result['ok'] else 1


if __name__ == '__main__':
    sys.exit(main())
