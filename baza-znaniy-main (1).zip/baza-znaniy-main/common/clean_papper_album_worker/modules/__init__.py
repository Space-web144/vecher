"""Clean Papper album worker copied from the pinned CleanPapper revision."""
