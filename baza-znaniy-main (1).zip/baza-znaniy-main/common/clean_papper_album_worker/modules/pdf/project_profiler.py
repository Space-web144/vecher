"""Bounded, evidence-first project compatibility profile; never approves quantities."""
from collections import Counter
import math
import re

MAX_SAMPLES = 6
MAX_STYLE_PATHS = 12000
SCALE = re.compile(r'(?<!\d)1\s*:\s*([1-9]\d{0,3})(?![\d.,])')
EXPLICIT_SCALE = re.compile(r'(?:масштаб|scale)\s*[:.=]?\s*1\s*:\s*([1-9]\d{0,3})(?![\d.,])', re.I)


def representative_pages(pages):
    """Sample across observed page kinds, not fixed page numbers or a project name."""
    buckets = {kind: [row['pdf_page'] for row in pages if row['kind'] == kind]
               for kind in ('plan', 'axonometry', 'mixed', 'unclassified', 'other')}
    selected = []
    for kind in buckets:
        if buckets[kind]:
            group = buckets[kind]
            selected.append(group[len(group) // 2])
    # Second plan where available; expose exact sampling coverage.
    for kind in ('plan', 'axonometry', 'mixed', 'unclassified', 'other'):
        for number in (buckets[kind][:1] + buckets[kind][-1:]):
            if len(selected) >= MAX_SAMPLES:
                break
            if number not in selected:
                selected.append(number)
    return sorted(selected)


def color_family(color):
    if not isinstance(color, (list, tuple)) or len(color) != 3:
        return 'unknown'
    if not all(isinstance(v, (int, float)) and math.isfinite(v) and 0 <= v <= 1 for v in color):
        return 'unknown'
    if max(color) - min(color) < .12:
        return 'neutral'
    return 'chromatic'


def sample_page(page, row):
    # BBox log counts painted vector paths and raster images, not duct objects.
    counts = Counter(item[0] for item in page.get_bboxlog())
    vector_count = counts['stroke-path'] + counts['fill-path']
    image_count = counts['fill-image']
    has_text = row['has_extracted_text']
    if vector_count:
        representation = 'mixed_vector_image' if image_count else 'vector'
    elif image_count:
        representation = 'image_with_text' if has_text else 'image_without_text'
    else:
        representation = 'text_only' if has_text else 'empty_or_other'
    color_counts = Counter()
    weights = Counter()
    style_status = 'not_applicable'
    if vector_count > MAX_STYLE_PATHS:
        style_status = 'complex_page_not_inspected'
    elif vector_count:
        paths = page.get_drawings()
        if len(paths) > MAX_STYLE_PATHS:
            style_status = 'complex_page_not_inspected'
        else:
            style_status = 'inspected'
            for path in paths:
                if path.get('color') is None:
                    continue
                color_counts[color_family(path['color'])] += 1
                width = path.get('width')
                if isinstance(width, (int, float)) and math.isfinite(width) and width >= 0:
                    weights[round(width, 3)] += 1
    scales = []
    # Only explicitly labelled scale is a candidate; never interpret a schematic
    # or arbitrary aspect ratio as a calibrated measurement.
    for line in page.get_text('text').splitlines():
        for match in EXPLICIT_SCALE.finditer(line):
            scales.append(int(match[1]))
    return {'pdf_page': row['pdf_page'], 'kind': row['kind'],
            'representation': representation, 'painted_vector_paths': vector_count,
            'painted_images': image_count, 'style_status': style_status,
            'stroke_color_counts': dict(color_counts),
            'common_line_weights_pt': [{'width_pt': w, 'count': n} for w, n in weights.most_common(8)],
            'printed_scale_candidates': sorted(set(scales)), 'scale_verified': False}


def build_project_profile(document, pages, register, specification, source_sha256):
    """Report suitability and unresolved evidence; do not change measurement settings."""
    formats = Counter()
    for row in pages:
        x0, y0, x1, y1 = row['page_bounds_pt']
        formats[(round(abs(x1 - x0) * 25.4 / 72), round(abs(y1 - y0) * 25.4 / 72))] += 1
    by_number = {row['pdf_page']: row for row in pages}
    samples = []
    for number in representative_pages(pages):
        try:
            samples.append(sample_page(document[number-1], by_number[number]))
        except (ValueError, RuntimeError, TypeError, OverflowError):
            samples.append({'pdf_page': number, 'kind': by_number[number]['kind'],
                            'representation': 'unknown', 'style_status': 'inspection_failed',
                            'printed_scale_candidates': [], 'scale_verified': False,
                            'stroke_color_counts': {}})
    types = Counter(row['representation'] for row in samples)
    colors = Counter()
    for row in samples:
        colors.update(row['stroke_color_counts'])
    drawing_samples = [row for row in samples if row['kind'] in ('plan', 'axonometry', 'mixed')]
    drawing_colors = Counter()
    for row in drawing_samples:
        drawing_colors.update(row['stroke_color_counts'])
    warnings = []
    if not drawing_samples:
        warnings.append('ventilation_sheets_not_identified')
    if types['image_without_text'] or types['image_with_text']:
        warnings.append('raster_content_requires_review')
    if any(row['style_status'] in ('complex_page_not_inspected', 'inspection_failed') for row in samples):
        warnings.append('style_sampling_incomplete')
    if drawing_colors['neutral'] and not drawing_colors['chromatic']:
        warnings.append('neutral_strokes_only_in_inspected_drawings')
    if not drawing_colors['chromatic'] and not drawing_colors['neutral']:
        warnings.append('drawing_stroke_style_unknown')
    if register.get('status') != 'verified_register':
        warnings.append('drawing_register_not_verified')
    if len(specification.get('candidates', [])) != 1:
        warnings.append('specification_range_requires_review')
    return {'schema': 'clean-papper.project-profile.v1', 'source_pdf_sha256': source_sha256,
            'page_count': len(pages), 'pages_with_text': sum(bool(row['has_extracted_text']) for row in pages),
            'page_formats_mm': [{'width_mm': w, 'height_mm': h, 'count': n} for (w,h),n in formats.most_common()],
            'sampling': {'method': 'stratified_by_detected_sheet_kind', 'sample_limit': MAX_SAMPLES,
                         'style_path_limit_per_page': MAX_STYLE_PATHS, 'pages': samples,
                         'representation_counts': dict(types), 'all_sample_stroke_colors': dict(colors),
                         'drawing_sample_stroke_colors': dict(drawing_colors)},
            'compatibility_warnings': warnings,
            'measurement_profile': {'scale_verified': False, 'system_color_mapping': None,
                                    'floor_multiplicity': None, 'geometry_tolerances': None,
                                    'automatic_takeoff_ready': False},
            'scope': 'diagnostic_samples_only_not_duct_recognition'}