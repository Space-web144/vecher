"""Extract documentary allowance candidates, never change measured or design quantities.

Only inspect detected specification ranges. A row note is not a project-wide
rule; even a general note requires scope review before it could be applied.
"""
from __future__ import annotations

from collections import defaultdict
import math
import re

MAX_EVIDENCE = 1000
MAX_BLOCK_CHARS = 1200
NUMBER = r'(\d{1,3}(?:[.,]\d{1,3})?)'
RESERVE = re.compile(r'\bзапас\w*\b', re.I)
FITTINGS = re.compile(
    r'металл\s+на\s+фасонн\w*\s+издели\w*\s+воздуховод\w*\s+учт[её]н\w*\s+в\s+длин{1,2}[еыу]\s+воздуховод\w*\s+(?:с\s+)?запас\w*\s*' + NUMBER + r'\s*%', re.I)
INSULATION = re.compile(r'(?:по\s+)?материал\w*\s+изоляци\w*\s+(труб\w*|воздуховод\w*)\s+' + NUMBER + r'\s*%', re.I)
ROW = re.compile(r'\bс\s+запасом\s+' + NUMBER + r'(?![\d.,%])\s*к\s*(.*)', re.I)
BASES = (
    ('straight_and_bent_length', re.compile(r'^длин[еы]\s+прямых\s+и\s+гнутых\s+участков\b', re.I)),
    ('straight_and_fittings_area', re.compile(r'^площад[ьи]\s+прямых\s+участков\s+и\s+(?:фитингов|фасонных\s+изделий)\b', re.I)),
    ('straight_length', re.compile(r'^длин[еы]\s+прямых\s+участков\b', re.I)),
)


def _number(raw):
    return float(raw.replace(',', '.'))


def block_rules(raw):
    """Interpret only explicit allowance language, keeping uncertain bases unknown."""
    line = ' '.join(raw.split())
    if not RESERVE.search(line) or len(line) > MAX_BLOCK_CHARS:
        return []
    matches = []
    for match in FITTINGS.finditer(line):
        matches.append(('general_note_candidate', 'fittings_included_in_duct_length', 'percent', _number(match[1])))
    # Require allowance context, not just an insulation product description with a percent.
    if matches or re.search(r'запас\w*\s+(?:по\s+)?материал\w*\s+изоляци', line, re.I):
        for match in INSULATION.finditer(line):
            scope = 'pipe_insulation' if match[1].casefold().startswith('труб') else 'duct_insulation'
            matches.append(('general_note_candidate', scope, 'percent', _number(match[2])))
    for match in ROW.finditer(line):
        basis = next((name for name, regex in BASES if regex.match(match[2])), 'unresolved_row_basis')
        matches.append(('row_note_candidate', basis, 'factor', _number(match[1])))
    return [dict(scope=scope, basis=basis, value_kind=kind, value=value,
                 approved=False, applied=False) for scope, basis, kind, value in matches
            if math.isfinite(value) and ((kind == 'percent' and 0 <= value <= 100) or (kind == 'factor' and 1 <= value <= 10))]


def _complete_row_note(block, blocks):
    """Join only uniquely aligned adjacent native blocks forming a known basis.

    Do not join arbitrary notes, cross columns, or infer a missing word.
    Each fragment remains independently traceable.
    """
    fragments = [block]
    raw = block[4]
    row = ROW.search(' '.join(raw.split()))
    if not row or any(regex.match(row[2]) for _, regex in BASES):
        return fragments
    # Only the narrow incomplete prefix of a known row note is eligible.
    possible = ('длине прямых участков', 'длине прямых и гнутых участков',
                'площади прямых участков и фитингов', 'площади прямых участков и фасонных изделий')
    prefix = row[2].casefold().strip()
    if not any(value.startswith(prefix) for value in possible):
        return fragments
    first = block
    height = first[3] - first[1]
    if not 3 <= height <= 30:
        return fragments
    center = (first[0] + first[2]) / 2
    for _ in range(3):
        previous = fragments[-1]
        eligible = []
        for candidate in blocks:
            if candidate in fragments or candidate[6] != 0:
                continue
            gap = candidate[1] - previous[3]
            h = candidate[3] - candidate[1]
            if not (-.15 * height <= gap <= .65 * height and .7 * height <= h <= 1.3 * height
                    and abs((candidate[0] + candidate[2]) / 2 - center) <= min(3, height * .25)):
                continue
            # A second aligned block is ambiguity, even if only one is useful.
            eligible.append(candidate)
        if len(eligible) != 1:
            return [block]
        nxt = eligible[0]
        prefix = (prefix + ' ' + ' '.join(nxt[4].split()).casefold()).strip()
        if not any(value.startswith(prefix) for value in possible):
            return [block]
        fragments.append(nxt)
        if prefix in possible:
            return fragments
    return [block]


def inspect_project_rules(document, inventory, source_sha256):
    """Read native PDF text blocks, preserve evidence, never infer row identity.

    The range detector is a candidate only. No scanning of equipment passports,
    no OCR, no numeric fallback, no automatic addition or subtraction.
    """
    pages = set()
    for run in inventory.get('candidates', []):
        first, last = run.get('first'), run.get('last')
        if type(first) is int and type(last) is int and 1 <= first <= last <= len(document):
            pages.update(range(first, last + 1))
    evidence, unresolved, groups = [], [], defaultdict(lambda: {'count': 0, 'pages': set()})
    observed_blocks = 0
    incomplete = 0
    fittings_present = False
    reconstructed_count = 0
    for number in sorted(pages):
        blocks = document[number - 1].get_text('blocks')
        for block in blocks:
            if len(block) < 7 or block[6] != 0 or not RESERVE.search(block[4]):
                continue
            observed_blocks += 1
            fragments = _complete_row_note(block, blocks)
            reconstructed_count += len(fragments) > 1
            raw = '\n'.join(fragment[4] for fragment in fragments) if len(fragments) > 1 else block[4]
            coords = [round(float(v), 2) for v in (min(f[0] for f in fragments), min(f[1] for f in fragments), max(f[2] for f in fragments), max(f[3] for f in fragments))]
            if not all(math.isfinite(v) for v in coords):
                incomplete += 1
                continue
            rules = block_rules(raw)
            source = {'pdf_page': number, 'bbox_pt': coords, 'raw_text': raw[:MAX_BLOCK_CHARS],
                      'text_truncated': len(raw) > MAX_BLOCK_CHARS,
                      'method': 'aligned_adjacent_text_blocks' if len(fragments) > 1 else 'native_text_block',
                      'fragments': [{'bbox_pt': [round(float(v), 2) for v in fragment[:4]], 'raw_text': fragment[4][:MAX_BLOCK_CHARS]} for fragment in fragments]}
            if not rules or any(row['basis'] == 'unresolved_row_basis' for row in rules):
                incomplete += 1
                if len(unresolved) < MAX_EVIDENCE:
                    unresolved.append(source)
            for rule in rules:
                key = (rule['scope'], rule['basis'], rule['value_kind'], rule['value'])
                groups[key]['count'] += 1
                groups[key]['pages'].add(number)
                fittings_present |= rule['basis'] == 'fittings_included_in_duct_length'
                if len(evidence) < MAX_EVIDENCE:
                    evidence.append({**rule, 'source': source})
    summaries = [{'scope': key[0], 'basis': key[1], 'value_kind': key[2], 'value': key[3],
                  'occurrence_count': group['count'], 'pdf_pages': sorted(group['pages']),
                  'approved': False, 'applied': False}
                 for key, group in sorted(groups.items())]
    total = sum(row['occurrence_count'] for row in summaries)
    return {'source_pdf_sha256': source_sha256, 'status': 'review_required' if observed_blocks else ('no_supported_notes_found' if pages else 'no_specification_range'),
            'scope': 'specification_range_candidates_only', 'inspected_pdf_pages': sorted(pages),
            'allowance_block_count': observed_blocks, 'rule_occurrence_count': total,
            'unresolved_block_count': incomplete, 'reconstructed_note_count': reconstructed_count, 'summaries': summaries, 'evidence': evidence,
            'unresolved_evidence': unresolved, 'evidence_truncated': total > len(evidence) or incomplete > len(unresolved),
            'double_count_risk': fittings_present, 'automatic_application': False,
            'limitations': ['No automatic project-wide scope or row identity assigned',
                            'No OCR; only uniquely aligned continuations of known note language are joined',
                            'Never add allowances to quantities already including them']}