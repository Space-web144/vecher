"""Extract traceable elevation/section text from an explicitly selected PDF scheme region.

No inferred duct lengths. An elevation-mark range is NOT a vertical centerline.
Inputs: 1-based PDF page, region rectangle in PDF points, optional system identifier.
"""
from __future__ import annotations
import argparse
import json
import math
import re
from pathlib import Path

ELEVATION = re.compile(r'(?<!\w)([+−-])\s*(\d{1,3})[.,](\d{3})(?!\d)')
SECTION = re.compile(r'(?<!\d)(\d{2,4})\s*[xх×]\s*(\d{2,4})(?!\d)', re.I)


def parse_level(token):
    match = ELEVATION.search(token)
    if not match:
        return None
    sign = -1 if match.group(1) in ('-', '−') else 1
    return sign * (int(match.group(2)) + int(match.group(3)) / 1000.0)


def collect_observations(words):
    """Extract elevation and section evidence from PyMuPDF word coordinates."""
    heights, sections = [], []
    for word in words:
        x0, y0, x1, y1, token = word[:5]
        box = [round(v, 2) for v in (x0, y0, x1, y1)]
        level = parse_level(token)
        if level is not None:
            heights.append({'raw': token, 'level_m': level, 'bbox_pt': box,
                            'evidence': 'explicit_signed_3_decimal_level'})
        for match in SECTION.finditer(token):
            code = token.upper()
            if 'КПВ' in code or 'BLE-' in code or 'РПП' in code:
                context = 'product_name_or_terminal_not_duct_section'
            elif token.strip() == match.group(0):
                context = 'standalone_section_label_candidate'
            else:
                context = 'embedded_section_candidate_review'
            sections.append({'raw': match.group(0), 'width_mm': int(match.group(1)),
                             'height_mm': int(match.group(2)), 'bbox_pt': box, 'context': context})
    heights.sort(key=lambda k: k['bbox_pt'][1])
    sections.sort(key=lambda k: k['bbox_pt'][1])
    return heights, sections


def parse_evidence(pdf_path, page_number, bounds_pt, system=None):
    import fitz
    if len(bounds_pt) != 4 or not all(math.isfinite(float(v)) for v in bounds_pt):
        raise ValueError('Region must have four finite PDF coordinates')
    with fitz.open(str(pdf_path)) as doc:
        if not 1 <= page_number <= len(doc):
            raise ValueError('PDF page outside document')
        page = doc[page_number - 1]
        rect = fitz.Rect(*[float(v) for v in bounds_pt])
        if rect.is_empty or not page.rect.contains(rect):
            raise ValueError('Region is empty or outside the PDF page')
        words = sorted(page.get_text('words', clip=rect), key=lambda w: (round(w[1], 1), w[0]))
        heights, sections = collect_observations(words)
        values = [h['level_m'] for h in heights]
        span = round(max(values) - min(values), 6) if len(values)>=2 else None
        return {'pdf_page':page_number,'scheme':system,
                'region_pt':[round(float(x),2) for x in bounds_pt],
                'elevation_marks':heights,'section_tokens':sections,
                'summary':{'elevation_mark_count':len(heights),
                           'isolated_section_candidates':sum(x['context']=='standalone_section_label_candidate'
                                                             for x in sections),
                           'range_of_elevation_marks_m':span,
                           'verified_vertical_duct_length_m':None,
                           'status':'mark_observations_only'},
                'limitations':['Scheme region manually chosen; no autonomous diagram segmentation',
                               'Difference between elevation marks is not duct centerline length',
                               'Sections in product codes and valves are not assigned as duct sections',
                               'No connections to 2D DXF objects asserted']}


def main():
    p=argparse.ArgumentParser(description='Read signed PDF elevation marks from one manual scheme region')
    p.add_argument('pdf')
    p.add_argument('--page',type=int,required=True)
    p.add_argument('--box',type=float,nargs=4,required=True,metavar=('X0','Y0','X1','Y1'))
    p.add_argument('--system')
    p.add_argument('--output')
    a=p.parse_args()
    payload=json.dumps(parse_evidence(a.pdf,a.page,a.box,a.system),ensure_ascii=False,indent=2)
    if a.output:Path(a.output).write_text(payload,encoding='utf-8')
    else:print(payload)

if __name__=='__main__':main()
