"""Read a complete project PDF and calculate its reviewed plan and axonometric runs."""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
import hashlib
import json
import math
from pathlib import Path
import re
import sys

from modules.calc.confirmed_quantities import straight_duct_surface, vertical_length_from_levels
from modules.pdf.drawing_register import extract_drawing_register, normalized_system, system_codes
from modules.pdf.project_profiler import build_project_profile
from modules.pdf.schematic_evidence import collect_observations
from modules.pdf.text_recovery import recover_words
from modules.pdf.project_rules import inspect_project_rules

MAX_BYTES = 100 * 1024 * 1024
MAX_PAGES = 600
MAX_REVIEW_BYTES = 96 * 1024
PAGE_KINDS = {'plan', 'axonometry', 'mixed', 'other'}
PLAN_TITLE = re.compile(r'^(?:план(?:ы)?\s+(?:[\w.,+−–()/-]+\s+)*вентиляц\w*|'
                        r'вентиляция[ .–-]+план\b|ventilation\s+plan\b)', re.I)
SCHEME_TITLE = re.compile(r'^(?:аксонометр\w*(?:\s+схем\w*)?|схем[аы]\s+'
                          r'(?:систем\w*|вентиляц\w*|(?:ДП|ДВ|П|В)\s*\d)|'
                          r'axonometric\s+(?:scheme|diagram))', re.I)
CONTENTS_TITLE = re.compile(r'^(?:ведомость рабочих чертежей основного комплекта|'
                            r'лист регистрации изменений|table of contents)\s*[.:]?$', re.I)


class AlbumInputError(ValueError):
    """An invalid PDF or review with a message safe to show in the web form."""


def _system(value):
    return normalized_system(value)


def _titles(words):
    grouped = defaultdict(list)
    for word in words:
        grouped[tuple(word[5:7])].append(word)
    matches = []
    for line in grouped.values():
        text = ' '.join(w[4] for w in sorted(line, key=lambda w: w[7]))
        if len(text) > 140:
            continue
        if CONTENTS_TITLE.fullmatch(text):
            kind = 'contents'
        elif PLAN_TITLE.match(text):
            kind = 'plan'
        elif SCHEME_TITLE.match(text):
            kind = 'axonometry'
        else:
            continue
        bbox = [min(w[0] for w in line), min(w[1] for w in line),
                max(w[2] for w in line), max(w[3] for w in line)]
        matches.append({'text': text, 'bbox_pt': [round(v, 2) for v in bbox], 'kind': kind})
    return matches


def _indexed_observations(observations, prefix, page):
    distinct = {(tuple(row['bbox_pt']), row['raw']): row for row in observations}
    return [{'id': f'{prefix}{page:03d}-{index:03d}', **distinct[key]}
            for index, key in enumerate(sorted(distinct, key=lambda k: (k[0][1], k[0][0], k)), 1)]


def _scan_page(page, number, override, register_entry=None):
    raw_words = page.get_text('words', sort=False)
    words, text_recovery = recover_words(raw_words)
    titles = _titles(words)
    kinds = {title['kind'] for title in titles}
    if override:
        kind = override
    elif 'contents' in kinds:
        kind = 'other'
    elif kinds == {'plan', 'axonometry'}:
        kind = 'mixed'
    else:
        kind = next(iter(kinds), 'unclassified')
    via_register = False
    if (not override and kind == 'unclassified' and register_entry and
            register_entry['title_verified_on_sheet']):
        kind = 'other' if register_entry['kind'].startswith('conditioning_') else register_entry['kind']
        via_register = True
        # The source bbox belongs to the register page, not to this sheet.
        titles.append({'text': register_entry['title'], 'bbox_pt': [],
                       'kind': kind, 'source': 'drawing_register',
                       'source_pdf_page': register_entry['source']['pdf_page']})
    heights, sections = collect_observations(words) if kind in PAGE_KINDS - {'other'} else ([], [])
    return {
        'pdf_page': number, 'kind': kind,
        'classification_source': 'review' if override else
                                 'drawing_register_crosschecked' if via_register else 'printed_titles',
        'has_extracted_text': bool(raw_words), 'rotation': page.rotation,
        'extracted_word_count': len(raw_words),
        'text_recovery': text_recovery,
        'page_bounds_pt': list(page.rect * page.derotation_matrix),
        'title_evidence': titles,
        'system_hints': sorted({code for title in titles if title['kind'] == 'axonometry'
                                for code in system_codes(title['text'])} |
                               (set(register_entry['systems_in_title']) if register_entry and
                                register_entry['title_verified_on_sheet'] and
                                not override and kind in ('axonometry', 'mixed') else set()))
                        if kind in ('axonometry', 'mixed') else [],
        'drawing_register_entry': {
            'sheet_number': register_entry['sheet_number'],
            'pdf_page': register_entry['pdf_page'],
            'source_pdf_page': register_entry['source']['pdf_page'],
            'title_verified_on_sheet': register_entry['title_verified_on_sheet']
        } if register_entry else None,
        'elevation_marks': _indexed_observations(heights, 'M', number) if kind in ('axonometry', 'mixed') else [],
        'section_marks': _indexed_observations(sections, 'S', number),
    }


def _review_page_kinds(review, count):
    values = review.get('page_kinds', {})
    if not isinstance(values, dict) or any(not isinstance(k, str) or
        not re.fullmatch(r'[1-9][0-9]{0,2}', k) or int(k) > count or
        not isinstance(v, str) or v not in PAGE_KINDS for k, v in values.items()):
        raise AlbumInputError('Разметка содержит недопустимый номер или тип страницы.')
    return {int(k): v for k, v in values.items()}


def _page_number(value):
    return value if type(value) is int else None


def _plan_location(segment, pages):
    page = pages.get(_page_number(segment.get('plan_page')))
    box = segment.get('plan_bbox_pt')
    if not page or page['kind'] not in ('plan', 'mixed') or not isinstance(box, list) or len(box) != 4:
        return None
    if not all(type(v) in (int, float) and math.isfinite(v) for v in box):
        return None
    x0, y0, x1, y1 = box
    left, top, right, bottom = page['page_bounds_pt']
    if not (left <= x0 < x1 <= right and top <= y0 < y1 <= bottom):
        return None
    return {'pdf_page': page['pdf_page'], 'bbox_pt': box}


def _segment_rows(segments, pages):
    if not isinstance(segments, list) or any(not isinstance(row, dict) for row in segments):
        raise AlbumInputError('Разметка должна содержать список участков segments.')
    ids = [row.get('segment_id') for row in segments]
    if any(not isinstance(key, str) or not key or key != key.strip() or len(key) > 100 for key in ids):
        raise AlbumInputError('Каждому участку нужен непустой постоянный ID.')
    if len(ids) != len(set(ids)):
        raise AlbumInputError('ID участков повторяются. Используйте один ID на физический участок.')
    if any(row.get('kind') not in ('plan', 'vertical') for row in segments):
        raise AlbumInputError('Тип участка должен быть plan или vertical.')

    elevations = {mark['id']: {'pdf_page': page['pdf_page'], **mark}
                  for page in pages.values() for mark in page['elevation_marks']}
    sections = {mark['id']: {'pdf_page': page['pdf_page'], **mark}
                for page in pages.values() for mark in page['section_marks']}
    endpoint_pairs = Counter(
        frozenset((row['start_mark_id'], row['end_mark_id'])) for row in segments
        if row['kind'] == 'vertical' and all(isinstance(row.get(k), str) for k in ('start_mark_id', 'end_mark_id'))
    )
    plan_regions = Counter(
        (location['pdf_page'], tuple(location['bbox_pt'])) for row in segments
        if (location := _plan_location(row, pages))
    )
    results = []
    for row in segments:
        system = _system(row.get('system'))
        plan = _plan_location(row, pages)
        kind = row['kind']
        reasons = []
        if not system or row.get('system_approved') is not True:
            reasons.append('system_not_confirmed')
        if row.get('scope_approved') is not True:
            reasons.append('physical_run_not_confirmed_in_project_scope')
        if plan is None:
            reasons.append('missing_plan_location')
        elif plan_regions[plan['pdf_page'], tuple(plan['bbox_pt'])] > 1:
            reasons.append('plan_location_reused')

        sources = [plan] if plan else []
        length = None
        if kind == 'plan':
            candidate = row.get('length_m')
            if (row.get('length_approved') is True and type(candidate) in (int, float) and
                    math.isfinite(candidate) and candidate > 0):
                length = candidate
            else:
                reasons.append('plan_length_not_confirmed')
        else:
            page = _page_number(row.get('axonometry_page'))
            mark_ids = [row.get('start_mark_id'), row.get('end_mark_id')]
            marks = [elevations.get(key) if isinstance(key, str) else None for key in mark_ids]
            if not all(m and m['pdf_page'] == page for m in marks) or mark_ids[0] == mark_ids[1]:
                reasons.append('axonometry_end_marks_missing_or_on_different_sheets')
            else:
                sources.extend(marks)
                if endpoint_pairs[frozenset(mark_ids)] > 1:
                    reasons.append('axonometry_mark_pair_reused')
                hints = pages[page]['system_hints']
                if hints and system not in hints:
                    reasons.append('system_conflicts_with_axonometry_title')
                vertical = vertical_length_from_levels(
                    *(m['level_m'] for m in marks), same_datum=row.get('same_datum') is True,
                    same_straight_axis=row.get('same_straight_axis') is True,
                    marks_define_centerline_ends=row.get('marks_define_centerline_ends') is True,
                    source_mark_ids=mark_ids)
                length = vertical['verified_straight_vertical_length_m']
                reasons.extend(vertical['reasons'])

        length = length if not reasons else None
        section_key = row.get('section_mark_id')
        section = sections.get(section_key) if isinstance(section_key, str) else None
        section_approved = (row.get('section_approved') is True and section is not None and
                            any(section['pdf_page'] == source['pdf_page'] for source in sources) and
                            section['context'] == 'standalone_section_label_candidate')
        area = straight_duct_surface({
            'element_id': row['segment_id'], 'system': system, 'length_m': length,
            'width_mm': section['width_mm'] if section_approved else None,
            'height_mm': section['height_mm'] if section_approved else None,
            'source_id': section['id'] if section_approved else None,
            'length_approved': length is not None, 'system_approved': row.get('system_approved') is True,
            'scope_approved': row.get('scope_approved') is True, 'width_approved': section_approved,
            'height_approved': section_approved,
        })
        results.append({'segment_id': row['segment_id'], 'kind': kind, 'system': system or None,
                        'length_m': length, 'status': 'approved' if length is not None else 'review_required',
                        'sources': sources, 'reasons': reasons,
                        'section_source': section if section_approved else None,
                        'rectangular_surface_m2': area['surface_m2']})
    return results


def _totals(segments):
    def total(values):
        values = [value for value in values if value is not None]
        return round(math.fsum(values), 6) if values else None

    return {
        'approved_plan_length_m': total(row['length_m'] for row in segments if row['kind'] == 'plan'),
        'approved_vertical_length_m': total(row['length_m'] for row in segments if row['kind'] == 'vertical'),
        'approved_length_m': total(row['length_m'] for row in segments),
        'approved_rectangular_surface_m2': total(row['rectangular_surface_m2'] for row in segments),
        'review_required_segments': sum(row['status'] == 'review_required' for row in segments),
    }


def analyze_album(pdf_path, review=None):
    import fitz

    path = Path(pdf_path)
    if not path.is_file() or not 10 <= path.stat().st_size <= MAX_BYTES:
        raise AlbumInputError('Выберите PDF-альбом размером до 100 МиБ.')
    with path.open('rb') as source:
        if source.read(5) != b'%PDF-':
            raise AlbumInputError('Файл не распознан как PDF.')
        source.seek(0)
        digest = hashlib.file_digest(source, 'sha256').hexdigest()
    if review is not None and (not isinstance(review, dict) or review.get('source_pdf_sha256') != digest):
        raise AlbumInputError('Разметка относится к другой версии PDF-альбома.')
    review = review if review is not None else {}
    try:
        with fitz.open(path) as document:
            if document.is_encrypted or not 1 <= document.page_count <= MAX_PAGES:
                raise AlbumInputError('Нужен PDF без пароля, от 1 до 600 страниц.')
            overrides = _review_page_kinds(review, len(document))
            # Same range detection as the local pipeline; no measured quantities.
            root = str(Path(__file__).resolve().parents[4])
            if root not in sys.path:
                sys.path.insert(0, root)
            from common.clean_papper_pipeline import inspect_specification
            specification_inventory = inspect_specification(document)
            project_rules = inspect_project_rules(document, specification_inventory, digest)
            drawing_register = extract_drawing_register(document)
            registered = {row['pdf_page']: row for row in drawing_register['entries']} if (
                drawing_register['status'] == 'verified_register') else {}
            pages = [_scan_page(page, number, overrides.get(number), registered.get(number))
                     for number, page in enumerate(document, 1)]
            project_profile = build_project_profile(document, pages, drawing_register, specification_inventory, digest)
            project_profile['text_recovery_summary'] = {
                'recovered_pages': [row['pdf_page'] for row in pages if row['text_recovery']['changed_word_count']],
                'changed_word_count': sum(row['text_recovery']['changed_word_count'] for row in pages),
                'pages_without_text': [row['pdf_page'] for row in pages if not row['has_extracted_text']],
                'pages_with_few_words': [row['pdf_page'] for row in pages if 0 < row['extracted_word_count'] <= 20],
                'ocr_performed': False,
            }
    except fitz.FileDataError as exc:
        raise AlbumInputError('Не удалось разобрать PDF-альбом.') from exc

    segments = _segment_rows(review.get('segments', []), {page['pdf_page']: page for page in pages})
    systems = defaultdict(list)
    for row in segments:
        if row['system']:
            systems[row['system']].append(row)
    return {
        'ok': True, 'mode': 'album', 'source_pdf_sha256': digest,
        'coordinate_space': 'unrotated_pdf_points', 'page_count': len(pages),
        'page_kind_counts': dict(Counter(page['kind'] for page in pages)), 'pages': pages,
        'drawing_register': drawing_register,
        'specification_inventory': specification_inventory,
        'project_profile': project_profile,
        'project_rules': project_rules,
        'system_codes_from_register': sorted({code for row in drawing_register['entries']
                                              if row['title_verified_on_sheet']
                                              for code in row['systems_in_title']}),
        'calculation': {'scope': 'approved_segments_only', 'totals': _totals(segments),
                        'systems': {code: _totals(rows) for code, rows in sorted(systems.items())},
                        'segments': segments},
        'review_template': {'source_pdf_sha256': digest, 'page_kinds': {}, 'segments': []},
    }


def main(argv=None):
    parser = argparse.ArgumentParser(description='Process all pages of a ventilation project PDF')
    parser.add_argument('--file', required=True, type=Path)
    parser.add_argument('--review', type=Path, help='Review JSON with references to this PDF')
    parser.add_argument('--review-stdin', action='store_true', help='Read review JSON from standard input')
    args = parser.parse_args(argv)
    if args.review and args.review_stdin:
        parser.error('use only one review input')
    try:
        raw = None
        if args.review:
            with args.review.open('rb') as handle:
                raw = handle.read(MAX_REVIEW_BYTES + 1)
        elif args.review_stdin:
            raw = sys.stdin.buffer.read(MAX_REVIEW_BYTES + 1)
        if raw is not None and len(raw) > MAX_REVIEW_BYTES:
            raise AlbumInputError('Разметка превышает 96 КиБ.')
        result = analyze_album(args.file, json.loads(raw) if raw else None)
    except AlbumInputError as exc:
        result = {'ok': False, 'code': 'invalid_album_input', 'message': str(exc)}
    except (UnicodeError, json.JSONDecodeError):
        result = {'ok': False, 'code': 'invalid_album_input', 'message': 'Разметка должна быть в формате JSON.'}
    except (ImportError, OSError, ValueError, OverflowError):
        result = {'ok': False, 'code': 'album_processing_error', 'message': 'Не удалось обработать альбом.'}
    print(json.dumps(result, ensure_ascii=False, separators=(',', ':'), allow_nan=False))
    return 0 if result['ok'] else 1


if __name__ == '__main__':
    sys.exit(main())
