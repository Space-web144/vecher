"""Conservative reversible recovery of CP1251 text misdecoded as Latin-1.
Coordinates and original words remain evidence; never infer missing glyphs.
"""
import re

ANCHORS = frozenset(('план', 'вентиляции', 'вентиляция', 'схемы', 'схема',
                     'систем', 'системы', 'воздуховодов', 'воздуховоды',
                     'примечание', 'спецификация', 'оборудования', 'ведомость',
                     'чертежей', 'кондиционирование', 'материалов'))
CODE = re.compile(r'(?:ДП|ДВ|ДК|ДЕ|ПД|ВД|ВЕ|ПЕ|П|В)\d+(?:[.,]\d+)?(?:[-–]\d+)?', re.I)
SECTION = re.compile(r'\d{2,4}[õÕ]\d{2,4}')
CYR = re.compile('[А-Яа-яЁё]')


def candidate(raw):
    if CYR.search(raw):
        return raw
    try:
        decoded = raw.encode('latin-1').decode('cp1251')
    except UnicodeError:
        return raw
    if decoded == raw:
        return raw
    if SECTION.fullmatch(raw):
        return re.sub('[õÕ]', 'х', raw)
    if CODE.fullmatch(decoded):
        return decoded
    # Avoid translating isolated accented Latin names on mixed-language sheets.
    letters = sum(c.isalpha() for c in decoded)
    cyr = len(CYR.findall(decoded))
    return decoded if cyr >= 2 and cyr == letters else raw


def recover_words(words):
    """Return normalized words and auditable corrections only on anchored pages."""
    candidates = [candidate(w[4]) for w in words]
    anchors = sorted({v.casefold().strip('.,:;()') for w, v in zip(words, candidates)
                      if w[4] != v and v.casefold().strip('.,:;()') in ANCHORS})
    if len(anchors) < 2:
        return words, {'status': 'unchanged', 'anchor_words': [], 'changed_word_count': 0,
                       'corrections': []}
    output, changes = [], []
    for w, v in zip(words, candidates):
        if w[4] != v:
            changes.append({'raw': w[4], 'normalized': v,
                            'bbox_pt': [round(float(x), 2) for x in w[:4]],
                            'word_id': list(w[5:8])})
            output.append((*w[:4], v, *w[5:]))
        else:
            output.append(w)
    return output, {'status': 'cp1251_recovered', 'anchor_words': anchors,
                    'changed_word_count': len(changes), 'corrections': changes}