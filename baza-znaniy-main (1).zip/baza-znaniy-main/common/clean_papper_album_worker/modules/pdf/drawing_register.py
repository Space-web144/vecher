"""Evidence-first drawing schedule from the printed engineering sheet register.

Pure PyMuPDF adapter: the register is an index, not evidence of scale, duct
geometry, approved systems or typical-floor multiplicity. Never infer these.
"""
from __future__ import annotations

from collections import defaultdict
import re

_SYSTEM = re.compile(r"(?<![\w-])(?:ДП|ДВ|ДК|ДЕ|ПД|ВД|ВЕ|ПЕ|П|В)\s*\d+(?:[.,]\d+)?(?:\s*[-−–]\s*\d+)?\b", re.I)
_NUM = re.compile(r"[1-9]\d{0,2}\Z")
_TITLE = re.compile(r"ведомость\s+рабочих\s+чертежей", re.I)
_FLOOR = re.compile(r"(?<!\d)(\d{1,2})\s*[-–]?\s*(?:го|ого|й)\s+этаж", re.I)


def normalized_system(raw):
    """Normalize a technical system code without guessing an absent suffix."""
    if not isinstance(raw, str):
        return ''
    return re.sub(r'\s+', '', raw).upper().translate(str.maketrans({',': '.', '−': '-', '–': '-'}))


def system_codes(text):
    return sorted({normalized_system(m.group(0)) for m in _SYSTEM.finditer(text)})


def normalized_title(title):
    return ''.join(char for char in title.casefold().replace('ё', 'е') if char.isalnum())


def drawing_kind(title):
    low = title.casefold()
    if 'кондиционирован' in low:
        return 'conditioning_scheme' if 'схем' in low else 'conditioning_plan'
    if 'схем' in low or 'аксонометр' in low:
        return 'axonometry'
    if re.match(r'^план(?:н)?\b', low) or low.startswith(('технадстр', 'кровля')):
        return 'plan'
    return 'other'


def _candidate_rows(page):
    """Find a consecutive number column underneath the register heading."""
    words = page.get_text('words', sort=False)
    title = page.get_text('text')
    if not _TITLE.search(title):
        return []
    headings = [w for w in words if w[4].casefold() == 'ведомость']
    if not headings:
        return []
    header_y = min(w[1] for w in headings)
    # Sheet numbers are short, left-aligned and consecutive. Restrict to a
    # horizontal column, not isolated dimension values from unrelated tables.
    numbers = [(int(w[4]), w[0], w[1]) for w in words
               if _NUM.fullmatch(w[4]) and w[1] > header_y + 22
               and w[0] < page.rect.width * .28]
    best = []
    for number, x, y in numbers:
        if number != 1:
            continue
        run = [(number, x, y)]
        for next_number in range(2, 301):
            options = [(n, xx, yy) for n, xx, yy in numbers
                       if n == next_number and abs(xx - x) <= 15
                       and 6 <= yy - run[-1][2] <= 60]
            if len(options) != 1:
                break
            run.append(options[0])
        if len(run) > len(best):
            best = run
    if len(best) < 5:
        return []
    # The right border excludes the parallel notes column and unrelated tables.
    left = best[0][1] + 16
    right = min(page.rect.width * .65, best[0][1] + 490)
    rows = []
    for index, (number, _, y) in enumerate(best):
        until = best[index + 1][2] - 9 if index + 1 < len(best) else y + 17
        tokens = [w for w in words if left <= w[0] < right
                  and y - 9 <= w[1] < until]
        if not tokens:
            return []
        tokens.sort(key=lambda w: (round(w[1] / 4), w[0]))
        title = ' '.join(w[4] for w in tokens).strip()
        if not title:
            return []
        rows.append((number, title, [round(min(w[0] for w in tokens), 2),
                                     round(min(w[1] for w in tokens), 2),
                                     round(max(w[2] for w in tokens), 2),
                                     round(max(w[3] for w in tokens), 2)]))
    return rows


def extract_drawing_register(document, max_index_pages=12):
    """Read printed drawing register; return accepted entries and diagnostics.

    A candidate is accepted only if the title on its predicted sheet is found
    in that sheet's own text and at least three independent sheets match.
    All unverified entries remain diagnostics and cannot reclassify pages.
    """
    for idx in range(min(len(document), max_index_pages)):
        rows = _candidate_rows(document[idx])
        if not rows:
            continue
        entries = []
        for sheet_no, title, bbox in rows:
            pdf_page = idx + sheet_no
            actual_text = document[pdf_page - 1].get_text('text') if pdf_page <= len(document) else ''
            # Whole title is normally repeated in the title block. For a
            # wrapped title only use a long opening fragment with clear context.
            expected = normalized_title(title)
            actual = normalized_title(actual_text)
            verified = bool(expected and expected in actual)
            if not verified and len(expected) > 55:
                verified = expected[:55] in actual
            floor_match = _FLOOR.search(title)
            entries.append({
                'sheet_number': sheet_no,
                'pdf_page': pdf_page,
                'title': title,
                'kind': drawing_kind(title),
                'systems_in_title': system_codes(title),
                'explicit_floor_numbers': [int(floor_match.group(1))] if floor_match else [],
                'title_verified_on_sheet': verified,
                'source': {'pdf_page': idx + 1, 'bbox_pt': bbox, 'method': 'printed_drawing_register'},
                'floor_multiplicity_approved': False,
                'scale_verified': False,
            })
        verified_count = sum(entry['title_verified_on_sheet'] for entry in entries)
        if verified_count < 3 or verified_count / len(entries) < .6:
            return {'status': 'unverified_register', 'source_pdf_page': idx + 1,
                    'verified_count': verified_count, 'entries': entries}
        return {'status': 'verified_register', 'source_pdf_page': idx + 1,
                'verified_count': verified_count, 'entries': entries}
    return {'status': 'not_found', 'source_pdf_page': None, 'verified_count': 0, 'entries': []}