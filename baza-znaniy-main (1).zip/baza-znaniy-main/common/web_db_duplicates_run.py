# -*- coding: utf-8 -*-
"""
Поиск дублей номенклатуры ВНУТРИ самой боевой базы сравнения (DB_FILE) —
дополнительная проверка к той, что уже есть при приёме от 1С
(common.nomenclature_intake: новая позиция против базы). Здесь наоборот —
база против самой себя: со временем в неё могли попасть две карточки на
одну и ту же позицию под разными кодами (например, при ручной правке в
1С или до того, как заработала проверка на приёме). Сам этот скрипт —
только отчёт, ничего на диске не меняет; удаление найденных дублей —
отдельный скрипт (web_db_duplicates_remove_run.py), вызывается только
после явного выбора администратора на web/onec_db_duplicates.php.

Переиспользует common.matcher.find_text_duplicate_groups — жёсткий
текстовый критерий (полностью совпадающий normalize() наименования), БЕЗ
разбора геометрии — заказчик явно попросил точность важнее полноты,
после того как геометрический разбор дважды дал ложные совпадения на
реальной базе (см. докстринг find_text_duplicate_groups за историей).
Это НЕ метод NomenclatureIndex и не строит его — полная сборка индекса
(geo_index/word_index и т.п.) этой функции не нужна и на ~66 тыс. позиций
стоила бы ~5.5 сек впустую на каждый вызов (воспроизведено как 502 в
web_db_duplicates_remove_run.py, где это выполнялось на каждый запрос).

С --out — пишет отчёт в файл и держит там, пока DB_FILE не станет новее
кэша (та же схема, что у common/web_db_file_dump.py и DB_FILE_DUMP_CACHE,
см. web/onec_database.php) — страница с результатами постраничная (групп
могут быть тысячи), пересчитывать на каждый клик "вперёд" незачем.

Пример вызова:
  python3 web_db_duplicates_run.py --db /path/1c_base.xlsx --out /path/report.json
"""
import os

# Обязательно ДО любого импорта common/openpyxl — см. common/
# web_db_file_dump.py за той же историей (RLIMIT_NPROC на хостинге).
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import sys
import json
import argparse

sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "program-a"))
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from common.matcher import find_text_duplicate_groups  # noqa: E402
from common.web_db_file_dump import _load_items_with_codes  # noqa: E402

# Меняется при любом изменении состава полей отчёта ИЛИ самой логики
# группировки (find_duplicate_groups, включая common.parameters.
# extract_sections, которым она пользуется) — web/onec_db_duplicates.php
# сверяет его с уже посчитанным кэшем (как web_db_file_dump.py/
# DB_FILE_DUMP_CACHE) и, если не совпало, пересчитывает заново независимо
# от времени изменения DB_FILE. Без этого исправление логики не долетело
# бы до уже посчитанного кэша на сервере, пока кто-то не тронет сам
# DB_FILE. История: 2 — защита от ложных групп у позиций без
# распознанного размера ("Заглушка" без Ду); 3 — защита от ложных групп
# у "Лист/Пластина ... с врезкой ..." (разные размеры врезки на одном и
# том же листе схлопывались в одно "сечение"); 4 — геометрический
# критерий убран совсем, остался только жёсткий текстовый (заказчик
# явно попросил точность важнее полноты).
SCHEMA_VERSION = 4

# Отчёт может быть большим (в проверенной базе уже встречались группы по
# 3 позиции на один типоразмер) — отдаём всё, "показать первые N" решает
# PHP при выводе, не скрипт.


def main():
    parser = argparse.ArgumentParser(description="Поиск дублей номенклатуры внутри DB_FILE")
    parser.add_argument("--db", required=True, help="путь к DB_FILE (.xlsx/.csv)")
    parser.add_argument("--out", default=None, help="куда сохранить JSON-отчёт целиком; без него — в stdout")
    args = parser.parse_args()

    if not os.path.isfile(args.db):
        print(json.dumps({"ok": False, "error": f"Файл не найден: {args.db}"}, ensure_ascii=False))
        sys.exit(1)

    try:
        items = _load_items_with_codes(args.db)
        groups = find_text_duplicate_groups(items, name_key="Наименование")
        report_groups = [
            [{"Код": it.get("Код", ""), "Наименование": it.get("Наименование", "")} for it in group]
            for group in groups
        ]
        # Крупные группы (больше позиций на один типоразмер) — вероятнее
        # настоящая проблема, чем случайная пара — наверх списка.
        report_groups.sort(key=lambda g: (-len(g), g[0]["Наименование"]))
    except Exception as exc:
        print(json.dumps({"ok": False, "error": str(exc)}, ensure_ascii=False))
        sys.exit(1)

    result = {
        "ok": True,
        "schema_version": SCHEMA_VERSION,
        "total_items": len(items),
        "group_count": len(report_groups),
        "duplicate_item_count": sum(len(g) for g in report_groups),
        "groups": report_groups,
    }

    if args.out:
        tmp_path = args.out + ".tmp"
        with open(tmp_path, "w", encoding="utf-8") as f:
            json.dump(result, f, ensure_ascii=False)
        os.replace(tmp_path, args.out)
        print(json.dumps({"ok": True, "group_count": len(report_groups)}, ensure_ascii=False))
    else:
        print(json.dumps(result, ensure_ascii=False))


if __name__ == "__main__":
    main()
