# -*- coding: utf-8 -*-
"""
Проверка входящей номенклатуры от 1С перед добавлением в общую базу
(common.matcher.NomenclatureIndex, ~42-43 тыс. позиций, используется в
VentSpec для сравнения спецификаций).

Ни одна из проверок ниже не ОТКЛОНЯЕТ позицию сама — только подсвечивает
её для решения человека (заказчик явно указал это как требование,
особенно для релевантности вентиляции). Позиция без единого замечания
(auto_promote_clean_items) добавляется автоматически — и в эталонный
снимок номенклатуры, и, если передан db_file, в боевую базу сравнения
(DB_FILE). Позиция с хотя бы одним замечанием никогда не уходит туда
сама — она попадает в очередь ручной проверки (write_pending_review,
web/onec_review.php): администратор либо правит наименование в браузере
и подтверждает (promote_reviewed_item — добавляет туда же, куда и чистые
позиции), либо отклоняет её совсем (reject_reviewed_item — никуда не
добавляется, просто уходит из очереди). Присланную пачку целиком —
например, если 1С прислала её по ошибке — можно удалить со страницы
web/onec_intake.php (web/onec_intake_delete.php); это только убирает
запись о пачке и её ещё не решённые позиции из очереди, уже добавленные
в базу чистые позиции этим не затрагиваются.

1С присылает JSON — список позиций с полями (схема подтверждена на
реальной выгрузке, ни одного расхождения на проверенных записях):
    Код, Наименование, Артикул, ВидНоменклатуры, Комментарий,
    СтранаПроисхождения, ВАрхиве, ПометкаУдаления, ЭтоГруппа, Описание,
    Производитель, Услуга
"Код" — устойчивый уникальный идентификатор карточки номенклатуры в 1С
(подтверждено заказчиком). Работы ("ВидНоменклатуры": "Работа") и
материалы/товары реально приходят раздельными выгрузками, но модуль
этого не предполагает жёстко — на входе просто список позиций.

Четыре проверки (по требованиям заказчика):

  1. Опечатки — текстовое расстояние редактирования (rapidfuzz) для явных
     опечаток (переставленные/задвоенные буквы) + проверка Claude: среди
     похожих существующих карточек модель ищет то же изделие, записанное
     иначе (см. common.claude_matcher). Часть с Claude опциональна — без
     файла с ключом Anthropic работает только текстовая часть.
  2. Дублирование — переиспользует точный геометрический Tier 1 матч
     (common.matcher.NomenclatureIndex.find_exact, как явно попросил
     заказчик, а не новая логика) + точное совпадение нормализованного
     текста наименования (для позиций без геометрии — крепёж, расходники
     и т.п. — где Tier 1 матч не предназначен искать совпадение).
     normalize() схлопывает лишние пробелы и регистр до сравнения —
     позиция, отличающаяся от существующей только лишними пробелами,
     всё равно находится как точный дубликат, а не пропускается.
  3. Принадлежность к вентиляции — ключевой фильтр (в новой номенклатуре
     1С нет дерева категорий/пути, регэкспами по пути классифицировать
     нельзя, как и было сказано). Финальное решение — обязательно
     ручное, фильтр только подсвечивает подозрительные позиции.
  4. Тройники — заказчик подтвердил формулу: длина тройника ("L=...")
     должна быть не меньше первого/единственного размера ответвления +
     100мм (круглое ответвление — не меньше диаметра + 100мм). Пример
     заказчика: тройник 400х400-500х500-400х400 — минимум 600мм
     (ответвление 500, 500+100=600).

CLI:
    python -m common.nomenclature_intake новая_номенклатура.json \\
        существующая_база.json отчёт.xlsx \\
        [--claude-credentials /path/anthropic.json] \\
        [--name-key Наименование] [--code-key Код]

Существующая база передаётся тем же форматом полей 1С (список словарей
с "Код"/"Наименование" и т.д.) — например, той же периодической полной
выгрузкой, что описана выше для новой номенклатуры.
"""
from __future__ import annotations

import argparse
import json
import os
import sys
from collections import defaultdict
from typing import Dict, List, Optional, Tuple

from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill
from rapidfuzz import fuzz, process

from common.anthropic_client import AnthropicClient, AnthropicError
from common.claude_matcher import ClaudeMatcher, PROMPT_DUPLICATE, SHORTLIST_SIZE
from common.matcher import NomenclatureIndex, determine_category
from common.parameters import clean_whitespace, extract_geometry, extract_sections, normalize
from common.report import CATEGORY_NAMES

# ────────────────────────────────────────────────────────────────────
# Проверка 3 — принадлежность к вентиляции (ключевой фильтр)
# ────────────────────────────────────────────────────────────────────

# Намеренно с запасом (лучше лишний раз подсветить для ручной проверки,
# чем молча пропустить нерелевантную позицию в вент-базу) — список не
# исчерпывающий, калибровать по факту первых прогонов на реальных
# данных заказчика. Objединяет фасонные изделия/оборудование из common.matcher
# (ОТВОД/ПЕРЕХОД/ТРОЙНИК/... и _EQUIPMENT_MARKERS) с более общими
# вент-терминами, которых там нет (сами по себе ключевые слова
# common.matcher не годятся — это маркеры типов ФАСОННЫХ ИЗДЕЛИЙ, определяющие
# уже подтверждённо-вентиляционную позицию, а не признак домена).
_VENT_DOMAIN_KEYWORDS = [
    "ВЕНТИЛ", "ВОЗДУХОВОД", "ВОЗДУХ", "ПРИТОЧ", "ВЫТЯЖ", "АЭРАЦ",
    "ДИФФУЗОР", "РЕШЕТК", "РЕШЁТК", "ДРОССЕЛЬ", "КЛАПАН", "ШУМОГЛУШИТЕЛ",
    "ФИЛЬТР", "СТАКАН", "ОТВОД", "ПЕРЕХОД", "ТРОЙНИК", "ВРЕЗКА",
    "ЗАГЛУШКА", "КРЕСТОВИНА", "АНЕМОСТАТ", "ЖАЛЮЗИ", "ШИБЕР",
    "КАЛОРИФЕР", "КОНДИЦИОН", "НАГНЕТАТЕЛ", "ФЛАНЕЦ", "КПВ",
    "ОГНЕЗАЩИТ", "ВИБРОВСТАВК", "ВОЗДУХОЗАБОР", "ВОЗДУХОРАСПРЕД",
    "ВОЗДУХОНАГРЕВАТЕЛ", "ВОЗДУХООХЛАДИТЕЛ",
]


def check_ventilation_relevance(name: str) -> Tuple[bool, List[str]]:
    """
    Ключевой фильтр релевантности вентиляции. НЕ финальное решение —
    только подсказка для обязательной ручной проверки (см. модульный
    docstring). Категория 1/2/3 (оборудование/воздуховод/фасонные изделия) от
    common.matcher.determine_category считается надёжным признаком сама
    по себе; категории 4/5 (изоляция/крепёж) построены на маркерах,
    которые в равной мере используются вне вентиляции (скотч, дюбель,
    саморез и т.п.), поэтому для них и для неопределённой категории (0)
    нужен ещё и явный вент-термин в тексте.

    Возвращает (is_relevant, matched_keywords).
    """
    text_norm = normalize(name)
    category = determine_category(name)
    matched = [kw for kw in _VENT_DOMAIN_KEYWORDS if kw in text_norm]
    is_relevant = category in (1, 2, 3) or bool(matched)
    return is_relevant, matched


# ────────────────────────────────────────────────────────────────────
# Проверка 4 — минимальная длина тройника
# ────────────────────────────────────────────────────────────────────

# Заказчик подтвердил формулу явно (см. модульный docstring) — не
# калибровка, точное требование.
TEE_LENGTH_MARGIN_MM = 100


def check_tee_min_length(name: str) -> Optional[dict]:
    """
    Проверка минимальной длины тройника: L= в наименовании должна быть
    не меньше первого/единственного размера ответвления + 100мм.

    Возвращает None, если позиция не тройник. Если тройник, но геометрия
    не распозналась в одну тройку сечений (extract_sections из
    common.parameters — то же извлечение, что использует Tier 1
    индексация базы, см. common.matcher.NomenclatureIndex._build) —
    {"status": "geometry_unclear"}, без оценки: если геометрия не
    распозналась, Tier 1 матч по этой позиции и так не сработает, а
    формулу проверять не на чем.

    extract_sections отдаёт два разных вида результата для тройника в
    зависимости от формата сечения: круглый (Ø400-Ø500-Ø400) — ОДИН
    3-элементный кортеж [(магистраль, ответвление, магистраль)] (найден
    напрямую по regex тройной записи); прямоугольный (400х400-500х500-
    400х400) — список из ТРЁХ 2-элементных кортежей-пар (магистраль,
    ответвление, магистраль каждый как AxB). Оба случая нужно разобрать
    отдельно.
    """
    geom = extract_geometry(name, is_spec_row=True)
    if geom["kw"] != "ТРОЙНИК":
        return None

    sections = extract_sections(name, "ТРОЙНИК", False)
    if len(sections) == 1 and len(sections[0]) == 3:
        branch_size = sections[0][1]
    elif len(sections) == 3:
        branch_size = sections[1][0]
    else:
        return {"status": "geometry_unclear", "actual_length": geom["length"]}
    required_min = branch_size + TEE_LENGTH_MARGIN_MM
    actual = geom["length"]

    if actual == 0:
        return {"status": "no_length", "required_min": required_min, "branch_size": branch_size}
    status = "ok" if actual >= required_min else "violation"
    return {
        "status": status,
        "actual_length": actual,
        "required_min": required_min,
        "branch_size": branch_size,
    }


# ────────────────────────────────────────────────────────────────────
# Проверки 1 и 2 — опечатки и дублирование против существующей базы
# ────────────────────────────────────────────────────────────────────

# rapidfuzz.fuzz.ratio (0-100) — начальная оценка порога, не
# откалиброванная на реальных данных заказчика — донастроить по факту
# первых прогонов.
TEXT_SIMILARITY_TYPO_MIN = 92.0


class IntakeChecker:
    """
    Строит индексы по уже существующей базе ОДИН РАЗ (геометрический
    Tier 1 + текстовые наименования для точного/нечёткого сравнения) и
    прогоняет через них каждую новую позицию от 1С — без пересборки
    индекса на каждый вызов.
    """

    def __init__(self, existing_items: List[dict], name_key: str = "Наименование",
                 code_key: str = "Код"):
        self.name_key = name_key
        self.code_key = code_key
        self.tier1_index = NomenclatureIndex(existing_items, name_key=name_key)

        self._existing_items = [it for it in existing_items if it.get(name_key)]
        self._existing_names_norm = [normalize(it[name_key]) for it in self._existing_items]
        self._by_exact_norm: Dict[str, dict] = {}
        for it in self._existing_items:
            self._by_exact_norm.setdefault(normalize(it[name_key]), it)

    def find_exact_text_duplicate(self, name: str) -> Optional[dict]:
        """Точное совпадение нормализованного текста — ловит дубликаты
        для позиций без геометрии (крепёж, расходники и т.п.), где
        Tier 1 find_exact не предназначен искать совпадение."""
        return self._by_exact_norm.get(normalize(name))

    def find_tier1_duplicate(self, name: str) -> Optional[dict]:
        """Геометрический Tier 1 матч (common.matcher.NomenclatureIndex),
        переиспользованный как есть — заказчик явно попросил не
        изобретать новую логику дублирования."""
        return self.tier1_index.find_exact(name)

    def find_typo_candidate(self, name: str) -> Optional[Tuple[dict, float]]:
        """Ближайшая по тексту существующая позиция (rapidfuzz, ratio —
        по сути нормализованное расстояние редактирования), если похожа,
        но не идентична — кандидат в опечатки (переставленные/задвоенные
        буквы и т.п. дают высокий ratio при небольшом реальном расстоянии
        редактирования)."""
        if not self._existing_names_norm:
            return None
        match = process.extractOne(
            normalize(name), self._existing_names_norm,
            scorer=fuzz.ratio, score_cutoff=TEXT_SIMILARITY_TYPO_MIN,
        )
        if match is None:
            return None
        _text, score, idx = match
        if score >= 100.0:
            return None  # точное совпадение после нормализации — дубликат, не опечатка
        return self._existing_items[idx], score

    def shortlist(self, name: str, limit: int = SHORTLIST_SIZE) -> List[str]:
        """Наименования самых похожих по тексту существующих карточек —
        кандидаты для проверки Claude (resolve_duplicate_candidates).
        WRatio, а не ratio, как у опечаток: дубль бывает записан с другим
        порядком слов или с лишними словами, а не только с опечаткой."""
        if not self._existing_names_norm:
            return []
        found = process.extract(normalize(name), self._existing_names_norm,
                                scorer=fuzz.WRatio, limit=limit)
        return list(dict.fromkeys(self._existing_items[idx][self.name_key]
                                  for _text, _score, idx in found))

# Предохранитель числа запросов к Claude на одну пачку от 1С: 100 запросов
# по ROWS_PER_REQUEST позиций — 2500 позиций без точного дубля.
DUPLICATE_MAX_REQUESTS = 100


def resolve_duplicate_candidates(names: List[str], checker: IntakeChecker,
                                 credentials_file=None, client=None,
                                 log=None) -> Tuple[Dict[str, str], Optional[str], bool]:
    """
    Проверка Claude на все имена сразу (пачками, см. ClaudeMatcher): для
    каждого имени IntakeChecker.shortlist отбирает похожие существующие
    карточки, модель выбирает ту, что обозначает то же изделие.

    Возвращает ({имя: наименование существующей карточки}, строка для
    отчёта, выполнялась ли проверка). Без файла с ключом и без client —
    ({}, None, False): проверка просто пропускается, остальные от неё не
    зависят. Сбой связи посреди пачки не роняет приём: то, что успели
    проверить, остаётся, остальное помечается в строке для отчёта.
    """
    if client is None:
        if not credentials_file:
            return {}, None, False
        try:
            client = AnthropicClient(credentials_file=credentials_file, log=log,
                                     max_requests=DUPLICATE_MAX_REQUESTS)
        except AnthropicError as exc:
            return {}, f"не выполнена: {exc}", False

    matcher = ClaudeMatcher(client, PROMPT_DUPLICATE, log=log)
    queries = [{"key": name, "name": name, "mark": "", "candidates": checker.shortlist(name)}
               for name in dict.fromkeys(names) if name]
    chosen = matcher.choose(queries)

    status = f"выполнена, модель {matcher.model}; {client.usage_summary()}"
    if matcher.failed:
        status = f"сбой связи: {matcher.failed}"
    if matcher.skipped:
        status += f"; без проверки осталось позиций: {matcher.skipped}"
    return chosen, status, True


# ────────────────────────────────────────────────────────────────────
# Сборка результата по одной позиции
# ────────────────────────────────────────────────────────────────────

FLAG_LABELS = {
    "not_vent_relevant": "Не вентиляция?",
    "possible_duplicate": "Дубликат?",
    "possible_typo": "Опечатка?",
    "tee_length_violation": "Тройник: длина мала",
    "tee_length_unknown": "Тройник: длина не указана",
    # web/onec_intake.php и web/onec_review.php держат свои копии этого
    # словаря в том же виде.
    "semantic_similarity": "Семантически близко",
}


def check_item(raw_item: dict, checker: IntakeChecker,
                semantic_results: Dict[str, str]) -> dict:
    name = raw_item.get(checker.name_key, "")
    flags: List[dict] = []

    is_relevant, _matched_kw = check_ventilation_relevance(name)
    if not is_relevant:
        flags.append({
            "type": "not_vent_relevant",
            "detail": "Ни один известный ключевой признак вентиляции не найден — проверить вручную",
        })

    tier1_dup = checker.find_tier1_duplicate(name)
    text_dup = checker.find_exact_text_duplicate(name)
    dup = tier1_dup or text_dup
    if dup is not None:
        method = "точное совпадение геометрии Tier 1" if tier1_dup else "точное совпадение текста наименования"
        flags.append({
            "type": "possible_duplicate",
            "detail": (f"Похоже на уже существующую позицию: код {dup.get(checker.code_key, '?')}, "
                       f"«{dup.get(checker.name_key, '')}» ({method})"),
            "existing_code": dup.get(checker.code_key),
            "existing_name": dup.get(checker.name_key),
        })

    if dup is None:
        typo = checker.find_typo_candidate(name)
        if typo is not None:
            cand, score = typo
            flags.append({
                "type": "possible_typo",
                "detail": (f"Похоже на «{cand.get(checker.name_key, '')}» (код {cand.get(checker.code_key, '?')}), "
                           f"текстовое сходство {score:.0f}% — проверить на опечатку"),
                "existing_code": cand.get(checker.code_key),
                "existing_name": cand.get(checker.name_key),
                "similarity": score,
            })

        sem_name = semantic_results.get(name)
        if sem_name is not None and normalize(sem_name) != normalize(name):
            existing = checker.find_exact_text_duplicate(sem_name) or {}
            flags.append({
                "type": "semantic_similarity",
                "detail": (f"По оценке Claude — то же изделие, что «{sem_name}» "
                           f"(код {existing.get(checker.code_key, '?')}) — проверить на "
                           f"дублирование/опечатку"),
                "existing_code": existing.get(checker.code_key),
                "existing_name": sem_name,
            })

    tee = check_tee_min_length(name)
    if tee is not None and tee["status"] == "violation":
        flags.append({
            "type": "tee_length_violation",
            "detail": (f"L={tee['actual_length']}мм меньше минимума {tee['required_min']}мм "
                       f"(ответвление {tee['branch_size']}+{TEE_LENGTH_MARGIN_MM})"),
        })
    elif tee is not None and tee["status"] == "no_length":
        flags.append({
            "type": "tee_length_unknown",
            "detail": (f"Длина (L=) не указана в наименовании — по формуле минимум "
                       f"{tee['required_min']}мм, проверить вручную"),
        })

    return {
        "code": raw_item.get(checker.code_key),
        "name": name,
        "kind": raw_item.get("ВидНоменклатуры"),
        "category": determine_category(name),
        "flags": flags,
        "ok": not flags,
    }


# ────────────────────────────────────────────────────────────────────
# Загрузка входных файлов и фильтрация служебных записей
# ────────────────────────────────────────────────────────────────────

def load_json_items(path) -> List[dict]:
    with open(path, encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, list):
        raise ValueError(f"Ожидался список позиций в {path}, получено: {type(data)}")
    return data


def filter_processable(raw_items: List[dict], name_key: str = "Наименование") -> Tuple[List[dict], dict]:
    """
    Отфильтровывает записи, которые не являются реальными позициями для
    проверки: группы 1С (ЭтоГруппа — узел дерева, не карточка товара) и
    позиции без наименования пропускаются всегда. Помеченные к удалению
    или архивные ТОЖЕ пропускаются — добавлять такую позицию в активную
    базу незачем, а значит и проверять её перед добавлением не нужно;
    количество пропущенных отдельно попадает в stats, чтобы не потерялось
    молча.
    """
    kept, skipped_groups, skipped_inactive = [], 0, 0
    for it in raw_items:
        if it.get("ЭтоГруппа"):
            skipped_groups += 1
            continue
        if it.get("ПометкаУдаления") or it.get("ВАрхиве"):
            skipped_inactive += 1
            continue
        if not it.get(name_key):
            continue
        kept.append(it)
    return kept, {"skipped_groups": skipped_groups, "skipped_inactive": skipped_inactive}


def _count_by_flag_type(results: List[dict]) -> Dict[str, int]:
    counts: Dict[str, int] = defaultdict(int)
    for r in results:
        for f in r["flags"]:
            counts[f["type"]] += 1
    return dict(counts)


def run_intake_check(new_items: List[dict], existing_items: List[dict],
                      name_key: str = "Наименование", code_key: str = "Код",
                      claude_credentials_file=None, claude_client=None,
                      log=None) -> Tuple[List[dict], dict]:
    """
    Полный цикл проверки: фильтрует служебные записи, строит индексы по
    existing_items один раз, прогоняет каждую позицию new_items через
    все четыре проверки. Возвращает (results, stats).
    """
    items, filter_stats = filter_processable(new_items, name_key)
    checker = IntakeChecker(existing_items, name_key=name_key, code_key=code_key)

    # В Claude — только позиции без точного дубля: для остальных check_item
    # его ответ всё равно не смотрит, а каждая позиция — входные токены.
    names = [it[name_key] for it in items
             if checker.find_tier1_duplicate(it[name_key]) is None
             and checker.find_exact_text_duplicate(it[name_key]) is None]
    semantic_results, semantic_status, semantic_ran = resolve_duplicate_candidates(
        names, checker, claude_credentials_file, claude_client, log=log)

    results = [check_item(it, checker, semantic_results) for it in items]

    stats = {
        "total_input": len(new_items),
        "total_checked": len(items),
        **filter_stats,
        "ok": sum(1 for r in results if not r["flags"]),
        "flagged": sum(1 for r in results if r["flags"]),
        "by_flag_type": _count_by_flag_type(results),
        "semantic_check_enabled": semantic_ran,
        "semantic_check_status": semantic_status,
    }
    return results, stats


# ────────────────────────────────────────────────────────────────────
# Загрузка в боевую номенклатуру — автоматическая (чистые позиции) и
# после ручной правки в браузере (web/onec_review.php). По явному
# запросу заказчика ПОВЕРХ ручной модерации, не вместо неё — позиция с
# хотя бы одним флагом никогда не уходит сюда сама, только через очередь
# проверки ниже.
# ────────────────────────────────────────────────────────────────────

def _append_to_bases(new_entries: List[dict], existing_items: List[dict], existing_items_path,
                      db_file_path=None, name_key: str = "Наименование",
                      code_key: str = "Код") -> int:
    """Дописывает new_entries в эталонный снимок (existing_items_path) и,
    если передан db_file_path, в боевую базу сравнения (DB_FILE, читает
    её program-a/vent_processor.py::_load_names — колонка B = наименование,
    остального не касается). Дубли по "Код" внутри existing_items не
    добавляются повторно. Наименование перед записью проходит
    clean_whitespace (множественные/краевые пробелы) — заказчик попросил
    приводить базу "к нормальному виду", без этого проблема возвращалась
    бы с каждой новой пачкой от 1С; на дедупликацию/отчёт это не влияет,
    там используется normalize() (сравнение без учёта пробелов и регистра
    уже и так не зависело от лишних пробелов). Копия словаря — чтобы не
    менять наименование в объекте, который вызывающий код мог использовать
    для чего-то ещё (например, в уже готовом отчёте). Возвращает число
    реально добавленных позиций.

    Обе записи — через временный файл рядом с целевым + os.replace
    (атомарная подмена на уровне файловой системы): и JSON-снимок, и
    особенно DB_FILE читаются множеством других запросов (сравнение
    спецификаций, дамп для "База", проверка дублей) практически
    непрерывно — запись поверх существующего файла не атомарна сама по
    себе, и конкурентное чтение ровно в момент записи может застать
    DB_FILE недописанным ("File is not a zip file" — воспроизведено на
    проде при параллельном запросе во время массового подтверждения всей
    очереди ручной проверки)."""
    existing_codes = {it.get(code_key) for it in existing_items if it.get(code_key)}
    fresh = []
    for it in new_entries:
        if it.get(code_key) in existing_codes:
            continue
        cleaned = dict(it)
        cleaned[name_key] = clean_whitespace(it.get(name_key, ""))
        fresh.append(cleaned)
    if not fresh:
        return 0

    existing_items.extend(fresh)
    existing_tmp_path = str(existing_items_path) + ".tmp"
    with open(existing_tmp_path, "w", encoding="utf-8") as f:
        json.dump(existing_items, f, ensure_ascii=False, indent=2)
    os.replace(existing_tmp_path, existing_items_path)

    if db_file_path:
        wb = load_workbook(db_file_path) if os.path.isfile(db_file_path) else Workbook()
        ws = wb.active
        for it in fresh:
            ws.append([it.get(code_key, ""), it.get(name_key, "")])
        db_tmp_path = str(db_file_path) + ".tmp"
        wb.save(db_tmp_path)
        os.replace(db_tmp_path, db_file_path)

    return len(fresh)


def auto_promote_clean_items(items: List[dict], results: List[dict],
                              existing_items: List[dict], existing_items_path,
                              db_file_path=None, name_key: str = "Наименование",
                              code_key: str = "Код") -> int:
    """items/results — из run_intake_check, тот же порядок и длина
    (results строится проходом по items). Позиции без единого замечания
    (results[i]["ok"]) дописываются в базы через _append_to_bases."""
    clean = [it for it, r in zip(items, results) if r["ok"]]
    return _append_to_bases(clean, existing_items, existing_items_path,
                             db_file_path, name_key, code_key)


def write_pending_review(items: List[dict], results: List[dict], pending_path,
                          token: str) -> int:
    """Позиции С хотя бы одним замечанием — в очередь ручной проверки
    (web/onec_review.php читает этот файл). "id" стабилен в пределах
    пачки (используется при подтверждении правки, см.
    promote_reviewed_item) — порядковый номер внутри этой же пачки,
    не глобальный: пачки не смешиваются, id всегда идёт вместе с token.
    Возвращает число позиций, ушедших в очередь."""
    pending = [
        {"id": i, "token": token, "raw_item": it, "flags": r["flags"], "resolved": False}
        for i, (it, r) in enumerate(zip(items, results)) if not r["ok"]
    ]
    if pending:
        with open(pending_path, "w", encoding="utf-8") as f:
            json.dump(pending, f, ensure_ascii=False, indent=2)
    return len(pending)


def promote_reviewed_item(pending_path, item_id: int, edited_name: str,
                           existing_items_path, existing_items: List[dict],
                           db_file_path=None, name_key: str = "Наименование",
                           code_key: str = "Код") -> dict:
    """Администратор подтвердил (возможно, поправленное) наименование
    позиции из очереди ручной проверки — добавляет её в базы той же
    функцией, что и чистые позиции, и отмечает "resolved" в файле
    очереди, чтобы она пропала из списка при следующем заходе на
    страницу. Бросает ValueError, если позиция не найдена или уже
    отмечена решённой (двойной сабмит формы, повторный клик и т.п.)."""
    with open(pending_path, encoding="utf-8") as f:
        pending = json.load(f)

    entry = next((p for p in pending if p["id"] == item_id), None)
    if entry is None:
        raise ValueError(f"Позиция id={item_id} не найдена в очереди {pending_path}")
    if entry["resolved"]:
        raise ValueError(f"Позиция id={item_id} уже обработана ранее")

    edited_name = edited_name.strip()
    if not edited_name:
        raise ValueError("Наименование не может быть пустым")

    raw_item = dict(entry["raw_item"])
    raw_item[name_key] = edited_name

    _append_to_bases([raw_item], existing_items, existing_items_path,
                      db_file_path, name_key, code_key)

    entry["resolved"] = True
    entry["resolved_name"] = edited_name
    with open(pending_path, "w", encoding="utf-8") as f:
        json.dump(pending, f, ensure_ascii=False, indent=2)

    return raw_item


def reject_reviewed_item(pending_path, item_id: int) -> dict:
    """Администратор отклонил позицию из очереди ручной проверки —
    противоположность promote_reviewed_item: НИКУДА не добавляется (ни в
    эталонный снимок, ни в DB_FILE), просто помечается решённой (resolved),
    чтобы пропасть из списка на web/onec_review.php при следующем заходе,
    но остаться в файле как журнал — rejected=True отличает её от
    подтверждённой (resolved_name) записи. Та же защита от повторной
    обработки, что и у promote_reviewed_item."""
    with open(pending_path, encoding="utf-8") as f:
        pending = json.load(f)

    entry = next((p for p in pending if p["id"] == item_id), None)
    if entry is None:
        raise ValueError(f"Позиция id={item_id} не найдена в очереди {pending_path}")
    if entry["resolved"]:
        raise ValueError(f"Позиция id={item_id} уже обработана ранее")

    entry["resolved"] = True
    entry["rejected"] = True
    with open(pending_path, "w", encoding="utf-8") as f:
        json.dump(pending, f, ensure_ascii=False, indent=2)

    return entry["raw_item"]


# ────────────────────────────────────────────────────────────────────
# Массовая обработка очереди (web/onec_review_bulk.php) — та же логика,
# что promote_reviewed_item/reject_reviewed_item, но для многих позиций
# сразу, выбранных администратором галочками. Позиции при массовом
# подтверждении добавляются КАК ЕСТЬ (raw_item, без правки наименования)
# — для правки нужна одиночная форма (promote_reviewed_item). Группирует
# выбранное по файлу очереди и читает/пишет каждый файл ОДИН раз, а не
# по разу на позицию — при выборе сотен позиций из одной пачки
# построчная запись была бы O(число_позиций × размер_файла).
# ────────────────────────────────────────────────────────────────────

def _group_selections_by_token(selections: List[Tuple[str, int]]) -> Dict[str, List[int]]:
    by_token: Dict[str, List[int]] = defaultdict(list)
    for token, item_id in selections:
        by_token[token].append(item_id)
    return by_token


def promote_reviewed_items_bulk(selections: List[Tuple[str, int]], pending_dir,
                                 existing_items_path, existing_items: List[dict],
                                 db_file_path=None, name_key: str = "Наименование",
                                 code_key: str = "Код") -> dict:
    """selections — список (token, id) отмеченных галочкой позиций,
    возможно из разных пачек. Возвращает {"promoted": N, "errors": [...]}
    — ошибка по одной позиции (не найдена/уже обработана/нет файла
    очереди) не останавливает остальные, попадает строкой в errors."""
    by_token = _group_selections_by_token(selections)
    to_append = []
    errors = []
    files_to_write = []  # (path, pending) — пишем после сбора to_append,
                          # чтобы частичная ошибка не оставила файл очереди
                          # помеченным "решено" для позиции, которая в базу
                          # так и не попала (_append_to_bases ниже, одним вызовом).

    for token, ids in by_token.items():
        path = os.path.join(pending_dir, f"{token}_1c_pending.json")
        if not os.path.isfile(path):
            errors.append(f"{token}: файл очереди не найден")
            continue
        with open(path, encoding="utf-8") as f:
            pending = json.load(f)
        by_id = {p["id"]: p for p in pending}
        changed = False
        for item_id in ids:
            entry = by_id.get(item_id)
            if entry is None:
                errors.append(f"{token}#{item_id}: позиция не найдена в очереди")
                continue
            if entry.get("resolved"):
                errors.append(f"{token}#{item_id}: уже обработана ранее")
                continue
            raw_item = dict(entry["raw_item"])
            to_append.append(raw_item)
            entry["resolved"] = True
            entry["resolved_name"] = raw_item.get(name_key, "")
            changed = True
        if changed:
            files_to_write.append((path, pending))

    promoted = _append_to_bases(to_append, existing_items, existing_items_path,
                                 db_file_path, name_key, code_key)

    for path, pending in files_to_write:
        with open(path, "w", encoding="utf-8") as f:
            json.dump(pending, f, ensure_ascii=False, indent=2)

    return {"promoted": promoted, "errors": errors}


def reject_reviewed_items_bulk(selections: List[Tuple[str, int]], pending_dir) -> dict:
    """Массовое отклонение — противоположность promote_reviewed_items_bulk:
    НИКУДА не добавляются, только помечаются resolved+rejected. Возвращает
    {"rejected": N, "errors": [...]}."""
    by_token = _group_selections_by_token(selections)
    rejected = 0
    errors = []

    for token, ids in by_token.items():
        path = os.path.join(pending_dir, f"{token}_1c_pending.json")
        if not os.path.isfile(path):
            errors.append(f"{token}: файл очереди не найден")
            continue
        with open(path, encoding="utf-8") as f:
            pending = json.load(f)
        by_id = {p["id"]: p for p in pending}
        changed = False
        for item_id in ids:
            entry = by_id.get(item_id)
            if entry is None:
                errors.append(f"{token}#{item_id}: позиция не найдена в очереди")
                continue
            if entry.get("resolved"):
                errors.append(f"{token}#{item_id}: уже обработана ранее")
                continue
            entry["resolved"] = True
            entry["rejected"] = True
            rejected += 1
            changed = True
        if changed:
            with open(path, "w", encoding="utf-8") as f:
                json.dump(pending, f, ensure_ascii=False, indent=2)

    return {"rejected": rejected, "errors": errors}


# ────────────────────────────────────────────────────────────────────
# Отчёт (Excel) — по образцу common/report.py и common/batch_match.py
# ────────────────────────────────────────────────────────────────────

_HEADER_FILL = PatternFill(start_color="DDEBF7", end_color="DDEBF7", fill_type="solid")
_FLAG_FILL = PatternFill(start_color="FCE4D6", end_color="FCE4D6", fill_type="solid")
_OK_FILL = PatternFill(start_color="C6E0B4", end_color="C6E0B4", fill_type="solid")
_HEADER_FONT = Font(bold=True)
_TITLE_FONT = Font(bold=True, size=14)


def write_intake_report(results: List[dict], stats: dict, output_path) -> str:
    wb = Workbook()
    ws = wb.active
    ws.title = "Проверка номенклатуры"

    headers = ["Код", "Наименование", "Вид номенклатуры", "Категория", "Статус", "Флаги", "Детали"]
    for col, title in enumerate(headers, start=1):
        cell = ws.cell(row=1, column=col, value=title)
        cell.fill = _HEADER_FILL
        cell.font = _HEADER_FONT

    for row_idx, r in enumerate(results, start=2):
        ws.cell(row=row_idx, column=1, value=r["code"])
        ws.cell(row=row_idx, column=2, value=r["name"])
        ws.cell(row=row_idx, column=3, value=r["kind"])
        ws.cell(row=row_idx, column=4, value=CATEGORY_NAMES.get(r["category"], str(r["category"])))
        status_cell = ws.cell(row=row_idx, column=5, value="Проверить" if r["flags"] else "OK")
        status_cell.fill = _FLAG_FILL if r["flags"] else _OK_FILL
        ws.cell(row=row_idx, column=6, value="; ".join(FLAG_LABELS.get(f["type"], f["type"]) for f in r["flags"]))
        ws.cell(row=row_idx, column=7, value=" | ".join(f["detail"] for f in r["flags"]))

    widths = {"A": 16, "B": 55, "C": 22, "D": 18, "E": 12, "F": 32, "G": 90}
    for col_letter, width in widths.items():
        ws.column_dimensions[col_letter].width = width
    ws.freeze_panes = "A2"

    _write_stats_sheet(wb.create_sheet("Статистика"), stats)

    wb.save(output_path)
    return output_path


def _write_stats_sheet(ws, stats: dict) -> None:
    ws["A1"] = "Проверка входящей номенклатуры 1С — сводка"
    ws["A1"].font = _TITLE_FONT

    rows = [
        ("Всего позиций во входном файле", stats["total_input"]),
        ("  из них групп 1С (пропущено)", stats["skipped_groups"]),
        ("  из них архив/к удалению (пропущено)", stats["skipped_inactive"]),
        ("Проверено позиций", stats["total_checked"]),
        ("Без замечаний", stats["ok"]),
        ("Требуют ручной проверки", stats["flagged"]),
        ("", ""),
        ("Проверка дублей через Claude",
         stats.get("semantic_check_status") or "пропущена (не передан --claude-credentials)"),
        ("", ""),
        ("По типам замечаний", ""),
    ]
    for flag_type, count in sorted(stats["by_flag_type"].items()):
        rows.append((f"  {FLAG_LABELS.get(flag_type, flag_type)}", count))

    r = 3
    for label, value in rows:
        ws.cell(row=r, column=1, value=label).font = Font(bold=True)
        ws.cell(row=r, column=2, value=value)
        r += 1
    ws.column_dimensions["A"].width = 45
    ws.column_dimensions["B"].width = 30


# ────────────────────────────────────────────────────────────────────
# CLI
# ────────────────────────────────────────────────────────────────────

def _main():
    parser = argparse.ArgumentParser(
        description="Проверка входящей номенклатуры 1С перед добавлением в базу (без автоматической вставки)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument("new_items", help="JSON со списком новой/обновлённой номенклатуры от 1С")
    parser.add_argument("existing_items", help="JSON с текущей базой номенклатуры (тот же формат полей 1С)")
    parser.add_argument("output", help="Куда сохранить Excel-отчёт")
    parser.add_argument("--claude-credentials",
                         help="JSON с ключом Anthropic (см. common/anthropic_client.py) — "
                              "включает проверку дублей через Claude")
    parser.add_argument("--name-key", default="Наименование", help="Ключ поля наименования (по умолчанию Наименование)")
    parser.add_argument("--code-key", default="Код", help="Ключ поля кода (по умолчанию Код)")
    args = parser.parse_args()

    new_items = load_json_items(args.new_items)
    existing_items = load_json_items(args.existing_items)

    results, stats = run_intake_check(
        new_items, existing_items,
        name_key=args.name_key, code_key=args.code_key,
        claude_credentials_file=args.claude_credentials,
        log=lambda msg: print(msg, file=sys.stderr),
    )
    write_intake_report(results, stats, args.output)

    print(f"Проверено: {stats['total_checked']} из {stats['total_input']} "
          f"(пропущено групп: {stats['skipped_groups']}, архив/к удалению: {stats['skipped_inactive']})")
    print(f"Без замечаний: {stats['ok']}, требуют проверки: {stats['flagged']}")
    for flag_type, count in sorted(stats["by_flag_type"].items()):
        print(f"  {FLAG_LABELS.get(flag_type, flag_type)}: {count}")
    print(f"Отчёт сохранён: {args.output}")


if __name__ == "__main__":
    sys.exit(_main())
