"""Run a private project statement job and publish its status atomically."""
import json
import os
from pathlib import Path
import sys
import time
import threading

STARTED = time.time()

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))


def status(folder, **values):
    tmp = folder / 'state.tmp'
    tmp.write_text(json.dumps(dict(values, updated=time.time(), started=STARTED), ensure_ascii=False), encoding='utf-8')
    os.replace(tmp, folder / 'state.json')


def heartbeat_loop(folder, stop):
    while not stop.is_set():
        try:
            (folder / 'heartbeat').touch()
        except OSError:
            pass
        stop.wait(3)


def claude_pages(album, source, credentials, folder, started):
    """Bounded, opt-in second pass. Only selected drawing JPEGs are transmitted."""
    import fitz
    import re
    from common.clean_papper_pipeline import inspect_specification
    from common.web_clean_papper_pdf import render_region, vision_request, PDFInputError
    from common.web_clean_papper_api import safe_error
    from common.anthropic_client import AnthropicError

    issues = album.setdefault('processing_issues', [])
    evidence = album.setdefault('claude_evidence', [])
    if not credentials or not Path(credentials).is_file():
        album.setdefault('claude_diagnostics',[]).append({'page':None,'code':'configuration','message':'Файл настроек Anthropic недоступен.'})
        issues.append('Claude: файл ключа API недоступен. Локальный расчёт продолжен.')
        return
    with fitz.open(source) as doc:
        try:
            ranges = (album.get('specification_inventory') or inspect_specification(doc)).get('candidates', [])
            excluded = set(range(ranges[0]['first'], ranges[0]['last']+1)) if len(ranges) == 1 else set()
        except Exception:
            excluded = set()
        eligible = [p for p in album['pages'] if p['pdf_page'] not in excluded and
                    (p['kind'] in ('plan','axonometry','mixed') or
                     (p['kind'] == 'unclassified' and (p.get('section_marks') or p.get('system_hints'))))]
        def priority(p):
            geom = p.get('geometry', {})
            return (geom.get('status') == 'inspected' and bool(geom.get('candidates')),
                    p['kind'] != 'unclassified', p['pdf_page'])
        eligible.sort(key=priority)
        selected = eligible[:5]
        if not selected:
            issues.append('Claude: не найдены подходящие листы для выборочной проверки.')
        elif len(eligible) > len(selected):
            issues.append(f'Claude: выборочная проверка {len(selected)} из {len(eligible)} подходящих листов (лимит 5 запросов).')
        def normalized(s):
            return re.sub(r'\s+', '', str(s or '')).lower().replace('×','x').replace('х','x')
        diagnostics = album.setdefault('claude_diagnostics', [])
        for idx, info in enumerate(selected):
            if time.monotonic()-started > 730:
                issues.append('Claude: достигнут лимит времени; часть выбранных листов не отправлена.')
                break
            number = info['pdf_page']
            status(folder, phase='running', message=f'Claude: автоматическая проверка листа {number} ({idx+1}/{len(selected)}).', completed=idx, total=len(selected))
            stage = 'render'
            try:
                page = doc[number-1]
                jpeg, _, _ = render_region(page, tuple(page.rect), 1900)
                stage = 'api'
                result = vision_request(credentials, jpeg)
                labels = {normalized(mark.get('raw')) for mark in info.get('section_marks', [])}
                for element in result.get('elements', []):
                    dimension = normalized(element.get('dimension'))
                    element['pdf_dimension_match'] = 'Да' if dimension and dimension in labels else 'Не подтверждено'
                evidence.append({'page': number, **result})
                diagnostics.append({'page':number,'code':'ok','message':'Ответ принят'})
                for note in result.get('notes', []):
                    issues.append(f'Claude, лист {number}: {note}')
            except Exception as exc:
                if stage=='render':
                    detail={'code':'render','message':'Не удалось сформировать JPEG страницы.'}
                elif isinstance(exc, json.JSONDecodeError):
                    detail={'code':'invalid_json','message':'Claude вернул неполный или некорректный JSON.'}
                elif isinstance(exc, ValueError):
                    detail={'code':'response_format','message':'Ответ не соответствует формату списка элементов.'}
                else:
                    detail=safe_error(exc)
                diagnostics.append({'page':number,'code':detail['code'],'message':detail['message']})
                issues.append(f"Claude, лист {number}: {detail['message']} Локальные данные сохранены.")
                # Permanent configuration/auth/model/billing errors are not retried on every page.
                if detail['code']=='configuration' or (isinstance(exc,AnthropicError) and getattr(exc,'status',None) in (400,401,402,403,404,429)):
                    issues.append('Claude: оставшиеся платные запросы пропущены из-за ошибки конфигурации или ограничения API.')
                    break
                continue


def run(folder, credentials=None):
    from modules.compare.project_statement import load_project, workbook
    from modules.compare.drawing_atlas import export_atlas
    from modules.compare.statement_review import read_review
    from modules.pdf.project_album import _segment_rows
    from modules.pdf.review_evidence import attach_review_evidence
    source = folder / 'album.pdf'
    status(folder, phase='running', message='Читаются страницы, размеры и геометрия.')
    started = time.monotonic()
    def progress(stage, completed, total):
        status(folder, phase='running', message=f'{stage}: {completed} из {total} листов.', completed=completed, total=total)

    album = load_project(source, None, [], None, geometry_budget_s=470 if credentials is not None else 610,
                         progress=progress)
    issues = album.setdefault('processing_issues', [])
    if album.get('geometry_summary', {}).get('processing_budget_reached'):
        issues.append('Достигнут лимит времени локальной геометрии: часть чертежей не обмерена.')
    limited=[str(p['pdf_page']) for p in album['pages'] if p.get('geometry',{}).get('candidate_list_limited')]
    if limited:
        issues.append('Достигнут предел выборки геометрии на листах: '+', '.join(limited)+'. Объёмы неполные.')
    from modules.compare.design_specification import read_design_specification
    status(folder, phase='running', message='Извлечение проектной спецификации и проверка VentSpec.')
    design_rows, design_issue = read_design_specification(source, album, timeout=max(0,min(100, int(690-(time.monotonic()-started)))))
    album['design_specification_rows'] = design_rows
    if design_issue:
        issues.append(design_issue)
    if credentials is not None:
        try:
            claude_pages(album, source, credentials, folder, started)
        except Exception:
            issues.append('Claude недоступен. Ведомость сформирована по локальным данным.')
    previous = []
    if (folder / 'review.xlsx').is_file():
        previous = read_review(folder / 'review.xlsx', album)
        pages = {p['pdf_page']: p for p in album['pages']}
        segments = _segment_rows(previous, pages)
        attach_review_evidence(previous, segments, pages)
        album['calculation']['segments'] = segments
    reference = folder / 'reference.xlsx'
    reference = reference if reference.is_file() else None
    status(folder, phase='running', message='Формирование расчётной ведомости' + (' и сверка с эталоном.' if reference else '.'))
    book = workbook(album, reference, None, 'Загруженный PDF-альбом', previous)
    status(folder, phase='running', message='Сохранение ведомости Excel.')
    book.save(folder / 'statement.xlsx')
    if not album['calculation'].get('preliminary_segments') and not album['calculation'].get('segments'):
        issues.append('Геометрические кандидаты не найдены. Ведомость не содержит участков; проверьте листы проекта.')
    if any(p.get('geometry', {}).get('candidates') for p in album['pages']):
        try:
            status(folder, phase='running', message='Формирование PDF с разметкой.')
            export_atlas(album, source, [], folder / 'atlas.pdf')
        except Exception:
            issues.append('PDF с разметкой не сформирован. Excel доступен отдельно.')
            (folder / 'atlas.pdf').unlink(missing_ok=True)
    status(folder, phase='done', pages=album['page_count'], atlas=(folder / 'atlas.pdf').is_file(),
           issues=album.get('processing_issues', []), claude_pages=len(album.get('claude_evidence', [])),
           preliminary_count=len(album['calculation'].get('preliminary_segments', [])),
           preliminary_measured=sum(s['unit_length_m'] is not None for s in album['calculation'].get('preliminary_segments', [])),
           design_rows=len(album.get('design_specification_rows', [])), fitting_count=len(album['calculation'].get('fitting_candidates',[])))


if __name__ == '__main__':
    folder = Path(sys.argv[1])
    stop = threading.Event()
    heartbeat = threading.Thread(target=heartbeat_loop, args=(folder, stop), daemon=True)
    heartbeat.start()
    try:
        run(folder, sys.argv[2] if len(sys.argv) > 2 else None)
    except (ValueError, KeyError) as error:
        status(folder, phase='failed', message=('Ошибка обработки проекта или дополнительных файлов. ' + str(error))[:380])
    except Exception:
        status(folder, phase='failed', message='Не удалось обработать документы. Проверьте формат файлов и установку Python, PyMuPDF и openpyxl.')
    finally:
        stop.set()
        heartbeat.join(timeout=1)
        for name in ('album.pdf','reference.xlsx','review.xlsx'):
            (folder / name).unlink(missing_ok=True)
