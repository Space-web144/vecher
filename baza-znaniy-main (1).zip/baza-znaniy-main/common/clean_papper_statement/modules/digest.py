import hashlib


def sha256_stream(stream):
    h = hashlib.sha256()
    for chunk in iter(lambda: stream.read(1048576), b""):
        h.update(chunk)
    return h.hexdigest()
