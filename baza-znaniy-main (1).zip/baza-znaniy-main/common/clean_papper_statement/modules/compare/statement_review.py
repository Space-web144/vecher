"""Workbook fields for returning engineer-reviewed drawing candidates to the album."""
from contextlib import closing
from openpyxl import load_workbook
from ..pdf.recovery_review import _report_digest
from openpyxl.worksheet.datavalidation import DataValidation

HEADERS = ('Страница PDF', 'ID кандидата', 'Источник', 'Включить (да)', 'Система',
           'ID сечения', 'Начальная отметка', 'Конечная отметка', 'Штук на экземпляр', 'ID участка')
SHEET = 'Заполнение инженером'


def review_digest(pages):
    return _report_digest([{k:p.get(k) for k in ('pdf_page','kind','geometry','floor_scope',
                                                 'elevation_marks','section_marks','single_sheet_source')}
                           for p in pages])


def add_review(book, pages, previous=()):
    sheet = book.create_sheet(SHEET)
    sheet.append(HEADERS)
    restored = {(row.get('plan_page') or row.get('axonometry_page'), row.get('plan_candidate_id') or
                 row.get('riser_candidate_id')):row for row in previous}
    for page in pages:
        geometry = page.get('geometry', {})
        for candidate in geometry.get('candidates', []):
            row = restored.get((page['pdf_page'],candidate['candidate_id']))
            values = [page['pdf_page'], candidate['candidate_id'], geometry['source_role']]
            if row:
                values.extend(['да', row['system'], row.get('section_mark_id'), row.get('start_mark_id'),
                               row.get('end_mark_id'), row.get('piece_count'), row['segment_id']])
            sheet.append(values)
    validation = DataValidation(type='list', formula1='"да"', allow_blank=True)
    sheet.add_data_validation(validation)
    validation.add(f'D2:D{max(2,sheet.max_row)}')


def read_review(file, album):
    with closing(load_workbook(file, data_only=False, read_only=True)) as book:
        meta = dict(book['Сводка'].values)
        if (meta.get('SHA-256 PDF') != album['source_pdf_sha256']
                or meta.get('Версия кандидатов') != review_digest(album['pages'])):
            raise ValueError('Таблица решений относится к другому PDF')
        rows = iter(book[SHEET].values)
        if tuple(next(rows)) != HEADERS:
            raise ValueError('Изменены колонки таблицы решений')
        candidates = {(p['pdf_page'], r['candidate_id']): (p, r)
                      for p in album['pages'] for r in p.get('geometry', {}).get('candidates', [])}
        result = []
        seen = set()
        for page, ident, role, approved, system, section, start, end, pieces, segment in rows:
            if approved in ('', None):
                continue
            if str(approved).strip().casefold() != 'да':
                raise ValueError('Для проверенных строк используйте отметку «да»')
            key = (page, ident)
            if key not in candidates or key in seen:
                raise ValueError(f'Кандидат не найден или указан повторно: {key}')
            seen.add(key)
            info, candidate = candidates[key]
            if role != info['geometry']['source_role'] or not isinstance(system, str) or not system.strip():
                raise ValueError(f'Проверьте систему и источник: {key}')
            if section and section not in {s['id'] for s in info['section_marks']}:
                raise ValueError(f'Проверьте ID сечения на листе: {key}')
            row = {'segment_id': segment or f'PDF-{page}-{ident}', 'system':system,
                   'system_approved': True, 'scope_approved': True,
                   'section_mark_id':section, 'section_approved':bool(section)}
            if pieces is not None:
                if type(pieces) is not int or pieces <= 0:
                    raise ValueError(f'Некорректное количество штук: {key}')
                row.update(piece_count=pieces,piece_count_approved=True)
            if role == 'floor_plan':
                row.update(kind='plan',plan_page=page,plan_candidate_id=ident,length_approved=True)
            elif role == 'riser_axonometry':
                marks = {m['id'] for m in info['elevation_marks']}
                if not start or not end or start == end or start not in marks or end not in marks:
                    raise ValueError(f'Для стояка нужны две разные отметки этого листа: {key}')
                row.update(kind='vertical',axonometry_page=page,riser_candidate_id=ident,start_mark_id=start,end_mark_id=end,
                           same_straight_axis=True,same_datum=True,marks_define_centerline_ends=True,
                           axonometry_bbox_pt=candidate['source']['bbox_pt'])
            else:
                raise ValueError(f'Неизвестный тип кандидата: {key}')
            result.append(row)
        return result
