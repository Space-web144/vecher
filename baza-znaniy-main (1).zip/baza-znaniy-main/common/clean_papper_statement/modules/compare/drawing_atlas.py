"""Render candidate frames on copies of the source sheets for review."""
from contextlib import ExitStack
from pathlib import Path
import fitz
from ..pdf.contact_register import atomic_output


def export_atlas(album, pdf_path, single_sheets, out):
    single = {int(number):Path(path) for number,path in single_sheets}
    with ExitStack() as stack:
        atlas = stack.enter_context(fitz.open())
        full = stack.enter_context(fitz.open(pdf_path)) if pdf_path else None
        contents = []
        for info in album['pages']:
            items = info.get('geometry',{}).get('candidates',[])
            if not items:
                continue
            number = info['pdf_page']
            if full:
                atlas.insert_pdf(full, from_page=number-1, to_page=number-1, links=False, annots=False)
            elif number in single:
                with fitz.open(single[number]) as src:
                    atlas.insert_pdf(src, from_page=0, to_page=0, links=False, annots=False)
            else:
                continue
            sheet = atlas[-1]
            contents.append([1, f"PDF {number} · {info['kind']}", len(atlas)])
            for candidate in items:
                rect = (candidate.get('source') or {}).get('bbox_pt')
                if not rect:
                    continue
                box = fitz.Rect(rect)
                annotation = sheet.add_rect_annot(box)
                annotation.set_colors(stroke=(0.95, 0.38, 0.03))
                annotation.set_border(width=.7)
                annotation.set_info(title=candidate['candidate_id'],content=f"PDF {number} / {candidate['candidate_id']}")
                annotation.update()
                sheet.insert_text((box.x0, max(6,box.y0-1)), candidate['candidate_id'],
                                  fontsize=6, color=(.62,.15,0), overlay=True)
        if not contents:
            raise ValueError('Нет доступных исходных страниц с кандидатами для атласа')
        atlas.set_toc(contents)
        atlas.set_metadata({'title':'CleanPapper · Обмер для инженерной проверки'})
        atomic_output(out, lambda dest:atlas.save(str(dest),garbage=3,deflate=True))
