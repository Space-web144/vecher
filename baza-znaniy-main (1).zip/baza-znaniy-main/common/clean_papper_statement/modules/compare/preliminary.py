"""Automatic provisional measurements; never approve geometry."""
import math
import re
from collections import Counter
from .connectivity import propagated

def _positive(v):
    return type(v) in (int,float) and math.isfinite(v) and v > 0

def _box(v):
    return isinstance(v,(tuple,list)) and len(v)==4 and all(type(x) in (int,float) and math.isfinite(x) for x in v)

def _distance(a,b):
    return math.hypot(max(a[0]-b[2],b[0]-a[2],0),max(a[1]-b[3],b[1]-a[3],0))

def _nearest(marks, box, key, limit=36, candidate=None, conflicts=None):
    if not _box(box):
        return None
    def distance(mark):
        a,b=(candidate or {}).get('center_start_pdf_pt'),(candidate or {}).get('center_end_pdf_pt')
        if isinstance(a,(list,tuple)) and isinstance(b,(list,tuple)) and len(a)==len(b)==2:
            x,y=(mark['bbox_pt'][0]+mark['bbox_pt'][2])/2,(mark['bbox_pt'][1]+mark['bbox_pt'][3])/2
            dx,dy=b[0]-a[0],b[1]-a[1]
            if dx*dx+dy*dy>0:
                t=max(0,min(1,((x-a[0])*dx+(y-a[1])*dy)/(dx*dx+dy*dy)))
                return math.hypot(x-a[0]-t*dx,y-a[1]-t*dy)
        return _distance(mark['bbox_pt'],box)
    ds=sorted(((distance(m),i,m) for i,m in enumerate(marks)
               if _box(m.get('bbox_pt')) and key(m) is not None),key=lambda x:x[:2])
    if not ds or ds[0][0]>limit:
        return None
    best=ds[0]
    if any(key(m)!=key(best[2]) and d<=limit and d<=best[0]+12 for d,_,m in ds[1:]):
        if conflicts is not None and candidate:
            conflicts.add(candidate['candidate_id'])
        return None
    return best[2]

def _size(m):
    if _positive(m.get('diameter_mm')):
        return (m['diameter_mm'],)
    if _positive(m.get('width_mm')) and _positive(m.get('height_mm')):
        return tuple(sorted((m['width_mm'],m['height_mm'])))
    return None

def provisional_segments(pages, reviewed=(), confirmed=()):
    ids={s['segment_id'] for s in confirmed}
    replaced={(r.get('plan_page') or r.get('axonometry_page'),r.get('plan_candidate_id') or r.get('riser_candidate_id'))
              for r in reviewed if r.get('segment_id') in ids}
    for s in confirmed:
        for src in s.get('sources',[]):
            if src.get('candidate_id'):
                replaced.add((src.get('pdf_page'),src['candidate_id']))
    output=[]
    for p in pages:
        geom=p.get('geometry',{})
        role=geom.get('source_role')
        if role not in ('floor_plan','riser_axonometry'):
            continue
        num=p['pdf_page']
        scope=p.get('floor_scope',{})
        floors=scope.get('floors',[])
        profile=geom.get('automatic_profile',{})
        scale=re.fullmatch(r'1:([1-9]\d*)',str(profile.get('nominal_scale','')))
        scale_source=profile.get('evidence',{}).get('scale_source')
        sections=[s for s in p.get('section_marks',[]) if s.get('context')=='standalone_section_label_candidate']
        hints=p.get('system_hints',[])
        candidates=geom.get('candidates',[])
        system_conflicts, section_conflicts=set(),set()
        direct_system={c['candidate_id']:_nearest(p.get('system_marks',[]),(c.get('source') or {}).get('bbox_pt'),lambda m:m.get('system'),45,candidate=c,conflicts=system_conflicts) for c in candidates}
        direct_section={c['candidate_id']:_nearest(sections,(c.get('source') or {}).get('bbox_pt'),_size,36,candidate=c,conflicts=section_conflicts) for c in candidates}
        linked_system=propagated(candidates,direct_system,lambda m:m.get('system'),blocked=system_conflicts) if role=='floor_plan' else {}
        linked_section=propagated(candidates,direct_section,_size,section=True,blocked=section_conflicts) if role=='floor_plan' else {}
        for c in candidates:
            cid=c['candidate_id']
            if (num,cid) in replaced:
                continue
            box=(c.get('source') or {}).get('bbox_pt')
            reasons=['Гипотеза; физический участок и отсутствие пересечений не проверены']
            source={'pdf_page':num,'candidate_id':cid,'bbox_pt':box,'source_stroke_ids':c.get('source_stroke_ids',[])}
            mark=direct_system.get(cid) or linked_system.get(cid)
            system=mark.get('system') if mark else None
            if role=='riser_axonometry' and len(hints)==1:
                if not system or system==hints[0]:
                    system=hints[0]
                    source['system_basis']='Единственная система в заголовке схемы'
                else:
                    system=None
            elif mark:
                source['system_basis']='Связная одноцветная цепочка с единственным обозначением' if cid in linked_system else 'Ближайшая однозначная подпись; соединение не доказано'
            if system is None:
                reasons.append('Система не определена однозначно')
            elif mark:
                source['system_mark']=mark
            section=direct_section.get(cid) or linked_section.get(cid)
            if section:
                source['section_mark_id']=section.get('id')
                source['section_basis']='Связная цепочка одинаковой ширины' if cid in linked_section else 'Ближайшая однозначная подпись'
            else:
                reasons.append('Сечение не определено однозначно')
            unit=total=multiplier=area=None
            if role=='floor_plan':
                if scale and scale_source in ('horizontal_dimension_ticks','printed_scale') and _positive(c.get('projected_length_pt')):
                    unit=c['projected_length_pt']*int(scale[1])*0.0254/72
                    source.update(scale=scale[0],scale_source=scale_source,projected_length_pt=c['projected_length_pt'])
                    if scale_source=='printed_scale':
                        reasons.append('Масштаб указан на листе; геометрическая калибровка не подтверждена')
                    if floors and scope.get('source') in ('printed_floor','printed_range'):
                        multiplier=len(floors)
                        total=unit*multiplier
                        source['floor_scope']=scope.get('source')
                    else:
                        reasons.append('Кратность этажей не доказана; указана длина одного изображения')
                        if scope.get('source')=='inferred_between_plans':
                            source['possible_floor_count']=len(floors)
                else:
                    reasons.append('Нет масштаба по размерным линиям')
            else:
                if _box(box):
                    top=[box[0],box[1],box[2],box[1]]
                    bottom=[box[0],box[3],box[2],box[3]]
                    levels=p.get('elevation_marks',[])
                    a=_nearest(levels,top,lambda m:m.get('level_m'),28)
                    b=_nearest(levels,bottom,lambda m:m.get('level_m'),28)
                    if a and b and a.get('id')!=b.get('id') and a['level_m']!=b['level_m']:
                        unit=total=abs(a['level_m']-b['level_m'])
                        multiplier=1
                        source['level_mark_ids']=[a['id'],b['id']]
                        source['levels_m']=[a['level_m'],b['level_m']]
                        reasons.append('Разность ближайших отметок; общую ось стояка нужно подтвердить')
                if unit is None:
                    reasons.append('Нет однозначной пары высотных отметок; длина не рассчитана')
            if total is not None and section:
                size=_size(section)
                if size:
                    area=(math.pi*size[0]/1000 if len(size)==1 else 2*sum(size)/1000)*total
            if geom.get('candidate_list_limited'):
                reasons.append('Выборка геометрии неполная')
            output.append({'segment_id':f'AUTO-{num:03d}-{cid}','kind':'plan' if role=='floor_plan' else 'vertical',
                           'system':system,'section_source':section,'unit_length_m':round(unit,6) if unit is not None else None,
                           'floor_multiplier':multiplier,'length_m':round(total,6) if total is not None else None,
                           'surface_m2':round(area,6) if area is not None else None,'pieces':None,
                           'sources':[source],'status':'preliminary' if unit is not None else 'review_required','reasons':reasons})
    pairs=Counter((s['sources'][0]['pdf_page'],tuple(sorted(s['sources'][0]['level_mark_ids'])))
                  for s in output if 'level_mark_ids' in s['sources'][0])
    for s in output:
        src=s['sources'][0]
        if 'level_mark_ids' in src and pairs[(src['pdf_page'],tuple(sorted(src['level_mark_ids'])))]>1:
            s.update(length_m=None,unit_length_m=None,floor_multiplier=None,surface_m2=None,status='review_required')
            s['reasons'].append('Пара отметок относится к нескольким кандидатам; исключена из суммы')
    return output
