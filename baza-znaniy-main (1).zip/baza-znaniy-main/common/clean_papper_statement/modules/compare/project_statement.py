"""Create a project takeoff, drawing register and row-level Excel reconciliation."""
import argparse
from collections import Counter, defaultdict
from ..digest import sha256_stream
import json
import math
from pathlib import Path
import re

from openpyxl import Workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.utils import get_column_letter

from .control_workbook import reference_rows
from .preliminary import provisional_segments
from .connectivity import fitting_candidates
from .design_specification import category
from .statement_review import add_review, read_review, review_digest
from ..pdf.album_geometry import local_geometry_reader
from ..pdf.contact_register import atomic_output
from ..pdf.floor_scope import attach_floor_scopes
from ..pdf.project_album import analyze_album, _segment_rows
from ..pdf.review_evidence import attach_review_evidence


def digest(path):
    with path.open('rb') as stream:
        return sha256_stream(stream)


def section_key(text):
    sizes = re.findall(r'(?<!\d)(\d{2,4})\s*[xх×]\s*(\d{2,4})(?!\d)', text, re.I)
    diameters = re.findall(r'[ØøФф⌀]\s*(\d{2,4})(?!\d)', text)
    keys = {tuple(sorted((int(w), int(h)))) for w, h in sizes} | {(int(d),) for d in diameters}
    return keys.pop() if len(keys) == 1 else None


def reconcile(reference, segments, coverage):
    matches = defaultdict(list)
    for i, row in enumerate(reference):
        if row['duct'] and (section := section_key(row['name'])) and row['system']:
            matches[row['system'], section].append(i)
    assigned = defaultdict(list)
    unlinked = []
    for s in segments:
        section = s.get('section_source') or {}
        candidates = matches.get((s['system'], section_key(section.get('raw', ''))), [])
        if len(candidates) == 1:
            assigned[candidates[0]].append(s)
        else:
            unlinked.append((s['segment_id'], len(candidates)))
    output = []
    for i, row in enumerate(reference):
        members = assigned[i]
        actual = row['actual']
        measured, delta = [], []
        complete = (row['sheet'], row['row']) in coverage
        for field, expected in zip(('length_m', 'pieces', 'surface_m2'), actual):
            values = [s.get(field) for s in members]
            subtotal = math.fsum(values) if values and all(v is not None for v in values) else None
            measured.append(subtotal)
            delta.append(round(subtotal-expected, 6) if complete and subtotal is not None and expected is not None else None)
        if row['uncertain']:
            status = 'Проверить смещение колонок'
        elif not members:
            status = 'Нет однозначного обмера'
        elif not complete:
            status = 'Совпали система и сечение. Проверить полноту и материал'
        elif any(v is not None and v != 0 for v in delta):
            status = 'Расхождение'
        elif any(v is not None and d is None for v, d in zip(actual, delta)):
            status = 'Не все величины измерены'
        elif any(v is not None for v in delta):
            status = 'Совпадает'
        else:
            status = 'Нет сравнимых величин'
        output.append((row, members, measured, delta, status))
    return output, unlinked


def load_project(pdf, snapshot, sheet_paths, review, *, geometry_budget_s=math.inf, progress=None):
    if pdf:
        return analyze_album(pdf, review, geometry_reader=local_geometry_reader, geometry_budget_s=geometry_budget_s, progress=progress)
    data = json.loads(snapshot.read_text())
    if data.get('mode') != 'album' or data.get('page_count') != len(data['pages']):
        raise ValueError('Некорректный сохранённый отчёт альбома')
    pages = {p['pdf_page']: p for p in data['pages']}
    if set(pages) != set(range(1, data['page_count']+1)):
        raise ValueError('Нарушена нумерация страниц')
    attach_floor_scopes(data['pages'])
    for num, path in sheet_paths:
        original = pages[int(num)]
        local = analyze_album(Path(path), geometry_reader=local_geometry_reader, geometry_budget_s=math.inf)
        sheet = local['pages'][0]
        if (local['page_count'] != 1 or not sheet['title_evidence'] or
                any(original[k] != sheet[k] for k in ('kind','rotation','page_bounds_pt','title_evidence','system_hints'))):
            raise ValueError(f'Исходный лист расходится с описанием страницы {num}')
        if not any('diameter_mm' in mark for mark in original['section_marks']):
            for mark in sheet['section_marks']:
                if 'diameter_mm' in mark:
                    original['section_marks'].append({**mark, 'id': f"D{int(num):03d}-" + mark['id'].split('-')[1]})
        original['geometry'] = sheet.get('geometry', {})
        original['single_sheet_source'] = {'sha256': local['source_pdf_sha256'], 'name': Path(path).name}
        # Candidate frames and annotation IDs refer to this one-page source.
    if review is not None:
        if review.get('source_pdf_sha256') != data['source_pdf_sha256'] or review.get('page_kinds'):
            raise ValueError('Для изменения классификации или версии нужен исходный PDF')
        rows = review.get('segments', [])
        segments = _segment_rows(rows, pages)
        attach_review_evidence(rows, segments, pages)
        data['calculation']['segments'] = segments
    return data


def workbook(album, reference_file, review, source, previous=()):
    reference_warnings = []
    has_reference = reference_file is not None
    reference = list(reference_rows(reference_file, warnings=reference_warnings)) if has_reference else []
    album.setdefault('processing_issues', []).extend(reference_warnings)
    sha = digest(reference_file) if has_reference else None
    coverage = set()
    if review and review.get('complete_reference_rows') and has_reference:
        if review.get('reference_sha256') != sha:
            raise ValueError('Подтверждение полноты относится к другой версии Excel')
        valid = {(r['sheet'], r['row']) for r in reference}
        for item in review['complete_reference_rows']:
            key = (item['sheet'], item['row'])
            if key not in valid:
                raise ValueError('Строка подтверждения отсутствует в эталоне')
            coverage.add(key)
    segments = album['calculation']['segments']
    preliminary = provisional_segments(album['pages'], previous or (review or {}).get('segments', []), segments)
    album['calculation']['preliminary_segments'] = preliminary
    fittings = fitting_candidates(album['pages'], [*segments, *preliminary])
    album['calculation']['fitting_candidates'] = fittings
    comparison, unlinked = reconcile(reference, segments, coverage) if has_reference else ([], [])
    book = Workbook()
    summary = book.active
    summary.title = 'Сводка'
    def sheet(name, headers):
        tab = book.create_sheet(name)
        tab.append(headers)
        return tab
    summary.append(['Показатель', 'Значение'])
    summary.append(['Версия кандидатов', review_digest(album['pages'])])
    summary.append(['Сверка с эталоном', ('Частичная / не выполнена: см. замечания' if reference_warnings else 'Колонки определены; полнота объёмов требует проверки') if has_reference else 'Не запрошена — самостоятельный расчёт по PDF'])
    for warning in album.get('processing_issues', []):
        summary.append(['Замечание', warning])
    summary.append(['Как пользоваться', 'Ведомость содержит автоматические гипотезы и подтверждённые участки. Для подтверждения используйте вкладку «Заполнение инженером».'])
    summary.append(['Предварительные объёмы', 'Не сметные и не закупочные объёмы; возможны неполный обмер, ошибочные контуры и повторный учёт. Не суммировать с подтверждёнными объёмами без проверки.'])
    summary.append(['Автоматических кандидатов', len(preliminary)])
    summary.append(['Кандидатов с оценкой длины', sum(s['unit_length_m'] is not None for s in preliminary)])
    summary.append(['Кандидатов с определённой системой', sum(bool(s['system']) for s in preliminary)])
    summary.append(['Кандидатов с сечением', sum(bool(s.get('section_source')) for s in preliminary)])
    summary.append(['Гипотезы фасонных изделий по стыкам',len(fittings)])
    summary.append(['Строк проверенной проектной спецификации',len(album.get('design_specification_rows',[]))])
    summary.append(['Правило этажности','Множитель только по явному диапазону или номеру этажа; косвенный диапазон не умножает предварительный объём.'])
    if not preliminary and not segments:
        summary.append(['Замечание', 'Геометрические кандидаты не найдены; ведомость не содержит участков.'])
    summary.append(['Планы', 'Отметка подтверждает длину трассы и применение ко всем этажам этого плана.'])
    summary.append(['Стояки', 'Отметка подтверждает общий ноль и обе границы одной прямой оси на аксонометрии.'])
    summary.append(['Сечение и штуки', 'Заполняйте только проверенные сведения. Идентификаторы отметок и сечений приведены во вкладке «Основания».'])
    for row in [('Источник проекта', source), ('SHA-256 PDF', album['source_pdf_sha256']),
                ('Эталон', reference_file.name if has_reference else 'Не предоставлен (не требуется)'), ('SHA-256 Excel', sha), ('Страниц', album['page_count']),
                ('Страниц с распознанной геометрией', sum(p.get('geometry',{}).get('status')=='inspected' for p in album['pages'])),
                ('Строк эталона', len(reference) if has_reference else None), ('Участков с подтверждённой длиной', sum(s['status']=='approved' for s in segments)),
                ('Строк с числовой разницей', sum(any(v is not None for v in d) for _,_,_,d,_ in comparison) if has_reference else None)]:
        summary.append(row)
    quantities = sheet('Ведомость', ['Система','Участок','Тип','Сечение','Длина на один экземпляр, м','Множитель',
                                     'Длина всего, м','Кол-во шт.','Площадь, м²','Страницы PDF','Основание / координаты','Статус','Причины'])
    systems = defaultdict(list)
    for s in [*segments, *preliminary]:
        sources = s['sources']
        quantities.append([s['system'], s['segment_id'], s['kind'], (s.get('section_source') or {}).get('raw'),
                           s.get('unit_length_m', s['length_m']), s.get('floor_multiplier', 1), s['length_m'],
                           s.get('pieces'), s.get('surface_m2', s.get('rectangular_surface_m2')),
                           ', '.join(str(v) for v in sorted({a['pdf_page'] for a in sources})),
                           json.dumps(sources,ensure_ascii=False), {'approved':'Подтверждено','preliminary':'Предварительно','review_required':'Требуется проверка'}.get(s['status'],s['status']), ', '.join(s['reasons'])])
        systems[s['system'] or 'Не определена'].append(s)
    totals = sheet('По системам',['Система','Подтверждено план, м','Подтверждено стояки, м','Участков на проверке','Гипотеза план, м','Гипотеза стояки, м','Гипотеза площадь, м²','Без итоговой длины, шт.'])
    for system, rows in systems.items():
        def subtotal(kind):
            values = [s['length_m'] for s in rows if s['status']=='approved' and s['kind']==kind and s['length_m'] is not None]
            return sum(values) if values else None
        def estimate(field, kind=None):
            values = [s[field] for s in rows if s['status']=='preliminary' and (kind is None or s['kind']==kind) and s[field] is not None]
            return round(math.fsum(values),6) if values else None
        totals.append([system,subtotal('plan'),subtotal('vertical'),sum(s['status']!='approved' for s in rows),estimate('length_m','plan'),estimate('length_m','vertical'),estimate('surface_m2'),sum(s['length_m'] is None for s in rows)])
    evidence = sheet('Основания', ['Страница PDF','Вид','Основание расчёта','Координаты или ссылка на источник'])
    pages = sheet('Листы', ['Страница','Классификация','Заголовок','Этажи','Основание этажности','Масштаб','Основание масштаба',
                            'Геометрия','Кандидатов всего','Показано','SHA-256 отдельного листа'])
    candidates = sheet('Обмер для проверки',['Страница альбома','ID','Тип','Координаты PDF pt','Штрихи','Длина проекции, pt',
                                'По масштабу плана, м (гипотеза)','Диапазон стояка на рисунке, pt','Источник'])
    for p in album['pages']:
        geom = p.get('geometry',{}); profile=geom.get('automatic_profile',{}); scope=p.get('floor_scope',{})
        scale=profile.get('nominal_scale', 'unknown')
        pages.append([p['pdf_page'],p['kind'],' / '.join(dict.fromkeys(t['text'] for t in p['title_evidence'])),
                      ', '.join(map(str,scope.get('floors',[]))),scope.get('source'),scale,
                      profile.get('evidence',{}).get('scale_source'),geom.get('status','Нет обмера'),
                      geom.get('candidate_count'),len(geom.get('candidates',[])),p.get('single_sheet_source',{}).get('sha256')])
        for observation in scope.get('evidence', []):
            evidence.append([p['pdf_page'],scope['source'],observation['text'],
                             f"PDF {observation['pdf_page']}, {observation['bbox_pt']}"])
        for dim in profile.get('evidence',{}).get('dimensions',[]):
            evidence.append([p['pdf_page'],'Размерная линия',f"{dim['dimension_mm']} мм, масштаб 1:{dim['scale_ratio']}",
                             str(dim['ticks_pdf_pt'])])
        for mark in p.get('section_marks', []):
            evidence.append([p['pdf_page'],'Сечение',f"{mark['id']} · {mark['raw']}",str(mark['bbox_pt'])])
        for mark in p.get('elevation_marks', []):
            evidence.append([p['pdf_page'],'Высотная отметка',f"{mark['id']} · {mark['level_m']} м",str(mark['bbox_pt'])])
        for r in geom.get('candidates',[]):
            projected = r.get('projected_length_pt')
            estimated = (projected*int(scale[2:])*0.0254/72 if p['kind']=='plan' and projected is not None
                         and re.fullmatch(r'1:\d+',scale) else None)
            candidates.append([p['pdf_page'],r['candidate_id'],geom['source_role'],str((r.get('source') or {}).get('bbox_pt')),
                               str(r['source_stroke_ids']),projected,estimated,r.get('bounding_span_pt'),
                               p.get('single_sheet_source',{}).get('name',source)])
    fit_tab = sheet('Фасонка — обмер', ['Страница PDF','Система','Тип','Смежные участки','На плане, шт.','Явная кратность','Гипотеза, шт.','Статус'])
    for f in fittings:
        fit_tab.append([f['page'],f['system'],f['kind'],', '.join(f['candidate_ids']),f['per_plan'],f['multiplier'],f['quantity'],f['status']])
    if not fittings:
        fit_tab.append([None,None,None,None,None,None,None,'Однозначные кандидаты стыков не найдены; отсутствие записи не означает нулевое количество.'])
    design_tab = sheet('Проектные материалы', ['Раздел','Система / раздел спецификации','Позиция','Наименование','Тип / марка','Ед. изм.','Проектное количество','Страницы PDF','Статус'])
    equipment_tab = sheet('Оборудование — проект', ['Система / раздел спецификации','Позиция','Наименование','Тип / марка','Ед. изм.','Проектное количество','Страницы PDF','Статус'])
    equipment_labels = sheet('Оборудование — чертежи', ['Страница PDF','ID подписи','Обозначение','Координаты PDF','Количество','Статус'])
    for p in album['pages']:
        for mark in p.get('equipment_marks', []):
            equipment_labels.append([p['pdf_page'],mark['id'],mark['raw'],str(mark['bbox_pt']),None,'Текстовая подпись; физическое изделие и количество не подтверждены'])
    if equipment_labels.max_row==1:
        equipment_labels.append([None,None,None,None,None,'Текстовые обозначения не найдены. Это не означает отсутствие оборудования.'])
    for row in album.get('design_specification_rows', []):
        f=row['fields']
        cat=category(f.get('NAME'))
        values=[f.get('SECTION'),f.get('POS'),f.get('NAME'),f.get('TYPE'),f.get('UNIT'),f.get('QTY'),
                ', '.join(map(str,row['album_pdf_pages'])),'Из проверенной проектной спецификации; не обмер по чертежу']
        design_tab.append([cat,*values])
        if cat=='Оборудование':
            equipment_tab.append(values)
    if equipment_tab.max_row==1:
        equipment_tab.append([None,None,None,None,None,None,None,'Оборудование не извлечено; количество неизвестно.'])
    if design_tab.max_row==1:
        design_tab.append([None,None,None,None,None,None,None,None,'Проектная спецификация недоступна или не прошла проверку.'])
    diagnostic_rows=album.get('claude_diagnostics',[])
    if diagnostic_rows:
        diag=sheet('Claude — диагностика',['Лист PDF','Код','Результат'])
        for d in diagnostic_rows:
            diag.append([d['page'],d['code'],d['message']])
    vision_rows = album.get('claude_evidence', [])
    if vision_rows:
        ai = sheet('Claude — проверка', ['Страница PDF','Тип','Описание','Размер','Система','Уверенность ИИ','Совпадение размера с PDF','Замечание','Статус'])
        for item in vision_rows:
            for element in item.get('elements', []):
                ai.append([item['page'], element['type'], element['label'], element['dimension'],
                           element['system'], element['confidence'], element.get('pdf_dimension_match',''),
                           element['note'], 'Гипотеза; не включена в утверждённые объёмы'])
            for note in item.get('notes', []):
                ai.append([item['page'], 'Замечание', None, None, None, None, None, note, 'Требуется проверка'])
    if has_reference:
        compare = sheet('Сверка с эталоном',['Лист Excel','Строка','Система','Позиция','Ячейки эталона','ФАКТ, м','Шт. эталон','м² эталон',
                              'Обмер, м','Обмер, шт.','Обмер, м²','Δ м','Δ шт.','Δ м²','Участки','Результат'])
        for r, members, actual, difference, status in comparison:
            compare.append([r['sheet'],r['row'],r['system'],r['name'],r['cells'],*r['actual'],*actual,*difference,
                            ', '.join(s['segment_id'] for s in members),status])
        for state,count in Counter(row[-1] for row in comparison).items():
            summary.append([state,count])
        for segment,count in unlinked:
            summary.append([f'Участок {segment} · вариантов строки эталона',count])
        draft = sheet('Предварительная сверка', ['Участок','Система','Сечение','Оценка длины, м','Оценка площади, м²','Лист эталона','Строка эталона','Статус'])
        lookup = defaultdict(list)
        for row in reference:
            if row['duct'] and row['system'] and section_key(row['name']):
                lookup[(row['system'],section_key(row['name']))].append(row)
        for s in preliminary:
            section = (s.get('section_source') or {}).get('raw','')
            hits = lookup.get((s['system'],section_key(section)),[]) if s['system'] and section_key(section) else []
            match = hits[0] if len(hits)==1 else {}
            draft.append([s['segment_id'],s['system'],section,s['length_m'],s['surface_m2'],match.get('sheet'),match.get('row'),'Кандидат соответствия; проверить материал и полноту' if match else 'Нет однозначного соответствия'])
    add_review(book, album['pages'], previous)
    for tab in book:
        tab.freeze_panes='A2'
        tab.auto_filter.ref=tab.dimensions
        for cell in tab[1]:
            cell.font=Font(color='FFFFFF',bold=True)
            cell.fill=PatternFill('solid',fgColor='244D46')
            tab.column_dimensions[get_column_letter(cell.column)].width=min(65,max(16,len(cell.value)+4))
        for row in tab:
            for cell in row:
                if cell.data_type in ('e','f'):
                    cell.data_type='s'
    from openpyxl.worksheet.hyperlink import Hyperlink
    for tab in (candidates, evidence):
        for cells in tab.iter_rows(min_row=2):
            cell = cells[0]
            cell.hyperlink = Hyperlink(ref=cell.coordinate, location=f"'Листы'!A{cell.value+1}")
            cell.style = 'Hyperlink'
    if has_reference:
        compare.column_dimensions['D'].width=75
    quantities.column_dimensions['K'].width=65
    quantities.column_dimensions['M'].width=65
    return book


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    source=parser.add_mutually_exclusive_group(required=True)
    source.add_argument('--pdf',type=Path)
    source.add_argument('--snapshot',type=Path)
    parser.add_argument('--sheet',action='append',nargs=2,default=[],metavar=('PAGE','PDF'))
    parser.add_argument('--reference',type=Path,help='Необязательный эталон Excel для сверки')
    parser.add_argument('--review',type=Path)
    parser.add_argument('--review-xlsx',type=Path)
    parser.add_argument('--atlas',type=Path,help='PDF с областями кандидатов на исходных чертежах')
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    if args.pdf and args.sheet:
        parser.error('--sheet применяется только к сохранённому отчёту')
    inputs = [args.pdf,args.snapshot,args.review,args.review_xlsx,args.reference,*[Path(p) for _,p in args.sheet]]
    outputs = [p.resolve() for p in (args.out,args.atlas) if p]
    if len(set(outputs)) != len(outputs) or set(outputs) & {p.resolve() for p in inputs if p}:
        parser.error('Укажите отдельный файл для результата')
    try:
        review=json.loads(args.review.read_text()) if args.review else None
        data=load_project(args.pdf,args.snapshot,args.sheet,review)
        previous = []
        if args.review_xlsx:
            if not review and data['calculation']['segments']:
                raise ValueError('Для дополнения прежних участков укажите их исходную разметку --review')
            previous = read_review(args.review_xlsx, data)
            rows = list((review or {}).get('segments', [])) + previous
            pages = {page['pdf_page']: page for page in data['pages']}
            data['calculation']['segments'] = _segment_rows(rows, pages)
            attach_review_evidence(rows, data['calculation']['segments'], pages)
        book=workbook(data,args.reference,review,(args.pdf or args.snapshot).name,previous)
        atomic_output(args.out,book.save)
        if args.atlas:
            from .drawing_atlas import export_atlas
            export_atlas(data,args.pdf,args.sheet,args.atlas)
    except (OSError,ValueError,TypeError,KeyError) as exc:
        parser.exit(1,f'{exc}\n')


if __name__=='__main__':
    main()
