"""Extract the verified project specification, independently of measured quantities."""
import json
import subprocess
import sys
from pathlib import Path
from tempfile import TemporaryDirectory
import re
import time

ROOT=Path(__file__).resolve().parents[4]

def category(name):
    text=str(name or '').casefold()
    if re.search(r'\b(отвод|переход|тройник|крестовина|заглушка|врезка|утка|колено)\b',text):
        return 'Фасонные изделия'
    if re.search(r'\b(воздуховод|воздуховоды)\b',text):
        return 'Воздуховоды'
    if re.search(r'\b(вентилятор|клапан|реш[её]тк\w*|диффузор|фильтр|шумоглушитель|воздухонагреватель|дроссел\w*|установк\w*|агрегат|воздухораспределител\w*)\b',text):
        return 'Оборудование'
    return 'Другие материалы'

def read_design_specification(source, album, timeout=100):
    ranges=album.get('specification_inventory',{}).get('candidates',[])
    if len(ranges)!=1:
        return [],'Спецификация проекта: диапазон не определён однозначно; проектные количества не подставлены.'
    if timeout<15:
        return [],'Спецификация проекта: недостаточно времени в пределах лимита задания.'
    first,last=ranges[0]['first'],ranges[0]['last']
    start=time.monotonic()
    try:
        with TemporaryDirectory(prefix='cp-spec-') as tmp:
            workspace=Path(tmp)
            # Native extraction and the existing verification gate; no model or network calls.
            subprocess.run([sys.executable,'-B','-m','common.clean_papper_pipeline','prepare',
                            '--pdf',str(source),'--workspace',str(workspace),'--pages',str(first),str(last)],
                           cwd=ROOT,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
                           check=True,timeout=min(35,timeout))
            stage=workspace/album['source_pdf_sha256']/('specification-%03d-%03d'%(first,last))
            output=workspace/'result'
            output.mkdir()
            remaining=timeout-(time.monotonic()-start)
            if remaining<5:
                raise subprocess.TimeoutExpired('native',timeout)
            subprocess.run([sys.executable,'-B','-m','common.clean_papper_pipeline','_native-worker',str(stage),str(output)],
                           cwd=ROOT,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
                           check=True,timeout=remaining)
            data=json.loads((output/'specification_rows.json').read_text(encoding='utf-8'))
            proof=json.loads((output/'verification.json').read_text(encoding='utf-8'))
            if (data.get('source_pdf_sha256')!=album['source_pdf_sha256'] or
                proof.get('protocol',{}).get('ok') is not True or
                data.get('specification_sha256')!=proof.get('specification_sha256') or
                data.get('row_count')!=len(data.get('rows',[])) or not data.get('rows')):
                return [],'Спецификация проекта: проверка происхождения или полноты не пройдена.'
            return data['rows'],None
    except subprocess.TimeoutExpired:
        return [],'Спецификация проекта: превышен лимит времени извлечения.'
    except (OSError,ValueError,KeyError,subprocess.CalledProcessError):
        return [],'Спецификация проекта: штатная проверка VentSpec не пройдена; проектные количества не подставлены.'
