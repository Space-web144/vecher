"""Conservative connectivity hints for draft takeoff. No crossing-only joins."""
import math
from collections import defaultdict

def _point(p):
    return isinstance(p,(list,tuple)) and len(p)==2 and all(type(v) in (int,float) and math.isfinite(v) for v in p)

def _ends(c):
    a,b=c.get('center_start_pdf_pt'),c.get('center_end_pdf_pt')
    return (a,b) if _point(a) and _point(b) else None

def _width(c):
    v=c.get('width_between_strokes_pt')
    return v if type(v) in (int,float) and v>0 and math.isfinite(v) else None

def _same_width(a,b):
    x,y=_width(a),_width(b)
    return x is not None and y is not None and abs(x-y)<=max(.45,.08*max(x,y))

def topology(candidates):
    """Endpoint-to-endpoint only, same actual stroke color, capped join distance."""
    nodes=defaultdict(list)
    endpoints={}
    for c in candidates:
        ends=_ends(c)
        if not ends or not c.get('stroke_color'):
            continue
        cid=c['candidate_id']
        for i,p in enumerate(ends):
            key=(cid,i)
            endpoints[key]=(c,p)
            nodes[(math.floor(p[0]/8),math.floor(p[1]/8),c['stroke_color'])].append(key)
    parent={k:k for k in endpoints}
    def root(k):
        while parent[k]!=k:
            parent[k]=parent[parent[k]]
            k=parent[k]
        return k
    for key,(c,p) in endpoints.items():
        x,y=math.floor(p[0]/8),math.floor(p[1]/8)
        for dx in (-1,0,1):
            for dy in (-1,0,1):
                for other in nodes.get((x+dx,y+dy,c['stroke_color']),()):
                    d,q=endpoints[other]
                    if key[0]==other[0] or other<=key:
                        continue
                    gap=min(8,max(3.5,((_width(c) or 0)+(_width(d) or 0))*.25))
                    if math.dist(p,q)<=gap:
                        parent[root(other)]=root(key)
    groups=defaultdict(list)
    for key in endpoints:
        groups[root(key)].append(key)
    # Reject transitive clusters with widely separated points, and both ends of one segment.
    junctions=[]
    for group in groups.values():
        if len(group)<2 or len({k[0] for k in group})!=len(group) or len(group)>4:
            continue
        points=[endpoints[k][1] for k in group]
        if any(math.dist(a,b)>8 for a in points for b in points):
            continue
        junctions.append(group)
    return junctions

def propagated(candidates, direct, key, *, section=False, blocked=()):
    by_id={c['candidate_id']:c for c in candidates}
    adj=defaultdict(set)
    for group in topology(candidates):
        # Sections propagate only along nonbranching, equal-width paths.
        if section and len(group)!=2:
            continue
        for a,_ in group:
            for b,_ in group:
                if a!=b and (not section or _same_width(by_id[a],by_id[b])):
                    adj[a].add(b)
    seen=set()
    output={}
    for cid in by_id:
        if cid in seen:
            continue
        stack=[cid]; group=[]
        while stack:
            cur=stack.pop()
            if cur in seen: continue
            seen.add(cur); group.append(cur); stack.extend(adj[cur]-seen)
        seeds=[direct[c] for c in group if c in direct and direct[c] is not None]
        values={key(s) for s in seeds}
        if len(values)==1 and seeds and not any(c in blocked for c in group):
            for c in group:
                if direct.get(c) is None:
                    output[c]=seeds[0]
    return output

def fitting_candidates(pages, segments):
    """Count possible joins, not independently confirmed physical fittings."""
    indexed={(s['sources'][0]['pdf_page'],s['sources'][0].get('candidate_id')):s
             for s in segments if s.get('sources')}
    output=[]
    for p in pages:
        if p.get('kind')!='plan':
            continue
        rows=p.get('geometry',{}).get('candidates',[])
        by_id={r['candidate_id']:r for r in rows}
        scope=p.get('floor_scope',{})
        multiplier=len(scope.get('floors',[])) if scope.get('source') in ('printed_floor','printed_range') else None
        for group in topology(rows):
            members=[indexed.get((p['pdf_page'],cid)) for cid,_ in group]
            if not all(members):
                continue
            systems={s.get('system') for s in members}
            if len(systems)!=1 or None in systems:
                continue
            kind=None
            if len(group)==3:
                kind='Тройник / ответвление'
            elif len(group)==2:
                vectors=[]
                for cid,i in group:
                    ends=_ends(by_id[cid])
                    a,b=ends[i],ends[1-i]
                    d=math.dist(a,b)
                    if not d: break
                    vectors.append(((b[0]-a[0])/d,(b[1]-a[1])/d))
                if len(vectors)==2:
                    angle=math.degrees(math.acos(max(-1,min(1,sum(a*b for a,b in zip(*vectors))))))
                    if 30<=angle<=150 and _same_width(by_id[group[0][0]],by_id[group[1][0]]):
                        kind='Отвод'
                    elif angle>=165 and not _same_width(by_id[group[0][0]],by_id[group[1][0]]):
                        kind='Переход'
            if kind:
                output.append({'page':p['pdf_page'],'system':next(iter(systems)),'kind':kind,
                               'candidate_ids':[cid for cid,_ in group],'per_plan':1,'multiplier':multiplier,
                               'quantity':multiplier,'status':'Гипотеза по стыку осей; проверить реальный элемент'})
    return output
