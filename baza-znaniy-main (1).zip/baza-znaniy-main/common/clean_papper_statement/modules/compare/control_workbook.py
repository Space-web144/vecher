"""Read ventilation control workbook sheets using verified header layouts."""
from contextlib import ExitStack, closing
import math
import re

from openpyxl import load_workbook
from openpyxl.utils import get_column_letter


def code(value):
    text = re.sub(r'\s+', '', str(value or '')).upper().replace('–', '-')
    one = r'(?:ДП|ДВ|П|ВЕ|В)\d+(?:[.,]\d+)?(?:-\d+)?'
    if re.fullmatch(one + '(?:[-,;/]' + one + ')*', text):
        return text


def _header_text(value):
    return re.sub(r'[\W_]+', '', str(value or '').casefold().replace('ё', 'е'))


def _label(value):
    text = _header_text(value)
    if text in ('факт', 'фактм', 'фактмп', 'фактдлина', 'фактмпог'):
        return 'length'
    if text in ('колвошт', 'количествошт', 'шт', 'фактшт', 'количествофактшт'):
        return 'pieces'
    if text in ('колвоквм', 'колвоквм2', 'колвоквм²', 'колвом2', 'колвом²', 'количествоквм', 'площадьм2', 'площадьм²', 'квм', 'м2', 'м²', 'фактм2', 'фактм²'):
        return 'area'
    if (text.startswith('наименование') or text in ('материал','наименованиематериала','описаниепозиции')) and '1с' not in text and '1c' not in text and 'систем' not in text:
        return 'name'
    if text in ('наименованиесистемы', 'наименованиесистем', 'система', 'системы', 'обозначениесистемы'):
        return 'system'
    if text in ('позиция', 'поз', 'номерпозиции'):
        return 'position'


def _layout(sheet, title):
    """Resolve fact columns from header evidence, never infer a shifted triple blindly."""
    rows = list(sheet.iter_rows(min_row=1, max_row=min(15, sheet.max_row or 15), values_only=True))
    legacy = {'Общеобменная': 2, 'Дымоудаление': 1}.get(title.strip())
    # Prefer header evidence over fixed column numbers, including old sheet titles.
    for index, row in enumerate(rows):
        for fact, value in enumerate(row):
            if _label(value) != 'length':
                continue
            band = rows[max(0, index-2):index+3]
            def has(col, label):
                return any(col < len(line) and _label(line[col]) == label for line in band)
            # Require independent labels for quantity and area, in the fact group.
            if not (has(fact+1, 'pieces') and has(fact+2, 'area')):
                continue
            names = {i for line in band for i, cell in enumerate(line) if _label(cell) == 'name'}
            systems = {i for line in band for i, cell in enumerate(line) if _label(cell) == 'system'}
            positions = {i for line in band for i, cell in enumerate(line) if _label(cell) == 'position'}
            if len(names) != 1 or len(systems) > 1 or len(positions) > 1:
                continue
            bottom = max(i+1 for i, line in enumerate(rows) if abs(i-index) <= 2 and
                         any(col < len(line) and _label(line[col]) == label
                             for col, label in ((fact,'length'),(fact+1,'pieces'),(fact+2,'area'))))
            name_col = next(iter(names))
            system_col = next(iter(systems), None)
            return bottom, next(iter(positions), 0), name_col, system_col, fact, bool(legacy and name_col==1 and fact==11 and bottom==legacy and system_col in (None,9))
    if legacy and len(rows) >= legacy and len(rows[legacy-1]) >= 14 and _label(rows[legacy-1][11]) == 'length' and any(len(row)>1 and _label(row[1])=='name' for row in rows[:legacy]):
        return legacy,0,1,9,11,True
    for index,row in enumerate(rows):
        names=[i for i,v in enumerate(row) if _label(v)=='name']
        if len(names)!=1:
            continue
        positions=[i for i,v in enumerate(row) if _label(v)=='position']
        systems=[i for i,v in enumerate(row) if _label(v)=='system']
        return index+1, positions[0] if len(positions)==1 else None, names[0], systems[0] if len(systems)==1 else None, None,False
    return None


def reference_rows(path, warnings=None):
    """Read any sheet with a supported fact layout; report skipped sheets explicitly."""
    with ExitStack() as stack:
        formulas, cached = [stack.enter_context(closing(load_workbook(path, read_only=True, data_only=v)))
                            for v in (False, True)]
        accepted = 0
        for title in formulas.sheetnames:
            layout = _layout(formulas[title], title)
            if layout is None:
                if warnings is not None:
                    warnings.append(f'Лист «{title}»: колонки факта, количества и площади не определены; сверка этого листа пропущена.')
                continue
            header, position, name_col, system_col, fact, legacy = layout
            if fact is None and warnings is not None:
                warnings.append(f'Лист «{title}»: извлечены наименования, но столбцы фактических итогов не определены; числовые значения не подставлены.')
            rows, shifted_blocks = [], set()
            system = None
            def get(row, i):
                return row[i] if i is not None and i < len(row) else None
            for n, (f, v) in enumerate(zip(formulas[title].values, cached[title].values, strict=True), 1):
                if n <= header:
                    continue
                system = code(get(f, position)) or system
                name = get(v,name_col) if isinstance(get(f,name_col),str) and get(f,name_col).startswith('=') else get(f,name_col)
                if not isinstance(name, str) or not name.strip() or _label(name)=='name':
                    continue
                shifted = legacy and title.strip() == 'Дымоудаление' and str(get(f,11)).replace('$','').upper() == f'=SUM(Q{n}:AT{n})'
                if shifted:
                    shifted_blocks.add(system)
                rows.append((n, system, code(get(f,system_col)) or system, f, v, shifted,name.strip()))
            if not rows:
                if warnings is not None: warnings.append(f'Лист «{title}»: заголовки найдены, но ни одной строки материала не прочитано.')
                continue
            accepted += 1
            for n, block, system, f, v, shifted,name in rows:
                uncertain = (legacy and block in shifted_blocks and not shifted and
                             any(get(v,j) is not None for j in range(10,14)) and
                             not re.fullmatch(fr'=SUM\([A-Z]+{n}:[A-Z]+{n}\)', str(get(f,12)).replace('$',''), re.I))
                cols = range(fact-1, fact+2) if shifted else range(fact, fact+3) if fact is not None else ()
                actual = [get(v,i) if not uncertain and type(get(v,i)) in (int,float) and math.isfinite(get(v,i))
                          else None for i in cols]
                if fact is None:
                    actual = [None,None,None]
                    uncertain = True
                duct = bool(re.match(r'^воздуховод\b', name, re.I))
                if not duct:
                    actual[0] = None
                yield {'sheet': title, 'row': n, 'system': system, 'name': name, 'duct': duct,
                       'cells': ', '.join(f'{get_column_letter(i+1)}{n}' for i in cols) if not uncertain else '',
                       'actual': actual, 'uncertain': uncertain}
        if not accepted:
            message = 'Из эталона не прочитано ни одной строки материала. Сформирован обмер без сверки с эталоном.'
            if warnings is None:
                raise ValueError(message)
            warnings.append(message)
