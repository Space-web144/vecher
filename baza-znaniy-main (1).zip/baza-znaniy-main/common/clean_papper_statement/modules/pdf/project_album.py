"""Read a complete project PDF and calculate its reviewed plan and axonometric runs."""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from ..digest import sha256_stream
import json
import math
from pathlib import Path
import re
import sys
from time import monotonic

from ..calc.confirmed_quantities import straight_duct_surface, vertical_length_from_levels
from .floor_scope import attach_floor_scopes, floor_interval
from .review_evidence import attach_review_evidence
from .schematic_evidence import collect_observations

MAX_BYTES = 100 * 1024 * 1024
MAX_PAGES = 600
MAX_REVIEW_BYTES = 96 * 1024
PAGE_KINDS = {'plan', 'axonometry', 'mixed', 'other'}
PLAN_TITLE = re.compile(r'^(?:план(?:ы)?\s+(?:[\w.,+−–()/-]+\s+)*вентиляц\w*|'
                        r'вентиляция[ .–-]+план\b|ventilation\s+plan\b)', re.I)
SCHEME_TITLE = re.compile(r'^(?:аксонометр\w*(?:\s+схем\w*)?|схем[аы]\s+'
                          r'(?:систем\w*|вентиляц\w*|(?:ДП|ДВ|П|В)\s*\d)|'
                          r'axonometric\s+(?:scheme|diagram))', re.I)
CONTENTS_TITLE = re.compile(r'^(?:ведомость рабочих чертежей основного комплекта|'
                            r'лист регистрации изменений|table of contents)\s*[.:]?$', re.I)
SYSTEM = re.compile(r'(?<![\w-])(?:ДП|ДВ|ВЕ|П|В)\s*\d+(?:[.,]\d+)?(?:\s*[-−–]\s*\d+)?\b', re.I)


class AlbumInputError(ValueError):
    """An invalid PDF or review with a message safe to show in the web form."""


def _system(value):
    if not isinstance(value, str):
        return ''
    return re.sub(r'\s+', '', value).upper().translate(str.maketrans({',': '.', '−': '-', '–': '-'}))


def _titles(words):
    grouped = defaultdict(list)
    for word in words:
        grouped[tuple(word[5:7])].append(word)
    matches = []
    for line in grouped.values():
        text = ' '.join(w[4] for w in sorted(line, key=lambda w: w[7]))
        if len(text) > 140:
            continue
        raw_text = text
        # Some CAD fonts expose Windows-1251 bytes as Latin-1 glyphs.
        if re.search(r'[À-ÿ]{2,}', text):
            try:
                text = text.encode('latin1').decode('cp1251')
            except UnicodeError:
                pass
        if CONTENTS_TITLE.fullmatch(text):
            kind = 'contents'
        elif PLAN_TITLE.match(text):
            kind = 'plan'
        elif SCHEME_TITLE.match(text):
            kind = 'axonometry'
        elif floor_interval(text) is not None:
            kind = 'floor_heading'
        else:
            continue
        bbox = [min(w[0] for w in line), min(w[1] for w in line),
                max(w[2] for w in line), max(w[3] for w in line)]
        match = {'text': text, 'bbox_pt': [round(v, 2) for v in bbox], 'kind': kind}
        if raw_text != text:
            match['raw_text'] = raw_text
        matches.append(match)
    return matches


def _indexed_observations(observations, prefix, page):
    distinct = {(tuple(row['bbox_pt']), row['raw']): row for row in observations}
    return [{'id': f'{prefix}{page:03d}-{index:03d}', **distinct[key]}
            for index, key in enumerate(sorted(distinct, key=lambda k: (k[0][1], k[0][0], k)), 1)]


def _scan_page(page, number, override, register_entry=None):
    from common.clean_papper_album_worker.modules.pdf.text_recovery import recover_words
    words, _ = recover_words(page.get_text('words', sort=False))
    titles = _titles(words)
    kinds = {title['kind'] for title in titles if title['kind'] != 'floor_heading'}
    if override:
        kind = override
    elif 'contents' in kinds:
        kind = 'other'
    elif kinds == {'plan', 'axonometry'}:
        kind = 'mixed'
    else:
        kind = next(iter(kinds), 'unclassified')
    via_register = False
    if not override and kind == 'unclassified' and register_entry and register_entry.get('title_verified_on_sheet'):
        registered_kind = register_entry.get('kind')
        if registered_kind in ('plan','axonometry','mixed','other') or str(registered_kind).startswith('conditioning_'):
            kind = 'other' if str(registered_kind).startswith('conditioning_') else registered_kind
            titles.append({'text': register_entry['title'], 'bbox_pt': [], 'kind': kind, 'source': 'drawing_register', 'source_pdf_page': register_entry['source']['pdf_page']})
            via_register = True
    system_marks = []
    if kind in ('plan','axonometry','mixed'):
        grouped = defaultdict(list)
        for word in words:
            grouped[tuple(word[5:7])].append(word)
        for line in grouped.values():
            ordered = sorted(line, key=lambda w:w[7])
            for i, word in enumerate(ordered):
                token = word[4]
                matched = SYSTEM.fullmatch(token)
                end = word
                if not matched and i+1 < len(ordered) and token.upper() in ('ДП','ДВ','ВЕ','П','В'):
                    next_word = ordered[i+1]
                    if 0 <= next_word[0]-word[2] <= 18:
                        matched = SYSTEM.fullmatch(token + ' ' + next_word[4])
                        end = next_word
                if matched:
                    system_marks.append({'system': _system(matched[0]), 'bbox_pt': [word[0], min(word[1],end[1]), end[2], max(word[3],end[3])]})
    heights, sections = collect_observations(words) if kind in PAGE_KINDS - {'other'} else ([], [])
    circular = []
    equipment_marks = []
    if kind in ('plan', 'axonometry', 'mixed'):
        # Extract separate CAD text tokens such as "250", "×", "150" or "Ø", "160".
        grouped_words = defaultdict(list)
        for word in words:
            grouped_words[tuple(word[5:7])].append(word)
        for line in grouped_words.values():
            ordered = sorted(line, key=lambda w:w[7])
            for i, word in enumerate(ordered):
                for count in (2,3):
                    part=ordered[i:i+count]
                    if len(part)!=count or any(b[0]-a[2]>12 or b[0]<a[0] for a,b in zip(part,part[1:])):
                        continue
                    joined=''.join(w[4] for w in part)
                    size=re.fullmatch(r'(\d{2,4})[xх×](\d{2,4})',joined,re.I)
                    diameter=re.fullmatch(r'[Øø⌀ФфДд](\d{2,4})',joined)
                    box=[round(min(w[0] for w in part),2),round(min(w[1] for w in part),2),
                         round(max(w[2] for w in part),2),round(max(w[3] for w in part),2)]
                    if size:
                        sections.append({'raw':joined,'width_mm':int(size[1]),'height_mm':int(size[2]),'bbox_pt':box,
                                         'context':'standalone_section_label_candidate'})
                    elif diameter:
                        circular.append({'raw':joined,'diameter_mm':int(diameter[1]),'bbox_pt':box,'context':'standalone_section_label_candidate'})
        # These are text mentions only. A label is not proof of a unique physical piece.
        for x0,y0,x1,y1,raw,*_ in words:
            if re.fullmatch(r'(?:вентилятор\w*|клапан\w*|реш[её]тк\w*|диффузор\w*|фильтр\w*|шумоглушител\w*|воздухонагревател\w*|дроссел\w*|(?:КЛОП|КПВ|КПС|КПУ|ВКР|ВР|ДПУ|РПП)[-–]?\d[\w.,xх×/()\-–]*)',raw,re.I):
                equipment_marks.append({'raw':raw,'bbox_pt':[round(x,2) for x in (x0,y0,x1,y1)]})
        for x0, y0, x1, y1, text, *_ in words:
            match = re.fullmatch(r'[Øø⌀ФфДд](\d{2,4})', text)
            if match:
                circular.append({'raw': text, 'diameter_mm': int(match[1]),
                                 'bbox_pt': [round(v, 2) for v in (x0, y0, x1, y1)],
                                 'context': 'standalone_section_label_candidate'})
    return {
        'pdf_page': number, 'kind': kind,
        'classification_source': 'review' if override else 'drawing_register_crosschecked' if via_register else 'printed_titles',
        'system_marks': system_marks,
        'equipment_marks': _indexed_observations(equipment_marks,'E',number),
        'has_extracted_text': bool(words), 'rotation': page.rotation,
        'page_bounds_pt': list(page.rect * page.derotation_matrix),
        'title_evidence': titles,
        'system_hints': sorted({_system(code) for title in titles if title['kind'] == 'axonometry'
                                for code in SYSTEM.findall(title['text'])}) if kind in ('axonometry', 'mixed') else [],
        'elevation_marks': _indexed_observations(heights, 'M', number) if kind in ('axonometry', 'mixed') else [],
        'section_marks': _indexed_observations(sections, 'S', number) + _indexed_observations(circular, 'D', number),
    }


def _review_page_kinds(review, count):
    values = review.get('page_kinds', {})
    if not isinstance(values, dict) or any(not isinstance(k, str) or
        not re.fullmatch(r'[1-9][0-9]{0,2}', k) or int(k) > count or
        not isinstance(v, str) or v not in PAGE_KINDS for k, v in values.items()):
        raise AlbumInputError('Разметка содержит недопустимый номер или тип страницы.')
    return {int(k): v for k, v in values.items()}


def _page_number(value):
    return value if type(value) is int else None


def _plan_location(segment, pages):
    page = pages.get(_page_number(segment.get('plan_page')))
    box = segment.get('plan_bbox_pt')
    if not page or page['kind'] not in ('plan', 'mixed') or not isinstance(box, list) or len(box) != 4:
        return None
    if not all(type(v) in (int, float) and math.isfinite(v) for v in box):
        return None
    x0, y0, x1, y1 = box
    left, top, right, bottom = page['page_bounds_pt']
    if not (left <= x0 < x1 <= right and top <= y0 < y1 <= bottom):
        return None
    return {'pdf_page': page['pdf_page'], 'bbox_pt': box}


def _cad_measurement(value):
    if not isinstance(value, dict):
        return None
    length = value.get('length_m')
    name = value.get('source_dwg')
    digest = value.get('source_dwg_sha256')
    sheet = value.get('sheet')
    handles = value.get('entity_handles')
    if (type(length) not in (int, float) or length <= 0
            or not isinstance(name, str) or len(name) > 255 or not name.lower().endswith('.dwg')
            or any(c in name for c in ('/', '\\', '\0'))
            or not isinstance(digest, str) or not re.fullmatch(r'[0-9a-fA-F]{64}', digest)
            or type(sheet) is not int or sheet < 1
            or not isinstance(handles, list) or not handles
            or any(not isinstance(h, str) or not re.fullmatch(r'[0-9a-fA-F]{1,16}', h) for h in handles)):
        return None
    try:
        if not math.isfinite(length):
            return None
    except OverflowError:
        return None
    normalized_handles = sorted({h.upper().lstrip('0') for h in handles})
    if '' in normalized_handles or len(normalized_handles) != len(handles):
        return None
    return {'source_kind': 'dwg', 'source_dwg': name, 'source_dwg_sha256': digest.lower(),
            'sheet': sheet, 'entity_handles': normalized_handles, 'length_m': length}


def _measured_plan_row(row, pages):
    """Resolve a reviewed physical run against the source candidate and dimension ticks."""
    if row.get('kind') != 'plan' or 'plan_candidate_id' not in row:
        return row
    page = pages.get(_page_number(row.get('plan_page')), {})
    geometry = page.get('geometry', {})
    profile = geometry.get('automatic_profile', {})
    scale = re.fullmatch(r'1:([1-9]\d*)', profile.get('nominal_scale', ''))
    candidate = next((r for r in geometry.get('candidates', [])
                      if r['candidate_id'] == row['plan_candidate_id']), None)
    measured = dict(row, length_m=None, plan_bbox_pt=None)
    if not candidate or page.get('kind') != 'plan' or geometry.get('source_role') != 'floor_plan':
        return measured
    frame = candidate.get('source') or {}
    measured['plan_bbox_pt'] = frame.get('bbox_pt')
    if (scale and profile.get('evidence', {}).get('scale_source') == 'horizontal_dimension_ticks'
            and candidate.get('projected_length_pt', 0) > 0):
        measured['length_m'] = candidate['projected_length_pt'] * int(scale[1]) * 0.0254 / 72
        measured['measurement'] = {'candidate_id': candidate['candidate_id'], 'scale': scale[0],
                                   'source_ids': candidate['source_stroke_ids'],
                                   'projected_length_pt': candidate['projected_length_pt'],
                                   'scale_evidence': profile['evidence'].get('dimensions', [])}
        if page.get('floor_scope'):
            measured.setdefault('length_basis', 'per_floor')
    return measured


def _segment_rows(segments, pages):
    if not isinstance(segments, list) or any(not isinstance(row, dict) for row in segments):
        raise AlbumInputError('Разметка должна содержать список участков segments.')
    segments = [_measured_plan_row(row, pages) for row in segments]
    ids = [row.get('segment_id') for row in segments]
    if any(not isinstance(key, str) or not key or key != key.strip() or len(key) > 100 for key in ids):
        raise AlbumInputError('Каждому участку нужен непустой постоянный ID.')
    if len(ids) != len(set(ids)):
        raise AlbumInputError('ID участков повторяются. Используйте один ID на физический участок.')
    if any(row.get('kind') not in ('plan', 'vertical') for row in segments):
        raise AlbumInputError('Тип участка должен быть plan или vertical.')

    elevations = {mark['id']: {'pdf_page': page['pdf_page'], **mark}
                  for page in pages.values() for mark in page['elevation_marks']}
    sections = {mark['id']: {'pdf_page': page['pdf_page'], **mark}
                for page in pages.values() for mark in page['section_marks']}
    endpoint_pairs = Counter(
        frozenset((row['start_mark_id'], row['end_mark_id'])) for row in segments
        if row['kind'] == 'vertical' and all(isinstance(row.get(k), str) for k in ('start_mark_id', 'end_mark_id'))
    )
    plan_regions = Counter(
        (location['pdf_page'], tuple(location['bbox_pt'])) for row in segments
        if row['kind'] == 'plan' and (location := _plan_location(row, pages))
    )
    cad_measurements = {row['segment_id']: _cad_measurement(row['cad_measurement'])
                        for row in segments if 'cad_measurement' in row}
    cad_entities = Counter(
        (value['source_dwg_sha256'], handle) for value in cad_measurements.values() if value
        for handle in value['entity_handles']
    )
    results = []
    for row in segments:
        segment_id = row['segment_id']
        system = _system(row.get('system'))
        plan = _plan_location(row, pages)
        kind = row['kind']
        has_cad = segment_id in cad_measurements
        cad = cad_measurements.get(segment_id)
        page = _page_number(row.get('axonometry_page'))
        hints = pages.get(page, {}).get('system_hints', [])
        system_approved = row.get('system_approved') is True
        if has_cad and 'system' not in row and len(hints) == 1:
            system = hints[0]
            system_approved = row.get('system_approved', True) is True
        reasons = []
        if not system or not system_approved:
            reasons.append('system_not_confirmed')
        if row.get('scope_approved') is not True:
            reasons.append('physical_run_not_confirmed_in_project_scope')
        sources = [plan] if plan else []
        if plan and row.get('plan_candidate_id') and row.get('measurement'):
            sources[0] = {**plan, **row['measurement']}
        section_page = page
        length = None
        if kind == 'plan':
            section_page = plan['pdf_page'] if plan else None
            if plan is None:
                reasons.append('missing_plan_location')
            elif plan_regions[plan['pdf_page'], tuple(plan['bbox_pt'])] > 1:
                reasons.append('plan_location_reused')
            if has_cad:
                reasons.append('cad_measurement_requires_vertical_run')
            candidate = row.get('length_m')
            if (row.get('length_approved') is True and type(candidate) in (int, float) and
                    math.isfinite(candidate) and candidate > 0):
                length = candidate
            else:
                reasons.append('plan_length_not_confirmed')
        else:
            mark_ids = [row.get('start_mark_id'), row.get('end_mark_id')]
            marks = [elevations.get(key) if isinstance(key, str) else None for key in mark_ids]
            from_scheme = pages.get(page, {}).get('kind') in ('axonometry', 'mixed')
            valid_marks = (from_scheme and all(m and m['pdf_page'] == page for m in marks)
                           and mark_ids[0] != mark_ids[1])
            if valid_marks:
                sources.extend(marks)
                if endpoint_pairs[frozenset(mark_ids)] > 1:
                    reasons.append('axonometry_mark_pair_reused')
            elif not has_cad or any(key in row for key in ('start_mark_id', 'end_mark_id')):
                reasons.append('axonometry_end_marks_missing_or_on_different_sheets')
            if (has_cad or valid_marks) and hints and system not in hints:
                reasons.append('system_conflicts_with_axonometry_title')
            if has_cad:
                if pages.get(page, {}).get('kind') not in ('axonometry', 'mixed'):
                    reasons.append('cad_axonometry_page_missing')
                if cad is None:
                    reasons.append('invalid_cad_measurement')
                else:
                    sources.append({'pdf_page': page, **cad})
                    if row['cad_measurement'].get('approved') is not True:
                        reasons.append('cad_measurement_not_confirmed')
                    if any(cad_entities[cad['source_dwg_sha256'], h] > 1 for h in cad['entity_handles']):
                        reasons.append('cad_entity_reused')
                    length = cad['length_m']
            elif valid_marks:
                vertical = vertical_length_from_levels(
                    *(m['level_m'] for m in marks), same_datum=row.get('same_datum') is True,
                    same_straight_axis=row.get('same_straight_axis') is True,
                    marks_define_centerline_ends=row.get('marks_define_centerline_ends') is True,
                    source_mark_ids=mark_ids)
                length = vertical['verified_straight_vertical_length_m']
                reasons.extend(vertical['reasons'])

        multiplier = 1
        if row.get('length_basis', 'total') == 'per_floor':
            floors = pages[plan['pdf_page']].get('floor_scope', {}).get('floors', []) if plan else []
            if kind == 'plan' and floors:
                multiplier = len(floors)
            else:
                reasons.append('floor_scope_unavailable')
        elif row.get('length_basis', 'total') != 'total':
            reasons.append('invalid_length_basis')
        unit_length = length if not reasons else None
        length = unit_length * multiplier if unit_length is not None else None
        section_key = row.get('section_mark_id')
        section = sections.get(section_key) if isinstance(section_key, str) else None
        section_approved = (row.get('section_approved') is True and section is not None and
                            section['pdf_page'] == section_page and
                            section['context'] == 'standalone_section_label_candidate')
        area = straight_duct_surface({
            'element_id': segment_id, 'system': system, 'length_m': length,
            'width_mm': section.get('width_mm') if section_approved else None,
            'height_mm': section.get('height_mm') if section_approved else None,
            'source_id': section['id'] if section_approved else None,
            'length_approved': length is not None, 'system_approved': system_approved,
            'scope_approved': row.get('scope_approved') is True, 'width_approved': section_approved,
            'height_approved': section_approved,
        })
        circular_area = (round(math.pi * section['diameter_mm'] / 1000 * length, 6)
                         if length is not None and section_approved and section.get('diameter_mm') else None)
        pieces = row.get('piece_count')
        pieces = (pieces * multiplier if length is not None and row.get('piece_count_approved') is True
                  and type(pieces) is int and pieces > 0 else None)
        results.append({'unit_length_m': unit_length, 'floor_multiplier': multiplier, 'pieces': pieces,
                        'surface_m2': circular_area if circular_area is not None else area['surface_m2'],
                        'segment_id': segment_id, 'kind': kind, 'system': system or None,
                        'length_m': length, 'status': 'approved' if length is not None else 'review_required',
                        'sources': sources, 'reasons': reasons,
                        'section_source': section if section_approved else None,
                        'rectangular_surface_m2': area['surface_m2']})
    return results


def _automatic_selection(pages):
    preview = next((page for page in pages if page['kind'] in ('plan', 'mixed')), None)
    if preview is None:
        preview = next((page for page in pages if page['kind'] == 'axonometry'), pages[0])
    return {'preview_page': preview['pdf_page'], 'preview_kind': preview['kind'],
            'systems': sorted({code for page in pages for code in page['system_hints']})}


def _totals(segments):
    def total(values):
        values = [value for value in values if value is not None]
        return round(math.fsum(values), 6) if values else None

    return {
        'approved_plan_length_m': total(row['length_m'] for row in segments if row['kind'] == 'plan'),
        'approved_vertical_length_m': total(row['length_m'] for row in segments if row['kind'] == 'vertical'),
        'approved_length_m': total(row['length_m'] for row in segments),
        'approved_rectangular_surface_m2': total(row['rectangular_surface_m2'] for row in segments),
        'review_required_segments': sum(row['status'] == 'review_required' for row in segments),
    }


def analyze_album(pdf_path, review=None, *, geometry_reader=None, geometry_budget_s=56, plan_reports=(), progress=None):
    import fitz
    root = str(Path(__file__).resolve().parents[4])
    if root not in sys.path:
        sys.path.insert(0, root)
    from common.clean_papper_pipeline import inspect_specification
    from common.clean_papper_album_worker.modules.pdf.drawing_register import extract_drawing_register

    started = monotonic()
    path = Path(pdf_path)
    if not path.is_file() or not 10 <= path.stat().st_size <= MAX_BYTES:
        raise AlbumInputError('Выберите PDF-альбом размером до 100 МиБ.')
    with path.open('rb') as source:
        if source.read(5) != b'%PDF-':
            raise AlbumInputError('Файл не распознан как PDF.')
        source.seek(0)
        digest = sha256_stream(source)
    if review is not None and (not isinstance(review, dict) or review.get('source_pdf_sha256') != digest):
        raise AlbumInputError('Разметка относится к другой версии PDF-альбома.')
    review = review if review is not None else {}
    try:
        with fitz.open(path) as document:
            if document.is_encrypted or not 1 <= document.page_count <= MAX_PAGES:
                raise AlbumInputError('Нужен PDF без пароля, от 1 до 600 страниц.')
            overrides = _review_page_kinds(review, len(document))
            specification_inventory = inspect_specification(document)
            register = extract_drawing_register(document)
            registered = {r['pdf_page']:r for r in register['entries']} if register['status']=='verified_register' else {}
            ranges = specification_inventory.get('candidates', [])
            spec_pages = set(range(ranges[0]['first'], ranges[0]['last']+1)) if len(ranges)==1 else set()
            pages = []
            if progress:
                progress('Распознавание страниц', 0, len(document))
            for number, page in enumerate(document, 1):
                info = _scan_page(page, number, overrides.get(number), registered.get(number))
                if number in spec_pages and number not in overrides and info['kind'] in ('unclassified','other'):
                    info.update(kind='specification', classification_source='specification_inventory')
                pages.append(info)
                if progress:
                    progress('Распознавание страниц', number, len(document))
            attach_floor_scopes(pages)
            geometry_counts = Counter()
            if geometry_reader is not None:
                drawing_pages = [info for info in pages if info['kind'] in ('plan', 'axonometry', 'mixed')]
                if progress and drawing_pages:
                    progress('Анализ геометрии', 0, len(drawing_pages))
                for index, info in enumerate(drawing_pages, 1):
                    kind = info['kind']
                    if kind == 'mixed':
                        geometry = {'status': 'separate_regions_required'}
                    elif monotonic() - started >= geometry_budget_s:
                        geometry = {'status': 'processing_budget_reached'}
                    else:
                        geometry = geometry_reader(document[info['pdf_page']-1], info)
                    info['geometry'] = geometry
                    geometry_counts[geometry['status']] += 1
                    if progress:
                        progress('Проверка геометрии', index, len(drawing_pages))
    except fitz.FileDataError as exc:
        raise AlbumInputError('Не удалось разобрать PDF-альбом.') from exc

    page_map = {page['pdf_page']: page for page in pages}
    if plan_reports:
        from .candidate_graph import build_candidate_graph

        regions = set()
        for walls, leaders, recovery in plan_reports:
            page = page_map.get(_page_number(walls.get('pdf_page')))
            if (walls.get('source_pdf_sha256') != digest or not page or page['kind'] != 'plan'
                    or walls.get('coordinate_space') != 'unrotated_pdf_points'):
                raise AlbumInputError('Граф относится к другой версии альбома или другой области расчёта.')
            box = walls.get('region_pdf_pt')
            if (not isinstance(box, (list, tuple)) or len(box) != 4
                    or not all(type(v) in (int, float) and math.isfinite(v) for v in box)):
                raise AlbumInputError('Некорректная область графа.')
            x0, y0, x1, y1 = page['page_bounds_pt']
            if not (x0-0.001 <= box[0] < box[2] <= x1+0.001 and y0-0.001 <= box[1] < box[3] <= y1+0.001):
                raise AlbumInputError('Область графа выходит за границы листа.')
            key = (page['pdf_page'], tuple(box))
            if key in regions:
                raise AlbumInputError('Область отчёта указана повторно.')
            regions.add(key)
            page.setdefault('plan_graphs', []).append(build_candidate_graph(walls, leaders, recovery))
    rows = review.get('segments', [])
    segments = _segment_rows(rows, page_map)
    attach_review_evidence(rows, segments, page_map)
    systems = defaultdict(list)
    for row in segments:
        if row['system']:
            systems[row['system']].append(row)
    return {
        'ok': True, 'mode': 'album', 'source_pdf_sha256': digest,
        'coordinate_space': 'unrotated_pdf_points', 'page_count': len(pages),
        'page_kind_counts': dict(Counter(page['kind'] for page in pages)), 'pages': pages,
        'specification_inventory': specification_inventory, 'drawing_register': register,
        'automatic_selection': _automatic_selection(pages),
        'geometry_summary': dict(geometry_counts),
        'calculation': {'scope': 'approved_segments_only', 'totals': _totals(segments),
                        'systems': {code: _totals(rows) for code, rows in sorted(systems.items())},
                        'segments': segments},
        'review_template': {'source_pdf_sha256': digest, 'page_kinds': {}, 'segments': []},
    }


def main(argv=None, *, geometry_reader=None):
    parser = argparse.ArgumentParser(description='Process all pages of a ventilation project PDF')
    parser.add_argument('--file', required=True, type=Path)
    parser.add_argument('--review', type=Path, help='Review JSON with references to this PDF')
    parser.add_argument('--review-stdin', action='store_true', help='Read review JSON from standard input')
    parser.add_argument('--plan-reports', nargs=3, action='append', type=Path,
                        metavar=('WALLS', 'LEADERS', 'RECOVERY'), help='Векторные отчёты области плана')
    args = parser.parse_args(argv)
    if args.review and args.review_stdin:
        parser.error('use only one review input')
    try:
        raw = None
        if args.review:
            with args.review.open('rb') as handle:
                raw = handle.read(MAX_REVIEW_BYTES + 1)
        elif args.review_stdin:
            raw = sys.stdin.buffer.read(MAX_REVIEW_BYTES + 1)
        if raw is not None and len(raw) > MAX_REVIEW_BYTES:
            raise AlbumInputError('Разметка превышает 96 КиБ.')
        reports = [[json.loads(p.read_text(encoding='utf-8')) for p in paths]
                   for paths in args.plan_reports or []]
        if any(not isinstance(obj, dict) for group in reports for obj in group):
            raise AlbumInputError('Ожидались JSON-объекты отчётов.')
        result = analyze_album(args.file, json.loads(raw) if raw else None, geometry_reader=geometry_reader,
                               plan_reports=reports)
    except AlbumInputError as exc:
        result = {'ok': False, 'code': 'invalid_album_input', 'message': str(exc)}
    except (UnicodeError, json.JSONDecodeError):
        result = {'ok': False, 'code': 'invalid_album_input', 'message': 'Разметка должна быть в формате JSON.'}
    except (ImportError, KeyError, TypeError, OSError, ValueError, OverflowError):
        result = {'ok': False, 'code': 'album_processing_error', 'message': 'Не удалось обработать альбом.'}
    print(json.dumps(result, ensure_ascii=False, separators=(',', ':'), allow_nan=False))
    return 0 if result['ok'] else 1


if __name__ == '__main__':
    sys.exit(main())
