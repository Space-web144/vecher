"""Detect possible vertical duct contours from broken colored PDF strokes.

This produces a source-traceable 2D projected shape hypothesis, not a physical
riser length. PDF points never become meters without separately confirmed
engineering geometry and endpoint semantics.
"""
from __future__ import annotations
import argparse
import json
import math
from collections import defaultdict
from pathlib import Path
import fitz

MIN_STROKE_LEN_PT = 5.0
MAX_VERTICAL_SLOPE_PT = 0.45
RAIL_X_TOL_PT = 0.85
MAX_DASH_GAP_PT = 9.8
MIN_RAIL_SPAN_PT = 35.0
MIN_RAIL_STROKES = 2
MIN_SINGLE_STROKE_RAIL_PT = 70.0
MIN_RAIL_SEPARATION_PT = 5.0
MAX_RAIL_SEPARATION_PT = 35.0
MIN_PAIR_OVERLAP_PT = 30.0
MIN_SPAN_OVERLAP_RATIO = 0.65
NEAR_AXIS_ENDPOINT_PT = 10.0


def _strong_color(color):
    """Mildly saturated green or blue diagram strokes; exclude gray annotations."""
    if not color or len(color) != 3:
        return False
    r, g, b = color
    return (g > 0.65 and g >= r * 1.35 and g > b * 1.25) or (b > 0.65 and b > r * 1.35 and b >= g * 1.15)


def _roi_check(page, roi):
    if len(roi) != 4 or not all(math.isfinite(float(x)) for x in roi):
        raise ValueError("Region must comprise four finite PDF-point coordinates")
    r = fitz.Rect(*map(float, roi))
    if r.is_empty or not page.rect.contains(r):
        raise ValueError("Region must be non-empty and within PDF page")
    return r


def _vertical_strokes(page, roi, drawings=None):
    """Only line primitives. Preserve path/item ids for direct PDF verification."""
    strokes = []
    seen = set()
    for i, d in enumerate(page.get_drawings() if drawings is None else drawings):
        color = d.get("color")
        if not _strong_color(color):
            continue
        for j, item in enumerate(d.get("items", [])):
            if item[0] != "l":
                continue
            a, b = item[1:3]
            x0, x1 = float(a[0]), float(b[0])
            y0, y1 = sorted((float(a[1]), float(b[1])))
            if abs(x0 - x1) > MAX_VERTICAL_SLOPE_PT or y1 - y0 < MIN_STROKE_LEN_PT:
                continue
            if not (roi.x0 <= (x0 + x1) / 2 <= roi.x1 and roi.y0 <= y0 < y1 <= roi.y1):
                continue
            key = (round((x0+x1)/2,2),round(y0,2),round(y1,2))
            if key in seen:
                continue
            seen.add(key)
            strokes.append({"x":(x0+x1)/2, "y0":y0, "y1":y1,
                            "vector_id": f"{i}:{j}"})
    return sorted(strokes, key=lambda x:(x["x"],x["y0"]))


def _rails_from_strokes(strokes, *, dash_gap_pt=MAX_DASH_GAP_PT, x_tolerance_pt=RAIL_X_TOL_PT):
    clusters=[]
    for stroke in strokes:
        if clusters and stroke["x"] - clusters[-1]["x"] <= x_tolerance_pt:
            c=clusters[-1]
            c["strokes"].append(stroke)
            c["x"] += (stroke["x"]-c["x"])/len(c["strokes"])
        else:
            clusters.append({"x":stroke["x"],"strokes":[stroke]})
    rails=[]
    for c in clusters:
        seq=sorted(c["strokes"],key=lambda s:s["y0"])
        chain=[]
        chain_end = 0.
        def emit(chain):
            if not chain:
                return
            y0=min(s["y0"] for s in chain)
            y1=max(s["y1"] for s in chain)
            span=y1-y0
            # Short single strokes often belong to equipment or valve outlines.
            if span < MIN_RAIL_SPAN_PT or (len(chain)<MIN_RAIL_STROKES and
                                            span < MIN_SINGLE_STROKE_RAIL_PT):
                return
            rails.append({"x_pt":round(sum(s["x"] for s in chain)/len(chain),3),
                          "y0_pt":round(y0,3),"y1_pt":round(y1,3),
                          "projected_span_pt":round(span,3),
                          "vector_ids":[s["vector_id"] for s in chain],
                          "fragments":len(chain)})
        for stroke in seq:
            if chain and stroke["y0"]-chain_end>dash_gap_pt:
                emit(chain)
                chain=[]
            chain_end = max(chain_end, stroke["y1"]) if chain else stroke["y1"]
            chain.append(stroke)
        emit(chain)
    return sorted(rails,key=lambda x:(x["x_pt"],x["y0_pt"]))


def _overlap(a,b):
    y0=max(a["y0_pt"],b["y0_pt"])
    y1=min(a["y1_pt"],b["y1_pt"])
    return max(0., y1-y0), y0, y1


def _riser_groups(rails, *, min_separation_pt=MIN_RAIL_SEPARATION_PT, max_separation_pt=MAX_RAIL_SEPARATION_PT):
    # Candidate rail corridors may contain extra hatch/insulation strokes.
    edges=[]
    parent=list(range(len(rails)))
    def root(i):
        while parent[i]!=i:
            parent[i]=parent[parent[i]]
            i=parent[i]
        return i
    for i,a in enumerate(rails):
        for j in range(i+1,len(rails)):
            b=rails[j]
            dx=b["x_pt"]-a["x_pt"]
            if dx > max_separation_pt:
                break
            if dx < min_separation_pt:
                continue
            common,lo,hi=_overlap(a,b)
            smaller=min(a["projected_span_pt"],b["projected_span_pt"])
            if common < MIN_PAIR_OVERLAP_PT or common/smaller < MIN_SPAN_OVERLAP_RATIO:
                continue
            pa,pb=root(i),root(j)
            parent[max(pa,pb)]=min(pa,pb)
            edges.append((i,j))
    clusters=defaultdict(list)
    connected={v for pair in edges for v in pair}
    for i in connected:
        clusters[root(i)].append(i)
    groups=[]
    for idx,inds in enumerate(sorted(clusters.values(),key=lambda vs:min(rails[v]["x_pt"] for v in vs)),1):
        inds=sorted(inds,key=lambda v:rails[v]["x_pt"])
        left,right=rails[inds[0]],rails[inds[-1]]
        common,lo,hi=_overlap(left,right)
        if common < MIN_PAIR_OVERLAP_PT:
            status="no_common_outer_overlap"
            axis=None
        else:
            status="ambiguous_parallel_rails" if len(inds)>2 else "two_rail_contour_candidate"
            axis={"x_pt":round((left["x_pt"]+right["x_pt"])/2,3),
                  "top_y_pt":round(lo,3),"bottom_y_pt":round(hi,3),
                  "projected_axis_span_pt":round(common,3)}
        groups.append({"candidate_id":f"V{idx:02d}","status":status,
                       "rail_count":len(inds),
                       "rails":[rails[i] for i in inds],
                       "outer_sep_pt":round(right["x_pt"]-left["x_pt"],3),
                       "projected_axis_candidate":axis,
                       "confirmed_vertical_length_m":None,
                       "confirmed_duct_section_mm":None,
                       "physical_endpoint_ids":[],
                       "engineer_review_required":True})
    return groups


def _leader_distance_to_ends(leader, candidate):
    p=leader.get("candidate_anchor_pt")
    axis=candidate.get("projected_axis_candidate")
    if not p or not axis:
        return None
    top=(axis["x_pt"],axis["top_y_pt"])
    bottom=(axis["x_pt"],axis["bottom_y_pt"])
    return {"mark":leader.get("raw"),"source_bbox_pt":leader.get("bbox_pt"),
            "top_distance_pt":round(math.dist(p,top),3),
            "bottom_distance_pt":round(math.dist(p,bottom),3),
            "anchor_at_candidate_riser_end":min(math.dist(p,top),math.dist(p,bottom))<=NEAR_AXIS_ENDPOINT_PT,
            "status":"projected_proximity_only"}


def detect_schematic_risers(pdf_path, page_number, roi, *, leader_report=None, system=None):
    if leader_report is not None:
        if int(leader_report.get('pdf_page',-1))!=page_number or [float(x) for x in leader_report.get('region_pt',[])]!=[float(x) for x in roi]:
            raise ValueError("Leader report does not match this exact PDF page and ROI")
        if not (leader_report.get('scheme_title_evidence') or {}).get('verified'):
            raise ValueError("Independent scheme-title verification is required")
        if system and ''.join(system.split()).upper()!=''.join(str(leader_report.get('scheme')).split()).upper():
            raise ValueError("System differs from leader report")
    with fitz.open(str(pdf_path)) as doc:
        if not 1<=page_number<=len(doc):
            raise ValueError("PDF page out of range")
        page=doc[page_number-1]
        rect=_roi_check(page,roi)
        raw=_vertical_strokes(page,rect)
    rails=_rails_from_strokes(raw)
    candidates=_riser_groups(rails)
    for c in candidates:
        c['mark_anchor_checks']=[_leader_distance_to_ends(m,c)
           for m in (leader_report or {}).get('level_anchor_evidence',[])
           if m.get('status')=='leader_to_colored_geometry_candidate']
        # Proximity never confirms that marks refer to physical riser ends.
        c['verified_elevation_endpoints']=False
    return {"source_pdf_filename":Path(pdf_path).name,"pdf_page":page_number,
            "region_pt":[float(v) for v in roi],
            "system":system or (leader_report or {}).get('scheme'),
            "summary":{"vertical_colored_vector_strokes":len(raw),
                       "grouped_vertical_rails":len(rails),
                       "projected_riser_envelope_candidates":len(candidates),
                       "ambiguous_envelopes":sum(c['status']!='two_rail_contour_candidate' for c in candidates),
                       "approved_vertical_lengths_m":None,
                       "approved_material_surface_m2":None},
            "riser_candidates":candidates,
            "limitations":["Vertical PDF geometry is 2D projected points, not meters",
                           "Parallel colored rails may be contour, centerline or hatch geometry",
                           "Candidate endpoints are projected rail ends, not proven physical duct ends",
                           "Proximity to a level leader does not prove duct-centerline association",
                           "No vertical length without independent engineering evidence"]}


def main():
    p=argparse.ArgumentParser(description="Detect PDF projected vertical riser contour hypotheses")
    p.add_argument('pdf')
    p.add_argument('--page',type=int,required=True)
    p.add_argument('--box',type=float,nargs=4,required=True,metavar=('X0','Y0','X1','Y1'))
    p.add_argument('--leaders',help="JSON output of elevation_leaders.py for exact same PDF region")
    p.add_argument('--system')
    p.add_argument('--output')
    args=p.parse_args()
    leaders=json.loads(Path(args.leaders).read_text(encoding='utf-8')) if args.leaders else None
    result=detect_schematic_risers(args.pdf,args.page,args.box,leader_report=leaders,system=args.system)
    output=json.dumps(result,ensure_ascii=False,indent=2)
    if args.output:
        Path(args.output).write_text(output,encoding='utf-8')
    else:
        print(output)

if __name__=='__main__':
    main()
