"""Prepare a type-review queue from a verified set of PDF diagnostic reports."""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path


_SOURCE_FIELDS = ('source_pdf_sha256', 'pdf_page', 'coordinate_space', 'region_pdf_pt')


def _report_digest(report):
    # Match the canonical serialization used by both transferred PDF producers.
    canonical = json.dumps(report, sort_keys=True, separators=(',', ':'), allow_nan=False)
    return hashlib.sha256(canonical.encode('utf-8')).hexdigest()


def prepare_recovery_review(walls, leaders, recovery):
    """Preserve the alternatives for each contact without approving an element."""
    if (walls.get('schema'), leaders.get('schema'), recovery.get('schema')) != (
            'clean-papper.wall-axes-diagnostic.v1', 'clean-papper.leader-links.v1',
            'clean-papper.leader-recovery.v1'):
        raise ValueError('Unexpected wall, leader or recovery report schema.')
    source = {field: walls[field] for field in _SOURCE_FIELDS}
    if any(report.get(field) != value for report in (leaders, recovery) for field, value in source.items()):
        raise ValueError('Reports refer to different PDF sources, pages or regions.')
    wall_digest = _report_digest(walls)
    leader_digest = _report_digest(leaders)
    if leaders.get('wall_report_sha256') != wall_digest or recovery.get('wall_report_sha256') != wall_digest:
        raise ValueError('The wall report does not match the leader and recovery reports.')
    if recovery.get('leader_report_sha256') != leader_digest:
        raise ValueError('The recovery report requires a different version of the leader report.')

    leader_labels = {link['label']['id'] for link in leaders['links']}
    contacts = []
    seen_labels = set()
    for contact in recovery['links']:
        label_id = contact['label']['id']
        if label_id not in leader_labels or label_id in seen_labels:
            raise ValueError(f'Missing or repeated leader label: {label_id}')
        seen_labels.add(label_id)
        pair_candidates = contact['candidate_pairs']
        has_closed_shape = (
            contact['compact_closed_contours'] or contact['circular_contours'] or
            any(pair['contour_check']['closed_contour_candidate'] for pair in pair_candidates)
        )
        if has_closed_shape:
            review = 'closed_shape_type_review'
        elif pair_candidates:
            review = 'wall_pair_type_review'
        else:
            review = 'contact_without_recovered_geometry'
        contacts.append({'label_id': label_id, 'review': review, 'evidence': contact})

    return {'schema': 'clean-papper.recovery-type-review.v1', **source,
            'input_reports': {'walls': wall_digest, 'leaders': leader_digest,
                              'recovery': _report_digest(recovery)},
            'counts': dict(Counter(item['review'] for item in contacts)), 'contacts': contacts}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for argument in ('walls', 'leaders', 'recovery'):
        parser.add_argument(argument, type=Path)
    args = parser.parse_args()
    try:
        inputs = [json.loads(path.read_text(encoding='utf-8')) for path in (args.walls, args.leaders, args.recovery)]
        result = prepare_recovery_review(*inputs)
    except (KeyError, TypeError, ValueError, OSError) as error:
        parser.exit(1, f'{error}\n')
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
