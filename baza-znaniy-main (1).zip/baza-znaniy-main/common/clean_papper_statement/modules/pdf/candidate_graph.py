"""Find reviewable contacts between candidate PDF duct axes."""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict
from itertools import product
import json
import math
from pathlib import Path

from .recovery_review import prepare_recovery_review
from .terminal_review import terminal_contacts


def _project(point, ends):
    (ax, ay), (bx, by) = ends
    dx, dy = bx - ax, by - ay
    t = ((point[0] - ax) * dx + (point[1] - ay) * dy) / (dx * dx + dy * dy)
    return t, (ax + t * dx, ay + t * dy)


def _interior(t, length, tolerance):
    return min(t, 1 - t) * length > tolerance


def _crossing(a, b, tolerance):
    (ax, ay), (bx, by) = a['axis_pdf_pt']
    (cx, cy), (dx, dy) = b['axis_pdf_pt']
    ux, uy, vx, vy = bx-ax, by-ay, dx-cx, dy-cy
    determinant = ux * vy - uy * vx
    if abs(determinant) <= 1e-10 * a['length_pdf_pt'] * b['length_pdf_pt']:
        return None
    t = ((cx-ax) * vy - (cy-ay) * vx) / determinant
    s = ((cx-ax) * uy - (cy-ay) * ux) / determinant
    if _interior(t, a['length_pdf_pt'], tolerance) and _interior(s, b['length_pdf_pt'], tolerance):
        return [ax + t * ux, ay + t * uy]
    return None


def _contacts(a, b, tolerance):
    a_ends, b_ends = a['axis_pdf_pt'], b['axis_pdf_pt']
    projections = [_project(point, a_ends) for point in b_ends]
    if all(math.dist(point, projected) <= tolerance for point, (_, projected) in zip(b_ends, projections)):
        lo, hi = sorted(t for t, _ in projections)
        if (min(1, hi) - max(0, lo)) * a['length_pdf_pt'] > tolerance:
            yield {'kind': 'axis_overlap', 'ports': []}
            return
    crossing = _crossing(a, b, tolerance)
    if crossing is not None:
        yield {'kind': 'crossing_requires_review', 'ports': [], 'at_pdf_pt': crossing}
    for i, j in product(range(2), repeat=2):
        distance = math.dist(a_ends[i], b_ends[j])
        if distance <= tolerance:
            yield {'kind': 'endpoint_pair', 'ports': [a['ports'][i], b['ports'][j]],
                   'distance_pdf_pt': distance}
    for branch, trunk in ((a, b), (b, a)):
        for port, point in zip(branch['ports'], branch['axis_pdf_pt']):
            t, projected = _project(point, trunk['axis_pdf_pt'])
            distance = math.dist(point, projected)
            if distance <= tolerance and _interior(t, trunk['length_pdf_pt'], tolerance):
                yield {'kind': 'possible_branch', 'ports': [port], 'trunk_axis': trunk['id'],
                       'at_pdf_pt': projected, 'distance_pdf_pt': distance}


def _branch_wall_review(branch, trunk, port, rails, tolerance):
    """Test the two reported rail spans at the outgoing side of the trunk."""
    result = {'status': 'insufficient_wall_evidence', 'walls': []}
    ids = branch.get('rail_ids', [])
    if (len(set(ids)) != 2 or len(ids) != 2 or any(r not in rails for r in ids)
            or not trunk.get('width_pdf_pt')):
        return result
    a, b = trunk['axis_pdf_pt']
    length = trunk['length_pdf_pt']
    tx, ty = (b[0] - a[0]) / length, (b[1] - a[1]) / length
    nx, ny = -ty, tx
    start, end = branch['axis_pdf_pt']
    if port == branch['ports'][1]:
        start, end = end, start
    outward = (end[0] - start[0]) * nx + (end[1] - start[1]) * ny
    if abs(outward) <= tolerance:
        return result
    side = math.copysign(trunk['width_pdf_pt'] / 2, outward)
    for rid in ids:
        rail = rails[rid]
        angle = math.radians(rail['angle_deg'])
        ux, uy = math.cos(angle), math.sin(angle)
        ox, oy = -uy * rail['offset_pt'], ux * rail['offset_pt']
        slope = nx * ux + ny * uy
        if abs(slope) < 1e-10 or not rail['source_ids']:
            return result
        t = (side - nx * (ox - a[0]) - ny * (oy - a[1])) / slope
        x, y = ox + t * ux, oy + t * uy
        along = (x - a[0]) * tx + (y - a[1]) * ty
        forward = (end[0] - start[0]) * ux + (end[1] - start[1]) * uy
        beyond = rail['hi_pt'] - t if forward > 0 else t - rail['lo_pt']
        result['walls'].append({'rail_id': rid, 'source_ids': rail['source_ids'],
                                'at_trunk_side_pdf_pt': [x, y],
                                'within_trunk_span': -tolerance <= along <= length + tolerance,
                                'extends_outside': (rail['lo_pt'] - tolerance <= t <= rail['hi_pt'] + tolerance
                                                    and beyond > tolerance)})
    if all(w['within_trunk_span'] and w['extends_outside'] for w in result['walls']):
        result['status'] = 'two_wall_spans_require_connection_review'
    else:
        result['status'] = 'element_type_review'
    return result


def _side_openings(axes, ports, rails, walls, tolerance, blocked):
    """Look for a break in one trunk wall opposite a continuous rail at a branch port."""
    settings = walls.get('settings_pdf_pt_diagnostic_only', {})
    if not {'min_width_pt', 'max_width_pt'} <= settings.keys():
        return []
    groups = defaultdict(list)
    for rail in rails.values():
        if not blocked.intersection(rail['source_ids']):
            color, weight = rail['style']
            groups[(tuple(color), weight, rail['angle_deg'])].append(rail)
    findings = []
    for axis in axes:
        branch_rails = [rails[r] for r in axis.get('rail_ids', []) if r in rails]
        if len(branch_rails) != 2 or branch_rails[0]['angle_deg'] != branch_rails[1]['angle_deg']:
            continue
        angle = branch_rails[0]['angle_deg']
        normal_angle = (angle + 90) % 180
        color, weight = axis['style']
        perpendicular = groups.get((tuple(color), weight, normal_angle), [])
        theta = math.radians(normal_angle)
        ux, uy = math.cos(theta), math.sin(theta)
        half = axis['width_pdf_pt'] / 2
        for port in axis['ports']:
            if ports[port]['contact_ids']:
                continue
            x, y = ports[port]['pdf_pt']
            other = axis['axis_pdf_pt'][1 - axis['ports'].index(port)]
            along, across = x * ux + y * uy, -x * uy + y * ux
            sign = math.copysign(1, -(other[0]-x)*uy + (other[1]-y)*ux)
            nearby = [r for r in perpendicular if abs(r['offset_pt']-across) <= half + tolerance]
            lower = [r for r in nearby if along - 2*half - 2*tolerance <= r['hi_pt'] < along]
            upper = [r for r in nearby if along < r['lo_pt'] <= along + 2*half + 2*tolerance]
            for low in lower:
                for high in upper:
                    gap = high['lo_pt'] - low['hi_pt']
                    if not (abs(low['offset_pt']-high['offset_pt']) <= tolerance
                            and low['hi_pt'] < along < high['lo_pt']
                            and gap >= half and gap <= 2 * half + 2 * tolerance
                            and abs((high['lo_pt']+low['hi_pt'])/2-along) <= tolerance):
                        continue
                    face = (low['offset_pt']+high['offset_pt'])/2
                    # Both branch rails must reach the face and continue away from it.
                    hits = []
                    for r in branch_rails:
                        a = math.radians(r['angle_deg'])
                        vx, vy = math.cos(a), math.sin(a)
                        t = (face - r['offset_pt']*(vy*uy+vx*ux)) / (-vx*uy+vy*ux)
                        outward = (other[0]-x)*vx + (other[1]-y)*vy
                        extent = r['hi_pt']-t if outward > 0 else t-r['lo_pt']
                        hits.append(r['lo_pt']-tolerance <= t <= r['hi_pt']+tolerance and extent > tolerance)
                    if not all(hits):
                        continue
                    for back in perpendicular:
                        width = sign * (face-back['offset_pt'])
                        if (settings['min_width_pt'] <= width <= settings['max_width_pt']
                                and back['lo_pt'] < low['hi_pt'] and back['hi_pt'] > high['lo_pt']):
                            evidence = [low, high, back, *branch_rails]
                            findings.append({'port': port, 'pdf_pt': [x, y], 'gap_pdf_pt': gap,
                                             'face_rails': [low['id'], high['id']], 'back_rail': back['id'],
                                             'branch_rails': axis['rail_ids'],
                                             'source_ids': sorted({sid for r in evidence for sid in r['source_ids']}),
                                             'status': 'side_opening_requires_review'})
    return findings


def _short_wall_pairs(walls, blocked, tolerance):
    """Propose coextensive unused rails for a separate test against a trunk opening."""
    settings = walls.get('settings_pdf_pt_diagnostic_only', {})
    required = {'min_aspect', 'min_overlap_pt', 'overlap_fraction', 'min_rail_pt',
                'min_width_pt', 'max_width_pt'}
    if not required <= settings.keys():
        return
    used = {rid for rows in ('axis_candidates', 'ambiguous_pairs')
            for pair in walls.get(rows, []) for rid in pair.get('rail_ids', [])}
    groups = defaultdict(list)
    for r in walls.get('rails', []):
        if (r['id'] not in used and r['span_pt'] >= settings['min_rail_pt']
                and not blocked.intersection(r['source_ids'])):
            color, weight = r['style']
            groups[(tuple(color), weight, r['angle_deg'])].append(r)
    for (_, _, angle), group in groups.items():
        group.sort(key=lambda r: r['offset_pt'])
        radians = math.radians(angle)
        ux, uy = math.cos(radians), math.sin(radians)
        for index, a in enumerate(group):
            for j in range(index + 1, len(group)):
                b = group[j]
                width = b['offset_pt'] - a['offset_pt']
                if width > settings['max_width_pt']:
                    break
                if width < settings['min_width_pt']:
                    continue
                lo, hi = max(a['lo_pt'], b['lo_pt']), min(a['hi_pt'], b['hi_pt'])
                length = hi - lo
                minimum = max(settings['min_overlap_pt'],
                              settings['overlap_fraction'] * max(a['span_pt'], b['span_pt']))
                if (length < minimum or abs(a['lo_pt']-b['lo_pt']) > tolerance
                        or abs(a['hi_pt']-b['hi_pt']) > tolerance):
                    continue
                # The local face search covers at most half the branch width at the port.
                deficit = width * settings['min_aspect'] - length
                if not 0 < deficit <= width / 2:
                    continue
                offset = (a['offset_pt'] + b['offset_pt']) / 2
                ids = sorted([a['id'], b['id']])
                yield {'id': 'short-' + '-'.join(ids), 'rail_ids': ids, 'style': a['style'],
                       'axis_pdf_pt': [[t*ux-offset*uy, t*uy+offset*ux] for t in (lo, hi)],
                       'source_ids': sorted(set(a['source_ids'] + b['source_ids'])),
                       'width_pdf_pt': width, 'length_pdf_pt': length, 'length_m': None,
                       'status': 'short_pair_with_opening_requires_review', 'label_hints': [],
                       'closed_shape_labels': [], 'aspect_deficit_pdf_pt': deficit}


def _closed_strokes(contacts):
    blocked = defaultdict(set)
    for item in contacts:
        evidence = item['evidence']
        closed = [*evidence['compact_closed_contours'], *evidence['circular_contours']]
        closed.extend(pair for pair in evidence['candidate_pairs']
                      if pair['contour_check']['closed_contour_candidate'])
        for shape in closed:
            cap_strokes = [sid for cap in shape.get('contour_check', {}).get('end_caps', [])
                           for sid in cap['source_ids']]
            for stroke in [*shape['source_ids'], *cap_strokes]:
                blocked[stroke].add(item['label_id'])
    return blocked


def build_candidate_graph(walls, leaders, recovery, *, tolerance_pt=0.25):
    """Build separate ports and geometric hypotheses within one PDF region."""
    if not math.isfinite(tolerance_pt) or tolerance_pt <= 0:
        raise ValueError('The PDF-point contact tolerance must be positive and finite.')
    queue = prepare_recovery_review(walls, leaders, recovery)
    blocked = _closed_strokes(queue['contacts'])
    axes = {}
    for axis in sorted(walls['axis_candidates'], key=lambda row: row['id']):
        axis_id = axis['id']
        points = axis['axis_pdf_pt']
        if (axis_id in axes or len(points) != 2 or
                any(len(p) != 2 or not all(math.isfinite(v) for v in p) for p in points)):
            raise ValueError(f'Invalid or duplicate axis: {axis_id}')
        length = math.dist(*points)
        if not length or not axis['source_ids']:
            raise ValueError(f'Degenerate axis or missing source strokes: {axis_id}')
        closed_labels = sorted({label for sid in axis['source_ids'] for label in blocked.get(sid, ())})
        axes[axis_id] = {**axis, 'length_pdf_pt': length, 'length_m': None, 'ports': [],
                         'closed_shape_labels': closed_labels}

    label_hints = defaultdict(list)
    unresolved_labels = []
    for link in leaders['links']:
        target = link.get('proposed_target')
        if target in axes:
            label_hints[target].append({'id': link['label']['id'], 'system': link.get('proposed_system'),
                                        'section': link.get('proposed_section')})
        elif target:
            unresolved_labels.append({'id': link['label']['id'], 'target': target})

    ports = {}
    eligible = []
    for axis in axes.values():
        axis['label_hints'] = label_hints.get(axis['id'], [])
        if axis['closed_shape_labels']:
            continue
        for index, point in enumerate(axis['axis_pdf_pt'], start=1):
            port = f"{axis['id']}:{index}"
            axis['ports'].append(port)
            ports[port] = {'axis': axis['id'], 'pdf_pt': point, 'contact_ids': []}
        eligible.append(axis)

    rails = {rail['id']: rail for rail in walls.get('rails', [])}
    relations = []
    eligible.sort(key=lambda axis: min(point[0] for point in axis['axis_pdf_pt']))
    for i, a in enumerate(eligible):
        limit = max(point[0] for point in a['axis_pdf_pt']) + tolerance_pt
        for b in eligible[i+1:]:
            if min(point[0] for point in b['axis_pdf_pt']) > limit:
                break
            for relation in _contacts(a, b, tolerance_pt):
                relation_id = f'contact-{len(relations)+1}'
                relation.update(id=relation_id, axes=[a['id'], b['id']],
                                shared_source_ids=sorted(set(a['source_ids']) & set(b['source_ids'])),
                                same_style=a['style'] == b['style'])
                if relation['kind'] == 'possible_branch':
                    port = relation['ports'][0]
                    review = _branch_wall_review(axes[ports[port]['axis']], axes[relation['trunk_axis']],
                                                 port, rails, tolerance_pt)
                    relation['wall_review'] = review
                    if review['status'] == 'element_type_review':
                        relation['kind'] = 'element_type_review'
                relations.append(relation)
                for port in relation['ports']:
                    ports[port]['contact_ids'].append(relation_id)
    for port in ports.values():
        port['status'] = 'contacts_require_review' if port['contact_ids'] else 'no_nearby_port_contact'

    opening_candidates = _side_openings(eligible, ports, rails, walls, tolerance_pt, set(blocked))
    short_axes = list(_short_wall_pairs(walls, set(blocked), tolerance_pt))
    short_ports = {}
    for axis in short_axes:
        axis['ports'] = []
        for index, point in enumerate(axis['axis_pdf_pt'], 1):
            port = f"{axis['id']}:{index}"
            short_ports[port] = {'axis': axis['id'], 'pdf_pt': point, 'contact_ids': []}
            axis['ports'].append(port)
    recovered = _side_openings(short_axes, short_ports, rails, walls, tolerance_pt, set(blocked))
    recovered_ports = {finding['port'] for finding in recovered}
    for axis in short_axes:
        if recovered_ports.intersection(axis['ports']):
            axes[axis['id']] = axis
            for port in axis['ports']:
                ports[port] = {**short_ports[port], 'status': 'side_opening_requires_review'
                               if port in recovered_ports else 'no_nearby_port_contact'}
    opening_candidates.extend(recovered)
    openings_by_port = defaultdict(list)
    for index, candidate in enumerate(opening_candidates):
        openings_by_port[candidate['port']].append(index)
    opening_locations = [{'port': port, 'pdf_pt': ports[port]['pdf_pt'],
                          'candidate_indices': indices}
                         for port, indices in openings_by_port.items()]

    return {**{key: queue[key] for key in ('source_pdf_sha256', 'pdf_page', 'coordinate_space',
                                           'region_pdf_pt', 'input_reports')},
            'schema': 'clean-papper.candidate-graph.v1', 'contact_tolerance_pdf_pt': tolerance_pt,
            'axes': list(axes.values()), 'ports': ports, 'geometric_contacts': relations,
            'terminal_contacts': terminal_contacts(walls, set(blocked), tolerance_pt),
            'side_opening_candidates': opening_candidates, 'side_opening_locations': opening_locations,
            'contact_counts': dict(Counter(relation['kind'] for relation in relations)),
            'type_review_counts': queue['counts'], 'unresolved_leader_targets': unresolved_labels,
            'approved_quantities': None}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ('walls', 'leaders', 'recovery'):
        parser.add_argument(name, type=Path)
    parser.add_argument('--contact-tolerance-pt', type=float, default=0.25)
    args = parser.parse_args()
    try:
        reports = [json.loads(path.read_text(encoding='utf-8')) for path in (args.walls, args.leaders, args.recovery)]
        result = build_candidate_graph(*reports, tolerance_pt=args.contact_tolerance_pt)
    except (KeyError, TypeError, ValueError, OSError) as error:
        parser.exit(1, f'{error}\n')
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
