"""Find bounded rectangular terminals overlapping the outline of a transverse run."""
from collections import defaultdict
import math


def terminal_contacts(walls, blocked, tolerance):
    settings = walls.get('settings_pdf_pt_diagnostic_only', {})
    if not {'min_width_pt', 'max_width_pt'} <= settings.keys():
        return []
    rails = {r['id']: r for r in walls.get('rails', []) if not blocked.intersection(r['source_ids'])}
    groups = defaultdict(list)
    for rail in rails.values():
        color, width = rail['style']
        groups[(tuple(color), width, rail['angle_deg'])].append(rail)
    results = []
    for pair in walls.get('ambiguous_pairs', []):
        ids = pair['rail_ids']
        if not all(rid in rails for rid in ids):
            continue
        a, b = (rails[rid] for rid in ids)
        if any(abs(a[k]-b[k]) > tolerance for k in ('lo_pt', 'hi_pt')):
            continue
        angle = a['angle_deg']
        cross_angle = (angle + 90) % 180
        sign = 1 if cross_angle > angle else -1
        edges = sorted(sign*r['offset_pt'] for r in (a, b))
        half = (edges[1]-edges[0])/2
        start, end = (sum(r[k] for r in (a, b))/2 for k in ('lo_pt', 'hi_pt'))
        color, weight = a['style']
        caps = [[], []]
        faces = []
        for r in groups[(tuple(color), weight, cross_angle)]:
            t = -sign*r['offset_pt']
            if max(abs(r['lo_pt']-edges[0]), abs(r['hi_pt']-edges[1])) <= tolerance:
                for i, endpoint in enumerate((start, end)):
                    if abs(endpoint-t) <= tolerance:
                        caps[i].append(r['id'])
            elif r['lo_pt'] < edges[0]-tolerance and r['hi_pt'] > edges[1]+tolerance:
                faces.append((t, r))
        if not all(caps):
            continue
        theta = math.radians(angle)
        ux, uy = math.cos(theta), math.sin(theta)
        offset = (a['offset_pt'] + b['offset_pt'])/2
        for endpoint, outward in ((start, -1), (end, 1)):
            for t, front in faces:
                if not -tolerance <= outward*(endpoint-t) <= half+tolerance:
                    continue
                backs = [r['id'] for depth, r in faces
                         if settings['min_width_pt'] <= outward*(depth-t) <= settings['max_width_pt']
                         and max(abs(front[k]-r[k]) for k in ('lo_pt', 'hi_pt')) <= tolerance]
                if backs:
                    results.append({'rail_ids': ids, 'cap_rails': caps, 'front_rail': front['id'],
                                    'terminal_cap_rails': caps[0 if outward < 0 else 1],
                                    'back_rails': backs, 'pdf_pt': [ux*t-uy*offset, uy*t+ux*offset],
                                    'source_ids': sorted({sid for rid in [*ids, *caps[0], *caps[1],
                                                                          front['id'], *backs]
                                                          for sid in rails[rid]['source_ids']}),
                                    'status': 'terminal_against_duct_requires_type_review'})
    return results
