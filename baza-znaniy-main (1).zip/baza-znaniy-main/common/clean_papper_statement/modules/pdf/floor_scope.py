"""Record where a ventilation plan applies without expanding measured quantities."""
import re


_NUMBER = r'([0-9]{1,3})(?:[-‑]?(?:го|й|ый))?(?!\w)'
_DASH = r'\s*[-‑−–—]\s*'
_RANGE = (
    re.compile(r'\bэтаж(?:и|ей)\s+' + _NUMBER + _DASH + _NUMBER, re.I),
    re.compile(r'(?<!\w)' + _NUMBER + _DASH + _NUMBER + r'\s+этаж(?:а|ей|и)?\b', re.I),
)
_SINGLE = (
    re.compile(r'\bэтаж\s+' + _NUMBER, re.I),
    re.compile(r'(?<![\w.‑−–—-])' + _NUMBER + r'\s+этаж(?:а)?\b', re.I),
)
_FLOOR_HEADING = re.compile(r'^(?:планы?\s+|этаж\w*\s+\d|\d)', re.I)
_VENTILATION_TYPE = re.compile(r'\b(общеобмен|противодым)\w*', re.I)


def floor_interval(text):
    """Read one numbered floor or an inclusive range from a heading."""
    if not _FLOOR_HEADING.match(text):
        return None
    for pattern in _RANGE:
        if match := pattern.search(text):
            return int(match[1]), int(match[2]), True
    for pattern in _SINGLE:
        if match := pattern.search(text):
            floor = int(match[1])
            return floor, floor, False
    return None


def _printed_scope(page):
    observations = []
    plans = page['title_evidence']
    for title in plans:
        if title['kind'] not in ('plan', 'floor_heading'):
            continue
        if interval := floor_interval(title['text']):
            observations.append((interval, {'pdf_page': page['pdf_page'], **title}))
    if not observations:
        return None
    intervals = {(a, b) for (a, b, _), _ in observations}
    ranges = {(a, b) for (a, b, explicit), _ in observations if explicit}
    start, end = next(iter(ranges or intervals))
    evidence = [observation for _, observation in observations]
    if len(ranges) > 1 or start > end or any(a < start or b > end for a, b in intervals):
        return {'source': 'conflicting_headings', 'floors': [], 'evidence': evidence}
    return {'source': 'printed_range' if ranges else 'printed_floor',
            'floors': list(range(start, end + 1)), 'evidence': evidence}


def _ventilation_type(page):
    return {match[1].casefold() for title in page['title_evidence'] if title['kind'] == 'plan'
            for match in _VENTILATION_TYPE.finditer(title['text'])}


def attach_floor_scopes(pages):
    """Use an explicit range first, then a forward gap between adjacent plans."""
    for page in pages:
        if page['kind'] == 'plan' and (scope := _printed_scope(page)) is not None:
            page['floor_scope'] = scope

    for page, following in zip(pages, pages[1:]):
        scope = page.get('floor_scope')
        next_scope = following.get('floor_scope')
        if (not scope or scope['source'] != 'printed_floor' or not next_scope
                or not next_scope['floors'] or _ventilation_type(page) != _ventilation_type(following)):
            continue
        first, = scope['floors']
        next_floor = next_scope['floors'][0]
        if next_floor > first + 1:
            page['floor_scope'] = {'source': 'inferred_between_plans',
                                   'floors': list(range(first, next_floor)),
                                   'evidence': scope['evidence'] + next_scope['evidence']}
