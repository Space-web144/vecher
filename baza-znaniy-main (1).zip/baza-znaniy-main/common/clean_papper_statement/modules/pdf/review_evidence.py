"""Frame source regions for album review without changing engineering decisions."""
from __future__ import annotations

import math


def _valid_box(box, bounds):
    return (isinstance(box, list) and len(box) == 4
            and all(type(v) in (int, float) for v in box)
            and bounds[0] <= box[0] < box[2] <= bounds[2]
            and bounds[1] <= box[1] < box[3] <= bounds[3])


def _contains(outer, inner):
    return (outer[0] <= inner[0] and outer[1] <= inner[1]
            and inner[2] <= outer[2] and inner[3] <= outer[3])


def _preview_frame(page, anchor, context=None):
    bounds = page["page_bounds_pt"]
    if not _valid_box(anchor, bounds):
        return None
    box = context if _valid_box(context, bounds) and _contains(context, anchor) else anchor
    left, top, right, bottom = bounds
    u0, v0, u1, v1 = [(value - origin) / extent for value, origin, extent in zip(
        box, (left, top, left, top), (right-left, bottom-top, right-left, bottom-top))]
    crop = {
        0: (u0, v0, u1, v1),
        90: (1-v1, u0, 1-v0, u1),
        180: (1-u1, 1-v1, 1-u0, 1-v0),
        270: (v0, 1-u1, v1, 1-u0),
    }[page["rotation"]]

    def padded(lo, hi):
        pad = max(.015, (hi-lo)*.12)
        start, end = max(0., lo-pad), min(1., hi+pad)
        # The existing preview endpoint needs at least 4% of either axis.
        if end-start < .045:
            start = min(start, .955)
            end = start+.045
        return round(math.floor(start*100000)/100000, 5), round(math.ceil(end*100000)/100000, 5)

    x0, x1 = padded(crop[0], crop[2])
    y0, y1 = padded(crop[1], crop[3])
    return {"pdf_page": page["pdf_page"], "bbox_pt": anchor, "crop_norm": [x0, y0, x1, y1]}


def attach_review_evidence(rows, segments, pages):
    """Associate existing sources with preview requests in the album response."""
    for row, segment in zip(rows, segments, strict=True):
        evidence = {}
        if segment["sources"]:
            plan = segment["sources"][0]
            if "id" not in plan and plan.get("pdf_page") == row.get("plan_page") and "bbox_pt" in plan:
                evidence["plan"] = _preview_frame(pages[plan["pdf_page"]], plan["bbox_pt"],
                                                  row.get("plan_context_bbox_pt"))
        marks = [source for source in segment["sources"] if "level_m" in source]
        scheme_number = row.get("axonometry_page")
        scheme = pages.get(scheme_number) if type(scheme_number) is int else None
        if segment["kind"] == "vertical" and scheme and scheme["kind"] in ("axonometry", "mixed"):
            source_box = row.get("axonometry_bbox_pt")
            if len(marks) == 2:
                a, b = (mark["bbox_pt"] for mark in marks)
                mark_box = [min(a[0], b[0]), min(a[1], b[1]), max(a[2], b[2]), max(a[3], b[3])]
                frame = _preview_frame(scheme, mark_box, source_box)
                evidence["elevation_span_m"] = round(abs(marks[0]["level_m"] - marks[1]["level_m"]), 6)
            else:
                frame = _preview_frame(scheme, source_box)
            if frame:
                evidence["axonometry"] = frame
        note = row.get("review_note")
        if isinstance(note, str) and note.strip():
            evidence["note"] = note.strip()[:300]
        if evidence:
            segment["review_evidence"] = evidence
