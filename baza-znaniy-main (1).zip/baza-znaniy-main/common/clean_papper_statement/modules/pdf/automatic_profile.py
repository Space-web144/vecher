"""Suggest a preview profile from PDF geometry in page coordinates."""
from __future__ import annotations

from bisect import bisect_left, bisect_right
from collections import Counter, defaultdict
import math
import re
from statistics import median


SUPPORTED_SCALES = (10, 20, 25, 40, 50, 75, 100, 150, 200, 250, 500)
KIND_TITLES = {
    "plan": re.compile(r"^(?:план\b.{0,100}вентиляц|вентиляция[ .–-]+план\b|ventilation plan\b)", re.I),
    "axonometry": re.compile(r"^(?:аксонометр|схем[аы]\s+(?:систем|вентиляц|(?:ДП|ДВ|П|В)\s*\d))", re.I),
    "section": re.compile(r"^(?:разрез\b|section\b)", re.I),
}
PRINTED_SCALE = re.compile(r"^(?:(?:масштаб|scale|м)\s*[:.=]?\s*)?1\s*:\s*(10|20|25|40|50|75|100|150|200|250|500)\s*$", re.I)


def _words_as_lines(words):
    groups = defaultdict(list)
    for word in words:
        groups[tuple(word[5:7])].append(word)
    return [" ".join(w[4] for w in sorted(line, key=lambda w: w[7]))
            for line in groups.values()]


def _in_region(a, b, box):
    return all(box[0] <= p[0] <= box[2] and box[1] <= p[1] <= box[3] for p in (a, b))


def _lines(path):
    for item in path.get("items", ()):
        if item[0] == "l":
            a, b = (tuple(p) for p in item[1:3])
            if all(math.isfinite(v) for v in (*a, *b)):
                yield a, b


def _dimension_scale(words, paths, box):
    """Match centred millimetre labels to dimension lines with two slash ticks."""
    labels = sorted((w[3], w[0], w[2], int(w[4])) for w in words
                    if re.fullmatch(r"[1-9][0-9]{2,4}", w[4]))
    if not labels:
        return None, [], False
    baselines = [label[0] for label in labels]
    candidates = []
    slashes = defaultdict(list)
    for path in paths:
        color = path.get("color")
        if not color or max(color) - min(color) > .04 or max(color) > .5:
            continue
        x0, y0, x1, y1 = path["rect"]
        if x0 > box[2] or x1 < box[0] or y0 > box[3] or y1 < box[1]:
            continue
        if bisect_left(baselines, y0 - 16) == bisect_right(baselines, y1 + 12):
            continue
        for a, b in _lines(path):
            if not _in_region(a, b, box):
                continue
            dx, dy = abs(b[0] - a[0]), abs(b[1] - a[1])
            if 1.2 <= dx <= 8 and .7 * dx <= dy <= 1.4 * dx:
                for point, other in ((a, b), (b, a)):
                    angle = 1 if other[0] > point[0] else -1
                    slope_sign = 1 if (other[1] - point[1]) * angle > 0 else -1
                    slashes[round(point[1], 1)].append((point[0], point[1], angle, slope_sign))
            elif dx >= 24 and dy <= .05:
                lo, hi = sorted((a[0], b[0]))
                y = (a[1] + b[1]) / 2
                start = bisect_left(baselines, y - 4)
                end = bisect_right(baselines, y + .3)
                for _, left, right, millimetres in labels[start:end]:
                    if abs((lo + hi - left - right) / 2) <= max(2.5, dx * .07):
                        candidates.append((lo, hi, y, millimetres))
    references = defaultdict(dict)
    for lo, hi, y, millimetres in candidates:
        at_line = defaultdict(set)
        for delta in (-1, 0, 1):
            for x, tick_y, direction, slope_sign in slashes.get(round(y + delta * .1, 1), ()):
                if abs(tick_y - y) <= .14:
                    at_line[round(x, 1), slope_sign].add(direction)
        # The two strokes of a slash share the dimension-line intersection.
        overhang = min(8, (hi - lo) * .16)
        ticks = {x for (x, _), signs in at_line.items() if len(signs) == 2}
        left = [x for x in ticks if lo - .15 <= x <= lo + overhang]
        right = [x for x in ticks if hi - overhang <= x <= hi + .15]
        if len(left) != 1 or len(right) != 1:
            continue
        span = right[0] - left[0]
        if span <= 0:
            continue
        ratio = millimetres * 72 / (span * 25.4)
        scale = min(SUPPORTED_SCALES, key=lambda value: abs(value - ratio))
        if abs(ratio / scale - 1) <= .0075:
            key = (left[0], right[0], round(y, 1))
            references[scale][key] = {"dimension_mm": millimetres,
                                      "ticks_pdf_pt": [[left[0], key[2]], [right[0], key[2]]],
                                      "scale_ratio": round(ratio, 3)}
    supported = [(scale, list(refs.values())) for scale, refs in references.items()
                 if len({ref["dimension_mm"] for ref in refs.values()}) >= 2]
    if len(supported) == 1:
        scale, evidence = supported[0]
        return scale, evidence[:8], False
    return None, [], len(supported) > 1


def _aligned_intervals(drawings, box):
    """Collect coloured straight strokes with consistent line weight and direction."""
    groups = defaultdict(set)
    for _, path in drawings:
        color = path.get("color")
        if not color or max(color) - min(color) < .16:
            continue
        style = tuple(round(float(c), 2) for c in color), round(float(path.get("width") or 0), 2)
        for a, b in _lines(path):
            if not _in_region(a, b, box):
                continue
            for axis in (0, 1):
                perpendicular = 1 - axis
                if abs(a[perpendicular] - b[perpendicular]) <= .05 and abs(a[axis] - b[axis]) >= 1.5:
                    across = (a[perpendicular] + b[perpendicular]) / 2
                    lo, hi = sorted((a[axis], b[axis]))
                    key = (axis, style, round(across / .15))
                    groups[key].add((round(lo, 3), round(hi, 3), round(across, 4)))
    return groups


def _stroke_evidence(groups):
    offsets, seams, dashes = [], [], []
    long_by_style = defaultdict(list)
    for (axis, style, _), segments in groups.items():
        near_offsets, near_seams, dash_gaps = [], [], []
        for lo, hi, across in segments:
            if hi - lo >= 16:
                long_by_style[axis, style].append((across, lo, hi))
        seq = sorted(segments)
        for (lo, hi, across), (next_lo, next_hi, other) in zip(seq, seq[1:]):
            gap = next_lo - hi
            offset = abs(across - other)
            if -.02 <= gap <= .25 and offset <= .1:
                if offset >= .003:
                    near_offsets.append(offset)
                if .008 <= gap <= .25:
                    near_seams.append(gap)
            if (.3 <= gap <= 14 and offset <= .04 and
                    max(hi - lo, next_hi - next_lo) <= 16):
                dash_gaps.append(gap)
                if len(dash_gaps) == 4:
                    med = median(dash_gaps)
                    if max(dash_gaps) - min(dash_gaps) <= max(.15, .2 * med):
                        dashes.append(med)
                        break
                    dash_gaps.pop(0)
            else:
                dash_gaps.clear()
        if near_offsets:
            offsets.append(median(near_offsets))
        if near_seams:
            seams.append(median(near_seams))

    widths = Counter()
    for segments in long_by_style.values():
        ordered = sorted(segments)
        for index, (across, lo, hi) in enumerate(ordered):
            for other, other_lo, other_hi in ordered[index + 1:index + 17]:
                width = other - across
                if width > 65:
                    break
                overlap = min(hi, other_hi) - max(lo, other_lo)
                if width >= 1 and overlap >= max(16, 4 * width, .9 * max(hi - lo, other_hi - other_lo)):
                    widths[round(width, 1)] += 1
                    break
    return offsets, seams, dashes, [width for width, count in widths.items() if count >= 4]


def _geometry_updates(drawings, box, defaults):
    offsets, seams, dashes, widths = _stroke_evidence(_aligned_intervals(drawings, box))
    geometry = {}
    evidence = {"alignment_groups": len(offsets), "seam_groups": len(seams),
                "repeated_dash_groups": len(dashes), "repeated_parallel_widths": len(widths)}
    for key, values, limits in (
        ("coaxial_tol_pt", offsets, (.03, .12)),
        ("join_gap_pt", seams, (.025, .2)),
    ):
        if len(values) >= 6 and max(values) <= 3 * min(values):
            geometry[key] = round(max(limits[0], min(limits[1], 1.5 * median(values))), 2)
    if widths:
        # Retain the existing span for other sizes, widening only with repeated evidence.
        geometry["rect_min_pt"] = round(max(.5, min(defaults["rect_min_pt"], .85 * min(widths))), 1)
        geometry["rect_max_pt"] = round(max(defaults["rect_max_pt"], 1.1 * max(widths)), 1)
    if len(dashes) >= 4:
        centre = median(dashes)
        common = [gap for gap in dashes if abs(gap - centre) <= .15 * centre]
        if len(common) >= max(4, .8 * len(dashes)):
            geometry.update({
                "dash_gap_min_pt": round(max(.2, .8 * min(common)), 1),
                "dash_gap_max_pt": round(min(30., 1.2 * max(common)), 1),
                "dash_median_min_pt": round(.9 * centre, 1),
            })
    return geometry, evidence


def suggest_preview_profile(page, region, paths, drawings, defaults, kind_hint=None):
    """Return unverified preview settings plus the scale and sample evidence."""
    box = tuple(region)
    page_box = tuple(page.rect)
    all_words = page.get_text("words", sort=False)
    titles = _words_as_lines(all_words)
    kinds = {kind for kind, pattern in KIND_TITLES.items() if any(pattern.search(line) for line in titles)}
    kind = next(iter(kinds)) if len(kinds) == 1 else "unknown"
    if kind == "unknown" and kind_hint == "plan":
        kind = "plan"
    words = [w for w in all_words if _in_region(w[:2], w[2:4], box)]
    scale_source = "unknown"
    scale = None
    dimensions = []
    if kind == "plan" and len(paths) and not page.rotation:
        scale, dimensions, conflicting = _dimension_scale(words, paths, box)
        printed = {int(found[1]) for title in _words_as_lines(words)
                   if (found := PRINTED_SCALE.fullmatch(title))}
        if conflicting or len(printed) > 1 or (scale is not None and printed and scale not in printed):
            scale, dimensions = None, []
            scale_source = "conflicting_scale_evidence"
        elif scale is not None:
            scale_source = "horizontal_dimension_ticks"
        elif len(printed) == 1:
            scale, scale_source = printed.pop(), "printed_scale"
    geometry, evidence = _geometry_updates(drawings, box, defaults)
    return {
        "region_kind": "fragment" if box != page_box else kind,
        "nominal_scale": f"1:{scale}" if scale else "unknown",
        "geometry_updates": geometry,
        "evidence": {**evidence, "scale_source": scale_source,
                     "dimensions": dimensions, "region_pdf_pt": list(box)},
    }
