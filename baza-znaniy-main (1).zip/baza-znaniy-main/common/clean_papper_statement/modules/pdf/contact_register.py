"""Build a portable local review of detected openings and terminal contacts."""
import argparse
import base64
from collections import defaultdict
from ..digest import sha256_stream
import json
import os
from pathlib import Path
import tempfile

import fitz

from .recovery_review import _report_digest


STATES = ('Ожидает проверки', 'Ответвление', 'Подключение оборудования',
          'Ложное срабатывание', 'Недостаточно данных')


def build_register(album):
    rows = []
    for sheet in album['pages']:
        for graph in sheet.get('plan_graphs', []):
            if (graph['source_pdf_sha256'] != album['source_pdf_sha256']
                    or graph['pdf_page'] != sheet['pdf_page']
                    or graph['coordinate_space'] != 'unrotated_pdf_points'):
                raise ValueError('Источник графа расходится с листом альбома.')
            groups = defaultdict(list)
            for candidate in graph['side_opening_candidates']:
                groups[('opening', candidate['port'])].append(candidate)
            for index, contact in enumerate(graph.get('terminal_contacts', [])):
                # Old graphs lack the contacted end. Keep their alternatives separate.
                caps = tuple(sorted(contact.get('terminal_cap_rails', [])))
                groups[('terminal', caps or ('legacy', index))].append(contact)
            for key, evidence in groups.items():
                identity = [graph['input_reports'], graph['region_pdf_pt'], key]
                rows.append({'id': _report_digest(identity), 'page': sheet['pdf_page'],
                             'kind': key[0], 'points': sorted({tuple(e['pdf_pt']) for e in evidence}),
                             'region': graph['region_pdf_pt'], 'evidence': evidence})
    digest = _report_digest([album['source_pdf_sha256'], rows])
    return {'review_digest': digest, 'pdf_sha256': album['source_pdf_sha256'], 'rows': rows}


def decisions_for(register, saved):
    if saved.get('review_digest') != register['review_digest'] or saved.get('pdf_sha256') != register['pdf_sha256']:
        raise ValueError('Решения относятся к другой версии проверки.')
    decisions = saved.get('decisions')
    ids = {r['id'] for r in register['rows']}
    if not isinstance(decisions, dict) or not decisions.keys() <= ids:
        raise ValueError('Неизвестная строка проверки.')
    for value in decisions.values():
        if (not isinstance(value, dict) or value.get('state') not in STATES
                or not isinstance(value.get('note'), str)):
            raise ValueError('Некорректное решение инженера.')
    return decisions


def preview(page, points):
    matrix = page.rotation_matrix
    pts = [fitz.Point(*point) * matrix for point in points]
    box = fitz.Rect(min(p.x for p in pts)-42, min(p.y for p in pts)-30,
                    max(p.x for p in pts)+42, max(p.y for p in pts)+30) & page.rect
    if box.is_empty:
        raise ValueError('Координаты фрагмента вне листа.')
    pix = page.get_pixmap(matrix=fitz.Matrix(3, 3), clip=box, alpha=False)
    return {'png': base64.b64encode(pix.tobytes('png')).decode(),
            'markers': [[100*(p.x*3-pix.x)/pix.width, 100*(p.y*3-pix.y)/pix.height] for p in pts]}


def write_review(pdf, album, output, saved=None):
    with pdf.open('rb') as stream:
        if sha256_stream(stream) != album['source_pdf_sha256']:
            raise ValueError('PDF отличается от источника отчёта.')
    register = build_register(album)
    decisions = decisions_for(register, saved) if saved is not None else {}
    with fitz.open(pdf) as doc:
        for row in register['rows']:
            row['preview'] = preview(doc[row['page']-1], row['points'])
    payload = json.dumps(dict(register, decisions=decisions, states=STATES), ensure_ascii=False).replace('<', r'\u003c')
    template = Path(__file__).with_name('contact_register.html').read_text(encoding='utf-8')
    return atomic_output(output, lambda temp: temp.write_text(template.replace('__REVIEW_DATA__', payload), encoding='utf-8'))


def atomic_output(output, writer):
    with tempfile.NamedTemporaryFile(dir=output.parent, delete=False) as stream:
        temp = Path(stream.name)
    try:
        writer(temp)
        os.replace(temp, output)
    finally:
        temp.unlink(missing_ok=True)


def export_excel(album, saved, output):
    from openpyxl import Workbook
    register = build_register(album)
    decisions = decisions_for(register, saved)
    workbook = Workbook()
    sheet = workbook.active
    sheet.title = 'Проверка мест'
    sheet.append(['Лист PDF', 'Тип гипотезы', 'Решение', 'Комментарий', 'Вариантов',
                  'Точки PDF (pt)', 'ID места'])
    detail = workbook.create_sheet('Векторные доказательства')
    detail.append(['ID места', 'Вариант', 'Точка PDF (pt)', 'ID исходного штриха'])
    for row in register['rows']:
        decision = decisions.get(row['id'], {'state': STATES[0], 'note': ''})
        sheet.append([row['page'], 'Боковое отверстие' if row['kind']=='opening' else 'Контакт торца',
                      decision['state'], decision['note'], len(row['evidence']), str(row['points']), row['id']])
        sheet.cell(sheet.max_row, 4).data_type = 's'
        for index, alternative in enumerate(row['evidence'], 1):
            for stroke in alternative['source_ids']:
                detail.append([row['id'], index, str(alternative['pdf_pt']), stroke])
    for tab in (sheet, detail):
        tab.freeze_panes = 'A2'
        tab.auto_filter.ref = tab.dimensions
    source = workbook.create_sheet('Источник')
    source.append(['SHA-256 PDF', register['pdf_sha256']])
    source.append(['Версия проверки', register['review_digest']])
    atomic_output(output, workbook.save)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('album', type=Path)
    parser.add_argument('--pdf', type=Path)
    parser.add_argument('--html', type=Path)
    parser.add_argument('--decisions', type=Path)
    parser.add_argument('--xlsx', type=Path)
    args = parser.parse_args()
    if not (args.html or args.xlsx) or (args.html and not args.pdf) or (args.xlsx and not args.decisions):
        parser.error('Для HTML укажите --pdf. Для Excel укажите --decisions.')
    files = [p.resolve() for p in (args.album, args.pdf, args.decisions, args.html, args.xlsx) if p]
    if len(files) != len(set(files)):
        parser.error('Укажите разные пути входных и выходных файлов.')
    try:
        album = json.loads(args.album.read_text())
        saved = json.loads(args.decisions.read_text()) if args.decisions else None
        if args.html:
            write_review(args.pdf, album, args.html, saved)
        if args.xlsx:
            export_excel(album, saved, args.xlsx)
    except (OSError, ValueError, KeyError, IndexError, TypeError) as exc:
        parser.exit(1, f'{exc}\n')


if __name__ == '__main__':
    main()
