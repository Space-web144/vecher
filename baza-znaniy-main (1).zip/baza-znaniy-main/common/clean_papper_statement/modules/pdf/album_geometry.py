"""Read candidate geometry in the source appropriate to each kind of duct."""
from __future__ import annotations

from .automatic_profile import suggest_preview_profile
from .review_evidence import _preview_frame
from .schematic_risers import (MAX_DASH_GAP_PT, MAX_RAIL_SEPARATION_PT, MIN_RAIL_SEPARATION_PT,
                              RAIL_X_TOL_PT, _rails_from_strokes, _riser_groups, _vertical_strokes)


MAX_REPORT_CANDIDATES = 36


def _section_hints(info, box):
    x = (box[0] + box[2]) / 2
    matches = []
    for mark in info["section_marks"]:
        if mark["context"] != "standalone_section_label_candidate":
            continue
        x0, y0, x1, y1 = mark["bbox_pt"]
        dx, dy = abs((x0+x1)/2-x), (y0+y1)/2-box[1]
        if dx <= 100 and -40 <= dy <= 60:
            matches.append((dx + 2*abs(dy), mark["id"]))
    return [ident for _, ident in sorted(matches)[:4]]


def _read_risers(page, info, paths, changes, limit):
    settings = {
        "dash_gap_pt": max(MAX_DASH_GAP_PT, changes.get("dash_gap_max_pt", 0)),
        "x_tolerance_pt": max(RAIL_X_TOL_PT, changes.get("coaxial_tol_pt", 0)),
        "min_separation_pt": min(MIN_RAIL_SEPARATION_PT, changes.get("rect_min_pt", MIN_RAIL_SEPARATION_PT)),
        "max_separation_pt": max(MAX_RAIL_SEPARATION_PT, changes.get("rect_max_pt", 0)),
    }
    raw = _vertical_strokes(page, page.rect, paths)
    rails = _rails_from_strokes(raw, dash_gap_pt=settings["dash_gap_pt"],
                                x_tolerance_pt=settings["x_tolerance_pt"])
    groups = _riser_groups(rails, min_separation_pt=settings["min_separation_pt"],
                           max_separation_pt=settings["max_separation_pt"])
    rows = []
    for group in groups[:limit]:
        outlines = group["rails"]
        box = [outlines[0]["x_pt"], min(r["y0_pt"] for r in outlines),
               outlines[-1]["x_pt"], max(r["y1_pt"] for r in outlines)]
        rows.append({
            "candidate_id": group["candidate_id"], "status": group["status"],
            "source": _preview_frame(info, box), "bounding_span_pt": round(box[3]-box[1], 3),
            "source_stroke_ids": [r["vector_ids"][0] for r in outlines][:24],
            "section_mark_ids_near_top": _section_hints(info, box),
        })
    return rows, len(groups), settings, False


def _read_plan(page, info, selected, changes, plan_detector, limit):
    labels = [{"text": mark["raw"], "at_pdf_pt": mark["bbox_pt"][:2]}
              for mark in info["section_marks"] if mark.get("context")=="standalone_section_label_candidate"]
    network = plan_detector(page, page.rect, labels, drawings=selected, settings=changes, automatic=True,
                            max_lines=100000, candidate_limit=1200)
    rows = []
    for trace in network["candidates"][:limit]:
        a, b = trace["center_start_pdf_pt"], trace["center_end_pdf_pt"]
        pad = trace["width_between_strokes_pt"] / 2
        bounds = info["page_bounds_pt"]
        box = [max(bounds[0], min(a[0], b[0])-pad), max(bounds[1], min(a[1], b[1])-pad),
               min(bounds[2], max(a[0], b[0])+pad), min(bounds[3], max(a[1], b[1])+pad)]
        rows.append({"candidate_id": trace["candidate_id"], "status": trace["status"],
                     "source": _preview_frame(info, box), "projected_length_pt": trace["projected_length_pt"],
                     "source_stroke_ids": trace["source_line_ids"][:12],
                     "dimension_text_nearby": trace["dimension_text_nearby"],
                     "center_start_pdf_pt": a, "center_end_pdf_pt": b,
                     "stroke_color": trace["stroke_color"], "width_between_strokes_pt": trace["width_between_strokes_pt"],
                     "spatial_group_id": trace.get("spatial_group_id")})
    return (rows, len(network["candidates"]), network["parameters"], network["scanning"]["trace_scan_truncated"])


def read_album_geometry(page, info, *, defaults, sampler, plan_detector, limit=MAX_REPORT_CANDIDATES):
    """Inspect a classified sheet with its own profile. Outputs are candidates."""
    is_plan = info["kind"] == "plan"
    source_role = "floor_plan" if is_plan else "riser_axonometry"
    rotation = page.rotation
    # PyMuPDF text and primitive coordinates are defined on the unrotated page.
    if rotation:
        page.set_rotation(0)
    try:
        paths = page.get_cdrawings() if hasattr(page, "get_cdrawings") else page.get_drawings()
        selected, inventory = sampler(paths, page.rect, budget=50000)
        # The trace detector reads colored strokes only. Include every original colored path,
        # independent of the neutral architectural sampling budget.
        from .drawing_sample import _colored
        colored = [(i,p) for i,p in enumerate(paths) if _colored(p.get('color'))]
        profile = suggest_preview_profile(page, page.rect, paths, selected, defaults, kind_hint=info['kind'])
        changes = profile.pop("geometry_updates")
        if is_plan:
            rows, count, settings, limited = _read_plan(page, info, colored, changes, plan_detector, limit)
        else:
            rows, count, settings, limited = _read_risers(page, info, paths, changes, limit)
        return {"status": "inspected" if paths else "no_vector_geometry",
                "source_role": source_role, "candidate_count": count,
                "candidates": rows, "candidate_list_limited": count > len(rows) or limited,
                "automatic_profile": profile, "geometry_parameters": settings,
                "sampling": {"all_colored_paths":len(colored), "profile_sample_limited":inventory["sampling_truncated"]}}
    except (RuntimeError, ValueError, TypeError, OverflowError, IndexError):
        return {"status": "geometry_unavailable", "source_role": source_role}
    finally:
        if rotation:
            page.set_rotation(rotation)

def local_geometry_reader(page, info):
    """Use the same sampling and trace parameters as the CleanPapper PDF worker."""
    from .drawing_sample import sample_drawings
    from .plan_traces import DEFAULTS, extract_trace_network
    return read_album_geometry(page, info, defaults=DEFAULTS, sampler=sample_drawings,
                               plan_detector=extract_trace_network, limit=None)
