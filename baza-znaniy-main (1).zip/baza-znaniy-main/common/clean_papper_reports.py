#!/usr/bin/env python3
"""Export *unverified* Clean Papper evidence as a readable XLSX workbook.

Uses Python standard library only so the VPS worker needs no extra packages.
Input is a small browser-generated JSON evidence snapshot, not a project PDF.
No quantity, duct length, area, steel grade or product count is fabricated.
"""
from __future__ import annotations

import io
import json
import re
import sys
import zipfile
from datetime import datetime, timezone
from xml.sax.saxutils import escape

NS = "http://schemas.openxmlformats.org/spreadsheetml/2006/main"
REL = "http://schemas.openxmlformats.org/officeDocument/2006/relationships"
MAX_INPUT = 200000
MAX_ITEMS = 16
MAX_LABELS = 45

CATEGORIES = {
    "duct": "Воздуховод (кандидат)",
    "elbow": "Отвод (кандидат)",
    "transition": "Переход (кандидат)",
    "tee": "Тройник (кандидат)",
    "valve": "Клапан (кандидат)",
    "fan": "Вентилятор (кандидат)",
    "air_terminal": "Воздухораспределитель (кандидат)",
}
FORMS = ("Обзор", "Материалы", "Проверка длин", "Все объекты ИИ", "Надписи PDF", "Линии PDF", "Геометрия PDF", "Цвета PDF", "Цветные трассы", "Пространственные группы", "Замечания")


def safe_text(value, limit=500):
    value = str(value if value is not None else "")
    value = "".join(ch for ch in value if ord(ch) >= 32 or ch in "\n\t")
    value = value[:limit]
    # Worksheet content comes from a model and a PDF; prevent formula injection.
    if value and value[0] in "=+-@\t\r":
        value = "'" + value
    return value


def x(value):
    return escape(safe_text(value), {'"': '&quot;', "'": '&apos;'})


def integer(value, upper=1000000):
    if isinstance(value, bool):
        return 0
    try:
        n = int(value)
    except (ValueError, TypeError, OverflowError):
        return 0
    return min(max(n, 0), upper)


def verify_payload(data):
    if not isinstance(data, dict) or data.get("schema") != "clean-papper.evidence.v1":
        raise ValueError("Unsupported report format")
    src, geo, vision = data.get("source"), data.get("geometry"), data.get("vision")
    if not all(isinstance(item, dict) for item in (src, geo, vision)):
        raise ValueError("Missing report sections")
    items, labels = vision.get("elements"), geo.get("section_text_candidates")
    if not isinstance(items, list) or len(items) > MAX_ITEMS:
        raise ValueError("Invalid model objects")
    if not isinstance(labels, list) or len(labels) > MAX_LABELS:
        raise ValueError("Invalid PDF labels")
    if not isinstance(vision.get("notes"), list) or len(vision["notes"]) > 5:
        raise ValueError("Invalid model notes")
    if integer(src.get("page"), 600) < 1:
        raise ValueError("Invalid PDF page")
    if not isinstance(src.get("crop_normalized"), list) or len(src["crop_normalized"]) != 4:
        raise ValueError("Invalid crop")
    if any(not isinstance(item, dict) for item in items + labels):
        raise ValueError("Invalid report rows")
    trace = geo.get("vector_trace", {})
    if not isinstance(trace, dict):
        raise ValueError("Invalid vector trace")
    line_rows = trace.get("candidates", [])
    if not isinstance(line_rows, list) or len(line_rows) > 55 or any(
        not isinstance(line, dict) for line in line_rows
    ):
        raise ValueError("Invalid line candidates")
    review = geo.get("vector_review", {})
    if not isinstance(review, dict):
        raise ValueError("Invalid vector review")
    links = review.get("manual_links", [])
    if not isinstance(links, list) or len(links) > 55 or any(
        not isinstance(link, dict) for link in links
    ):
        raise ValueError("Invalid manually linked rows")
    duct = geo.get("duct_geometry", {})
    if not isinstance(duct, dict):
        raise ValueError("Invalid geometry groups")
    candidates = duct.get("candidates", [])
    layers = duct.get("layer_statistics", [])
    if (not isinstance(candidates, list) or len(candidates) > 35 or
        any(not isinstance(row, dict) for row in candidates)):
        raise ValueError("Invalid geometry candidates")
    if (not isinstance(layers, list) or len(layers) > 12 or
        any(not isinstance(row, dict) for row in layers)):
        raise ValueError("Invalid PDF color layers")
    trace_network = duct.get("trace_network", {})
    if not isinstance(trace_network, dict):
        raise ValueError("Invalid stage 10.2 trace record")
    trace_items = trace_network.get("candidates", [])
    trace_groups = trace_network.get("spatial_groups", [])
    if not isinstance(trace_items, list) or len(trace_items) > 100 or any(
        not isinstance(row, dict) for row in trace_items
    ):
        raise ValueError("Invalid stage 10.2 trace candidates")
    if not isinstance(trace_groups, list) or len(trace_groups) > 100 or any(
        not isinstance(row, dict) for row in trace_groups
    ):
        raise ValueError("Invalid stage 10.2 spatial groups")
    review = geo.get("duct_review", {})
    if not isinstance(review, dict):
        raise ValueError("Invalid geometry review")
    colors = review.get("layer_systems", [])
    if (not isinstance(colors, list) or len(colors) > 12 or
        any(not isinstance(row, dict) for row in colors)):
        raise ValueError("Invalid layer names")
    return src, geo, vision


def col(index):
    result = ""
    while index:
        index, r = divmod(index - 1, 26)
        result = chr(65 + r) + result
    return result


def cell(address, content, style=5):
    if isinstance(content, dict) and "formula" in content:
        return ('<c r="%s" s="%d"><f>%s</f><v></v></c>' %
                (address, style, x(content["formula"])))
    if isinstance(content, (int, float)) and not isinstance(content, bool):
        return '<c r="%s" s="%d"><v>%s</v></c>' % (address, style, content)
    txt = x(content)
    return '<c r="%s" s="%d" t="inlineStr"><is><t xml:space="preserve">%s</t></is></c>' % (
        address, style, txt
    )


def worksheet(title, subtitle, headers, rows, widths):
    n = len(headers)
    if not n:
        raise ValueError("Headers required")
    xml = [
        '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>',
        '<worksheet xmlns="%s">' % NS,
        '<sheetViews><sheetView workbookViewId="0">'
        '<pane ySplit="4" topLeftCell="A5" activePane="bottomLeft" state="frozen"/>'
        '</sheetView></sheetViews>',
        '<sheetFormatPr defaultRowHeight="20"/>',
        '<cols>'
    ]
    for i in range(n):
        width = widths[i] if i < len(widths) else 22
        xml.append('<col min="%d" max="%d" width="%.1f" customWidth="1"/>' %
                   (i + 1, i + 1, min(max(width, 10), 50)))
    xml.append('</cols><sheetData>')
    xml.append('<row r="1" ht="32" customHeight="1">%s</row>' %
               cell("A1", title, 1))
    xml.append('<row r="2" ht="38" customHeight="1">%s</row>' %
               cell("A2", subtitle, 2))
    xml.append('<row r="3" ht="10" customHeight="1"/>')
    xml.append('<row r="4" ht="32" customHeight="1">' +
               "".join(cell("%s4" % col(i+1), h, 3)
                       for i, h in enumerate(headers)) + '</row>')
    for row_index, values in enumerate(rows, 5):
        style = 5 if row_index % 2 else 6
        xml.append('<row r="%d" ht="44" customHeight="1">' % row_index)
        for i in range(n):
            value = values[i] if i < len(values) else ""
            xml.append(cell("%s%d" % (col(i+1), row_index), value, style))
        xml.append('</row>')
    xml.append('</sheetData>')
    if rows:
        xml.append('<autoFilter ref="A4:%s%d"/>' % (col(n), len(rows)+4))
    xml.append('<mergeCells count="2"><mergeCell ref="A1:%s1"/><mergeCell ref="A2:%s2"/></mergeCells>' %
               (col(n), col(n)))
    xml.append('</worksheet>')
    return "".join(xml).encode("utf-8")


def styles():
    return ('''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<styleSheet xmlns="%s">
<fonts count="4">
 <font><sz val="11"/><name val="Aptos"/></font>
 <font><b/><sz val="17"/><color rgb="FFFFFFFF"/><name val="Aptos Display"/></font>
 <font><sz val="11"/><color rgb="FF506577"/><name val="Aptos"/></font>
 <font><b/><sz val="10"/><color rgb="FFFFFFFF"/><name val="Aptos"/></font>
</fonts>
<fills count="5">
 <fill><patternFill patternType="none"/></fill>
 <fill><patternFill patternType="gray125"/></fill>
 <fill><patternFill patternType="solid"><fgColor rgb="FF15324B"/><bgColor indexed="64"/></patternFill></fill>
 <fill><patternFill patternType="solid"><fgColor rgb="FF276384"/><bgColor indexed="64"/></patternFill></fill>
 <fill><patternFill patternType="solid"><fgColor rgb="FFF1F6FA"/><bgColor indexed="64"/></patternFill></fill>
</fills>
<borders count="2"><border><left/><right/><top/><bottom/><diagonal/></border>
 <border><left/><right/><top/><bottom style="hair"><color rgb="FFDCE5EC"/></bottom><diagonal/></border></borders>
<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>
<cellXfs count="7">
 <xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/>
 <xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFill="1" applyFont="1" applyAlignment="1"><alignment vertical="center"/></xf>
 <xf numFmtId="0" fontId="2" fillId="4" borderId="0" xfId="0" applyFill="1" applyFont="1" applyAlignment="1"><alignment wrapText="1" vertical="center"/></xf>
 <xf numFmtId="0" fontId="3" fillId="3" borderId="0" xfId="0" applyFill="1" applyFont="1" applyAlignment="1"><alignment wrapText="1" vertical="center"/></xf>
 <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyAlignment="1"><alignment wrapText="1" vertical="top"/></xf>
 <xf numFmtId="0" fontId="0" fillId="0" borderId="1" xfId="0" applyAlignment="1"><alignment wrapText="1" vertical="top"/></xf>
 <xf numFmtId="0" fontId="0" fillId="4" borderId="1" xfId="0" applyFill="1" applyAlignment="1"><alignment wrapText="1" vertical="top"/></xf>
</cellXfs>
<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles>
</styleSheet>''' % NS).encode("utf-8")


def list_sheets(data):
    src, geo, vision = verify_payload(data)
    items, labels = vision["elements"], geo["section_text_candidates"]
    usable = [e for e in items if str(e.get("type")) in CATEGORIES]
    descriptions = []
    for i, e in enumerate(items, 1):
        descriptions.append([
            e.get("evidence_id") or "AI-%03d" % i, e.get("type", ""),
            e.get("label", ""), e.get("dimension", ""), e.get("system", ""),
            e.get("confidence", ""),
            "Есть текст" if e.get("pdf_dimension_text_match") else "Нет подтверждения",
            e.get("note", ""), "Не подтверждено",
        ])
    materials = []
    for i, e in enumerate(usable, 1):
        kind = str(e.get("type") or "")
        materials.append([
            i, e.get("evidence_id", ""), CATEGORIES[kind],
            e.get("label", ""), e.get("dimension", ""),
            e.get("system", ""), e.get("confidence", ""),
            "Текст найден" if e.get("pdf_dimension_text_match") else "Не найден",
            "уточнить", "", "", "", "не установлен",
            "Требует инженерной проверки", e.get("note", ""),
        ])
    calcs = []
    for e in usable:
        if e.get("type") != "duct":
            continue
        row = len(calcs) + 5
        calcs.append([
            e.get("evidence_id", ""), e.get("label", ""),
            e.get("system", ""), e.get("dimension", ""),
            "", "", "", "Нет",
            {"formula": 'IF(AND(H%d="Да",ISNUMBER(E%d),ISNUMBER(F%d),ISNUMBER(G%d)),ROUND(2*(E%d+F%d)/1000*G%d,3),"")' %
             (row, row, row, row, row, row, row)},
            "Заполнить W, H, L после инженерного обмера; утвердить Да.",
        ])
    src_rows = []
    for i, e in enumerate(labels, 1):
        coords = e.get("at_pdf_pt") if isinstance(e.get("at_pdf_pt"), list) else []
        src_rows.append([i, e.get("text", ""),
                         coords[0] if len(coords) > 0 else "",
                         coords[1] if len(coords) > 1 else "",
                         "Подпись PDF, без привязки к физическому объекту"])
    # PDF vector candidate strokes are NOT ducts, CAD handles, or verified centerlines.
    trace = geo.get("vector_trace") or {}
    vector_lines = trace.get("candidates") or []
    review = geo.get("vector_review") or {}
    manual_links = {
        str(link.get("source_id")): link
        for link in (review.get("manual_links") or [])
        if isinstance(link.get("source_id"), str)
    }
    calibration = review.get("calibration")
    factor = 0.0
    if isinstance(calibration, dict) and calibration.get("method") == "two_user_points_known_distance":
        try:
            factor = float(calibration.get("mm_per_pdf_pt", 0))
        except (TypeError, ValueError, OverflowError):
            factor = 0.0
        if not (0 < factor < 100000):
            factor = 0.0
    vector_rows = []
    for line in vector_lines:
        start = line.get("start_pdf_pt") if isinstance(line.get("start_pdf_pt"), list) else []
        end = line.get("end_pdf_pt") if isinstance(line.get("end_pdf_pt"), list) else []
        dim_hint = line.get("dimension_text_nearby") or {}
        system_hint = line.get("system_text_nearby") or {}
        manual = manual_links.get(str(line.get("source_id")), {})
        pt_length = line.get("projected_length_pt", 0)
        try:
            pt_length = float(pt_length)
        except (TypeError, ValueError, OverflowError):
            pt_length = 0.0
        if not 0 <= pt_length < 100000:
            pt_length = 0.0
        # A temporary, PLANAR projection estimate, deliberately never
        # propagated to Materials or Verified Lengths.
        provisional_m = round(pt_length * factor / 1000, 4) if factor else ""
        vector_rows.append([
            line.get("candidate_id", ""), line.get("source_id", ""),
            start[0] if len(start) > 0 else "", start[1] if len(start) > 1 else "",
            end[0] if len(end) > 0 else "", end[1] if len(end) > 1 else "",
            round(pt_length, 3),
            dim_hint.get("text", "") if isinstance(dim_hint, dict) else "",
            system_hint.get("text", "") if isinstance(system_hint, dict) else "",
            manual.get("system_manual", ""), manual.get("ai_evidence_id", ""),
            provisional_m, "Графическая линия; не подтверждено",
        ])
    duct = geo.get("duct_geometry") or {}
    duct_items = duct.get("candidates") or []
    layer_items = duct.get("layer_statistics") or []
    manual_colors = {
        str(x.get("stroke_color")): x.get("system_manual", "")
        for x in (geo.get("duct_review") or {}).get("layer_systems", [])
        if isinstance(x.get("stroke_color"), str)
    }
    duct_rows = []
    for candidate in duct_items:
        p0 = candidate.get("center_start_pdf_pt") or []
        p1 = candidate.get("center_end_pdf_pt") or []
        hint = candidate.get("dimension_text_nearby") or {}
        source_ids = candidate.get("source_line_ids") or []
        color = str(candidate.get("stroke_color") or "")
        duct_rows.append([
            candidate.get("candidate_id", ""),
            "Пара стенок" if candidate.get("kind") == "rectangular_wall_pair"
                else "Пунктирная ось + стенки",
            color, candidate.get("orientation", ""),
            p0[0] if len(p0) == 2 else "",
            p0[1] if len(p0) == 2 else "",
            p1[0] if len(p1) == 2 else "",
            p1[1] if len(p1) == 2 else "",
            candidate.get("projected_length_pt", ""),
            candidate.get("width_between_strokes_pt", ""),
            hint.get("text", "") if isinstance(hint, dict) else "",
            manual_colors.get(color, ""),
            ", ".join(str(x) for x in source_ids[:24]),
            "Кандидат, не подтверждено",
            "", "", "",
        ])
    color_rows = []
    for layer in layer_items:
        color = str(layer.get("stroke_color") or "")
        color_rows.append([
            color, layer.get("stroke_width_pt", ""),
            layer.get("dash_signature", ""), layer.get("stroke_count", ""),
            layer.get("pdf_path_count", ""),
            layer.get("total_stroke_length_pt", ""),
            manual_colors.get(color, ""),
            "Система не подтверждена",
        ])
    network = duct.get("trace_network") or {}
    network_scan = network.get("scanning") or {}
    network_items = network.get("candidates") or []
    network_groups = network.get("spatial_groups") or []
    network_rows = []
    for candidate in network_items:
        p0 = candidate.get("center_start_pdf_pt") or []
        p1 = candidate.get("center_end_pdf_pt") or []
        hint = candidate.get("dimension_text_nearby") or {}
        source_ids = candidate.get("source_line_ids") or []
        color = str(candidate.get("stroke_color") or "")
        network_rows.append([
            candidate.get("candidate_id", ""),
            candidate.get("spatial_group_id", ""),
            candidate.get("orientation", ""),
            candidate.get("angle_deg", ""),
            color,
            p0[0] if len(p0) == 2 else "",
            p0[1] if len(p0) == 2 else "",
            p1[0] if len(p1) == 2 else "",
            p1[1] if len(p1) == 2 else "",
            candidate.get("projected_length_pt", ""),
            candidate.get("width_between_strokes_pt", ""),
            hint.get("text", "") if isinstance(hint, dict) else "",
            manual_colors.get(color, ""),
            ", ".join(str(x) for x in source_ids[:24]),
            "Пара цветных линий, не подтверждено",
            "", "", "",
        ])
    group_rows = []
    for group in network_groups:
        coords = group.get("bounds_pdf_pt") or []
        color = str(group.get("stroke_color") or "")
        group_rows.append([
            group.get("group_id", ""), color, group.get("candidate_count", ""),
            coords[0] if len(coords) == 4 else "",
            coords[1] if len(coords) == 4 else "",
            coords[2] if len(coords) == 4 else "",
            coords[3] if len(coords) == 4 else "",
            manual_colors.get(color, ""), "Близость на PDF, не подтверждено",
        ])
    inventory = geo.get("drawing_inventory") or {}
    applied_profile = (duct.get("profile_applied") or {})
    summary = [
        ["Файл", src.get("filename",""), "Название передано браузером, без повторной загрузки PDF"],
        ["Страница", integer(src.get("page"), 600), "Одна страница/выбранный фрагмент"],
        ["Область (нормализованные координаты)", ", ".join(str(x) for x in src.get("crop_normalized", [])), "0–1"],
        ["Дата формирования", data.get("created_at", ""), "UTC, время браузера"],
        ["Модель", vision.get("model", ""), "Результат одного вызова"],
        ["Токены входящие", integer(vision.get("input_tokens")), "Техническая информация"],
        ["Токены исходящие", integer(vision.get("output_tokens")), "Техническая информация"],
        ["PDF путей (весь лист)", integer(inventory.get("source_paths_total"), 10000000),
         "Инвентаризация всей страницы; не количество изделий"],
        ["PDF путей (выбранная область)", integer(inventory.get("region_paths_total"), 10000000),
         "Инвентаризация всей области; не количество изделий"],
        ["Путей передано геометрии", integer(inventory.get("selected_paths"), 50000),
         "Ограниченная выборка по всей странице с приоритетом цвета"],
        ["Выборка неполная", "Да" if inventory.get("sampling_truncated") else "Нет",
         "При Да отсутствие кандидатов нельзя считать отсутствием воздуховодов"],
        ["Цветных штрихов / заливок в области", integer(inventory.get("colored_paths_in_region"), 10000000),
         "Проверка цвета без анализа вложенных растровых изображений"],
        ["Профиль настройки", applied_profile.get("region_kind", "unknown"),
         "Текущий тип области; настройки не являются инженерным утверждением"],
        ["Номинальный масштаб", applied_profile.get("nominal_scale", "unknown"),
         "Масштаб НЕ подтверждён по размерным цепочкам"],
        ["Графические пути в выборке", integer(geo.get("vector_paths_sampled"), 100000),
         "Не длина / не количество"],
        ["Достигнут лимит выборки", "Да" if geo.get("sampling_limited") else "Нет", "При Да результаты неполные"],
        ["Подписи PDF", len(labels), "Не связаны однозначно с воздуховодами"],
        ["Линии PDF (кандидаты)", len(vector_lines), "Не являются подсчётом воздуховодов"],
        ["Кандидаты геометрии воздуховодов", len(duct_items),
         "Пары стенок и пунктирные оси; НЕ количество изделий"],
        ["Цветные трассы (кандидаты)", len(network_items),
         "Параллельные линии; не подтверждённые воздуховоды"],
        ["Пространственные группы", len(network_groups),
         "Близость линий без доказательства общих систем и высот"],
        ["Наклонные цветные трассы", sum(
            1 for x in network_items if x.get("orientation") == "inclined"
         ), "Не подтверждённые оси, только PDF проекция"],
        ["Найденных потенциальных цветных пар", integer(
            network_scan.get("parallel_pair_proposals"), 100000),
         "Геометрические комбинации, не количество элементов"],
        ["Цветовые группы PDF", len(layer_items),
         "Цвет не подтверждает принадлежность системе"],
        ["Масштаб", "Ручная калибровка (непроверенная)" if factor else "Не калиброван",
         "PDF pt не гарантирует реальную длину"],
        ["Кандидаты элементов ИИ", len(items), "Не доказанное количество изделий"],
        ["Кандидаты материалов/оборудования", len(usable), "Не итоговые позиции сметы"],
        ["Подтверждено количеств", 0, "Не проводилось"],
        ["Подтверждено длин, м", "", "Не проводилось"],
        ["Подтверждено площадей, м²", "", "Не проводилось"],
        ["Статус", "ПРЕДВАРИТЕЛЬНО", "Требуется инженерная проверка по графике"],
    ]
    notes = [
        ["Ограничение", "ИИ распознаёт не более 16 объектов за один запрос; это не полный подсчёт по листу."],
        ["Ограничение", "Найдено не более 45 подписей; лимит графических путей — 8000."],
        ["Ограничение", "Совпадение текста размера в PDF не подтверждает, что он относится к объекту ИИ."],
        ["Ограничение", "Не установлены фактические количества, длины, площади и материал изготовления."],
        ["Ограничение", "Данные одного изображения нельзя суммировать как физические изделия."],
        ["Ограничение", "Векторная линия может быть стеной, штрихом контура, выноской или частью оборудования."],
        ["Ограничение", "Ручной масштаб даёт только проекционную оценку. Ни метры, ни площади не утверждаются."],
        ["Ограничение", "Геометрические пары стенок могут быть архитектурой; ширина в PDF pt не является проверенным сечением."],
        ["Ограничение", "Цвета PDF требуют ручного присвоения систем; пороги поиска основаны на 1:100 и условны."],
        ["Ограничение", "Группы 10.2 получены из близости цветных линий. Пересечения могут быть разными высотами или архитектурой."],
        ["Ограничение", "Отбор 100 пар для просмотра не равен полному количеству воздуховодов или узлов."],
        ["Следующий шаг", "Верифицировать объект и систему, связать с CAD/IFC координатами."],
        ["Следующий шаг", "Указать реальное сечение W/H, обмеренную длину и признак проверки."],
    ]
    for note in vision["notes"][:5]:
        notes.append(["Замечание Claude", note])
    return [
        ("Обзор", "Наблюдения одной страницы/области · без утверждённых объёмов",
         ["Параметр", "Значение", "Смысл / оговорка"], summary, [34, 48, 50]),
        ("Материалы", "Позиции-кандидаты по Claude · количество, длина, площадь и материал изготовления не установлены",
         ["№", "ID", "Категория", "Описание (ИИ)", "Размер (ИИ)", "Система (ИИ)",
          "Уверенность", "Текст PDF", "Ед. изм.", "Кол-во", "Длина, м",
          "Площадь, м²", "Материал изготовления", "Статус", "Комментарий ИИ"],
         materials, [6, 12, 30, 46, 20, 18, 14, 18, 15, 13, 15, 17, 21, 30, 49]),
        ("Проверка длин", "Формула площади работает только при проверенном прямоугольном воздуховоде и подтверждении «Да»",
         ["ID", "Объект ИИ", "Система ИИ", "Размер ИИ", "W мм (проверить)",
          "H мм (проверить)", "L м (проверить)", "Подтверждено?",
          "Площадь м² (формула)", "Примечание"],
         calcs, [13, 46, 18, 18, 18, 18, 18, 18, 23, 48]),
        ("Все объекты ИИ", "Полный список модели, включая неоднозначные объекты, надписи и оборудование",
         ["ID", "Тип", "Описание", "Размер (ИИ)", "Система (ИИ)", "Уверенность",
          "Сверка текста", "Комментарий ИИ", "Статус"],
         descriptions, [13, 19, 48, 20, 18, 16, 22, 48, 22]),
        ("Надписи PDF", "Извлечённые векторным анализом подписи и координаты PDF (пункты, не миллиметры)",
         ["№", "Текст", "X (PDF pt)", "Y (PDF pt)", "Оговорка"],
         src_rows, [7, 24, 15, 15, 51]),
        ("Линии PDF", "Графические штрихи с координатами; предварительная калибровка не означает физической длины",
         ["ID", "PDF path/item", "X нач.", "Y нач.", "X кон.", "Y кон.",
          "Длина PDF pt", "Близкий размер", "Близкая система",
          "Система вручную", "Связь с ИИ", "Проекция м (НЕ подтвержд.)", "Статус"],
         vector_rows, [12, 33, 13, 13, 13, 13, 16, 18, 18, 21, 17, 22, 43]),
        ("Геометрия PDF", "Этап 10: геометрические пары и осевые — НЕ утверждённые воздуховоды, длины в PDF pt",
         ["ID", "Тип гипотезы", "Цвет", "Направление", "X0 PDF pt", "Y0 PDF pt",
          "X1 PDF pt", "Y1 PDF pt", "Проекция PDF pt", "Ширина PDF pt",
          "Близкий размер", "Система вручную", "Исходные PDF штрихи",
          "Статус", "Кол-во (нет)", "Метры (нет)", "Площадь (нет)"],
         duct_rows,[12,27,14,15,15,15,15,15,20,17,20,22,49,27,16,16,17]),
        ("Цвета PDF", "Статистика исходных штрихов; цвет не определяет вентиляционную систему без проверки",
         ["Цвет", "Толщина PDF pt", "Пунктир", "Штрихов", "PDF-путей",
          "Длина графики PDF pt", "Система вручную", "Статус"],
         color_rows,[17,22,26,15,15,25,24,32]),
        ("Цветные трассы", "Этап 10.2: параллельные цветные линии, в том числе наклонные, НЕ подтверждённые воздуховоды",
         ["ID", "Группа", "Ориентация", "Угол град", "Цвет",
          "X0 PDF pt", "Y0 PDF pt", "X1 PDF pt", "Y1 PDF pt",
          "Проекция PDF pt", "Разнос линий PDF pt", "Близкий размер",
          "Система вручную", "Исходные ID PDF", "Статус",
          "Кол-во (нет)", "Длина м (нет)", "Площадь м² (нет)"],
         network_rows, [12, 12, 16, 13, 14, 15, 15, 15, 15,
                        21, 22, 18, 22, 58, 36, 16, 17, 18]),
        ("Пространственные группы", "Соприкосновение линий на плане не доказывает единую сеть/высоту",
         ["ID", "Цвет", "Пар линий", "Xmin PDF pt", "Ymin PDF pt",
          "Xmax PDF pt", "Ymax PDF pt", "Система вручную", "Статус"],
         group_rows, [13, 16, 18, 17, 17, 17, 17, 24, 52]),
        ("Замечания", "Причины, почему это ещё не полная ведомость материалов",
         ["Тип", "Замечание"], notes, [22, 91]),
    ]


def build_xlsx(data):
    sheets = list_sheets(data)
    content_types = [
        '<?xml version="1.0" encoding="UTF-8"?>',
        '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">',
        '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>',
        '<Default Extension="xml" ContentType="application/xml"/>',
        '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>',
        '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>',
    ]
    for i in range(len(sheets)):
        content_types.append('<Override PartName="/xl/worksheets/sheet%d.xml" '
                             'ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' % (i+1))
    content_types.append('</Types>')
    book = ('<?xml version="1.0" encoding="UTF-8"?>'
            '<workbook xmlns="%s" xmlns:r="%s"><sheets>' % (NS, REL))
    for i, sheet in enumerate(sheets, 1):
        book += '<sheet name="%s" sheetId="%d" r:id="rId%d"/>' % (x(sheet[0]), i, i)
    book += '</sheets><calcPr calcId="191029" fullCalcOnLoad="1"/></workbook>'
    relations = ('<?xml version="1.0" encoding="UTF-8"?>'
                 '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">')
    for i in range(len(sheets)):
        relations += ('<Relationship Id="rId%d" '
                      'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" '
                      'Target="worksheets/sheet%d.xml"/>' % (i+1, i+1))
    relations += ('<Relationship Id="rId%d" '
                  'Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" '
                  'Target="styles.xml"/></Relationships>' % (len(sheets)+1))
    root_rels = ('<?xml version="1.0" encoding="UTF-8"?>'
                 '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                 '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
                 '</Relationships>')
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=6) as z:
        z.writestr("[Content_Types].xml", "".join(content_types))
        z.writestr("_rels/.rels", root_rels)
        z.writestr("xl/workbook.xml", book)
        z.writestr("xl/_rels/workbook.xml.rels", relations)
        z.writestr("xl/styles.xml", styles())
        for i, (name, subtitle, columns, rows, widths) in enumerate(sheets, 1):
            z.writestr("xl/worksheets/sheet%d.xml" % i, worksheet(name, subtitle, columns, rows, widths))
    return out.getvalue()


def main():
    data = sys.stdin.buffer.read(MAX_INPUT + 1)
    if len(data) > MAX_INPUT:
        return 2
    try:
        report = json.loads(data)
        workbook = build_xlsx(report)
        if len(workbook) > 2_000_000:
            return 2
    except (ValueError, TypeError, KeyError):
        return 2
    sys.stdout.buffer.write(workbook)
    return 0


if __name__ == "__main__":
    sys.exit(main())
