@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo   Build: Ventilation Spec Tool  ^(VentSpec.exe^)
echo ============================================================

if not exist "vent_gui.py"       ( echo MISSING FILE: vent_gui.py       & pause & exit /b 1 )
if not exist "vent_processor.py" ( echo MISSING FILE: vent_processor.py & pause & exit /b 1 )
if not exist "icon.ico"          ( echo MISSING FILE: icon.ico          & pause & exit /b 1 )
if not exist "..\common"         ( echo MISSING FOLDER: ..\common ^(V2.0 depends on the shared package one level up - keep this checkout intact^) & pause & exit /b 1 )

echo.
echo [1/3] Installing dependencies...
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
if errorlevel 1 (
    echo.
    echo ERROR installing dependencies. If behind a corporate proxy, see the guide.
    pause
    exit /b 1
)

echo.
echo [2/3] Staging shared package (..\common) next to vent_gui.py...
rem --paths .. alone is not reliable enough in practice - copying common\
rem next to the entry script guarantees PyInstaller bundles it the same
rem way it bundles every other local file (no special flag to trust).
rem This copy is removed again after the build - see step [3/3].
if exist "common" rmdir /s /q "common"
xcopy "..\common" "common\" /E /I /Y >nul
if errorlevel 1 (
    echo.
    echo ERROR copying ..\common into program-a\common - check the checkout is intact.
    pause
    exit /b 1
)

echo.
echo [3/3] Building exe with PyInstaller...
python -m PyInstaller --noconfirm --onefile --windowed --icon=icon.ico --add-data "icon.ico;." --paths ".." --collect-all customtkinter --name VentSpec vent_gui.py
set BUILD_ERR=%errorlevel%

rem Clean up the staged copy either way, so `python vent_gui.py` (dev mode,
rem no build) keeps reading the real ..\common instead of this stale copy.
rmdir /s /q "common"

if %BUILD_ERR% neq 0 (
    echo.
    echo ERROR during build. See messages above.
    pause
    exit /b 1
)

echo.
echo ============================================================
echo   DONE!  File:  dist\VentSpec.exe
echo ============================================================
pause
endlocal
