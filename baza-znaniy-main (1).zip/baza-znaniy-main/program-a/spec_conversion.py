"""Общий конвертор: проверенная геометрия, затем чтение сложных страниц Claude."""
import hashlib
import json
import sys
from collections import defaultdict
from pathlib import Path

import fitz
from openpyxl.styles import Alignment, Font, PatternFill

from common.claude_client import ClaudeError
from spec_agent import (FIELDS, MAX_PAGES, PROMPT_PATH, SCHEMA, SpecAgentError,
                        _digest, _merge, load_examples, read_page)
from pdf_layout import detect_columns, table_extent, visible_page


def _verify_native(pdf_path, rows):
    # Существующая независимая проверка количеств/порядка/наименований.
    folder = str(Path(__file__).resolve().parents[1] / 'program-b')
    if folder not in sys.path:
        sys.path.insert(0, folder)
    from verify_so import verify_spec
    return verify_spec(pdf_path, rows)


def _verify_numbered_grid(doc, rows):
    """Use the independent quantity/name reader per sheet, not header
    coordinates from sheet 1 or a document-wide sequence alignment."""
    from verify_so import (_page_quantities, _to_float, _name_share,
                           _row_text, SUM_TOLERANCE, NAME_MIN_SHARE)
    grouped = defaultdict(list)
    for row in rows:
        grouped[row['_PAGE']].append(row)
    failed = []
    for index, page in enumerate(doc):
        actual = grouped[index]
        if not actual:
            failed.append(index + 1)
            continue
        bounds = actual[0]['_GRID_BOUNDS']
        expected = _page_quantities(page, bounds, [])
        # The header is confirmed geometrically, but its column widths
        # can differ from the body. For example, "1 ед., кг" in the mass
        # header may lie in the body quantity column. It is not a row.
        header_bottom = actual[0].get('_GRID_HEADER_BOTTOM')
        if header_bottom is not None:
            expected = [item for item in expected if item[0] >= header_bottom - 2]
        relocated = [row for row in actual if row.get('_GRID_QTY_RELOCATED')]
        if relocated:
            # Independently read the physical unit column and corroborate
            # each inference by its own row band and source value. Never
            # remove or replace a quantity already printed in its column.
            alternate = dict(bounds, QTY=bounds['UNIT'], UNIT=bounds['QTY'])
            unit_numbers = _page_quantities(page, alternate, [])
            valid = True
            for row in relocated:
                lo, hi = row['_GRID_BAND']
                candidates = [item for item in unit_numbers if lo <= item[0] < hi]
                if (len(candidates) != 1 or any(lo <= item[0] < hi for item in expected)
                        or candidates[0][1] != _to_float(row['_GRID_QTY_RELOCATED'])):
                    valid = False
                    break
                expected.append(candidates[0])
            if not valid:
                failed.append(index + 1)
                continue
            expected.sort(key=lambda item: item[0])
        quantities = [_to_float(row.get('QTY')) for row in actual]
        values = [value for _y, value, _names in expected]
        if (len(values) != len(quantities) or any(q is None for q in quantities)
                or abs(sum(values) - sum(quantities)) > SUM_TOLERANCE
                or any(abs(a-b) > .0001 for a, b in zip(values, quantities))):
            failed.append(index + 1)
            continue
        for (_y, _value, names), row in zip(expected, actual):
            share = _name_share(names, _row_text(row))
            if share is not None and share < NAME_MIN_SHARE:
                failed.append(index + 1)
                break
    return {'positions_parsed': len(rows), 'ok': not failed, 'pages_failed': failed}


def _assess_native(doc, pdf_path, rows):
    needed, blank = set(), set()
    grid = bool(rows) and all(row.get('_GRID_BOUNDS') for row in rows)
    previous = None
    width = None
    for index, page in enumerate(doc):
        shown = visible_page(page)
        words = shown.get_text('words')
        if not words and not page.get_images() and not page.get_drawings():
            blank.add(index)
            continue
        # Grid rows already have a confirmed body layout. Their independent
        # verification below identifies missing and mismatching pages.
        if grid:
            continue
        detected = detect_columns(shown, words) if words else None
        if detected:
            previous, width = detected, shown.rect.width
        inherited = (previous is not None and abs(shown.rect.width - width) < 2
                     and table_extent(shown, previous) is not None)
        if (not words or not (detected or inherited)
                or page.rotation != doc[0].rotation):
            needed.add(index)
    if rows:
        try:
            if grid:
                folder = str(Path(__file__).resolve().parents[1] / 'program-b')
                if folder not in sys.path:
                    sys.path.insert(0, folder)
                check = _verify_numbered_grid(doc, rows)
            else:
                check = _verify_native(pdf_path, rows)
        except (ImportError, RuntimeError, ValueError, IndexError):
            check = None
        if not check or not check.get('positions_parsed'):
            needed.update(set(range(len(doc))) - blank)
        elif not check.get('ok'):
            failed = {int(p) - 1 for p in check.get('pages_failed', [])}
            needed.update(failed or (set(range(len(doc))) - blank))
    else:
        needed.update(set(range(len(doc))) - blank)
    # Позиция, пересекающая границу страницы, читается одним способом
    # целиком, чтобы её начало не потерялось и не продублировалось.
    changed = True
    while changed:
        changed = False
        for row in rows:
            sources = set(row.get('_SOURCE_PAGES', [row.get('_PAGE', 0)]))
            if sources & needed and not sources <= needed:
                needed.update(sources)
                changed = True
    return needed, blank


def _native_rows(pdf_path, progress):
    from pdf_to_spec import extract_spec_rows
    callback = ((lambda done, total: progress(done, total, 'Чтение PDF: %s из %s' % (done, total)))
                if progress else None)
    try:
        return extract_spec_rows(pdf_path, progress_callback=callback, allow_partial_grid=True)
    except (RuntimeError, ValueError, IndexError):
        return [], False, False


def _sources(row):
    return [{'page': p + 1, 'bbox': None}
            for p in row.get('_SOURCE_PAGES', [row.get('_PAGE', 0)])]


def _grid_source_issues(rows):
    """Explicit review trail for local interpretations of malformed cells."""
    by_page = defaultdict(list)
    for row in rows:
        if row.get('_GRID_QTY_RELOCATED'):
            by_page[row['_PAGE'] + 1].append(
                'Поз. %s: число %s напечатано в графе «Ед. измерения», '
                'графа «Кол.» пуста. Число перенесено в количество '
                'предположительно; единица оставлена пустой. Сверьте с проектировщиком.'
                % (row.get('_PDF_POS', '?'), row['_GRID_QTY_RELOCATED']))
    return by_page


def convert_specification(pdf_path, output_path, format_name, client=None, progress=None,
                          client_factory=None, cache_dir=None):
    if format_name not in ('ventspec', 'area'):
        raise ValueError('Неизвестный формат спецификации')
    with fitz.open(pdf_path) as doc:
        if doc.needs_pass:
            raise SpecAgentError('PDF защищён паролем')
        if not len(doc):
            raise SpecAgentError('В PDF нет страниц')
        total_pages = len(doc)
        native, rotated, gost = _native_rows(pdf_path, progress)
        if progress:
            progress(0, len(doc), 'Проверка прочитанных позиций')
        needed, blank = _assess_native(doc, pdf_path, native)
        if not needed and native:
            result = {'rows': native, 'pages': [], 'engine': 'native', 'model': '',
                      'examples': 0, 'warnings': [], 'rotated': rotated, 'gost': gost}
        else:
            if not needed:
                raise SpecAgentError('Позиции спецификации не найдены. Пустой Excel не сформирован')
            if len(needed) > MAX_PAGES:
                raise SpecAgentError('Для распознавания более %s сложных страниц разделите PDF' % MAX_PAGES)
            if client is None and client_factory is not None:
                client = client_factory()
            if client is None:
                scans = any(not doc[i].get_text('words') for i in needed)
                detail = 'В PDF нет текстового слоя.' if scans else 'Вёрстка требует дополнительного распознавания.'
                raise SpecAgentError(detail + ' Для этого файла необходимо подключение Anthropic; '
                                     'Пустой Excel не сформирован.')
            rules, examples = PROMPT_PATH.read_text(encoding='utf-8'), load_examples()
            fingerprint = _digest({'pdf': hashlib.sha256(Path(pdf_path).read_bytes()).hexdigest(),
                                   'model': client.model, 'effort': getattr(client, 'effort', ''),
                                   'rules': rules, 'examples': examples, 'schema': SCHEMA,
                                   'reader': hashlib.sha256((Path(__file__).read_bytes() +
                                       Path(__file__).with_name('spec_agent.py').read_bytes() +
                                       Path(__file__).with_name('pdf_layout.py').read_bytes() +
                                       Path(__file__).with_name('pdf_to_spec.py').read_bytes())).hexdigest()})
            cache = Path(cache_dir or (output_path + '.pages'))
            by_page = defaultdict(list)
            for row in native:
                if not set(row.get('_SOURCE_PAGES', [row.get('_PAGE', 0)])) & needed:
                    by_page[row.get('_PAGE', 0)].append(row)
            rows, pages, section = [], [], ''
            numbered_grid = bool(native) and all(row.get('_GRID_BOUNDS') for row in native)
            for index, page in enumerate(doc):
                number = index + 1
                if index in blank:
                    pages.append({'page': number, 'engine': 'blank', 'is_specification': False,
                                  'rows': 0, 'issues': ['Пустая страница']})
                    continue
                if index not in needed:
                    page_rows = by_page[index]
                    for row in page_rows:
                        if row.get('_GRID_INHERITED'):
                            row['POS'] = row['SECTION'] = section
                        row['_SOURCES'], row['_FRAGMENTS'] = _sources(row), []
                        rows.append(row)
                        if row.get('_GRID_ROW_LOCAL_SYSTEM'):
                            # A material breakdown names a system for this
                            # row only; it does not start a new section.
                            continue
                        if row.get('_GRID_BOUNDS'):
                            section = row.get('SECTION', '')
                        else:
                            section = row.get('SECTION') or section
                    if page_rows and '_GRID_END_SECTION' in page_rows[-1]:
                        section = page_rows[-1]['_GRID_END_SECTION']
                    pages.append({'page': number, 'engine': 'native', 'is_specification': bool(page_rows),
                                  'rows': len(page_rows), 'issues': []})
                    continue
                if progress:
                    progress(number, len(doc), 'Распознавание страницы %s из %s' % (number, len(doc)))
                previous = {f: str(rows[-1].get(f) or '') for f in FIELDS} if rows else None
                context = {'section': section, 'previous_row': previous}
                try:
                    answer, issues = read_page(page, client, number, context,
                                               cache / ('%04d.json' % number), fingerprint,
                                               progress, len(doc), rules, examples)
                except (ClaudeError, SpecAgentError, ValueError, RuntimeError, OSError):
                    raise SpecAgentError('Не удалось распознать страницу %s. '
                                         'Проверьте подключение и повторите обработку; '
                                         'неполный результат не выдан как готовый.' % number) from None
                if (not answer['is_specification'] and issues) or (answer['is_specification'] and not answer['rows']):
                    raise SpecAgentError('На странице %s есть признаки спецификации, '
                                         'но позиции не прочитаны. Нужна проверка исходника.' % number)
                if format_name == 'ventspec' and issues:
                    # A successful download must not conceal unresolved
                    # recognition discrepancies. Keep diagnostics in the log.
                    print(json.dumps({'page': number, 'issues': issues},
                                     ensure_ascii=False), file=sys.stderr)
                    raise SpecAgentError('Не удалось однозначно проверить страницу %s. '
                                         'Excel не сформирован.' % number)
                # Source geometry, not the printed position number, determines
                # the order. Duplicate and fractional positions are legitimate.
                answer['rows'].sort(key=lambda item: (item['bbox'][1], item['bbox'][0]))
                for item in answer['rows']:
                    if not item['SECTION']:
                        item['SECTION'] = section
                    if numbered_grid:
                        # Match the native numbered-grid contract: A and K
                        # contain the section, never the printed row number.
                        if not item['SECTION']:
                            raise SpecAgentError('Не определена система на странице %s. '
                                                 'Excel не сформирован.' % number)
                        item['POS'] = item['SECTION']
                _merge(rows, answer, number, issues)
                if format_name == 'ventspec' and issues:
                    print(json.dumps({'page': number, 'issues': issues},
                                     ensure_ascii=False), file=sys.stderr)
                    raise SpecAgentError('Не удалось однозначно объединить данные страницы %s. '
                                         'Excel не сформирован.' % number)
                if answer['is_specification']:
                    section = answer['last_section'] or section
                pages.append({'page': number, 'engine': 'claude',
                              'is_specification': answer['is_specification'],
                              'rows': len(answer['rows']), 'issues': issues})
            if not rows or not any(r.get('NAME') and (r.get('QTY') or r.get('UNIT')) for r in rows):
                raise SpecAgentError('Позиции спецификации не найдены. Пустой Excel не сформирован')
            result = {'rows': rows, 'pages': pages,
                      'engine': 'mixed' if len(needed | blank) < len(doc) else 'claude',
                      'model': client.model, 'examples': len(examples),
                      'warnings': ['Страницы, прочитанные по изображению, нужно сверить с PDF.'],
                      'rotated': rotated, 'gost': gost}
    if progress:
        progress(total_pages, total_pages, 'Формирование Excel')
    result['source'] = Path(pdf_path).name
    source_issues = _grid_source_issues(result['rows'])
    if source_issues:
        result['warnings'].append('Обнаружены числа в графе единицы измерения; '
                                  'предположительные исправления зафиксированы в протоколе.')
        if not result['pages']:
            page_counts = defaultdict(int)
            for row in result['rows']:
                page_counts[row['_PAGE'] + 1] += 1
            result['pages'] = [
                {'page': n, 'engine': 'native', 'is_specification': bool(page_counts[n]),
                 'rows': page_counts[n], 'issues': []}
                for n in range(1, total_pages + 1)]
        for page in result['pages']:
            page['issues'].extend(source_issues.get(page['page'], []))
    data = result['rows'], result['rotated'], result['gost']
    info = result if result['engine'] != 'native' or source_issues else None
    if format_name == 'area':
        from area_convert import convert_to_area
        convert_to_area(pdf_path, output_path, rows_data=data, conversion_info=info)
    else:
        from pdf_to_spec import convert
        # VentSpec keeps the original single-sheet 38-column contract.
        # The protocol is logged on the server, never added to the workbook.
        if info is not None:
            print(json.dumps({'event': 'ventspec_internal_check', 'source': result['source'],
                              'engine': result['engine'], 'warnings': result['warnings'],
                              'pages': result['pages']}, ensure_ascii=False), file=sys.stderr)
        convert(pdf_path, output_path, rows_data=data, editable_systems=True)
    return {'output_file': output_path, 'report_file': None, 'total_rows': len(result['rows']),
            'engine': result['engine'], 'needs_review': info is not None,
            'warnings': result['warnings'], 'checked_pages': total_pages,
            'ai_pages': [p['page'] for p in result['pages'] if p['engine'] == 'claude']}


def add_report(book, result):
    """Добавляется ДО сохранения книги: формулы A → K и их кэш сохраняются."""
    sheet = book.create_sheet('Проверка')
    sheet.append(['Результат', 'Нужна сверка отмеченных строк и страниц с PDF'])
    sheet.append(['Источник', result['source']])
    sheet.append(['Способ чтения', result['engine'], 'Модель', result['model']])
    for warning in result['warnings']:
        sheet.append(['Внимание', warning])
    sheet.append(['Ограничение', 'Автоматическое чтение не гарантирует полноту. Проверьте строки, системы, количества и примечания.'])
    sheet.append([])
    sheet.append(['Страница PDF', 'Способ чтения', 'Позиций', 'Замечания'])
    for page in result['pages']:
        issues = list(page['issues'])
        if page['engine'] == 'claude' and not page['is_specification']:
            issues.append('Модель пропустила страницу как не спецификацию — проверьте решение')
        sheet.append([page['page'], page['engine'], page['rows'], '\n'.join(issues)])
    sheet.append([])
    sheet.append(['Строка Excel', 'Страницы PDF', 'Области', 'Продолжения'])
    for index, row in enumerate(result['rows'], 2):
        sources = row.get('_SOURCES', _sources(row))
        sheet.append([index, ', '.join(str(s['page']) for s in sources),
                      json.dumps(sources, ensure_ascii=False),
                      json.dumps(row.get('_FRAGMENTS', []), ensure_ascii=False)])
    for cells in sheet:
        for cell in cells:
            if isinstance(cell.value, str):
                cell.data_type = 's'
            cell.alignment = Alignment(vertical='top', wrap_text=True)
    for cell in sheet[1]:
        cell.font = Font(bold=True)
        cell.fill = PatternFill('solid', fgColor='FFF2CC')
    for column, width in [('A', 24), ('B', 55), ('C', 45), ('D', 75)]:
        sheet.column_dimensions[column].width = width
    sheet.freeze_panes = 'A2'
    book.active = 0
