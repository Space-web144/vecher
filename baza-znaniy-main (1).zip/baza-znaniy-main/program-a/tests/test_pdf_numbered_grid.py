"""Numbered grid reads multiline notes and retains system across pages."""
import sys
import unittest
from pathlib import Path
from unittest.mock import patch
import fitz

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from pdf_to_spec import _read_numbered_grid, _COLUMN_ORDER


class NumberedGridTests(unittest.TestCase):
    def test_grid_and_shifted_columns(self):
        edges = [50, 100, 300, 450, 510, 600, 660, 720, 780, 900]
        bounds = dict(zip(_COLUMN_ORDER, zip(edges, edges[1:])))
        def word(x, y, value):
            return (x, y, x + 12, y + 7, value, 0, 0, 0)
        words = [word(110, 105, 'Система'), word(160, 105, '2П1'),
                 word(55, 143, '1'), word(110, 143, 'Вентилятор'),
                 word(615, 143, 'шт.'), word(675, 143, '1'),
                 word(790, 126, 'Примечание'), word(790, 143, 'продолжение'),
                 word(790, 156, 'конец'), word(55, 181, '2'),
                 word(110, 181, 'Клапан'), word(615, 181, 'шт.'),
                 word(675, 181, '2')]
        items = [('l', fitz.Point(50, y), fitz.Point(900, y))
                 for y in (100, 120, 170, 200)]
        items += [('l', fitz.Point(x, 120), fitz.Point(x, 200)) for x in edges]
        class Page:
            rect = fitz.Rect(0, 0, 950, 260)
            def get_text(self, kind):
                return words
            def get_drawings(self):
                return [{'items': items}]
        with patch('pdf_to_spec.visible_page', side_effect=lambda p: p), \
             patch('pdf_to_spec.service_text_lines', return_value=set()), \
             patch('pdf_to_spec.layout_header_bottom', return_value=100):
            rows, state = _read_numbered_grid(Page(), bounds, '')
            self.assertEqual(state, '2П1')
            self.assertEqual([r['SECTION'] for r in rows], ['2П1', '2П1'])
            self.assertEqual([r['QTY'] for r in rows], ['1', '2'])
            self.assertEqual(rows[0]['NOTE'], 'Примечание продолжение конец')
            words[:2] = []
            rows, state = _read_numbered_grid(Page(), bounds, state)
            self.assertEqual(rows[0]['SECTION'], '2П1')

    def test_fractional_duplicate_nonsequential_positions_keep_physical_order(self):
        xs = [50, 100, 300, 450, 510, 600, 660, 720, 780, 900]
        bounds = dict(zip(_COLUMN_ORDER, zip(xs, xs[1:])))
        def word(x, y, value):
            return (x, y, x + 12, y + 7, value, 0, 0, 0)
        positions = ['114', '102.1', '102.2', '124', '124']
        words = []
        for i, (pos, qty) in enumerate(zip(positions, ['44', '14', '2', '33', '1'])):
            y = 110 + 30*i
            words.extend([word(55, y, pos), word(110, y, 'Муфта'),
                          word(615, y, 'шт.'), word(675, y, qty)])
        # Two wrapped size subcolumns appear above the main word.
        words.extend([word(270, 103, 'Нет'), word(270, 114, 'типоразм'),
                      word(270, 122, 'ера'), word(270, 133, 'Ø40xØ25'),
                      word(270, 149, 'xØ40')])
        items = [('l', fitz.Point(50, y), fitz.Point(900, y))
                 for y in range(100, 251, 30)]
        items += [('l', fitz.Point(x, 100), fitz.Point(x, 250)) for x in xs]
        class Page:
            rect = fitz.Rect(0, 0, 950, 300)
            def get_text(self, kind):
                return list(reversed(words))
            def get_drawings(self):
                return [{'items': items}]
        with patch('pdf_to_spec.visible_page', side_effect=lambda p: p), \
             patch('pdf_to_spec.service_text_lines', return_value=set()), \
             patch('pdf_to_spec.layout_header_bottom', return_value=100):
            rows, section = _read_numbered_grid(Page(), bounds, 'Х2')
        self.assertEqual([r['_PDF_POS'] for r in rows], positions)
        self.assertEqual([r['QTY'] for r in rows], ['44', '14', '2', '33', '1'])
        self.assertEqual([r['POS'] for r in rows], ['Х2'] * 5)
        self.assertEqual(rows[0]['NAME'], 'Муфта Нет типоразмера')
        self.assertEqual(rows[1]['NAME'], 'Муфта Ø40xØ25xØ40')
        self.assertEqual(section, 'Х2')

    def test_unnumbered_material_breakdown_preserves_all_rows_and_systems(self):
        # Real layout: numbered frames, a merged category heading,
        # a parent material description, child systems without POS,
        # a following merged heading and another numbered item.
        xs = [50, 100, 450, 550, 610, 680, 740, 800, 860, 950]
        bounds = dict(zip(_COLUMN_ORDER, zip(xs, xs[1:])))
        def word(x, y, value):
            return (x, y, x + 12, y + 7, value, 0, 0, 0)
        words = [word(55, 110, '673'), word(110, 110, 'Рама'),
                 word(690, 110, 'компл.'), word(750, 110, '5.0'),
                 word(55, 140, 'Кожухи'),
                 word(110, 170, 'Окожухование'), word(190, 170, 'воздуховодов'),
                 word(270, 170, 'для...')]
        systems = ['4В30', '4В31', '4В32', '4В33', '4ПВ1', '4ПД1',
                   '4ПД2', '4ПД3', '4ПД4', '4ПД5', '4П6', '4ПД7']
        quantities = ['130','129','149','123','100','36','30','12','27','30','42','29']
        for i, (system, qty) in enumerate(zip(systems, quantities)):
            y = 200 + 30*i
            words.extend([word(110, y, 'Система'), word(180, y, system),
                          word(690, y, 'м2'), word(750, y, qty)])
        words.extend([word(55, 560, 'Козырьки'),
                      word(55, 590, '667'), word(110, 590, 'Навес'),
                      word(690, 590, 'компл.'), word(750, 590, '9.0')])
        items = [('l', fitz.Point(50, y), fitz.Point(950, y))
                 for y in range(100, 611, 30)]
        items += [('l', fitz.Point(x, 100), fitz.Point(x, 610)) for x in xs]
        class Page:
            rect = fitz.Rect(0, 0, 1000, 650)
            def get_text(self, kind):
                return list(reversed(words))
            def get_drawings(self):
                return [{'items': items}]
        with patch('pdf_to_spec.visible_page', side_effect=lambda p: p), \
             patch('pdf_to_spec.service_text_lines', return_value=set()), \
             patch('pdf_to_spec.layout_header_bottom', return_value=100):
            rows, section = _read_numbered_grid(Page(), bounds, 'Рамы')
        self.assertEqual(len(rows), 14)
        self.assertEqual([r['_PDF_POS'] for r in rows], ['673'] + ['']*12 + ['667'])
        self.assertEqual([r['SECTION'] for r in rows], ['Рамы'] + systems + ['Козырьки'])
        self.assertEqual([r['QTY'] for r in rows], ['5.0'] + quantities + ['9.0'])
        self.assertEqual([r['NAME'] for r in rows[1:-1]],
                         ['Окожухование воздуховодов для... Система ' + s for s in systems])
        self.assertEqual(sum(int(r['QTY']) for r in rows[1:-1]), 837)
        self.assertTrue(all(not r['_GRID_INHERITED'] for r in rows[1:-1]))
        self.assertEqual(section, 'Козырьки')
        self.assertTrue(all(r['_GRID_ROW_LOCAL_SYSTEM'] for r in rows[1:-1]))

        # A continuation consisting entirely of unnumbered rows uses
        # the same actual ruled column layout, without a numeric POS.
        words[:] = [w for w in words if 200 <= w[1] < 560]
        with patch('pdf_to_spec.visible_page', side_effect=lambda p: p), \
             patch('pdf_to_spec.service_text_lines', return_value=set()), \
             patch('pdf_to_spec.layout_header_bottom', return_value=100):
            rows, section = _read_numbered_grid(Page(), bounds, 'Кожухи')
        self.assertEqual([r['SECTION'] for r in rows], systems)
        self.assertEqual([r['QTY'] for r in rows], quantities)
        self.assertTrue(all(not r['_PDF_POS'] for r in rows))
        self.assertEqual(section, 'Кожухи')

    def test_unnumbered_grid_header_uses_outer_page_frame(self):
        # A fully unnumbered sheet with separate page-frame and body
        # rules. The header POS starts at x=0, but the table starts
        # at x=56.64 and POS/NAME is shifted by about 2 pt.
        xs = [56.64, 111.36, 481.68, 651.84, 751.08, 878.64,
              935.28, 992.04, 1062.84, 1176.36]
        header = [0, 113.3, 481.8, 652, 751.2, 878.8, 935.4,
                  992.2, 1063, 1176.4]
        bounds = dict(zip(_COLUMN_ORDER, zip(header, header[1:])))
        def word(x, y, value):
            return (x, y, x + 12, y + 7, value, 0, 0, 0)
        quantities = ['4.0', '1.0', '8.0', '7.0', '3.0', '3.0',
                      '2.0', '1.0', '1.0', '6.0', '1.0', '1.0',
                      '1.0', '3.0', '1.0', '1.0', '2.0', '1.0',
                      '1.0', '1.0']
        words = [word(60, 105, 'Рамы')]
        for i, qty in enumerate(quantities):
            y = 122 + 24*i
            words.extend([word(120, y, 'Рама'), word(890, y, 'шт.'),
                          word(958, y, qty)])
        words.extend([word(60, 602, 'Привода'),
                      word(120, 622, 'Привод'), word(890, 622, 'шт.'),
                      word(958, 622, '2.0')])
        edges = [100] + [116 + 24*i for i in range(21)] + [616, 640]
        items = [('l', fitz.Point(xs[0], y), fitz.Point(xs[-1], y))
                 for y in edges]
        items += [('l', fitz.Point(x, 116), fitz.Point(x, 640)) for x in xs]
        items.append(('l', fitz.Point(0, 0), fitz.Point(0, 680)))
        items.append(('l', fitz.Point(1190, 0), fitz.Point(1190, 680)))
        class Page:
            rect = fitz.Rect(0, 0, 1191, 680)
            def get_text(self, kind):
                return words
            def get_drawings(self):
                return [{'items': items}]
        with patch('pdf_to_spec.visible_page', side_effect=lambda p: p), \
             patch('pdf_to_spec.service_text_lines', return_value=set()), \
             patch('pdf_to_spec.layout_header_bottom', return_value=100):
            rows, section = _read_numbered_grid(Page(), bounds, '')
        self.assertEqual(len(rows), 21)
        self.assertTrue(all(not r['_PDF_POS'] for r in rows))
        self.assertEqual([r['QTY'] for r in rows], quantities + ['2.0'])
        self.assertEqual([r['SECTION'] for r in rows], ['Рамы'] * 20 + ['Привода'])
        self.assertEqual(rows[0]['_GRID_BOUNDS']['POS'], (56.64, 111.36))
        self.assertEqual(section, 'Привода')

    def test_incomplete_grid_does_not_replace_existing_parser(self):
        self.assertIsNone(_read_numbered_grid(None, {}, ''))


if __name__ == '__main__':
    unittest.main()
