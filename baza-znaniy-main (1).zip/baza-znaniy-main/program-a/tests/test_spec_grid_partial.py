"""A failed grid sheet must not trigger rereading the whole document."""
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import fitz
from openpyxl import load_workbook
from test_spec_agent import FakeClient, answer, pdf, row
from pdf_to_spec import _try_numbered_grid
from spec_conversion import _assess_native, convert_specification
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'program-b'))


def grid_row(page, section, inherited=False):
    result = {k: v for k, v in row(name='Duct', qty='2').items()
              if k not in ('bbox', 'continuation')}
    result.update(POS=section, SECTION=section, _PAGE=page,
                  _SOURCE_PAGES=[page], _GRID_BOUNDS={'QTY': (780, 850)},
                  _GRID_INHERITED=inherited)
    return result


class PartialGridTests(unittest.TestCase):
    def test_failed_sheet_does_not_discard_other_grid_rows(self):
        class Page:
            rotation = 90
            def get_text(self, kind=None):
                return 'Система П1' if kind is None else []
        doc = [Page(), Page(), Page()]
        with patch('pdf_to_spec.visible_page', side_effect=lambda p: p), \
             patch('pdf_to_spec.detect_columns', return_value={}), \
             patch('pdf_to_spec._read_numbered_grid',
                   side_effect=[([grid_row(0, 'П1')], 'П1'), None,
                                ([grid_row(2, '', True)], '')]) as reader:
            result = _try_numbered_grid(doc, None, allow_partial=True)
        self.assertEqual([r['_PAGE'] for r in result], [0, 2])
        self.assertEqual(reader.call_args_list[2][0][2], '')

    def test_direct_reader_does_not_return_incomplete_document(self):
        class Page:
            rotation = 90
            def get_text(self, kind=None):
                return 'Система П1' if kind is None else []
        with patch('pdf_to_spec.visible_page', side_effect=lambda p: p), \
             patch('pdf_to_spec.detect_columns', return_value={}), \
             patch('pdf_to_spec._read_numbered_grid',
                   side_effect=[([grid_row(0, 'П1')], 'П1'), None]):
            self.assertIsNone(_try_numbered_grid([Page(), Page()], None))

    def test_unnumbered_rows_are_verified_and_exported_without_api(self):
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp) / 'source.pdf'
            output = Path(tmp) / 'result.xlsx'
            pdf(source)
            native = [grid_row(0, '4В30'), grid_row(0, '4В31')]
            for item, qty in zip(native, ['130', '129']):
                item.update(_PDF_POS='', NAME='Окожухование Система ' + item['SECTION'],
                            QTY=qty, UNIT='м2', _GRID_ROW_LOCAL_SYSTEM=True)
            with fitz.open(str(source)) as doc, \
                 patch('verify_so._page_quantities', return_value=[(200,130,[]),(220,129,[])]):
                needed, blank = _assess_native(doc, str(source), native)
            self.assertEqual(needed, set())
            def forbidden():
                self.fail('Verified unnumbered rows must not call Claude')
            with patch('spec_conversion._native_rows', return_value=(native, True, False)), \
                 patch('verify_so._page_quantities', return_value=[(200,130,[]),(220,129,[])]):
                result = convert_specification(str(source), str(output), 'ventspec',
                                               client_factory=forbidden)
            self.assertEqual(result['engine'], 'native')
            self.assertEqual(result['ai_pages'], [])
            book = load_workbook(output, data_only=True)
            try:
                self.assertEqual(book.sheetnames, ['Общеобменная'])
                self.assertEqual([book.active['G%d' % n].value for n in (2,3)], [130,129])
                self.assertEqual([book.active['K%d' % n].value for n in (2,3)], ['4В30','4В31'])
            finally:
                book.close()

    def test_only_missing_page_goes_to_api_and_section_is_rebound(self):
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp) / 'source.pdf'
            output = Path(tmp) / 'result.xlsx'
            pdf(source, ['Duct', 'Duct', 'Duct'])
            native = [grid_row(0, 'П1'), grid_row(2, 'STALE', True)]
            # Verify independently using the synthetic page quantity.
            with fitz.open(str(source)) as doc, \
                 patch('verify_so._page_quantities', return_value=[(200, 2, [])]):
                needed, blank = _assess_native(doc, str(source), native)
            self.assertEqual(needed, {1})
            self.assertEqual(blank, set())
            model_answer = answer([dict(row(), POS='102.1', SECTION='П2')])
            model_answer['last_section'] = 'П2'
            with patch('spec_conversion._native_rows', return_value=(native, True, False)), \
                 patch('spec_conversion._assess_native', return_value=({1}, set())), \
                 patch('spec_conversion.read_page', return_value=(model_answer, [])) as read:
                result = convert_specification(str(source), str(output), 'ventspec',
                                               client=FakeClient([]))
            self.assertEqual(result['ai_pages'], [2])
            self.assertEqual(read.call_count, 1)
            self.assertEqual(read.call_args[0][3]['section'], 'П1')
            self.assertEqual(result['total_rows'], 3)
            book = load_workbook(output, data_only=True)
            try:
                for column in ('A', 'K'):
                    self.assertEqual([book.active['%s%d' % (column, n)].value for n in (2,3,4)],
                                     ['П1', 'П2', 'П2'])
                self.assertEqual(book.sheetnames, ['Общеобменная'])
            finally:
                book.close()


if __name__ == '__main__':
    unittest.main()
