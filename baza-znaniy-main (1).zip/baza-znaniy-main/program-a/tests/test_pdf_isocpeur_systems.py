"""Regression for merged ISOCPEUR system headers."""
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from pdf_to_spec import _SystemColumn, _clean_position


class IsocpeurSystemTests(unittest.TestCase):
    def test_isocpeur_merged_headings_and_page_carry(self):
        from unittest.mock import patch
        from pdf_to_spec import _extract_page_rows_vk, _column_bounds_vk
        bounds = _column_bounds_vk(1191)
        def line(x, y, text, font="ISOCPEUR"):
            return dict(x0=x, x1=x+10, y0=y, y1=y+10,
                        text=text, font=font, size=8)
        def item(y, pos, name):
            return [line(70, y, pos), line(140, y, name),
                    line(900, y, "шт."), line(950, y, "1")]
        first = [line(70, 100, "Система 2П1", "MicrosoftSansSerif")]
        first += item(125, "1", "Вентилятор")
        second = item(105, "2", "Клапан")
        second += [line(70, 135, "Система 2ПВ1(В)")]
        second += item(160, "3", "Воздуховод")
        second += [line(70, 190, "Система кондиционирования 1К-1")]
        second += item(215, "4", "Труба")
        second += [line(70, 245, "Рамы")]
        second += item(270, "5", "Рама")
        with patch("pdf_to_spec._iter_rotated_lines", side_effect=[first, second]), \
             patch("pdf_to_spec.visible_page"), \
             patch("pdf_to_spec.layout_header_bottom", return_value=90):
            rows, carry, section = _extract_page_rows_vk(None, bounds)
            more, tail, section = _extract_page_rows_vk(None, bounds, carry, section)
        rows += more + [tail]
        self.assertEqual([r["SECTION"] for r in rows],
                         ["2П1", "2П1", "2ПВ1(В)", "1К-1", "Рамы"])
        self.assertEqual([r["NAME"] for r in rows],
                         ["Вентилятор", "Клапан", "Воздуховод", "Труба", "Рама"])
        systems = _SystemColumn(True)
        for index, row in enumerate(rows, 2):
            systems.cell(row, index)
        self.assertEqual(systems.cached["K4"], "2ПВ1(В)")
        self.assertEqual(systems.cached["K5"], "1К-1")
        self.assertEqual(_clean_position("2В1(к)"), "2В1(к)")


if __name__ == '__main__':
    unittest.main()
