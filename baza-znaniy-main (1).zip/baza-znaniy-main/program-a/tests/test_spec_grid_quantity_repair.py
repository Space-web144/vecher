"""Local correction of a number printed in the unit field, with audit."""
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch

import fitz
from openpyxl import load_workbook
from test_spec_agent import pdf, row
from pdf_to_spec import _read_numbered_grid, _COLUMN_ORDER
from spec_conversion import _assess_native, convert_specification
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[2] / 'program-b'))


class GridQuantityRepairTests(unittest.TestCase):
    def test_number_in_unit_is_relocated_without_inventing_unit(self):
        xs = [50, 100, 300, 450, 510, 600, 660, 720, 780, 900]
        bounds = dict(zip(_COLUMN_ORDER, zip(xs, xs[1:])))
        def word(x, y, value):
            return (x, y, x + 12, y + 7, value, 0, 0, 0)
        words = [word(110, 105, 'Система'), word(160, 105, 'П1'),
                 word(55, 143, '707'), word(110, 143, 'Вентилятор'),
                 word(615, 143, '1.0'),
                 word(55, 181, '708'), word(110, 181, 'Клапан'),
                 word(615, 181, 'шт.'), word(675, 181, '2')]
        items = [('l', fitz.Point(50, y), fitz.Point(900, y))
                 for y in (100, 120, 170, 200)]
        items += [('l', fitz.Point(x, 120), fitz.Point(x, 200)) for x in xs]
        class Page:
            rect = fitz.Rect(0, 0, 950, 260)
            def get_text(self, kind):
                return words
            def get_drawings(self):
                return [{'items': items}]
        with patch('pdf_to_spec.visible_page', side_effect=lambda p: p), \
             patch('pdf_to_spec.service_text_lines', return_value=set()), \
             patch('pdf_to_spec.layout_header_bottom', return_value=100):
            rows, _ = _read_numbered_grid(Page(), bounds, '')
        self.assertEqual([r['QTY'] for r in rows], ['1.0', '2'])
        self.assertEqual(rows[0]['UNIT'], '')
        self.assertEqual(rows[0]['_GRID_QTY_RELOCATED'], '1.0')
        self.assertEqual(rows[0]['_PDF_POS'], '707')
        self.assertNotIn('_GRID_QTY_RELOCATED', rows[1])

    def test_header_number_does_not_count_as_body_quantity(self):
        with tempfile.TemporaryDirectory() as tmp:
            source = Path(tmp) / 'source.pdf'
            pdf(source)
            native = [dict(NAME='Duct', QTY='2', UNIT='pcs', _PAGE=0,
                           _SOURCE_PAGES=[0], _GRID_BOUNDS={'QTY': (780, 850)},
                           _GRID_HEADER_BOTTOM=100)]
            with fitz.open(str(source)) as doc, \
                 patch('verify_so._page_quantities', return_value=[(63,1,[]), (200,2,[])]):
                needed, _ = _assess_native(doc, str(source), native)
            self.assertEqual(needed, set())
            with fitz.open(str(source)) as doc, \
                 patch('verify_so._page_quantities', return_value=[(63,1,[]), (200,2,[]), (230,1,[])]):
                needed, _ = _assess_native(doc, str(source), native)
            self.assertEqual(needed, {0})

    def test_independent_check_and_audit_without_api(self):
        with tempfile.TemporaryDirectory() as tmp:
            source, output = Path(tmp) / 'source.pdf', Path(tmp) / 'result.xlsx'
            pdf(source)
            native = [{k: v for k, v in row(qty='1.0').items()
                       if k not in ('bbox', 'continuation')}]
            native[0].update(POS='П1', SECTION='П1', UNIT='', _PAGE=0,
                             _SOURCE_PAGES=[0], _GRID_BOUNDS={'QTY': (780,850), 'UNIT': (700,780)},
                             _PDF_POS='707', _GRID_QTY_RELOCATED='1.0', _GRID_BAND=(180,220))
            with fitz.open(str(source)) as doc, \
                 patch('verify_so._page_quantities', side_effect=[[], [(200,1,[])]]):
                needed, _ = _assess_native(doc, str(source), native)
            self.assertEqual(needed, set())
            with fitz.open(str(source)) as doc, \
                 patch('verify_so._page_quantities', side_effect=[[], [(200,2,[])]]):
                needed, _ = _assess_native(doc, str(source), native)
            self.assertEqual(needed, {0})
            def forbidden():
                self.fail('Confirmed local interpretation must not call Claude')
            with patch('spec_conversion._native_rows', return_value=(native, True, False)), \
                 patch('spec_conversion._assess_native', return_value=(set(), set())):
                result = convert_specification(str(source), str(output), 'ventspec',
                                               client_factory=forbidden)
            self.assertEqual(result['ai_pages'], [])
            self.assertTrue(result['needs_review'])
            book = load_workbook(output, data_only=True)
            try:
                self.assertEqual(book.active['G2'].value, 1)
                self.assertFalse(book.active['F2'].value)
                self.assertEqual(book.sheetnames, ['Общеобменная'])
                self.assertTrue(result['warnings'])
            finally:
                book.close()


if __name__ == '__main__':
    unittest.main()
