#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Интерфейс «Обработка спецификаций вентиляции» — панель управления.

Этапы:
  1. Создать базовую таблицу спецификации (Вариант 1 — порт VBA; 2,3 — заглушки)
  2. Спецификация для обработки → «Расчёт площади фасонных изделий» (самостоятельная единица)
  3. Номенклатура 1С → «Сравнение с 1С» (самостоятельная единица)
  + Полная обработка (все этапы сразу)

Требуется customtkinter (pip install customtkinter) и openpyxl.
Файл vent_processor.py должен лежать рядом.
"""

import os
import re
import sys
import queue
import threading

import tkinter as tk
from tkinter import filedialog, messagebox

import vent_processor as core

try:
    import customtkinter as ctk
    ctk.set_appearance_mode("dark")
    ctk.set_default_color_theme("blue")
except ImportError:
    _r = tk.Tk(); _r.withdraw()
    messagebox.showerror(
        "Нужен customtkinter",
        "Для интерфейса установите customtkinter:\n\n    pip install customtkinter")
    sys.exit(1)

# Перетаскивание файлов (drag-and-drop) — необязательная зависимость.
# Если tkinterdnd2 не установлен, программа работает как раньше (без DnD).
try:
    from tkinterdnd2 import TkinterDnD, DND_FILES
    _DND_OK = True

    class _Root(ctk.CTk, TkinterDnD.DnDWrapper):
        """Окно customtkinter с поддержкой перетаскивания файлов."""
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.TkdndVersion = TkinterDnD._require(self)
except Exception:
    _DND_OK = False
    DND_FILES = None
    _Root = ctk.CTk


def resource_path(name):
    """Путь к файлу-ресурсу: работает и при запуске .py, и внутри собранного exe.
    PyInstaller распаковывает вложенные файлы во временную папку sys._MEIPASS."""
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, name)


# Палитра
GREEN = "#2f8a3e"
GREEN_HOVER = "#256e32"
BLUE = "#2f6fb0"
GRAY = "#3a3a3a"
GRAY_HOVER = "#4a4a4a"
GRAY_TEXT = "#8a8a8a"
GREEN_TEXT = "#7ec77e"


class App:
    # Отображаемый текст в выпадающем списке → destination для
    # core.run_processing/compare_with_1c(report_destination=...).
    REPORT_OPTIONS = ["Доп. лист в файле", "Отдельный файл (папка результатов)"]
    REPORT_DESTINATIONS = {
        "Доп. лист в файле": "sheet",
        "Отдельный файл (папка результатов)": "folder",
    }

    def __init__(self):
        self.root = _Root()
        self.root.title("Обработка спецификаций вентиляции")
        self.root.geometry("960x1020")
        self.root.minsize(860, 760)
        self._set_icon()

        # состояние
        self.spec_path = None
        self.nomen_path = None
        self.nomen_loaded = False
        self.base_done = False
        self.busy = False
        desktop = os.path.join(os.path.expanduser("~"), "Desktop")
        self.out_dir = desktop if os.path.isdir(desktop) else os.path.expanduser("~")

        self.q = queue.Queue()
        core.set_logger(lambda m: self.q.put(("log", m)))

        self._build()
        self._refresh()
        self.root.after(60, self._drain)

    # ───────── иконка окна ─────────
    def _set_icon(self):
        """Ставит иконку программы в заголовок окна и на панель задач.

        Ищет файл иконки рядом с программой (и в распакованном бандле
        PyInstaller). Поддерживает icon.ico и icon.png. Применяет несколько
        раз с задержками, т.к. CustomTkinter может сбросить иконку после
        запуска. Если icon.ico недоступен, пробует iconphoto через Pillow.
        """
        # кандидаты на файл иконки (по приоритету)
        names = ("icon.ico", "icon.png", "logo.ico", "logo.png")
        candidates = []
        for name in names:
            candidates.append(resource_path(name))                       # рядом со скриптом / в бандле
            candidates.append(os.path.join(os.getcwd(), name))           # текущая папка
        self._icon_path = next((p for p in candidates if os.path.exists(p)), None)
        if not self._icon_path:
            # файла иконки нет — оставляем системный значок
            return

        # Windows: уникальный AppUserModelID, чтобы на панели задач была
        # иконка программы, а не общий значок Python.
        try:
            if sys.platform == "win32":
                import ctypes
                ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
                    "ventilation.spec.tool")
        except Exception:
            pass

        # Ставим сразу и повторяем с задержками (CTk перехватывает иконку
        # на старте — одиночная установка часто «не доживает»).
        self._apply_icon()
        for delay in (200, 500, 1000, 2000):
            self.root.after(delay, self._apply_icon)

    def _apply_icon(self):
        path = getattr(self, "_icon_path", None)
        if not path:
            return
        # 1) Родной путь Windows для .ico — iconbitmap (чёткий значок заголовка).
        if path.lower().endswith(".ico"):
            try:
                self.root.iconbitmap(path)
                return
            except Exception:
                pass
        # 2) Универсальный путь — iconphoto через Pillow (ico или png).
        #    Ссылку на изображение держим в self, иначе значок исчезнет (GC).
        try:
            from PIL import Image, ImageTk
            self._icon_image = ImageTk.PhotoImage(Image.open(path))
            self.root.iconphoto(True, self._icon_image)
        except Exception:
            pass

    # ───────── построение ─────────
    def _badge(self, parent, text, color, size=42, font_size=18):
        return ctk.CTkLabel(parent, text=text, width=size, height=size,
                            corner_radius=size // 2, fg_color=color,
                            text_color="white",
                            font=ctk.CTkFont(size=font_size, weight="bold"))

    def _arrow(self, parent):
        return ctk.CTkLabel(parent, text="\u2013 \u2013 \u2013 \u2013 \u2013 \u2013 \u2013 \u2013 \u2192",
                            text_color="#555555", font=ctk.CTkFont(size=15))

    def _card(self, parent):
        return ctk.CTkFrame(parent, fg_color="#1e1e1e", corner_radius=12,
                            border_width=1, border_color="#333333")

    def _sep(self, parent):
        ctk.CTkFrame(parent, height=1, fg_color="#3a3a3a").pack(fill="x", padx=4, pady=(14, 10))

    def _build(self):
        root = ctk.CTkScrollableFrame(self.root, fg_color="transparent")
        root.pack(fill="both", expand=True, padx=22, pady=16)

        # ── Заголовок ──
        head = ctk.CTkFrame(root, fg_color="transparent"); head.pack(fill="x")
        ctk.CTkLabel(head, text="Обработка спецификаций вентиляции",
                     font=ctk.CTkFont(size=24, weight="bold")).pack(side="left")
        ctk.CTkLabel(head, text=f"v{core.VERSION}", width=58, height=28, corner_radius=8,
                     fg_color="#333333", text_color="#cfcfcf",
                     font=ctk.CTkFont(size=13)).pack(side="right", pady=4)
        ctk.CTkLabel(root, text="Панель управления", text_color=GRAY_TEXT,
                     font=ctk.CTkFont(size=14)).pack(anchor="w", pady=(0, 10))

        # ── Степпер 1 → 2 → 3 ──
        step = ctk.CTkFrame(root, fg_color="transparent"); step.pack(fill="x", pady=(8, 4))
        for i in range(5):
            step.grid_columnconfigure(i, weight=(2 if i in (0, 2, 4) else 3))
        self.badge1 = self._badge(step, "1", BLUE)
        self.badge2 = self._badge(step, "2", BLUE)
        self.badge3 = self._badge(step, "3", BLUE)
        self.badge1.grid(row=0, column=0)
        self._arrow(step).grid(row=0, column=1, sticky="ew")
        self.badge2.grid(row=0, column=2)
        self._arrow(step).grid(row=0, column=3, sticky="ew")
        self.badge3.grid(row=0, column=4)
        ctk.CTkLabel(step, text="Создать базовую\nтаблицу",
                     font=ctk.CTkFont(size=14)).grid(row=1, column=0, pady=(8, 0))
        ctk.CTkLabel(step, text="Спецификация\nдля обработки",
                     font=ctk.CTkFont(size=14)).grid(row=1, column=2, pady=(8, 0))
        ctk.CTkLabel(step, text="Номенклатура 1С",
                     font=ctk.CTkFont(size=14)).grid(row=1, column=4, pady=(8, 0))
        # скрытые метки статуса — логика _refresh их использует; обратная
        # связь о завершении идёт через цвет кружков (синий → зелёный ✓)
        self.status1 = ctk.CTkLabel(step, text="", text_color=GREEN_TEXT,
                                     font=ctk.CTkFont(size=12, slant="italic"))
        self.status2 = ctk.CTkLabel(step, text="", text_color=GREEN_TEXT,
                                     font=ctk.CTkFont(size=12, slant="italic"))

        # ── Три карточки в ряд ──
        cards = ctk.CTkFrame(root, fg_color="transparent"); cards.pack(fill="x", pady=(16, 0))
        for i in range(3):
            cards.grid_columnconfigure(i, weight=1, uniform="cards")

        # Карточка 1 — создать таблицу
        c1 = self._card(cards); c1.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        self.btn_create = ctk.CTkButton(c1, text="+ Создать таблицу", height=40,
                                        fg_color=GRAY, hover_color=GRAY_HOVER,
                                        command=self._create_table)
        self.btn_create.pack(fill="x", padx=16, pady=(18, 8))
        self.variant_var = tk.StringVar(value="Вариант 1")
        ctk.CTkOptionMenu(c1, height=40, values=["Вариант 1", "Вариант 2", "Вариант 3"],
                          variable=self.variant_var).pack(fill="x", padx=16)
        ctk.CTkLabel(c1, text="по умолчанию", text_color=GRAY_TEXT,
                     font=ctk.CTkFont(size=13, slant="italic")).pack(
                         anchor="w", padx=16, pady=(10, 18))

        # Карточка 2 — спецификация
        c2 = self._card(cards); c2.grid(row=0, column=1, sticky="nsew", padx=8)
        self.card2 = c2
        self.spec_chip = ctk.CTkLabel(c2, text="файл не выбран", height=40,
                                      corner_radius=8, fg_color="#2a2a2a", text_color=GRAY_TEXT)
        self.spec_chip.pack(fill="x", padx=16, pady=(18, 8))
        ctk.CTkButton(c2, text="↑ Загрузить", height=40, fg_color=GRAY,
                      hover_color=GRAY_HOVER, command=self._load_spec).pack(fill="x", padx=16)
        self.btn_fitting = ctk.CTkButton(c2, text="▶ Расчёт площади фасонных изделий", height=40,
                                         fg_color=GRAY, hover_color=GRAY_HOVER,
                                         command=self._run_fitting)
        self.btn_fitting.pack(fill="x", padx=16, pady=(8, 0))
        self.status_fit = ctk.CTkLabel(c2, text="нужна спецификация", text_color=GRAY_TEXT,
                                       font=ctk.CTkFont(size=13, slant="italic"))
        self.status_fit.pack(anchor="w", padx=16, pady=(10, 18))

        # Карточка 3 — номенклатура 1С + полная обработка
        c3 = self._card(cards); c3.grid(row=0, column=2, sticky="nsew", padx=(8, 0))
        self.card3 = c3
        ctk.CTkButton(c3, text="↑ Загрузить", height=40, fg_color=GRAY,
                      hover_color=GRAY_HOVER, command=self._load_nomen).pack(
                          fill="x", padx=16, pady=(18, 8))
        self.btn_match = ctk.CTkButton(c3, text="🔒 Сравнение с 1С", height=40,
                                       fg_color=GRAY, hover_color=GRAY_HOVER,
                                       command=self._run_match)
        self.btn_match.pack(fill="x", padx=16)
        self.status_match = ctk.CTkLabel(c3, text="нужны спецификация и 1С", text_color=GRAY_TEXT,
                                         font=ctk.CTkFont(size=13, slant="italic"))
        self.status_match.pack(anchor="w", padx=16, pady=(10, 12))
        self.btn_full = ctk.CTkButton(c3, text="🔒 Полная обработка", height=40,
                                      fg_color=GRAY, hover_color=GRAY_HOVER,
                                      command=self._run_full)
        self.btn_full.pack(fill="x", padx=16)
        ctk.CTkLabel(c3, text="запускает все этапы сразу",
                     font=ctk.CTkFont(size=13)).pack(anchor="w", padx=16, pady=(8, 0))
        ctk.CTkLabel(c3, text="нужны спецификация и\nноменклатура 1С", justify="left",
                     text_color=GRAY_TEXT, font=ctk.CTkFont(size=12, slant="italic")).pack(
                         anchor="w", padx=16, pady=(0, 18))

        # ── Папка результатов ──
        ro = ctk.CTkFrame(root, fg_color="transparent"); ro.pack(fill="x", pady=(18, 0))
        ctk.CTkLabel(ro, text="Папка результатов", width=150, anchor="w").pack(side="left")
        self.out_var = tk.StringVar(value=self.out_dir)
        ctk.CTkEntry(ro, textvariable=self.out_var, height=38).pack(side="left", fill="x",
                                                                    expand=True, padx=8)
        ctk.CTkButton(ro, text="Изменить", width=110, height=38, fg_color=GRAY,
                      hover_color=GRAY_HOVER, command=self._change_outdir).pack(side="left")

        # ── Отчёт (о сравнении с 1С — «Сравнение с 1С» и «Полная обработка») ──
        rp = ctk.CTkFrame(root, fg_color="transparent"); rp.pack(fill="x", pady=(8, 0))
        ctk.CTkLabel(rp, text="Отчёт", width=150, anchor="w").pack(side="left")
        self.report_var = tk.StringVar(value=self.REPORT_OPTIONS[0])
        ctk.CTkOptionMenu(rp, height=38, values=self.REPORT_OPTIONS,
                          variable=self.report_var).pack(side="left", fill="x", expand=True, padx=8)

        # ── Окно процессов ──
        ctk.CTkLabel(root, text="ОКНО ПРОЦЕССОВ", text_color=GRAY_TEXT,
                     font=ctk.CTkFont(size=13, weight="bold")).pack(anchor="w", pady=(18, 0))
        self.log = ctk.CTkTextbox(root, height=220, font=ctk.CTkFont(family="Consolas", size=13))
        self.log.pack(fill="both", expand=True, pady=(6, 0))
        self.log.configure(state="disabled")

        self._setup_dnd()

    # ───────── перетаскивание файлов (drag-and-drop) ─────────
    def _setup_dnd(self):
        """Регистрирует карточки спецификации и номенклатуры как цели для
        перетаскивания файлов из проводника. Если tkinterdnd2 не установлен —
        тихо пропускает (программа работает как обычно)."""
        if not _DND_OK:
            return
        try:
            for w in (self.card2, self.spec_chip):
                w.drop_target_register(DND_FILES)
                w.dnd_bind("<<Drop>>", lambda e: self._on_drop(e, "spec"))
            self.card3.drop_target_register(DND_FILES)
            self.card3.dnd_bind("<<Drop>>", lambda e: self._on_drop(e, "nomen"))
        except Exception as ex:
            self._log(f"! перетаскивание недоступно: {ex}")

    @staticmethod
    def _parse_drop(data):
        """Из данных события DnD достаёт путь к первому файлу.
        Пути с пробелами tkdnd оборачивает в фигурные скобки: {C:\\путь\\файл}."""
        data = (data or "").strip()
        m = re.findall(r"\{([^}]*)\}", data)
        if m:
            return m[0].strip()
        return data.split()[0] if data else ""

    def _on_drop(self, event, target):
        if self.busy:
            return
        path = self._parse_drop(event.data)
        if not path or not os.path.isfile(path):
            return
        ext = os.path.splitext(path)[1].lower()
        if target == "spec":
            if ext not in (".xlsx", ".xlsm"):
                self._log("! для спецификации нужен файл .xlsx")
                return
            self._set_spec_path(path)
        else:
            if ext not in (".xlsx", ".xlsm", ".csv"):
                self._log("! для номенклатуры нужен файл .xlsx или .csv")
                return
            self._set_nomen_path(path)

    # ───────── состояние / включение кнопок ─────────
    def _refresh(self):
        # Блок 1 — кнопка создания таблицы доступна всегда, пока нет работы
        # (блок `if self.busy` ниже глушит её на время выполнения).
        self.btn_create.configure(state="normal", fg_color=GRAY, hover_color=GRAY_HOVER)
        if self.base_done:
            self.badge1.configure(text="✓", fg_color=GREEN)
            self.status1.configure(text="таблица создана", text_color=GREEN_TEXT)
        else:
            self.badge1.configure(text="1", fg_color=BLUE)
            self.status1.configure(text="")

        # Блок 2
        if self.spec_path:
            self.badge2.configure(text="✓", fg_color=GREEN)
            self.spec_chip.configure(text="✓ " + os.path.basename(self.spec_path),
                                     text_color=GREEN_TEXT, fg_color="#23351f")
            self.status2.configure(text="загружена", text_color=GREEN_TEXT)
            self.btn_fitting.configure(state="normal", fg_color=GREEN, hover_color=GREEN_HOVER)
            self.status_fit.configure(text="готово к запуску", text_color=GREEN_TEXT)
        else:
            self.badge2.configure(text="2", fg_color=BLUE)
            self.spec_chip.configure(text="файл не выбран", text_color=GRAY_TEXT, fg_color="#2a2a2a")
            self.status2.configure(text="")
            self.btn_fitting.configure(state="disabled", fg_color=GRAY)
            self.status_fit.configure(text="нужна спецификация", text_color=GRAY_TEXT)

        # Блок 3
        self.badge3.configure(text="✓" if self.nomen_loaded else "3",
                              fg_color=GREEN if self.nomen_loaded else BLUE)
        can_match = bool(self.spec_path and self.nomen_loaded)
        if can_match:
            self.btn_match.configure(state="normal", text="▶ Сравнение с 1С",
                                     fg_color=GREEN, hover_color=GREEN_HOVER)
            self.status_match.configure(text="готово к запуску", text_color=GREEN_TEXT)
        else:
            self.btn_match.configure(state="disabled", text="🔒 Сравнение с 1С", fg_color=GRAY)
            self.status_match.configure(
                text="нужна номенклатура 1С" if self.spec_path else "нужны спецификация и 1С",
                text_color=GRAY_TEXT)

        # Полная обработка
        if can_match:
            self.btn_full.configure(state="normal", text="▶ Полная обработка",
                                    fg_color=GREEN, hover_color=GREEN_HOVER)
        else:
            self.btn_full.configure(state="disabled", text="🔒 Полная обработка", fg_color=GRAY)

        # во время работы блокируем запуски
        if self.busy:
            for b in (self.btn_create, self.btn_fitting, self.btn_match, self.btn_full):
                b.configure(state="disabled")

    # ───────── helpers ─────────
    def _out(self, suffix):
        d = self.out_var.get().strip() or self.out_dir
        base = os.path.splitext(os.path.basename(self.spec_path))[0] if self.spec_path else "результат"
        return os.path.join(d, base + suffix + ".xlsx")

    def _log(self, text):
        self.log.configure(state="normal")
        self.log.insert("end", text + "\n")
        self.log.see("end")
        self.log.configure(state="disabled")

    # ───────── действия ─────────
    def _create_table(self):
        if self.busy:
            return
        variant = int(self.variant_var.get().split()[-1])
        d = self.out_var.get().strip() or self.out_dir
        path = filedialog.asksaveasfilename(
            title="Куда сохранить базовую таблицу", initialdir=d,
            initialfile=f"Спецификация_базовая_В{variant}.xlsx",
            defaultextension=".xlsx", filetypes=[("Excel", "*.xlsx")])
        if not path:
            return
        self._start(lambda: core.create_base_table(path, variant=variant), "base")

    def _load_spec(self):
        if self.busy:
            return
        path = filedialog.askopenfilename(title="Выберите спецификацию",
                                          filetypes=[("Excel", "*.xlsx *.xlsm"), ("Все", "*.*")])
        if not path:
            return
        self._set_spec_path(path)

    def _set_spec_path(self, path):
        """Установить спецификацию (из диалога или перетаскиванием)."""
        self.spec_path = path
        self._log("> спецификация: " + os.path.basename(path))
        self._refresh()
        self._start(lambda: self._count_rows(path), "spec_count")

    @staticmethod
    def _count_rows(path):
        from openpyxl import load_workbook
        wb = load_workbook(path, read_only=True)
        ws = wb.active
        n = 0
        for row in ws.iter_rows(min_row=2, max_col=2, values_only=True):
            if row and len(row) >= 2 and row[1]:
                n += 1
        wb.close()
        return n

    def _run_fitting(self):
        if self.busy:
            return
        self._start(lambda: core.calc_fitting_area(self.spec_path, self._out("_фасонные_изделия")), "fitting")

    def _load_nomen(self):
        if self.busy:
            return
        path = filedialog.askopenfilename(title="Выберите файл номенклатуры 1С",
                                          filetypes=[("Excel/CSV", "*.xlsx *.xlsm *.csv"), ("Все", "*.*")])
        if not path:
            return
        self._set_nomen_path(path)

    def _set_nomen_path(self, path):
        """Загрузить номенклатуру (из диалога или перетаскиванием)."""
        self.nomen_path = path
        self._log("> номенклатура: " + os.path.basename(path))
        self._start(lambda: core.load_database(db_file_path=path, force_reload=True, use_com=False), "nomen")

    def _report_kwargs(self):
        """report_destination/report_folder для core.compare_with_1c/run_processing,
        по текущему выбору в выпадающем списке «Отчёт»."""
        destination = self.REPORT_DESTINATIONS.get(self.report_var.get(), "sheet")
        folder = self.out_var.get().strip() or self.out_dir
        return {"report_destination": destination, "report_folder": folder}

    def _run_match(self):
        if self.busy:
            return
        self._start(lambda: core.compare_with_1c(self.spec_path, db_file=self.nomen_path,
                                                 output_file=self._out("_1С"),
                                                 force_reload=False, **self._report_kwargs()), "match")

    def _run_full(self):
        if self.busy:
            return
        self._start(lambda: core.run_processing(self.spec_path, db_file=self.nomen_path,
                                                output_file=self._out("_processed"),
                                                force_reload=False, mode=core.MODE_FULL,
                                                **self._report_kwargs()), "full")

    def _change_outdir(self):
        d = filedialog.askdirectory(title="Папка для результатов")
        if d:
            self.out_var.set(d)

    # ───────── асинхронный запуск ─────────
    def _start(self, fn, kind):
        if self.busy:
            return
        self.busy = True
        self._refresh()
        threading.Thread(target=self._worker, args=(fn, kind), daemon=True).start()

    def _worker(self, fn, kind):
        try:
            result = fn()
            self.q.put(("done", kind, result))
        except Exception as e:
            self.q.put(("error", kind, str(e)))

    def _drain(self):
        try:
            while True:
                item = self.q.get_nowait()
                if item[0] == "log":
                    self._log(item[1])
                elif item[0] == "done":
                    self._on_done(item[1], item[2])
                elif item[0] == "error":
                    self.busy = False
                    self._refresh()
                    self._log(f"❌ Ошибка: {item[2]}")
                    messagebox.showerror("Ошибка", item[2])
        except queue.Empty:
            pass
        self.root.after(60, self._drain)

    def _on_done(self, kind, result):
        self.busy = False
        if kind == "base":
            self.base_done = True
            self._log(f"> базовая таблица создана ({self.variant_var.get()})")
        elif kind == "spec_count":
            self._log(f"> спецификация загружена · строк: {result}")
        elif kind == "nomen":
            self.nomen_loaded = bool(core._db_loaded)
            self._log("> номенклатура 1С загружена" if self.nomen_loaded
                      else "> не удалось загрузить номенклатуру 1С")
        elif kind in ("fitting", "match", "full"):
            self._log(f"> готово, файл сохранён: {result}")
        self._refresh()

    def run(self):
        self.root.mainloop()


if __name__ == "__main__":
    App().run()
