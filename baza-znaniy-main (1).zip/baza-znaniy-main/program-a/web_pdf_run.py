# -*- coding: utf-8 -*-
"""
Точка входа фоновых PDF-задач сайта.

VentSpec/Area: spec_conversion сначала читает геометрию, проверяет результат,
затем передаёт только сложные страницы Anthropic. Оборудование читает
известные листы кодом, сложные — Claude, затем сверяет объекты кодом.
Статус содержит ход обработки и итоговый JSON;
при распознавании добавляются needs_review и номера страниц.

"""

import os

# Та же предосторожность, что в web_run.py — на всякий случай, даже если
# сам pdf_to_spec.py не тянет numpy напрямую (openpyxl/PyMuPDF могут это
# делать транзитивно).
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import sys
import json
import time
import argparse
import traceback
import hashlib
from pathlib import Path

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
# common/ лежит на уровень выше program-a/ — оттуда берётся клиент Claude API.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

FORMAT_VENTSPEC = "ventspec"
FORMAT_AREA = "area"
FORMAT_EQUIPMENT = "equipment"


def _write_status(status_file, payload):
    if not status_file:
        return
    tmp_path = status_file + ".tmp"
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False)
    os.replace(tmp_path, status_file)


def main():
    parser = argparse.ArgumentParser(description="Веб-конвертация PDF-спецификации в Excel")
    parser.add_argument("--pdf", required=True, help="путь к загруженному PDF")
    parser.add_argument("--output", required=True, help="путь для сохранения .xlsx")
    parser.add_argument("--status-file", default=None,
                        help="куда записать итоговый JSON-статус (для фонового запуска из PHP)")
    parser.add_argument("--display-base", default=None,
                        help="имя исходного PDF (без расширения) для пользовательского "
                             "имени результата при скачивании")
    parser.add_argument("--format", default=FORMAT_VENTSPEC,
                        choices=[FORMAT_VENTSPEC, FORMAT_AREA, FORMAT_EQUIPMENT],
                        help="формат результата: ventspec — спецификация VentSpec "
                             "(38 колонок), area — плоский список для расчёта площади, "
                             "equipment — сверка марок вентиляторов по альбому")
    args = parser.parse_args()

    is_area = args.format == FORMAT_AREA
    is_equipment = args.format == FORMAT_EQUIPMENT

    t0 = time.time()
    print(f"⏱️  Начало конвертации: {time.strftime('%H:%M:%S')}", file=sys.stderr)

    # "mode" в статусе — по нему status.php возвращает пользователя на
    # area.php или equipment.php, а не на ventspec.php (то же поле пишет
    # web_run.py). Для формата VentSpec поля нет, как и раньше.
    mode_field = {"mode": args.format} if (is_area or is_equipment) else {}

    try:
        # Модуль конвертера подгружается здесь, а не наверху файла,
        # намеренно. Импорт на верхнем уровне падает ДО того, как
        # начинает работать этот try, — то есть до записи статус-файла:
        # для пользователя это выглядит как вечное "Обработка идёт...",
        # потому что status.php ждёт файла, которого уже никто не
        # напишет. И, что хуже, сломанный (или просто не выложенный на
        # сервер) модуль одного блока ронял бы вместе с собой два
        # других — скрипт у всех трёх форматов общий. Так ошибка
        # попадает в статус-файл, пользователь видит внятное сообщение,
        # а соседние блоки продолжают работать.
        if is_equipment:
            from common.claude_client import client_from_environment
            from equipment_pipeline import build as build_equipment
            claude = client_from_environment()
            if claude is not None:
                claude.timeout = min(claude.timeout, 90)
                claude.max_retries = min(claude.max_retries, 1)
            def equipment_progress(stage, done, total):
                _write_status(args.status_file, dict(
                    mode='equipment', state='running', started=t0, updated=time.time(),
                    stage='%s: %s из %s' % (stage, done, total)))
            conversion = build_equipment(args.pdf, client=claude, output_path=args.output,
                                         progress=equipment_progress)
            output_file, total_rows = conversion['output_file'], conversion['total_rows']
        else:
            from spec_conversion import convert_specification
            from common.claude_client import client_from_environment
            def make_client():
                client = client_from_environment()
                if client is not None:
                    client.timeout = min(client.timeout, 90)
                    client.max_retries = 1
                return client
            def progress(done, total, stage):
                payload = {"state": "running", "stage": stage,
                           "current_page": done, "total_pages": total}
                payload.update(mode_field)
                _write_status(args.status_file, payload)
            fingerprint = hashlib.sha256(Path(args.pdf).read_bytes()).hexdigest()
            conversion = convert_specification(
                args.pdf, args.output, args.format, progress=progress,
                client_factory=make_client,
                cache_dir=str(Path(args.output).parent / 'spec_cache' / fingerprint))
            output_file, total_rows = conversion['output_file'], conversion['total_rows']
        dt = time.time() - t0
        print(f"⏱️  Конвертация завершена за {dt:.1f} сек, позиций: {total_rows}", file=sys.stderr)
        result = {
            "ok": True,
            "output_file": output_file,
            "report_file": None,
            "total_rows": total_rows,
        }
        result.update(mode_field)
        result.update({key: conversion[key] for key in
                       ("engine", "checked_pages", "ai_pages")})
        if is_area or is_equipment:
            result.update({key: conversion[key] for key in ("needs_review", "warnings")})
        if args.display_base:
            if is_equipment:
                suffix = "_oborud.xlsx"
            elif is_area:
                suffix = "_area_cont.xlsx"
            else:
                suffix = "_cont.xlsx"
            result["output_display_name"] = args.display_base + suffix
        print(json.dumps(result, ensure_ascii=False))
        _write_status(args.status_file, result)
    except Exception as exc:
        result = {"ok": False, "error": str(exc), "trace": traceback.format_exc()}
        result.update(mode_field)
        print(json.dumps(result, ensure_ascii=False))
        _write_status(args.status_file, result)
        sys.exit(1)


if __name__ == "__main__":
    main()
