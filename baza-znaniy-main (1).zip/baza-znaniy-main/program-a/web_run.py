# -*- coding: utf-8 -*-
"""
Точка входа для веб-интеграции (PHP -> shell_exec -> этот скрипт).

Тонкая обёртка над run_processing() из vent_processor.py — той же функцией,
которую вызывает десктопный GUI (vent_gui.py). Никакой отдельной логики
обработки здесь нет, только: разбор аргументов командной строки, ограничение
числа потоков BLAS (нужно на shared-хостинге с лимитом процессов на аккаунт)
и печать результата в виде JSON на stdout, чтобы PHP мог его разобрать.

Пример вызова:
  python3 web_run.py --spec /path/spec.xlsx --db /path/1c_base.xlsx \
      --mode full --output /path/result.xlsx --report-folder /path/reports
"""

import os

# Обязательно ДО импорта vent_processor (на случай, если что-то из common/
# транзитивно потянет numpy). На shared-хостинге с лимитом RLIMIT_NPROC на
# аккаунт numpy/OpenBLAS может упасть при попытке создать поток на каждое
# ядро — см. историю переписки по деплою на reg.ru Host-0.
os.environ.setdefault("OPENBLAS_NUM_THREADS", "1")
os.environ.setdefault("OMP_NUM_THREADS", "1")
os.environ.setdefault("NUMEXPR_NUM_THREADS", "1")
os.environ.setdefault("MKL_NUM_THREADS", "1")

import sys
import json
import argparse
import traceback

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from vent_processor import run_processing, set_logger, MODE_FULL, MODE_FITTING, MODE_MATCH  # noqa: E402
from area_calc import run_area_calc  # noqa: E402

# "area" — отдельный от MODE_FULL/MODE_FITTING/MODE_MATCH режим: не через
# run_processing() (там 38-колоночная структура VentSpec обязательна), а
# через свой лёгкий run_area_calc() — плоский список "Наименование" +
# "Площадь", см. area_calc.py.
MODE_AREA = "area"

# run_processing() по умолчанию печатает весь ход обработки через print()
# (десятки/сотни строк на файл — для GUI это лог в текстовом поле). Если
# это попадёт на stdout, PHP не сможет разобрать финальную строку JSON.
# Поэтому весь этот вывод уходит в stderr, а stdout остаётся только для
# итогового JSON.
set_logger(lambda msg: print(msg, file=sys.stderr))


def _find_report_file(spec_file, report_folder):
    """run_processing() не возвращает путь к отдельному файлу-отчёту (только
    к обработанной спецификации) — имя отчёта генерируется внутри, по
    известному шаблону (см. common/report.py: default_report_path)."""
    if not report_folder:
        return None
    base = os.path.splitext(os.path.basename(spec_file))[0]
    path = os.path.join(report_folder, f"{base}_otch.xlsx")
    return path if os.path.isfile(path) else None


def _write_status(status_file, payload):
    """Пишет итоговый статус в файл — process.php запускает этот скрипт в
    фоне (не дожидаясь его завершения в самом HTTP-запросе, обработка может
    идти дольше, чем живёт соединение с браузером), поэтому единственный
    надёжный способ узнать результат — файл на диске, а не то, что скрипт
    напечатает в stdout (это соединение уже никто не читает)."""
    if not status_file:
        return
    tmp_path = status_file + ".tmp"
    with open(tmp_path, "w", encoding="utf-8") as f:
        json.dump(payload, f, ensure_ascii=False)
    os.replace(tmp_path, status_file)  # атомарно — status.php не увидит частично записанный файл


def main():
    parser = argparse.ArgumentParser(description="Веб-запуск обработки спецификации")
    parser.add_argument("--spec", required=True, help="путь к загруженной спецификации (.xlsx)")
    parser.add_argument("--db", default=None, help="путь к файлу базы 1С (.xlsx/.csv)")
    parser.add_argument("--output", default=None, help="путь для сохранения результата")
    parser.add_argument("--mode", default=MODE_FULL,
                        choices=[MODE_FULL, MODE_FITTING, MODE_MATCH, MODE_AREA])
    parser.add_argument("--report-folder", default=None,
                        help="папка для отдельного файла-отчёта (mode=full/match)")
    parser.add_argument("--status-file", default=None,
                        help="куда записать итоговый JSON-статус (для фонового запуска из PHP)")
    parser.add_argument("--display-base", default=None,
                        help="имя исходного файла (без расширения) для пользовательского "
                             "имени результата при скачивании — файл на диске всё равно "
                             "хранится под токеном, это только для Content-Disposition")
    parser.add_argument("--claude-credentials", default=None,
                        help="путь к JSON с ключом Anthropic (тот же файл выше корня сайта, "
                             "что у Verrata) для Tier 3: Claude выбирает позицию базы 1С "
                             "среди кандидатов Tier 2. Передаётся путь, не ключ. Не "
                             "указано — Tier 3 просто не включается.")
    args = parser.parse_args()

    report_destination = "folder" if args.mode in (MODE_FULL, MODE_MATCH) and args.report_folder else None

    try:
        if args.mode == MODE_AREA:
            output_file = run_area_calc(
                spec_file=args.spec,
                output_file=args.output,
                log=lambda msg: print(msg, file=sys.stderr),
            )
            report_file = None
        else:
            output_file = run_processing(
                spec_file=args.spec,
                db_file=args.db,
                output_file=args.output,
                use_com=False,
                force_reload=True,
                mode=args.mode,
                report_destination=report_destination,
                report_folder=args.report_folder,
                claude_credentials_file=args.claude_credentials,
            )
            report_file = _find_report_file(args.spec, args.report_folder) if report_destination else None
        result = {"ok": True, "output_file": output_file, "report_file": report_file, "mode": args.mode}
        if args.display_base:
            suffix = "_area.xlsx" if args.mode == MODE_AREA else "_full_obr.xlsx"
            result["output_display_name"] = args.display_base + suffix
            if report_file:
                result["report_display_name"] = args.display_base + "_otch.xlsx"
        print(json.dumps(result, ensure_ascii=False))
        _write_status(args.status_file, result)
    except Exception as exc:
        result = {"ok": False, "error": str(exc), "trace": traceback.format_exc(), "mode": args.mode}
        print(json.dumps(result, ensure_ascii=False))
        _write_status(args.status_file, result)
        sys.exit(1)


if __name__ == "__main__":
    main()
