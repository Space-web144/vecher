"""Import all deployable application files as exact Git blobs, refusing conflicts."""

import argparse
import os
from pathlib import Path
import re
import subprocess
import sys


sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "deploy"))
from vps_server import allowed as deployable_path  # Shared server-side safety policy
REVISION = Path(".github/co-import/source-revision")
SHA = re.compile(r"[0-9a-f]{40}")


def git(*args, data=None):
    return subprocess.run(["git", *args], input=data, check=True, stdout=subprocess.PIPE).stdout


def tree_entry(revision, path):
    """Return the exact mode and blob SHA for a file in a Git tree."""
    raw = git("ls-tree", "-z", revision, "--", path)
    if not raw:
        return None
    entries = raw.rstrip(b"\0").split(b"\0")
    if len(entries) != 1:
        raise ValueError(f"Неоднозначный путь в Git: {path!r}")
    metadata, actual_path = entries[0].split(b"\t", 1)
    mode, kind, blob = metadata.split()
    if os.fsdecode(actual_path) != path or kind != b"blob":
        raise ValueError(f"Ожидался обычный файл: {path!r}")
    return mode, blob


def stage_import(base, head):
    if not all(SHA.fullmatch(sha) for sha in (base, head)):
        raise ValueError("Укажите полные SHA исходных коммитов.")
    if git("status", "--porcelain", "--untracked-files=no"):
        raise ValueError("Перед импортом нужен чистый checkout main.")

    if subprocess.run(["git", "merge-base", "--is-ancestor", base, head]).returncode:
        raise ValueError("Исходная ветка больше не содержит последнюю принятую ревизию.")

    raw = git("diff", "--raw", "--no-renames", "-z", base, head)
    entries = raw.split(b"\0")[:-1]
    paths = {}
    for metadata, path in zip(entries[::2], entries[1::2], strict=True):
        old_mode, new_mode, _, _, status = metadata[1:].split()
        paths[os.fsdecode(path)] = (old_mode, new_mode, status)

    blocked = {path for path in paths if not deployable_path(path)}
    if blocked:
        raise ValueError("Файлы вне разрешённых путей приложения для VPS: " + ", ".join(repr(p) for p in sorted(blocked)))
    for path, (old_mode, new_mode, status) in paths.items():
        if status not in {b"A", b"M"} or new_mode not in {b"100644", b"100755"}:
            raise ValueError(f"Импорт поддерживает добавление и правку обычных файлов: {path!r}")
        if status == b"M" and old_mode != new_mode:
            raise ValueError(f"Изменение прав файла требует отдельной правки: {path!r}")

    # Check every file before making changes. Independent changes to main
    # are conflicts even if git apply --3way could merge them automatically.
    to_copy = []
    for path, (_, new_mode, status) in paths.items():
        previous = tree_entry(base, path)
        incoming = tree_entry(head, path)
        current = tree_entry("HEAD", path)
        if incoming is None or incoming[0] != new_mode:
            raise ValueError(f"Не удалось сверить исходный файл: {path!r}")
        if status == b"A" and previous is not None:
            raise ValueError(f"Исходная ревизия неожиданно содержит файл: {path!r}")
        if status == b"M" and previous is None:
            raise ValueError(f"Исходный файл отсутствует в базовой ревизии: {path!r}")
        if current == incoming:
            continue  # Already identical to the developer's version.
        if current != previous:
            raise ValueError(f"Конфликт с текущим main (файл не перезаписан): {path!r}")
        destination = Path(path)
        if current is None and (destination.exists() or destination.is_symlink()):
            raise ValueError(f"Незарегистрированный файл уже существует: {path!r}")
        if any(parent.is_symlink() for parent in destination.parents):
            raise ValueError(f"Символическая ссылка в пути назначения: {path!r}")
        to_copy.append(path)

    if to_copy:
        # Restore entire original source blobs, not a three-way merged patch.
        git("restore", "--source", head, "--staged", "--worktree", "--", *to_copy)
        for path in to_copy:
            indexed = git("ls-files", "-s", "--", path).rstrip(b"\n")
            mode, blob, stage_and_path = indexed.split(b" ", 2)
            if stage_and_path != b"0\t" + os.fsencode(path) or (mode, blob) != tree_entry(head, path):
                raise ValueError(f"Ошибка проверки точного содержимого файла: {path!r}")
        staged = {os.fsdecode(name) for name in
                  git("diff", "--cached", "--name-only", "--no-renames", "-z").split(b"\0") if name}
        if staged - paths.keys():
            raise ValueError("Итоговый diff содержит файлы вне исходного набора правок.")

    REVISION.parent.mkdir(parents=True, exist_ok=True)
    REVISION.write_text(head + "\n")
    git("add", "--", str(REVISION))
    return sorted(paths)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("head")
    args = parser.parse_args()
    base = REVISION.read_text().strip() if REVISION.is_file() else os.getenv("CO_SOURCE_BASE", "")
    try:
        files = stage_import(base, args.head)
    except (ValueError, subprocess.CalledProcessError) as error:
        sys.exit(str(error))
    for path in files:
        print(path)


if __name__ == "__main__":
    main()
