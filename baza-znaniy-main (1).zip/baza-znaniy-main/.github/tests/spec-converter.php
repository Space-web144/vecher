<?php
declare(strict_types=1);
// Isolated fixtures: no real credentials, sessions or production files.
$source = dirname(__DIR__, 2) . '/web';
$temporary = sys_get_temp_dir() . '/spec-test-' . bin2hex(random_bytes(8));
mkdir($temporary . '/assets', 0700, true);
function check(bool $condition, string $message): void {
    if (!$condition) throw new RuntimeException($message);
}
function render_case(string $directory, string $code): string {
    file_put_contents($directory . '/case.php', '<?php ' . $code);
    $lines = []; $exit = 0;
    exec(escapeshellarg(PHP_BINARY) . ' ' . escapeshellarg($directory . '/case.php') . ' 2>&1', $lines, $exit);
    check($exit === 0, 'PHP fixture failed: ' . implode("\n", $lines));
    return implode("\n", $lines);
}
try {
    copy($source . '/status.php', $temporary . '/status.php');
    copy($source . '/libob.php', $temporary . '/libob.php');
    foreach (['auth_guard.php', 'users.php', 'sidebar.php'] as $name) file_put_contents($temporary . '/' . $name, '<?php');
    file_put_contents($temporary . '/config.php', "<?php define('OUTPUT_DIR', __DIR__); define('UPLOAD_DIR', __DIR__);");
    foreach (['ui.js','style.css'] as $name) file_put_contents($temporary . '/assets/' . $name, '');
    $run = '$_GET=["token"=>"0123456789abcdef"];require __DIR__."/status.php";';
    foreach (['running', 'review', 'ventspec_review', 'success', 'error'] as $scenario) {
        $value = ['ok'=>true, 'output_file'=>'result.xlsx', 'mode'=>'area'];
        if ($scenario === 'running') $value = ['state'=>'running','mode'=>'area','stage'=>'Чтение 2 из 4 <script>bad()</script>'];
        if ($scenario === 'review') $value['needs_review'] = true;
        if ($scenario === 'ventspec_review') { unset($value['mode']); $value['needs_review'] = true; }
        if ($scenario === 'error') $value = ['ok'=>false,'mode'=>'area','error'=>'Позиции не найдены'];
        file_put_contents($temporary . '/0123456789abcdef_status.json', json_encode($value));
        $html = render_case($temporary, $run);
        if ($scenario === 'running') {
            check(strpos($html, 'Обработка идёт') !== false, 'Running status was treated as failure');
            check(strpos($html, '&lt;script&gt;') !== false && strpos($html, '<script>bad') === false, 'Stage must be escaped');
        } elseif ($scenario === 'review') {
            check(strpos($html, 'alert warn') !== false && strpos($html, 'alert success') === false, 'Review must be visible');
            check(strpos($html, 'href="area.php"') !== false, 'Area return link lost');
        } elseif ($scenario === 'ventspec_review') {
            check(strpos($html, 'alert warn') === false && strpos($html, 'alert success') !== false, 'VentSpec must have clean success page');
            check(strpos($html, 'href="ventspec.php"') !== false, 'VentSpec return link lost');
        } elseif ($scenario === 'success') {
            check(strpos($html, 'alert success') !== false, 'Native success missing');
        } else check(strpos($html, 'Позиции не найдены') !== false, 'Error message missing');
    }
    // Read both supported credential formats without ever printing their contents.
    foreach (['json', 'php'] as $extension) {
        $secret = ['api_key'=>"fake-'test", 'model'=>'equipment-only', 'model_spec'=>'spec-test', 'effort_spec'=>'medium', 'proxy'=>'http://proxy.test'];
        file_put_contents($temporary . '/secret.' . $extension, $extension === 'json' ? json_encode($secret) : '<?php return ' . var_export($secret,true) . ';');
        $code = 'define("ANTHROPIC_CREDENTIALS_FILE",__DIR__."/secret.' . $extension . '");require __DIR__."/libob.php";'
            . '$p=spec_claude_env_prefix();if(strpos($p,"ANTHROPIC_MODEL=".escapeshellarg("spec-test"))===false || strpos($p,"equipment-only")!==false || strpos($p,"ANTHROPIC_PROXY=")===false)exit(2);echo "OK";';
        check(render_case($temporary, $code) === 'OK', 'Credential loader leaked output');
    }
    echo "PASS: running/review/success/error, HTML escaping, area navigation, JSON/PHP settings\n";
} finally {
    $items = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($temporary, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
    foreach ($items as $item) $item->isDir() ? rmdir($item->getPathname()) : unlink($item->getPathname());
    rmdir($temporary);
}
