<?php
declare(strict_types=1);

require dirname(__DIR__, 2) . '/web/clean_papper_access.php';

function cp_expect(bool $condition, string $message): void
{
    if (!$condition) {
        fwrite(STDERR, "FAIL: " . $message . "\n");
        exit(1);
    }
}

cp_expect(clean_papper_allowed('veryhardlogin'), 'requested account must be allowed');
foreach (['', 'admin', 'mainadmin', 'veryhardlogin69', 'Veryhardlogin',
          'veryhardlogin ', ' veryhardlogin', 'other.user'] as $login) {
    cp_expect(!clean_papper_allowed($login), 'unexpected access for ' . var_export($login, true));
}

$root = dirname(__DIR__, 2);
$guard = (string) file_get_contents($root . '/web/clean_papper_guard.php');
$page = (string) file_get_contents($root . '/web/clean_papper.php');
$sidebar = (string) file_get_contents($root . '/web/sidebar.php');
$refresh = (string) file_get_contents($root . '/web/sidebar_refresh.php');

cp_expect(str_contains($guard, "require __DIR__ . '/auth_guard.php';"), 'guard must use PHP session authentication');
cp_expect(str_contains($guard, "require_once __DIR__ . '/clean_papper_access.php';"), 'guard must require allowlist');
cp_expect(str_contains($guard, 'http_response_code(403);'), 'guard must return HTTP 403');
cp_expect(str_contains($page, "require __DIR__ . '/clean_papper_guard.php';"), 'page must invoke guard');
cp_expect(str_contains($sidebar, 'if ($kbCleanPapperAllowed): ?>'), 'original navigation must guard link');
cp_expect(str_contains($refresh, 'if ($kbCleanPapperAllowed): ?>'), 'refreshed navigation must guard link');
cp_expect(str_contains($sidebar, 'href="clean_papper.php"'), 'original menu link absent');
cp_expect(str_contains($refresh, "kb_nav('clean_papper.php'"), 'refreshed menu link absent');

echo "Clean Papper: strict account allowlist and admin menu guards OK\n";
