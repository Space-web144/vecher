<?php
declare(strict_types=1);

/** Synthetic, offline tests: no accounts, no project PDFs, no Claude API. */
require dirname(__DIR__, 2) . '/web/clean_papper_upload_lib.php';

function cp_chunk_expect(bool $ok, string $reason): void
{
    if (!$ok) {
        fwrite(STDERR, "Clean Papper chunks: " . $reason . "\n");
        exit(1);
    }
}
function cp_chunk_reject(callable $fn, string $reason): void
{
    try {
        $fn();
    } catch (InvalidArgumentException $e) {
        return;
    }
    cp_chunk_expect(false, $reason);
}

$root = dirname(__DIR__, 2);
$endpoint = (string) file_get_contents($root . '/web/clean_papper_upload.php');
$process = (string) file_get_contents($root . '/web/clean_papper_pdf.php');
$frontend = (string) file_get_contents($root . '/web/assets/clean_papper_drawing.js');

cp_chunk_expect(str_contains($endpoint, "require __DIR__ . '/clean_papper_guard.php';"),
    'authorization guard missing');
cp_chunk_expect(str_contains($endpoint, 'hash_equals(') && str_contains($endpoint, 'clean_papper_csrf'),
    'CSRF and session-bound tokens required');
cp_chunk_expect(str_contains($endpoint, 'is_uploaded_file('), 'uploaded-file validation absent');
cp_chunk_expect(str_contains($endpoint, "['init', 'chunk', 'cancel']"),
    'expected upload actions absent');
cp_chunk_expect(str_contains($process, 'cp_pdf_upload_complete_path('),
    'processing must require a complete session-bound upload');
cp_chunk_expect(str_contains($process, 'register_shutdown_function('),
    'processing must schedule file cleanup');
cp_chunk_expect(str_contains($frontend, "f.slice(offset, end)"),
    'browser must transmit small chunks');
cp_chunk_expect(str_contains($frontend, "data.delete('pdf')"),
    'browser must not resend whole PDF during processing');
cp_chunk_expect(str_contains($frontend, 'cancelUpload(uploadId)'),
    'client must cancel interrupted uploads');

cp_chunk_expect(CP_PDF_CHUNK_BYTES === 1048576, 'chunk size must be <= 1 MiB');
cp_chunk_expect(CP_PDF_MAX_BYTES === 100 * 1024 * 1024, 'max file must stay 100 MiB');
cp_chunk_reject(static fn() => cp_pdf_upload_begin('bad.exe', 12),
    'non-PDF extension must be denied');
cp_chunk_reject(static fn() => cp_pdf_upload_begin('bad.pdf', 100 * 1024 * 1024 + 1),
    'oversize PDF must be denied');

// Verify that a PDF at the new limit can be uploaded in 100 unchanged 1 MiB parts.
$maxUpload = cp_pdf_upload_begin('max-size.pdf', CP_PDF_MAX_BYTES);
$maxPath = cp_pdf_upload_path((string) $maxUpload['id']);
try {
    $payload = str_repeat('A', CP_PDF_CHUNK_BYTES);
    $first = '%PDF-1.4' . substr($payload, 8);
    for ($offset = 0; $offset < CP_PDF_MAX_BYTES; $offset += CP_PDF_CHUNK_BYTES) {
        cp_chunk_expect(cp_pdf_upload_append($maxUpload, $offset === 0 ? $first : $payload, $offset) === $offset + CP_PDF_CHUNK_BYTES,
            '100 MiB upload offset mismatch');
    }
    cp_chunk_expect(cp_pdf_upload_complete_path($maxUpload, (string) $maxUpload['id']) === $maxPath,
        '100 MiB upload must be accepted');
} finally {
    cp_pdf_upload_discard($maxUpload);
}


$pdf = '%PDF-1.4' . str_repeat('A', 2 * CP_PDF_CHUNK_BYTES + 29);
$meta = cp_pdf_upload_begin('synthetic.pdf', strlen($pdf));
$path = cp_pdf_upload_path((string) $meta['id']);
cp_chunk_expect(is_file($path), 'staged private file missing');
cp_chunk_expect((fileperms($path) & 0077) === 0, 'temporary file permissions too broad');
cp_chunk_reject(static fn() => cp_pdf_upload_complete_path($meta, (string) $meta['id']),
    'partial file must not be processable');
$pos = 0;
while ($pos < strlen($pdf)) {
    $fragment = substr($pdf, $pos, CP_PDF_CHUNK_BYTES);
    $received = cp_pdf_upload_append($meta, $fragment, $pos);
    cp_chunk_expect($received === $pos + strlen($fragment), 'offset mismatch');
    $pos = $received;
}
cp_chunk_expect($meta['complete'] === true, 'final flag absent');
cp_chunk_expect(cp_pdf_upload_complete_path($meta, (string) $meta['id']) === $path,
    'complete file should resolve');
cp_chunk_expect(file_get_contents($path) === $pdf, 'PDF bytes differ after chunk assembly');
cp_chunk_reject(static fn() => cp_pdf_upload_complete_path($meta, str_repeat('a', 32)),
    'different upload token must be denied');
cp_chunk_reject(static function () use (&$meta) {
    cp_pdf_upload_append($meta, 'X', 0);
}, 'completed upload must reject append');
cp_pdf_upload_discard($meta);
cp_chunk_expect(!file_exists($path), 'finished file must be deleted');

$bad = cp_pdf_upload_begin('test.pdf', 20);
cp_chunk_reject(static function () use (&$bad) {
    cp_pdf_upload_append($bad, 'NOT-PDF', 0);
}, 'PDF signature required');
cp_pdf_upload_discard($bad);
$reordered = cp_pdf_upload_begin('test.pdf', 25);
cp_chunk_reject(static function () use (&$reordered) {
    cp_pdf_upload_append($reordered, '%PDF-test', 9);
}, 'out-of-order chunk must be refused');
cp_pdf_upload_discard($reordered);
$expired = cp_pdf_upload_begin('test.pdf', 25);
$expired['updated'] -= (CP_PDF_TTL_SECONDS + 10);
cp_chunk_reject(static function () use (&$expired) {
    cp_pdf_upload_append($expired, '%PDF-test', 0);
}, 'expired upload must be rejected');
cp_pdf_upload_discard($expired);

echo "Clean Papper: chunk size, assembly, provenance, isolation and cleanup OK\n";
