<?php
declare(strict_types=1);
// Render real UI and exercise real form handlers with a harmless argv recorder.
$source = dirname(__DIR__, 2) . '/web';
$temporary = sys_get_temp_dir() . '/onec-routing-' . bin2hex(random_bytes(8));
mkdir($temporary . '/assets', 0700, true);
mkdir($temporary . '/outputs', 0700);
function check(bool $ok, string $message): void {
    if (!$ok) throw new RuntimeException($message);
}
function run_case(string $file, array $post = [], bool $authorized = true): string {
    global $temporary;
    @unlink($temporary . '/argv.json');
    file_put_contents($temporary . '/case.php', '<?php $_SESSION=["csrf"=>"test-csrf"]; $_GET=[];'
        . '$_POST=' . var_export($post, true) . '; $_SERVER["REQUEST_METHOD"]="POST";'
        . '$authorized=' . var_export($authorized, true) . ';require __DIR__."/' . $file . '";');
    $lines=[]; $exit=0;
    exec(escapeshellarg(PHP_BINARY) . ' ' . escapeshellarg($temporary . '/case.php') . ' 2>&1', $lines, $exit);
    check($exit === 0, 'Fixture failed: ' . implode("\n", $lines));
    $html=implode("\n", $lines);
    check(strpos($html,'Warning:')===false, 'PHP warning: ' . $html);
    return $html;
}
try {
    foreach (['onec_review.php','onec_review_submit.php','onec_review_bulk.php','onec_review_approve_all.php','onec_intake.php'] as $file) {
        copy($source.'/'.$file,$temporary.'/'.$file);
    }
    file_put_contents($temporary.'/admin_guard.php','<?php if (!$authorized) { echo "AUTH_REQUIRED"; exit; }');
    file_put_contents($temporary.'/sidebar.php','<?php');
    foreach (['style.css','ui.js'] as $file) file_put_contents($temporary.'/assets/'.$file,'');
    file_put_contents($temporary.'/config.php','<?php define("OUTPUT_DIR",__DIR__."/outputs");'
        . 'define("UPLOAD_DIR",__DIR__."/uploads");'
        . 'define("PYTHON_BIN",PHP_BINARY);'
        . 'define("WEB_1C_REVIEW_SUBMIT_SCRIPT",__DIR__."/runner.php");'
        . 'define("WEB_1C_REVIEW_BULK_SCRIPT",__DIR__."/runner.php");'
        . 'define("ONEC_NOMENCLATURE_FILE",__DIR__."/existing.json");'
        . 'define("DB_FILE",__DIR__."/database.xlsx");');
    file_put_contents($temporary.'/runner.php','<?php file_put_contents(__DIR__."/argv.json",json_encode($argv));'
        . 'echo json_encode(["ok"=>true,"promoted"=>1,"errors"=>[]]);');
    file_put_contents($temporary.'/existing.json','[]'); file_put_contents($temporary.'/database.xlsx','fixture');
    $entries=[];
    for ($i=0;$i<51;$i++) $entries[]=['id'=>$i,'token'=>'0123456789abcdef','raw_item'=>['Код'=>'VK-'.$i,'Наименование'=>'Болт <script>alert(1)</script>'],
        'routing'=>['catalog'=>$i===0?'vk':null,'reason'=>'Причина <unsafe>'],
        'flags'=>[['type'=>'catalog_review','detail'=>'Выберите раздел']], 'resolved'=>false];
    file_put_contents($temporary.'/outputs/0123456789abcdef_1c_pending.json',json_encode($entries));
    $html=run_case('onec_review.php');
    check(strpos($html,'name="catalog"')!==false,'Catalog selector missing');
    check(strpos($html,'value="vk" selected')!==false,'VK recommendation not selected');
    check(strpos($html,'Причина &lt;unsafe&gt;')!==false,'Routing reason must be escaped');
    check(strpos($html,'<script>alert(1)</script>')===false,'Incoming name must be escaped');
    check(strpos($html,'onec_review_approve_all.php')!==false,'Approve-all path missing');
    $base=['csrf'=>'test-csrf','token'=>'0123456789abcdef','id'=>'0','name'=>'Болт','action'=>'approve','catalog'=>'vk'];
    foreach (['onec_review_submit.php','onec_review_bulk.php','onec_review_approve_all.php'] as $file) {
        $post=$base+['selected'=>['0123456789abcdef:0']];
        check(run_case($file,$post,false)==='AUTH_REQUIRED','Handler lost admin guard: '.$file);
        check(!is_file($temporary.'/argv.json'),'Unauthorized execution: '.$file);
        run_case($file,array_replace($post,['csrf'=>'wrong']));
        check(!is_file($temporary.'/argv.json'),'CSRF rejection failed: '.$file);
        run_case($file,$post);
        check(is_file($temporary.'/argv.json'),'Approved handler did not invoke runner: '.$file);
        $args=json_decode(file_get_contents($temporary.'/argv.json'),true);
        if ($file!=='onec_review_approve_all.php') {
            check(in_array('--catalog',$args,true) && in_array('vk',$args,true),'Catalog not forwarded: '.$file);
            run_case($file,array_replace($post,['catalog'=>'../unknown']));
            check(!is_file($temporary.'/argv.json'),'Invalid catalog executed: '.$file);
        } else {
            check(!in_array('--catalog',$args,true),'Approve-all must resolve each position separately');
        }
    }
    echo "Routing UI, auth, CSRF and all approval handlers: OK\n";
} finally {
    $iterator=new RecursiveIteratorIterator(new RecursiveDirectoryIterator($temporary,FilesystemIterator::SKIP_DOTS),RecursiveIteratorIterator::CHILD_FIRST);
    foreach($iterator as $path) { if($path->isDir()) rmdir($path->getPathname()); else unlink($path->getPathname()); }
    rmdir($temporary);
}
