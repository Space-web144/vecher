"""Exercise the importer against two snapshots in an isolated Git repository."""

import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest


AUTOMATION = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(AUTOMATION / "co-import"))
sys.path.insert(0, str(AUTOMATION / "deploy"))

from prepare import REVISION, stage_import
from vps_server import allowed


class ImportTest(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.addCleanup(os.chdir, Path.cwd())
        os.chdir(self.temp.name)
        self.git("init", "-q")
        self.git("config", "user.name", "Tests")
        self.git("config", "user.email", "test@example.invalid")
        self.rv = Path("web/rv.php")
        self.tkp = Path("web/tkp_customer.php")
        self.area = Path("web/area.php")
        self.rv.parent.mkdir()
        self.original = "\n".join(["Исходное"] + ["неизменная строка"] * 12 + ["Подвал"]) + "\n"
        self.rv.write_text(self.original)
        self.area.write_text("Расчёт площади\n")
        self.base = self.commit("Общая исходная версия")

    def git(self, *args):
        return subprocess.check_output(["git", *args], text=True).strip()

    def commit(self, message):
        self.git("add", "--all")
        self.git("commit", "-qm", message)
        return self.git("rev-parse", "HEAD")

    def switch_to_site(self):
        self.git("switch", "-q", "--detach", self.base)

    def test_import_accepts_all_deployable_app_files_and_protects_data(self):
        for path in ["web/area.php", "web/structure.php", "common/agent_files.py",
                     "common/tests/test_agent_chat.py", "web/agent1c.php",
                     "web/sidebar_refresh.php", "program-a/area_calc.py"]:
            self.assertTrue(allowed(path), path)
        for path in ["web/config.php", "web/data/file.php", "common/secrets/token.py",
                     ".github/workflows/deploy-vps.yml", "docs/readme.md",
                     "web/.auth_credentials.php"]:
            self.assertFalse(allowed(path), path)

    def test_exact_app_code_beyond_rv_tkp_is_imported(self):
        self.area.write_text("Обновлённая площадь\\n")
        common = Path("common/agent_files.py")
        common.parent.mkdir(parents=True)
        common.write_text("VALUE = 1\\n")
        source = self.commit("Обновления разных модулей")
        self.switch_to_site()
        self.assertEqual(stage_import(self.base, source),
                         ["common/agent_files.py", "web/area.php"])
        for path in [self.area, common]:
            self.assertEqual(self.git("rev-parse", ":" + path.as_posix()),
                             self.git("rev-parse", source + ":" + path.as_posix()))

    def test_copies_exact_original_blobs_without_merging(self):
        binary = b"Developer\x00\r\nSource\xff\n"
        tkp = b"New TKP\r\n"
        self.rv.write_bytes(binary)
        self.tkp.write_bytes(tkp)
        source = self.commit("РВ и ТКП")
        self.switch_to_site()
        self.area.write_text("Моя формула\n")
        self.commit("Независимая правка расчета площади")
        self.assertEqual(stage_import(self.base, source), [self.rv.as_posix(), self.tkp.as_posix()])
        self.assertEqual(self.rv.read_bytes(), binary)
        self.assertEqual(self.tkp.read_bytes(), tkp)
        for path in (self.rv, self.tkp):
            self.assertEqual(self.git("rev-parse", ":" + path.as_posix()),
                             self.git("rev-parse", source + ":" + path.as_posix()))
        self.assertEqual(self.area.read_text(), "Моя формула\n")
        self.assertEqual(REVISION.read_text().strip(), source)

    def test_parallel_main_edit_is_conflict_even_when_nonoverlapping(self):
        self.rv.write_text(self.original.replace("Исходное", "РВ разработчика"))
        source = self.commit("РВ разработчика")
        self.switch_to_site()
        self.rv.write_text(self.original.replace("Подвал", "Локальная правка"))
        self.commit("Независимая правка сайта")
        with self.assertRaisesRegex(ValueError, "Конфликт"):
            stage_import(self.base, source)
        self.assertFalse(REVISION.exists())
        self.assertEqual(self.rv.read_text(), self.original.replace("Подвал", "Локальная правка"))
        self.assertEqual(self.git("status", "--porcelain"), "")

    def test_new_file_collision_blocks_entire_batch(self):
        self.rv.write_text("РВ разработчика\n")
        self.tkp.write_text("ТКП разработчика\n")
        source = self.commit("РВ и ТКП")
        self.switch_to_site()
        self.tkp.write_text("Независимый ТКП сайта\n")
        self.commit("ТКП сайта")
        with self.assertRaisesRegex(ValueError, "Конфликт"):
            stage_import(self.base, source)
        self.assertEqual(self.rv.read_text(), self.original)
        self.assertEqual(self.tkp.read_text(), "Независимый ТКП сайта\n")
        self.assertFalse(REVISION.exists())
        self.assertEqual(self.git("status", "--porcelain"), "")

    def test_matching_source_file_is_not_overwritten(self):
        self.rv.write_text("РВ разработчика\n")
        source = self.commit("РВ разработчика")
        self.switch_to_site()
        self.rv.write_text("РВ разработчика\n")
        self.commit("Уже опубликовано")
        self.assertEqual(stage_import(self.base, source), [self.rv.as_posix()])
        self.assertEqual(REVISION.read_text().strip(), source)

    def test_patch_with_protected_change_rejected_before_writing(self):
        self.rv.write_text("Новая РВ\n")
        protected = Path("web/config.php")
        protected.write_text("Конфигурация сервера\n")
        source = self.commit("Общая правка")
        self.switch_to_site()
        with self.assertRaisesRegex(ValueError, "web/config.php"):
            stage_import(self.base, source)
        self.assertEqual(self.git("status", "--porcelain"), "")

    def test_symlink_and_deletion_are_rejected(self):
        self.rv.unlink()
        deleted = self.commit("Удаление файла")
        self.rv.symlink_to("area.php")
        symlink = self.commit("Символическая ссылка")
        self.switch_to_site()
        for source in (deleted, symlink):
            with self.subTest(source=source):
                with self.assertRaisesRegex(ValueError, "обычных файлов"):
                    stage_import(self.base, source)
                self.assertEqual(self.git("status", "--porcelain"), "")

    def test_overlapping_site_change_prevents_recording_new_revision(self):
        self.rv.write_text(self.original.replace("Исходное", "РВ разработчика"))
        source = self.commit("Изменение разработчика")
        self.switch_to_site()
        self.rv.write_text(self.original.replace("Исходное", "Моя версия"))
        self.commit("Изменение на сайте")
        with self.assertRaisesRegex(ValueError, "Конфликт"):
            stage_import(self.base, source)
        self.assertFalse(REVISION.exists())
