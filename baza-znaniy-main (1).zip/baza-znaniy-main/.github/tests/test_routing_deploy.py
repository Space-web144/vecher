"""Deployment proves limited targets, preflight rejection and restoration on failure."""
import ftplib
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

spec=importlib.util.spec_from_file_location('deploy_routing',Path(__file__).parents[1]/'deploy/deploy-routing.py')
module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)


class FTP:
    def __init__(self, files):
        self.files=dict(files);self.mutations=[];self.fail=None
    def retrbinary(self, command, callback):
        path=command[5:]
        if path not in self.files: raise ftplib.error_perm('550 Missing')
        callback(self.files[path])
    def storbinary(self,command,stream):
        path=command[5:];self.files[path]=stream.read();self.mutations.append(path)
    def rename(self,src,dst):
        if dst==self.fail:
            self.fail=None;raise OSError('simulated publish failure')
        self.files[dst]=self.files.pop(src);self.mutations.append(dst)
    def delete(self,path): del self.files[path]
    def nlst(self,path): return []


class DeploymentTest(unittest.TestCase):
    def setUp(self):
        self.backup=tempfile.TemporaryDirectory();self.addCleanup(self.backup.cleanup)
        self.plan=json.loads(Path('.github/deploy/routing-plan.json').read_text())
        self.before={path: (b'old '+path.encode()) for path in self.plan['files']}
        for path in ('common/catalog_store.py','common/routed_intake.py'):
            self.before.pop(path)
        self.plan['files']={p:module.sha(self.before.get(p)) for p in self.plan['files']}
        self.before.update({'web/data/.htaccess':b'Require all denied',
           'web/data/1c_vk_catalog.json':json.dumps({'schema_version':1,'catalog':'vk','item_count':1,
              'missing_units':0,'items':[{'Код':'VK-1','Наименование':'Сифон','ЕдиницаИзмерения':'шт'}]}).encode(),
           'web/data/1c_base.xlsx':b'never change this', 'web/process.php':b'server PDF converter'})
        self.ftp=FTP(self.before)
        sleeper=patch.object(module.time,'sleep');sleeper.start();self.addCleanup(sleeper.stop)
    def deploy(self): module.deploy(self.ftp,Path(self.backup.name),self.plan)
    def test_only_plan_source_is_published(self):
        self.deploy()
        for path in self.plan['files']: self.assertEqual(self.ftp.files[path],Path(path).read_bytes())
        for path in ('web/data/1c_base.xlsx','web/data/1c_vk_catalog.json','web/process.php'):
            self.assertEqual(self.ftp.files[path],self.before[path])
        self.assertNotIn(module.GATE,self.ftp.files)
        result=json.loads((Path(self.backup.name)/'result.json').read_text())
        self.assertFalse(result['runtime_catalogs_modified'])
    def test_server_edits_rejected_before_any_mutation(self):
        self.ftp.files['web/onec_review.php']=b'changed by owner'
        with self.assertRaisesRegex(RuntimeError,'Unreviewed server changes'): self.deploy()
        self.assertEqual(self.ftp.mutations,[])
    def test_mid_deploy_error_restores_source(self):
        self.ftp.fail='common/web_1c_intake_run.py'
        with self.assertRaises(OSError): self.deploy()
        for path,data in self.before.items(): self.assertEqual(self.ftp.files[path],data)
        self.assertNotIn('common/catalog_store.py',self.ftp.files)
        self.assertNotIn(module.GATE,self.ftp.files)
    def test_runtime_targets_cannot_be_published(self):
        self.plan['files']['web/data/private.json']=None
        with self.assertRaises(ValueError): self.deploy()
        self.assertEqual(self.ftp.mutations,[])
    def test_existing_gate_prevents_overlapping_publish(self):
        self.ftp.files[module.GATE]=b'another run'
        with self.assertRaisesRegex(RuntimeError,'in progress'): self.deploy()
        self.assertEqual(self.ftp.mutations,[])
    def test_unfinished_intakes_block_publication_and_restore_source(self):
        self.ftp.nlst=lambda path:['web/data/uploads/0123456789abcdef_1c_input.json']
        from datetime import datetime,timezone
        self.ftp.sendcmd=lambda cmd:'213 '+datetime.now(timezone.utc).strftime('%Y%m%d%H%M%S')
        with self.assertRaisesRegex(RuntimeError,'still running'): self.deploy()
        for path,data in self.before.items(): self.assertEqual(self.ftp.files[path],data)
        self.assertNotIn(module.GATE,self.ftp.files)


if __name__=='__main__': unittest.main()
