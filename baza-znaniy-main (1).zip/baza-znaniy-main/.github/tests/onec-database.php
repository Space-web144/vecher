<?php
declare(strict_types=1);
// Isolated page fixtures: no production database, credentials or sessions.
$source = dirname(__DIR__, 2) . '/web';
$temporary = sys_get_temp_dir() . '/onec-database-' . bin2hex(random_bytes(8));
mkdir($temporary . '/assets', 0700, true);
function check(bool $condition, string $message): void {
    if (!$condition) throw new RuntimeException($message);
}
function render_catalog(array $query): string {
    global $temporary;
    file_put_contents($temporary . '/case.php', '<?php $_GET=' . var_export($query, true)
        . '; require __DIR__."/onec_database.php";');
    $lines = []; $exit = 0;
    exec(escapeshellarg(PHP_BINARY) . ' ' . escapeshellarg($temporary . '/case.php') . ' 2>&1', $lines, $exit);
    check($exit === 0, 'Page fixture failed: ' . implode("\n", $lines));
    $html = implode("\n", $lines);
    check(strpos($html, 'Warning:') === false, 'Page emitted a PHP warning');
    return $html;
}
try {
    copy($source . '/onec_database.php', $temporary . '/onec_database.php');
    foreach (['admin_guard.php', 'sidebar.php'] as $name) file_put_contents($temporary . '/' . $name, '<?php');
    foreach (['style.css', 'ui.js'] as $name) file_put_contents($temporary . '/assets/' . $name, '');
    file_put_contents($temporary . '/config.php', '<?php define("DB_FILE",__DIR__."/database.xlsx");'
        . 'define("DB_FILE_DUMP_CACHE",__DIR__."/dump.json");');

    // These routes must work even when ventilation's database is unavailable.
    $root = render_catalog([]);
    check(substr_count($root, 'class="btn"') === 2, 'Catalog chooser must contain two buttons');
    check(strpos($root, 'href="onec_database.php?catalog=ventilation">Вентиляция</a>') !== false, 'Ventilation route missing');
    check(strpos($root, 'href="onec_database.php?catalog=vk">ВК</a>') !== false, 'VK route missing');
    check(strpos($root, 'Файл базы') === false && strpos($root, 'data-table') === false, 'Chooser read the ventilation database');
    $vk = render_catalog(['catalog'=>'vk', 'q'=>'Воздуховод', 'page'=>2]);
    check(strpos($vk, 'Номенклатура ВК пока не добавлена.') !== false, 'VK empty state missing');
    check(strpos($vk, 'Файл базы') === false && strpos($vk, 'data-table') === false, 'VK read the ventilation database');
    check(strpos($vk, 'href="onec_database.php">← К разделам базы') !== false, 'Return to chooser missing');
    check(strpos(render_catalog(['catalog'=>['vk']]), 'Выберите раздел') !== false, 'Invalid catalog should show chooser');
    check(strpos(render_catalog(['catalog'=>'ventilation']), 'Файл базы') !== false, 'Ventilation database error lost');

    // A fresh synthetic cache exercises existing groups, search and pagination.
    $items = [];
    for ($i = 1; $i <= 102; $i++) {
        $items[] = ['Код'=>sprintf('OV-%03d', $i), 'Наименование'=>'Позиция вентиляции ' . $i,
            'Категория'=>$i === 1 ? 2 : ($i === 2 ? 3 : 0),
            'Вид'=>$i === 2 ? 'ОТВОД' : '', 'Толщина'=>0.7, 'Сечение'=>'100x200',
            'СечениеКлюч'=>[100,200], 'Длина'=>1000];
    }
    file_put_contents($temporary . '/database.xlsx', 'synthetic database marker');
    file_put_contents($temporary . '/dump.json', json_encode(['schema_version'=>3, 'items'=>$items]));
    $ventilation = render_catalog(['catalog'=>'ventilation']);
    check(strpos($ventilation, 'Всего позиций: 102.') !== false, 'Ventilation positions lost');
    check(strpos($ventilation, 'Воздуховоды (1)') !== false && strpos($ventilation, 'Отводы (1)') !== false, 'Category trees lost');
    check(strpos($ventilation, 'name="catalog" value="ventilation"') !== false, 'Search must retain catalog');
    check(strpos($ventilation, 'catalog=ventilation&amp;page=2') !== false, 'Pagination must retain catalog');
    check(strpos(render_catalog(['catalog'=>'ventilation','page'=>2]), 'OV-102') !== false, 'Second page missing');
    $search = render_catalog(['catalog'=>'ventilation','q'=>'ov-102']);
    check(strpos($search, 'Найдено: 1 из 102.') !== false && strpos($search, 'OV-102') !== false, 'Code search broken');
    check(strpos($search, 'href="onec_database.php?catalog=ventilation">Сбросить') !== false, 'Reset must retain catalog');
    $searchPages = render_catalog(['catalog'=>'ventilation','q'=>'ПОЗИЦИЯ']);
    check(strpos($searchPages, 'catalog=ventilation&amp;page=2&amp;q=') !== false, 'Search pagination lost query or catalog');
    $escaped = render_catalog(['catalog'=>'ventilation','q'=>'<script>alert(1)</script>']);
    check(strpos($escaped, '<script>alert(1)</script>') === false && strpos($escaped, '&lt;script&gt;') !== false, 'Search query must be escaped');
    foreach ([[], ['catalog'=>'vk']] as $query) {
        $html = render_catalog($query);
        check(strpos($html, 'OV-001') === false && strpos($html, 'Позиция вентиляции') === false, 'Ventilation positions leaked into another route');
    }
    mkdir($temporary . '/data');
    $vkItems = [];
    for ($i = 1; $i <= 102; $i++) {
        $vkItems[] = ['Код'=>sprintf('VK-%03d', $i), 'Наименование'=>'Позиция ВК ' . $i,
            'ЕдиницаИзмерения'=>$i === 1 ? null : 'пог. м'];
    }
    $vkItems[0]['Наименование'] = 'Позиция ВК <script>1</script>';
    $vkData = ['schema_version'=>1, 'catalog'=>'vk', 'item_count'=>102, 'missing_units'=>1, 'items'=>$vkItems];
    file_put_contents($temporary . '/data/1c_vk_catalog.json', json_encode($vkData));
    $vk = render_catalog(['catalog'=>'vk']);
    check(strpos($vk, 'Всего позиций: 102.') !== false && strpos($vk, 'VK-001') !== false, 'Loaded VK catalog missing');
    check(strpos($vk, '<th>Единица измерения</th>') !== false && strpos($vk, 'пог. м') !== false, 'VK unit column missing');
    check(strpos($vk, '<script>1</script>') === false && strpos($vk, '&lt;script&gt;1&lt;/script&gt;') !== false, 'VK name must be escaped');
    check(strpos($vk, 'data-label="Единица измерения">—</td>') !== false, 'Missing unit must not be invented');
    check(strpos($vk, 'Воздуховоды (') === false && strpos($vk, 'OV-001') === false, 'Ventilation groups or items leaked into VK');
    check(strpos($vk, 'catalog=vk&amp;page=2') !== false, 'VK pagination lost catalog');
    check(strpos(render_catalog(['catalog'=>'vk','page'=>2]), 'VK-102') !== false, 'VK second page missing');
    $vkSearch = render_catalog(['catalog'=>'vk','q'=>'vk-102']);
    check(strpos($vkSearch, 'Найдено: 1 из 102.') !== false && strpos($vkSearch, 'VK-102') !== false, 'VK search broken');
    check(strpos($vkSearch, 'name="catalog" value="vk"') !== false && strpos($vkSearch, '?catalog=vk">Сбросить') !== false, 'VK search/reset lost catalog');
    check(strpos(render_catalog(['catalog'=>'ventilation']), 'VK-001') === false, 'VK items leaked into ventilation');
    unlink($temporary . '/database.xlsx');
    check(strpos(render_catalog(['catalog'=>'vk']), 'VK-001') !== false, 'VK depends on ventilation database');
    file_put_contents($temporary . '/data/1c_vk_catalog.json', '{}');
    check(strpos(render_catalog(['catalog'=>'vk']), 'Не удалось прочитать номенклатуру ВК') !== false, 'Corrupt VK catalog must report an error');
    echo "PASS: chooser; isolated VK/ventilation; groups/search/pagination; units; escaping; missing/corrupt catalogs\n";
} finally {
    $entries = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($temporary, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST);
    foreach ($entries as $entry) $entry->isDir() ? rmdir($entry->getPathname()) : unlink($entry->getPathname());
    rmdir($temporary);
}
