<?php
declare(strict_types=1);

// Static integration tests, intentionally do not execute the network endpoint.
function cp_assert(bool $value, string $reason): void
{
    if (!$value) {
        fwrite(STDERR, "Clean Papper API: " . $reason . "\n");
        exit(1);
    }
}

$root = dirname(__DIR__, 2);
$api = (string) file_get_contents($root . '/web/clean_papper_api.php');
$lib = (string) file_get_contents($root . '/web/clean_papper_api_lib.php');
$page = (string) file_get_contents($root . '/web/clean_papper.php');
$js = (string) file_get_contents($root . '/web/assets/clean_papper.js');
$worker = (string) file_get_contents($root . '/common/web_clean_papper_api.py');

cp_assert(str_contains($api, "require __DIR__ . '/clean_papper_guard.php';"),
          'API must invoke exact-account authorization before processing');
cp_assert(str_contains($api, "REQUEST_METHOD") && str_contains($api, "'POST'"),
          'API only accepts POST');
cp_assert(str_contains($api, "hash_equals(") && str_contains($api, "clean_papper_csrf"),
          'anti-CSRF token must be verified');
cp_assert(str_contains($api, "clean_papper_last_ping") && str_contains($api, "60"),
          'ping must be rate-limited');
cp_assert(str_contains($lib, "CLEAN_PAPPER_CREDENTIALS_FILE")
          && str_contains($lib, "ANTHROPIC_CREDENTIALS_FILE"),
          'worker must use a server-owned credentials path');
cp_assert(str_contains($lib, 'proc_open(') && str_contains($lib, "web_clean_papper_api.py"),
          'worker must execute fixed server-owned Python code');
cp_assert(str_contains($page, 'name="csrf"') && str_contains($page, 'data-action="ping"'),
          'web panel must offer protected manual connection test');
cp_assert(str_contains($js, "credentials: 'same-origin'"),
          'browser must send session cookie only to same-origin server');
cp_assert(!str_contains($page, 'sk-ant-') && !str_contains($js, 'sk-ant-'),
          'browser assets must not contain API key literals');
cp_assert(str_contains($worker, 'MAX_TEST_TOKENS = 128') && str_contains($worker, 'fallbacks=False'),
          'probe must use a bounded, no-fallback request');

echo "Clean Papper: API authorization, CSRF, worker isolation and UI checks OK\n";
