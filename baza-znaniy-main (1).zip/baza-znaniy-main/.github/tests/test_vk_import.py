import base64
import ftplib
import gzip
import hashlib
import importlib.util
import json
from pathlib import Path
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('import_vk_catalog', ROOT / '.github/deploy/import-vk-catalog.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class FTP:
    def __init__(self, existing=None, protected=True, concurrent=False):
        self.files = {'web/data/.htaccess': b'Require all denied\n' if protected else b'Require all granted\n',
                      'web/data/1c_base.xlsx': b'ventilation database',
                      'web/data/outputs/db_file_dump.json': b'ventilation cache'}
        if existing is not None:
            self.files[module.TARGET] = existing
        self.writes = []
        self.renames = []
        self.concurrent = concurrent

    def retrbinary(self, command, append):
        path = command[5:]
        if path not in self.files:
            raise ftplib.error_perm('550 File not found')
        append(self.files[path])

    def storbinary(self, command, stream):
        path = command[5:]
        self.files[path] = stream.read()
        self.writes.append(path)
        if self.concurrent and path == 'web/data/.in.vk-catalog.json':
            self.files[module.TARGET] = b'concurrent user edit'

    def rename(self, old, new):
        self.renames.append((old, new))
        self.files[new] = self.files.pop(old)

    def delete(self, path):
        del self.files[path]


def catalog():
    return {'schema_version':1, 'catalog':'vk', 'item_count':2, 'missing_units':1,
            'source':{'sha256':'f' * 64}, 'items':[
                {'Код':'VK-1', 'Наименование':'Муфта', 'ЕдиницаИзмерения':'шт'},
                {'Код':'VK-2', 'Наименование':'Муфта', 'ЕдиницаИзмерения':None}]}


def events(data=None, total=1, previous='missing'):
    raw = json.dumps(data if data is not None else catalog(), ensure_ascii=False).encode()
    payload = gzip.compress(raw, mtime=0)
    step = (len(payload) + total - 1) // total
    return [{'inputs':{'payload_sha256':hashlib.sha256(payload).hexdigest(),
                       'expected_previous_sha256':previous, 'chunk_index':str(index),
                       'total_chunks':str(total), 'expected_items':'2',
                       'chunk':base64.b64encode(payload[index*step:(index+1)*step]).decode()}}
            for index in range(total)]


class ImportVKTest(unittest.TestCase):
    def transfer(self, ftp, event):
        with tempfile.TemporaryDirectory() as directory:
            return module.transfer(ftp, event, Path(directory))

    def test_complete_import_and_ventilation_is_unchanged(self):
        ftp = FTP()
        result = self.transfer(ftp, events()[0])
        self.assertTrue(result['complete'])
        actual = json.loads(ftp.files[module.TARGET])
        self.assertEqual(actual['items'], catalog()['items'])
        self.assertEqual(ftp.files['web/data/1c_base.xlsx'], b'ventilation database')
        self.assertEqual(ftp.files['web/data/outputs/db_file_dump.json'], b'ventilation cache')
        self.assertEqual(set(ftp.files), {'web/data/.htaccess', 'web/data/1c_base.xlsx',
                                        'web/data/outputs/db_file_dump.json', module.TARGET})

    def test_out_of_order_chunks_do_not_publish_partial_data(self):
        ftp = FTP()
        first, second = events(total=2)
        self.assertFalse(self.transfer(ftp, second)['complete'])
        self.assertNotIn(module.TARGET, ftp.files)
        self.assertTrue(self.transfer(ftp, first)['complete'])

    def test_repeated_import_is_idempotent(self):
        ftp = FTP()
        event = events()[0]
        self.transfer(ftp, event)
        writes = list(ftp.writes)
        result = self.transfer(ftp, event)
        self.assertTrue(result['idempotent'])
        self.assertEqual(ftp.writes, writes)

    def test_unreviewed_existing_catalog_stops_before_writing(self):
        ftp = FTP(existing=b'previous catalog')
        with self.assertRaisesRegex(RuntimeError, 'changed since review'):
            self.transfer(ftp, events()[0])
        self.assertFalse(ftp.writes)
        self.assertEqual(ftp.files[module.TARGET], b'previous catalog')

    def test_existing_catalog_is_backed_up_when_previous_checksum_matches(self):
        before = b'previous reviewed catalog'
        ftp = FTP(existing=before)
        self.transfer(ftp, events(previous=hashlib.sha256(before).hexdigest())[0])
        self.assertEqual(ftp.files['web/data/.vk-catalog-previous.json'], before)

    def test_checksum_mismatch_does_not_replace_catalog(self):
        event = events()[0]
        event['inputs']['payload_sha256'] = '0' * 64
        ftp = FTP()
        with self.assertRaisesRegex(RuntimeError, 'checksum differs'):
            self.transfer(ftp, event)
        self.assertNotIn(module.TARGET, ftp.files)

    def test_duplicate_code_does_not_replace_catalog(self):
        data = catalog()
        data['items'][1]['Код'] = 'VK-1'
        ftp = FTP()
        with self.assertRaisesRegex(ValueError, 'Duplicate VK code'):
            self.transfer(ftp, events(data)[0])
        self.assertNotIn(module.TARGET, ftp.files)

    def test_count_mismatch_does_not_replace_catalog(self):
        ftp = FTP()
        event = events()[0]
        event['inputs']['expected_items'] = '3'
        with self.assertRaisesRegex(ValueError, 'reviewed import'):
            self.transfer(ftp, event)
        self.assertNotIn(module.TARGET, ftp.files)

    def test_concurrent_edit_is_preserved(self):
        ftp = FTP(concurrent=True)
        with self.assertRaisesRegex(RuntimeError, 'Concurrent VK edit'):
            self.transfer(ftp, events()[0])
        self.assertEqual(ftp.files[module.TARGET], b'concurrent user edit')
        self.assertFalse(any(new == module.TARGET for old,new in ftp.renames))

    def test_runtime_storage_must_be_protected(self):
        ftp = FTP(protected=False)
        with self.assertRaisesRegex(RuntimeError, 'protection'):
            self.transfer(ftp, events()[0])
        self.assertFalse(ftp.writes)

    def test_invalid_input_does_not_write(self):
        for key,value in [('chunk_index','../0'), ('total_chunks','1000'), ('chunk','$(command)'),
                          ('payload_sha256','bad')]:
            event = events()[0]
            event['inputs'][key] = value
            ftp = FTP()
            with self.assertRaises((ValueError, TypeError)):
                self.transfer(ftp, event)
            self.assertFalse(ftp.writes)


if __name__ == '__main__':
    unittest.main()
