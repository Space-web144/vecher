import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

DEPLOY = Path(__file__).resolve().parents[1] / 'deploy'
sys.path.insert(0, str(DEPLOY))
import vps_server as server
import vps_client as client


class ServerChecks(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name) / 'site'
        self.root.mkdir()
        self.state = Path(self.temp.name) / 'state.json'
        self.state.write_text(json.dumps({'commit': 'a' * 40}))
        self.backups = Path(self.temp.name) / 'backups'
        for name, value in [('ROOT', self.root), ('STATE', self.state), ('BACKUPS', self.backups)]:
            p = patch.object(server, name, value)
            p.start()
            self.addCleanup(p.stop)
        self.file = self.root / 'web/page.php'
        self.file.parent.mkdir()
        self.file.write_text('<?php echo 1;')
        self.old = server.blob(self.file)
        self.new_file = Path(self.temp.name) / 'new'
        self.new_file.write_text('<?php echo 2;')
        self.new = server.blob(self.new_file)
        self.plan = {'base': 'a' * 40, 'head': 'b' * 40,
                     'files': [{'path': 'web/page.php', 'before': self.old, 'after': self.new}]}

    def test_protected_paths(self):
        for name in ['../web/index.php', '/web/index.php', 'web/config.php',
                     'web/.auth_credentials.php', 'web/auth_credentials.php',
                     'web/data/test.php', 'program-c/rv/data/test.py',
                     'web/.htaccess', 'web/x/../../config.php', 'web/x\\y.php',
                     'web//page.php', 'web/a\n.php', 'common/secrets/test.py']:
            with self.subTest(name=name):
                self.assertFalse(server.allowed(name))

    def test_drift_blocks_all_writes(self):
        self.file.write_text('<?php echo 99;')
        with self.assertRaisesRegex(ValueError, 'Server changes'):
            server.backup(self.plan)
        self.assertFalse(self.backups.exists())
        self.assertEqual(self.file.read_text(), '<?php echo 99;')
        self.assertEqual(json.loads(self.state.read_text())['commit'], 'a' * 40)

    def test_backup_and_verified_receipt(self):
        folder = Path(server.backup(self.plan))
        self.assertEqual((folder / 'web/page.php').read_bytes(), self.file.read_bytes())
        with self.assertRaises(ValueError):
            server.finish(self.plan)
        self.file.write_bytes(self.new_file.read_bytes())
        server.finish(self.plan)
        self.assertEqual(json.loads(self.state.read_text())['commit'], 'b' * 40)

    def test_interrupted_transfer_can_be_retried(self):
        self.file.write_bytes(self.new_file.read_bytes())
        self.assertEqual(len(server.check(self.plan)), 1)

    def test_existing_unknown_file_is_not_replaced_by_addition(self):
        self.plan['files'][0]['before'] = None
        with self.assertRaises(ValueError):
            server.check(self.plan)

    def test_symlink_parent_and_leaf_rejected(self):
        outside = Path(self.temp.name) / 'outside'
        outside.mkdir()
        (self.file.parent / 'linked').symlink_to(outside, target_is_directory=True)
        with self.assertRaisesRegex(ValueError, 'Symlink'):
            server.target('web/linked/page.php')
        self.file.unlink()
        self.file.symlink_to(self.new_file)
        with self.assertRaisesRegex(ValueError, 'Symlink'):
            server.check(self.plan)

    def test_stale_plan_cannot_advance_state(self):
        self.plan['base'] = 'c' * 40
        with self.assertRaisesRegex(ValueError, 'baseline changed'):
            server.finish(self.plan)


class GitDelta(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.repo = Path(self.temp.name) / 'repo'
        self.repo.mkdir()
        self.current = Path.cwd()
        import os
        os.chdir(self.repo)
        self.addCleanup(os.chdir, self.current)
        subprocess.run(['git', 'init', '-q'], check=True)
        client.git('config', 'user.name', 'Test')
        client.git('config', 'user.email', 'test@example.invalid')
        self.write('web/page.php', 'old')
        self.write('web/config.php', 'private server paths')
        self.write('web/deleted.php', 'keep on server')
        self.base = self.commit()

    def write(self, name, value):
        p = self.repo / name
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(value)

    def commit(self):
        client.git('add', '.')
        client.git('commit', '-qm', 'test')
        return client.git('rev-parse', 'HEAD').decode().strip()

    def test_delta_spans_multiple_commits_and_skips_secrets(self):
        self.write('web/page.php', 'new')
        self.commit()
        self.write('web/config.php', 'old hosting paths')
        self.write('web/data/user.php', 'private')
        self.write('common/new file.py', 'x = 1')
        (self.repo / 'web/deleted.php').unlink()
        head = self.commit()
        plan, skipped, retained = client.build_plan(self.base, head, Path(self.temp.name) / 'stage')
        self.assertEqual({f['path'] for f in plan['files']}, {'web/page.php', 'common/new file.py'})
        self.assertEqual(set(skipped), {'web/config.php', 'web/data/user.php'})
        self.assertEqual(retained, ['web/deleted.php'])
        self.assertEqual(plan['files'][0]['before'], None)

    def test_ventspec_test_files_are_ci_only_but_runtime_is_deployed(self):
        self.write('program-a/tests/test_spec_agent.py', 'old test')
        self.write('program-a/tests/test_spec_pipeline.py', 'old test')
        baseline = self.commit()
        self.write('program-a/tests/test_spec_agent.py', 'updated test')
        self.write('program-a/tests/test_spec_pipeline.py', 'updated test')
        self.write('program-a/tests/test_new.py', 'new test')
        self.write('program-a/pdf_to_spec.py', 'x = 1')
        self.write('web/status.php', '<?php echo 1;')
        head = self.commit()
        folder = Path(self.temp.name) / 'stage'
        plan, skipped, retained = client.build_plan(baseline, head, folder)
        self.assertEqual({f['path'] for f in plan['files']},
                         {'program-a/pdf_to_spec.py', 'web/status.php'})
        self.assertEqual(set(skipped), {'program-a/tests/test_spec_agent.py',
                                        'program-a/tests/test_spec_pipeline.py',
                                        'program-a/tests/test_new.py'})
        self.assertFalse((folder / 'program-a/tests').exists())
        self.assertEqual(retained, [])

    def test_symlink_is_rejected(self):
        (self.repo / 'web/link.php').symlink_to('/etc/passwd')
        head = self.commit()
        with self.assertRaisesRegex(ValueError, 'Symlinks'):
            client.build_plan(self.base, head, Path(self.temp.name) / 'stage')


if __name__ == '__main__':
    unittest.main()
