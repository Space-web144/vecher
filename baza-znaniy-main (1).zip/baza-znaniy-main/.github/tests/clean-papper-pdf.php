<?php
declare(strict_types=1);

function cp_pdf_assert(bool $check, string $reason): void
{
    if (!$check) {
        fwrite(STDERR, "Clean Papper PDF: " . $reason . "\n");
        exit(1);
    }
}
$root = dirname(__DIR__,2);
$endpoint = (string) file_get_contents($root . '/web/clean_papper_pdf.php');
$lib = (string) file_get_contents($root . '/web/clean_papper_pdf_lib.php');
$page = (string) file_get_contents($root . '/web/clean_papper.php');
$js = (string) file_get_contents($root . '/web/assets/clean_papper_drawing.js');
$worker = (string) file_get_contents($root . '/common/web_clean_papper_pdf.py');

cp_pdf_assert(str_contains($endpoint, "require __DIR__ . '/clean_papper_guard.php';"), 'missing private authorization');
cp_pdf_assert(str_contains($endpoint, 'REQUEST_METHOD') && str_contains($endpoint, "'POST'"), 'POST required');
cp_pdf_assert(str_contains($endpoint, 'hash_equals('), 'CSRF comparison missing');
cp_pdf_assert(str_contains($endpoint, 'post_max_size') && str_contains($endpoint, 'CONTENT_LENGTH'),
              'request size must be validated before CSRF');
cp_pdf_assert(str_contains($endpoint, 'UPLOAD_ERR_INI_SIZE'),
              'PHP upload limit must be explained');
cp_pdf_assert(str_contains($endpoint, "=== 'diagnostic'"),
              'diagnostic branch must work without a file');
cp_pdf_assert(str_contains($endpoint, 'is_uploaded_file('), 'upload provenance check missing');
cp_pdf_assert(str_contains($endpoint, '%PDF-'), 'PDF signature check missing');
cp_pdf_assert(str_contains($endpoint, "vision_consent"), 'server opt-in missing');
cp_pdf_assert(str_contains($endpoint, "clean_papper_last_vision"), 'paid request cooldown missing');
cp_pdf_assert(str_contains($lib, "web_clean_papper_pdf.py"), 'fixed worker missing');
cp_pdf_assert(str_contains($lib, 'proc_open('), 'bounded runner missing');
cp_pdf_assert(str_contains($page, 'id="cp-drawing-form"'), 'drawing form missing');
cp_pdf_assert(str_contains($page, 'id="cp-diagnostic-run"'), 'diagnostics button missing');
cp_pdf_assert(str_contains($page, 'id="cp-album-run"') && str_contains($js, "submit('album')"),
              'album entry point missing');
cp_pdf_assert(str_contains($endpoint, "=== 'album'") && str_contains($lib, "'modules.pdf.project_album'"),
              'album worker routing missing');
cp_pdf_assert(str_contains($page, '>Обработать альбом</button>'),
              'simplified primary album action missing');
cp_pdf_assert(str_contains($page, 'id="cp-advanced-tools"') &&
              str_contains($page, 'id="cp-technical-results"'),
              'advanced controls and detailed results must be collapsible');
cp_pdf_assert(str_contains($page, 'id="cp-album-suggested"') &&
              str_contains($js, "openPlan.addEventListener('click'"),
              'automatic source-plan review suggestion missing');
cp_pdf_assert(str_contains($page, 'data-cp-step="processing"') &&
              str_contains($page, 'id="cp-upload-progress"') &&
              str_contains($page, 'id="cp-selected-file"'),
              'project upload workflow must expose stage, file and progress');
cp_pdf_assert(str_contains($page, 'id="cp-album-filter"') &&
              str_contains($page, 'id="cp-album-search"') &&
              str_contains($page, 'id="cp-album-kpis"') &&
              str_contains($page, 'id="cp-album-visible-count"'),
              'project results must offer overview, search and page filter');
cp_pdf_assert(str_contains($js, "function renderAlbumPages()") &&
              str_contains($js, "function openAlbumPage(item)") &&
              str_contains($js, "item.pdf_page") &&
              str_contains($js, "button.addEventListener('click'"),
              'selecting a sheet must launch a real preview');
cp_pdf_assert(str_contains($js, "uploadProgress.removeAttribute('value')") &&
              str_contains($js, "activeAlbum = null;"),
              'progress must be honest and old file data reset');
cp_pdf_assert(str_contains($js, "page.dispatchEvent(new Event('change'"),
              'review suggestion must change the preview page');
cp_pdf_assert(substr_count($page, 'id="cp-drawing-page"') === 1 &&
              substr_count($page, 'id="cp-diagnostic-run"') === 1 &&
              substr_count($page, 'id="cp-vision-run"') === 1,
              'original manual review controls must remain available exactly once');
cp_pdf_assert(is_file($root . '/common/clean_papper_album_worker/modules/pdf/project_album.py'),
              'bundled album worker missing');
cp_pdf_assert(str_contains($worker, 'def diagnostic():'), 'Python PDF smoke test missing');
cp_pdf_assert(str_contains($lib, "php_post_max"), 'diagnostics should explain upload limits');
cp_pdf_assert(str_contains($page, 'name="vision_consent"'), 'consent field missing');
cp_pdf_assert(str_contains($js, "textContent"), 'safe DOM output missing');
cp_pdf_assert(!str_contains($js, "innerHTML"), 'must not render AI HTML');
cp_pdf_assert(str_contains($worker, 'MAX_OUTPUT_TOKENS = 1500'), 'AI cap missing');
cp_pdf_assert(str_contains($worker, 'max_requests=1'), 'exactly one paid request required');
cp_pdf_assert(str_contains($worker, 'fallbacks=False'), 'fallback requests forbidden');
cp_pdf_assert(!str_contains($page, 'sk-ant-'), 'API key exposed in page');

cp_pdf_assert(str_contains($endpoint, "=== 'specification'") && str_contains($endpoint, 'source_pdf_sha256') &&
              str_contains($lib, 'web_clean_papper_specification.py'), 'fixed specification route and source hash missing');
cp_pdf_assert(str_contains($page, 'id="cp-spec-first"') && str_contains($page, 'id="cp-spec-last"') &&
              str_contains($js, "runSpecification('convert')") && str_contains($js, "runSpecification('extract')"),
              'specification controls are missing');
cp_pdf_assert(str_contains($page, 'id="cp-project-profile"') &&
              str_contains($page, 'id="cp-project-profile-download"') &&
              str_contains($js, 'showProjectProfile(data)') &&
              str_contains($js, 'clean-papper-project-profile.json'),
              'project compatibility profile and source-bound download missing');
cp_pdf_assert(str_contains($page, 'id="cp-project-text-recovery"') &&
              str_contains($js, 'text_recovery_summary') &&
              str_contains($js, 'aligned_columns_and_sequential_footer'),
              'cross-project text recovery and continuation diagnostics missing');
cp_pdf_assert(str_contains($page, 'id="cp-project-rules"') &&
              str_contains($page, 'id="cp-rules-download"') &&
              str_contains($js, 'showProjectRules(data)') &&
              str_contains($js, 'clean-papper-project-rules.json') &&
              str_contains($js, 'double_count_risk'),
              'documentary allowance diagnostics and source-bound export missing');
cp_pdf_assert(str_contains($js, 'showSpatialInventory(info)') &&
              str_contains($js, 'clean-papper-spatial-page-') &&
              str_contains($js, 'legacy_detector_rotation_review_required'),
              'full spatial inventory diagnostic and coordinate warning missing');
cp_pdf_assert(str_contains($page, 'id="cp-processing-monitor"') &&
              str_contains($js, 'function watchPdfWorker(') &&
              str_contains($js, 'monitorBar.removeAttribute'), 'real processing monitor missing');
cp_pdf_assert(str_contains($endpoint, 'cp_pdf_status_token') && str_contains($endpoint, 'hash_equals($owned, $token)') &&
              str_contains($lib, "proc_get_status(") && str_contains($lib, "lastHeartbeat"), 'worker heartbeat must be session-bound and server-driven');
echo "Clean Papper: PDF upload security and opt-in checks OK\n";
