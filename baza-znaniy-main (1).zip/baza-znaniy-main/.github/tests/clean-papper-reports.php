<?php
declare(strict_types=1);

function cp_reports_expect(bool $value, string $message): void
{
    if (!$value) {
        fwrite(STDERR, "Clean Papper reports: " . $message . "\n");
        exit(1);
    }
}
$root = dirname(__DIR__, 2);
$page = (string) file_get_contents($root . '/web/clean_papper.php');
$endpoint = (string) file_get_contents($root . '/web/clean_papper_report.php');
$frontend = (string) file_get_contents($root . '/web/assets/clean_papper_reports.js');
$drawing = (string) file_get_contents($root . '/web/assets/clean_papper_drawing.js');
$worker = (string) file_get_contents($root . '/common/clean_papper_reports.py');
$vectorJS = (string) file_get_contents($root . '/web/assets/clean_papper_vector.js');
$vectorPY = (string) file_get_contents($root . '/common/clean_papper_vector.py');
$pdfEngine = (string) file_get_contents($root . '/common/web_clean_papper_pdf.py');
$ductsJS = (string) file_get_contents($root . '/web/assets/clean_papper_ducts.js');
$ductsPY = (string) file_get_contents($root . '/common/clean_papper_ducts.py');
$tracesPY = (string) file_get_contents($root . '/common/clean_papper_traces.py');
$samplingPY = (string) file_get_contents($root . '/common/clean_papper_sampling.py');
$profilePY = (string) file_get_contents($root . '/common/clean_papper_profile.py');
$profileJS = (string) file_get_contents($root . '/web/assets/clean_papper_profile.js');
$pdfLib = (string) file_get_contents($root . '/web/clean_papper_pdf_lib.php');

cp_reports_expect(str_contains($endpoint, "require __DIR__ . '/clean_papper_guard.php';"),
    'admin authorization must be first');
cp_reports_expect(str_contains($endpoint, "hash_equals(") && str_contains($endpoint, "clean_papper_csrf"),
    'CSRF token required');
cp_reports_expect(str_contains($endpoint, "'clean-papper.evidence.v1'"),
    'structured report schema must be checked');
cp_reports_expect(str_contains($endpoint, '180000'),
    'payload size limit required');
cp_reports_expect(str_contains($endpoint, 'session_write_close()'),
    'session should be released during export');
cp_reports_expect(str_contains($endpoint, 'proc_open('),
    'fixed local XLSX worker must be used');
cp_reports_expect(str_contains($endpoint, 'spreadsheetml.sheet'),
    'XLSX MIME must be returned');
cp_reports_expect(str_contains($page, 'id="cp-profile-json"') &&
    str_contains($page, 'id="cp-profile-apply"') &&
    str_contains($page, 'id="cp-diagnostics"'),
    'single workspace with album profile and diagnostics required');
cp_reports_expect(str_contains($samplingPY, 'sample_drawings(') &&
    str_contains($samplingPY, 'colored_paths_in_region'),
    'whole-region sampling and colors must be inventoried');
cp_reports_expect(str_contains($profilePY, 'normalized_profile(') &&
    str_contains($profileJS, 'clean-papper:profile-changed'),
    'per-album profile must be validated and invalidate preview');
cp_reports_expect(str_contains($pdfEngine, 'drawing_inventory') &&
    str_contains($pdfLib, "'--profile-json'"),
    'worker must accept profile and return full-region inventory');
cp_reports_expect(str_contains($page, 'id="cp-duct-overlay"') &&
    str_contains($page, 'id="cp-duct-candidates"'), 'stage10 overlay missing');
cp_reports_expect(str_contains($ductsJS, 'clean-papper:duct-review') &&
    str_contains($ductsJS, 'manual_color_hypothesis_unverified'),
    'color-to-system assignment must be manual and tentative');
cp_reports_expect(str_contains($ductsPY, 'rectangular_wall_pair') &&
    str_contains($ductsPY, 'round_dashed_axis_with_walls'),
    'stage10 geometry algorithms missing');
cp_reports_expect(str_contains($page, 'id="cp-duct-method"') &&
    str_contains($page, 'id="cp-duct-filter"'),
    'stage 10.2 must provide method and color filters');
cp_reports_expect(str_contains($tracesPY, 'extract_trace_network(') &&
    str_contains($tracesPY, 'physical_length_m'),
    'colored trace topology must never output physical quantities');
cp_reports_expect(str_contains($pdfEngine, 'extract_trace_network(') &&
    str_contains($frontend, 'cleanTraceNetwork('),
    'stage 10.2 geometric evidence must reach JSON exports');
cp_reports_expect(str_contains($worker, '"Цветные трассы"') &&
    str_contains($worker, '"Пространственные группы"'),
    'stage 10.2 evidence sheets required');
cp_reports_expect(str_contains($pdfEngine, 'extract_duct_geometry('),
    'PDF engine must call duct geometric classifier');
cp_reports_expect(str_contains($page, 'id="cp-vector-overlay"') &&
    str_contains($page, 'id="cp-vector-calibrate-mode"'), 'PDF overlay and scale controls required');
cp_reports_expect(str_contains($vectorJS, 'clean-papper:vector-review') &&
    str_contains($vectorJS, 'manual_link_unverified'),
    'manual links must stay unverified');
cp_reports_expect(str_contains($pdfEngine, 'extract_vector_candidates('),
    'PDF extractor must include path source IDs');
cp_reports_expect(str_contains($vectorPY, 'physical_length_m') &&
    str_contains($vectorPY, 'None'), 'no projected PDF distance may become approved length');
cp_reports_expect(str_contains($page, 'id="cp-report-json"') &&
    str_contains($page, 'id="cp-report-excel"'),
    'two real report buttons required');
cp_reports_expect(str_contains($drawing, "notifyReport('vision'"),
    'structured AI evidence needs to be passed to report UI');
cp_reports_expect(str_contains($frontend, 'JSON.stringify(report, null, 2)'),
    'machine readable JSON export required');
cp_reports_expect(str_contains($frontend, "report = createReport(event.detail"),
    'report must be built from latest model response');
cp_reports_expect(str_contains($frontend, "credentials: 'same-origin'"),
    'XLSX export must stay on same origin');
cp_reports_expect(!str_contains($frontend, 'innerHTML'),
    'never render model text as HTML');
cp_reports_expect(str_contains($worker, 'quantities_confirmed') === false,
    'no quantities may be implied as confirmed');
cp_reports_expect(str_contains($worker, 'safe_text('),
    'excel text requires formula-injection protection');

echo "Clean Papper: private JSON and XLSX report guards OK\n";
