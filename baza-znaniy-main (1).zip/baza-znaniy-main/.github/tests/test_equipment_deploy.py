"""The limited publisher must preserve foreign edits before its first write."""
import copy
import ftplib
import importlib.util
import io
from pathlib import Path
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[2]
spec=importlib.util.spec_from_file_location('equipment_deploy',ROOT/'.github/deploy/deploy-equipment.py')
deploy=importlib.util.module_from_spec(spec);spec.loader.exec_module(deploy)


class FakeFTP:
    def __init__(self,data):self.data=data;self.writes=[]
    def retrbinary(self,cmd,callback):
        p=cmd[5:]
        if p not in self.data:raise ftplib.error_perm('550 missing')
        callback(self.data[p])
    def storbinary(self,cmd,stream):
        self.writes.append(cmd[5:]);self.data[cmd[5:]]=stream.read()
    def rename(self,src,dst):self.data[dst]=self.data.pop(src)


class EquipmentDeployTests(unittest.TestCase):
    def fixture(self):
        data={p:('old:'+p).encode() for p in deploy.FILES if not p.endswith('equipment_pipeline.py')}
        data['foreign.php']=b'foreign server source'
        plan={'files':{p:deploy.digest(data.get(p)) for p in deploy.FILES},
              'preserve':{'foreign.php':deploy.digest(data['foreign.php'])}}
        return FakeFTP(data),plan

    def test_exact_whitelist_and_readback(self):
        ftp,plan=self.fixture()
        with tempfile.TemporaryDirectory() as tmp:deploy.deploy(ftp,Path(tmp),plan)
        self.assertEqual(len(ftp.writes),4)
        for p in deploy.FILES:self.assertEqual(ftp.data[p],Path(p).read_bytes())
        self.assertEqual(ftp.data['foreign.php'],b'foreign server source')
        ftp.writes=[]
        with tempfile.TemporaryDirectory() as tmp:deploy.deploy(ftp,Path(tmp),plan)
        self.assertEqual(ftp.writes,[])

    def test_unknown_target_prevents_any_write(self):
        ftp,plan=self.fixture();ftp.data[deploy.FILES[0]]=b'new server edit'
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(RuntimeError):deploy.deploy(ftp,Path(tmp),plan)
        self.assertEqual(ftp.writes,[])

    def test_protected_source_edit_prevents_any_write(self):
        ftp,plan=self.fixture();ftp.data['foreign.php']=b'changed'
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(RuntimeError):deploy.deploy(ftp,Path(tmp),plan)
        self.assertEqual(ftp.writes,[])

    def test_concurrent_edit_prevents_replacement(self):
        ftp,plan=self.fixture();original=ftp.retrbinary;reads=[]
        def read(cmd,callback):
            reads.append(cmd)
            if reads.count('RETR '+deploy.FILES[0])==2:
                ftp.data[deploy.FILES[0]]=b'concurrent edit'
            original(cmd,callback)
        ftp.retrbinary=read
        with tempfile.TemporaryDirectory() as tmp:
            with self.assertRaises(RuntimeError):deploy.deploy(ftp,Path(tmp),plan)
        self.assertEqual(ftp.writes,[])


if __name__=='__main__':unittest.main()
