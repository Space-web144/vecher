<?php
declare(strict_types=1);
// Temporary accounts only. No production sessions or credentials are used.
$temporary = sys_get_temp_dir() . '/departments-' . bin2hex(random_bytes(8));
mkdir($temporary, 0700);
define('AUTH_CREDENTIALS_FILE', $temporary . '/accounts.php');
define('OUTPUT_DIR', $temporary);
define('KB_PLAN_VIEWERS', ['planner', 'grigorian']);
session_start();
require_once dirname(__DIR__, 2) . '/web/structure_lib.php';

function check(bool $value, string $message): void {
    if (!$value) throw new RuntimeException($message);
}
function account(string $login, ?string $profile, string $role = ROLE_USER): void {
    $record = ['login'=>$login, 'password_hash'=>'fixture-only', 'role'=>$role];
    if ($profile !== null) $record['department'] = $profile;
    save_users([$record]);
    $_SESSION = ['kb_user'=>$login, 'kb_role'=>$role];
    $_GET = []; $_POST = [];
}
function expect_department_scope(?string $department): void {
    foreach (kb_structure_all() as $module) {
        $expected = in_array($department, ['BA','KZ','SK'], true) ? $module['id'] === 'alfik'
            : empty($module['private']) && (empty($module['departments'])
                || ($department !== null && in_array($department, $module['departments'], true)));
        check(kb_can_open_module($module) === $expected, 'Wrong scope: ' . $module['id']);
    }
}

try {
    check(department_code('ДР') === 'DR' && department_code('Дирекция') === 'DR', 'Director aliases');
    check(department_code('НО') === 'NO' && department_code('Начальник отдела') === 'NO', 'Head aliases');
    check(department_code('DIR') === 'DIR' && department_label('DIR') === 'ГПР', 'GPR code must stay distinct');

    check(department_code('ba') === 'BA' && department_label('BA') === 'BA', 'BA missing from departments');
    foreach (['employee_PTO', 'planner.g_CO'] as $login) {
        account($login, 'BA');
        check(current_department() === 'BA' && kb_alfik_only(), 'BA lost restricted profile');
        check(!user_has_all_tools() && !kb_can_see_plans($login), 'BA escaped through planner exception');
        expect_department_scope('BA');
        foreach (['agent.php', 'agent_api.php', 'agent_file.php'] as $file) {
            check(kb_can_open_page($file), 'BA lost assistant endpoint: ' . $file);
        }
        foreach (['index.php', 'docs.php', 'roadmap.php', 'ventspec.php', 'area.php', 'equipment.php',
                  'verrata.php', 'rv.php', 'tkp_customer.php', 'process.php', 'process_pdf.php',
                  'status.php', 'download.php', 'admin_users.php', 'agent_log.php', 'doc_file.php', 'unknown.php'] as $file) {
            check(!kb_can_open_page($file), 'BA gained another page: ' . $file);
        }
        check(!kb_can_open_module(['id'=>'another_shared_tool','departments'=>[]]), 'BA gained future shared tools');
        check(kb_can_open_module(['id'=>'alfik','departments'=>[]], $login, ROLE_USER), 'BA explicit-login lookup failed');
    }

    foreach (['KZ'=>'Казначейство', 'SK'=>'Секретариат'] as $department=>$label) {
        check(department_label($department) === $label && department_code($label) === $department, 'Missing department label');
        foreach (['employee_PTO','planner.g_CO'] as $login) {
            account($login, $department);
            check(current_department() === $department && kb_limited_department() === $department, 'Restricted department not resolved');
            check(!kb_alfik_only(), 'KZ/SK lost documentation through BA policy');
            check(!user_has_all_tools() && !kb_can_see_plans($login), 'Restricted department gained planner rights');
            expect_department_scope($department);
            foreach (['agent.php','agent_api.php','agent_file.php','docs.php','doc_file.php'] as $file) {
                check(kb_can_open_page($file), 'Common endpoint denied: ' . $file);
            }
            foreach (['index.php','roadmap.php','rv.php','tkp_customer.php','ventspec.php','equipment.php',
                      'area.php','verrata.php','process.php','process_pdf.php','status.php','download.php',
                      'admin_users.php','agent_log.php','unknown.php'] as $file) {
                check(!kb_can_open_page($file), 'Restricted department gained another page: ' . $file);
            }
            check(!kb_can_open_module(['id'=>'future_shared_tool','departments'=>[]]), 'Future tool was granted implicitly');
        }
    }

    foreach (['director_PTO', 'planner.g_DR'] as $login) {
        account($login, 'DR');
        check(user_has_all_tools(), 'DR lost the tools grant');
        foreach (kb_structure_all() as $module) {
            foreach ($module['tools'] as $tool) {
                check(kb_can_open_page((string) parse_url($tool['href'], PHP_URL_PATH)), 'DR lost tool: ' . $tool['href']);
            }
        }
        check(!is_admin_tier_role((string) $_SESSION['kb_role']), 'DR became administrator');
        check(!kb_can_see_plans($login), 'DR gained management through legacy planner list');
        check(!kb_can_open_module(['private'=>true]), 'DR gained private administration module');
    }

    foreach (array_keys(KB_DEPARTMENT_NAMES) as $department) {
        if (in_array($department, ['DR','NO'], true)) continue;
        account('head_' . strtolower($department), 'NO');
        check(current_department_profile() === 'NO', 'NO profile was lost');
        check(current_department() === $department, 'NO suffix was not resolved');
        check(department_of_login('head_' . strtolower($department)) === $department, 'Other-login department differs');
        check(user_department_profile(load_users()[0]) === 'NO', 'Stored profile was replaced');
        check(user_department(load_users()[0]) === $department, 'Business code cannot see the head department');
        check(!user_has_all_tools(), 'NO gained global tools');
        expect_department_scope($department);
    }

    foreach (['BY'=>'BUH', 'MTO'=>'OMTS', 'VP'=>'RN', 'UR'=>'YUR', 'KD'=>'OK', 'PTO'=>'PTO'] as $suffix=>$department) {
        foreach ([$suffix, strtolower($suffix)] as $spelling) {
            $login = 'head_' . $spelling;
            account($login, 'NO');
            check(current_department_profile() === 'NO', 'Alias replaced the NO profile');
            check(current_department() === $department, 'Wrong NO alias: ' . $spelling);
            check(department_of_login($login) === $department, 'Wrong external lookup for NO alias');
            check(department_assignment_error($login, 'NO') === null, 'NO alias rejected by account form');
            check(!user_has_all_tools() && !is_admin_tier_role((string) $_SESSION['kb_role']), 'NO alias granted extra rights');
            expect_department_scope($department);
        }
    }

    account('grigorian.g_CO', 'NO');
    check(kb_can_open_page('rv.php') && kb_can_open_page('tkp_customer.php') && kb_can_open_page('area.php'), 'CO head lost tools');
    check(!kb_can_open_page('ventspec.php') && !kb_can_open_page('equipment.php'), 'CO head received PTO-only tools');
    check(!kb_can_see_plans('grigorian.g_CO'), 'NO escaped department through surname exception');
    check(!kb_can_see_plans('grigorian.g_co'), 'Login case bypassed NO restrictions');
    $_GET = $_POST = ['department'=>'DR','role'=>'mainadmin'];
    check(current_department() === 'CO' && !user_has_all_tools(), 'Client parameters changed permissions');
    $_POST = ['format'=>'ventspec'];
    check(kb_spec_target_page('process_pdf.php') === 'ventspec.php', 'Wrong shared handler target');
    check(!kb_can_open_page(kb_spec_target_page('process_pdf.php')), 'CO head can run VentSpec through shared handler');
    $_POST = ['format'=>'area'];
    check(kb_can_open_page(kb_spec_target_page('process_pdf.php')), 'CO head cannot convert for Area');

    foreach (['head', 'head_UNKNOWN', 'head_DR', 'head_NO', 'head_ДР', 'head_'] as $login) {
        account($login, 'NO');
        check(department_assignment_error($login, 'NO') !== null, 'Invalid head assignment accepted');
        check(current_department() === null && !user_has_all_tools(), 'Invalid head escalated access');
        expect_department_scope(null);
    }
    check(head_department_from_login('head_ЦО') === 'CO', 'Cyrillic department alias');
    check(department_assignment_error('grigorian.g_CO', 'NO') === null, 'Valid example rejected');

    account('employee_PTO', 'CO');
    check(current_department() === 'CO', 'Regular stored department lost precedence');
    expect_department_scope('CO');
    account('legacy_PTO', null);
    check(current_department() === 'PTO', 'Legacy login fallback broken');

    // Already-open sessions observe a server-side account change.
    account('head_CO', 'CO');
    check(current_department() === 'CO', 'Initial session department');
    $accounts = load_users(); $accounts[0]['department'] = 'DR'; save_users($accounts);
    check(current_department() === 'DR' && user_has_all_tools(), 'Open session did not gain DR tools');
    $accounts[0]['department'] = 'NO'; save_users($accounts);
    check(current_department() === 'CO' && current_department_profile() === 'NO', 'Open session did not resolve NO');
    check(!kb_can_open_page('ventspec.php'), 'Stale DR grant survived profile change');

    foreach ([ROLE_ADMIN, ROLE_MAINADMIN] as $role) {
        account('administrator_BA', 'BA', $role);
        check(!kb_alfik_only() && kb_can_open_page('ventspec.php'), 'BA overrode separately assigned administrative role');
        account('head_CO', 'NO', $role);
        check(is_admin_tier_role($role), 'Separately assigned admin role was removed');
        check(kb_can_see_plans('head_CO'), 'Role upgrade lost management rights');
        foreach (kb_structure_all() as $module) check(kb_can_open_module($module), 'Role upgrade did not apply');
    }
    account('planner.g_CO', 'CO');
    check(kb_can_see_plans('planner.g_CO'), 'Regular legacy planner changed');
    foreach (kb_structure_all() as $module) check(kb_can_open_module($module), 'Regular planner scope changed');

    foreach (array_merge(array_keys(KB_DEPARTMENT_NAMES), [null]) as $profile) {
        account('employee_CO', $profile);
        check(kb_can_open_page('developer_feedback.php'), 'Developer form must be available to all profiles');
        check(!kb_can_open_page('admin_developer_feedback.php'), 'Employee can access developer inbox');
    }
    account('another_admin', 'PTO', ROLE_MAINADMIN);
    check(!kb_can_open_page('admin_developer_feedback.php'), 'Unaddressed administrator can access inbox');
    account('veryhardlogin', 'BA');
    check(kb_can_open_page('admin_developer_feedback.php'), 'Recipient cannot access inbox');
    check(!kb_can_open_page('admin_users.php'), 'Inbox access granted unrelated administration rights');
    $_SESSION = [];
    check(!kb_can_open_page('developer_feedback.php') && !kb_can_open_page('admin_developer_feedback.php'), 'Guest can access developer feedback');

    echo "PASS: KZ/SK assistant+documentation; BA assistant-only routes; DR tools/user role; NO scope for all departments; aliases; unknown suffixes; shared handlers; session updates; independent admin roles\n";
} finally {
    session_write_close();
    foreach (glob($temporary . '/*') ?: [] as $file) unlink($file);
    rmdir($temporary);
}
