<?php
declare(strict_types=1);

$credentials = tempnam(sys_get_temp_dir(), 'alfik-users-');
define('AUTH_CREDENTIALS_FILE', $credentials);
define('KB_PLAN_VIEWERS', ['planner']);
file_put_contents($credentials, "<?php return [];\n");
session_start();

require_once dirname(__DIR__, 2) . '/web/alfik_context_lib.php';

function check(bool $ok, string $message): void
{
    if (!$ok) {
        throw new RuntimeException($message);
    }
}

function account(string $department = '', string $role = ROLE_USER, string $login = 'employee'): void
{
    $_SESSION = [
        'kb_user' => $login,
        'kb_role' => $role,
        'kb_dept' => $department !== '' ? $department : null,
        'kb_dept_for' => $login,
    ];
}

try {
    $_SESSION = [];
    check(alfik_session_context() === null, 'Guest received a context');

    foreach (array_keys(KB_DEPARTMENT_NAMES) as $department) {
        account($department, ROLE_USER, $department === 'NO' ? 'employee_CO' : 'employee');
        $context = alfik_session_context();
        check($context['department']['code'] === ($department === 'NO' ? 'CO' : $department), 'Wrong department');
        check(!$context['permissions']['manageUsers'], 'Regular employee has admin rights');
        $expected = [];
        foreach (kb_structure_all() as $module) {
            if (kb_can_open_module($module)) {
                $expected[] = $module['id'];
            }
        }
        check(array_column($context['modules'], 'id') === $expected, 'Module permissions differ from site');
        foreach ($context['tools'] as $tool) {
            check(kb_can_open_page((string) parse_url($tool['href'], PHP_URL_PATH)), 'Forbidden tool in context');
        }
    }

    account('PTO');
    $pto = alfik_session_context();
    $hrefs = array_column($pto['tools'], 'href');
    check(in_array('ventspec.php', $hrefs, true), 'PTO lost VentSpec');
    check(!in_array('rv.php', $hrefs, true), 'PTO received CO tool');
    $_GET = ['department' => 'CO', 'role' => 'mainadmin'];
    $_POST = $_GET;
    check(alfik_session_context() === $pto, 'Client parameters changed permissions');

    account('CO');
    $hrefs = array_column(alfik_session_context()['tools'], 'href');
    check(in_array('area.php?department=co', $hrefs, true), 'CO area mode was lost');
    check(!in_array('ventspec.php', $hrefs, true), 'CO received PTO-only tool');

    foreach (['', 'UNKNOWN'] as $department) {
        account($department, ROLE_USER, $department === 'NO' ? 'employee_CO' : 'employee');
        $context = alfik_session_context();
        foreach ($context['modules'] as $entry) {
            foreach (kb_structure_all() as $module) {
                if ($module['id'] === $entry['id']) {
                    check(empty($module['departments']) && empty($module['private']), 'Unknown department received restricted module');
                }
            }
        }
    }

    foreach ([ROLE_ADMIN, ROLE_MAINADMIN] as $role) {
        account('PTO', $role);
        $context = alfik_session_context();
        check($context['permissions']['manageUsers'], 'Administrator lost permissions');
        check(count($context['modules']) === count(kb_structure_all()), 'Administrator lost modules');
    }

    account('PTO', ROLE_USER, 'planner');
    $context = alfik_session_context();
    check($context['permissions']['viewPlans'], 'Plan viewer lost plans');
    check(!$context['permissions']['manageUsers'], 'Plan viewer gained admin rights');

    account('PTO', 'unexpected-role');
    check(alfik_session_context()['role']['code'] === ROLE_USER, 'Invalid role was not normalized');


    account('PTO');
    $context = alfik_session_context();
    $hints = alfik_pto_hints($context, 'ventspec.php');
    check($hints !== null && count($hints['steps']) === 3, 'PTO VentSpec guide missing');
    check(strpos($hints['title'], 'VentSpec') !== false, 'Wrong current-page guide');
    check(count($hints['tools']) === 5, 'PTO tool catalogue incomplete');
    check($hints['selectedHref'] === 'ventspec.php', 'Current guide not selected');
    check(alfik_pto_hints($context, 'index.php')['selectedHref'] === null, 'Home must start with catalogue');
    foreach ($hints['tools'] as $tool) {
        check(in_array($tool['href'], array_column($context['tools'], 'href'), true), 'Guide contains forbidden link');
        check(count($tool['steps']) === 3 && $tool['title'] !== '', 'Full algorithm missing from catalogue item');
        check(strpos($tool['href'], 'department=co') === false, 'Guide contains CO mode');
    }
    foreach (['verrata.php', 'equipment.php', 'area.php'] as $page) {
        check(count(alfik_pto_hints($context, $page)['steps']) === 3, 'Page guide missing');
    }
    check(strpos(alfik_pto_hints($context, 'area.php', 'wasser')['title'], 'WasserSpec') !== false, 'WasserSpec mode ignored');
    check(alfik_pto_hints($context, 'index.php')['steps'] === [], 'Home should offer tool selection');
    $restricted = $context;
    $restricted['tools'] = array_values(array_filter($context['tools'], static fn(array $tool): bool => $tool['href'] !== 'ventspec.php'));
    check(alfik_pto_hints($restricted, 'ventspec.php')['steps'] === [], 'Guide ignored tool permissions');
    check(alfik_pto_hints(null, 'ventspec.php') === null, 'Guest received guide');

    foreach (['CO', 'SDO', 'BUH', 'UNKNOWN', ''] as $department) {
        foreach ([ROLE_USER, ROLE_ADMIN] as $role) {
            account($department, $role);
            check(alfik_pto_hints(alfik_session_context(), 'ventspec.php') === null, 'Another department received PTO guide');
        }
    }

    foreach (array_merge(array_keys(KB_DEPARTMENT_NAMES), ['', 'UNKNOWN']) as $department) {
        account($department, ROLE_MAINADMIN);
        $adminContext = alfik_session_context();
        $adminHints = alfik_pto_hints($adminContext, 'ventspec.php');
        check($adminHints !== null && count($adminHints['tools']) === 5, 'Mainadmin lost the full hint catalogue');
        check(count($adminHints['steps']) === 3, 'Mainadmin lost current-page guide');
        check(strpos(alfik_pto_hints($adminContext, 'area.php', 'wasser')['title'], 'WasserSpec') !== false, 'Mainadmin lost WasserSpec guide');
    }

    account('DR', ROLE_USER, 'director');
    $directorContext = alfik_session_context();
    $directorHints = alfik_pto_hints($directorContext, 'ventspec.php');
    check($directorHints !== null && count($directorHints['tools']) === 5, 'DR lost hints');
    check($directorHints['selectedHref'] === 'ventspec.php', 'DR current guide missing');
    check(count($directorHints['steps']) === 3, 'DR guide incomplete');
    check(alfik_pto_hints($directorContext, 'index.php')['selectedHref'] === null, 'DR home must show catalogue');
    check(strpos(alfik_pto_hints($directorContext, 'area.php', 'wasser')['title'], 'WasserSpec') !== false, 'DR WasserSpec guide missing');
    check(!$directorContext['permissions']['manageUsers'], 'DR gained administration');
    $restrictedDirector = $directorContext;
    $restrictedDirector['tools'] = array_values(array_filter($directorContext['tools'], static fn(array $tool): bool => $tool['href'] !== 'ventspec.php'));
    check(alfik_pto_hints($restrictedDirector, 'ventspec.php')['steps'] === [], 'DR hints bypass tool permissions');
    $_SERVER['SCRIPT_NAME'] = '/VentSpec/web/ventspec.php';
    $_GET = [];
    ob_start();
    include dirname(__DIR__, 2) . '/web/alfik.php';
    $directorHtml = ob_get_clean();
    check(strpos($directorHtml, 'id="kb-alfik-help"') !== false, 'DR panel not rendered');
    check(strpos($directorHtml, 'Перейти в VentSpec') !== false, 'DR navigation button missing');

    // Render the real shared template, including PHP conditionals and safe output.
    account('PTO');
    $_SERVER['SCRIPT_NAME'] = '/VentSpec/web/ventspec.php';
    $_GET = [];
    ob_start();
    include dirname(__DIR__, 2) . '/web/alfik.php';
    $html = ob_get_clean();
    check(strpos($html, 'id="kb-alfik-help"') !== false, 'PTO panel not rendered');
    check(strpos($html, 'Как работать с VentSpec') !== false, 'Wrong rendered guide');
    check(strpos($html, 'aria-expanded="false"') !== false, 'Hints should start closed');
    check(strpos($html, 'data-guide-target="ventspec.php"') !== false, 'Catalogue must select a guide first');
    check(strpos($html, 'data-guide-panel="ventspec.php"') !== false, 'Guide view missing');
    check(strpos($html, 'Перейти в VentSpec') !== false, 'Explicit navigation button missing');
    check(strpos($html, 'data-help-scope=') !== false, 'Session-scoped UI persistence missing');

    account('CO', ROLE_MAINADMIN);
    ob_start();
    include dirname(__DIR__, 2) . '/web/alfik.php';
    $html = ob_get_clean();
    check(strpos($html, 'id="kb-alfik-help"') !== false, 'Mainadmin did not receive hints');
    account('CO', ROLE_ADMIN);
    ob_start();
    include dirname(__DIR__, 2) . '/web/alfik.php';
    $html = ob_get_clean();
    check(strpos($html, 'id="kb-alfik-help"') !== false, 'CO did not receive general help');
    check(strpos($html, 'Как писать промт') !== false, 'CO did not receive prompt guidance');
    check(strpos($html, 'data-guide-panel="pto"') === false, 'Regular admin from CO received PTO hints');
    check(strpos($html, 'data-guide-panel="ventspec.php"') === false, 'CO received a restricted tool guide');
    echo "PASS: PTO-only guides, page selection, tool permissions, real template rendering\\n";

    // Old sessions without department fields use the existing account lookup.
    file_put_contents($credentials, "<?php return [['login'=>'legacy','password_hash'=>'test','role'=>'user','department'=>'PTO']];\n");
    $_SESSION = ['kb_user' => 'legacy', 'kb_role' => ROLE_USER];
    check(alfik_session_context()['department']['code'] === 'PTO', 'Legacy session lookup failed');

    $json = json_encode(alfik_session_context(), JSON_THROW_ON_ERROR);
    check(strpos($json, 'password') === false && strpos($json, 'legacy') === false, 'Unneeded account data exposed');
    echo "PASS: departments, roles, shared tools, guests, legacy sessions, client tampering and plan viewers\n";
} finally {
    session_write_close();
    unlink($credentials);
}
