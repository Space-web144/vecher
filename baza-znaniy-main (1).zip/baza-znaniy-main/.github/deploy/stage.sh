#!/usr/bin/env bash
# Собирает в папку DIR ровно то, что выкладывается на сайт: файлы текущего
# коммита (git archive — без .git и без неотслеживаемого), кроме служебных
# файлов репозитория, которым на сервере делать нечего.
#
#   .github/deploy/stage.sh DIR
#
# Секреты и web/data/ в репозиторий не входят (.gitignore), поэтому и сюда
# не попадают никогда.
set -euo pipefail

dir="${1:?укажите папку}"
rm -rf "$dir"
mkdir -p "$dir"
git archive --format=tar HEAD | tar -x -C "$dir"

# Не выкладывается: служебное для GitHub, описание репозитория и агент
# проверки ТКП (он работает не на хостинге, а в своей песочнице — см. tkp-agent/README.md).
for path in .github .gitignore .gitattributes README.md CLAUDE.md AGENTS.md tkp-agent docs program-a/tests; do
    rm -rf "${dir:?}/$path"
done

# Защита от ошибки в .gitignore: секреты и рабочие данные сайта не должны
# уйти на сервер даже случайно — там они перезаписали бы настоящие.
if find "$dir" \( -path "$dir/web/data" -o -name '.auth_credentials.php*' \
        -o -name '.onec_api_key.php*' -o -name 'anthropic.json' \) -print -quit | grep -q .; then
    echo "В выкладку попали секреты или web/data — выкладка остановлена." >&2
    exit 1
fi

echo "К выкладке: $(find "$dir" -type f | wc -l) файлов, $(du -sh "$dir" | cut -f1)."
