"""Ограниченная выкладка общего PDF-парсера VentSpec/Area/WasserSpec."""

import ftplib
import io
import os
from pathlib import Path
import ssl
import subprocess


# Общие зависимости и страница статуса — до включающей новый путь обёртки.
FILES = (
    'common/claude_client.py',
    'program-a/spec_agent.py',
    'program-a/pdf_layout.py',
    'program-a/prompts/specification.md',
    'program-a/pdf_to_spec.py',
    'program-a/area_convert.py',
    'program-a/spec_conversion.py',
    'web/libob.php',
    'web/status.php',
    'program-a/web_pdf_run.py',
    'web/process_pdf.php',
)
NEW_FILES = set()
BASELINE = '7fd1fb1a3be0b78cd4d880372628b5f3c028821b'
# Снимок 43161265859: эти три файла на сайте были заменены точными
# старыми копиями d6becff. Сверены побайтно; новых правок в них нет.
SERVER_BASELINES = {
    path: 'd6becff' for path in (
        'program-a/pdf_to_spec.py', 'program-a/area_convert.py',
        'program-a/web_pdf_run.py')
}


def deploy(ftp, backup):
    def read(path):
        out = io.BytesIO()
        ftp.retrbinary('RETR ' + path, out.write)
        return out.getvalue()

    def save(kind, path, data):
        target = backup / kind / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)

    desired = {path: Path(path).read_bytes() for path in FILES}
    previous, unexpected = {}, []
    # До первой записи сохраняем и проверяем ВСЕ файлы. Не затираем
    # изменения, появившиеся на сервере после исходной сверки.
    for path in FILES:
        try:
            current = read(path)
        except ftplib.error_perm as exc:
            if path not in NEW_FILES or not str(exc).startswith('550'):
                raise
            current = None
        previous[path] = current
        if current is not None:
            save('before', path, current)
        expected = (None if path in NEW_FILES else
                    subprocess.check_output(['git', 'show', SERVER_BASELINES.get(path, BASELINE) + ':' + path]))
        if current != expected and current != desired[path]:
            unexpected.append(path)
    if unexpected:
        raise RuntimeError('На сервере другая версия, запись отменена: ' + ', '.join(unexpected))
    for path, data in desired.items():
        # Повторная проверка перед заменой защищает и от параллельных правок.
        try:
            current = read(path)
        except ftplib.error_perm as exc:
            if path not in NEW_FILES or not str(exc).startswith('550'):
                raise
            current = None
        if current != previous[path]:
            raise RuntimeError('Файл изменился во время выкладки: ' + path)
        parent, name = path.rsplit('/', 1)
        temporary = parent + '/.in.converters-' + name
        ftp.storbinary('STOR ' + temporary, io.BytesIO(data))
        if read(temporary) != data:
            raise RuntimeError('Не совпала временная копия: ' + path)
        ftp.rename(temporary, path)
        actual = read(path)
        save('after', path, actual)
        if actual != data:
            raise RuntimeError('Не совпал выложенный файл: ' + path)
        print('Verified: ' + path)


def main():
    server = os.environ['FTP_SERVER'].strip().removeprefix('ftp://').rstrip('/')
    host, sep, port = server.partition(':')
    context = ssl.create_default_context()
    if os.environ.get('FTP_TLS_VERIFY') == 'off':
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
    tls = os.environ.get('FTP_TLS') != 'off'
    ftp = ftplib.FTP_TLS(context=context, timeout=45) if tls else ftplib.FTP(timeout=45)
    try:
        ftp.connect(host, int(port) if sep else 21)
        ftp.login(os.environ['FTP_USERNAME'].strip(), os.environ['FTP_PASSWORD'])
        if tls:
            ftp.prot_p()
        ftp.cwd(os.environ.get('FTP_DIR') or '.')
        ftp.voidcmd('TYPE I')
        ftp.size('web/config.php')
        backup = Path(os.environ['RUNNER_TEMP']) / 'converters-backup'
        deploy(ftp, backup)
        if os.environ.get('SPEC_SMOKE') == 'true':
            from smoke_converters import run
            run(ftp, backup / 'smoke')
    finally:
        ftp.close()


if __name__ == '__main__':
    main()
