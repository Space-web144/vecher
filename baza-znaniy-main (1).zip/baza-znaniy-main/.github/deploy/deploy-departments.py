"""Publish only reviewed department access files; retain all tools and credentials."""
import ftplib
import hashlib
import io
import json
import os
from pathlib import Path
import ssl

FILES = (
    'web/users.php', 'web/login.php', 'web/structure_lib.php',
    'web/sidebar_refresh.php', 'web/admin_users.php',
)
BA_FILES = ('web/users.php', 'web/structure_lib.php', 'web/sidebar_refresh.php', 'web/sidebar.php')


def digest(data):
    return hashlib.sha256(data).hexdigest()


def deploy(ftp, backup, plan, files=FILES):
    if tuple(files) not in (FILES, ('web/users.php',), BA_FILES):
        raise RuntimeError('Unexpected publication scope')
    if set(plan['files']) != set(files):
        raise RuntimeError('Unexpected department access whitelist')
    def read(path):
        out = io.BytesIO()
        ftp.retrbinary('RETR ' + path, out.write)
        return out.getvalue()
    def save(kind, path, data):
        target = backup / kind / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    def guards():
        hashes = {path: digest(read(path)) for path in plan['preserve']}
        if hashes != plan['preserve']:
            raise RuntimeError('Protected application files changed; publication stopped')
        return hashes

    desired = {path: Path(path).read_bytes() for path in files}
    before = {}
    # Read and compare every target before the first mutation.
    for path in files:
        current = read(path)
        before[path] = current
        save('before', path, current)
        if digest(current) != plan['files'][path] and current != desired[path]:
            raise RuntimeError('Unreviewed server changes; nothing uploaded: ' + path)
    preserved_before = guards()
    changed = []
    for path in files:
        current = read(path)
        if current != before[path]:
            raise RuntimeError('Concurrent server edit: ' + path)
        if current == desired[path]:
            continue
        parent, name = path.rsplit('/', 1)
        temporary = parent + '/.in.departments-' + name
        ftp.storbinary('STOR ' + temporary, io.BytesIO(desired[path]))
        if read(temporary) != desired[path]:
            raise RuntimeError('Temporary copy differs: ' + path)
        ftp.rename(temporary, path)
        changed.append(path)
    # Read back every target, in the department access whitelist.
    for path in files:
        actual = read(path)
        save('after', path, actual)
        if actual != desired[path]:
            raise RuntimeError('Published file differs: ' + path)
        print('Verified: ' + path)
    preserved_after = guards()
    (backup / 'result.json').write_text(json.dumps({
        'changed': changed, 'verified': list(files),
        'preserved_before': preserved_before, 'preserved_after': preserved_after,
        'snapshot_run': plan.get('snapshot_run'), 'baseline_commit': plan.get('baseline_commit'),
    }, ensure_ascii=False, indent=2), encoding='utf-8')
    print('Protected application files preserved; changed %s department access files' % len(changed))


def main():
    users_only = os.environ.get('DEPARTMENTS_USERS_ONLY') == 'true'
    ba_only = os.environ.get('DEPARTMENTS_BA_ONLY') == 'true'
    if users_only and ba_only:
        raise RuntimeError('Choose one limited publication mode')
    if ba_only:
        plan_file, files = '.github/deploy/ba-plan.json', BA_FILES
    elif users_only:
        plan_file, files = '.github/deploy/users-only-plan.json', ('web/users.php',)
    else:
        plan_file, files = '.github/deploy/departments-plan.json', FILES
    plan = json.loads(Path(plan_file).read_text(encoding='utf-8'))
    server = os.environ['FTP_SERVER'].strip().removeprefix('ftp://').rstrip('/')
    host, sep, port = server.partition(':')
    context = ssl.create_default_context()
    if os.environ.get('FTP_TLS_VERIFY') == 'off':
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
    tls = os.environ.get('FTP_TLS') != 'off'
    ftp = ftplib.FTP_TLS(context=context, timeout=45) if tls else ftplib.FTP(timeout=45)
    try:
        ftp.connect(host, int(port) if sep else 21)
        ftp.login(os.environ['FTP_USERNAME'].strip(), os.environ['FTP_PASSWORD'])
        if tls:
            ftp.prot_p()
        ftp.cwd(os.environ.get('FTP_DIR') or '.')
        ftp.voidcmd('TYPE I')
        ftp.size('web/config.php')
        deploy(ftp, Path(os.environ['RUNNER_TEMP']) / 'departments-backup', plan, files)
    finally:
        ftp.close()


if __name__ == '__main__':
    main()
