#!/usr/bin/env python3
"""Restricted SSH endpoint and one-time installer for alfastroi.info."""
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import pwd
import re
import shutil
import subprocess
import sys
import tempfile

ROOT = Path('/var/www/alfastroi.info/VentSpec')
ACCOUNT = 'alfa-deploy'
HOME_DIR = Path('/home/alfa-deploy')
STATE = HOME_DIR / '.deploy-state.json'
BACKUPS = HOME_DIR / '.deploy-backups'
INSTALLED = Path('/usr/local/lib/alfastroi-deploy/server.py')
SHA = re.compile(r'^[0-9a-f]{40}$')
EXTENSIONS = {'.php', '.py', '.js', '.css', '.svg', '.png', '.jpg', '.jpeg',
              '.webp', '.woff', '.woff2', '.ttf', '.ico', '.html'}
EXCLUDED = {'data', 'uploads', 'runtime', 'secrets', 'venv', 'node_modules',
            '__pycache__', 'config.php', 'auth_credentials.php', 'onec_api_key.php'}
PREFIXES = {'common', 'program-a', 'program-b', 'program-c', 'web'}


def allowed(name):
    if not isinstance(name, str) or not name or '\\' in name or any(ord(c) < 32 for c in name):
        return False
    p = PurePosixPath(name)
    return (not p.is_absolute() and str(p) == name and len(p.parts) > 1
            and p.parts[0] in PREFIXES and p.suffix.lower() in EXTENSIONS
            and all(not x.startswith('.') and x not in EXCLUDED for x in p.parts))


def target(name):
    if not allowed(name):
        raise ValueError('Protected or invalid path: ' + str(name))
    p = ROOT / name
    if ROOT.is_symlink():
        raise ValueError('Symlink at site root')
    current = ROOT
    for part in PurePosixPath(name).parts:
        current = current / part
        if current.is_symlink():
            raise ValueError('Symlink in destination: ' + name)
    if p.exists() and not p.is_file():
        raise ValueError('Destination is not a regular file: ' + name)
    return p


def blob(path):
    if not path.exists():
        return None
    b = path.read_bytes()
    return hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()


def read_state():
    value = json.loads(STATE.read_text())
    if not isinstance(value, dict) or not SHA.fullmatch(value.get('commit', '')):
        raise ValueError('Invalid deployment state')
    return value


def validate_plan(plan):
    if not isinstance(plan, dict) or any(not SHA.fullmatch(plan.get(k, '')) for k in ('base', 'head')):
        raise ValueError('Invalid plan commits')
    files = plan.get('files')
    if not isinstance(files, list) or len(files) > 5000:
        raise ValueError('Invalid file list')
    seen = set()
    for item in files:
        if not isinstance(item, dict) or not allowed(item.get('path')):
            raise ValueError('Protected or invalid path in plan')
        if item['path'] in seen:
            raise ValueError('Duplicate file in plan')
        seen.add(item['path'])
        if not SHA.fullmatch(item.get('after', '')):
            raise ValueError('Invalid new file hash')
        if item.get('before') is not None and not SHA.fullmatch(item['before']):
            raise ValueError('Invalid old file hash')
    if read_state()['commit'] != plan['base']:
        raise ValueError('Deployment baseline changed; start a new run')
    return files


def check(plan, finishing=False):
    files = validate_plan(plan)
    conflicts = []
    for item in files:
        actual = blob(target(item['path']))
        accepted = [item['after']] if finishing else [item.get('before'), item['after']]
        if actual not in accepted:
            conflicts.append(item['path'])
    if conflicts:
        raise ValueError('Server changes detected; nothing overwritten: ' + ', '.join(conflicts))
    return files


def backup(plan):
    files = check(plan)
    BACKUPS.mkdir(mode=0o700, exist_ok=True)
    folder = Path(tempfile.mkdtemp(prefix=plan['head'][:12] + '-', dir=str(BACKUPS)))
    for item in files:
        source = target(item['path'])
        if source.exists():
            out = folder / item['path']
            out.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, out)
    (folder / 'plan.json').write_text(json.dumps(plan, indent=2))
    return str(folder)


def finish(plan):
    check(plan, finishing=True)
    fd, name = tempfile.mkstemp(prefix='.deploy-state-', dir=str(STATE.parent))
    try:
        with os.fdopen(fd, 'w') as out:
            json.dump({'commit': plan['head']}, out)
        os.replace(name, STATE)
    finally:
        if os.path.exists(name):
            os.unlink(name)


def install(baseline):
    if os.geteuid() != 0 or not SHA.fullmatch(baseline):
        raise ValueError('Run with sudo and a full baseline commit SHA')
    for tool in ('/usr/bin/rrsync', '/usr/bin/setfacl'):
        if not Path(tool).is_file():
            raise ValueError('Install rsync and acl first: missing ' + tool)
    if not ROOT.is_dir() or ROOT.is_symlink():
        raise ValueError('Site directory missing or is a symlink')
    user = pwd.getpwnam(ACCOUNT)
    key = Path('/home/admin/.ssh/alfastroi_actions.pub').read_text().strip().split()
    if len(key) < 2 or key[0] != 'ssh-ed25519':
        raise ValueError('Invalid public deploy key')
    INSTALLED.parent.mkdir(mode=0o755, parents=True, exist_ok=True)
    if Path(__file__).resolve() != INSTALLED:
        shutil.copyfile(__file__, INSTALLED)
    os.chown(INSTALLED.parent, 0, 0)
    os.chmod(INSTALLED.parent, 0o755)
    os.chown(INSTALLED, 0, 0)
    os.chmod(INSTALLED, 0o755)
    if not STATE.exists():
        STATE.write_text(json.dumps({'commit': baseline}))
        os.chown(STATE, user.pw_uid, user.pw_gid)
        os.chmod(STATE, 0o600)
    else:
        read_state()  # Reinstallation never silently resets the last deployed commit.
    BACKUPS.mkdir(mode=0o700, exist_ok=True)
    os.chown(BACKUPS, user.pw_uid, user.pw_gid)
    os.chmod(BACKUPS, 0o700)
    acl = '/usr/bin/setfacl'
    for folder, dirs, files in os.walk(ROOT, followlinks=False):
        dirs[:] = [n for n in dirs if not n.startswith('.') and n not in EXCLUDED
                   and not (Path(folder) / n).is_symlink()]
        rel = Path(folder).relative_to(ROOT)
        if rel.parts and rel.parts[0] not in PREFIXES:
            dirs[:] = []
            continue
        subprocess.run([acl, '-m', 'u:alfa-deploy:rwx,d:u:alfa-deploy:rwx,d:u:www-data:r-x', folder], check=True)
        selected = [str(Path(folder) / n) for n in files
                    if allowed(str((Path(folder) / n).relative_to(ROOT)))
                    and not (Path(folder) / n).is_symlink()]
        if selected:
            subprocess.run([acl, '-m', 'u:alfa-deploy:rw', '--'] + selected, check=True)
    auth = HOME_DIR / '.ssh/authorized_keys'
    auth.parent.mkdir(mode=0o700, exist_ok=True)
    auth.write_text('restrict,command="/usr/bin/python3 ' + str(INSTALLED) + '" '
                    + ' '.join(key) + '\n')
    os.chown(auth, user.pw_uid, user.pw_gid)
    os.chmod(auth, 0o600)
    print('Installed. Baseline:', read_state()['commit'])
    print('Existing site contents and data were not replaced. Code ACLs were configured.')


def main():
    if len(sys.argv) == 3 and sys.argv[1] == '--install':
        install(sys.argv[2])
        return
    command = os.environ.get('SSH_ORIGINAL_COMMAND', '')
    if command.startswith('rsync --server '):
        os.execv('/usr/bin/rrsync', ['rrsync', '-wo', '-no-del', '-munge', str(ROOT)])
    if command == 'alfastroi-state':
        print(json.dumps(read_state()))
        return
    if command not in {'alfastroi-check', 'alfastroi-backup', 'alfastroi-finish'}:
        raise ValueError('Only deployment commands and restricted rsync are allowed')
    raw = sys.stdin.buffer.read(2_000_001)
    if len(raw) > 2_000_000:
        raise ValueError('Plan too large')
    plan = json.loads(raw)
    if command == 'alfastroi-check':
        print('Checked files:', len(check(plan)))
    elif command == 'alfastroi-backup':
        print('Backup:', backup(plan))
    else:
        finish(plan)
        print('Verified and recorded:', plan['head'])


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, subprocess.CalledProcessError) as error:
        print('Deployment stopped:', error, file=sys.stderr)
        sys.exit(1)
