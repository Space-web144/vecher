# -*- coding: utf-8 -*-
"""Сверка файлов сервера с репозиторием: что выкладка изменит.

    python3 .github/deploy/compare.py STAGE SERVER

STAGE — то, что выкладывается (см. stage.sh), SERVER — снимок сайта
(ftp.sh snapshot). Печатает отчёт в Markdown: какие файлы на сервере
отличаются от репозитория (с изменениями построчно), каких нет в
репозитории, каких нет на сервере. Ничего не меняет; код выхода 0, если
сверка прошла (расхождения — не ошибка, а то, что нужно увидеть).

Главное, что ищем: правки, сделанные прямо на сервере после переноса кода
в репозиторий. Выкладка перезапишет такой файл версией из репозитория —
значит, правку надо сначала перенести в репозиторий.
"""
import difflib
import hashlib
import json
import os
import re
import shutil
import sys

# Только на сервере и не сравнивается: рабочие данные, секреты, кэш.
IGNORED = re.compile(r"^web/data/|(^|/)__pycache__/|(^|/)\.auth_credentials\.php"
                     r"|(^|/)\.onec_api_key\.php|(^|/)\.in\.|^\.deployed$")
DIFF_MAX_BYTES = 400 * 1024
DIFF_LINES_PER_FILE = 120
DIFF_LINES_TOTAL = 1500


def files(root):
    found = {}
    for base, dirs, names in os.walk(root):
        dirs.sort()
        for name in sorted(names):
            path = os.path.join(base, name)
            rel = os.path.relpath(path, root).replace(os.sep, "/")
            if not IGNORED.search(rel):
                found[rel] = path
    return found


def digest(path):
    sha = hashlib.sha256()
    with open(path, "rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            sha.update(chunk)
    return sha.hexdigest()


def text(path):
    if os.path.getsize(path) > DIFF_MAX_BYTES:
        return None
    with open(path, "rb") as handle:
        raw = handle.read()
    if b"\0" in raw:
        return None
    for encoding in ("utf-8", "cp1251"):
        try:
            return raw.decode(encoding).splitlines()
        except UnicodeDecodeError:
            continue
    return None


def main(argv):
    if len(argv) != 3:
        print(__doc__)
        return 2
    stage, server = files(argv[1]), files(argv[2])
    same, changed = [], []
    for rel in sorted(set(stage) & set(server)):
        (same if digest(stage[rel]) == digest(server[rel]) else changed).append(rel)
    only_server = sorted(set(server) - set(stage))
    only_repo = sorted(set(stage) - set(server))

    # Сохраняем исходные версии только изменённых отслеживаемых файлов.
    # Рабочие данные, секреты и неизвестные файлы сервера в этот набор не входят.
    changes_dir = os.environ.get("SERVER_CHANGES_DIR")
    if changes_dir:
        extra_source = {'web/rv_local.php', 'web/rv_rebuild.php', 'web/rv_kind.php',
                        'program-c/rv/data/kc_rvr.json',
                        'common/onec_db_duplicates.php', 'common/onec_db_duplicates_remove_all.php'}
        for rel in changed + [rel for rel in only_server if rel in extra_source]:
            target = os.path.join(changes_dir, rel)
            os.makedirs(os.path.dirname(target), exist_ok=True)
            shutil.copyfile(server[rel], target)

    if changes_dir:
        os.makedirs(changes_dir, exist_ok=True)
        manifest = {
            'same': same, 'changed': changed,
            'only_server': only_server, 'only_repo': only_repo,
            'server_sha256': {rel: digest(path) for rel, path in server.items()},
            'repo_sha256': {rel: digest(path) for rel, path in stage.items()},
        }
        with open(os.path.join(changes_dir, 'comparison.json'), 'w', encoding='utf-8') as handle:
            json.dump(manifest, handle, ensure_ascii=False, indent=2)

    out = ["## Сверка сервера с репозиторием", ""]
    out.append("| | файлов |\n|---|---|")
    out.append("| совпадают | %d |" % len(same))
    out.append("| **отличаются** — выкладка заменит версию на сервере | %d |" % len(changed))
    out.append("| есть только в репозитории — выкладка добавит | %d |" % len(only_repo))
    out.append("| есть только на сервере — выкладка не тронет | %d |" % len(only_server))
    out.append("")
    if not changed:
        out.append("Правок прямо на сервере нет: выкладка ничего не перезапишет.")
        out.append("")

    budget = DIFF_LINES_TOTAL
    if changed:
        out.append("### Отличаются")
        out.append("Строки с «-» — как сейчас на сервере, с «+» — как в репозитории. "
                   "Если на сервере правка, которой нет в репозитории, её нужно сначала "
                   "перенести в репозиторий, иначе выкладка её затрёт.")
        out.append("")
        for rel in changed:
            server_lines, stage_lines = text(server[rel]), text(stage[rel])
            out.append("#### `%s`" % rel)
            if server_lines is None or stage_lines is None:
                out.append("двоичный или большой файл: %d байт на сервере, %d в репозитории" % (
                    os.path.getsize(server[rel]), os.path.getsize(stage[rel])))
                out.append("")
                continue
            diff = list(difflib.unified_diff(server_lines, stage_lines, "сервер/" + rel,
                                             "репозиторий/" + rel, n=2, lineterm=""))
            if not diff:
                out.append("отличаются только переводы строк или пробелы в конце")
                out.append("")
                continue
            shown = diff[:min(DIFF_LINES_PER_FILE, max(budget, 0))]
            budget -= len(shown)
            out.append("```diff")
            out.extend(shown)
            if len(shown) < len(diff):
                out.append("… ещё %d строк" % (len(diff) - len(shown)))
            out.append("```")
            out.append("")

    for title, items in (("Есть только в репозитории", only_repo),
                         ("Есть только на сервере", only_server)):
        if items:
            out.append("### %s" % title)
            out.extend("- `%s`" % rel for rel in items)
            out.append("")

    report = "\n".join(out)
    print(report)
    if changes_dir:
        with open(os.path.join(changes_dir, 'report.md'), 'w', encoding='utf-8') as handle:
            handle.write(report + '\n')
    summary = os.environ.get("GITHUB_STEP_SUMMARY")
    if summary:
        with open(summary, "a", encoding="utf-8") as handle:
            handle.write(report + "\n")
    if os.environ.get("GITHUB_ACTIONS"):
        # Итог ещё и аннотацией: её видно в списке запусков без раскрытия
        # журнала и можно прочитать через API.
        level = "warning" if changed else "notice"
        print("::%s title=Сверка сервера с репозиторием::%s" % (level, annotation(report)))
    return 0


ANNOTATION_MAX_CHARS = 30000


def annotation(report):
    if len(report) > ANNOTATION_MAX_CHARS:
        report = report[:ANNOTATION_MAX_CHARS] + "\n… отчёт обрезан, полностью — в журнале запуска"
    return report.replace("%", "%25").replace("\r", "%0D").replace("\n", "%0A")


if __name__ == "__main__":
    sys.exit(main(sys.argv))
