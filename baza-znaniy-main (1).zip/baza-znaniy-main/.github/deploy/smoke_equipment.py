"""One synthetic equipment scan through PHP → Python → Anthropic.

No credentials are retrieved from hosting. A fixed-job POST endpoint is
single-use, random-token protected, expires in ten minutes and removes itself
before launching. All transient paths are random and cleaned in finally.
"""
import hashlib
import io
import json
from pathlib import Path
import secrets
import sys
import tempfile
import time
import urllib.request
import ftplib

import fitz
from openpyxl import load_workbook

SITE = 'https://alfastroi.info/VentSpec/web/'


def fixture(path):
    with fitz.open() as source:
        page = source.new_page(width=600, height=500)
        page.insert_text((40, 70), 'FAN SELECTION DATA', fontsize=24)
        page.insert_text((40, 130), 'System: P1', fontsize=24)
        page.insert_text((40, 190), 'Fan model: ROOF-H 355 E4 30', fontsize=20)
        image = page.get_pixmap(matrix=fitz.Matrix(2, 2), alpha=False)
        with fitz.open() as scan:
            sheet = scan.new_page(width=600, height=500)
            sheet.insert_image(sheet.rect, stream=image.tobytes('png'))
            scan.save(str(path))


def run(ftp, artifacts):
    artifacts.mkdir(parents=True, exist_ok=True)
    nonce, token = secrets.token_hex(8), secrets.token_hex(32)
    script = 'equipment_probe_' + secrets.token_hex(16) + '.php'
    endpoint = 'web/' + script
    uploaded = 'web/data/uploads/' + nonce + '_spec.pdf'
    prefix = 'web/data/outputs/' + nonce
    status_path = prefix + '_status.json'
    result_path = prefix + '_result.xlsx'
    log_path, lock_path = prefix + '_probe.log', prefix + '_probe.lock'
    code = r'''<?php
if ($_SERVER['REQUEST_METHOD'] !== 'POST' || time() > __DEADLINE__ ||
    !is_string($_POST['token'] ?? null) || !hash_equals('__HASH__', hash('sha256', $_POST['token']))) {
    http_response_code(404); exit;
}
require __DIR__ . '/config.php';
require __DIR__ . '/libob.php';
$nonce = '__NONCE__';
$lock = @fopen(OUTPUT_DIR . '/' . $nonce . '_probe.lock', 'x');
if (!$lock) { http_response_code(409); exit; }
fclose($lock);
@unlink(__FILE__);
$env = '';
$settings = ob_claude_secrets();
foreach (['api_key'=>'ANTHROPIC_API_KEY','model_equipment'=>'ANTHROPIC_MODEL',
          'effort_equipment'=>'ANTHROPIC_EFFORT','proxy'=>'ANTHROPIC_PROXY'] as $key=>$variable) {
    if (!empty($settings[$key])) $env .= $variable . '=' . escapeshellarg((string)$settings[$key]) . ' ';
}
$cmd = $env . 'nohup ' . escapeshellarg(PYTHON_BIN) . ' ' . escapeshellarg(WEB_PDF_RUN_SCRIPT)
    . ' --pdf ' . escapeshellarg(UPLOAD_DIR . '/' . $nonce . '_spec.pdf')
    . ' --output ' . escapeshellarg(OUTPUT_DIR . '/' . $nonce . '_result.xlsx')
    . ' --status-file ' . escapeshellarg(OUTPUT_DIR . '/' . $nonce . '_status.json')
    . ' --format equipment > ' . escapeshellarg(OUTPUT_DIR . '/' . $nonce . '_probe.log') . ' 2>&1 &';
shell_exec($cmd);
header('Content-Type: application/json'); echo '{"started":true}';
'''
    code = code.replace('__DEADLINE__', str(int(time.time()) + 600)).replace(
        '__HASH__', hashlib.sha256(token.encode()).hexdigest()).replace('__NONCE__', nonce)

    def read(path):
        out = io.BytesIO()
        ftp.retrbinary('RETR ' + path, out.write)
        return out.getvalue()

    def delete(path):
        try:
            ftp.delete(path)
        except ftplib.error_perm as exc:
            if not str(exc).startswith('550'):
                raise

    try:
        with tempfile.TemporaryDirectory() as folder:
            local = Path(folder) / 'scan.pdf'
            fixture(local)
            data = local.read_bytes()
            ftp.storbinary('STOR ' + uploaded, io.BytesIO(data))
        ftp.storbinary('STOR ' + endpoint, io.BytesIO(code.encode()))
        request = urllib.request.Request(SITE + script, data=('token=' + token).encode(), method='POST')
        with urllib.request.urlopen(request, timeout=30) as response:
            if json.load(response) != {'started': True}:
                raise RuntimeError('Smoke: fixed-job launch failed')
        deadline = time.monotonic() + 420
        result = None
        while time.monotonic() < deadline:
            try:
                result = json.loads(read(status_path))
            except ftplib.error_perm as exc:
                if not str(exc).startswith('550'):
                    raise
            if result and result.get('state') != 'running':
                break
            time.sleep(3)
        if not result or not result.get('ok'):
            (artifacts / 'diagnostic.json').write_text(json.dumps({
                'has_status': bool(result),
                'error': str((result or {}).get('error', 'no final status'))[:600],
            }, ensure_ascii=False), encoding='utf-8')
            # Logs/trace can contain private provider details: do not print them.
            raise RuntimeError('Smoke: real conversion failed or timed out; credentials were not retrieved')
        if result.get('engine') != 'equipment-hybrid' or result.get('ai_pages') != 1 or not result.get('needs_review'):
            raise RuntimeError('Smoke: scan did not take the recognition/review route')
        workbook = read(result_path)
        book = load_workbook(io.BytesIO(workbook), data_only=True)
        try:
            sheet = book.active
            if sheet.max_column != 10 or sheet.max_row != 2 or 'Проверка' not in book.sheetnames:
                raise RuntimeError('Smoke: wrong equipment report structure')
            if sheet['A2'].value != 'P1' or sheet['D2'].value != 'ROOF-H 355 E4 30':
                raise RuntimeError('Smoke: equipment scan values are wrong')
            if book['Источники']['E2'].value != 1:
                raise RuntimeError('Smoke: source page was lost')
        finally:
            book.close()
        (artifacts / 'synthetic-scan.xlsx').write_bytes(workbook)
        (artifacts / 'result.json').write_text(json.dumps({
            key: result[key] for key in ('ok', 'engine', 'total_rows', 'needs_review', 'ai_pages')
        }, ensure_ascii=False), encoding='utf-8')
        print('PASS equipment live scan: model, system, source page and explicit review')
    finally:
        # Only this random probe's paths; no uploaded user files are touched.
        for path in (endpoint, uploaded, status_path, result_path, log_path, lock_path):
            delete(path)
