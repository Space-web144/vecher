#!/usr/bin/env bash
# Доступ к сайту по FTP для GitHub Actions (через lftp из пакетов Ubuntu).
#
#   ftp.sh snapshot DIR          — скачать файлы сайта в DIR: только чтение,
#                                  без web/data/ и без файлов с секретами
#   ftp.sh menu DIR BACKUP_DIR  — выложить только три файла меню, с резервом
#                                  и побайтовой проверкой после загрузки
#   ftp.sh area-access DIR BACKUP_DIR — три файла меню и доступа ЦО
#   ftp.sh upload DIR INFO_FILE  — выложить содержимое DIR на сервер и
#                                  записать INFO_FILE в .deployed (какой
#                                  коммит выложен). Ничего не удаляет.
#
# Окружение:
#   FTP_SERVER, FTP_USERNAME, FTP_PASSWORD — секреты репозитория;
#   FTP_DIR        — папка VentSpec относительно входа FTP (переменная
#                    репозитория; по умолчанию «.» — FTP-пользователь
#                    заведён с домашней папкой VentSpec);
#   FTP_TLS        — on (по умолчанию) / off: шифровать соединение;
#   FTP_TLS_VERIFY — on (по умолчанию) / off: проверять сертификат сервера.
#
# Пароль идёт в lftp через переменную окружения LFTP_PASSWORD — не через
# командную строку и не через файл.
set -euo pipefail

mode="${1:?snapshot, upload, menu или area-access}"
dir="${2:?укажите папку}"

# Ошибка — в журнал и в аннотацию запуска: её видно на странице запуска
# сразу, без раскрытия журнала (и через API — тому, кто чинит выкладку).
fail() {
    local msg="$1"
    echo "$msg" >&2
    if [ -n "${GITHUB_ACTIONS:-}" ]; then
        msg="${msg//'%'/'%25'}"
        msg="${msg//$'\r'/'%0D'}"
        msg="${msg//$'\n'/'%0A'}"
        echo "::error title=Доступ к сайту по FTP::$msg"
    fi
    exit "${2:-1}"
}

secrets_hint="Settings → Secrets and variables → Actions → Secrets"
[ -n "${FTP_SERVER:-}" ] || fail "Нет секрета FTP_SERVER ($secrets_hint)." 2
[ -n "${FTP_USERNAME:-}" ] || fail "Нет секрета FTP_USERNAME ($secrets_hint)." 2
[ -n "${FTP_PASSWORD:-}" ] || fail "Нет секрета FTP_PASSWORD ($secrets_hint)." 2
# Лишний пробел или перевод строки при вставке — частая причина отказа.
FTP_SERVER="$(printf '%s' "$FTP_SERVER" | tr -d '[:space:]')"
FTP_USERNAME="$(printf '%s' "$FTP_USERNAME" | tr -d '[:space:]')"
ftp_dir="${FTP_DIR:-.}"
tls="${FTP_TLS:-on}"
verify="${FTP_TLS_VERIFY:-on}"

# ftp://host/ — обычная запись адреса из панели хостинга. Протокол
# нормализуем; обязательное TLS-шифрование ниже остаётся включённым.
case "$FTP_SERVER" in
    ftp://*) FTP_SERVER="${FTP_SERVER#ftp://}" ;;
esac
while [[ "$FTP_SERVER" == */ ]]; do FTP_SERVER="${FTP_SERVER%/}"; done

# Значения подставляются в команды lftp — только безопасные символы.
# Диагностика не показывает секрет даже при случайно вставленном URL с паролем.
if ! [[ "$FTP_SERVER" =~ ^[A-Za-z0-9.-]+(:[0-9]{1,5})?$ ]]; then
    case "$FTP_SERVER" in
        *'@'*) hint="Указан адрес с учётными данными. Логин и пароль задаются отдельными секретами." ;;
        *'://'* ) hint="Указан другой протокол. Этот workflow использует FTP с TLS; нужен адрес FTP-сервера из панели хостинга." ;;
        *'/'*|*'\'*) hint="В значении есть путь. В FTP_SERVER оставьте только сервер; папку задайте в FTP_DIR." ;;
        *'='*) hint="В значении есть знак =. Вставьте только адрес, без FTP_SERVER= или Name/Value." ;;
        *'"'*|*"'"*) hint="В значении есть кавычки. Вставьте адрес без кавычек." ;;
        *':'*) hint="Не распознан порт. Допустимо имя-сервера:21; IPv6 этой настройкой пока не поддерживается." ;;
        *) hint="Есть недопустимые символы. Скопируйте имя FTP-сервера или IPv4 из панели хостинга латиницей." ;;
    esac
    fail "FTP_SERVER: $hint Значение секрета в журнал не выводится." 2
fi
[[ "$FTP_USERNAME" =~ ^[A-Za-z0-9._@-]+$ ]] \
    || fail "FTP_USERNAME: недопустимые символы — нужен логин вида u2980659_github." 2
[[ "$ftp_dir" =~ ^[A-Za-z0-9._/-]+$ && ! "$ftp_dir" =~ (^|/)\.\.(/|$) ]] \
    || fail "FTP_DIR: недопустимый путь." 2

export LFTP_PASSWORD="$FTP_PASSWORD"

settings=(
    "set cmd:fail-exit yes"                 # любая ошибка — остановка
    "set net:timeout 30"
    "set net:max-retries 3"
    "set net:reconnect-interval-base 5"
    "set dns:order 'inet inet6'"
    "set ftp:passive-mode on"
    # Файл пишется под временным именем и подменяется целиком: посетитель
    # сайта не застанет наполовину записанный .php.
    "set xfer:use-temp-file yes"
)
if [ "$tls" = "off" ]; then
    settings+=("set ftp:ssl-allow no")
else
    # Без шифрования пароль не отправляется вовсе.
    settings+=("set ftp:ssl-force yes" "set ftp:ssl-protect-data yes")
fi
if [ "$verify" = "off" ]; then
    settings+=("set ssl:verify-certificate no")
fi

script="$(mktemp)"
trap 'rm -f "$script"' EXIT
{
    printf '%s\n' "${settings[@]}"
    printf "open --env-password -u '%s' 'ftp://%s'\n" "$FTP_USERNAME" "$FTP_SERVER"
    printf "cd '%s'\n" "$ftp_dir"
    # Признак того, что это папка сайта VentSpec, а не корень хостинга или
    # чужая папка: выкладка не туда размножила бы сайт.
    echo "cls -1 web/config.php common/anthropic_client.py"
} > "$script"

case "$mode" in
    snapshot)
        mkdir -p "$dir"
        # Рабочие данные, секреты, кэш Python и временные файлы lftp не
        # скачиваем: сравнивать их не с чем, а секретам на сборщике делать
        # нечего. Шаблоны — по пути от корня VentSpec.
        cat >> "$script" <<EOF
mirror --no-perms --parallel=4 \
    -x '^web/data/' \
    -x '(^|/)__pycache__/' \
    -x '(^|/)\.auth_credentials\.php' \
    -x '(^|/)\.onec_api_key\.php' \
    -x '(^|/)\.in\.' \
    -x '^\.deployed$' \
    . '$dir'
EOF
        ;;
    upload)
        info="${3:?укажите файл со сведениями о выкладке}"
        [ -d "$dir" ] || { echo "Нет папки $dir." >&2; exit 2; }
        # mirror -R без --delete: только добавляет и обновляет файлы.
        # Удалённое из репозитория остаётся на сервере — его видно в сверке.
        cat >> "$script" <<EOF
mirror -R --no-perms --parallel=2 --verbose=1 '$dir' .
put '$info' -o .deployed
EOF
        ;;
    menu|area-access)
        backup="${3:?укажите папку резервной копии}"
        if [ "$mode" = "menu" ]; then
            menu_files=(web/sidebar_refresh.php web/structure.php web/assets/refresh.css)
        else
            menu_files=(web/sidebar_refresh.php web/structure.php web/structure_lib.php)
        fi
        [ "$(find "$dir" -type f | wc -l)" -eq 3 ] || fail "В выкладке меню должны быть ровно три файла." 2
        for file in "${menu_files[@]}"; do
            [ -f "$dir/$file" ] && [ ! -L "$dir/$file" ] || fail "Нет файла меню $file." 2
            mkdir -p "$backup/before/$(dirname "$file")" "$backup/after/$(dirname "$file")"
            printf "get '%s' -o '%s'\n" "$file" "$backup/before/$file" >> "$script"
        done
        # Единственные команды записи на сайт в режимах menu/area-access — эти три put.
        for file in "${menu_files[@]}"; do
            printf "put '%s' -o '%s'\n" "$dir/$file" "$file" >> "$script"
        done
        for file in "${menu_files[@]}"; do
            printf "get '%s' -o '%s'\n" "$file" "$backup/after/$file" >> "$script"
        done
        ;;
    *)
        echo "Режим: snapshot, upload, menu или area-access." >&2
        exit 2
        ;;
esac
echo "bye" >> "$script"

errlog="$(mktemp)"
trap 'rm -f "$script" "$errlog"' EXIT
# Ошибки lftp — в журнал как есть и, если команда не прошла, последние
# строки — в аннотацию. Пароля в них нет: он только в окружении.
if ! lftp -f "$script" 2> >(tee "$errlog" >&2); then
    sleep 1                                 # дождаться, пока tee допишет
    hint=""
    if grep -q "Certificate verification" "$errlog"; then
        # Сертификат выдан на имя сервера, а в FTP_SERVER — другое имя или
        # IP. Подсказываем, на какое имя он выдан: его и надо указать.
        host="${FTP_SERVER%%:*}"
        port="${FTP_SERVER##*:}"
        [ "$port" = "$FTP_SERVER" ] && port=21
        names="$(timeout 20 openssl s_client -connect "$host:$port" -starttls ftp </dev/null 2>/dev/null \
            | openssl x509 -noout -subject -ext subjectAltName 2>/dev/null \
            | grep -v '^X509v3' | tr -s ' \n' ' ')"
        # Имя сервера по обратной записи DNS — если в FTP_SERVER указан IP.
        ptr=""
        if [[ "$host" =~ ^[0-9.]+$ ]]; then
            ptr="$(getent hosts "$host" | awk '{print $2}' | head -n 1)"
        fi
        hint="
Сертификат сервера выдан на: ${names:-не удалось прочитать}.${ptr:+ Имя этого сервера по DNS: $ptr.} Укажите имя сервера, подходящее под сертификат, в секрете FTP_SERVER вместо адреса, который там сейчас."
    fi
    fail "lftp: $(grep -v '^[[:space:]]*$' "$errlog" | tail -n 6)$hint"
fi

if [ "$mode" = "menu" ] || [ "$mode" = "area-access" ]; then
    for file in "${menu_files[@]}"; do
        cmp -s "$dir/$file" "$backup/after/$file" || fail "Проверка загруженного файла не прошла: $file"
        echo "Проверено после выкладки: $file"
    done
fi
