"""Ограниченная выкладка расчёта площади и переименования термина."""

import ftplib
import io
import os
from pathlib import Path
import ssl
import subprocess


# Новый модуль — раньше ядра, интерфейс — после ядра. Только эта группа
# файлов: PDF-конвертер и проверка результата в выкладку не входят.
FILES = (
    'common/xlsx_values.py',
    'common/area.py', 'common/batch_match.py', 'common/header_style.py',
    'common/matcher.py', 'common/nomenclature_intake (1).py',
    'common/nomenclature_intake.py', 'common/parameters.py',
    'common/query_classifier.py', 'common/report.py', 'common/web_db_file_dump.py',
    'program-a/area_calc.py', 'program-a/vent_gui.py', 'program-a/vent_processor.py',
    'web/alfik_context_lib.php', 'web/area.php', 'web/onec_database.php',
    'web/structure.php', 'web/ventspec.php',
)
NEW_FILES = {'common/xlsx_values.py'}
BASELINE = 'ed78e49f4fd06b08f46c30aa292b21c510629a61'


def deploy(ftp, backup):
    def read(path):
        out = io.BytesIO()
        ftp.retrbinary('RETR ' + path, out.write)
        return out.getvalue()

    def save(kind, path, data):
        target = backup / kind / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)

    desired = {path: Path(path).read_bytes() for path in FILES}
    previous = {}
    # До первой записи сохраняем и проверяем ВСЕ файлы. Не затираем
    # изменения, появившиеся на сервере после исходной сверки.
    for path in FILES:
        try:
            current = read(path)
        except ftplib.error_perm as exc:
            if path not in NEW_FILES or not str(exc).startswith('550'):
                raise
            current = None
        previous[path] = current
        if current is not None:
            save('before', path, current)
        expected = (None if path in NEW_FILES else
                    subprocess.check_output(['git', 'show', BASELINE + ':' + path]))
        if current != expected and current != desired[path]:
            raise RuntimeError('На сервере другая версия, запись отменена: ' + path)
    for path, data in desired.items():
        # Повторная проверка перед заменой защищает и от параллельных правок.
        try:
            current = read(path)
        except ftplib.error_perm as exc:
            if path not in NEW_FILES or not str(exc).startswith('550'):
                raise
            current = None
        if current != previous[path]:
            raise RuntimeError('Файл изменился во время выкладки: ' + path)
        parent, name = path.rsplit('/', 1)
        temporary = parent + '/.in.fitting-' + name
        ftp.storbinary('STOR ' + temporary, io.BytesIO(data))
        if read(temporary) != data:
            raise RuntimeError('Не совпала временная копия: ' + path)
        ftp.rename(temporary, path)
        actual = read(path)
        save('after', path, actual)
        if actual != data:
            raise RuntimeError('Не совпал выложенный файл: ' + path)
        print('Verified: ' + path)


def main():
    server = os.environ['FTP_SERVER'].strip().removeprefix('ftp://').rstrip('/')
    host, sep, port = server.partition(':')
    context = ssl.create_default_context()
    if os.environ.get('FTP_TLS_VERIFY') == 'off':
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
    tls = os.environ.get('FTP_TLS') != 'off'
    ftp = ftplib.FTP_TLS(context=context, timeout=45) if tls else ftplib.FTP(timeout=45)
    try:
        ftp.connect(host, int(port) if sep else 21)
        ftp.login(os.environ['FTP_USERNAME'].strip(), os.environ['FTP_PASSWORD'])
        if tls:
            ftp.prot_p()
        ftp.cwd(os.environ.get('FTP_DIR') or '.')
        ftp.voidcmd('TYPE I')
        ftp.size('web/config.php')
        deploy(ftp, Path(os.environ['RUNNER_TEMP']) / 'fitting-backup')
    finally:
        ftp.close()


if __name__ == '__main__':
    main()
