"""Guarded, limited source deployment. Runtime catalog contents are never uploaded."""
from datetime import datetime, timezone
import ftplib
import hashlib
import io
import json
import os
from pathlib import Path
import re
import ssl
import time

GATE = 'web/data/.catalog-routing-deploying'
ENTRANCES = ('web/1c_intake.php', 'web/onec_review_submit.php', 'web/onec_review_bulk.php',
             'web/onec_review_approve_all.php')


def read(ftp, path, optional=False):
    stream = io.BytesIO()
    try:
        ftp.retrbinary('RETR ' + path, stream.write)
    except ftplib.error_perm as exc:
        if optional and str(exc).startswith('550'):
            return None
        raise
    return stream.getvalue()


def sha(data):
    return hashlib.sha256(data).hexdigest() if data is not None else None


def publish(ftp, path, data):
    temporary = str(Path(path).with_name('.in.routing-' + Path(path).name))
    ftp.storbinary('STOR ' + temporary, io.BytesIO(data))
    if read(ftp, temporary) != data:
        raise RuntimeError('Staged copy differs: ' + path)
    ftp.rename(temporary, path)
    if read(ftp, path) != data:
        raise RuntimeError('Published copy differs: ' + path)


def wait_for_intakes(ftp):
    # The newly gated API cannot launch new processes. Drain any old background
    # intake accepted before the gate, without inspecting or logging customer rows.
    for attempt in range(12):
        active = 0
        for name in ftp.nlst('web/data/uploads'):
            filename = name.rsplit('/', 1)[-1]
            match = re.fullmatch(r'([a-f0-9]{16})_1c_input.json', filename)
            if not match:
                continue
            stamp = ftp.sendcmd('MDTM web/data/uploads/' + filename).split()[-1]
            age = (datetime.now(timezone.utc) - datetime.strptime(stamp, '%Y%m%d%H%M%S').replace(tzinfo=timezone.utc)).total_seconds()
            if age > 86400:
                continue  # Old incomplete batches remain available for manual investigation.
            status = read(ftp, 'web/data/outputs/' + match[1] + '_1c_status.json', optional=True)
            if status is None:
                active += 1
        if not active:
            return
        time.sleep(5)
    raise RuntimeError('An earlier intake is still running; source deployment rolled back. Retry after it finishes.')


def deploy(ftp, backup, plan=None):
    plan = plan or json.loads(Path('.github/deploy/routing-plan.json').read_text())
    targets = plan['files']
    if any(path.startswith('web/data/') or '..' in Path(path).parts for path in targets):
        raise ValueError('Runtime data is not a deployment target')
    desired, before = {}, {}
    for path, baseline in targets.items():
        desired[path] = Path(path).read_bytes()
        before[path] = read(ftp, path, optional=True)
        if sha(before[path]) != baseline and before[path] != desired[path]:
            raise RuntimeError('Unreviewed server changes; nothing published: ' + path)
        if before[path] is not None:
            saved = backup / 'before' / path
            saved.parent.mkdir(parents=True, exist_ok=True)
            saved.write_bytes(before[path])
    if read(ftp, GATE, optional=True) is not None:
        raise RuntimeError('Another routing publication is in progress')
    protection = read(ftp, 'web/data/.htaccess')
    if b'Require all denied' not in protection:
        raise RuntimeError('Runtime data protection is missing')
    from common.vk_catalog import validate_catalog
    catalog = validate_catalog(json.loads(read(ftp, 'web/data/1c_vk_catalog.json')))
    changed = []
    remove_gate = True
    ftp.storbinary('STOR ' + GATE, io.BytesIO(b'Catalog routing source publication\n'))
    try:
        # Four entrance files include the gate, so no requests reach changing runners.
        for path in ENTRANCES:
            if read(ftp, path, optional=True) != before[path]:
                raise RuntimeError('Concurrent server edit: ' + path)
            if before[path] != desired[path]:
                changed.append(path)
                publish(ftp, path, desired[path])
        time.sleep(3)
        wait_for_intakes(ftp)
        for path in targets:
            if path in ENTRANCES:
                continue
            if read(ftp, path, optional=True) != before[path]:
                raise RuntimeError('Concurrent server edit: ' + path)
            if before[path] != desired[path]:
                changed.append(path)
                publish(ftp, path, desired[path])
        for path in targets:
            if read(ftp, path) != desired[path]:
                raise RuntimeError('Final source verification failed: ' + path)
        (backup / 'result.json').write_text(json.dumps({
            'snapshot_run': plan['snapshot_run'], 'changed': changed,
            'verified': {path: sha(data) for path, data in desired.items()},
            'vk_items_before': catalog['item_count'], 'runtime_catalogs_modified': False,
        }, indent=2))
        print('Verified source files:', len(targets))
        print('Runtime catalogs were not rewritten; routing applies to incoming 1C items.')
    except BaseException:
        try:
            for path in reversed(changed):
                current = read(ftp, path, optional=True)
                if current not in (before[path], desired[path]):
                    raise RuntimeError('Concurrent source edit prevents rollback: ' + path)
                if before[path] is None:
                    if current is not None:
                        ftp.delete(path)
                elif current != before[path]:
                    publish(ftp, path, before[path])
        except BaseException:
            # An incomplete rollback must not enable callers of mixed versions.
            remove_gate = False
            raise
        raise
    finally:
        if remove_gate:
            ftp.delete(GATE)



def main():
    server = os.environ['FTP_SERVER'].strip()
    if server.startswith('ftp://'):
        server = server[6:]
    host, separator, port = server.rstrip('/').partition(':')
    context = ssl.create_default_context()
    if os.environ.get('FTP_TLS_VERIFY') == 'off':
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
    tls = os.environ.get('FTP_TLS') != 'off'
    ftp = ftplib.FTP_TLS(context=context, timeout=45) if tls else ftplib.FTP(timeout=45)
    try:
        ftp.connect(host, int(port) if separator else 21)
        ftp.login(os.environ['FTP_USERNAME'].strip(), os.environ['FTP_PASSWORD'])
        if tls:
            ftp.prot_p()
        ftp.cwd(os.environ.get('FTP_DIR') or '.')
        ftp.voidcmd('TYPE I')
        backup = Path(os.environ['RUNNER_TEMP']) / 'routing-backup'
        backup.mkdir(parents=True, exist_ok=True)
        deploy(ftp, backup)
    finally:
        ftp.close()


if __name__ == '__main__':
    main()
