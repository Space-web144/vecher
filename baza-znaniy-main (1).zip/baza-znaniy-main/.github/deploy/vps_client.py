#!/usr/bin/env python3
"""Deploy the delta since the last verified deployment, preserving server drift."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shlex
import subprocess
import sys
import tempfile

from vps_server import SHA, allowed


def git(*args):
    return subprocess.check_output(['git', *args])


def old_blob(commit, name):
    result = subprocess.run(['git', 'rev-parse', '--verify', commit + ':' + name],
                            stdout=subprocess.PIPE, stderr=subprocess.DEVNULL)
    return result.stdout.decode().strip() if result.returncode == 0 else None


def build_plan(base, head, folder):
    if not SHA.fullmatch(base) or not SHA.fullmatch(head):
        raise ValueError('Invalid deployment commits')
    subprocess.run(['git', 'merge-base', '--is-ancestor', base, head], check=True)
    changed = git('diff', '--no-renames', '--name-only', '-z', base, head).split(b'\0')
    plan = {'base': base, 'head': head, 'files': []}
    skipped, retained = [], []
    for raw in changed:
        if not raw:
            continue
        name = raw.decode('utf-8')
        # VentSpec regression fixtures run in CI only; never transfer
        # or overwrite old test copies on the production server.
        if name.startswith('program-a/tests/') or not allowed(name):
            skipped.append(name)
            continue
        entry = git('ls-tree', '-z', head, '--', name)
        if not entry:
            retained.append(name)  # Deletions require a separate reviewed operation.
            continue
        mode, kind, new_hash = entry.split(b'\t', 1)[0].split()
        if kind != b'blob' or mode not in {b'100644', b'100755'}:
            raise ValueError('Symlinks and submodules cannot be deployed: ' + name)
        data = git('show', head + ':' + name)
        expected = new_hash.decode()
        if hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest() != expected:
            raise ValueError('Git blob mismatch: ' + name)
        dest = folder / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
        os.chmod(dest, 0o644)
        plan['files'].append({'path': name, 'before': old_blob(base, name), 'after': expected})
    return plan, skipped, retained


def syntax_checks(plan, folder):
    for item in plan['files']:
        path = folder / item['path']
        if path.suffix == '.py':
            compile(path.read_bytes(), str(path), 'exec')
        elif path.suffix == '.php':
            subprocess.run(['php', '-l', str(path)], check=True)
        elif path.suffix == '.js':
            subprocess.run(['node', '--check', str(path)], check=True)


def ssh_args():
    return ['ssh', '-T', '-i', os.environ['VPS_KEY_FILE'],
            '-o', 'IdentitiesOnly=yes', '-o', 'BatchMode=yes',
            '-o', 'StrictHostKeyChecking=yes',
            '-o', 'UserKnownHostsFile=' + os.environ['VPS_HOSTS_FILE'],
            '-o', 'ConnectTimeout=20', '-o', 'ServerAliveInterval=15',
            '-o', 'ServerAliveCountMax=3']


def remote(command, plan=None):
    payload = None if plan is None else json.dumps(plan).encode()
    result = subprocess.run(ssh_args() + ['alfa-deploy@193.181.221.27', command],
                            input=payload, stdout=subprocess.PIPE, check=True, timeout=120)
    return result.stdout.decode()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--dry-run', action='store_true')
    args = parser.parse_args()
    head = git('rev-parse', 'HEAD').decode().strip()
    if os.environ.get('VPS_TARGET_SHA', head) != head:
        raise ValueError('Checkout is not the triggering commit')
    base = json.loads(remote('alfastroi-state'))['commit']
    with tempfile.TemporaryDirectory(prefix='vps-delta-') as temp:
        folder = Path(temp) / 'files'
        folder.mkdir()
        plan, skipped, retained = build_plan(base, head, folder)
        print('Baseline:', base, 'Target:', head, flush=True)
        for item in plan['files']:
            print('Update:', item['path'], flush=True)
        for name in skipped:
            print('Not deployed (protected/configuration/metadata/CI-only):', name, flush=True)
        for name in retained:
            print('Retained on server (deleted in Git):', name, flush=True)
        if any(n.endswith('requirements.txt') or n.endswith('requirements-web.txt') for n in skipped):
            raise ValueError('Dependency changes require installing packages on the VPS before deployment')
        syntax_checks(plan, folder)
        print(remote('alfastroi-check', plan), flush=True)
        if not args.dry_run:
            print(remote('alfastroi-backup', plan), flush=True)
        if plan['files']:
            file_list = Path(temp) / 'files.list'
            file_list.write_bytes(b''.join(x['path'].encode() + b'\0' for x in plan['files']))
            command = ['rsync', '--recursive', '--checksum', '--delay-updates',
                       '--no-perms', '--no-owner', '--no-group', '--omit-dir-times',
                       '--itemize-changes', '--timeout=90', '--from0',
                       '--files-from=' + str(file_list), '-e', shlex.join(ssh_args())]
            if args.dry_run:
                command.append('--dry-run')
            command += [str(folder) + '/', 'alfa-deploy@193.181.221.27:./']
            subprocess.run(command, check=True, timeout=600)
        if not args.dry_run:
            print(remote('alfastroi-finish', plan), flush=True)
        summary = ('Dry run: no site files written.' if args.dry_run else 'Deployment verified.')
        summary += '\nFiles: ' + str(len(plan['files'])) + '\nCommit: ' + head + '\n'
        print(summary)
        if os.environ.get('GITHUB_STEP_SUMMARY'):
            with open(os.environ['GITHUB_STEP_SUMMARY'], 'a') as out:
                out.write(summary)


if __name__ == '__main__':
    try:
        main()
    except (ValueError, OSError, subprocess.SubprocessError) as error:
        print('Deployment stopped:', error, file=sys.stderr)
        sys.exit(1)
