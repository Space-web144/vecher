"""Publish only the reviewed mascot/menu files; retain server edits elsewhere."""
import ftplib
import hashlib
import io
import json
import os
from pathlib import Path
import ssl

FILES = (
    'web/structure_lib.php', 'web/structure.php', 'web/assets/refresh.css',
    'web/assets/alfik.svg', 'web/assets/alfik-animation.webp',
    'web/alfik_context_lib.php', 'web/alfik.php',
    'web/sidebar_refresh.php', 'web/sidebar.php',
)


def digest(data):
    return hashlib.sha256(data).hexdigest()


def deploy(ftp, backup, plan):
    if set(plan['files']) != set(FILES):
        raise RuntimeError('Unexpected interface whitelist')
    def read(path):
        out = io.BytesIO()
        ftp.retrbinary('RETR ' + path, out.write)
        return out.getvalue()
    def save(kind, path, data):
        target = backup / kind / path
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
    def guards():
        hashes = {path: digest(read(path)) for path in plan['preserve']}
        if hashes != plan['preserve']:
            raise RuntimeError('Protected converter files changed; publication stopped')
        return hashes

    desired = {path: Path(path).read_bytes() for path in FILES}
    before = {}
    # Read and compare every target before the first mutation.
    for path in FILES:
        current = read(path)
        before[path] = current
        save('before', path, current)
        if digest(current) != plan['files'][path] and current != desired[path]:
            raise RuntimeError('Unreviewed server changes; nothing uploaded: ' + path)
    preserved_before = guards()
    changed = []
    for path in FILES:
        current = read(path)
        if current != before[path]:
            raise RuntimeError('Concurrent server edit: ' + path)
        if current == desired[path]:
            continue
        parent, name = path.rsplit('/', 1)
        temporary = parent + '/.in.interface-' + name
        ftp.storbinary('STOR ' + temporary, io.BytesIO(desired[path]))
        if read(temporary) != desired[path]:
            raise RuntimeError('Temporary copy differs: ' + path)
        ftp.rename(temporary, path)
        changed.append(path)
    # Read back every target, including unchanged sprite assets.
    for path in FILES:
        actual = read(path)
        save('after', path, actual)
        if actual != desired[path]:
            raise RuntimeError('Published file differs: ' + path)
        print('Verified: ' + path)
    preserved_after = guards()
    (backup / 'result.json').write_text(json.dumps({
        'changed': changed, 'verified': list(FILES),
        'preserved_before': preserved_before, 'preserved_after': preserved_after,
        'snapshot_run': plan['snapshot_run'],
    }, ensure_ascii=False, indent=2), encoding='utf-8')
    print('Converter preserved; changed %s interface files' % len(changed))


def main():
    plan = json.loads(Path('.github/deploy/interface-plan.json').read_text(encoding='utf-8'))
    server = os.environ['FTP_SERVER'].strip().removeprefix('ftp://').rstrip('/')
    host, sep, port = server.partition(':')
    context = ssl.create_default_context()
    if os.environ.get('FTP_TLS_VERIFY') == 'off':
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
    tls = os.environ.get('FTP_TLS') != 'off'
    ftp = ftplib.FTP_TLS(context=context, timeout=45) if tls else ftplib.FTP(timeout=45)
    try:
        ftp.connect(host, int(port) if sep else 21)
        ftp.login(os.environ['FTP_USERNAME'].strip(), os.environ['FTP_PASSWORD'])
        if tls:
            ftp.prot_p()
        ftp.cwd(os.environ.get('FTP_DIR') or '.')
        ftp.voidcmd('TYPE I')
        ftp.size('web/config.php')
        deploy(ftp, Path(os.environ['RUNNER_TEMP']) / 'interface-backup', plan)
    finally:
        ftp.close()


if __name__ == '__main__':
    main()
