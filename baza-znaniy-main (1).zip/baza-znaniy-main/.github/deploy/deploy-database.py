"""Publish only the database catalog chooser; preserve all other server files."""
import ftplib
import hashlib
import io
import json
import os
from pathlib import Path
import ssl


TARGET = 'web/onec_database.php'
# Verified after the catalog chooser deployment, run 43849127794.
SERVER_BASELINE = 'ed07834d31a240452934c3f6382072e6246138d9e9de9d4d7a71d02d60ae453d'


def deploy(ftp, backup):
    def read(path):
        data = io.BytesIO()
        ftp.retrbinary('RETR ' + path, data.write)
        return data.getvalue()

    def save(kind, data):
        path = backup / kind / TARGET
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes(data)

    desired = Path(TARGET).read_bytes()
    before = read(TARGET)
    save('before', before)
    if hashlib.sha256(before).hexdigest() != SERVER_BASELINE and before != desired:
        raise RuntimeError('Unreviewed server changes; nothing uploaded: ' + TARGET)
    if before != desired:
        temporary = 'web/.in.database-onec_database.php'
        ftp.storbinary('STOR ' + temporary, io.BytesIO(desired))
        if read(temporary) != desired:
            raise RuntimeError('Temporary copy differs: ' + TARGET)
        if read(TARGET) != before:
            raise RuntimeError('Concurrent server edit; publication stopped: ' + TARGET)
        ftp.rename(temporary, TARGET)
    after = read(TARGET)
    save('after', after)
    if after != desired:
        raise RuntimeError('Published file differs: ' + TARGET)
    (backup / 'result.json').write_text(json.dumps({
        'changed': [TARGET] if before != after else [],
        'verified': TARGET,
        'before_sha256': hashlib.sha256(before).hexdigest(),
        'after_sha256': hashlib.sha256(after).hexdigest(),
        'snapshot_run': 43849127794,
    }, indent=2), encoding='utf-8')
    print('Verified: ' + TARGET)
    print('Only the catalog page was published; database files were not modified.')


def main():
    server = os.environ['FTP_SERVER'].strip().removeprefix('ftp://').rstrip('/')
    host, sep, port = server.partition(':')
    context = ssl.create_default_context()
    if os.environ.get('FTP_TLS_VERIFY') == 'off':
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
    tls = os.environ.get('FTP_TLS') != 'off'
    ftp = ftplib.FTP_TLS(context=context, timeout=45) if tls else ftplib.FTP(timeout=45)
    try:
        ftp.connect(host, int(port) if sep else 21)
        ftp.login(os.environ['FTP_USERNAME'].strip(), os.environ['FTP_PASSWORD'])
        if tls:
            ftp.prot_p()
        ftp.cwd(os.environ.get('FTP_DIR') or '.')
        ftp.voidcmd('TYPE I')
        deploy(ftp, Path(os.environ['RUNNER_TEMP']) / 'database-backup')
    finally:
        ftp.close()


if __name__ == '__main__':
    main()
