"""Transfer a reviewed catalog to protected runtime storage, without Git data.

Workflow inputs carry bounded base64 chunks, never shell commands. Only the
complete payload with the reviewed checksum/count can replace the VK catalog.
"""
import base64
import ftplib
import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import re
import ssl
import sys

sys.path.insert(0, str(Path(__file__).resolve().parents[2]))
from common.vk_catalog import validate_catalog

TARGET = 'web/data/1c_vk_catalog.json'
MAX_JSON_BYTES = 20 * 1024 * 1024
MAX_CHUNKS = 30


def inputs(event):
    data = event.get('inputs', {})
    checksum = data.get('payload_sha256', '')
    previous = data.get('expected_previous_sha256', 'missing')
    if not re.fullmatch(r'[0-9a-f]{64}', checksum):
        raise ValueError('Invalid payload checksum')
    if previous != 'missing' and not re.fullmatch(r'[0-9a-f]{64}', previous):
        raise ValueError('Invalid previous catalog checksum')
    index, total, count = (int(data[key]) for key in ('chunk_index', 'total_chunks', 'expected_items'))
    if not 1 <= total <= MAX_CHUNKS or not 0 <= index < total or not 1 <= count <= 100000:
        raise ValueError('Invalid chunk or item count')
    encoded = data.get('chunk', '')
    if not isinstance(encoded, str) or not 1 <= len(encoded) <= 50000:
        raise ValueError('Invalid chunk size')
    chunk = base64.b64decode(encoded, validate=True)
    return checksum, previous, index, total, count, chunk


def transfer(ftp, event, result_dir):
    checksum, previous, index, total, count, chunk = inputs(event)
    result_dir.mkdir(parents=True, exist_ok=True)
    prefix = 'web/data/.vk-import-' + checksum[:24]
    paths = [prefix + '-%02d.part' % n for n in range(total)]

    def read(path, missing=False, maximum=MAX_JSON_BYTES):
        out = io.BytesIO()
        def append(value):
            if out.tell() + len(value) > maximum:
                raise ValueError('Remote import file exceeds limit')
            out.write(value)
        try:
            ftp.retrbinary('RETR ' + path, append)
        except ftplib.error_perm as error:
            if missing and str(error).startswith('550'):
                return None
            raise
        return out.getvalue()

    def digest(data):
        return hashlib.sha256(data).hexdigest()

    # Catalog payloads stay in existing denied runtime storage, not public files.
    protection = read('web/data/.htaccess', maximum=8192)
    if not re.search(rb'(?im)^\s*(Require\s+all\s+denied|Deny\s+from\s+all)\s*$', protection):
        raise RuntimeError('Runtime storage protection not confirmed')
    before = read(TARGET, missing=True)
    before_hash = digest(before) if before is not None else 'missing'
    # A repeated dispatch after successful import verifies the same reviewed payload.
    if before is not None:
        try:
            existing = json.loads(before)
        except (ValueError, UnicodeError):
            existing = {}
        if existing.get('import_payload_sha256') == checksum:
            validate_catalog(existing, count)
            result = {'complete': True, 'idempotent': True, 'items': count,
                      'missing_units': existing['missing_units'], 'target_sha256': before_hash}
            (result_dir / 'result.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
            print('Verified existing VK catalog: %s records' % count)
            return result
    if before_hash != previous:
        raise RuntimeError('VK catalog changed since review; import stopped')

    path = paths[index]
    existing_chunk = read(path, missing=True, maximum=40000)
    if existing_chunk is not None and existing_chunk != chunk:
        raise RuntimeError('Conflicting import chunk; nothing replaced')
    temporary = path + '.tmp'
    ftp.storbinary('STOR ' + temporary, io.BytesIO(chunk))
    if read(temporary, maximum=40000) != chunk:
        raise RuntimeError('Uploaded chunk differs')
    ftp.rename(temporary, path)
    chunks = [read(part, missing=True, maximum=40000) for part in paths]
    if any(part is None for part in chunks):
        result = {'complete': False, 'received': sum(part is not None for part in chunks), 'total': total}
        (result_dir / 'result.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
        print('VK import staged: %s of %s chunks' % (result['received'], total))
        return result

    payload = b''.join(chunks)
    if digest(payload) != checksum:
        raise RuntimeError('Complete import checksum differs; catalog not replaced')
    with gzip.GzipFile(fileobj=io.BytesIO(payload)) as stream:
        raw = stream.read(MAX_JSON_BYTES + 1)
    if len(raw) > MAX_JSON_BYTES:
        raise ValueError('Catalog exceeds size limit')
    catalog = validate_catalog(json.loads(raw), count)
    catalog['import_payload_sha256'] = checksum
    desired = json.dumps(catalog, ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    temporary = 'web/data/.in.vk-catalog.json'
    ftp.storbinary('STOR ' + temporary, io.BytesIO(desired))
    if read(temporary) != desired:
        raise RuntimeError('Uploaded VK catalog differs')
    if read(TARGET, missing=True) != before:
        raise RuntimeError('Concurrent VK edit; catalog not replaced')
    if before is not None:
        ftp.storbinary('STOR web/data/.vk-catalog-previous.json', io.BytesIO(before))
    ftp.rename(temporary, TARGET)
    after = read(TARGET)
    if after != desired:
        raise RuntimeError('Published VK catalog differs')
    verified = validate_catalog(json.loads(after), count)
    for part in paths:
        ftp.delete(part)
    result = {'complete': True, 'items': count, 'missing_units': verified['missing_units'],
              'source_sha256': verified.get('source', {}).get('sha256'),
              'before_sha256': before_hash, 'target_sha256': digest(after),
              'payload_sha256': checksum, 'target': TARGET}
    (result_dir / 'result.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print('Verified VK catalog: %s records, %s without unit' % (count, verified['missing_units']))
    return result


def main():
    event = json.loads(Path(os.environ['GITHUB_EVENT_PATH']).read_text(encoding='utf-8'))
    inputs(event)  # Reject malformed input before connecting or writing.
    server = os.environ['FTP_SERVER'].strip().removeprefix('ftp://').rstrip('/')
    host, sep, port = server.partition(':')
    context = ssl.create_default_context()
    if os.environ.get('FTP_TLS_VERIFY') == 'off':
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
    tls = os.environ.get('FTP_TLS') != 'off'
    ftp = ftplib.FTP_TLS(context=context, timeout=45) if tls else ftplib.FTP(timeout=45)
    try:
        ftp.connect(host, int(port) if sep else 21)
        ftp.login(os.environ['FTP_USERNAME'].strip(), os.environ['FTP_PASSWORD'])
        if tls:
            ftp.prot_p()
        ftp.cwd(os.environ.get('FTP_DIR') or '.')
        ftp.voidcmd('TYPE I')
        transfer(ftp, event, Path(os.environ['RUNNER_TEMP']) / 'vk-import-result')
    finally:
        ftp.close()


if __name__ == '__main__':
    main()
