"""Publish only equipment sources; preserve converters, permissions and mascot."""
import ftplib
import hashlib
import io
import json
import os
from pathlib import Path
import ssl

FILES = ('program-a/equipment_table.py', 'program-a/equipment_pipeline.py',
         'program-a/web_pdf_run.py', 'web/equipment.php')


def digest(data):
    return hashlib.sha256(data).hexdigest() if data is not None else None


def deploy(ftp, backup, plan):
    if set(plan['files']) != set(FILES):
        raise RuntimeError('Unexpected equipment whitelist')
    def read(path):
        out = io.BytesIO()
        ftp.retrbinary('RETR ' + path, out.write)
        return out.getvalue()
    def target(path):
        try:
            return read(path)
        except ftplib.error_perm as exc:
            if plan['files'][path] is not None or not str(exc).startswith('550'):
                raise
            return None
    def save(kind, path, data):
        if data is not None:
            p = backup / kind / path
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(data)
    def guards():
        actual = {p: digest(read(p)) for p in plan['preserve']}
        if actual != plan['preserve']:
            raise RuntimeError('Protected server sources changed; publication stopped')
        return actual
    desired = {p: Path(p).read_bytes() for p in FILES}
    before = {}
    for p in FILES:
        current = target(p)
        before[p] = current
        save('before', p, current)
        if digest(current) != plan['files'][p] and current != desired[p]:
            raise RuntimeError('Unreviewed server changes: ' + p)
    preserved_before = guards()
    changed = []
    for p in FILES:
        if target(p) != before[p]:
            raise RuntimeError('Concurrent server edit: ' + p)
        if before[p] == desired[p]:
            continue
        parent, name = p.rsplit('/', 1)
        temporary = parent + '/.in.equipment-' + name
        ftp.storbinary('STOR ' + temporary, io.BytesIO(desired[p]))
        if read(temporary) != desired[p]:
            raise RuntimeError('Temporary source differs: ' + p)
        ftp.rename(temporary, p)
        changed.append(p)
    for p in FILES:
        actual = read(p)
        save('after', p, actual)
        if actual != desired[p]:
            raise RuntimeError('Published source differs: ' + p)
        print('Verified: ' + p)
    preserved_after = guards()
    (backup / 'result.json').write_text(json.dumps(dict(changed=changed, verified=list(FILES),
        preserved_before=preserved_before, preserved_after=preserved_after), indent=2))


def main():
    plan = json.loads(Path('.github/deploy/equipment-plan.json').read_text())
    host, sep, port = os.environ['FTP_SERVER'].strip().removeprefix('ftp://').rstrip('/').partition(':')
    context = ssl.create_default_context()
    if os.environ.get('FTP_TLS_VERIFY') == 'off':
        context.check_hostname = False
        context.verify_mode = ssl.CERT_NONE
    tls = os.environ.get('FTP_TLS') != 'off'
    ftp = ftplib.FTP_TLS(context=context, timeout=45) if tls else ftplib.FTP(timeout=45)
    try:
        ftp.connect(host, int(port) if sep else 21)
        ftp.login(os.environ['FTP_USERNAME'].strip(), os.environ['FTP_PASSWORD'])
        if tls:
            ftp.prot_p()
        ftp.cwd(os.environ.get('FTP_DIR') or '.')
        ftp.voidcmd('TYPE I')
        ftp.size('web/config.php')
        deploy(ftp, Path(os.environ['RUNNER_TEMP']) / 'equipment-backup', plan)
        if os.environ.get('EQUIPMENT_SMOKE') == 'true':
            from smoke_equipment import run
            run(ftp, Path(os.environ['RUNNER_TEMP']) / 'equipment-backup' / 'smoke')
    finally:
        ftp.close()


if __name__ == '__main__':
    main()
