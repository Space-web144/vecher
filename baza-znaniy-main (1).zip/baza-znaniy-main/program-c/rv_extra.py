# -*- coding: utf-8 -*-
"""
Работы без материалов в РВ: гидроиспытания, испытание и наладка, ПНР, сдача
систем СКБ. В ЛРВ под ними строк нет, поэтому инструмент привязки их не
выводит; в ТКП из 1С они есть (форма «Гидравлическое испытание трубопроводов
… 805,36 пог. м»). Решение владельца 01.11.2026: агент добавляет их сам —
по каждому элементу РВ, объём — из работ, которые уже есть в РВ.

  ВК    гидроиспытание каждой системы с трубами (ветки 1–6) — Σ метров прокладки
        трубопроводов этой ветки; шахт-пакеты (ветка 7) — Σ штук монтажа
        шахт-пакетов (тип 1 «без К1» по умолчанию — проверить);
  ОВ1   гидроиспытание 9.1.1 — Σ метров прокладки трубопроводов элемента;
  ОВ2   «Испытание и наладка системы» каждой ветки (ОВ, ПДВ) — 1 комплекс, проверить;
  ЭОМ   ПНР ВРУ — Σ штук «Установка и коммутация щитов ВРУ»;
  СКБ   сдача систем в эксплуатирующую организацию (и ПНР ЭОМ) — 1 комплекс на раздел.

СС (ПНР по подсистемам и видам оборудования) пока не добавляется — нужно
правило объёма. Варианты «СКБ» берутся только у объектов СКБ.
Каждая добавленная работа помечена auto и попадает «на проверку».
"""
import re

TEST_RE = re.compile(r"^Гидравлическое испытание трубопроводов")
PIPE_RE = re.compile(r"^Прокладка трубопроводов")


def _parts(code):
    return code.split(".")


def _num(value):
    try:
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _find(works, prefix, name_re, skb):
    """Действующие коды с префиксом и именем по шаблону; СКБ-вариант — только для объектов СКБ."""
    found = []
    for code, name in works.items():
        if not code.startswith(prefix) or not name_re.search(name) or "НЕ ИСПОЛЬЗ" in name.upper():
            continue
        if ("СКБ" in name) != skb:
            continue
        if "Москва" in name:
            continue
        found.append(code)
    return sorted(found, key=lambda c: [int(x) for x in c.split(".") if x.isdigit()])


def _work(code, works, unit, volume, method, note):
    return dict(code=code, work=works.get(code, "")[:120], unit=unit, volume=round(volume, 4) if volume else volume,
                method=method, materials=[], auto=True, note=note)


def add_works(section, rv_works, works, kc, object_type=None):
    """Работы без материалов для блока РВ (раздел × элемент). rv_works — работы блока (bind.rv),
    works — код → имя (bind.KB['works']), kc — bind.KB['kc'] (единицы). Возвращает новые работы."""
    skb = (object_type or "") == "СКБ"
    have = {w["code"] for w in rv_works}
    unit_of = lambda code: (kc.get(code) or {}).get("unit", "")  # noqa: E731
    added = []

    def add(code, volume, method, note):
        if code and code not in have and volume:
            added.append(_work(code, works, unit_of(code), volume, method, note))
            have.add(code)

    def volume_where(cond):
        return sum(_num(w.get("volume")) for w in rv_works if cond(w))

    if section == "ВК":
        branches = sorted({_parts(w["code"])[4] for w in rv_works if len(_parts(w["code"])) > 5})
        for branch in branches:
            if branch in ("1", "2", "3", "4", "5", "6"):
                metres = volume_where(lambda w: _parts(w["code"])[4] == branch and PIPE_RE.search(works.get(w["code"], ""))
                                      and unit_of(w["code"]) in ("м", "пог. м"))
                codes = _find(works, "6.2.3.1.%s." % branch, TEST_RE, skb)
                if codes:
                    add(codes[0], metres, "объём = сумма длин трубопроводов системы (%s м)" % _fmt(metres),
                        "добавлено агентом: работа без материалов — гидроиспытание системы")
            elif branch == "7":
                count = volume_where(lambda w: w["code"].startswith("6.2.3.1.7.") and works.get(w["code"], "").startswith("Монтаж шахт-пакетов"))
                add("6.2.3.1.7.3.1" if "6.2.3.1.7.3.1" in works else None, count,
                    "объём = число шахт-пакетов (%s шт)" % _fmt(count),
                    "добавлено агентом: гидроиспытание шахт-пакетов; тип 1 «без К1» — проверить, если в шахт-пакетах есть К1 — тип 2")
        if skb:
            add(_first(works, "6.2.3.1.99.", r"^Сдача систем"), 1, "1 комплекс на раздел", "добавлено агентом: объект СКБ — сдача систем")
    elif section == "ОВ1":
        metres = volume_where(lambda w: PIPE_RE.search(works.get(w["code"], "")) and unit_of(w["code"]) in ("м", "пог. м"))
        codes = _find(works, "6.2.3.2.9.", TEST_RE, skb)
        if codes:
            add(codes[0], metres, "объём = сумма длин трубопроводов элемента (%s м)" % _fmt(metres),
                "добавлено агентом: работа без материалов — гидроиспытание системы отопления")
        if skb:
            add(_first(works, "6.2.3.2.9.", r"^Сдача систем"), 1, "1 комплекс на раздел", "добавлено агентом: объект СКБ — сдача систем")
    elif section == "ОВ2":
        branches = sorted({_parts(w["code"])[4] for w in rv_works if len(_parts(w["code"])) > 5 and _parts(w["code"])[4] in ("1", "2")})
        for branch in branches:
            add(_first(works, "6.2.3.3.%s.99." % branch, r"^Испытание и наладка системы"), 1,
                "1 комплекс на систему — уточнить по числу систем",
                "добавлено агентом: работа без материалов — испытание и наладка; объём проверить")
            if skb:
                add(_first(works, "6.2.3.3.%s.99." % branch, r"^Сдача систем"), 1, "1 комплекс на систему",
                    "добавлено агентом: объект СКБ — сдача систем")
    elif section == "ЭОМ":
        panels = volume_where(lambda w: works.get(w["code"], "").startswith("Установка и коммутация щитов ВРУ"))
        add("6.2.3.4.1.1.5.1" if "6.2.3.4.1.1.5.1" in works else None, panels,
            "объём = число щитов ВРУ (%s шт)" % _fmt(panels), "добавлено агентом: работа без материалов — ПНР ВРУ")
        if skb:
            add(_first(works, "6.2.3.4.5.", r"^Пуско-наладочные работы СКБ"), 1, "1 комплекс на раздел",
                "добавлено агентом: объект СКБ — ПНР ЭОМ")
            add(_first(works, "6.2.3.4.5.", r"^Сдача систем в эксплуатирующую организацию СКБ \("), 1, "1 комплекс на раздел",
                "добавлено агентом: объект СКБ — сдача систем")
    return added


def _first(works, prefix, pattern):
    regex = re.compile(pattern)
    codes = sorted((c for c, n in works.items() if c.startswith(prefix) and regex.search(n) and "Москва" not in n
                    and "НЕ ИСПОЛЬЗ" not in n.upper()),
                   key=lambda c: [int(x) for x in c.split(".") if x.isdigit()])
    return codes[0] if codes else None


def _fmt(value):
    text = ("%.2f" % value).rstrip("0").rstrip(".")
    return text.replace(".", ",")
