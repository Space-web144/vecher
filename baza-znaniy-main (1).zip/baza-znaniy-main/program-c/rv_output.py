# -*- coding: utf-8 -*-
"""
Книга Excel с результатом агента РВ.

Первый лист — «РВ» в форме ТКП (rv_form.py: иерархия ИСР, работы с объёмом,
материалы с коэффициентом расхода, колонки проверки). Дальше — как просит
мастер-инструкция (A15): «Сводка», «Работы», «Строки ЛРВ», «Кр», «Вопросы»
и «Проверка» с рекомендациями модели по строкам «на проверку» (их решает
человек: рекомендация РВ не меняет).
"""
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter

HEAD_FILL = PatternFill("solid", fgColor="FFE4E2DD")
REVIEW_FILL = PatternFill("solid", fgColor="FFFDF6E6")   # жёлтый — на проверку
QUESTION_FILL = PatternFill("solid", fgColor="FFFCEFEC")  # красный — вопрос
DONE_FILL = PatternFill("solid", fgColor="FFEDF7F0")

DECISION_FILL = {"готово": None, "на проверку": REVIEW_FILL, "вопрос": QUESTION_FILL}


def _sheet(book, title, columns, widths):
    sheet = book.create_sheet(title)
    sheet.append(columns)
    for cell in sheet[1]:
        cell.font = Font(bold=True)
        cell.fill = HEAD_FILL
        cell.alignment = Alignment(wrap_text=True, vertical="top")
    for index, width in enumerate(widths, start=1):
        sheet.column_dimensions[get_column_letter(index)].width = width
    sheet.freeze_panes = "A2"
    sheet.auto_filter.ref = "A1:%s1" % get_column_letter(len(columns))
    return sheet


def _fill_row(sheet, row_index, fill):
    if fill is None:
        return
    for cell in sheet[row_index]:
        cell.fill = fill


def percent(value):
    """Уверенность 0–1 → целые проценты для человека."""
    try:
        return int(round(float(value) * 100))
    except (TypeError, ValueError):
        return None


def decision(binding):
    if not binding.get("code"):
        return "вопрос"
    return "на проверку" if binding.get("review") else "готово"


def build_workbook(path, result, form_rows=None):
    """result — словарь из web_rv_run: section, object_type, elements:
    [{element, items, bindings, rv, volumes, distribution}], review,
    questions, notes, summary. form_rows — строки формы (rv_form.build_rows);
    без них лист «РВ» не пишется."""
    book = Workbook()
    book.remove(book.active)
    if form_rows:
        import rv_form
        rv_form.write_sheet(book, result, form_rows)

    # ── Сводка ──
    summary = result["summary"]
    sheet = book.create_sheet("Сводка")
    sheet.column_dimensions["A"].width = 44
    sheet.column_dimensions["B"].width = 70
    rows = [
        ("Раздел" + ("ы" if len(result.get("sections") or []) > 1 else ""), result["section"]),
        ("Тип объекта", result.get("object_type") or "не указан"),
        ("Файл ЛРВ", result.get("source_name", "")),
        ("Формат файла", "отчёт 1С с группировкой по системам" if result.get("format") == "1c_report" else "таблица"),
        ("Строк ЛРВ в работе", summary["rows"]),
        ("из них готово", summary["done"]),
        ("на проверку", summary["review"]),
        ("вопросов (без работы)", summary["unbound"]),
        ("Не включено (накладные, вспомогательные)", summary.get("skipped", 0)),
        ("Работ", summary["works"]),
        ("из них с объёмом", summary["works_with_volume"]),
        ("Строк Кр", summary["kr"]),
        ("распределено по потребителям", summary["kr_distributed"]),
        ("Элементов (раздел × элемент)", summary["elements"]),
        ("Единицы: из библиотеки / по типу материала", "%d / %d" % (summary.get("units_from_library", 0), summary.get("units_guessed", 0))
         if summary.get("units_from_library") or summary.get("units_guessed") else "из файла"),
        ("Проверка моделью", summary.get("review_note", "")),
        ("Решения инженеров", "исправлено %d, подтверждено %d" % (summary["learned"].get("corrected", 0), summary["learned"].get("confirmed", 0))
         if summary.get("learned") else "не применялись"),
    ]
    for label, value in rows:
        sheet.append([label, value])
    sheet["A1"].font = Font(bold=True)
    for row in sheet.iter_rows(min_row=1, max_row=sheet.max_row):
        row[0].font = Font(bold=True)
    if result.get("notes"):
        sheet.append([])
        sheet.append(["Принятые умолчания и замечания"])
        sheet.cell(row=sheet.max_row, column=1).font = Font(bold=True)
        for note in result["notes"]:
            sheet.append(["", note])

    # ── Работы ──
    works_sheet = _sheet(book, "Работы",
                         ["Код", "Работа", "Элемент", "Ед.", "Объём", "Способ расчёта объёма", "Строк ЛРВ", "Флаги"],
                         [20, 60, 18, 8, 12, 44, 10, 30])
    for block in result["elements"]:
        for work in block["rv"]["works"]:
            flags = sorted({f for m in work.get("materials", []) for f in _flags_of(block, m.get("id"))})
            works_sheet.append([work["code"], work["work"], block["element"], work.get("unit"),
                                work.get("volume"), work.get("method"), len(work.get("materials", [])),
                                "; ".join(f for f in flags if f.startswith("F-VOL") or f.startswith("F-ZERO"))])

    # ── Строки ЛРВ ──
    lines = _sheet(book, "Строки ЛРВ",
                   ["id", "Наименование (1С)", "Ед.", "Кол-во", "Система", "Элемент", "Код работы", "Работа",
                    "Роль", "Часть (Кр)", "Уверенность, %", "Источник", "Флаги", "Решение", "Рекомендация модели"],
                   [6, 54, 7, 10, 12, 16, 20, 50, 7, 11, 11, 40, 36, 13, 60])
    review = result.get("review") or {}
    for block in result["elements"]:
        by_id = {it["id"]: it for it in block["items"]}
        parts = {d["id"]: d for d in block["distribution"]}
        for binding in block["bindings"]:
            item = by_id[binding["id"]]
            dec = decision(binding)
            rec = review.get(str(binding["id"]))
            rec_text = ""
            if rec:
                rec_text = rec["verdict"]
                if rec.get("code"):
                    rec_text += ": %s %s" % (rec["code"], rec.get("work", ""))
                if rec.get("role"):
                    rec_text += " (роль %s)" % rec["role"]
                if rec.get("reason"):
                    rec_text += " — " + rec["reason"]
                if rec.get("question"):
                    rec_text += " Вопрос: " + rec["question"]
            common = [binding["id"], item["name"], item.get("unit"), item.get("qty"), item.get("system") or "",
                      block["element"], binding.get("code") or "", binding.get("work") or "", binding.get("role") or ""]
            tail = [percent(binding.get("confidence")), binding.get("source") or "", "; ".join(binding.get("flags") or []),
                    dec, rec_text]
            split = (parts.get(binding["id"]) or {}).get("split") or []
            if binding.get("role") == "Кр" and split:
                for part in split:
                    lines.append(common[:6] + [part.get("code"), part.get("work", ""), "Кр", part.get("qty")] + tail)
                    _fill_row(lines, lines.max_row, DECISION_FILL[dec])
            else:
                lines.append(common + [""] + tail)
                _fill_row(lines, lines.max_row, DECISION_FILL[dec])

    # ── Кр ──
    kr_sheet = _sheet(book, "Кр", ["id", "Наименование (1С)", "Ед.", "Кол-во", "Система", "Элемент",
                                    "Код работы-потребителя", "Работа", "Часть", "Флаги"],
                      [6, 54, 7, 10, 12, 16, 20, 50, 11, 30])
    for block in result["elements"]:
        by_id = {it["id"]: it for it in block["items"]}
        by_binding = {b["id"]: b for b in block["bindings"]}
        for dist in block["distribution"]:
            item = by_id.get(dist["id"])
            binding = by_binding.get(dist["id"], {})
            if not item:
                continue
            if not dist.get("split"):
                kr_sheet.append([item["id"], item["name"], item.get("unit"), item.get("qty"), item.get("system") or "",
                                 block["element"], binding.get("code") or "", binding.get("work") or "", item.get("qty"),
                                 "; ".join(binding.get("flags") or [])])
                _fill_row(kr_sheet, kr_sheet.max_row, REVIEW_FILL)
                continue
            for part in dist["split"]:
                kr_sheet.append([item["id"], item["name"], item.get("unit"), item.get("qty"), item.get("system") or "",
                                 block["element"], part.get("code"), part.get("work", ""), part.get("qty"),
                                 "; ".join(binding.get("flags") or [])])

    # ── Вопросы ──
    q_sheet = _sheet(book, "Вопросы", ["Тип", "id", "Наименование (1С)", "Система", "Элемент", "Вопрос"],
                     [14, 6, 54, 12, 16, 80])
    for block in result["elements"]:
        by_id = {it["id"]: it for it in block["items"]}
        for binding in block["bindings"]:
            if binding.get("code"):
                continue
            item = by_id[binding["id"]]
            rec = review.get(str(binding["id"])) or {}
            q_sheet.append(["строка без работы", item["id"], item["name"], item.get("system") or "", block["element"],
                            rec.get("question") or rec.get("reason") or "; ".join(binding.get("flags") or []) or
                            "Работа не определена"])
    for question in result.get("questions") or []:
        q_sheet.append(["вопрос владельцу", "", "", "", "", question])
    for note in result.get("notes") or []:
        q_sheet.append(["умолчание", "", "", "", "", note])

    # ── Проверка ──
    r_sheet = _sheet(book, "Проверка", ["id", "Наименование (1С)", "Элемент", "Код инструмента", "Работа инструмента",
                                        "Уверенность, %", "Вердикт модели", "Код модели", "Работа модели", "Роль", "Причина", "Вопрос"],
                     [6, 54, 16, 20, 44, 12, 14, 20, 44, 7, 60, 50])
    for block in result["elements"]:
        by_id = {it["id"]: it for it in block["items"]}
        for binding in block["bindings"]:
            rec = review.get(str(binding["id"]))
            if not rec:
                continue
            item = by_id[binding["id"]]
            r_sheet.append([binding["id"], item["name"], block["element"], binding.get("code") or "",
                            binding.get("work") or "", percent(binding.get("confidence")), rec["verdict"], rec.get("code", ""), rec.get("work", ""),
                            rec.get("role", ""), rec.get("reason", ""), rec.get("question", "")])
            fill = {"подтвердить": DONE_FILL, "заменить": REVIEW_FILL, "вопрос": QUESTION_FILL}.get(rec["verdict"])
            _fill_row(r_sheet, r_sheet.max_row, fill)

    book.save(path)


def _flags_of(block, item_id):
    for binding in block["bindings"]:
        if binding["id"] == item_id:
            return binding.get("fcodes") or []
    return []
