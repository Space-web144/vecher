# -*- coding: utf-8 -*-
"""Тесты разбора ТКП заказчика (program-c/tkp_customer.py) на выдуманных данных: настоящие ТКП - коммерческие,
в репозиторий не кладутся. Запуск: python3 -m unittest program-c.tests.test_tkp_customer (из корня репозитория)."""
import json
import os
import sys
import tempfile
import unittest

HERE = os.path.dirname(os.path.abspath(__file__))
PROGRAM_C = os.path.dirname(HERE)
if PROGRAM_C not in sys.path:
    sys.path.insert(0, PROGRAM_C)

import tkp_customer  # noqa: E402

try:
    import openpyxl  # noqa: F401
    HAS_OPENPYXL = True
except ImportError:
    HAS_OPENPYXL = False

WIDTH = 42  # A..AP


def _row(**cells):
    """Строка листа: {буква: значение}."""
    out = [None] * WIDTH
    for letter, value in cells.items():
        out[tkp_customer._col(letter)] = value
    return tuple(out)


def sheet(version="200", qty_pipe=10, price_pipe=500.0, extra_work=False, drop_mat=False):
    """Выдуманное ТКП: один блок, узел, две работы с материалами; параметры - для второй версии."""
    head = _row(A="Указать название организации", D=json.dumps({"estimateId": 100, "estimateVersionId": int(version)}),
                AC="object_element_guid", AD="id", AE="zeroParent_id", AF="material_guid", AG="work_guid",
                AH="hwd_guid", AI="cost_item_guid")
    rows = [
        head,
        _row(A="ТЕХНИКО-КОММЕРЧЕСКОЕ ПРЕДЛОЖЕНИЕ (ТКП)"),
        _row(A="г. Москва, Тестовый пр., 1"),
        _row(A="Стоимость включает всё"),
        _row(A="Номер п/п", B="Код узла ИСР", C="Наименование затрат", F="Ед. изм.", J="ПСПР", P="ООО Подрядчик", S="7700000000"),
        _row(J="Цена, руб.с НДС 22%"),
        _row(J="Материалы/\nоборудование"),
        _row(A="1. Тестовый корпус", AC="blk-guid-1", M=1000.0, N=2000.0, O=3000.0, S=900.0, T=1800.0, U=2700.0),
        _row(A="1.1", B="6.2.3.1", C="Водоснабжение и канализация", AE=11, AD=9011),
        _row(A="1.1.1", B="6.2.3.1.1.1.1.1", C="Прокладка трубопроводов из ПП", F="м", G=1.0, I=qty_pipe,
             J=400.0, K=150.0, L=550.0, P=price_pipe, Q=140.0, R=price_pipe + 140.0, AE=12, AD="9012", AG="w-1"),
        _row(A="1.1.1.1", C="Труба ПП 110", F="м", G=1, I=qty_pipe, J=400.0, P=price_pipe, AE="12.501", AD="9012.501", AF="m-501"),
    ]
    if not drop_mat:
        rows.append(_row(A="1.1.1.2", C="Отвод ПП 110", F="шт", G=0.3, I=3, J=50.0, P=45.0, AE="12.502", AD="9012.502", AF="m-502"))
    rows.append(_row(A="1.1.2", B="6.2.3.1.1.5.1.1", C="Гидравлическое испытание", F="м", G=1.0, I=qty_pipe,
                     K=30.0, L=30.0, Q="#VALUE!", AE=13, AD=9013))
    if extra_work:
        rows.append(_row(A="1.1.3", B="6.2.3.1.1.2.4.1", C="Монтаж муфт противопожарных", F="шт", I=4, K=400.0, Q=380.0, AE=14, AD=9014))
    rows.append(_row())
    rows.append(_row(A="Квалификационная и контактная информация"))
    rows.append(_row(B="П", C="Сайт компании"))
    return rows


class ParseTest(unittest.TestCase):
    def test_kinds_ids_and_parents(self):
        data = tkp_customer.parse_rows(sheet())
        self.assertEqual(data["estimate_id"], "100")
        self.assertEqual(data["version_id"], "200")
        self.assertEqual(data["address"], "г. Москва, Тестовый пр., 1")
        self.assertEqual(data["contractor"], "ООО Подрядчик")
        self.assertEqual(data["contractor_inn"], "7700000000")
        kinds = [r["kind"] for r in data["rows"]]
        self.assertEqual(kinds, ["block", "node", "work", "material", "material", "work"])
        block, node, work, mat = data["rows"][:4]
        self.assertEqual(block["uid"], "b:blk-guid-1")
        self.assertEqual(block["name"], "Тестовый корпус")
        self.assertEqual(block["cost"], 2700.0)
        self.assertEqual(node["parent"], block["uid"])
        self.assertEqual(work["uid"], "12")
        self.assertEqual(work["parent"], "11")
        self.assertEqual(work["qty"], 10.0)
        self.assertEqual(mat["work"], "12")
        self.assertEqual(mat["uid"], "12.501")
        self.assertEqual(data["totals"]["works"], 2)
        self.assertEqual(data["totals"]["materials"], 2)
        # ошибка формулы - пусто, пустые поля не хранятся
        self.assertNotIn("price_smr", data["rows"][5])
        self.assertEqual(block["works"], 2)

    def test_not_a_tkp(self):
        rows = sheet()
        rows[4] = _row(A="Наименование", B="Количество")
        with self.assertRaises(tkp_customer.TkpError):
            tkp_customer.parse_rows(rows)
        rows = sheet()
        rows[0] = _row(D="{}", AE="zeroParent_id")
        with self.assertRaises(tkp_customer.TkpError):
            tkp_customer.parse_rows(rows)

    @unittest.skipUnless(HAS_OPENPYXL, "нет openpyxl")
    def test_parse_xlsx_picks_tkp_sheet(self):
        wb = openpyxl.Workbook()
        wb.active.title = "Изменения"
        wb.active["A1"] = "старое"
        ws = wb.create_sheet("ТКП")
        for row in sheet():
            ws.append(list(row))
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "tkp.xlsx")
            wb.save(path)
            data = tkp_customer.parse(path)
            out = os.path.join(tmp, "v.json")
            self.assertEqual(tkp_customer.main(["parse", path, "--out", out]), 0)
            with open(out, encoding="utf-8") as fh:
                self.assertEqual(json.load(fh)["version_id"], "200")
            bad = os.path.join(tmp, "bad.xlsx")
            other = openpyxl.Workbook()
            other.active["A1"] = "не ТКП"
            other.save(bad)
            with self.assertRaises(tkp_customer.TkpError):
                tkp_customer.parse(bad)
        self.assertEqual(data["totals"]["blocks"], 1)


class DiffTest(unittest.TestCase):
    def test_stable_uid_diff(self):
        old = tkp_customer.parse_rows(sheet("200"))
        new = tkp_customer.parse_rows(sheet("201", qty_pipe=12, price_pipe=480.0, extra_work=True, drop_mat=True))
        d = tkp_customer.diff(old, new)
        self.assertEqual(d["from_version"], "200")
        self.assertEqual(d["to_version"], "201")
        self.assertEqual(d["added"], ["14"])
        self.assertEqual(d["removed"], ["12.502"])
        self.assertEqual(d["removed_rows"]["12.502"]["name"], "Отвод ПП 110")
        by_uid = {c["uid"]: c["fields"] for c in d["changed"]}
        self.assertEqual(by_uid["12"]["qty"], [10.0, 12.0])
        self.assertEqual(by_uid["12"]["price_mat"], [500.0, 480.0])
        self.assertIn("qty", by_uid["13"])
        self.assertNotIn("11", by_uid)
        self.assertEqual(d["summary"]["added"]["work"], 1)
        self.assertEqual(d["summary"]["removed"]["material"], 1)
        self.assertEqual(d["summary"]["price_changed"], 2)

    def test_same_version_no_changes(self):
        a = tkp_customer.parse_rows(sheet())
        d = tkp_customer.diff(a, tkp_customer.parse_rows(sheet()))
        self.assertEqual((d["added"], d["removed"], d["changed"]), ([], [], []))


if __name__ == "__main__":
    unittest.main()
