# -*- coding: utf-8 -*-
"""Тесты агента РВ: чтение ЛРВ, разметка систем, разбор ответов модели,
сквозной прогон на примере комплекта. Под Python 3.8, как на хостинге.
Запуск: python3 -m unittest program-c.tests.test_rv (из корня репозитория)."""
import json
import os
import sys
import tempfile
import unittest
from unittest import mock

HERE = os.path.dirname(os.path.abspath(__file__))
PROGRAM_C = os.path.dirname(HERE)
ROOT = os.path.dirname(PROGRAM_C)
for path in (PROGRAM_C, ROOT, os.path.join(PROGRAM_C, "rv")):
    if path not in sys.path:
        sys.path.insert(0, path)

import rv_input  # noqa: E402
import rv_agent  # noqa: E402

try:
    import openpyxl  # noqa: F401
    HAS_OPENPYXL = True
except ImportError:
    HAS_OPENPYXL = False


class FakeClient(object):
    """Клиент модели, отдающий заранее заданный JSON."""

    def __init__(self, payloads):
        self.payloads = list(payloads)
        self.calls = []
        self.usage = {}

    def messages(self, turns, **kwargs):
        self.calls.append((turns, kwargs))
        return {"stop_reason": "end_turn", "content": [{"type": "text", "text": json.dumps(self.payloads.pop(0), ensure_ascii=False)}]}


class SystemsTest(unittest.TestCase):
    def test_vk_synonyms(self):
        self.assertEqual(rv_input.normalize_system("ВК", "К1н"), "К1")
        self.assertEqual(rv_input.normalize_system("ВК", "В2 Противопожарный водопровод"), "В2")
        self.assertEqual(rv_input.normalize_system("ВК", "ХВС"), "В1")
        self.assertIsNone(rv_input.normalize_system("ВК", "Корпус 1"))

    def test_ss_branch_code(self):
        self.assertEqual(rv_input.normalize_system("СС", "Система 2.2 СКС"), "2.2")
        self.assertEqual(rv_input.normalize_system("СС", "10.1"), "10.1")

    def test_ov2(self):
        self.assertEqual(rv_input.normalize_system("ОВ2", "Противодымная вентиляция ПДВ"), "ПДВ")
        self.assertEqual(rv_input.normalize_system("ОВ2", "ОВ"), "ОВ")

    def test_guess_headers_and_apply(self):
        parsed = {"headers": [{"row": 1, "text": "Корпус 1"}, {"row": 2, "text": "К1 Канализация"}],
                  "items": [{"row": 3, "name": "Труба", "unit": "м", "qty": 1.0, "headers": [0, 1]}]}
        marks = rv_input.guess_headers("ВК", parsed["headers"])
        self.assertEqual(marks[0]["kind"], "element")
        self.assertEqual((marks[1]["kind"], marks[1]["section"], marks[1]["system"]), ("system", "ВК", "К1"))
        rv_input.apply_marks("ВК", parsed, marks)
        self.assertEqual(parsed["items"][0]["system"], "К1")
        self.assertEqual(parsed["items"][0]["section"], "ВК")
        self.assertEqual(parsed["items"][0]["element"], "Корпус 1")

    def test_system_1c_dictionary(self):
        cases = {
            "Система хозяйственно-бытового водоснабжения (Насосная)": ("ВК", "В1"),
            "Система внутреннего противопожарного водопровода и система автоматического пожаротушения": ("ВК", "В2"),
            "Система хозяйственно-бытовой канализации": ("ВК", "К1"),
            "Система ливневой канализации": ("ВК", "К2"),
            "Система дренажной канализации": ("ВК", "К4"),          # в КЦ ветка 4; ветка 3 — производственная
            "Система производственной канализации": ("ВК", "К3"),
            "Канализация условно-чистых стоков": ("ВК", "К4"),
            "Дренаж приямков К3": ("ВК", "К4"),                       # слово главнее кода в названии
            "Шахт-пакеты": ("ВК", "ШП"),
            "Отопление жилая часть": ("ОВ1", "отопление"),
            "Оборудование противодымной вентиляции": ("ОВ2", "ПДВ"),
            "Общеобменная вентиляция": ("ОВ2", "ОВ"),
            "Электромонтажные работы в нежилой части": ("ЭОМ", "нежилая"),
            "Электромонтажные работы квартир": ("ЭОМ", "квартиры"),
            "АПС/СОУЭ - Автоматическая пожарная сигнализация": ("СС", "5"),
            "АСКУВТ - Автоматизированная систем коммерческого учета воды и тепла": ("СС", "2.2"),
            "СВН - Система видеонаблюдения/СОТ - Система охранного телевидения": ("СС", "11"),
            "Сети связи (телевидение, радиофикация, СКС)": ("СС", "9"),
            "СОВ/СКУД - Система охраны входов / Система контроля управления доступом": ("СС", "10"),
            "КК - Кабельные конструкции": ("СС", "7"),
            "Накладные расходы": ("skip", None),
            "Что-то непонятное": (None, None),
        }
        for text, expected in cases.items():
            self.assertEqual(rv_input.system_1c(text), expected, text)

    def test_fix_drainage_marks(self):
        """РВ, собранные до исправления словаря: дренаж, размеченный К3 (производственная), при пересборке — К4."""
        headers = [{"text": "ЖК Тест"}, {"text": "Система дренажной канализации"}, {"text": "Система производственной канализации"},
                   {"text": "Дренажная насосная"}]
        marks = {0: {"kind": "other"}, 1: {"kind": "system", "section": "ВК", "system": "К3", "confidence": 0.9},
                 2: {"kind": "system", "section": "ВК", "system": "К3", "confidence": 0.9},
                 3: {"kind": "system", "section": "ВК", "system": "К1", "confidence": 1.0}}
        self.assertEqual(rv_input.fix_drainage_marks(headers, marks), ["Система дренажной канализации"])
        self.assertEqual([marks[i].get("system") for i in range(4)], [None, "К4", "К3", "К1"])
        self.assertEqual(rv_input.fix_drainage_marks(headers, marks), [])          # повторно — нечего менять

    def test_guess_unit(self):
        self.assertEqual(rv_input.guess_unit("Кабель ВВГнг(А)-LS 3х1,5")[0], "м")
        self.assertEqual(rv_input.guess_unit("Анкер клин 6х40 мм")[0], "шт")
        self.assertEqual(rv_input.guess_unit("Клеевый состав для огнезащиты")[0], "кг")
        self.assertEqual(rv_input.guess_unit("Краска огнезащитная 25 кг")[0], "кг")
        self.assertEqual(rv_input.split_system("ВК|В1"), ("ВК", "В1"))
        self.assertEqual(rv_input.split_system("В1"), (None, "В1"))

    def test_apply_marks_skip_and_sections(self):
        parsed = {"headers": [{"row": 1, "text": "Вспомогательные работы", "level": 1, "label": "Аналитика 4"},
                              {"row": 2, "text": "Накладные расходы", "level": 3, "label": "Система"},
                              {"row": 10, "text": "Основные работы", "level": 1, "label": "Аналитика 4"},
                              {"row": 11, "text": "Отопление жилая часть", "level": 3, "label": "Система"},
                              {"row": 30, "text": "Работы по З/Н №6", "level": 1, "label": "Аналитика 4"},
                              {"row": 31, "text": "Система хозяйственно-бытового водоснабжения", "level": 3, "label": "Система"}],
                  "items": [{"row": 3, "name": "Дрель", "unit": "", "qty": 1.0, "headers": [0, 1]},
                            {"row": 12, "name": "Труба стальная 57х3,5", "unit": "", "qty": 10.0, "headers": [2, 3]},
                            {"row": 32, "name": "Гильза", "unit": "", "qty": 5.0, "headers": [4, 5]}]}
        marks = rv_input.guess_headers("авто", parsed["headers"], "1c_report")
        self.assertEqual(marks[0]["kind"], "skip")
        self.assertEqual(marks[1]["kind"], "skip")
        self.assertEqual(marks[2]["kind"], "other")
        self.assertEqual((marks[3]["section"], marks[3]["system"]), ("ОВ1", "отопление"))
        self.assertEqual(marks[4], {"kind": "element", "element": "Работы по З/Н №6"})
        rv_input.apply_marks("авто", parsed, marks)
        items = parsed["items"]
        self.assertTrue(items[0]["skip"])
        self.assertEqual((items[1]["section"], items[1]["system"], items[1]["element"]), ("ОВ1", "отопление", ""))
        self.assertEqual((items[2]["section"], items[2]["system"], items[2]["element"]), ("ВК", "В1", "Работы по З/Н №6"))


class MemoryBudgetTest(unittest.TestCase):
    def test_agent_data_fits_hosting_memory(self):
        """Данные агента должны загружаться в разумную память: 31.10.2026 справочник с полным списком
        материалов поднял её до ~510 МБ, и хостинг молча убивал процесс РВ."""
        import subprocess
        # Пик — по VmHWM текущего образа процесса: ru_maxrss дочернего процесса включает память родителя
        # на момент fork (до exec), и после тестов, загрузивших данные агента в этот процесс, завышен вдвое.
        code = ("import sys, resource; sys.path[:0] = [%r, %r]; import bind; bind.load(%r)\n"
                "peak = resource.getrusage(resource.RUSAGE_SELF).ru_maxrss // 1024\n"
                "try:\n"
                "    for line in open('/proc/self/status'):\n"
                "        if line.startswith('VmHWM:'): peak = int(line.split()[1]) // 1024\n"
                "except OSError: pass\n"
                "print(peak)") % (
            os.path.join(PROGRAM_C, "rv"), PROGRAM_C, os.path.join(PROGRAM_C, "rv", "data"))
        out = subprocess.run([sys.executable, "-c", code], stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                             universal_newlines=True, timeout=300)
        self.assertEqual(out.returncode, 0, out.stderr[-500:])
        peak_mb = int(out.stdout.strip().splitlines()[-1])
        self.assertLess(peak_mb, 380, "пик памяти загрузки данных агента %d МБ" % peak_mb)


class KcImportTest(unittest.TestCase):
    def test_build_index_keeps_units_and_flags_main(self):
        import rv_kc_import
        works = {"6.2.3.1.1.1.1.1": {"name": "Прокладка трубопроводов", "guid": "g1"},
                 "6.2.3.4.9.9.9.9": {"name": "Новая работа", "guid": "g2"}}
        mats = {"6.2.3.1.1.1.1.1": [
                    {"group": "Труба", "material": "Труба PP-H 110", "unit": "м", "coef": 1.0, "main": True, "edit": False},
                    {"group": "Труба", "material": "Труба PP-H 110", "unit": "м", "coef": 1.0, "main": True, "edit": False},
                    {"group": "Хомут", "material": "Хомут 110", "unit": "шт", "coef": 1.5, "main": False, "edit": False}],
                "6.2.3.4.9.9.9.9": [{"group": "Кабель", "material": "Кабель ВВГ", "unit": "м", "coef": 1.0, "main": True, "edit": True}]}
        old = {"vk_works": [["6.2.3.1.1.1.1.1", "Прокладка трубопроводов", "g1", "", "", 0, 0, [], [], "м"],
                            ["6.2.3.1.9.9.9.9", "Закрытая работа", "g0", "", "", 0, 0, [], [], "шт"]]}
        index, guessed = rv_kc_import.build_index(works, mats, old)
        self.assertEqual(index["vk_works"], [["6.2.3.1.1.1.1.1", "Прокладка трубопроводов", "g1", "", "", 0, 0, [], [], "м"]])
        self.assertEqual(len(index["vk_mats"]), 2)          # повтор строки материала убран
        self.assertEqual(index["vk_mats"][0][1], "g1")       # материал привязан guid работы
        self.assertTrue(index["vk_mats"][0][9])
        self.assertFalse(index["vk_mats"][1][9])
        self.assertEqual(index["eom_works"][0][9], "м")      # новая работа: единица по основным материалам
        self.assertEqual(guessed, ["6.2.3.4.9.9.9.9"])
        report = rv_kc_import.compare(old, index, log=lambda *_: None)
        self.assertEqual(report["ВК"]["removed"], ["6.2.3.1.9.9.9.9"])

    def test_isr_names_from_paths(self):
        import rv_kc_import
        base = "Затраты на строительство / СМР корпуса без отделки / Инженерные системы / Водоснабжение и канализация"
        works = {
            "6.2.3.1.1.1.1.1": {"name": "Прокладка трубопроводов из ПП труб / в строительном исполнении",
                                "path": base + " / Система хозяйственно-бытовой канализации / Прокладка трубопроводов / Прокладка трубопроводов из ПП труб"},
            # имя семьи с « / » внутри ломает путь — семья берётся из имени работы
            "6.2.3.5.1.2.33.1": {"name": "Монтаж шкафа / щита управления вентиляцией",
                                 "path": "Затраты на строительство / СМР корпуса без отделки / Инженерные системы / Слаботочные системы / "
                                         "Автоматизация комплексная (АК) / Оборудование и материалы / Монтаж шкафа / щита управления вентиляцией"},
            # в пути на уровень больше, чем в коде: верхние четыре — с начала, остальные — с конца
            "6.2.3.5.10.1.1.2.1": {"name": "Прокладка провода",
                                   "path": "Затраты на строительство / СМР корпуса без отделки / Инженерные системы / Слаботочные системы / "
                                           "Система охраны входов / СКУД (СОВ/СКУД) / СОВ / Кабельно-проводниковая продукция / Прокладка провода"},
        }
        names = rv_kc_import.build_names(works)
        self.assertEqual(names["6.2.3.1"], "Водоснабжение и канализация")
        self.assertEqual(names["6.2.3.1.1"], "Система хозяйственно-бытовой канализации")
        self.assertEqual(names["6.2.3.1.1.1.1"], "Прокладка трубопроводов из ПП труб")
        self.assertEqual(names["6.2.3.5.1.2.33"], "Монтаж шкафа")
        self.assertEqual(names["6.2.3.5.1.2"], "Оборудование и материалы")
        self.assertEqual(names["6.2.3.5"], "Слаботочные системы")
        self.assertEqual(names["6.2.3.5.10"], "СКУД (СОВ/СКУД)")
        self.assertEqual(names["6.2.3.5.10.1.1.2"], "Прокладка провода")
        self.assertEqual(names["6.2.3.5.10.1.1"], "Кабельно-проводниковая продукция")


class OneCTest(unittest.TestCase):
    """ЛРВ из 1С по API: строки JSON читаются как отчёт 1С; очередь разбирается по одной задаче."""

    def test_overhead_and_bnr_are_skipped(self):
        """БНР и накладные расходы — не материалы работ: такие системы в РВ не включаются."""
        for name in ("Накладные расходы", "БНР", "Работы БНР-2", "Вспомогательные работы"):
            self.assertEqual(rv_input.system_1c(name), ("skip", None), name)
        self.assertEqual(rv_input.system_1c("Система водоснабжения"), ("ВК", "В1"))
        self.assertEqual(rv_input.system_1c("ОБНРУЖЕНИЕ"), (None, None))

    def test_zn_from_number_or_analytic(self):
        """Наряд-заказ строки: «НомерЗН» или Аналитика 4 «Работы по З/Н №…»; основные работы — пусто."""
        import web_rv_run
        items = [{"ext": {"НомерЗН": " 21 "}}, {"ext": {"Аналитика": "Работы по З/Н №ЭОМ-1"}},
                 {"ext": {"Аналитика": "Работы по З/Н №ЭОМ-1"}}, {"ext": {"Аналитика": "Основные работы"}},
                 {"ext": {"Аналитика_4_Имя": "Работы по заказ-наряду"}}, {"name": "без полей 1С"},
                 {"ext": {"НомерЗН": "21"}, "skip": True}]
        self.assertEqual(web_rv_run.zn_counts(items), {"21": 1, "ЭОМ-1": 2, "Работы по заказ-наряду": 1})

    def test_json_rows_like_1c_report(self):
        rows = [
            {"Номенклатура": "Труба PP-H 110", "ЕдиницаИзмерения": "м", "Количество": "12,5",
             "Система": "Система хозяйственно-бытовой канализации", "Аналитика": "Основные работы", "Код": "00-1",
             "ИдентификаторСтроки": "row-7", "Номенклатура_GUID": "a1b2", "Субконто": "СМР", "Пусто": ""},
            {"номенклатура": "Кабель ВВГнг 3х2,5", "Ед": "м", "количество": 100,
             "Система": "Электромонтажные работы квартир", "Аналитика": "Работы по З/Н №ЭОМ-1"},
            {"Номенклатура": "_Плановая экономия", "Количество": 1, "Система": "Накладные расходы"},
            {"Номенклатура": "Без количества", "Количество": 0, "Система": "Шахт-пакеты"},
        ]
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "lrv.json")
            with open(path, "w", encoding="utf-8") as handle:
                json.dump({"ИдентификаторЛРВ": "1", "Строки": rows}, handle, ensure_ascii=False)
            parsed = rv_input.parse_lrv(path)
        self.assertEqual(parsed["format"], "1c_report")
        self.assertEqual((len(parsed["items"]), parsed["skipped_zero"]), (3, 1))
        self.assertEqual(parsed["items"][0]["qty"], 12.5)
        self.assertEqual(parsed["items"][0]["code_1c"], "00-1")
        self.assertEqual(parsed["items"][0]["uid"], "row-7")
        self.assertEqual(parsed["items"][0]["ext"], {"Номенклатура_GUID": "a1b2", "Субконто": "СМР"})
        marks = rv_input.guess_headers("авто", parsed["headers"], parsed["format"])
        rv_input.apply_marks("авто", parsed, marks)
        got = [(it["section"], it["system"], it["element"], bool(it["skip"])) for it in parsed["items"]]
        self.assertEqual(got, [("ВК", "К1", "", False), ("ЭОМ", "квартиры", "Работы по З/Н №ЭОМ-1", False), (None, None, "", True)])

    def test_queue_one_by_one_with_retry(self):
        import types
        import web_rv_run
        with tempfile.TemporaryDirectory() as tmp:
            for n, token in enumerate(("b" * 16, "a" * 16, "c" * 16)):
                inp = os.path.join(tmp, token + ".json")
                open(inp, "w").close()
                with open(os.path.join(tmp, token + "_job.json"), "w", encoding="utf-8") as handle:
                    json.dump({"created": 100 + n, "input": inp if token != "c" * 16 else os.path.join(tmp, "нет.json"),
                               "source_name": token, "default_system": "ВК|В1" if token == "a" * 16 else ""}, handle)
                with open(os.path.join(tmp, token + "_status.json"), "w", encoding="utf-8") as handle:
                    json.dump({"state": "queued"}, handle)
            calls = []

            def runner(cmd, env):
                status = cmd[cmd.index("--status-file") + 1]
                calls.append((os.path.basename(status), env["RV_ATTEMPT"], "--default-system" in cmd))
                if status.startswith(os.path.join(tmp, "a" * 16)) and env["RV_ATTEMPT"] == "1":
                    return 75                                   # нехватка памяти на старте — повтор
                with open(status, "w", encoding="utf-8") as handle:
                    json.dump({"state": "done"}, handle)
                return 0

            args = types.SimpleNamespace(queue_dir=tmp, credentials="", learning_file="/x/learn.json")
            self.assertEqual(web_rv_run.run_queue(args, runner=runner, sleep=lambda s: None), 0)
            self.assertEqual(calls, [("b" * 16 + "_status.json", "1", False), ("a" * 16 + "_status.json", "1", True),
                                     ("a" * 16 + "_status.json", "2", True)])
            missing = json.load(open(os.path.join(tmp, "c" * 16 + "_status.json"), encoding="utf-8"))
            self.assertEqual(missing["state"], "error")
            self.assertEqual(web_rv_run.queued_jobs(tmp), [])

    def test_queue_rebuild_after_new_lrv(self):
        """Пересборка готовой РВ через очередь (rv_rebuild.php, пачкой): после новых ЛРВ, фазой bind с --rebuild,
        файл ЛРВ не нужен; согласование из статуса не теряется до запуска; без разметки — ошибка."""
        import types
        import web_rv_run
        with tempfile.TemporaryDirectory() as tmp:
            def put(token, job, status, work=True):
                with open(os.path.join(tmp, token + "_job.json"), "w", encoding="utf-8") as handle:
                    json.dump(job, handle)
                with open(os.path.join(tmp, token + "_status.json"), "w", encoding="utf-8") as handle:
                    json.dump(status, handle)
                if work:
                    open(os.path.join(tmp, token + "_work.json"), "w").close()

            fresh = os.path.join(tmp, "fresh.json")
            open(fresh, "w").close()
            feedback = {"user": "parfenov", "corrected": 1, "confirmed": 5}
            put("a" * 16, {"created": 50, "source_name": "старая РВ"},
                {"state": "queued", "rebuild": {"by": "kadrova", "at": 1}, "feedback": feedback})
            put("b" * 16, {"created": 200, "source_name": "новая ЛРВ", "input": fresh}, {"state": "queued"}, work=False)
            put("c" * 16, {"created": 60, "source_name": "без разметки"}, {"state": "queued", "rebuild": {"by": "kadrova"}}, work=False)
            self.assertEqual([t[0] for t, _ in web_rv_run.queued_jobs(tmp)], ["b", "a", "c"])     # новая ЛРВ раньше пересборок
            calls = []

            def runner(cmd, env):
                status = cmd[cmd.index("--status-file") + 1]
                seen = json.load(open(status, encoding="utf-8"))
                calls.append((os.path.basename(status)[0], cmd[cmd.index("--phase") + 1], "--rebuild" in cmd, "--no-review" in cmd,
                              cmd[cmd.index("--user") + 1] if "--user" in cmd else None, seen.get("feedback")))
                with open(status, "w", encoding="utf-8") as handle:
                    json.dump({"state": "done"}, handle)
                return 0

            args = types.SimpleNamespace(queue_dir=tmp, credentials="/x/key.json", learning_file="/x/learn.json")
            self.assertEqual(web_rv_run.run_queue(args, runner=runner, sleep=lambda s: None), 0)
            self.assertEqual(calls, [("b", "mark", False, False, None, None), ("a", "bind", True, True, "kadrova", feedback)])
            failed = json.load(open(os.path.join(tmp, "c" * 16 + "_status.json"), encoding="utf-8"))
            self.assertEqual((failed["state"], failed["stage"]), ("error", "нет разметки"))
            command = web_rv_run._queue_command(args, tmp, "a" * 16, {"_rebuild": {"by": "kadrova"}, "source_name": "старая РВ"})
            self.assertEqual(command[command.index("--out-json") + 1], os.path.join(tmp, "a" * 16 + "_rv.json.gz"))
            self.assertEqual(command[command.index("--learning-file") + 1], "/x/learn.json")

    def test_queue_worker_not_killed_as_stale(self):
        import rv_startup
        procs = [(10, 300, 9000, ["python3", "web_rv_run.py", "--phase", "queue", "--queue-dir", "/d"]),
                 (11, 300, 9000, ["python3", "web_rv_run.py", "--phase", "mark", "--status-file", "/d/x"]),
                 (12, 300, 5400, ["python3", "web_rv_run.py", "--phase", "bind", "--status-file", "/d/y"])]
        killed = []
        original = os.kill
        try:
            os.kill = lambda pid, sig: killed.append(pid)
            stopped = rv_startup.stop_stale_runs(processes=procs)
        finally:
            os.kill = original
        self.assertEqual((stopped, killed), ([11], [11]))


class OneCCoefTest(unittest.TestCase):
    """Коэффициент, проведённый в 1С, агент не меняет — предлагает свой; решение инженера уходит в 1С заменой."""

    def setUp(self):
        import web_rv_run
        self.run = web_rv_run
        works = [{"Код": "6.1.1", "Наименование": "Монтаж лотка", "Количество": 8, "Коэффициент": 0}]
        self.items = [{"id": 1, "qty": 8, "ext": {"РаботыВ1С": works}},
                      {"id": 2, "qty": 10, "ext": {"РаботыВ1С": [{"Код": "6.1.1", "Количество": 10, "Коэффициент": 1}]}},
                      {"id": 3, "qty": 5}]

    def bindings(self):
        return [{"id": 1, "code": "6.1.1", "onec_code": "6.1.1", "role": "П"},
                {"id": 2, "code": "6.1.1", "onec_code": "6.1.1", "role": "В", "coef_user": 1.0, "learned_token": "старая"},
                {"id": 3, "code": "6.1.1", "role": "В"}]

    def test_onec_coef_kept_agent_suggests(self):
        bindings = self.bindings()
        coefs = {1: 0.5, 2: 1.0, 3: 1.0}
        self.assertEqual(self.run.apply_onec_coefs(self.items, bindings, coefs, "эта"), 1)
        self.assertEqual(coefs[1], 0)                       # в 1С 0 — так и остаётся
        self.assertEqual(bindings[0]["coef_agent"], 0.5)    # а агент предлагает 0,5
        self.assertNotIn("coef_agent", bindings[1])         # совпадает с 1С — предлагать нечего
        self.assertNotIn("coef_user", bindings[1])          # память по другой РВ не меняет проведённое в 1С
        self.assertNotIn("coef_onec", bindings[2])          # строки нет в 1С — коэффициент агента как был
        volumes = {"6.1.1": {"volume": 19.0, "method": "сумма"}}
        import bind
        with mock.patch.object(bind, "KB", {"kc": {}, "works": {}}):
            self.run.apply_coef_overrides(self.items, bindings, volumes, coefs)
        self.assertEqual(volumes["6.1.1"]["volume"], 15.0)  # 8×0 + 10×1 + 5×1
        self.assertIn("1С", volumes["6.1.1"]["method"])
        bindings[0]["coef"] = coefs[1]
        self.assertEqual(self.run.onec_action(bindings[0]), "как в 1С")

    def test_engineer_coef_in_this_rv_wins_and_goes_to_1c(self):
        bindings = self.bindings()
        bindings[0].update(coef_user=0.5, learned_token="эта")
        coefs = {1: 0.5, 2: 1.0, 3: 1.0}
        self.run.apply_onec_coefs(self.items, bindings, coefs, "эта")
        self.assertEqual(bindings[0]["coef_user"], 0.5)
        self.assertNotIn("coef_agent", bindings[0])
        bindings[0]["coef"] = 0.5
        self.assertEqual(self.run.onec_action(bindings[0]), "перепривязать")   # 1С: −8 с коэф. 0, +8 с коэф. 0,5
        self.assertEqual(self.run.onec_action(dict(bindings[2], coef=1.0)), "привязать")


class ReduceTest(unittest.TestCase):
    """ЛРВ уменьшилась: отрицательный остаток в пакете 1С уменьшает разнесённое под работы — пропорционально,
    если материал под несколькими работами; в 1С уходит минус (действие строки не меняется, поле «Уменьшение»)."""

    GUID = "0148ffed-0000-0000-0000-000000000001"

    def setUp(self):
        import web_rv_run
        self.run = web_rv_run

    def item(self, works, qty=None):
        total = sum(w["Количество"] for w in works)
        return {"id": 1, "name": "Отвод 90° 450х700", "unit": "шт", "qty": total if qty is None else qty,
                "uid": self.GUID + "|разнесено", "ext": {"РаботыВ1С": works, "РазнесеноВ1С": total, "КоличествоВСмету": total * 2}}

    def test_reductions_of_packet(self):
        packet = {"Строки": [
            {"Номенклатура": "Отвод 90° 450х700", "НоменклатураGUID": self.GUID, "ЕдиницаИзмерения": "шт", "Колво": -2, "КолвоВСмету": -4},
            {"Номенклатура": "Отвод 90° 450х700", "НоменклатураGUID": self.GUID.upper(), "Колво": "-1,5"},
            {"Номенклатура": "Воздуховод", "НоменклатураGUID": "0148ffed-0000-0000-0000-000000000002", "Колво": 7},
            {"Номенклатура": "Тройник", "НоменклатураGUID": "0148ffed-0000-0000-0000-000000000003", "Колво": 0},
            {"Наименование": "Без GUID", "Количество": -3}]}
        found = {r["uid"].lower(): r for r in self.run.reductions_of(packet)}
        self.assertEqual(sorted(found), [self.GUID, "без guid"])
        self.assertEqual((found[self.GUID]["qty"], found[self.GUID]["unit"]), (3.5, "шт"))
        self.assertEqual(found["без guid"]["qty"], 3.0)
        self.assertEqual(self.run.reductions_of({"Строки": []}), [])
        self.assertEqual(self.run.reductions_of(None), [])

    def test_single_work(self):
        item = self.item([{"Код": "6.1.1", "Количество": 10, "Коэффициент": 2, "СметнаяПозицияGUID": "p1"}])
        done, notes = self.run.apply_reductions([item], [{"uid": self.GUID, "qty": 2, "name": "Отвод"}])
        self.assertEqual(done, 1)
        self.assertEqual((item["qty"], item["reduce"]), (8.0, {"qty": 2.0, "before": 10.0}))
        work = item["ext"]["РаботыВ1С"][0]
        self.assertEqual((work["Количество"], work["Уменьшение"], work["Остается"]), (10, 2.0, 8.0))   # как в 1С + сколько снять
        self.assertTrue(any("уменьшилась по 1 материалам" in n for n in notes))

    def test_proportional_over_works(self):
        item = self.item([{"Код": "6.1.1", "Количество": 30, "СметнаяПозицияGUID": "p1"},
                          {"Код": "6.1.2", "Количество": 10, "СметнаяПозицияGUID": "p2"},
                          {"Код": "6.1.3", "Количество": 0}])
        self.run.apply_reductions([item], [{"uid": self.GUID.upper(), "qty": 8}])
        works = item["ext"]["РаботыВ1С"]
        self.assertEqual([w.get("Уменьшение") for w in works], [6.0, 2.0, None])
        self.assertEqual([w.get("Остается") for w in works], [24.0, 8.0, None])
        self.assertEqual((item["qty"], item["reduce"]["qty"]), (32.0, 8.0))
        # части строки берут остаток под своей работой и несут своё уменьшение
        kb = {"6.1.1": "Работа 1", "6.1.2": "Работа 2"}
        items, bindings, stats = self.run.apply_splits([item], [{"id": 1, "code": "6.1.1", "role": "В"}], {}, kb, lambda name: "", "ЭОМ")
        self.assertEqual(stats["onec"], 1)
        self.assertEqual([(i["qty"], i["reduce"]["qty"], i["reduce"]["before"], i["reduce"]["total"]) for i in items],
                         [(24.0, 6.0, 30.0, 40.0), (8.0, 2.0, 10.0, 40.0)])
        self.assertEqual([b["code"] for b in bindings], ["6.1.1", "6.1.2"])

    def test_rounding_keeps_total(self):
        item = self.item([{"Код": "6.1.1", "Количество": 1}, {"Код": "6.1.2", "Количество": 1}, {"Код": "6.1.3", "Количество": 1}])
        self.run.apply_reductions([item], [{"uid": self.GUID, "qty": 1}])
        cuts = [w["Уменьшение"] for w in item["ext"]["РаботыВ1С"]]
        self.assertAlmostEqual(sum(cuts), 1.0, places=6)
        self.assertEqual(cuts[:2], [0.3333, 0.3333])
        self.assertEqual(item["qty"], 2.0)

    def test_more_than_distributed_and_missing(self):
        item = self.item([{"Код": "6.1.1", "Количество": 3}, {"Код": "6.1.2", "Количество": 2}])
        done, notes = self.run.apply_reductions([item], [{"uid": self.GUID, "qty": 9, "name": "Отвод"},
                                                           {"uid": "нет-такого", "qty": 4, "name": "Не разнесён"},
                                                           {"uid": self.GUID + "-x", "qty": 0}])
        self.assertEqual(done, 1)
        self.assertEqual((item["qty"], item["reduce"]), (0.0, {"qty": 5.0, "before": 5.0}))
        self.assertTrue(any("больше разнесённого" in n for n in notes))
        self.assertTrue(any("уменьшать нечего" in n and "Не разнесён (−4)" in n for n in notes))
        # снятая целиком строка остаётся двумя частями с нулём — чтобы минус ушёл по каждой работе
        kb = {"6.1.1": "Работа 1", "6.1.2": "Работа 2"}
        items, bindings, _ = self.run.apply_splits([item], [{"id": 1, "code": "6.1.1", "role": "В"}], {}, kb, lambda name: "", "ЭОМ")
        self.assertEqual([(i["qty"], i["reduce"]["qty"]) for i in items], [(0.0, 3.0), (0.0, 2.0)])

    def test_engineer_split_shares_reduction(self):
        item = self.item([{"Код": "6.1.1", "Количество": 10}])
        self.run.apply_reductions([item], [{"uid": self.GUID, "qty": 4}])
        kb = {"6.1.1": "Работа 1", "6.1.2": "Работа 2"}
        splits = {1: {"by": "ivanov", "parts": [{"code": "6.1.1", "qty": 7.5}, {"code": "6.1.2", "qty": 2.5}]}}
        items, _, stats = self.run.apply_splits([item], [{"id": 1, "code": "6.1.1", "role": "В"}], splits, kb, lambda name: "", "ЭОМ")
        self.assertEqual(stats["engineer"], 1)
        self.assertEqual([(i["qty"], i["reduce"]["qty"], i["reduce"]["before"]) for i in items], [(4.5, 3.0, 7.5), (1.5, 1.0, 2.5)])

    def test_no_reduction_unchanged(self):
        item = self.item([{"Код": "6.1.1", "Количество": 10}])
        before = json.dumps(item, ensure_ascii=False, sort_keys=True)
        self.assertEqual(self.run.apply_reductions([item], []), (0, []))
        self.assertEqual(json.dumps(item, ensure_ascii=False, sort_keys=True), before)

    def changes(self, rows, works=None):
        works = works or [("6.1.1", "Работа 1", "p1"), ("6.1.2", "Работа 2", "p2")]
        out_works = [{"КодИСР": code, "Наименование": name, "ЕдиницаИзмерения": "шт", "Объем": 1,
                      "Материалы": [r for r in rows if r["_code"] == code]} for code, name, _ in works]
        smeta = {code: {"guid": guid, "node": "node-" + guid} for code, _, guid in works}
        return self.run.sopost_1c({}, out_works, smeta, {}, {"lrv_id": "Смета-1"}, {})

    def row(self, code, qty, action, **extra):
        base = {"_code": code, "Номенклатура": "Отвод 90° 450х700", "НоменклатураGUID": self.GUID, "ЕдиницаИзмерения": "шт",
                "ИдентификаторСтроки": self.GUID + "|разнесено", "Количество": qty, "КоличествоВсего": qty,
                "Коэффициент": 2, "Роль": "В", "Действие": action, "КоличествоВСмету": 20}
        base.update(extra)
        return base

    def test_export_same_work(self):
        # работа та же: одна строка изменений с минусом; «в смету» — доля от прежнего количества (20 на 10 шт)
        sopost = self.changes([self.row("6.1.1", 8, "как в 1С", РаботаВ1С="6.1.1", Уменьшение=2, КоличествоВ1С=10, КоличествоВсегоВ1С=10,
                                        РаботыВ1С=[{"Код": "6.1.1", "Количество": 10, "Уменьшение": 2, "Остается": 8, "СметнаяПозицияGUID": "p1"}])])
        self.assertEqual(len(sopost["ТЧИзменений"]), 1)
        change = sopost["ТЧИзменений"][0]
        self.assertEqual((change["Действие"], change["Количество"], change["КоличествоВСмету"], change["КодИерархии"],
                          change["СметнаяПозицияGUID"], change["УИДУзлаДерева"]), ("уменьшить", -2, -4.0, "6.1.1", "p1", "node-p1"))
        self.assertEqual((sopost["Итого"]["Уменьшить"], sopost["Итого"]["Привязать"]), (1, 0))
        self.assertEqual(sopost["Товары"][0]["Количество"], 8)
        self.assertEqual(sopost["Товары"][0]["КоличествоВСмету"], 16.0)

    def test_export_parts(self):
        works_1c = [{"Код": "6.1.1", "Наименование": "Работа 1", "Количество": 30, "Уменьшение": 6, "Остается": 24, "СметнаяПозицияGUID": "p1"},
                    {"Код": "6.1.2", "Наименование": "Работа 2", "Количество": 10, "Уменьшение": 2, "Остается": 8, "СметнаяПозицияGUID": "p2"}]
        rows = [self.row("6.1.1", 24, "как в 1С", Часть="1/2", КоличествоВсего=32, Уменьшение=6, КоличествоВ1С=30, КоличествоВсегоВ1С=40, РаботыВ1С=works_1c, КоличествоВСмету=80),
                self.row("6.1.2", 8, "как в 1С", Часть="2/2", КоличествоВсего=32, Уменьшение=2, КоличествоВ1С=10, КоличествоВсегоВ1С=40, РаботыВ1С=works_1c, КоличествоВСмету=80)]
        changes = self.changes(rows)["ТЧИзменений"]
        self.assertEqual([(c["Действие"], c["КодИерархии"], c["Количество"], c["КоличествоВСмету"]) for c in changes],
                         [("уменьшить", "6.1.1", -6, -12.0), ("уменьшить", "6.1.2", -2, -4.0)])

    def test_export_whole_row_on_several_works(self):
        # строка не разбита на части (работа 6.1.2 сайту неизвестна): минус по каждой работе 1С на её долю
        works_1c = [{"Код": "6.1.1", "Наименование": "Работа 1", "Количество": 30, "Уменьшение": 6, "СметнаяПозицияGUID": "p1"},
                    {"Код": "6.9.9", "Наименование": "Работа вне справочника", "Количество": 10, "Уменьшение": 2, "СметнаяПозицияGUID": "p9"}]
        changes = self.changes([self.row("6.1.1", 32, "как в 1С", Уменьшение=8, КоличествоВ1С=40, КоличествоВсегоВ1С=40, РаботыВ1С=works_1c)])["ТЧИзменений"]
        self.assertEqual([(c["КодИерархии"], c["Количество"], c["СметнаяПозицияGUID"]) for c in changes], [("6.1.1", -6, "p1"), ("6.9.9", -2, "p9")])

    def test_export_rebind_takes_all_from_old(self):
        # инженер перенёс уменьшенную строку на другую работу: со старой снимается всё, что там было, на новую — остаток
        row = self.row("6.1.2", 8, "перепривязать", РаботаВ1С="6.1.1", Уменьшение=2, КоличествоВ1С=10, КоличествоВсегоВ1С=10,
                       РаботыВ1С=[{"Код": "6.1.1", "Наименование": "Работа 1", "Количество": 10, "Уменьшение": 2, "СметнаяПозицияGUID": "p1"}])
        changes = self.changes([row])["ТЧИзменений"]
        self.assertEqual([(c["Действие"], c["КодИерархии"], c["Количество"]) for c in changes],
                         [("перепривязать", "6.1.1", -10), ("перепривязать", "6.1.2", 8)])

    def test_export_without_reduction_unchanged(self):
        changes = self.changes([self.row("6.1.1", 10, "как в 1С", РаботаВ1С="6.1.1"), self.row("6.1.2", 5, "привязать")])
        self.assertEqual([(c["Действие"], c["Количество"]) for c in changes["ТЧИзменений"]], [("привязать", 5)])
        self.assertEqual(changes["Итого"]["Уменьшить"], 0)


class EngineerWorksTest(unittest.TestCase):
    """«Добавить работу»: работа без материалов с объёмом сметчика; объём вручную у работы «добавлено агентом»;
    пересборка согласованной РВ снимает согласование, только если изменилось то, что уйдёт в 1С."""

    WORKS = {"6.2.3.3.1.99.3.1": "Испытание и наладка системы", "6.2.3.3.1.1.1.2": "Прокладка воздуховодов прямоугольного сечения",
             "6.2.3.3.1.5.1.1": "Монтаж решёток", "6.2.3.1.1.1.1.1": "Прокладка трубопроводов ПП"}
    KC = {"6.2.3.3.1.99.3.1": {"unit": "комплекс"}, "6.2.3.3.1.5.1.1": {"unit": "шт"}}

    def setUp(self):
        import web_rv_run
        self.run = web_rv_run

    def test_engineer_works_merge(self):
        with tempfile.TemporaryDirectory() as tmp:
            feedback = os.path.join(tmp, "fb.json")
            with open(feedback, "w", encoding="utf-8") as handle:
                json.dump({"user": "kadrova", "added_works": {"6.2.3.3.1.5.1.1": "12,5", "6.2.3.3.1.99.3.1": 0}}, handle)
            previous = {"added_works": {"6.2.3.3.1.99.3.1": {"qty": 2, "by": "parfenov"}, "6.2.3.3.1.1.1.2": {"qty": 7, "by": "zotov"}}}
            got = self.run.engineer_works(previous, feedback)
            self.assertEqual(got, {"6.2.3.3.1.5.1.1": {"qty": 12.5, "by": "kadrova"}, "6.2.3.3.1.1.1.2": {"qty": 7.0, "by": "zotov"}})
            self.assertEqual(self.run.engineer_works(None, ""), {})

    def test_apply_to_block(self):
        rv_works = [{"code": "6.2.3.3.1.1.1.2", "volume": 100, "materials": [{"id": 1}]},
                    {"code": "6.2.3.3.1.99.3.1", "volume": 1, "materials": [], "auto": True, "note": "добавлено агентом"}]
        added = {"6.2.3.3.1.99.3.1": {"qty": 3, "by": "kadrova"}, "6.2.3.3.1.5.1.1": {"qty": 24, "by": "kadrova"},
                 "6.2.3.3.1.1.1.2": {"qty": 5, "by": "kadrova"}, "6.2.3.1.1.1.1.1": {"qty": 9, "by": "kadrova"},
                 "9.9.9.9": {"qty": 1, "by": "kadrova"}}
        taken = set()
        count, notes = self.run.apply_engineer_works("ОВ2", rv_works, added, self.WORKS, self.KC, taken)
        self.assertEqual(count, 2)
        by_code = {w["code"]: w for w in rv_works}
        self.assertEqual((by_code["6.2.3.3.1.99.3.1"]["volume"], by_code["6.2.3.3.1.99.3.1"]["auto"], by_code["6.2.3.3.1.99.3.1"]["manual"]), (3, False, True))
        new = by_code["6.2.3.3.1.5.1.1"]
        self.assertEqual((new["volume"], new["unit"], new["materials"], new["method"], new["manual"]), (24, "шт", [], self.run.MANUAL_METHOD, True))
        self.assertIn("kadrova", new["note"])
        self.assertEqual(by_code["6.2.3.3.1.1.1.2"]["volume"], 100)                    # со строками — объём по строкам
        self.assertTrue(any("6.2.3.3.1.1.1.2" in n for n in notes))
        self.assertNotIn("6.2.3.1.1.1.1.1", by_code)                                    # другой раздел — в свой блок
        self.assertEqual(taken, {"6.2.3.3.1.99.3.1", "6.2.3.3.1.5.1.1", "6.2.3.3.1.1.1.2"})
        again = [{"code": "x", "materials": []}]
        self.assertEqual(self.run.apply_engineer_works("ОВ2", again, added, self.WORKS, self.KC, taken)[0], 0)   # одна работа — один блок

    def test_export_marks_engineer_work(self):
        result = {"elements": [{"element": "", "section": "ОВ2", "items": [], "bindings": [],
                                "rv": {"works": [{"code": "6.2.3.3.1.5.1.1", "work": "Монтаж решёток", "unit": "шт", "volume": 24,
                                                  "method": self.run.MANUAL_METHOD, "materials": [], "manual": True, "note": "добавлено сметчиком"}],
                                       "unbound": []}}], "summary": {}, "sections": ["ОВ2"]}
        out = self.run.export_1c(result, {"lrv_id": "Смета-1"}, self.WORKS)
        work = out["Работы"][0]
        self.assertEqual((work["ДобавленоСметчиком"], work["ДобавленоАгентом"], work["Объем"], work["Материалы"]), (True, False, 24, []))
        sopost = out["СопоставлениеРВиЛРВ"]
        self.assertEqual((sopost["СметныеПозиции"][0]["ДобавленоСметчиком"], sopost["СметныеПозиции"][0]["Количество"]), (True, 24))
        self.assertEqual((sopost["Итого"]["РаботСметчика"], sopost["ТЧИзменений"]), (1, []))

    def test_signature_changes(self):
        base = {"Работы": [{"КодИСР": "1.1", "Объем": 10, "Материалы": [
            {"ИдентификаторСтроки": "a", "Количество": 5, "Коэффициент": 2, "Действие": "привязать"}]}], "БезРаботы": []}
        same = json.loads(json.dumps(base))
        same["Сформировано"] = "другое время"
        same["Работы"][0]["Материалы"][0]["Уверенность"] = 50                          # не то, что делает 1С
        self.assertEqual(self.run.signature_changes(self.run.onec_signature(base), self.run.onec_signature(same)), {"works": 0, "rows": 0})
        coef = json.loads(json.dumps(base))
        coef["Работы"][0]["Материалы"][0]["Коэффициент"] = 2.5
        coef["Работы"][0]["Объем"] = 12.5
        self.assertEqual(self.run.signature_changes(self.run.onec_signature(base), self.run.onec_signature(coef)), {"works": 1, "rows": 1})
        reduced = json.loads(json.dumps(base))
        reduced["Работы"][0]["Материалы"][0].update(Количество=3, Уменьшение=2, Действие="как в 1С")
        reduced["Работы"].append({"КодИСР": "1.2", "Объем": 1, "Материалы": []})
        self.assertEqual(self.run.signature_changes(self.run.onec_signature(base), self.run.onec_signature(reduced)), {"works": 1, "rows": 1})


class LocalTzTest(unittest.TestCase):
    """Указания для одной РВ: ТЗ сметчика (текст и файлы) — чтение файлов, проход модели, применение замен."""

    WORKS = {"6.2.3.3.1.1.1.2": "Прокладка воздуховодов прямоугольного сечения / толщина стенки от 0,71 до 0,9 мм",
             "6.2.3.3.1.1.1.4": "Прокладка воздуховодов прямоугольного сечения / соединительные элементы",
             "6.2.3.3.1.5.1.1": "Монтаж решёток"}

    def setUp(self):
        import web_rv_run
        self.run = web_rv_run

    def _docx(self, path):
        import zipfile
        w = "http://schemas.openxmlformats.org/wordprocessingml/2006/main"
        xml = ('<w:document xmlns:w="%s"><w:body><w:p><w:r><w:t>Решётки — к монтажу решёток</w:t></w:r></w:p>'
               '<w:tbl><w:tr><w:tc><w:p><w:r><w:t>Воздуховод 300х300</w:t></w:r></w:p></w:tc>'
               '<w:tc><w:p><w:r><w:t>Прокладка воздуховодов</w:t></w:r></w:p></w:tc></w:tr></w:tbl></w:body></w:document>' % w)
        with zipfile.ZipFile(path, "w") as book:
            book.writestr("word/document.xml", xml)

    def test_material(self):
        with tempfile.TemporaryDirectory() as tmp:
            folder = os.path.join(tmp, "abc_local")
            os.mkdir(folder)
            files = []
            if HAS_OPENPYXL:
                import openpyxl
                book = openpyxl.Workbook()
                book.active.title = "Смета"
                book.active.append(["1", "Прокладка воздуховодов", "м2", 40.5])
                book.active.append([None, None, None])
                book.active.append([None, "Воздуховод 300х300 толщ. 0,8", "шт", 20])
                book.save(os.path.join(folder, "a1.xlsx"))
                files.append({"name": "смета.xlsx", "file": "a1.xlsx"})
            self._docx(os.path.join(folder, "b2.docx"))
            with open(os.path.join(folder, "c3.csv"), "wb") as handle:
                handle.write("Труба ПП 20;м;50\n".encode("cp1251"))
            with open(os.path.join(folder, "d4.png"), "wb") as handle:
                handle.write(b"\x89PNG fake")
            with open(os.path.join(folder, "e5.pdf"), "wb") as handle:
                handle.write(b"%PDF" + b"0" * 2000)
            files += [{"name": "ТЗ.docx", "file": "b2.docx"}, {"name": "трубы.csv", "file": "c3.csv"},
                      {"name": "схема.png", "file": "d4.png"}, {"name": "большой.pdf", "file": "e5.pdf"},
                      {"name": "старый.doc", "file": "f6.doc"}, {"name": "пропал.xlsx", "file": "g7.xlsx"}]
            local = {"text": "всё по смете", "files": files, "_dir": folder}
            with mock.patch.object(self.run, "LOCAL_PDF_MAX", 1000):
                text, blocks, used, skipped = self.run.local_material(local)
        self.assertTrue(text.startswith("Задание сметчика:\nвсё по смете"))
        if HAS_OPENPYXL:
            self.assertIn("Файл ТЗ «смета.xlsx»:\n— лист «Смета»\n1 | Прокладка воздуховодов | м2 | 40.5\n"
                          "Воздуховод 300х300 толщ. 0,8 | шт | 20", text)
        self.assertIn("Решётки — к монтажу решёток\nВоздуховод 300х300 | Прокладка воздуховодов", text)
        self.assertIn("Труба ПП 20;м;50", text)                                     # CSV в cp1251
        self.assertEqual([b["type"] for b in blocks], ["text", "image"])           # картинка — как есть
        self.assertEqual(blocks[1]["source"]["media_type"], "image/png")
        self.assertIn("схема.png", used)
        reasons = dict(skipped)
        self.assertEqual(reasons["большой.pdf"], "больше 0 МБ")
        self.assertEqual(reasons["старый.doc"], "формат не читается")
        self.assertIn("пропал.xlsx", reasons)                                       # нет файла — не падаем

    def test_local_input(self):
        import types
        with tempfile.TemporaryDirectory() as tmp:
            args = types.SimpleNamespace(status_file=os.path.join(tmp, "abc_status.json"))
            self.assertIsNone(self.run.local_input(args))
            path = os.path.join(tmp, "abc_local.json")
            with open(path, "w", encoding="utf-8") as handle:
                json.dump({"text": "  ", "files": [{"name": "x"}]}, handle)          # файл без имени на диске — не в счёт
            self.assertIsNone(self.run.local_input(args))
            with open(path, "w", encoding="utf-8") as handle:
                json.dump({"text": "", "files": [{"name": "смета.pdf", "file": "a.pdf"}]}, handle)
            local = self.run.local_input(args)
            self.assertEqual((local["_dir"], len(local["files"])), (os.path.join(tmp, "abc_local"), 1))
            self.assertTrue(self.run._update_local(args, agent={"rows": {}}))
            self.assertEqual(json.load(open(path, encoding="utf-8"))["agent"], {"rows": {}})

    def _bindings(self):
        return [{"id": 1, "name": "Решетка АМН 300х150", "code": "6.2.3.3.1.1.1.4", "role": "В", "confidence": 0.95, "review": False,
                 "alts": [{"code": "x"}]},
                {"id": 2, "name": "Воздуховод 300х300", "code": "6.2.3.3.1.1.1.4", "role": "В", "confidence": 1.0,
                 "learned": "onec", "review": False},
                {"id": 3, "name": "Хомут", "code": "", "role": "", "confidence": 0.1, "review": True},
                {"id": 4, "name": "Отвод", "code": "6.2.3.3.1.1.1.4", "role": "В", "confidence": 1.0,
                 "learned": "correction", "learned_token": "t1"}]

    def test_apply_agent(self):
        bindings = self._bindings()
        items = [{"id": b["id"], "name": b["name"]} for b in bindings]
        rows = {"1": {"code": "6.2.3.3.1.5.1.1", "role": "", "reason": "ТЗ: решётки к монтажу решёток"},
                "4": {"code": "6.2.3.3.1.5.1.1", "role": "", "reason": "x"},       # решение сметчика в этой РВ сильнее
                "3": {"code": "9.9.9", "role": "", "reason": "x"}}                   # код не из справочника — пропуск
        count = self.run.apply_local_agent(items, bindings, rows, self.WORKS, lambda name: "fam", "t1")
        b = bindings[0]
        self.assertEqual(count, 1)
        self.assertEqual((b["code"], b["learned"], b["learned_token"], b["review"], b["fcodes"], b["alts"], b["role"]),
                         ("6.2.3.3.1.5.1.1", "local", "t1", True, ["F-LOCAL"], [], "В"))
        self.assertEqual(b["flags"], ["F-LOCAL: по указаниям для этой РВ — ТЗ: решётки к монтажу решёток; было 6.2.3.3.1.1.1.4"])
        self.assertEqual(bindings[3]["code"], "6.2.3.3.1.1.1.4")
        self.assertEqual(bindings[2]["code"], "")
        # Строка с такой работой — разнесённая в 1С (apply_onec после указаний): работа по указаниям станет предложением.
        onec_item = {"id": 1, "name": "Решетка", "ext": {"РаботыВ1С": [{"КодИСР": "6.2.3.3.1.1.1.4", "Количество": 1}]}}
        self.run.apply_onec([onec_item], [b], self.WORKS, lambda name: "fam", None, "t1")
        self.assertEqual((b["code"], b["learned"], b["agent_code"], b["review"]), ("6.2.3.3.1.1.1.4", "onec", "6.2.3.3.1.5.1.1", True))

    def test_onec_work_missing_in_kc(self):
        """Работа 1С, которой нет в справочнике КЦ агента (КЦ в 1С пополнили позже): в знания агента на этот запуск
        (группы материалов — у той же работы другой ветки), строка остаётся на работе 1С без спора (F-KC)."""
        import bind
        twin = "6.2.3.1.5.1.2.1"
        name = "Прокладка трубопроводов из стальных труб на резьбовом соединении / от 15 мм до 60 мм"
        fam = ("ВК", "Прокладка трубопроводов из стальных труб на резьбовом соединении")
        kb = {"works": {twin: name, "6.2.3.1.4.1.4.2": "Прокладка трубопроводов из стальных труб на сварном соединении / от 15 мм до 60 мм"},
              "kc": {twin: {"unit": "м", "groups": {"труба": {}}}, "6.2.3.1.4.1.4.2": {"unit": "м", "groups": {}}},
              "famcodes": {fam: [(twin, "5", "от 15 мм до 60 мм", 297)]}}
        new = "6.2.3.1.4.1.8.1"
        items = [{"id": 1, "name": "Труба ВГП 25", "ext": {"РаботыВ1С": [
                     {"Код": new, "Наименование": name + ". Лимит на дренажную канализацию", "Количество": 12}]}},
                 {"id": 2, "name": "Труба ВГП 32", "ext": {"РаботыВ1С": [{"Код": "00-000123", "Количество": 3}]}},
                 {"id": 3, "name": "Труба ВГП 40", "ext": {"РаботыВ1С": [{"Код": new, "Количество": 5}]}}]
        smeta = {"6.2.3.1.4.9.9.1": {"name": "Монтаж нового узла", "unit": "шт"}, twin: {"name": name, "unit": "м"}}
        with mock.patch.object(bind, "KB", kb):
            added = self.run.register_onec_works(items, smeta)
            self.assertEqual(sorted(added), [new, "6.2.3.1.4.9.9.1"])                  # «00-…» — не код ИСР
            self.assertEqual(kb["works"][new], name + ". Лимит на дренажную канализацию")
            self.assertEqual((kb["kc"][new]["unit"], kb["kc"][new]["groups"]), ("м", {"труба": {}}))   # двойник из ветки В1
            self.assertEqual(kb["kc"]["6.2.3.1.4.9.9.1"], {"unit": "шт", "groups": {}})
            self.assertIn((new, "4", "от 15 мм до 60 мм", 297), kb["famcodes"][fam])
            bindings = [{"id": 1, "code": "6.2.3.1.4.1.4.2", "work": "сварка", "confidence": 0.6, "review": False},
                        {"id": 2, "code": "6.2.3.1.4.1.4.2", "work": "сварка", "confidence": 0.6, "review": False},
                        {"id": 3, "code": "6.2.3.1.4.1.4.2", "work": "сварка", "confidence": 0.9, "review": False,
                         "learned": "correction", "learned_token": "t1"}]
            stats = self.run.apply_onec(items, bindings, kb["works"], lambda n: "fam", None, "t1")
        b = bindings[0]
        self.assertEqual((b["code"], b["learned"], b["review"], b.get("agent_code")), (new, "onec", False, None))
        self.assertEqual(b["fcodes"], ["F-KC"])
        self.assertEqual(bindings[1]["code"], "6.2.3.1.4.1.4.2")                          # не работа ИСР — без изменений
        self.assertIn("F-1C", bindings[2]["fcodes"])                                      # решение сметчика в этой РВ — спор
        self.assertEqual((stats["bound"], stats["disputed"]), (2, 1))
        self.run.ONEC_ONLY.clear()

    def test_agent_pass(self):
        bindings = self._bindings()
        items = [{"id": b["id"], "name": b["name"]} for b in bindings]
        seen = []

        def review(client, section, object_type, items_, todo, works, **kwargs):
            seen.append(([b["id"] for b in todo], kwargs))
            if kwargs.get("local_blocks"):
                raise RuntimeError("PDF больше 100 страниц")
            return ({1: {"verdict": "заменить", "code": "6.2.3.3.1.5.1.1", "role": "В", "reason": "по ТЗ"},
                     2: {"verdict": "заменить", "code": "6.2.3.3.1.1.1.2", "role": "В", "reason": "по смете"},
                     3: {"verdict": "вопрос", "question": "к чему хомут?", "reason": ""}}, ["общий вопрос"])

        out = self.run.local_agent_pass(object(), [("ОВ2", items, bindings)], "жилой", "ТЗ", [{"type": "text", "text": "pdf"}],
                                        self.WORKS, "t1", review=review)
        self.assertEqual(seen[0][0], [1, 2, 3])                    # решение сметчика в этой РВ модель не смотрит
        self.assertTrue(seen[0][1]["all_rows"])
        self.assertEqual((seen[0][1]["local"], seen[1][1]["local_blocks"]), ("ТЗ", None))   # повтор без PDF
        self.assertEqual(out["rows"], {"1": {"code": "6.2.3.3.1.5.1.1", "role": "В", "reason": "по ТЗ"}})
        self.assertEqual(sorted(out["review"]), [2, 3])            # 1С — предложение, вопрос — вопрос
        self.assertEqual(out["questions"], ["общий вопрос"])
        s = out["stats"]
        self.assertEqual((s["checked"], s["changed"], s["onec_proposed"], s["questions"], s["confirmed"]), (3, 1, 1, 1, 0))
        self.assertIn("100 страниц", s["files_error"])

    def test_review_prompt_with_files(self):
        client = FakeClient([{"rows": [{"id": 1, "verdict": "подтвердить", "code": "", "role": "", "reason": "ок", "question": ""}],
                              "questions": []}])
        items = [{"id": 1, "name": "Решетка", "unit": "шт", "qty": 2, "system": "ОВ"}]
        bindings = [{"id": 1, "code": "6.2.3.3.1.5.1.1", "work": "Монтаж решёток", "role": "В", "confidence": 0.99, "review": False}]
        blocks = [{"type": "text", "text": "Файл ТЗ «смета.pdf»:"},
                  {"type": "document", "source": {"type": "base64", "media_type": "application/pdf", "data": "JVBERg=="}}]
        review, _ = rv_agent.review_rows(client, "ОВ2", "жилой", items, bindings, self.WORKS, local="Задание сметчика:\nвсё по смете",
                                         local_blocks=blocks, all_rows=True)
        self.assertEqual(review[1]["verdict"], "подтвердить")      # проверена и строка, где агент уверен
        turns, kwargs = client.calls[0]
        self.assertNotIn("cache", kwargs)
        self.assertEqual(kwargs["system"][0]["cache_control"], {"type": "ephemeral"})
        self.assertIn("ТЗ сметчика для ЭТОЙ РВ", kwargs["system"][0]["text"])
        self.assertIn("всё по смете", kwargs["system"][0]["text"])
        content = turns[0]["content"]
        self.assertEqual([b["type"] for b in content], ["text", "document", "text"])
        self.assertEqual(content[1]["cache_control"], {"type": "ephemeral"})
        self.assertNotIn("cache_control", blocks[1])               # исходные блоки не портим
        self.assertTrue(content[2]["text"].startswith("Строки на проверку:"))

    def test_learning_skips_confirmations(self):
        import rv_learning
        result = {"elements": [{"section": "ОВ2", "bindings": [
            {"id": 1, "name": "А", "code": "6.2.3.3.1.1.1.2", "role": "В", "review": True, "confidence": 0.5},
            {"id": 2, "name": "Б", "code": "6.2.3.3.1.1.1.4", "role": "В", "review": True, "confidence": 0.5}]}]}
        feedback = {"confirm_rest": True, "corrections": [{"id": 2, "code": "6.2.3.3.1.5.1.1", "role": ""}]}
        self.assertEqual(len(rv_learning.decisions_from_feedback(result, feedback)), 2)
        only = rv_learning.decisions_from_feedback(result, feedback, confirm_rest=False)
        self.assertEqual([(d["name"], d["kind"]) for d in only], [("Б", "correction")])
        feedback["corrections"][0]["via"] = "model"                     # принято пачкой из предложений модели
        self.assertEqual(rv_learning.decisions_from_feedback(result, feedback, confirm_rest=False), [])
        self.assertEqual(len(rv_learning.decisions_from_feedback(result, feedback)), 2)   # в обычной РВ — как ручное


class DuctCoefTest(unittest.TestCase):
    """ОВ2: построчные коэффициенты фасонных (переход, тройник, крестовина, заглушка) не обнуляются как принадлежности —
    объём работы «площадь по геометрии» складывают все изделия, и Σ количество × коэффициент равна объёму."""

    CODE = "6.2.3.3.1.1.1.4"   # Прокладка воздуховодов прямоугольного сечения / соединительные элементы, м²
    ROWS = [("Отвод 90° прямоугольного сечения из оцинк. стали кл. В 300х300 с толщиной стенки 0.8мм", 2),
            ("Переход прямоугольного сечения из оцинк. стали кл. В 200х100- Ø125 L=300мм Тип 1. с толщиной стенки 0.8мм", 2),
            ("Тройник прямоугольного сечения из оцинк. стали кл. В 200х200-200х200-200х200 L=400мм с толщиной стенки 0.8мм", 1),
            ("Крестовина прямоугольного сечения из оцинк. стали кл. В 300х300-200х200-300х300-200х200 L=500мм", 1),
            ("Заглушка прямоугольного сечения из оцинк. стали кл. В 200х200 с толщиной стенки 0.8мм", 3),
            ("Переход прямоугольного сечения из оцинк. стали кл. В 200х100- Ø125 Тип 5 совмест. с толщиной стенки 0.8мм", 1),
            ("Дроссель-клапан прямоугольный с фланцами из оцинк. стали 200х100 0,8", 2)]

    def setUp(self):
        import bind
        import web_rv_run
        bind.load(os.path.join(PROGRAM_C, "rv", "data"))
        self.bind, self.run = bind, web_rv_run
        self.items = [dict(id=str(i), name=name, unit="шт", qty=qty) for i, (name, qty) in enumerate(self.ROWS)]
        self.bindings = [dict(code=self.CODE, role="В") for _ in self.items]

    def test_fittings_keep_coef(self):
        volume, method, notes = self.bind.volume_of(self.CODE, [(it["name"], it["unit"], it["qty"]) for it in self.items])
        self.assertTrue(method.startswith(self.bind.DUCT_AREA_METHOD), method)
        coefs = self.run.row_coefs(self.items, self.bindings, {self.CODE: dict(volume=volume, method=method)})
        by_head = {it["name"].split()[0]: coefs[it["id"]] for it in self.items if "совмест" not in it["name"]}
        for head in ("Отвод", "Переход", "Тройник", "Крестовина", "Заглушка"):
            self.assertGreater(by_head[head], 0, head)
        self.assertEqual(by_head["Дроссель-клапан"], 0)                         # не воздуховод — объём не ведёт
        self.assertEqual(coefs["5"], 0)                                         # переход без длины: площадь не определяется
        self.assertTrue(any("площадь не определяется" in n for n in notes), notes)
        self.assertAlmostEqual(sum(it["qty"] * coefs[it["id"]] for it in self.items), volume, places=3)

    def test_other_sections_keep_accessory_filter(self):
        # Вне ОВ2 фильтр принадлежностей прежний: при нескольких ведущих классах переход/тройник объём не ведут
        self.assertIn("перех", self.bind.ACCESSORY)
        self.assertIn("тройн", self.bind.ACCESSORY)


class PaintCoefTest(unittest.TestCase):
    """[В 10.11] Окраска трубопроводов: объём — площадь окрашиваемых труб; в 1С он складывается Σ количество ×
    коэффициент, поэтому коэффициент у грунтовки = площадь / количество грунтовки, у краски и растворителя — 0."""

    ROWS = [("Труба стальная электросварная 57х3,5 ГОСТ 10704-91", "м", 40),
            ("Труба стальная водогазопроводная Ду25х3,2 ГОСТ 3262-75", "м", 30),
            ("Грунтовка ГФ-021", "кг", 4),
            ("Грунтовка ГФ-021 серая", "кг", 2),
            ("Эмаль ПФ-115", "кг", 8),
            ("Уайт-спирит", "л", 1)]

    def setUp(self):
        import bind
        import web_rv_run
        bind.load(os.path.join(PROGRAM_C, "rv", "data"))
        self.bind, self.run = bind, web_rv_run

    def _coefs(self, rows):
        items = [dict(id=i + 1, name=n, unit=u, qty=q, system="ПУ", row=i + 1, element="") for i, (n, u, q) in enumerate(rows)]
        by_id = {b["id"]: b for b in self.bind.bind("ОВ1", items, "жилой")}
        bindings = [by_id[it["id"]] for it in items]
        volumes = self.bind.volumes("ОВ1", items, bindings)
        paint = next(code for code in volumes if self.bind.PAINT_WORK.search(self.bind.KB["works"][code]))
        coefs = self.run.row_coefs(items, bindings, volumes)
        return items, bindings, volumes[paint]["volume"], coefs, paint

    def test_primer_carries_area(self):
        items, bindings, volume, coefs, paint = self._coefs(self.ROWS)
        self.assertTrue(paint.startswith("6.2.3.2.7.2.1."))                  # теплоснабжение ПУ — ветка 7
        self.assertAlmostEqual(volume, 3.14159265 * (57 * 40 + 33.5 * 30) / 1000, places=2)
        by_name = {it["name"]: coefs[it["id"]] for it in items}
        self.assertEqual(by_name["Грунтовка ГФ-021"], by_name["Грунтовка ГФ-021 серая"])
        self.assertGreater(by_name["Грунтовка ГФ-021"], 0)
        self.assertEqual((by_name["Эмаль ПФ-115"], by_name["Уайт-спирит"]), (0, 0))
        on_paint = [it for it, b in zip(items, bindings) if b["code"] == paint]
        self.assertAlmostEqual(sum(it["qty"] * coefs[it["id"]] for it in on_paint), volume, places=3)

    def test_without_primer_paint_carries_area(self):
        items, bindings, volume, coefs, paint = self._coefs([r for r in self.ROWS if not r[0].startswith("Грунтовка")])
        by_name = {it["name"]: coefs[it["id"]] for it in items}
        self.assertAlmostEqual(by_name["Эмаль ПФ-115"] * 8, volume, places=3)
        self.assertEqual(by_name["Уайт-спирит"], 0)


class KrChoiceTest(unittest.TestCase):
    """Крепёж (Кр) делится между работами прокладки. Выбор сметчика сильнее: строка идёт в выбранную работу целиком.
    Скоба для изоляции и теплоизоляционная трубка — изоляция труб, не крепёж и не КИП."""

    ROWS = [("Труба стальная электросварная 159х4,5 ГОСТ 10704-91", "м", 221),
            ("Труба стальная электросварная 57х3,5 ГОСТ 10704-91", "м", 100),
            ("Анкер клин 12х100 мм", "шт", 22),
            ("Скоба монтажная", "шт", 178),
            ("Скоба для изоляции из вспененного полиэтилена", "шт", 60),
            ("Трубка Energoflex Super 60/13", "м", 100)]
    INSULATION = "6.2.3.2.2.2.2"      # Изоляция трубопроводов цилиндрами / вспененный полиэтилен или каучук

    def setUp(self):
        import bind
        import rv_learning
        bind.load(os.path.join(PROGRAM_C, "rv", "data"))
        self.bind, self.learning = bind, rv_learning
        self.items = [dict(id=i + 1, name=n, unit=u, qty=q, system="отопление", row=i + 1, element="")
                      for i, (n, u, q) in enumerate(self.ROWS)]

    def _bind(self):
        by_id = {b["id"]: b for b in self.bind.bind("ОВ1", self.items, "паркинг")}
        return [by_id[it["id"]] for it in self.items]

    def _where(self, index, code, token, own):
        bindings = self._bind()
        entries = {self.learning.key_of("ОВ1", "отопление", self.items[index]["name"]):
                   dict(code=code, role="Кр", kind="correction", token=token, count=1)}
        self.learning.apply(entries, "ОВ1", self.items, bindings, self.bind.KB["works"], self.bind.fam_of,
                            self.bind.sys_code, own_token=own)
        volumes = self.bind.volumes("ОВ1", self.items, bindings)
        result = self.bind.rv("ОВ1", self.items, bindings, volumes, self.bind.distribute("ОВ1", self.items, bindings, volumes))
        return bindings[index]["role"], [(w["code"], m["qty"]) for w in result["works"] for m in w["materials"]
                                         if m["id"] == self.items[index]["id"]]

    def test_insulation_rows(self):
        bindings = self._bind()
        self.assertEqual((bindings[4]["code"], bindings[4]["role"]), (self.INSULATION, "Р"))      # не Кр по трубам
        self.assertEqual((bindings[5]["code"], bindings[5]["role"]), (self.INSULATION, "С-С"))    # не «термометр, манометр»
        self.assertEqual(bindings[3]["role"], "Кр")                                               # обычная скоба — крепёж
        self.assertEqual(self.bind.volumes("ОВ1", self.items, bindings)[self.INSULATION]["volume"], 100.0)

    def test_choice_outside_consumers_takes_whole_row(self):
        # Память из другой РВ: «скоба монтажная» — в изоляцию. Работа не из потребителей крепежа → вся строка там, роль Р.
        self.assertEqual(self._where(3, self.INSULATION, "0123456789abcdef", "f" * 16), ("Р", [(self.INSULATION, 178.0)]))

    def test_old_confirmation_does_not_undo_rule(self):
        # В памяти — подтверждение прежней разбивки «скобы для изоляции» как крепежа труб; по правилу она — изоляция.
        bindings = self._bind()
        entries = {self.learning.key_of("ОВ1", "отопление", self.items[4]["name"]):
                   dict(code="6.2.3.2.1.1.1", role="Кр", kind="confirmed", token="0123456789abcdef", count=1)}
        self.learning.apply(entries, "ОВ1", self.items, bindings, self.bind.KB["works"], self.bind.fam_of, self.bind.sys_code)
        self.assertEqual((bindings[4]["code"], bindings[4]["role"]), (self.INSULATION, "Р"))
        # Явное исправление сметчика (роль строки на странице была Кр) — сильнее правила; работа не «прокладка» → вся строка, Р.
        self.assertEqual(self._where(4, "6.2.3.2.2.2.1", "0123456789abcdef", "f" * 16), ("Р", [("6.2.3.2.2.2.1", 60.0)]))

    def test_choice_among_consumers(self):
        small = "6.2.3.2.1.1.2"
        # В этой же РВ сметчик перенёс анкеры на одну из труб — вся строка под ней.
        self.assertEqual(self._where(2, small, "f" * 16, "f" * 16), ("Кр", [(small, 22)]))
        # То же решение из другой РВ: между трубами крепёж по-прежнему делится по правилу.
        role, parts = self._where(2, small, "0123456789abcdef", "f" * 16)
        self.assertEqual((role, sorted(code for code, _ in parts), sum(q for _, q in parts)),
                         ("Кр", ["6.2.3.2.1.1.1", small], 22))


class HeatSupplyTest(unittest.TestCase):
    """[В 10.11] ЛРВ теплоснабжения (калориферы приточных установок, воздушно-тепловые завесы) — работы отдельного раздела
    КЦ 6.2.3.2.7; сами завесы — 6.2.3.2.6.1 по нагреву из имени."""

    def test_system_by_name(self):
        import rv_input
        for text in ("Теплоснабжение", "Теплоснабжение паркинга", "Теплоснабжение калориферов П1"):
            self.assertEqual(rv_input.system_1c(text), ("ОВ1", "ПУ"), text)
        self.assertEqual(rv_input.system_1c("Отопление"), ("ОВ1", "отопление"))

    def test_works_of_branch_7(self):
        import bind
        bind.load(os.path.join(PROGRAM_C, "rv", "data"))
        rows = [("Труба стальная электросварная 57х3,5 ГОСТ 10704-91", "м", 40), ("Кран шаровой Ду25", "шт", 6),
                ("Узел смесительный для калорифера", "шт", 2), ("Насос циркуляционный", "шт", 1),
                ("Термометр биметаллический", "шт", 4), ("Цилиндр K-FLEX ST 54/13", "м", 40),
                ("Цилиндр минераловатный 57х30", "м", 10), ("Завеса воздушно-тепловая водяная КЭВ-28П", "шт", 2)]
        items = [dict(id=i + 1, name=n, unit=u, qty=q, system="ПУ", row=i + 1, element="") for i, (n, u, q) in enumerate(rows)]
        codes = {b["name"].split()[0]: b["code"] for b in bind.bind("ОВ1", items, "паркинг")}
        for head in ("Труба", "Кран", "Узел", "Насос", "Термометр"):
            self.assertTrue(codes[head].startswith("6.2.3.2.7."), (head, codes[head]))
        by_name = {b["name"]: b["code"] for b in bind.bind("ОВ1", items, "паркинг")}
        self.assertEqual(by_name["Цилиндр K-FLEX ST 54/13"], "6.2.3.2.7.2.2.2")           # вспененные
        self.assertEqual(by_name["Цилиндр минераловатный 57х30"], "6.2.3.2.7.2.2.1")      # минвата
        self.assertEqual(by_name["Завеса воздушно-тепловая водяная КЭВ-28П"], "6.2.3.2.6.1.2")


class RvrTest(unittest.TestCase):
    """Заказ-наряд РВР: работы кода 12. В КЦ работы 12.1.11–12.1.15 повторяют работы 6.2.3 по названию и материалам —
    агент подбирает работу по правилам кода 6 и ставит её пару (bind.to_rvr); пары строит rv_kc_import.build_rvr."""

    def test_build_pairs(self):
        import rv_kc_import
        works = {
            "6.2.3.4.1.4.1.1": dict(name="Затяжка кабеля, провода в трубу / до 6 мм2", guid="g1",
                                    path="Инженерные системы / Электроснабжение / Электромонтажные работы в нежилой части / Прокладка кабеля / Затяжка кабеля, провода в трубу"),
            "6.2.3.4.2.2.1.1": dict(name="Затяжка кабеля, провода в трубу / до 6 мм2", guid="g2",
                                    path="Инженерные системы / Электроснабжение / Электромонтажные работы в квартирах / Прокладка кабеля / Затяжка кабеля, провода в трубу"),
            "6.2.3.4.4.1.1.1": dict(name="Затяжка кабеля, провода в трубу / до 6 мм2", guid="g3",
                                    path="Инженерные системы / Электроснабжение / Электромонтажные работы ЦИН / Прокладка кабеля / Затяжка кабеля, провода в трубу"),
            "6.2.3.4.1.9.1.1": dict(name="Монтаж только в основном проекте", guid="g4", path="Инженерные системы / Электроснабжение / Электромонтажные работы в нежилой части / Монтаж только в основном проекте"),
            "12.1.14.2.1.6.1": dict(name="Затяжка кабеля, провода в трубу / до 6 мм2", guid="r1",
                                    path="Доп. работы / Электроснабжение / Электромонтажные работы Жилая часть / Монтажные работы / Затяжка кабеля, провода в трубу"),
            "12.1.14.3.2.24.1": dict(name="Затяжка кабеля, провода в трубу / до 6 мм2", guid="r2",
                                     path="Доп. работы / Электроснабжение / Электромонтажные работы Нежилая часть / Монтажные работы / Затяжка кабеля, провода в трубу"),
            "12.1.14.1.3.1": dict(name="Демонтаж кабеля, провода", guid="r3", path="Доп. работы / Электроснабжение / Демонтажные работы / Демонтаж кабеля, провода"),
        }
        mats = {"12.1.14.1.3.1": [dict(group="Кабель", material="Кабель ВВГ", unit="м", coef=1.0, main=True, edit=False)] * 2,
                "12.1.14.3.2.24.1": [dict(group="Кабель", material="Кабель ВВГ", unit="м", coef=1.0, main=True, edit=False)]}
        data, unsure = rv_kc_import.build_rvr(works, mats, {"6.2.3.4.1.4.1.1": "м"})
        self.assertEqual(data["pairs"]["6.2.3.4.1.4.1.1"], ["12.1.14.3.2.24.1", 1])      # нежилая часть
        self.assertEqual(data["pairs"]["6.2.3.4.2.2.1.1"], ["12.1.14.2.1.6.1", 1])       # квартиры — жилая часть
        self.assertEqual(data["pairs"]["6.2.3.4.4.1.1.1"], ["12.1.14.3.2.24.1", 0])      # ЦИН: такой части в коде 12 нет — нежилая, не наверняка
        self.assertNotIn("6.2.3.4.1.9.1.1", data["pairs"])
        self.assertEqual(unsure, 1)
        self.assertEqual(data["works"]["12.1.14.3.2.24.1"][2:], ["м", "6.2.3.4.1.4.1.1"])   # единица и материалы — от пары
        self.assertEqual(data["works"]["12.1.14.1.3.1"][2:], ["м", ""])                     # без пары: единица по основным материалам
        self.assertEqual(data["mats"], [["12.1.14.1.3.1", "Кабель", "Кабель ВВГ", "м", 1.0, True]])   # материалы — только у работ без пары

    def test_to_rvr(self):
        import bind
        bind.load(os.path.join(PROGRAM_C, "rv", "data"))
        pairs = bind.load_rvr(os.path.join(PROGRAM_C, "rv", "data"))
        self.assertGreater(len(pairs), 4000)
        self.assertEqual(bind.rvr_code("6.2.3.2.1.1.2"), "12.1.12.3.1.2")
        self.assertEqual(bind.KB["works"]["12.1.12.3.1.2"], bind.KB["works"]["6.2.3.2.1.1.2"])
        self.assertIs(bind.KB["kc"]["12.1.12.3.1.2"], bind.KB["kc"]["6.2.3.2.1.1.2"])       # группы материалов — общие, память не растёт
        self.assertIsNone(bind.rvr_code("6.2.3.2.1.7.2"))                                    # в коде 12 такой работы нет
        unsure = next(code for code, (pair, sure) in pairs.items() if not sure)
        rows = [dict(code="6.2.3.2.1.1.2", role="В", flags=[], fcodes=[], review=False, confidence=0.9,
                     alts=[dict(code="6.2.3.2.1.1.1", work="x"), dict(code="6.2.3.2.1.7.2", work="y")]),
                dict(code="6.2.3.2.1.7.2", role="В", flags=[], fcodes=[], review=False, confidence=0.9),
                dict(code="6.2.3.2.1.1.2", role="Кр", flags=[], fcodes=[], review=False, confidence=0.8,
                     consumers=["6.2.3.2.1.1.1", "6.2.3.2.1.1.2"]),
                dict(code=unsure, role="В", flags=[], fcodes=[], review=False, confidence=0.9),
                dict(code=None, role="?", flags=["F-NEW: x"], fcodes=["F-NEW"], review=True, confidence=0)]
        bind.to_rvr("ОВ1", rows)
        self.assertEqual((rows[0]["code"], rows[0]["code6"], rows[0]["review"], rows[0]["fcodes"]),
                         ("12.1.12.3.1.2", "6.2.3.2.1.1.2", False, []))
        self.assertEqual([a["code"] for a in rows[0]["alts"]], ["12.1.12.3.1.1"])            # вариант без пары отброшен
        self.assertEqual((rows[1]["code"], rows[1]["review"], rows[1]["fcodes"]), (None, True, ["F-RVR"]))
        self.assertIn("Установка неподвижных опор горизонтальных", rows[1]["flags"][0])     # что искали — в пометке
        self.assertEqual(rows[2]["consumers"], ["12.1.12.3.1.1", "12.1.12.3.1.2"])
        self.assertEqual((rows[3]["code"], rows[3]["review"], rows[3]["fcodes"]), (pairs[unsure][0], True, ["F-RVR"]))
        self.assertEqual((rows[4]["code"], rows[4]["fcodes"]), (None, ["F-NEW"]))

    def test_review_translates_code(self):
        import bind
        bind.load(os.path.join(PROGRAM_C, "rv", "data"))
        bind.load_rvr(os.path.join(PROGRAM_C, "rv", "data"))
        client = FakeClient([{"rows": [
            {"id": 1, "verdict": "заменить", "code": "6.2.3.2.1.1.1", "role": "В", "reason": "по карточке", "question": ""},
            {"id": 2, "verdict": "заменить", "code": "6.2.3.2.1.7.2", "role": "В", "reason": "опора", "question": ""}], "questions": []}])
        items = [{"id": 1, "name": "Труба 159х4,5", "unit": "м", "qty": 2, "system": "отопление"},
                 {"id": 2, "name": "Опора", "unit": "шт", "qty": 2, "system": "отопление"}]
        bindings = [{"id": 1, "code": "12.1.12.3.1.2", "work": "x", "role": "В", "confidence": 0.5, "review": True},
                    {"id": 2, "code": "", "work": "", "role": "?", "confidence": 0, "review": True}]
        with mock.patch.object(rv_agent, "CODE_TRANSLATE", bind.rvr_code):
            review, _ = rv_agent.review_rows(client, "ОВ1", "жилой", items, bindings, bind.KB["works"])
        self.assertEqual((review[1]["verdict"], review[1]["code"]), ("заменить", "12.1.12.3.1.1"))   # код 6 по карточке → пара в коде 12
        self.assertEqual(review[2]["verdict"], "вопрос")                                             # пары нет — вопрос, не код 6
        self.assertIn("в коде 12", review[2]["question"])
        self.assertIn("заказ-наряду РВР", client.calls[0][1]["system"])


class FittingLengthTest(unittest.TestCase):
    """[В 11.11] Объём прокладки трубопроводов = метраж труб + длина по оси фасонных частей по каталогу (HALIFAX для SML);
    коэффициент фасонной части = её длина, м — в 1С Σ количество × коэффициент = объём."""

    SML = "6.2.3.1.1.1.2.1"       # Прокладка трубопроводов из чугунных труб безраструбных

    def setUp(self):
        import bind
        import web_rv_run
        bind.load(os.path.join(PROGRAM_C, "rv", "data"))
        self.bind, self.run = bind, web_rv_run

    def test_lengths_by_catalog(self):
        cases = {"Отвод чугунный SML 88° DN100": 0.22,             # 2A, A = 110
                 "Отвод SML 45° DN100": 0.14,
                 "Отвод SML 67,5° DN100": 0.18,                    # ~69°
                 "Отвод 87° Ду 50 SML": 0.15,
                 "Тройник SML 45° DN100x100": 0.485,               # A + C = 275 + 210
                 "Тройник SML DN100/50 45°": 0.353,
                 "Тройник SML 100х100 88° с ревизией": 0.42,
                 "Крестовина SML 88° 100x100x100": 0.471,          # A + 2C = 233 + 2·119
                 "Переходник SML 110х50": 0.08,                     # наружный 110 → DN100
                 "Ревизия SML DN100": 0.25,
                 "Ревизия SML DN100 с прямоугольной крышкой": 0.32}
        for name, length in cases.items():
            self.assertEqual(self.bind.fitting_length(self.SML, name, "шт")[:3], (length, self.bind.fitting_length(self.SML, name, "шт")[1], False), name)
        self.assertEqual(self.bind.fitting_length(self.SML, "Отвод SML DN100", "шт")[0], 0.22)     # угла нет — 88°, приближённо
        self.assertTrue(self.bind.fitting_length(self.SML, "Отвод SML DN100", "шт")[2])
        for name in ("Хомут SML Rapid DN100", "Заглушка SML DN50", "Труба чугунная безраструбная SML DN100"):
            self.assertIsNone(self.bind.fitting_length(self.SML, name, "шт"), name)
        self.assertIsNone(self.bind.fitting_length("6.2.3.1.1.1.1.1", "Отвод ПП 110/45", "шт"))   # каталога для ПП нет

    def test_volume_and_coefs(self):
        rows = [("Труба чугунная безраструбная SML DN100 L=3000", "м", 30), ("Отвод чугунный SML 88° DN100", "шт", 6),
                ("Тройник SML 45° DN100x100", "шт", 3), ("Хомут SML Rapid DN100", "шт", 20), ("Заглушка SML DN100", "шт", 1)]
        items = [dict(id=i + 1, name=n, unit=u, qty=q, system="К1", row=i + 1, element="") for i, (n, u, q) in enumerate(rows)]
        by_id = {b["id"]: b for b in self.bind.bind("ВК", items, "жилой")}
        bindings = [by_id[it["id"]] for it in items]
        self.assertTrue(all(b["code"] == self.SML for b in bindings))
        volume = self.bind.volumes("ВК", items, bindings)[self.SML]
        self.assertAlmostEqual(volume["volume"], 30 + 6 * 0.22 + 3 * 0.485, places=4)
        self.assertIn("длина фасонных частей по каталогу", volume["method"])
        coefs = self.run.row_coefs(items, bindings, {self.SML: volume})
        self.assertEqual([coefs[it["id"]] for it in items], [1.0, 0.22, 0.485, 0, 0])
        self.assertAlmostEqual(sum(it["qty"] * coefs[it["id"]] for it in items), volume["volume"], places=4)


class OneCIdsTest(unittest.TestCase):
    """Шапка РВ для 1С: код и УИД сайта, GUID ЛРВ без приставки «Смета-», смета и её GUID — и в корне, и в Документе."""

    GUID = "ADA1BF7C-1234-5678-9ABC-DEF012345678"
    TOKEN = "fedcba9876543210"

    def setUp(self):
        import web_rv_run
        self.run = web_rv_run
        self.result = {"elements": [], "summary": {}, "sections": ["ВК"], "object_type": "жилой", "source_name": "lrv.json", "notes": []}
        self.work = {"lrv_id": "Смета-" + self.GUID, "version": "2026-11-01T08:00:00", "object": "ЖК Тест / Смета ВК К1"}

    def test_clean_guid(self):
        self.assertEqual(self.run.clean_guid("Смета-" + self.GUID), self.GUID)
        self.assertEqual(self.run.clean_guid("Сверка-" + self.GUID.lower()), self.GUID.lower())
        self.assertEqual(self.run.clean_guid(self.GUID), self.GUID)
        self.assertEqual((self.run.clean_guid("Смета-match-1"), self.run.clean_guid("ЛРВ-000123"), self.run.clean_guid("")), ("", "", ""))

    def test_site_uuid_stable(self):
        first = self.run.site_uuid(self.TOKEN)
        self.assertEqual(len(first), 36)
        self.assertEqual(first, self.run.site_uuid(self.TOKEN))
        self.assertNotEqual(first, self.run.site_uuid("0123456789abcdef"))
        self.assertEqual(self.run.site_uuid(""), "")

    def test_ids_from_job(self):
        # Обычный пакет ЛРВ (раздел 2): шапки обработки нет, смета и её GUID — из job.meta, записанного 1c_rv.php
        job = {"token": self.TOKEN, "lrv_id": self.work["lrv_id"], "meta": {"smeta": "Смета ВК К1", "smeta_id": self.GUID}}
        out = self.run.export_1c(self.result, self.work, {}, None, None, job)
        self.assertEqual((out["ИдентификаторЛРВ"], out["ЛРВGUID"]), ("Смета-" + self.GUID, self.GUID))
        self.assertEqual((out["КодСайта"], out["УИДСайта"]), (self.TOKEN, self.run.site_uuid(self.TOKEN)))
        self.assertEqual((out["Смета"], out["СметаGUID"]), ("Смета ВК К1", self.GUID))
        doc = out["СопоставлениеРВиЛРВ"]["Документ"]
        self.assertEqual((doc["КодСайта"], doc["УИДСайта"], doc["ЛРВGUID"], doc["Смета"], doc["СметаGUID"]),
                         (self.TOKEN, out["УИДСайта"], self.GUID, "Смета ВК К1", self.GUID))
        self.assertEqual((doc["Сопоставление"], doc["СопоставлениеGUID"]), ("", ""))
        self.assertNotIn("Сопоставление1С", out)

    def test_smeta_guid_from_lrv_id(self):
        # Задача без meta (старая): GUID сметы — из идентификатора ЛРВ
        out = self.run.export_1c(self.result, self.work, {}, None, None, {"token": self.TOKEN})
        self.assertEqual((out["Смета"], out["СметаGUID"]), ("", self.GUID))

    def test_head_wins(self):
        # Пакет из обработки «Соответствие РВ и ЛРВ»: смета и сопоставление — как прислала 1С
        job = {"token": self.TOKEN, "meta": {"smeta": "Из пакета", "smeta_id": "22222222-2222-2222-2222-222222222222"}}
        head = {"Сопоставление": "Сопоставление РВ и ЛРВ 000006700 от 03.11.2026", "СопоставлениеGUID": "f475a8ab-0000-0000-0000-000000000001",
                "Смета": "Из шапки", "СметаGUID": "11111111-1111-1111-1111-111111111111"}
        out = self.run.export_1c(self.result, self.work, {}, None, head, job)
        self.assertEqual((out["Смета"], out["СметаGUID"], out["Сопоставление"], out["СопоставлениеGUID"]),
                         ("Из шапки", head["СметаGUID"], head["Сопоставление"], head["СопоставлениеGUID"]))
        self.assertEqual(out["Сопоставление1С"], head)
        doc = out["СопоставлениеРВиЛРВ"]["Документ"]
        self.assertEqual((doc["СметаGUID"], doc["СопоставлениеGUID"], doc["КодСайта"]), (head["СметаGUID"], head["СопоставлениеGUID"], self.TOKEN))

    def test_without_job(self):
        out = self.run.export_1c(self.result, {"lrv_id": "ЛРВ-000123"}, {})
        self.assertEqual((out["ЛРВGUID"], out["КодСайта"], out["УИДСайта"], out["Смета"], out["СметаGUID"]), ("", "", "", "", ""))


class ExtraWorksTest(unittest.TestCase):
    """Работы без материалов: гидроиспытания, испытание и наладка, ПНР — добавляются по работам РВ."""

    WORKS = {"6.2.3.1.1.1.1.1": "Прокладка трубопроводов из ПП труб / в строительном исполнении",
             "6.2.3.1.1.5.1.1": "Гидравлическое испытание трубопроводов системы хозяйственно-бытовой канализации",
             "6.2.3.1.1.5.2.1": "Гидравлическое испытание трубопроводов системы хозяйственно-бытовой канализации СКБ (СОШ, ДОУ)",
             "6.2.3.1.7.2.1": "Монтаж шахт-пакетов бескаркасных / однозонных / без циркуляции",
             "6.2.3.1.7.3.1": "Гидравлическое испытание трубопроводов шахт-пакетов / тип 1 без К1",
             "6.2.3.1.99.5.1": "Сдача систем в эксплуатирующую организацию СКБ (СОШ, ДОУ)",
             "6.2.3.3.1.1.1.2": "Прокладка воздуховодов прямоугольного сечения / толщина стенки от 0,71 до 0,9 мм",
             "6.2.3.3.1.99.3.1": "Испытание и наладка системы",
             "6.2.3.4.1.1.1.4": "Установка и коммутация щитов ВРУ / 3 панели",
             "6.2.3.4.1.1.5.1": "Пуско-наладочные работы ВРУ"}
    KC = {"6.2.3.1.1.5.1.1": {"unit": "м"}, "6.2.3.1.7.3.1": {"unit": "шт"}, "6.2.3.3.1.99.3.1": {"unit": "комплекс"},
          "6.2.3.4.1.1.5.1": {"unit": "шт"}, "6.2.3.1.1.1.1.1": {"unit": "м"}, "6.2.3.1.7.2.1": {"unit": "шт"},
          "6.2.3.4.1.1.1.4": {"unit": "шт"}, "6.2.3.1.99.5.1": {"unit": "комплекс"}}

    def test_vk_hydro_test_and_shafts(self):
        import rv_extra
        rv_works = [{"code": "6.2.3.1.1.1.1.1", "volume": 944.15, "materials": [1]},
                    {"code": "6.2.3.1.7.2.1", "volume": 82, "materials": [1]}]
        added = rv_extra.add_works("ВК", rv_works, self.WORKS, self.KC, "жилой")
        by_code = {w["code"]: w for w in added}
        self.assertEqual(set(by_code), {"6.2.3.1.1.5.1.1", "6.2.3.1.7.3.1"})
        self.assertEqual((by_code["6.2.3.1.1.5.1.1"]["volume"], by_code["6.2.3.1.1.5.1.1"]["unit"]), (944.15, "м"))
        self.assertEqual(by_code["6.2.3.1.7.3.1"]["volume"], 82)
        self.assertTrue(all(w["auto"] and w["materials"] == [] for w in added))
        # уже есть в РВ — второй раз не добавляется; СКБ-вариант у жилого не берётся
        again = rv_extra.add_works("ВК", rv_works + added, self.WORKS, self.KC, "жилой")
        self.assertEqual(again, [])
        skb = rv_extra.add_works("ВК", rv_works, self.WORKS, self.KC, "СКБ")
        self.assertIn("6.2.3.1.1.5.2.1", {w["code"] for w in skb})
        self.assertIn("6.2.3.1.99.5.1", {w["code"] for w in skb})

    def test_vent_and_eom(self):
        import rv_extra
        vent = rv_extra.add_works("ОВ2", [{"code": "6.2.3.3.1.1.1.2", "volume": 4455.0, "materials": [1]}], self.WORKS, self.KC, "жилой")
        self.assertEqual([(w["code"], w["volume"], w["unit"]) for w in vent], [("6.2.3.3.1.99.3.1", 1, "комплекс")])
        eom = rv_extra.add_works("ЭОМ", [{"code": "6.2.3.4.1.1.1.4", "volume": 2, "materials": [1]}], self.WORKS, self.KC, "жилой")
        self.assertEqual([(w["code"], w["volume"]) for w in eom], [("6.2.3.4.1.1.5.1", 2)])
        self.assertEqual(rv_extra.add_works("ЭОМ", [], self.WORKS, self.KC, "жилой"), [])


class StorageTest(unittest.TestCase):
    """Результат и строки формы хранятся на сервере сжатыми (.json.gz); старые задачи — несжатые."""

    def test_gz_roundtrip_and_form_path(self):
        import types
        import web_rv_run
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "x_rv.json.gz")
            web_rv_run._write(path, {"a": "кириллица", "n": [1, 2]})
            with open(path, "rb") as handle:
                self.assertEqual(handle.read(2), b"\x1f\x8b")
            self.assertEqual(web_rv_run._read(path), {"a": "кириллица", "n": [1, 2]})
            plain = os.path.join(tmp, "y_rv.json")
            web_rv_run._write(plain, {"b": 1})
            self.assertEqual(web_rv_run._read(plain), {"b": 1})
        self.assertEqual(web_rv_run.form_path(types.SimpleNamespace(out_json="/d/t_rv.json.gz")), "/d/t_rv_form.json.gz")
        self.assertEqual(web_rv_run.form_path(types.SimpleNamespace(out_json="/d/t_rv.json")), "/d/t_rv_form.json")


class LearningTest(unittest.TestCase):
    """Память решений инженера: что запоминается по проверке и как применяется к привязкам."""

    WORKS = {"6.2.3.1.1.1.1.1": "Прокладка трубопроводов из ПП труб / в строительном исполнении",
             "6.2.3.1.1.1.2.1": "Прокладка трубопроводов из чугунных труб безраструбных / до 100 мм",
             "6.2.3.1.3.1.2.1": "Прокладка трубопроводов из чугунных труб безраструбных / до 100 мм",
             "6.2.3.1.1.2.1.1": "Монтаж арматуры / кран"}

    @staticmethod
    def _sys_code(section, system):
        return {"К1": "1", "К3": "3"}.get(system or "")

    @staticmethod
    def _fam(work):
        return work.split(" / ")[0]

    def _result(self):
        return {"elements": [{"section": "ВК", "element": "", "bindings": [
            {"id": 1, "name": "Манжета HT 110", "system": "К1", "code": "6.2.3.1.1.1.1.1", "role": "С-В", "confidence": 0.5, "review": True},
            {"id": 2, "name": "Переход HL9", "system": "К1", "code": "6.2.3.1.1.1.1.1", "role": "С-В", "confidence": 0.62, "review": True},
            {"id": 3, "name": "Труба PP-H 110", "system": "К1", "code": "6.2.3.1.1.1.1.1", "role": "В", "confidence": 0.98, "review": False},
            {"id": 4, "name": "Что-то без работы", "system": "К1", "code": None, "role": "?", "confidence": 0.0, "review": True},
        ]}]}

    def test_decisions_corrections_and_confirmations(self):
        import rv_learning
        feedback = {"corrections": [{"id": 1, "code": "6.2.3.1.1.1.2.1", "role": "С-В"},
                                    {"id": 2, "code": "6.2.3.1.1.1.1.1", "role": "С-В"},    # тот же код — подтверждение
                                    {"id": 99, "code": "6.2.3.1.1.1.1.1", "role": "В"}],    # нет такой строки
                    "confirm_rest": True}
        feedback["corrections"].append({"id": 3, "coef": "0,5"})            # только коэффициент — работа остаётся
        decisions = rv_learning.decisions_from_feedback(self._result(), feedback)
        kinds = {d["name"]: d["kind"] for d in decisions}
        self.assertEqual(kinds, {"Манжета HT 110": "correction", "Переход HL9": "confirmed", "Труба PP-H 110": "confirmed"})
        self.assertEqual([d for d in decisions if d["name"] == "Труба PP-H 110"][0]["coef"], 0.5)
        # строка без работы в подтверждения не попадает; уверенная (98 %) — только из-за коэффициента
        self.assertNotIn("Что-то без работы", kinds)
        self.assertEqual(decisions[0]["key"], "ВК|к1|манжета ht 110")

    def test_merge_counts_and_latest_wins(self):
        import rv_learning
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "learn.json")
            base = dict(key="ВК|к1|манжета ht 110", section="ВК", system="К1", name="Манжета HT 110", role="С-В")
            rv_learning.merge(path, [dict(base, code="6.2.3.1.1.1.2.1", kind="correction")], user="ivanov")
            rv_learning.merge(path, [dict(base, code="6.2.3.1.1.1.2.1", kind="confirmed", coef=2.5)], user="petrov")
            entries = rv_learning.load(path)
            entry = entries["ВК|к1|манжета ht 110"]
            self.assertEqual((entry["code"], entry["count"], entry["kind"], entry["user"], entry["coef"]),
                             ("6.2.3.1.1.1.2.1", 2, "correction", "petrov", 2.5))
            rv_learning.merge(path, [dict(base, code="6.2.3.1.1.1.2.1", kind="confirmed")], user="petrov")
            self.assertEqual(rv_learning.load(path)["ВК|к1|манжета ht 110"]["coef"], 2.5)   # коэффициент остаётся
            rv_learning.merge(path, [dict(base, code="6.2.3.1.1.2.1.1", kind="correction")], user="sidorov")
            entry = rv_learning.load(path)["ВК|к1|манжета ht 110"]
            self.assertEqual((entry["code"], entry["count"], entry.get("coef")), ("6.2.3.1.1.2.1.1", 1, None))   # новое решение — счёт заново, коэффициент сброшен
            self.assertEqual(rv_learning.summary(rv_learning.load(path))["corrections"], 1)

    def test_forget_rolls_back_one_rv(self):
        """Откат согласования: решения одной РВ уходят из памяти, прежние решения по тем же ключам возвращаются."""
        import rv_learning
        a, b = "aaaaaaaaaaaaaaaa", "bbbbbbbbbbbbbbbb"
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "learn.json")
            cuff = dict(key="ВК|к1|манжета ht 110", section="ВК", system="К1", name="Манжета HT 110", role="С-В")
            pipe = dict(key="ВК|к1|труба pp-h 110", section="ВК", system="К1", name="Труба PP-H 110", role="В")
            rv_learning.merge(path, [dict(cuff, code="6.2.3.1.1.1.2.1", kind="correction")], user="ivanov", source="ЛРВ 1", token=a)
            # проба: другая РВ меняет решение по манжете и добавляет трубу — дважды (повторная проверка той же РВ)
            for _ in range(2):
                rv_learning.merge(path, [dict(cuff, code="6.2.3.1.1.2.1.1", kind="correction"),
                                         dict(pipe, code="6.2.3.1.1.1.1.1", kind="confirmed")],
                                  user="parfenov", source="ЛРВ 2", token=b)
            entry = rv_learning.load(path)[cuff["key"]]
            self.assertEqual((entry["code"], entry["token"], entry["prev"]["code"], entry["prev"]["token"]),
                             ("6.2.3.1.1.2.1.1", b, "6.2.3.1.1.1.2.1", a))
            self.assertEqual(rv_learning.forget(path, token=b, source="ЛРВ 2"), (1, 1))
            entries = rv_learning.load(path)
            self.assertNotIn(pipe["key"], entries)
            restored = entries[cuff["key"]]
            self.assertEqual((restored["code"], restored["user"], restored["token"], restored["count"]),
                             ("6.2.3.1.1.1.2.1", "ivanov", a, 1))
            self.assertEqual(rv_learning.forget(path, token=b, source="ЛРВ 2"), (0, 0))   # повторный откат — ничего
            self.assertEqual(rv_learning.forget(path, token=a), (1, 0))
            self.assertEqual(rv_learning.load(path), {})

    def test_forget_legacy_entries_by_source(self):
        """Записи до появления token узнаются по имени ЛРВ; чужие записи не трогаются,
        а ссылка «прежнее решение» на откаченную РВ у них снимается."""
        import rv_learning
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "learn.json")
            legacy = dict(code="6.2.3.1.1.1.2.1", role="С-В", kind="correction", count=1, section="ВК", system="К1",
                          name="Манжета HT 110", user="parfenov", updated="2026-11-01", source="ЛРВ проба.xlsx")
            other = dict(legacy, name="Кран", code="6.2.3.1.1.2.1.1", source="ЛРВ объект.xlsx", token="cccccccccccccccc",
                         prev=dict(legacy, name="Кран"))
            with open(path, "w", encoding="utf-8") as handle:
                json.dump(dict(version=1, entries={"ВК|к1|манжета ht 110": legacy, "ВК|к1|кран": other}), handle,
                          ensure_ascii=False)
            self.assertEqual(rv_learning.forget(path, token="dddddddddddddddd", source="ЛРВ проба.xlsx"), (1, 0))
            entries = rv_learning.load(path)
            self.assertEqual(list(entries), ["ВК|к1|кран"])
            self.assertNotIn("prev", entries["ВК|к1|кран"])
            self.assertEqual(rv_learning.forget(path), (0, 0))      # без token и source — ничего не трогаем

    def test_job_token_from_status_file(self):
        import web_rv_run
        args = mock.Mock(status_file="/x/rv/0123456789abcdef_status.json")
        self.assertEqual(web_rv_run.job_token(args), "0123456789abcdef")
        self.assertEqual(web_rv_run.job_token(mock.Mock(status_file="/x/status.json")), "")

    def test_apply_overrides_confirms_and_transfers(self):
        import rv_learning
        entries = {
            "ВК|к1|манжета ht 110": dict(code="6.2.3.1.1.1.2.1", role="С-В", kind="correction", count=2, user="ivanov", updated="2026-10-31", system="К1"),
            "ВК|к1|переход hl9": dict(code="6.2.3.1.1.1.1.1", role="С-В", kind="confirmed", count=1, user="ivanov", updated="2026-10-31", system="К1", coef=0.25),
            "ВК|к1|труба pp-h 110": dict(code="9.9.9.9.9.9", role="В", kind="correction", count=1, system="К1"),   # код ушёл из справочника
        }
        items = [{"id": 1, "name": "Манжета HT 110", "system": "К1"}, {"id": 2, "name": "Переход HL9", "system": "К1"},
                 {"id": 3, "name": "Труба PP-H 110", "system": "К1"}, {"id": 5, "name": "Манжета HT 110", "system": "К3"}]
        bindings = [
            {"id": 1, "name": "Манжета HT 110", "code": "6.2.3.1.1.1.1.1", "work": "x", "family": "x", "role": "С-В", "confidence": 0.5, "review": True,
             "flags": ["F-SYS: ветка не та", "F-UNIT: единица по типу"], "fcodes": ["F-SYS", "F-UNIT"], "source": "библиотека"},
            {"id": 2, "name": "Переход HL9", "code": "6.2.3.1.1.1.1.1", "role": "С-В", "confidence": 0.62, "review": True, "flags": [], "fcodes": [], "source": "библиотека"},
            {"id": 3, "name": "Труба PP-H 110", "code": "6.2.3.1.1.1.1.1", "role": "В", "confidence": 0.98, "review": False, "flags": [], "fcodes": [], "source": ""},
            {"id": 5, "name": "Манжета HT 110", "code": "6.2.3.1.3.1.1.1", "role": "С-В", "confidence": 0.5, "review": True, "flags": [], "fcodes": [], "source": ""},
        ]
        stats = rv_learning.apply(entries, "ВК", items, bindings, self.WORKS, self._fam, self._sys_code)
        self.assertEqual(stats, dict(corrected=2, confirmed=1, transferred=1))
        self.assertEqual((bindings[0]["code"], bindings[0]["confidence"], bindings[0]["review"], bindings[0]["learned"]),
                         ("6.2.3.1.1.1.2.1", 1.0, False, "correction"))
        self.assertEqual(bindings[0]["fcodes"], ["F-UNIT"])           # F-SYS снят, F-UNIT остался
        self.assertIn("×2", bindings[0]["source"])
        self.assertEqual((bindings[1]["confidence"], bindings[1]["review"], bindings[1]["learned"], bindings[1]["coef_user"]),
                         (0.95, False, "confirmed", 0.25))
        self.assertEqual(bindings[2]["code"], "6.2.3.1.1.1.1.1")     # неизвестный код памяти — без изменений
        self.assertNotIn("learned", bindings[2])
        self.assertEqual(bindings[3]["code"], "6.2.3.1.3.1.2.1")     # перенос решения К1 → ветка К3
        self.assertIn("перенесено", bindings[3]["source"])


@unittest.skipUnless(HAS_OPENPYXL, "нет openpyxl")
class FormTest(unittest.TestCase):
    """РВ в форме ТКП: иерархия ИСР над работами, материалы под работой, книга с формулами."""

    ISR = {"6": "Затраты на строительство", "6.2": "СМР корпуса без отделки", "6.2.3": "Инженерные системы",
           "6.2.3.1": "Водоснабжение и канализация", "6.2.3.1.1": "Система хозяйственно-бытовой канализации",
           "6.2.3.1.1.1": "Прокладка трубопроводов", "6.2.3.1.1.1.1": "Прокладка трубопроводов из ПП труб"}
    WORKS = {"6.2.3.1.1.1.1.1": "Прокладка трубопроводов из ПП труб / в строительном исполнении",
             "6.2.3.1.1.4.1.2": "Антикоррозийная окраска / в 2 слоя"}

    def _result(self):
        items = [{"id": 1, "name": "Труба PP-H 110", "unit": "м", "qty": 100.0, "system": "К1"},
                 {"id": 2, "name": "Хомут 110", "unit": "шт", "qty": 40, "system": "К1"},
                 {"id": 3, "name": "Загадка", "unit": "шт", "qty": 1, "system": "К1"}]
        bindings = [{"id": 1, "name": "Труба PP-H 110", "unit": "м", "qty": 100.0, "system": "К1", "code": "6.2.3.1.1.1.1.1", "role": "В",
                     "confidence": 0.9, "review": False, "flags": [], "fcodes": [], "source": "правило"},
                    {"id": 2, "name": "Хомут 110", "unit": "шт", "qty": 40, "system": "К1", "code": "6.2.3.1.1.1.1.1", "role": "Кр",
                     "confidence": 0.8, "review": False, "flags": [], "fcodes": [], "source": "конвенция"},
                    {"id": 3, "name": "Загадка", "unit": "шт", "qty": 1, "system": "К1", "code": None, "role": "?",
                     "confidence": 0.0, "review": True, "flags": ["F-CTX: нет"], "fcodes": ["F-CTX"], "source": ""}]
        rv = {"works": [{"code": "6.2.3.1.1.1.1.1", "work": "Прокладка…", "unit": "м", "volume": 100.0, "method": "Σ ведущих",
                         "materials": [{"id": 1, "name": "Труба PP-H 110", "unit": "м", "qty": 100.0, "role": "В"},
                                       {"id": 2, "name": "Хомут 110", "unit": "шт", "qty": 40, "role": "Кр"}]}],
              "unbound": [{"id": 3, "name": "Загадка"}]}
        return {"section": "ВК", "sections": ["ВК"], "source_name": "ЛРВ Тест.xlsx", "review": {"3": {"verdict": "вопрос", "question": "что это?"}},
                "elements": [{"section": "ВК", "element": "", "items": items, "bindings": bindings, "rv": rv, "distribution": []}],
                "summary": {}, "notes": []}

    def test_rows_follow_form(self):
        import rv_form
        result = self._result()
        result["elements"][0]["bindings"][0]["coef"] = 1
        result["elements"][0]["bindings"][1]["coef"] = 0
        result["elements"][0]["bindings"][1]["coef_user"] = 1.5
        rows = rv_form.build_rows(result, self.WORKS, isr=self.ISR)
        kinds = [r["t"] for r in rows]
        self.assertEqual(kinds, ["title"] + ["node"] * 7 + ["work", "mat", "mat", "title", "node", "mat", "total"])
        self.assertEqual(rows[0]["name"], "ЛРВ Тест / Система хозяйственно-бытовой канализации / Основные работы")
        self.assertEqual([r["code"] for r in rows[1:8]], ["6", "6.2", "6.2.3", "6.2.3.1", "6.2.3.1.1", "6.2.3.1.1.1", "6.2.3.1.1.1.1"])
        self.assertEqual(rows[7]["name"], "Прокладка трубопроводов из ПП труб")
        work = rows[8]
        self.assertEqual((work["code"], work["unit"], work["coef"], work["qty"], work["lvl"]), ("6.2.3.1.1.1.1.1", "м", 1, 100.0, 8))
        self.assertEqual((rows[9]["id"], rows[9]["coef"], rows[9]["conf"], rows[9]["role"]), (1, 1, 90, "В"))
        self.assertEqual((rows[10]["coef"], rows[10]["coef_user"], rows[10]["sysc"]), (1.5, True, ""))
        self.assertEqual(rows[8]["method"], "Σ ведущих")                     # незнакомый способ — как есть
        self.assertEqual(rv_form.explain_method("Σ количество / k ведущих групп [КЦ]"),
                         "объём = сумма количеств ведущих материалов по справочнику КЦ")
        self.assertEqual(rows[13]["why"], [rv_form.FLAG_TEXT["F-CTX"]])
        self.assertIn("часть строки ЛРВ", rv_form._note(dict(part=True, qty_total=634.0, code="x")))
        self.assertEqual(rows[12]["name"], rv_form.NO_WORK)
        self.assertEqual((rows[13]["id"], rows[13]["code"], rows[13]["rec"]["question"]), (3, "", "что это?"))

    def test_sheet_layout_and_formulas(self):
        import rv_form
        import rv_output
        from openpyxl import load_workbook
        result = self._result()
        rows = rv_form.build_rows(result, self.WORKS, isr=self.ISR)
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "rv.xlsx")
            result["summary"] = dict(rows=3, done=2, review=0, unbound=1, works=1, works_with_volume=1, kr=1, kr_distributed=0,
                                     elements=1, sections=["ВК"], skipped=0, review_note="")
            rv_output.build_workbook(path, result, rows)
            book = load_workbook(path)
            self.assertEqual(book.sheetnames[0], "РВ")
            sheet = book["РВ"]
            self.assertEqual([sheet.cell(4, c).value for c in (1, 2, 3, 5, 6, 7, 8, 14, 15, 16)],
                             ["Номер п/п", "Код узла ИСР/код материала", "Наименование затрат", "Ед. изм.", "Коэф. расхода", "Кол-во",
                              "Предельная стоимость производства работ (ПСПР)", "Уверенность, %", "Роль", "Примечание агента"])
            self.assertEqual((sheet["H5"].value, sheet["H6"].value, sheet["I6"].value, sheet["K5"].value, sheet["M5"].value),
                             ("Цена, руб. с НДС", "Материалы/\nоборудование", "СМР, ПНР", "Стоимость, руб с НДС", "Общая стоимость,\nруб. с НДС"))
            self.assertIn("H4:M4", {str(r) for r in sheet.merged_cells.ranges})
            self.assertEqual(sheet["B8"].value, "6")
            self.assertEqual(sheet.row_dimensions[8].outlineLevel, 1)
            work_row = 15
            self.assertEqual((sheet.cell(work_row, 2).value, sheet.cell(work_row, 6).value, sheet.cell(work_row, 7).value), ("6.2.3.1.1.1.1.1", 1, 100.0))
            self.assertEqual(sheet.cell(work_row, 11).value, "=SUM(K16:K17)")
            self.assertEqual(sheet.cell(work_row, 8).value, "=IF(G15>0,K15/G15,0)")
            self.assertEqual(sheet.cell(work_row, 13).value, "=K15+L15")
            self.assertEqual(sheet.cell(16, 11).value, "=G16*H16")
            self.assertEqual((sheet.cell(16, 1).value, sheet.cell(16, 14).value, sheet.cell(16, 15).value), (1, 90, "В"))
            self.assertEqual(sheet.cell(8, 11).value, "=SUM(K15)")      # узел «6» — сумма по работам под ним
            self.assertIn("Роль строки", sheet["O4"].comment.text)
            self.assertEqual(sheet.cell(7, 11).value, "=SUM(K15)")      # заголовок блока
            self.assertEqual(sheet.cell(sheet.max_row, 3).value, "Общая стоимость работ с НДС (руб.)")
            self.assertTrue(str(sheet.cell(sheet.max_row, 13).value).startswith("=SUM("))


@unittest.skipUnless(HAS_OPENPYXL, "нет openpyxl")
class ParseTest(unittest.TestCase):
    def test_xlsx_with_group_headers(self):
        import openpyxl
        book = openpyxl.Workbook()
        sheet = book.active
        sheet.append(["ЛРВ ЖК Пример"])
        sheet.append(["№", "Наименование", "Ед. изм.", "Кол-во"])
        sheet.append(["", "Корпус 1", "", None])
        sheet.append(["", "В2 Противопожарный водопровод", "", None])
        sheet.append([1, "Труба стальная 57х3,5", "м", 300])
        sheet.append([2, "Гайка М10", "шт", "1 200"])
        sheet.append(["", "Итого", "", 1500])
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "lrv.xlsx")
            book.save(path)
            parsed = rv_input.parse_lrv(path)
        self.assertEqual([h["text"] for h in parsed["headers"]], ["Корпус 1", "В2 Противопожарный водопровод"])
        self.assertEqual(len(parsed["items"]), 2)
        self.assertEqual(parsed["items"][1]["qty"], 1200.0)
        self.assertEqual(parsed["skipped"], 1)
        self.assertEqual(parsed["columns"]["name"], 1)

    def test_1c_report_with_outline_levels(self):
        """Отчёт 1С «Остатки по ЛРВ»: шапка, подписи уровней, группировка строк."""
        import openpyxl
        book = openpyxl.Workbook()
        sheet = book.active
        sheet.append(["Отбор:", "Проект В списке"])
        sheet.append([])
        sheet.append(["Проект", None, None, None, "Начальный остаток", "Количество план ЛРВ", "Операция добавления",
                      "Операция корректировки", "Заказано по предварительной заявке", "Заказано по заявке", "Остаток по спецификации"])
        for label in ("Аналитика 4", "Проект", "Система", "Номенклатура", "Регистратор"):
            sheet.append([label])
        rows = [
            (0, "ЖК Пример", 100), (1, "Основные работы", 100), (2, "ЖК Пример", 100), (3, "Отопление жилая часть", 100),
            (4, "Труба стальная 57х3,5", 60), (5, "Лимитно-разделительная ведомость № 1", 60),
            (4, "Кран шаровой Ду15", 40), (5, "Лимитно-разделительная ведомость № 1", 40),
            (4, "Снятая позиция", None),
            (1, "Вспомогательные работы", 3), (2, "ЖК Пример", 3), (3, "Накладные расходы", 3),
            (4, "Перчатки", 3), (5, "Заявка на МПЗ", None),
        ]
        for level, text, qty in rows:
            sheet.append([text, None, None, None, None, qty])
            sheet.row_dimensions[sheet.max_row].outline_level = level
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "report.xlsx")
            book.save(path)
            parsed = rv_input.parse_lrv(path)
        self.assertEqual(parsed["format"], "1c_report")
        self.assertEqual(parsed["levels"], ["Проект", "Аналитика 4", "Проект", "Система", "Номенклатура", "Регистратор"])
        self.assertEqual([it["name"] for it in parsed["items"]], ["Труба стальная 57х3,5", "Кран шаровой Ду15", "Перчатки"])
        self.assertEqual(parsed["items"][0]["qty"], 60.0)
        self.assertEqual(parsed["skipped_zero"], 1)
        self.assertEqual(parsed["docs"], 3)
        # Уровни «Проект» в заголовки не попадают; система и аналитика — да.
        self.assertEqual([(h["label"], h["text"]) for h in parsed["headers"]],
                         [("Аналитика 4", "Основные работы"), ("Система", "Отопление жилая часть"),
                          ("Аналитика 4", "Вспомогательные работы"), ("Система", "Накладные расходы")])
        self.assertEqual(parsed["items"][0]["headers"], [0, 1])
        self.assertEqual(parsed["items"][2]["headers"], [2, 3])
        self.assertFalse(parsed["has_unit"])

    def test_csv_semicolon_cp1251(self):
        text = "Наименование;Ед.;Количество\nК1;;\nТруба ПП 110;м;12,5\n"
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "lrv.csv")
            with open(path, "wb") as handle:
                handle.write(text.encode("cp1251"))
            parsed = rv_input.parse_lrv(path)
        self.assertEqual(parsed["items"][0]["qty"], 12.5)
        self.assertEqual(parsed["headers"][0]["text"], "К1")


class AgentParsingTest(unittest.TestCase):
    def test_mark_headers_filters_bad_indexes_and_systems(self):
        headers = [{"row": 1, "text": "Корпус 1"}, {"row": 2, "text": "Водопровод В1"}, {"row": 3, "text": "Трубы"}]
        client = FakeClient([{"headers": [
            {"i": 0, "kind": "element", "element": "Корпус 1"},
            {"i": 1, "kind": "system", "system": "В1"},
            {"i": 2, "kind": "system", "system": "нет такой"},
            {"i": 9, "kind": "system", "system": "К1"},
        ], "default_system": "В2", "notes": ["заметка"]}])
        marks, default, notes = rv_agent.mark_headers(client, "ВК", headers, [{"name": "Труба", "unit": "м", "qty": 1}])
        self.assertEqual(marks[0], {"kind": "element", "element": "Корпус 1"})
        self.assertEqual(marks[1], {"kind": "system", "system": "В1"})
        self.assertEqual(marks[2], {"kind": "other"})
        self.assertNotIn(9, marks)
        self.assertEqual(default, "В2")
        self.assertEqual(notes, ["заметка"])
        self.assertIn("output_schema", client.calls[0][1])

    def test_review_rejects_unknown_codes(self):
        items = [{"id": 1, "name": "Труба", "unit": "м", "qty": 1, "system": "К1"},
                 {"id": 2, "name": "Нечто", "unit": "шт", "qty": 1, "system": "К1"}]
        bindings = [{"id": 1, "code": "6.2.3.1.1.1.1.1", "work": "Трубы", "review": True, "flags": [], "confidence": 0.6},
                    {"id": 2, "code": None, "work": None, "review": False, "flags": ["F-NEW"], "confidence": 0}]
        client = FakeClient([{"rows": [
            {"id": 1, "verdict": "заменить", "code": "6.2.3.1.1.1.1.2", "role": "В", "reason": "п. 1.2"},
            {"id": 2, "verdict": "заменить", "code": "9.9.9", "reason": "выдумал"},
            {"id": 77, "verdict": "подтвердить", "reason": "чужая строка"},
        ], "questions": ["Как считать?"]}])
        works = {"6.2.3.1.1.1.1.2": "Работа 2"}
        review, questions = rv_agent.review_rows(client, "ВК", "жилой", items, bindings, works)
        self.assertEqual(review[1]["verdict"], "заменить")
        self.assertEqual(review[1]["work"], "Работа 2")
        self.assertEqual(review[2]["verdict"], "вопрос")
        self.assertIn("9.9.9", review[2]["question"])
        self.assertNotIn(77, review)
        self.assertEqual(questions, ["Как считать?"])

    def test_model_and_effort_default_and_override(self):
        bindings = [{"id": i, "code": None, "work": None, "review": True, "flags": [], "confidence": 0}
                    for i in range(1, rv_agent.REVIEW_BATCH + 3)]
        items = [{"id": b["id"], "name": "Строка %d" % b["id"], "unit": "шт", "qty": 1} for b in bindings]
        client = FakeClient([{"rows": [], "questions": []}, {"rows": [], "questions": []}])
        seen = []
        rv_agent.review_rows(client, "ВК", None, items, bindings, {}, progress=lambda done, total: seen.append((done, total)))
        kwargs = client.calls[0][1]
        self.assertEqual((kwargs["model"], kwargs["effort"]), ("claude-opus-5-5", "high"))
        self.assertTrue(callable(kwargs["on_event"]))          # поток: длинный ответ не упирается в таймаут чтения
        self.assertEqual(kwargs["max_tokens"], 64000)
        self.assertEqual(seen, [(0, len(bindings)), (rv_agent.REVIEW_BATCH, len(bindings))])
        client = FakeClient([{"headers": []}])
        rv_agent.mark_headers(client, "ВК", [{"row": 1, "text": "В1"}], [])
        self.assertEqual((client.calls[0][1]["model"], client.calls[0][1]["effort"]), ("claude-opus-5-5", "medium"))
        client = FakeClient([{"headers": []}])
        client.model_rv, client.effort_rv, client.effort_rv_mark = "claude-fable-5-1", "xhigh", "low"
        rv_agent.mark_headers(client, "ВК", [{"row": 1, "text": "В1"}], [])
        self.assertEqual((client.calls[0][1]["model"], client.calls[0][1]["effort"]), ("claude-fable-5-1", "low"))
        self.assertEqual(rv_agent.model_of(client), ("claude-fable-5-1", "xhigh"))

    def test_heartbeat_while_model_thinks(self):
        class StreamingClient(FakeClient):
            def messages(self, turns, **kwargs):
                for _ in range(3):
                    kwargs["on_event"]({"type": "ping"}, None)
                return FakeClient.messages(self, turns, **kwargs)
        beats = []
        client = StreamingClient([{"headers": []}])
        with mock.patch.object(rv_agent, "HEARTBEAT_SEC", 0):
            rv_agent.mark_headers(client, "ВК", [{"row": 1, "text": "В1"}], [], heartbeat=lambda: beats.append(1))
        self.assertEqual(len(beats), 3)
        beats = []
        client = StreamingClient([{"headers": []}])
        rv_agent.mark_headers(client, "ВК", [{"row": 1, "text": "В1"}], [], heartbeat=lambda: beats.append(1))
        self.assertEqual(beats, [])                             # чаще HEARTBEAT_SEC статус не пишется

    def test_status_touch_keeps_stage(self):
        import web_rv_run
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "s.json")
            status = web_rv_run.Status(path, 100)
            status.touch()                                      # до первого шага — ничего
            self.assertFalse(os.path.exists(path))
            status.update("running", "проверяю строки", rows=5)
            with open(path, "w", encoding="utf-8") as handle:
                json.dump({"state": "x"}, handle)
            status.touch()
            with open(path, encoding="utf-8") as handle:
                data = json.load(handle)
            self.assertEqual((data["state"], data["stage"], data["rows"]), ("running", "проверяю строки", 5))

    def test_master_parts_has_section_card(self):
        text = rv_agent.master_parts("ОВ2")
        self.assertIn("A11", text)
        self.assertIn("Раздел ОВ2", text)
        self.assertNotIn("Раздел ЭОМ", text)


class AutoConfirmTest(unittest.TestCase):
    """Подтверждение систем: система выбрана при загрузке — без вопроса и для всех строк;
    не выбрана — вопрос только если у строк нет системы в файле."""

    def _table(self, path):
        from openpyxl import Workbook
        wb = Workbook()
        ws = wb.active
        ws.append(["Наименование", "Ед. изм.", "Кол-во"])
        ws.append(["Воздуховод круглого сечения Ø200 L=400мм", None, None])
        ws.append(["Воздуховод круглого сечения из оцинкованной стали Ø200", "м2", 12.5])
        ws.append(["Хомут для воздуховода Ø200", "шт", 40])
        wb.save(path)

    def _run(self, tmp, extra):
        import subprocess
        src = os.path.join(tmp, "lrv.xlsx")
        self._table(src)
        st = os.path.join(tmp, "st.json")
        with open(st, "w", encoding="utf-8") as handle:
            json.dump({"state": "running", "launched": False}, handle)
        cmd = [sys.executable, os.path.join(PROGRAM_C, "web_rv_run.py"), "--phase", "mark", "--status-file", st,
               "--work-file", os.path.join(tmp, "work.json"), "--out-xlsx", os.path.join(tmp, "out.xlsx"),
               "--out-json", os.path.join(tmp, "out.json"), "--section", "ОВ2", "--keep-input"] + extra + ["--", src]
        out = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=300)
        self.assertEqual(out.returncode, 0, out.stderr.decode("utf-8")[-800:])
        return json.load(open(st, encoding="utf-8")), json.load(open(os.path.join(tmp, "work.json"), encoding="utf-8"))

    def test_no_system_in_file_asks(self):
        with tempfile.TemporaryDirectory() as tmp:
            status, work = self._run(tmp, [])
            self.assertEqual(status["state"], "awaiting_confirm")
            self.assertTrue(work["need_confirm"])
            self.assertFalse(os.path.exists(os.path.join(tmp, "out.xlsx")))

    def test_system_chosen_on_upload_builds_at_once(self):
        with tempfile.TemporaryDirectory() as tmp:
            status, work = self._run(tmp, ["--default-system", "ОВ2|ОВ"])
            self.assertEqual(status["state"], "done")
            self.assertEqual(work["confirmed"], "auto")
            result = json.load(open(os.path.join(tmp, "out.json"), encoding="utf-8"))
            systems = {b.get("system") for e in result["elements"] for b in e["bindings"]}
            self.assertEqual(systems, {"ОВ"})
            self.assertTrue(any("выбрана при загрузке" in n for n in result["notes"]))

    def test_local_rebuild(self):
        """Указания для одной РВ (<токен>_local.json, rv_local.php): замены модели по ТЗ (agent) строка берёт «на проверку»
        (F-LOCAL); при согласовании в общую память идут только ручные исправления сметчика."""
        import subprocess
        import rv_learning
        with tempfile.TemporaryDirectory() as tmp:
            self._run(tmp, ["--default-system", "ОВ2|ОВ"])
            token = "0123456789abcdef"
            st = os.path.join(tmp, token + "_status.json")
            os.rename(os.path.join(tmp, "st.json"), st)
            out_json = os.path.join(tmp, "out.json")
            learn = os.path.join(tmp, "learn.json")
            local_path = os.path.join(tmp, token + "_local.json")
            bindings = [b for e in json.load(open(out_json, encoding="utf-8"))["elements"] for b in e["bindings"]]
            bound = [b for b in bindings if b.get("code")]
            first, second = bound[0], bound[1]
            import bind
            bind.load(os.path.join(PROGRAM_C, "rv", "data"))
            branch = first["code"].rsplit(".", 1)[0]
            other = next(code for code in sorted(bind.KB["works"]) if code != first["code"] and code.startswith(branch))
            base = [sys.executable, os.path.join(PROGRAM_C, "web_rv_run.py"), "--phase", "bind", "--status-file", st,
                    "--work-file", os.path.join(tmp, "work.json"), "--out-xlsx", os.path.join(tmp, "out.xlsx"),
                    "--out-json", out_json, "--learning-file", learn, "--source-name", "lrv.xlsx"]

            def run(extra):
                out = subprocess.run(base + extra, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=300)
                self.assertEqual(out.returncode, 0, out.stderr.decode("utf-8")[-800:])
                with open(st, encoding="utf-8") as handle:
                    return json.load(handle)

            def rows():
                return {b["id"]: b for e in json.load(open(out_json, encoding="utf-8"))["elements"] for b in e["bindings"]}

            # Указания только что сохранены, а модели нет: РВ собирается как обычно, в сводке — почему не применены.
            with open(local_path, "w", encoding="utf-8") as handle:
                json.dump({"text": "решётки — к монтажу решёток", "files": [], "by": "kadrova", "at": 1}, handle)
            status = run(["--rebuild", "--user", "kadrova"])
            self.assertEqual(status["summary"]["local"]["error"], "модель недоступна")
            self.assertNotIn("agent", json.load(open(local_path, encoding="utf-8")))

            # Модель смотрит РВ по указаниям (в процессе, модель подменена): все строки, её замена — в указаниях (agent),
            # строка берёт работу «на проверку» с причиной; второй проверки моделью нет.
            import types
            import web_rv_run
            calls = []

            def review(client, section, object_type, items, todo, works, **kwargs):
                calls.append((sorted(b["id"] for b in todo), kwargs.get("all_rows"), kwargs.get("local")))
                return ({b["id"]: ({"verdict": "заменить", "code": other, "work": works[other], "role": "", "reason": "по ТЗ",
                                    "question": ""} if b["id"] == first["id"] else
                                   {"verdict": "подтвердить", "reason": "ок", "question": "", "role": ""}) for b in todo}, [])

            args = types.SimpleNamespace(phase="bind", status_file=st, work_file=os.path.join(tmp, "work.json"),
                                         out_xlsx=os.path.join(tmp, "out.xlsx"), out_json=out_json, credentials="x",
                                         learning_file=learn, feedback_file="", forget_learning=False, no_review=False,
                                         rebuild=True, user="kadrova", notes_file="", source_name="lrv.xlsx", lrv_id="",
                                         lrv_version="", object_name="", section="авто", object_type="жилой",
                                         default_system="", input=None, keep_input=False)
            with mock.patch.object(web_rv_run, "_client", return_value=FakeClient([])), \
                    mock.patch.object(rv_agent, "review_rows", side_effect=review):
                self.assertFalse(web_rv_run.run_bind(args))
            self.assertEqual(len(calls), 1)
            self.assertEqual((calls[0][0], calls[0][1]), (sorted(b["id"] for b in bindings), True))
            self.assertIn("решётки — к монтажу решёток", calls[0][2])
            stored = json.load(open(local_path, encoding="utf-8"))
            self.assertEqual(stored["agent"]["rows"], {str(first["id"]): {"code": other, "role": "", "reason": "по ТЗ"}})
            self.assertEqual(stored["agent"]["stats"]["changed"], 1)
            status = json.load(open(st, encoding="utf-8"))
            self.assertEqual(status["state"], "done")
            self.assertTrue(status["summary"]["local"]["fresh"])
            self.assertTrue(status["summary"]["review_note"].startswith("по указаниям для этой РВ: проверено %d строк — изменено 1" % len(bindings)))
            result = json.load(open(out_json, encoding="utf-8"))
            self.assertNotIn(str(first["id"]), {str(k) for k in result["review"]})
            self.assertEqual(result["review"][str(second["id"])]["verdict"], "подтвердить")
            form = web_rv_run._read(web_rv_run.form_path(args))
            recs = {r["id"]: r.get("rec") for r in form["rows"] if r.get("t") == "mat"}
            self.assertEqual(recs[second["id"]]["verdict"], "подтвердить")      # свежая проверка видна на странице
            b = rows()[first["id"]]
            self.assertEqual((b["code"], b["learned"], b["review"], b["fcodes"]), (other, "local", True, ["F-LOCAL"]))

            # Пересборка без модели: замены берутся из указаний.
            status = run(["--rebuild", "--no-review", "--user", "kadrova"])
            self.assertEqual(status["state"], "done")
            self.assertEqual((status["summary"]["local"]["changed"], status["summary"]["local"]["fresh"]), (1, False))
            self.assertTrue(any(n.startswith("Указания для этой РВ: по ним изменено строк — 1") for n in status["notes"]))
            self.assertTrue(json.load(open(out_json, encoding="utf-8"))["local"])
            b = rows()[first["id"]]
            self.assertEqual((b["code"], b["learned"], b["review"], b["fcodes"]), (other, "local", True, ["F-LOCAL"]))

            # Согласование целиком: подтверждения «остального» (в том числе строки по указаниям) в общую память не идут.
            feedback = os.path.join(tmp, "feedback.json")
            with open(feedback, "w", encoding="utf-8") as handle:
                json.dump({"token": token, "user": "kadrova", "confirm_rest": True, "corrections": []}, handle)
            status = run(["--feedback-file", feedback, "--no-review", "--user", "kadrova"])
            self.assertEqual((status["feedback"]["corrected"], status["feedback"]["confirmed"]), (0, 0))
            self.assertEqual(rv_learning.load(learn), {})
            self.assertEqual(rows()[first["id"]]["code"], other)                 # по указаниям — и после согласования

            # Принятое пачкой из предложений модели (via=model) — только в этой РВ: в её файле указаний, не в общей памяти.
            target = next(code for code in sorted(bind.KB["works"]) if code != second["code"] and code.startswith(second["code"].rsplit(".", 1)[0]))
            with open(feedback, "w", encoding="utf-8") as handle:
                json.dump({"token": token, "user": "kadrova", "confirm_rest": True,
                           "corrections": [{"id": second["id"], "code": target, "role": "", "coef": None, "via": "model"}]}, handle)
            status = run(["--feedback-file", feedback, "--no-review", "--user", "kadrova"])
            self.assertEqual((status["feedback"]["corrected"], status["feedback"]["confirmed"]), (0, 0))
            self.assertEqual(rv_learning.load(learn), {})
            self.assertEqual((rows()[second["id"]]["code"], rows()[second["id"]]["learned"]), (target, "correction"))
            stored = json.load(open(local_path, encoding="utf-8"))
            self.assertEqual(stored["fixes"][str(second["id"])]["code"], target)
            self.assertIn("agent", stored)                                       # замены модели остаются в указаниях
            run(["--rebuild", "--no-review", "--user", "kadrova"])               # и всё переживает пересборку
            self.assertEqual((rows()[second["id"]]["code"], rows()[first["id"]]["code"]), (target, other))

            # Ручное исправление сметчика в такой РВ в память идёт; и оно сильнее указаний в этой РВ.
            mine = next(code for code in sorted(bind.KB["works"]) if code not in (other, first["code"]) and code.startswith(branch))
            with open(feedback, "w", encoding="utf-8") as handle:
                json.dump({"token": token, "user": "kadrova", "confirm_rest": True,
                           "corrections": [{"id": first["id"], "code": mine, "role": "", "coef": None}]}, handle)
            status = run(["--feedback-file", feedback, "--no-review", "--user", "kadrova"])
            self.assertEqual(status["feedback"]["corrected"], 1)
            self.assertEqual([e["code"] for e in rv_learning.load(learn).values()], [mine])
            self.assertEqual((rows()[first["id"]]["code"], rows()[first["id"]]["learned"]), (mine, "correction"))
            self.assertNotEqual(second["id"], first["id"])

    def test_order_asks_dr_or_rvr(self):
        """Заказ-наряд (meta.kind = НЗ) без известного вида: перед сборкой — вопрос «ДР или РВР»; вид известен — без вопроса."""
        import subprocess
        with tempfile.TemporaryDirectory() as tmp:
            src = os.path.join(tmp, "lrv.xlsx")
            self._table(src)
            token = "0123456789abcdef"
            st = os.path.join(tmp, token + "_status.json")
            job_path = os.path.join(tmp, token + "_job.json")
            cmd = [sys.executable, os.path.join(PROGRAM_C, "web_rv_run.py"), "--phase", "mark", "--status-file", st,
                   "--work-file", os.path.join(tmp, "work.json"), "--out-xlsx", os.path.join(tmp, "out.xlsx"),
                   "--out-json", os.path.join(tmp, "out.json"), "--section", "ОВ2", "--keep-input",
                   "--default-system", "ОВ2|ОВ", "--", src]

            def run(job):
                with open(job_path, "w", encoding="utf-8") as handle:
                    json.dump(job, handle)
                with open(st, "w", encoding="utf-8") as handle:
                    json.dump({"state": "running", "launched": False}, handle)
                out = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=300)
                self.assertEqual(out.returncode, 0, out.stderr.decode("utf-8")[-800:])
                return json.load(open(st, encoding="utf-8")), json.load(open(os.path.join(tmp, "work.json"), encoding="utf-8"))

            status, work = run({"token": token, "meta": {"kind": "НЗ", "zn": "7"}})
            self.assertEqual((status["state"], work["ask_code_root"]), ("awaiting_confirm", True))
            self.assertTrue(work["confirm_reason"].startswith("Заказ-наряд: выберите"))
            status, work = run({"token": token, "meta": {"kind": "НЗ", "zn": "7"}, "code_root": "12"})
            self.assertEqual((status["state"], work["ask_code_root"], status["summary"]["code_root"]), ("done", False, "12"))
            status, work = run({"token": token, "meta": {"kind": "осн"}})
            self.assertEqual((status["state"], work["ask_code_root"], status["summary"]["code_root"]), ("done", False, "6"))

    def test_rvr_order_builds_in_code_12(self):
        """Заказ-наряд РВР (job['code_root'] = '12', выбор на сайте): РВ собирается из работ кода 12 — пар работ 6.2.3 с тем
        же названием; память решений у кода 12 своя; в выгрузке для 1С — «КодРабот»: «12»."""
        import subprocess
        import rv_learning
        with tempfile.TemporaryDirectory() as tmp:
            self._run(tmp, ["--default-system", "ОВ2|ОВ"])
            token = "0123456789abcdef"
            st = os.path.join(tmp, token + "_status.json")
            os.rename(os.path.join(tmp, "st.json"), st)
            out_json = os.path.join(tmp, "out.json")
            learn = os.path.join(tmp, "learn.json")
            before = {b["id"]: b for e in json.load(open(out_json, encoding="utf-8"))["elements"] for b in e["bindings"]}
            self.assertTrue(all(b["code"].startswith("6.2.3.3.") for b in before.values() if b.get("code")))
            with open(os.path.join(tmp, token + "_job.json"), "w", encoding="utf-8") as handle:
                json.dump({"token": token, "code_root": "12"}, handle)
            base = [sys.executable, os.path.join(PROGRAM_C, "web_rv_run.py"), "--phase", "bind", "--status-file", st,
                    "--work-file", os.path.join(tmp, "work.json"), "--out-xlsx", os.path.join(tmp, "out.xlsx"),
                    "--out-json", out_json, "--learning-file", learn, "--source-name", "lrv.xlsx"]

            def run(extra):
                out = subprocess.run(base + extra, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=300)
                self.assertEqual(out.returncode, 0, out.stderr.decode("utf-8")[-800:])
                with open(st, encoding="utf-8") as handle:
                    return json.load(handle)

            status = run(["--rebuild", "--no-review", "--user", "kadrova"])
            self.assertEqual((status["state"], status["summary"]["code_root"]), ("done", "12"))
            result = json.load(open(out_json, encoding="utf-8"))
            after = {b["id"]: b for e in result["elements"] for b in e["bindings"]}
            import bind
            bind.load(os.path.join(PROGRAM_C, "rv", "data"))
            bind.KB.pop("rvr", None)
            pairs = bind.load_rvr(os.path.join(PROGRAM_C, "rv", "data"))
            moved = 0
            for row_id, was in before.items():
                now = after[row_id]
                if was.get("code") and was["code"] in pairs:
                    self.assertEqual(now["code"], pairs[was["code"]][0], was["name"])           # та же работа, код 12
                    self.assertEqual(bind.KB["works"][now["code"]], bind.KB["works"][was["code"]])
                    moved += 1
                elif was.get("code") and was.get("role") != "Кр":
                    self.assertEqual((now.get("code"), now["fcodes"]), (None, ["F-RVR"]), was["name"])   # пары нет — выбрать
            self.assertGreater(moved, 0)
            works = [w for e in result["elements"] for w in e["works"]]
            self.assertTrue(works and all(w["code"].startswith("12.1.13.") for w in works), [w["code"] for w in works])
            self.assertTrue(any(n.startswith("Заказ-наряд РВР: РВ собрана из работ кода 12") for n in status["notes"]))
            export = json.load(open(os.path.join(tmp, "out_1c.json"), encoding="utf-8"))
            self.assertEqual(export["КодРабот"], "12")
            self.assertTrue(all(w["КодИСР"].startswith("12.1.13.") for w in export["Работы"]))
            form = json.load(open(os.path.join(tmp, "out_form.json"), encoding="utf-8"))
            self.assertTrue(all(row[0].startswith("12.1.13.") for row in form["catalog"]["ОВ2"]))   # выбор работы — из кода 12

            # Исправление сметчика в РВР — в память кода 12 (learn_rvr.json), общая память кода 6 не тронута.
            first = next(b for b in after.values() if b.get("code"))
            other = next(code for code in sorted(pairs.values()) if code[0].startswith("12.1.13.") and code[0] != first["code"])[0]
            feedback = os.path.join(tmp, "feedback.json")
            with open(feedback, "w", encoding="utf-8") as handle:
                json.dump({"token": token, "user": "kadrova", "confirm_rest": False,
                           "corrections": [{"id": first["id"], "code": other, "role": "", "coef": None}]}, handle)
            status = run(["--feedback-file", feedback, "--no-review", "--user", "kadrova"])
            self.assertEqual(status["feedback"]["corrected"], 1)
            self.assertEqual(rv_learning.load(learn), {})
            self.assertEqual([e["code"] for e in rv_learning.load(os.path.join(tmp, "learn_rvr.json")).values()], [other])
            now = {b["id"]: b for e in json.load(open(out_json, encoding="utf-8"))["elements"] for b in e["bindings"]}
            self.assertEqual(now[first["id"]]["code"], other)

    def test_approval_then_rollback(self):
        """Согласование пишет решения в память с номером задачи; откат (--forget-learning) их убирает,
        РВ пересобирается без них и без отметки проверки."""
        import subprocess
        import rv_learning
        with tempfile.TemporaryDirectory() as tmp:
            self._run(tmp, ["--default-system", "ОВ2|ОВ"])
            token = "abcdef0123456789"
            st = os.path.join(tmp, token + "_status.json")
            os.rename(os.path.join(tmp, "st.json"), st)
            out_json = os.path.join(tmp, "out.json")
            learn = os.path.join(tmp, "learn.json")
            bindings = [b for e in json.load(open(out_json, encoding="utf-8"))["elements"] for b in e["bindings"]]
            first = [b for b in bindings if b.get("code")][0]
            import bind
            bind.load(os.path.join(PROGRAM_C, "rv", "data"))
            branch = first["code"].rsplit(".", 1)[0]
            other = next(code for code in sorted(bind.KB["works"]) if code != first["code"] and code.startswith(branch))
            feedback = os.path.join(tmp, "feedback.json")
            with open(feedback, "w", encoding="utf-8") as handle:
                json.dump({"token": token, "user": "parfenov", "confirm_rest": True,
                           "corrections": [{"id": first["id"], "code": other, "role": "", "coef": None}]}, handle)
            base = [sys.executable, os.path.join(PROGRAM_C, "web_rv_run.py"), "--phase", "bind", "--status-file", st,
                    "--work-file", os.path.join(tmp, "work.json"), "--out-xlsx", os.path.join(tmp, "out.xlsx"),
                    "--out-json", out_json, "--learning-file", learn, "--no-review", "--source-name", "lrv.xlsx"]

            def run(extra):
                out = subprocess.run(base + extra, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=300)
                self.assertEqual(out.returncode, 0, out.stderr.decode("utf-8")[-800:])
                with open(st, encoding="utf-8") as handle:
                    return json.load(handle)

            status = run(["--feedback-file", feedback, "--user", "parfenov"])
            self.assertEqual(status["state"], "done")
            self.assertEqual(status["feedback"]["corrected"], 1)
            entries = rv_learning.load(learn)
            self.assertTrue(entries)
            self.assertEqual({e["token"] for e in entries.values()}, {token})
            rebound = {b["id"]: b for e in json.load(open(out_json, encoding="utf-8"))["elements"] for b in e["bindings"]}
            self.assertEqual(rebound[first["id"]]["code"], other)

            # Пересборка по кнопке (rv_rebuild.php → --rebuild): память не трогается, исправление инженера применяется
            # из памяти, согласование (feedback в статусе) сохраняется — как и в статусе «running», который пишет PHP.
            with open(st, "w", encoding="utf-8") as handle:
                json.dump({"state": "running", "stage": "пересобираю РВ…", "started": 1, "updated": 1,
                           "feedback": status["feedback"]}, handle)
            status = run(["--rebuild", "--user", "kadrova"])
            self.assertEqual(status["state"], "done")
            self.assertEqual(status["feedback"]["corrected"], 1)                 # для 1С ничего не изменилось — согласование остаётся
            self.assertEqual(status["feedback"]["user"], "parfenov")
            self.assertEqual(status["rebuilt"]["changes"], {"works": 0, "rows": 0})
            self.assertFalse(status["rebuilt"]["approval_reset"])
            self.assertEqual(rv_learning.load(learn), entries)
            rebound = {b["id"]: b for e in json.load(open(out_json, encoding="utf-8"))["elements"] for b in e["bindings"]}
            self.assertEqual(rebound[first["id"]]["code"], other)
            self.assertTrue(any("пересборка по запросу (kadrova)" in line for line in status["log"]))

            # Пересборка, после которой РВ для 1С другая (здесь — работа сметчика в прежнем результате): согласование снимается.
            slim = json.load(open(out_json, encoding="utf-8"))
            have = {w["code"] for e in slim["elements"] for w in e["works"]}
            extra = next(code for code in sorted(bind.KB["works"]) if code.startswith(branch.rsplit(".", 1)[0]) and code not in have
                         and bind.KB["works"][code] and "НЕ ИСПОЛЬЗОВАТЬ" not in bind.KB["works"][code].upper())
            slim["added_works"] = {extra: {"qty": 4, "by": "kadrova"}}
            with open(out_json, "w", encoding="utf-8") as handle:
                json.dump(slim, handle, ensure_ascii=False)
            with open(st, "w", encoding="utf-8") as handle:
                json.dump({"state": "running", "stage": "пересобираю РВ…", "started": 1, "updated": 1,
                           "feedback": status["feedback"]}, handle)
            status = run(["--rebuild", "--user", "kadrova"])
            self.assertIsNone(status.get("feedback"))
            self.assertTrue(status["rebuilt"]["approval_reset"])
            self.assertEqual(status["rebuilt"]["changes"]["works"], 1)
            self.assertEqual(status["summary"]["manual_works"], 1)
            onec = json.load(open(out_json[:-len(".json")] + "_1c.json", encoding="utf-8"))
            added = [w for w in onec["Работы"] if w["КодИСР"] == extra]
            self.assertEqual((len(added), added[0]["Объем"], added[0]["ДобавленоСметчиком"]), (1, 4, True))
            self.assertIsNone(onec["Итого"]["ПроверкаИнженером"])
            self.assertEqual(onec["СопоставлениеРВиЛРВ"]["Документ"]["Пользователь"], "")
            self.assertTrue(any("согласование снято" in line for line in status["log"]))

            status = run(["--forget-learning", "--user", "parfenov"])
            self.assertEqual(status["state"], "done")
            self.assertIsNone(status.get("feedback"))
            self.assertEqual(status["rollback"], {"removed": len(entries), "restored": 0, "user": "parfenov"})
            self.assertEqual(rv_learning.load(learn), {})
            rebound = {b["id"]: b for e in json.load(open(out_json, encoding="utf-8"))["elements"] for b in e["bindings"]}
            self.assertEqual(rebound[first["id"]]["code"], first["code"])   # снова как подобрал агент

    def test_force_system_overrides_headers(self):
        parsed = {"headers": [{"text": "Система К1", "row": 1}], "columns": {},
                  "items": [{"name": "Труба", "headers": [0]}, {"name": "Отвод", "headers": []}]}
        marks = {0: {"kind": "system", "section": "ВК", "system": "К1"}}
        rv_input.apply_marks("ВК", parsed, marks, None, "ВК|В1")
        self.assertEqual([it["system"] for it in parsed["items"]], ["В1", "В1"])


class AuditTest(unittest.TestCase):
    """Сверка РВ из 1С с агентом: статусы строк и работ, вердикт модели, прогон без вопросов, очередь."""

    def test_compare_rows_works_and_model(self):
        import rv_audit
        works_1c = lambda *codes: {"РаботыВ1С": [{"Код": c, "Наименование": "работа " + c, "Количество": 5} for c in codes]}  # noqa: E731
        elements = [{"element": "", "items": [
            {"id": 1, "name": "Труба", "unit": "м", "qty": 10, "ext": works_1c("1.1")},
            {"id": 2, "name": "Отвод", "unit": "шт", "qty": 4, "ext": works_1c("1.2")},
            {"id": 3, "name": "Хомут", "unit": "шт", "qty": 40, "ext": works_1c("1.3", "1.1")},
            {"id": 4, "name": "Кран", "unit": "шт", "qty": 2},
            {"id": 5, "name": "Анкер", "unit": "шт", "qty": 9, "ext": {"РаботыВ1С": [{"Код": "", "Наименование": "Прочее"}]}},
            {"id": 6, "name": "Нечто", "unit": "шт", "qty": 1, "ext": works_1c("1.4")},
        ], "bindings": [
            {"id": 1, "code": "1.1", "role": "В"}, {"id": 2, "code": "1.1", "role": "С-В"},
            {"id": 3, "code": "1.9", "role": "Кр"}, {"id": 4, "code": "1.1"}, {"id": 5, "code": "1.1"}, {"id": 6, "code": None},
        ], "distribution": [{"id": 3, "split": [{"code": "1.1", "qty": 30}, {"code": "1.9", "qty": 10}]}],
            "rv": {"works": [{"code": "1.1", "work": "Прокладка", "unit": "м", "volume": 10.5},
                             {"code": "1.9", "work": "Крепление", "unit": "шт", "volume": 3}]}}]
        works_rv = [{"Код": "1.1", "Количество": 10}, {"Код": "1.2", "Количество": 4}, {"Код": "", "Наименование": "Своя работа", "Количество": 1}]
        review = {"2": {"verdict": "заменить", "code": "1.2", "reason": "отвод — фасонная часть"},
                  6: {"verdict": "вопрос", "question": "что это?"}}
        result = rv_audit.compare(elements, works_rv, review=review)
        status = {row["id"]: row["status"] for row in result["rows"]}
        self.assertEqual(status, {1: "match", 2: "differ", 3: "match", 4: "no_1c", 5: "not_isr", 6: "agent_none"})
        model = {row["id"]: row["model"]["side"] for row in result["rows"] if row["model"]}
        self.assertEqual(model, {2: "1c", 6: "question"})
        self.assertEqual(result["rows"][2]["c1_main"], "1.3")
        works = {w["code"]: w["status"] for w in result["works"]}
        self.assertEqual(works, {"1.1": "match", "1.2": "only_1c", "1.9": "only_agent", "": "not_isr"})
        summary = result["summary"]
        self.assertEqual((summary["match"], summary["disputed"], summary["match_pct"]), (2, 2, 50.0))
        self.assertEqual(summary["model"]["1c"], 1)

    def test_audit_run_without_questions(self):
        """Сверка из 1С: нераспознанная система не останавливает задачу; в итоге — сверка строк и объёмов."""
        import subprocess
        import bind
        bind.load(os.path.join(PROGRAM_C, "rv", "data"))
        probe = [{"id": 1, "name": "Труба PP-H 110", "unit": "м", "qty": 50, "system": "К1"}]
        code = bind.bind("ВК", probe, "жилой")[0]["code"]
        other = next(c for c in sorted(bind.KB["works"]) if c != code and c.startswith(code.rsplit(".", 2)[0]))
        rows = [
            {"Номенклатура": "Труба PP-H 110", "ЕдиницаИзмерения": "м", "Количество": 50, "ИдентификаторСтроки": "r1",
             "Система": "Система хозяйственно-бытовой канализации", "РаботыВ1С": [{"Код": code, "Количество": 50}]},
            {"Номенклатура": "Труба PP-H 50", "ЕдиницаИзмерения": "м", "Количество": 20, "ИдентификаторСтроки": "r2",
             "Система": "Система хозяйственно-бытовой канализации", "РаботыВ1С": [{"Код": other, "Количество": 20}]},
            {"Номенклатура": "Ревизия 110", "ЕдиницаИзмерения": "шт", "Количество": 3, "ИдентификаторСтроки": "r3",
             "Система": "Система хозяйственно-бытовой канализации"},
            {"Номенклатура": "Нечто особое", "ЕдиницаИзмерения": "шт", "Количество": 1, "ИдентификаторСтроки": "r4",
             "Система": "Непонятная система"},
        ]
        with tempfile.TemporaryDirectory() as tmp:
            token = "0123456789abcdef"
            src = os.path.join(tmp, "lrv.json")
            with open(src, "w", encoding="utf-8") as handle:
                json.dump({"ИдентификаторЛРВ": "Сверка-1", "Строки": rows}, handle, ensure_ascii=False)
            st = os.path.join(tmp, token + "_status.json")
            with open(st, "w", encoding="utf-8") as handle:
                json.dump({"state": "running", "launched": False}, handle)
            with open(os.path.join(tmp, token + "_audit.json"), "w", encoding="utf-8") as handle:
                json.dump({"doc": "РВ 000123", "works": [{"Код": code, "Количество": 70}, {"Код": "", "Наименование": "Своя"}]},
                          handle, ensure_ascii=False)
            out_json = os.path.join(tmp, token + "_rv.json")
            cmd = [sys.executable, os.path.join(PROGRAM_C, "web_rv_run.py"), "--phase", "mark", "--status-file", st,
                   "--work-file", os.path.join(tmp, token + "_work.json"), "--out-xlsx", os.path.join(tmp, token + "_rv.xlsx"),
                   "--out-json", out_json, "--keep-input", "--", src]
            out = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=300)
            self.assertEqual(out.returncode, 0, out.stderr.decode("utf-8")[-800:])
            with open(st, encoding="utf-8") as handle:
                status = json.load(handle)
            self.assertEqual(status["state"], "done")
            with open(out_json, encoding="utf-8") as handle:
                result = json.load(handle)
        audit = result["audit"]
        by_name = {row["name"]: row["status"] for row in audit["rows"]}
        self.assertEqual(by_name["Труба PP-H 110"], "match")
        self.assertEqual(by_name["Ревизия 110"], "no_1c")
        self.assertEqual(by_name["Нечто особое"], "no_1c")
        self.assertIn(by_name["Труба PP-H 50"], ("differ", "match"))
        self.assertEqual(status["summary"]["audit"]["rows"], 4)
        self.assertEqual(audit["doc"], "РВ 000123")
        self.assertIn("not_isr", {w["status"] for w in audit["works"]})

    def test_onec_bound_rows_and_smeta_works(self):
        """Обычная ЛРВ из 1С с разнесённым и работами сметы: разнесённые строки берут работу 1С, несогласие агента —
        на проверку (F-1C), решение инженера в этой задаче — «перепривязать»; работа не из сметы — F-SMETA;
        в РВ для 1С — «Действие» у строк и «ЕстьВСмете» у работ."""
        import subprocess
        import bind
        bind.load(os.path.join(PROGRAM_C, "rv", "data"))
        probe = [{"id": 1, "name": "Труба PP-H 110", "unit": "м", "qty": 50, "system": "К1"}]
        agent_code = bind.bind("ВК", probe, "жилой")[0]["code"]
        other = next(c for c in sorted(bind.KB["works"]) if c != agent_code and c.startswith(agent_code.rsplit(".", 2)[0]))
        rows = [
            {"Номенклатура": "Труба PP-H 110", "ЕдиницаИзмерения": "м", "Количество": 50, "ИдентификаторСтроки": "r1",
             "Система": "Система хозяйственно-бытовой канализации", "РаботыВ1С": [{"Код": agent_code, "Количество": 50}]},
            {"Номенклатура": "Труба PP-H 50", "ЕдиницаИзмерения": "м", "Количество": 20, "ИдентификаторСтроки": "r2",
             "Система": "Система хозяйственно-бытовой канализации", "РаботыВ1С": [{"Код": other, "Количество": 20}]},
            {"Номенклатура": "Ревизия 110", "ЕдиницаИзмерения": "шт", "Количество": 3, "ИдентификаторСтроки": "r3",
             "Система": "Система хозяйственно-бытовой канализации"},
        ]
        with tempfile.TemporaryDirectory() as tmp:
            token = "fedcba9876543210"
            src = os.path.join(tmp, "lrv.json")
            with open(src, "w", encoding="utf-8") as handle:
                json.dump({"ИдентификаторЛРВ": "Смета-1", "Строки": rows}, handle, ensure_ascii=False)
            st = os.path.join(tmp, token + "_status.json")
            with open(st, "w", encoding="utf-8") as handle:
                json.dump({"state": "running", "launched": False}, handle)
            with open(os.path.join(tmp, token + "_smeta.json"), "w", encoding="utf-8") as handle:
                json.dump({"works": [{"Код": agent_code, "Наименование": "Прокладка", "Количество": 70, "СметнаяПозицияGUID": "sp-1",
                                      "Примечание": "по стене паркинга"}]},
                          handle, ensure_ascii=False)
            out_json = os.path.join(tmp, token + "_rv.json")
            learn = os.path.join(tmp, "learn.json")
            base = [sys.executable, os.path.join(PROGRAM_C, "web_rv_run.py"), "--status-file", st,
                    "--work-file", os.path.join(tmp, token + "_work.json"), "--out-xlsx", os.path.join(tmp, token + "_rv.xlsx"),
                    "--out-json", out_json, "--learning-file", learn, "--source-name", "lrv.json"]

            def run(extra):
                out = subprocess.run(base + extra, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=300)
                self.assertEqual(out.returncode, 0, out.stderr.decode("utf-8")[-800:])
                with open(st, encoding="utf-8") as handle:
                    status = json.load(handle)
                self.assertEqual(status["state"], "done", status.get("error"))
                with open(out_json, encoding="utf-8") as handle:
                    result = json.load(handle)
                with open(os.path.join(tmp, token + "_rv_1c.json"), encoding="utf-8") as handle:
                    onec = json.load(handle)
                return status, result, onec

            status, result, onec = run(["--phase", "mark", "--keep-input", "--", src])
            bindings = {b["id"]: b for e in result["elements"] for b in e["bindings"]}
            by_name = {}
            for e in result["elements"]:
                for b in e["bindings"]:
                    by_name[b["name"]] = b
            pipe50 = by_name["Труба PP-H 50"]
            self.assertEqual((pipe50["code"], pipe50["learned"], pipe50["onec_code"]), (other, "onec", other))
            self.assertEqual(status["summary"]["onec"]["bound"], 2)
            actions = {m["Номенклатура"]: m["Действие"] for w in onec["Работы"] for m in w["Материалы"]}
            self.assertEqual(actions["Труба PP-H 110"], "как в 1С")
            self.assertEqual(actions["Ревизия 110"], "привязать")
            self.assertIn(actions["Труба PP-H 50"], ("как в 1С",))
            works = {w["КодИСР"]: w for w in onec["Работы"]}
            self.assertTrue(works[agent_code]["ЕстьВСмете"])
            self.assertEqual(works[agent_code]["СметнаяПозицияGUID"], "sp-1")
            # Блок для документов 1С: позиции (из сметы — с GUID, новые — с УИД узла) и только разница с 1С
            sopost = onec["СопоставлениеРВиЛРВ"]
            positions = {p["КодИерархии"]: p for p in sopost["СметныеПозиции"]}
            self.assertEqual((positions[agent_code]["СметнаяПозицияGUID"], positions[agent_code]["ЕстьВСмете"], positions[agent_code]["УИДУзлаДерева"]),
                             ("sp-1", True, ""))
            self.assertFalse(positions[other]["ЕстьВСмете"])
            self.assertEqual(len(positions[other]["УИДУзлаДерева"]), 36)
            # примечание к работе: из сметы 1С возвращается как есть; у работы не из сметы - пусто
            self.assertEqual((positions[agent_code]["Примечание"], positions[other]["Примечание"]), ("по стене паркинга", ""))
            self.assertEqual(result["work_notes"], {agent_code: {"text": "по стене паркинга", "by": "1С"}})
            with open(os.path.join(tmp, token + "_rv_form.json"), encoding="utf-8") as handle:
                form_works = {r["code"]: r for r in json.load(handle)["rows"] if r.get("t") == "work"}
            self.assertEqual((form_works[agent_code]["remark"], form_works[agent_code]["remark_by"]), ("по стене паркинга", "1С"))
            self.assertEqual([(c["Номенклатура"], c["Действие"], c["Количество"], c["КодИерархии"]) for c in sopost["ТЧИзменений"]],
                             [("Ревизия 110", "привязать", 3, agent_code)])
            self.assertEqual(sopost["Итого"]["Привязать"], 1)
            self.assertEqual(sopost["Документ"]["ВидОперацииРВ"], "Добавление")
            self.assertEqual({g["Источник"] for g in sopost["Товары"] if g["Номенклатура"] == "Труба PP-H 110"}, {"1С"})
            if pipe50.get("agent_code") and pipe50["agent_code"] != other:
                self.assertIn("F-1C", pipe50["fcodes"])
                self.assertTrue(pipe50["review"])
                # инженер принял агента: исправление с кодом агента → «перепривязать»
                feedback = os.path.join(tmp, "feedback.json")
                with open(feedback, "w", encoding="utf-8") as handle:
                    json.dump({"token": token, "user": "parfenov", "when": 1794000000, "confirm_rest": False,
                               "corrections": [{"id": pipe50["id"], "code": pipe50["agent_code"], "role": "", "coef": None}],
                               "work_notes": {agent_code: "по стене паркинга, высота 3 м", other: "новая работа"}}, handle)
                status, result, onec = run(["--phase", "bind", "--feedback-file", feedback, "--no-review", "--user", "parfenov"])
                # примечания сметчика поверх 1С уходят в 1С и помнятся в результате
                notes = {p["КодИерархии"]: p["Примечание"] for p in onec["СопоставлениеРВиЛРВ"]["СметныеПозиции"]}
                self.assertEqual(notes[agent_code], "по стене паркинга, высота 3 м")
                self.assertNotIn(other, notes)      # работы больше нет в РВ - позиции нет, примечание ждёт в результате
                self.assertEqual(result["work_notes"][other], {"text": "новая работа", "by": "parfenov"})
                actions = {m["Номенклатура"]: (m["Действие"], m["РаботаВ1С"]) for w in onec["Работы"] for m in w["Материалы"]}
                self.assertEqual(actions["Труба PP-H 50"], ("перепривязать", other))
                self.assertEqual(onec["Итого"]["Перепривязать"], 1)
                sopost = onec["СопоставлениеРВиЛРВ"]
                moves = [(c["Действие"], c["Количество"], c["КодИерархии"]) for c in sopost["ТЧИзменений"] if c["Номенклатура"] == "Труба PP-H 50"]
                self.assertEqual(moves, [("перепривязать", -20, other), ("перепривязать", 20, pipe50["agent_code"])])
                self.assertEqual(sopost["Итого"]["Перепривязать"], 1)
                self.assertEqual((sopost["Документ"]["Пользователь"], sopost["Документ"]["ДатаСогласования"][:4]), ("parfenov", "2026"))
            self.assertEqual(onec["Итого"]["РазнесеноВ1С"], 2)

    def test_split_rows_across_works(self):
        """Строка ЛРВ на несколько работ: как разнесено в 1С («РаботыВ1С» с двумя работами) — части с тем же
        ИдентификаторСтроки и долями (ВесовойКоэф), обе «как в 1С»; по решению сметчика (feedback.splits) —
        части «привязать» с количеством под каждой работой, в «ТЧИзменений» по строке на часть; части помнятся
        в результате (splits) и переживают пересборку. Агент предлагает варианты (alts) кабелю ЭОМ."""
        import subprocess
        import bind
        bind.load(os.path.join(PROGRAM_C, "rv", "data"))
        probe = [{"id": 1, "name": "Труба PP-H 110", "unit": "м", "qty": 50, "system": "К1"}]
        agent_code = bind.bind("ВК", probe, "жилой")[0]["code"]
        other = next(c for c in sorted(bind.KB["works"]) if c != agent_code and c.startswith(agent_code.rsplit(".", 2)[0]))
        rows = [
            {"Номенклатура": "Труба PP-H 110", "ЕдиницаИзмерения": "м", "Количество": 50, "ИдентификаторСтроки": "r1",
             "Система": "Система хозяйственно-бытовой канализации",
             "РаботыВ1С": [{"Код": agent_code, "Количество": 30}, {"Код": other, "Количество": 20}]},
            {"Номенклатура": "Ревизия 110", "ЕдиницаИзмерения": "шт", "Количество": 3, "ИдентификаторСтроки": "r3",
             "Система": "Система хозяйственно-бытовой канализации"},
        ]
        with tempfile.TemporaryDirectory() as tmp:
            token = "0123456789abcdef"
            src = os.path.join(tmp, "lrv.json")
            with open(src, "w", encoding="utf-8") as handle:
                json.dump({"ИдентификаторЛРВ": "Смета-2", "Строки": rows}, handle, ensure_ascii=False)
            st = os.path.join(tmp, token + "_status.json")
            with open(st, "w", encoding="utf-8") as handle:
                json.dump({"state": "running", "launched": False}, handle)
            out_json = os.path.join(tmp, token + "_rv.json")
            base = [sys.executable, os.path.join(PROGRAM_C, "web_rv_run.py"), "--status-file", st,
                    "--work-file", os.path.join(tmp, token + "_work.json"), "--out-xlsx", os.path.join(tmp, token + "_rv.xlsx"),
                    "--out-json", out_json, "--learning-file", os.path.join(tmp, "learn.json"), "--source-name", "lrv.json"]

            def run(extra):
                out = subprocess.run(base + extra, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=300)
                self.assertEqual(out.returncode, 0, out.stderr.decode("utf-8")[-800:])
                with open(out_json, encoding="utf-8") as handle:
                    result = json.load(handle)
                with open(os.path.join(tmp, token + "_rv_1c.json"), encoding="utf-8") as handle:
                    onec = json.load(handle)
                return result, onec

            result, onec = run(["--phase", "mark", "--keep-input", "--", src])
            self.assertEqual(result["summary"]["splits"], {"engineer": 0, "onec": 1})
            parts = [(w["КодИСР"], m["Количество"], m["КоличествоВсего"], m["Часть"], m["ВесовойКоэф"], m["Действие"], m["ИдентификаторСтроки"])
                     for w in onec["Работы"] for m in w["Материалы"] if m["Номенклатура"] == "Труба PP-H 110"]
            self.assertEqual(sorted(parts), sorted([(agent_code, 30, 50, "1/2", 0.6, "как в 1С", "r1"), (other, 20, 50, "2/2", 0.4, "как в 1С", "r1")]))
            bindings = {b["name"]: b for e in result["elements"] for b in e["bindings"]}
            rev_id = bindings["Ревизия 110"]["id"]
            self.assertFalse(any(c["Номенклатура"] == "Труба PP-H 110" for c in onec["СопоставлениеРВиЛРВ"]["ТЧИзменений"]))
            # сметчик делит ревизию: 2 шт на работу агента, 1 шт на другую
            feedback = os.path.join(tmp, "feedback.json")
            with open(feedback, "w", encoding="utf-8") as handle:
                json.dump({"token": token, "user": "parfenov", "when": 1794000000, "confirm_rest": True, "corrections": [],
                           "splits": {str(rev_id): [{"code": agent_code, "qty": 2}, {"code": other, "qty": 1}]}}, handle)
            result, onec = run(["--phase", "bind", "--feedback-file", feedback, "--no-review", "--user", "parfenov"])
            self.assertEqual(result["summary"]["splits"], {"engineer": 1, "onec": 1})
            self.assertEqual(result["splits"], {str(rev_id): {"parts": [{"code": agent_code, "qty": 2.0}, {"code": other, "qty": 1.0}], "by": "parfenov"}})
            parts = sorted((w["КодИСР"], m["Количество"], m["Действие"]) for w in onec["Работы"] for m in w["Материалы"] if m["Номенклатура"] == "Ревизия 110")
            self.assertEqual(parts, sorted([(agent_code, 2, "привязать"), (other, 1, "привязать")]))
            changes = sorted((c["КодИерархии"], c["Количество"], c["ВесовойКоэф"]) for c in onec["СопоставлениеРВиЛРВ"]["ТЧИзменений"] if c["Номенклатура"] == "Ревизия 110")
            self.assertEqual(changes, sorted([(agent_code, 2, 0.6667), (other, 1, 0.3333)]))
            with open(os.path.join(tmp, token + "_rv_form.json"), encoding="utf-8") as handle:
                form = [r for r in json.load(handle)["rows"] if r.get("t") == "mat" and r["name"] == "Ревизия 110"]
            self.assertEqual(sorted((r["split_k"], r["split_n"], r["split_total"], r["split_by"]) for r in form), [(0, 2, 3, "parfenov"), (1, 2, 3, "parfenov")])
            # пересборка без новой проверки: разбиение остаётся; пустой список убирает его
            result, onec = run(["--phase", "bind", "--no-review", "--user", "parfenov"])
            self.assertEqual(result["summary"]["splits"]["engineer"], 1)
            with open(feedback, "w", encoding="utf-8") as handle:
                json.dump({"token": token, "user": "parfenov", "when": 1794000100, "confirm_rest": True, "corrections": [], "splits": {str(rev_id): []}}, handle)
            result, onec = run(["--phase", "bind", "--feedback-file", feedback, "--no-review", "--user", "parfenov"])
            self.assertEqual(result["summary"]["splits"]["engineer"], 0)
            self.assertEqual(result["splits"], {})
        # варианты агента: кабель ЭОМ может лежать в лотке, в трубе или открыто - на проверку с F-ALT и списком
        cable = bind.bind("ЭОМ", [{"id": 1, "name": "Кабель ВВГнг(А)-LS 3х2,5", "unit": "м", "qty": 100, "system": "Электроснабжение"}], "жилой")[0]
        self.assertIn("F-ALT", cable["fcodes"])
        self.assertTrue(cable["review"])
        self.assertEqual(len(cable["alts"]), 2)
        self.assertTrue(all(a["code"] != cable["code"] and a["work"] for a in cable["alts"]))

    def test_sopost_rows_parse_like_1c_report(self):
        """Строки из обработки «Соответствие РВ и ЛРВ» после нормализации в 1c_rv.php: «Колво» — количество,
        «Система» — Аналитика 1 сметы, остальные поля 1С — как есть."""
        rows = [{"Номенклатура": "Адаптер прямоугольный 150х150-125-250", "НоменклатураGUID": "e006-1", "Код": "БП-10155304",
                 "АртикулНоменклатуры": "", "ЕдиницаИзмерения": "шт", "ЕдиницаИзмеренияGUID": "54c0", "ЕстьВЛРВ": "Да",
                 "Колво": 2, "КолвоВСмету": 2, "Количество": 2, "КоличествоВСмету": 2, "КолВоСпец": 3,
                 "СпецОсновнаяСметнаяПозицияНоменклатура": "Прокладка воздуховодов прямоугольного сечения / соединительные элементы",
                 "ОсновнаяСпецификация": "<>", "ВесовойКоэф": 1.8, "СуммаВСмету": 0, "Сумма": 0,
                 "Система": "Общеобменная вентиляция", "Аналитика": "Основные работы", "ИдентификаторСтроки": "e006-1"}]
        with tempfile.TemporaryDirectory() as tmp:
            path = os.path.join(tmp, "lrv.json")
            with open(path, "w", encoding="utf-8") as handle:
                json.dump({"ИдентификаторЛРВ": "Смета-1", "Строки": rows}, handle, ensure_ascii=False)
            parsed = rv_input.parse_lrv(path)
        item = parsed["items"][0]
        self.assertEqual((item["qty"], item["unit"], item["code_1c"], item["uid"]), (2, "шт", "БП-10155304", "e006-1"))
        self.assertEqual(item["ext"]["НоменклатураGUID"], "e006-1")
        self.assertEqual(item["ext"]["ВесовойКоэф"], 1.8)
        self.assertIn("СпецОсновнаяСметнаяПозицияНоменклатура", item["ext"])
        marks = rv_input.guess_headers("авто", parsed["headers"], parsed["format"])
        rv_input.apply_marks("авто", parsed, marks)
        self.assertEqual((item["section"], item["system"]), ("ОВ2", "ОВ"))

    def test_sopost_positions_become_smeta_works_and_bound_rows(self):
        """Пакет из обработки со «СметныеПозиции» (в позиции зашита работа, под ней разнесённые материалы):
        1c_rv.php выводит из них работы сметы (код ИСР — «КодИерархии», а не код позиции) и строки
        разнесённого с «РаботыВ1С»; материал под двумя позициями (крепёж) — одна строка с двумя работами.
        Без «Строки» пакет тоже принимается. Нужен php; работа без кода ИСР — код по имени (smeta_input)."""
        import shutil
        import subprocess
        php = shutil.which("php")
        if not php:
            self.skipTest("php не установлен")
        packet = {"Сопоставление": "Сопоставление РВ и ЛРВ 000001", "СопоставлениеGUID": "doc-1", "Смета": "Смета 1",
                  "СметаGUID": "sm-1", "Аналитика1": "Общеобменная вентиляция", "Аналитика4": "Основные работы",
                  "СметныеПозиции": [
                      {"СметнаяПозиция": "Прокладка воздуховодов круглого сечения / толщина стенки до 0,7 мм м2",
                       "СметнаяПозицияGUID": "sp-1", "Код": "12", "Работа": "Прокладка воздуховодов круглого сечения / толщина стенки до 0,7 мм",
                       "РаботаGUID": "w-1", "КодИерархии": "6.2.3.3.1.1.2.1", "ЕдиницаИзмерения": "м2", "Количество": 100,
                       "Материалы": [{"Номенклатура": "Воздуховод d125", "НоменклатураGUID": "n-1", "Код": "БП-1", "ЕдиницаИзмерения": "м2",
                                      "Колво": 100, "КолвоВСмету": 100, "ВесовойКоэф": 1},
                                     {"Номенклатура": "Болт анкерный М8", "НоменклатураGUID": "n-3", "Код": "БП-3", "ЕдиницаИзмерения": "шт",
                                      "Колво": 30, "КолвоВСмету": 30, "ВесовойКоэф": 0.5}]},
                      {"СметнаяПозиция": "Прокладка воздуховодов прямоугольного сечения / толщина стенки до 0,7 мм м2",
                       "СметнаяПозицияGUID": "sp-2", "Код": "13", "Работа": "Прокладка воздуховодов прямоугольного сечения / толщина стенки до 0,7 мм",
                       "РаботаGUID": "w-2", "КодИерархии": "", "ЕдиницаИзмерения": "м2", "Количество": 40,
                       "Материалы": [{"Номенклатура": "Болт анкерный М8", "НоменклатураGUID": "n-3", "Код": "БП-3", "ЕдиницаИзмерения": "шт",
                                      "Колво": 10, "КолвоВСмету": 10, "ВесовойКоэф": 0.5}]}]}
        script = ("require $argv[1]; echo json_encode(rv1c_normalize_sopost(json_decode(file_get_contents($argv[2]), true)),"
                  " JSON_UNESCAPED_UNICODE);")
        with tempfile.TemporaryDirectory() as tmp:
            src = os.path.join(tmp, "packet.json")
            with open(src, "w", encoding="utf-8") as handle:
                json.dump(packet, handle, ensure_ascii=False)
            out = subprocess.run([php, "-r", script, os.path.join(ROOT, "web", "1c_rv.php"), src], stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE, timeout=60, env=dict(os.environ, RV1C_FUNCTIONS_ONLY="1"))
            self.assertEqual(out.returncode, 0, out.stderr.decode("utf-8")[-800:])
            data = json.loads(out.stdout.decode("utf-8"))
        self.assertEqual(data["ИдентификаторЛРВ"], "Смета-sm-1")
        works = data["РаботыСметы"]
        self.assertEqual([(w["Код"], w["Наименование"][:22], w["КодПозиции"], w["СметнаяПозицияGUID"], w["Количество"]) for w in works],
                         [("6.2.3.3.1.1.2.1", "Прокладка воздуховодов", "12", "sp-1", 100), ("", "Прокладка воздуховодов", "13", "sp-2", 40)])
        rows = {r["ИдентификаторСтроки"]: r for r in data["Строки"]}
        self.assertEqual(sorted(rows), ["n-1|разнесено", "n-3|разнесено"])
        bolt = rows["n-3|разнесено"]
        self.assertEqual((bolt["Количество"], bolt["КоличествоВСмету"], bolt["РазнесеноВ1С"], bolt["Система"], bolt["Аналитика"]),
                         (40, 40, 40, "Общеобменная вентиляция", "Основные работы"))
        self.assertEqual([(w["Код"], w["Количество"], w["СметнаяПозицияGUID"]) for w in bolt["РаботыВ1С"]],
                         [("6.2.3.3.1.1.2.1", 30, "sp-1"), ("", 10, "sp-2")])
        self.assertEqual(bolt["РаботыВ1С"][1]["Наименование"], "Прокладка воздуховодов прямоугольного сечения / толщина стенки до 0,7 мм")
        # Работа без кода ИСР — код по наименованию, как у спецификаций
        import bind
        import web_rv_run
        bind.load(os.path.join(PROGRAM_C, "rv", "data"))
        with tempfile.TemporaryDirectory() as tmp:
            st = os.path.join(tmp, "t_status.json")
            with open(os.path.join(tmp, "t_smeta.json"), "w", encoding="utf-8") as handle:
                json.dump({"works": works}, handle, ensure_ascii=False)
            smeta = web_rv_run.smeta_input(mock.Mock(status_file=st), bind.KB["works"], "ОВ2", bind.sys_code("ОВ2", "ОВ"))
        self.assertIn("6.2.3.3.1.1.2.1", smeta)
        found = [c for c, w in smeta.items() if w["guid"] == "sp-2"]
        self.assertEqual(len(found), 1, smeta)
        self.assertEqual(bind.KB["works"][found[0]], "Прокладка воздуховодов прямоугольного сечения / толщина стенки до 0,7 мм")

    def test_sopost_processor_tree_massiv_rabot(self):
        """Реальный формат обработки «Соответствие РВ и ЛРВ» (var3): «СметныеПозиции» с именами полей 1С
        (сити_ВнутреннееНаименованиеРаботы, УИДУзлаДерева, без кода) и плоское дерево «МассивРабот»
        (позиция → материал-родитель → материал с «КолвоМатериала» и «СметаКодИерархия»). Код позиции — из
        её материалов; материал с нулевым разносом не строка; «МассивРабот» в пакете не остаётся;
        строка «Строки» с отрицательным остатком пропускается при чтении."""
        import shutil
        import subprocess
        php = shutil.which("php")
        if not php:
            self.skipTest("php не установлен")
        pos = {"СметнаяПозиция": "Монтаж лотка / перфорированного, неперфорированного пог. м /пог. м", "СметнаяПозицияGUID": "sp-1",
               "сити_СметноеНаименованиеРаботы": "Монтаж лотка / перфорированного, неперфорированного",
               "сити_СметноеНаименованиеРаботыGUID": "w-1", "сити_ВнутреннееНаименованиеРаботы": "Монтаж лотка / перфорированного, неперфорированного",
               "сити_ВнутреннееНаименованиеРаботыGUID": "w-1", "ЕдиницаИзмерения": "пог. м", "ЕдиницаИзмеренияGUID": "u-pm",
               "Количество": 360, "КоличествоПоСмете": 444, "УИДУзлаДерева": "node-1"}
        line = {"СметнаяПозиция": pos["СметнаяПозиция"], "СметнаяПозицияGUID": "sp-1", "КоличествоСметныхПозиций": 0,
                "сити_СметноеНаименованиеРаботы": "", "сити_ВнутреннееНаименованиеРаботы": "", "Номенклатура": "", "НоменклатураGUID": "",
                "НоменклатураРодитель": "", "НоменклатураРодительGUID": "", "ЕдиницаИзмерения": "", "ЕдиницаИзмеренияGUID": "",
                "СметаКодИерархия": "", "РесурснаяВедомость": "", "РесурснаяВедомостьGUID": "", "ВесовойКоэф": 0, "Колво": 0, "КолвоВСмету": 0,
                "Сумма": 0, "СуммаВСмету": 0, "КолвоМатериала": 0, "КолвоМатериалаВСмету": 0, "КолвоРабот": 360, "КолвоРаботВСмету": 444,
                "КолВоСпец": 0, "ЕстьВЛРВ": "", "ОсновнаяСпецификация": "", "ОсновнаяСпецификацияGUID": "",
                "СпецОсновнаяСметнаяПозицияНоменклатура": "", "СпецОсновнаяСметнаяПозицияНоменклатураGUID": ""}
        parent = dict(line, НоменклатураРодитель="DNP-32 Дюбель-гвоздь", НоменклатураРодительGUID="n-1")
        material = dict(parent, Номенклатура="DNP-32 Дюбель-гвоздь", НоменклатураGUID="n-1", ЕдиницаИзмерения="шт", КолвоМатериала=288,
                        КолвоМатериалаВСмету=300, ВесовойКоэф=0.5, КолВоСпец=2, ЕстьВЛРВ="Да", СметаКодИерархия="6.2.3.4.1.4.6.2",
                        Сумма=1440.5, СуммаВСмету=1500,
                        СпецОсновнаяСметнаяПозицияНоменклатура="Монтаж лотка электротехнического / перфорированного, неперфорированного")
        empty = dict(material, Номенклатура="Винт М5х8", НоменклатураGUID="n-2", КолвоМатериала=0, КолвоМатериалаВСмету=0)
        packet = {"Сопоставление": "Сопоставление РВ и ЛРВ 000006700", "СопоставлениеGUID": "doc-1", "Смета": "ЖК Б к.3.6 ЭОМ / Эл. нежилой / Основные работы",
                  "СметаGUID": "sm-1", "НоменклатурнаяГруппа": "ЖК Б к.3.6 Электромонтажные работы", "НоменклатурнаяГруппаGUID": "ng-1",
                  "Аналитика1": "Электромонтажные работы в нежилой части", "Аналитика2": "", "Аналитика3": "", "Аналитика4": "Основные работы",
                  "Источник": "1С БИТ.Строительство, СайтРВ_Обмен",
                  "Строки": [{"Номенклатура": "Плита Rockwool", "НоменклатураGUID": "n-9", "Код": "БП-1", "Артикул": "", "ЕдиницаИзмерения": "шт",
                              "ЕстьВЛРВ": "Да", "Колво": -22, "КолвоВСмету": 0, "КолВоСпец": 0, "СпецОсновнаяСметнаяПозицияНоменклатура": "",
                              "ОсновнаяСпецификация": "", "ВесовойКоэф": 0, "СуммаВСмету": 0, "Сумма": 0},
                             {"Номенклатура": "Труба гофрированная ПВХ д.20", "НоменклатураGUID": "n-8", "Код": "БП-2", "Артикул": "",
                              "ЕдиницаИзмерения": "м", "ЕстьВЛРВ": "Да", "Колво": 350, "КолвоВСмету": 0, "КолВоСпец": 0,
                              "СпецОсновнаяСметнаяПозицияНоменклатура": "Монтаж трубы ПВХ, ПНД для кабеля / до 32", "ОсновнаяСпецификация": "",
                              "ВесовойКоэф": 0, "СуммаВСмету": 0, "Сумма": 0}],
                  "МассивРабот": [line, parent, material, dict(parent, НоменклатураРодитель="Винт М5х8", НоменклатураРодительGUID="n-2"), empty],
                  "СметныеПозиции": [pos]}
        script = ("require $argv[1]; $d = json_decode(file_get_contents($argv[2]), true);"
                  " echo json_encode(['unknown' => rv1c_unknown_fields($d), 'data' => rv1c_normalize_sopost($d)], JSON_UNESCAPED_UNICODE);")
        with tempfile.TemporaryDirectory() as tmp:
            src = os.path.join(tmp, "packet.json")
            with open(src, "w", encoding="utf-8") as handle:
                json.dump(packet, handle, ensure_ascii=False)
            out = subprocess.run([php, "-r", script, os.path.join(ROOT, "web", "1c_rv.php"), src], stdout=subprocess.PIPE,
                                 stderr=subprocess.PIPE, timeout=60, env=dict(os.environ, RV1C_FUNCTIONS_ONLY="1"))
            self.assertEqual(out.returncode, 0, out.stderr.decode("utf-8")[-800:])
            result = json.loads(out.stdout.decode("utf-8"))
        self.assertEqual(result["unknown"], [])
        data = result["data"]
        self.assertNotIn("МассивРабот", data)
        self.assertEqual([(w["Код"], w["Наименование"], w["Количество"], w["РаботаGUID"], w["УИДУзлаДерева"]) for w in data["РаботыСметы"]],
                         [("6.2.3.4.1.4.6.2", "Монтаж лотка / перфорированного, неперфорированного", 360, "w-1", "node-1")])
        self.assertEqual(data["РаботыСметы"][0]["ЕдиницаИзмеренияGUID"], "u-pm")
        rows = {r["ИдентификаторСтроки"]: r for r in data["Строки"]}
        self.assertEqual(sorted(rows), ["n-1|разнесено", "n-8", "n-9"])
        bolt = rows["n-1|разнесено"]
        self.assertEqual((bolt["Количество"], bolt["КоличествоВСмету"], bolt["РазнесеноВ1С"], bolt["Система"], bolt["ЕдиницаИзмерения"]),
                         (288, 300, 288, "Электромонтажные работы в нежилой части", "шт"))
        self.assertEqual((bolt["Сумма"], bolt["СуммаВСмету"]), (1440.5, 1500))        # суммы разнесённого — как количества
        self.assertEqual(bolt["РаботыВ1С"], [{"Код": "6.2.3.4.1.4.6.2", "Наименование": "Монтаж лотка / перфорированного, неперфорированного",
                                             "Количество": 288, "Коэффициент": 0.5, "Сумма": 1440.5, "СуммаВСмету": 1500,
                                             "СметнаяПозицияGUID": "sp-1"}])
        self.assertNotIn("КолвоМатериала", bolt)
        self.assertNotIn("НоменклатураРодитель", bolt)
        self.assertEqual(bolt["СпецОсновнаяСметнаяПозицияНоменклатура"], "Монтаж лотка электротехнического / перфорированного, неперфорированного")
        self.assertEqual(rows["n-9"]["Количество"], -22)
        # отрицательный остаток не читается как строка ЛРВ
        import rv_input
        with tempfile.TemporaryDirectory() as tmp:
            src = os.path.join(tmp, "lrv.json")
            with open(src, "w", encoding="utf-8") as handle:
                json.dump({"ИдентификаторЛРВ": "x", "Строки": data["Строки"]}, handle, ensure_ascii=False)
            parsed = rv_input.parse_lrv(src)
        self.assertEqual(sorted(i["name"] for i in parsed["items"]), ["DNP-32 Дюбель-гвоздь", "Труба гофрированная ПВХ д.20"])

    def test_export_1c_row_sums(self):
        """РВ для 1С: у каждой строки «Работы[].Материалы[]» и «БезРаботы» есть «Сумма», «СуммаВСмету», «КоличествоВСмету» —
        доля строки ЛРВ под этой работой, как в «Товары»: части строки, разнесённой на две работы, в сумме дают сумму строки;
        строка без сумм из 1С — с нулями, а не без полей."""
        part = {"uid": "r1", "name": "Хомут", "unit": "шт", "qty_total": 10, "system": "В1", "split_of": 1, "split_n": 2,
                "ext": {"НоменклатураGUID": "n-1", "Сумма": 1000, "СуммаВСмету": 1200, "КоличествоВСмету": 12}}
        items = [dict(part, id=1, qty=6, split_k=0), dict(part, id=2, qty=4, split_k=1),
                 {"id": 3, "uid": "r3", "name": "Труба", "unit": "м", "qty": 5, "system": "В1", "ext": {"НоменклатураGUID": "n-3"}},
                 {"id": 4, "uid": "r4", "name": "Прочее", "unit": "шт", "qty": 2, "system": "В1",
                  "ext": {"НоменклатураGUID": "n-4", "Сумма": "50,5"}}]
        bindings = [{"id": 1, "code": "A", "role": "Кр"}, {"id": 2, "code": "B", "role": "Кр"}, {"id": 3, "code": "B"}, {"id": 4}]
        result = {"elements": [{"element": "", "section": "ВК", "items": items, "bindings": bindings,
                                "rv": {"works": [{"code": "A", "unit": "шт", "volume": 6, "materials": [{"id": 1, "qty": 6}]},
                                                 {"code": "B", "unit": "м", "volume": 5, "materials": [{"id": 2, "qty": 4}, {"id": 3, "qty": 5}]}],
                                       "unbound": [{"id": 4}]}}], "summary": {}}
        import web_rv_run
        smeta = {"A": {"guid": "sp-A", "unit": "шт", "unit_guid": "u-sht"}, "Z": {"guid": "sp-Z", "unit": "м"}}
        units = web_rv_run.unit_guids_of({"Строки": [{"ЕдиницаИзмерения": "м", "ЕдиницаИзмеренияGUID": "u-m"},
                                                      {"ЕдиницаИзмерения": "кг", "ЕдиницаИзмеренияGUID": "u-kg"},
                                                      {"ЕдиницаИзмерения": "кг", "ЕдиницаИзмеренияGUID": "u-kg2"}],
                                          "СметныеПозиции": [{"СметнаяПозицияGUID": "sp-Z", "ЕдиницаИзмеренияGUID": "u-z"}]})
        self.assertEqual(units, {"position": {"sp-Z": "u-z"}, "name": {"м": "u-m"}})      # «кг» с двумя GUID — не угадываем
        out = web_rv_run.export_1c(result, {"lrv_id": "Смета-x"}, {"A": "Работа A", "B": "Работа B"}, smeta, units=units)
        works = {w["КодИСР"]: w for w in out["Работы"]}
        totals = ("Количество", "КоличествоПоСмете", "Сумма", "СуммаВСмету", "ЕдиницаИзмеренияGUID")
        self.assertEqual(tuple(works["A"][f] for f in totals), (6, 7.2, 600, 720, "u-sht"))      # GUID единицы — у позиции сметы
        self.assertEqual(tuple(works["B"][f] for f in totals), (9, 4.8, 400, 480, "u-m"))        # не в смете — по имени из пакета
        self.assertEqual(works["A"]["Объем"], 6)
        positions = {p["КодИерархии"]: p for p in out["СопоставлениеРВиЛРВ"]["СметныеПозиции"]}
        self.assertEqual((positions["A"]["ЕдиницаИзмеренияGUID"], positions["B"]["ЕдиницаИзмеренияGUID"]), ("u-sht", "u-m"))
        # новая сметная позиция — явно: работы нет среди позиций сметы 1С; без сметы из 1С — null (сайт не знает)
        self.assertEqual((works["A"]["НоваяСметнаяПозиция"], works["B"]["НоваяСметнаяПозиция"]), (False, True))
        self.assertEqual((works["B"]["СметнаяПозицияGUID"], out["Итого"]["НовыхСметныхПозиций"]), ("", 1))
        self.assertEqual((positions["A"]["НоваяСметнаяПозиция"], positions["B"]["НоваяСметнаяПозиция"]), (False, True))
        bare = web_rv_run.export_1c(result, {"lrv_id": "Смета-x"}, {"A": "Работа A", "B": "Работа B"}, None)
        self.assertEqual([w["НоваяСметнаяПозиция"] for w in bare["Работы"]], [None, None])
        self.assertEqual(bare["Итого"]["НовыхСметныхПозиций"], 0)
        rows = {m["ИдентификаторСтроки"] + m.get("Часть", ""): m for w in out["Работы"] for m in w["Материалы"]}
        fields = ("Сумма", "СуммаВСмету", "КоличествоВСмету")
        self.assertEqual([tuple(rows["r11/2"][f] for f in fields), tuple(rows["r12/2"][f] for f in fields)], [(600, 720, 7.2), (400, 480, 4.8)])
        self.assertEqual(tuple(rows["r3"][f] for f in fields), (0, 0, 0))
        self.assertEqual(tuple(out["БезРаботы"][0][f] for f in fields), (50.5, 0, 0))
        goods = {(g["ИдентификаторСтроки"], g["КодИерархии"]): g for g in out["СопоставлениеРВиЛРВ"]["Товары"]}
        self.assertEqual((goods[("r1", "A")]["Сумма"], goods[("r1", "B")]["Сумма"]), (600, 400))   # «Товары» — те же доли

    def test_fill_onec_sums_from_packet(self):
        """РВ, собранная до переноса сумм разнесённого: при пересборке «Сумма»/«СуммаВСмету» строк «разнесено в 1С»
        берутся из пакета 1С — строки материалов «МассивРабот» (по всем позициям) или «Материалы» сметных позиций;
        строки с суммами и строки ЛРВ не трогаются; в пакете сумм нет — ничего."""
        import web_rv_run
        line = {"Номенклатура": "Хомут", "НоменклатураGUID": "N-1", "КолвоМатериала": 4, "Сумма": 100, "СуммаВСмету": 120}
        packet = {"Строки": [], "МассивРабот": [line, dict(line, КолвоМатериала=6, Сумма=150.5, СуммаВСмету=0),
                                                 dict(line, Номенклатура="", НоменклатураGUID=""),          # строка позиции
                                                 dict(line, НоменклатураGUID="n-2", КолвоМатериала=0, Сумма=9)]}
        self.assertEqual(web_rv_run.onec_sums_of(packet), {"n-1": (250.5, 120)})
        items = [{"uid": "n-1|разнесено", "ext": {"Количество": 10}},
                 {"uid": "n-1|разнесено", "ext": {"Сумма": 7, "СуммаВСмету": 8}},
                 {"uid": "n-1", "ext": {}}, {"uid": "n-3|разнесено", "ext": {}}]
        self.assertEqual(web_rv_run.fill_onec_sums(items, web_rv_run.onec_sums_of(packet)), 1)
        self.assertEqual([i["ext"].get("Сумма") for i in items], [250.5, 7, None, None])
        positions = {"СметныеПозиции": [{"Материалы": [{"Номенклатура": "Труба", "НоменклатураGUID": "t", "Колво": 3, "Сумма": 30}]}]}
        self.assertEqual(web_rv_run.onec_sums_of(positions), {"t": (30, 0)})
        self.assertEqual(web_rv_run.onec_sums_of({"СметныеПозиции": [{"Материалы": [{"Номенклатура": "Труба", "Колво": 3}]}]}), {})

    def test_objects_table_match(self):
        """Справочник объектов (rv/data/rv_objects_table.json, таблица «Объекты и сметчики»): номенклатурная группа 1С
        находит объект по началу имени (с псевдонимами), корпус - по номеру/паркингу/секции, систему - по имени;
        ответственный - из ячейки корпуса (осн / НЗ), иначе по объекту, иначе запасной; объекта нет - никого.
        Архивные (исключённые) объекты находятся, но ответственного не дают. Нужен php."""
        import shutil
        import subprocess
        php = shutil.which("php")
        if not php:
            self.skipTest("php не установлен")
        cases = [
            ["ЖК Большая Академическая к.3.6 Электромонтажные работы", "Электромонтажные работы в нежилой части", "ЖК Большая Академическая к.3.6 Электромонтажные работы / Электромонтажные работы в нежилой части / Основные работы", ""],
            ["ЖК Сиреневый бульвар корпус 1.3 ВК", "Водоснабжение", "ЖК Сиреневый бульвар корпус 1.3 ВК / Водоснабжение / Работы по З/Н №12", "12"],
            ["ЖК Амурский парк блок 1, корпус 1.4 Вентиляция", "Общеобменная вентиляция", "x / Основные работы", ""],
            ["ЖК Белая Дача Корпус 16,2 Вентиляция Секция 3", "Вентиляция", "x", ""],
            ["2-Й Иртышский Корпус 1.5 ВК", "ВК", "x", ""],
            ["Сигнальный 16 к.2.1 Паркинг ЭОМ", "ЭОМ", "x", ""],
            ["ЖК Римского-Корсакова 11 ОДС Вентиляция", "Вентиляция", "x", ""],
            ["ЖК Холланд парк к.8 Вентиляция", "Вентиляция", "x", ""],
        ]
        script = ("require $argv[1] . '/web/config.php'; require_once $argv[1] . '/web/users.php'; require_once $argv[1] . '/web/lib.php';"
                  " require_once $argv[1] . '/web/rv_lib.php'; $out = [];"
                  " foreach (json_decode(file_get_contents($argv[2]), true) as [$ng, $sys, $smeta, $zn]) {"
                  "   $meta = ['obj' => $ng, 'obj_key' => rv_registry_key('', $ng), 'folder' => '', 'smeta' => $smeta, 'system' => $sys, 'zn' => $zn,"
                  "            'work_kind' => rv_kind_of($smeta, $zn)];"
                  "   $m = rv_table_match($meta); $r = rv_table_responsible($m, $meta['work_kind']);"
                  "   $out[] = [$m['object'], $m['building_label'], $m['system'], $meta['work_kind'], $r['login'], $r['level']]; }"
                  " echo json_encode($out, JSON_UNESCAPED_UNICODE);")
        with tempfile.TemporaryDirectory() as tmp:
            src = os.path.join(tmp, "cases.json")
            with open(src, "w", encoding="utf-8") as handle:
                json.dump(cases, handle, ensure_ascii=False)
            out = subprocess.run([php, "-r", script, ROOT, src], stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
            self.assertEqual(out.returncode, 0, out.stderr.decode("utf-8")[-800:])
            got = json.loads(out.stdout.decode("utf-8"))
        self.assertEqual(got, [
            ["ЖК Большая Академическая", "к.3.6", "ЭОМ", "осн", "saytkina.t", "table"],
            ["ЖК Сиреневый б-р 6.1", "к.1.3", "ВК", "НЗ", "borcsh.v", "table"],
            ["ЖК Амурский парк блок 1", "к.1.4", "Вентиляция", "осн", "levchuk", "fallback"],
            ["ЖК Белая Дача", "к.16.2 секц 3", "Вентиляция", "осн", "levchuk", "fallback"],
            ["ЖК 2-ой Иртышский", "к.1.5", "ВК", "осн", "bezugliy.s", "table"],
            ["ЖК Сигнальный 16", "к.2.1 подземный паркинг", "ЭОМ", "осн", "melnikova.n", "table"],
            ["", "", "Вентиляция", "осн", "", "table"],
            ["ЖК Холланд парк", "к.8", "Вентиляция", "осн", "", "table"],      # Холланд парк в архиве: объект виден, ответственного нет
        ])

    def test_queue_puts_audit_last(self):
        import web_rv_run
        with tempfile.TemporaryDirectory() as tmp:
            for token, created, mode in (("a" * 16, 1, "audit"), ("b" * 16, 5, ""), ("c" * 16, 3, "audit"), ("d" * 16, 9, "")):
                with open(os.path.join(tmp, token + "_job.json"), "w", encoding="utf-8") as handle:
                    json.dump({"created": created, "mode": mode}, handle)
                with open(os.path.join(tmp, token + "_status.json"), "w", encoding="utf-8") as handle:
                    json.dump({"state": "queued"}, handle)
            self.assertEqual([t[0] for t, _ in web_rv_run.queued_jobs(tmp)], ["b", "d", "a", "c"])


class SchemaTest(unittest.TestCase):
    """Структурированный вывод API: у каждого объекта схемы "additionalProperties": false, иначе HTTP 400."""

    def _walk(self, node, path):
        if isinstance(node, dict):
            if node.get("type") == "object":
                self.assertIs(node.get("additionalProperties"), False, path)
            for key, value in node.items():
                self._walk(value, path + "/" + key)
        elif isinstance(node, list):
            for index, value in enumerate(node):
                self._walk(value, "%s/%d" % (path, index))

    def test_schemas_strict(self):
        self._walk(rv_agent.MARK_SCHEMA, "MARK_SCHEMA")
        self._walk(rv_agent.REVIEW_SCHEMA, "REVIEW_SCHEMA")


class StartupTest(unittest.TestCase):
    """Старт на общем хостинге: нехватка памяти при загрузке библиотек и зависшие запуски."""

    def _run(self, status, env_extra):
        import subprocess
        env = dict(os.environ, **env_extra)
        return subprocess.run([sys.executable, os.path.join(PROGRAM_C, "web_rv_run.py"), "--phase", "mark",
                               "--status-file", status, "--work-file", status + ".work", "--", status + ".xlsx"],
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env, timeout=60)

    def test_out_of_memory_on_start(self):
        with tempfile.TemporaryDirectory() as tmp:
            status = os.path.join(tmp, "status.json")
            with open(status, "w", encoding="utf-8") as handle:
                json.dump({"state": "running", "launched": False, "log": ["[00:00:00] первая фаза"]}, handle)
            out = self._run(status, {"RV_SIMULATE_STARTUP_OOM": "1", "RV_ATTEMPT": "1", "RV_ATTEMPTS": "3"})
            self.assertEqual(out.returncode, 75)                 # оболочка повторит
            data = json.load(open(status, encoding="utf-8"))
            self.assertEqual(data["state"], "running")
            self.assertNotIn("launched", data)
            self.assertIn("попытка 1 из 3", data["stage"])
            self.assertEqual(data["log"], ["[00:00:00] первая фаза"])
            out = self._run(status, {"RV_SIMULATE_STARTUP_OOM": "1", "RV_ATTEMPT": "3", "RV_ATTEMPTS": "3"})
            self.assertEqual(out.returncode, 75)
            data = json.load(open(status, encoding="utf-8"))
            self.assertEqual(data["state"], "error")
            self.assertIn("не хватает памяти", data["error"])
            self.assertIn("процессы аккаунта", data["error"])
            self.assertIn("failed to map segment", out.stderr.decode("utf-8"))

    def test_start_error_is_reported_at_once(self):
        with tempfile.TemporaryDirectory() as tmp:
            status = os.path.join(tmp, "status.json")
            with open(status, "w", encoding="utf-8") as handle:
                json.dump({"state": "running", "launched": False}, handle)
            out = self._run(status, {"RV_SIMULATE_STARTUP_ERROR": "1"})
            self.assertEqual(out.returncode, 1)
            data = json.load(open(status, encoding="utf-8"))
            self.assertEqual(data["state"], "error")              # страница не ждёт 15 минут
            self.assertIn("libtest", data["error"])

    def test_thread_limit_and_no_numpy(self):
        import subprocess
        code = ("import sys; sys.path.insert(0, %r); import rv_startup; rv_startup.limit_threads(); import os, openpyxl; "
                "wb = openpyxl.Workbook(); wb.active['A1'] = 1.5; "
                "print(os.environ['OPENBLAS_NUM_THREADS'], 'numpy' in sys.modules and sys.modules['numpy'] is not None)") % PROGRAM_C
        out = subprocess.run([sys.executable, "-c", code], stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60)
        self.assertEqual(out.stdout.decode().split(), ["1", "False"], out.stderr.decode())
        self.assertIn("лимит хостинга", __import__("rv_startup").memory_report())

    def test_stop_stale_runs(self):
        import subprocess
        import time
        import rv_startup
        with tempfile.TemporaryDirectory() as tmp:
            fake = os.path.join(tmp, "web_rv_run.py")
            with open(fake, "w") as handle:
                handle.write("import time\ntime.sleep(60)\n")
            proc = subprocess.Popen([sys.executable, fake, "--phase", "bind"])
            try:
                time.sleep(1.2)
                stopped = rv_startup.stop_stale_runs(max_age=0)
                self.assertIn(proc.pid, stopped)
                self.assertIsNotNone(proc.wait(timeout=10))
            finally:
                if proc.poll() is None:
                    proc.kill()
            self.assertEqual(rv_startup.stop_stale_runs(max_age=10 ** 9), [])

    def test_memory_report(self):
        import rv_startup
        text = rv_startup.memory_report()
        self.assertIn("процессы аккаунта", text)
        self.assertIn("МБ", text)


class BindSmokeTest(unittest.TestCase):
    """Инструмент комплекта на его же примере: тот же итог, что в комплекте."""

    def test_example_vk(self):
        import bind
        bind.load(os.path.join(PROGRAM_C, "rv", "data"))
        sample = json.load(open(os.path.join(PROGRAM_C, "rv", "docs", "пример_ЛРВ_ВК.json"), encoding="utf-8"))
        for index, item in enumerate(sample["items"]):
            item.setdefault("id", index)
        result = bind.bind(sample["section"], sample["items"], sample.get("object_type"))
        self.assertEqual(len(result), len(sample["items"]))
        self.assertEqual(sum(1 for r in result if r["review"]), 2)
        self.assertTrue(all(r["code"] for r in result))

    def test_row_coefs_match_volumes_and_overrides(self):
        import bind
        import web_rv_run
        bind.load(os.path.join(PROGRAM_C, "rv", "data"))
        items = [{"id": 1, "name": "Воздуховод прямоугольного сечения из оцинк. стали кл. В 1000х500 L=1250мм с толщиной стенки 0.8мм", "unit": "шт", "qty": 3, "system": "ОВ"},
                 {"id": 2, "name": "Воздуховод прямоугольного сечения из оцинк. стали кл. В 100х100 L=1000мм с толщиной стенки 0.8мм", "unit": "шт", "qty": 6, "system": "ОВ"},
                 {"id": 3, "name": "Анкер клин 6х40 мм", "unit": "шт", "qty": 100, "system": "ОВ"}]
        bindings = bind.bind("ОВ2", items, "жилой")
        by_id = {b["id"]: b for b in bindings}
        ordered = [by_id[it["id"]] for it in items]
        volumes = bind.volumes("ОВ2", items, ordered)
        coefs = web_rv_run.row_coefs(items, ordered, volumes)
        code = ordered[0]["code"]
        self.assertEqual(ordered[1]["code"], code)
        self.assertAlmostEqual(coefs[1], 3.75, places=3)       # периметр 3 м × 1,25 м
        self.assertAlmostEqual(coefs[2], 0.4, places=3)
        self.assertEqual(coefs[3], 0)                           # крепёж объём не ведёт
        self.assertAlmostEqual(3 * coefs[1] + 6 * coefs[2], volumes[code]["volume"], places=3)
        ordered[0]["coef_user"] = 4.0                           # инженер поправил
        web_rv_run.apply_coef_overrides(items, ordered, volumes, coefs)
        self.assertAlmostEqual(volumes[code]["volume"], 3 * 4.0 + 6 * 0.4, places=3)
        self.assertTrue(volumes[code]["method"].startswith("по коэффициентам инженера"))

    def test_library_code_moves_into_row_branch(self):
        import bind
        bind.load(os.path.join(PROGRAM_C, "rv", "data"))
        items = [{"id": 1, "name": "Виброизолирующий эластомер Sylomer SR 11 желтый 1200х1500х12,5мм", "unit": "м2", "qty": 21, "system": "ОВ"}]
        binding = bind.bind("ОВ2", items, "жилой")[0]
        self.assertEqual(binding["code"], "6.2.3.3.1.3.10.1")  # та же работа в ветке ОВ, а не код ПДВ из библиотеки
        self.assertTrue(binding["review"])


if __name__ == "__main__":
    unittest.main()
