# -*- coding: utf-8 -*-
"""Сверка РВ, сделанной в 1С, с агентом РВ (ЛРВ из 1С в режиме «Сверка»: web/1c_rv.php → rv_audit.php).

1С присылает строки ЛРВ сметы, у каждой — «РаботыВ1С»: как её разнесли в 1С (документы «Сопоставление
с ресурсной ведомостью»): [{Код — код ИСР, Наименование, Количество — часть строки под работой,
Коэффициент}]; в шапке — «РаботыРВ»: сметные позиции документа РВ с объёмами (файл <токен>_audit.json).
Агент разносит строки сам, как обычную ЛРВ (с памятью решений инженеров), а здесь его разнос
сравнивается с 1С.

Строка:
  match       — работа агента есть среди работ строки в 1С (у крепежа — хоть одна из работ, между которыми
                агент его распределил);
  differ      — в 1С другая работа;
  agent_none  — в 1С работа есть, агент не нашёл;
  no_1c       — в 1С строка не разнесена (её нет в сопоставлениях);
  not_isr     — в 1С работа без кода ИСР (не из классификатора) — сравнить нельзя.
Работы: объём в 1С против объёма агента по коду ИСР — match, volume (расходятся больше VOLUME_TOL),
only_1c, only_agent; позиции 1С без кода ИСР — not_isr.

Модель (режим «только расхождения») смотрит строки differ и agent_none, видя и работу из 1С:
«подтвердить» — прав агент, «заменить» на код из 1С — права 1С, на другой код — оба неверны, «вопрос».
"""

VOLUME_TOL = 0.1

ROW_STATUS = {
    "match": "совпадает",
    "differ": "другая работа",
    "agent_none": "агент не нашёл работу",
    "no_1c": "в 1С не разнесена",
    "not_isr": "в 1С работа без кода ИСР",
}
WORK_STATUS = {
    "match": "совпадает",
    "volume": "объём расходится",
    "only_1c": "только в 1С",
    "only_agent": "только у агента",
    "not_isr": "в 1С без кода ИСР",
}
DISPUTED = ("differ", "agent_none")


def _num(value):
    try:
        return float(str(value).replace(",", ".").replace(" ", ""))
    except (TypeError, ValueError):
        return None


def works_1c(ext):
    """Работы строки в 1С: [{code, name, qty, coef, reduce, left}] из поля «РаботыВ1С». qty — сколько под работой
    в 1С; reduce и left — уменьшение по ЛРВ и сколько остаётся (web_rv_run.apply_reductions), None — уменьшения нет."""
    out = []
    for work in (ext or {}).get("РаботыВ1С") or []:
        if not isinstance(work, dict):
            continue
        out.append(dict(code=str(work.get("Код") or work.get("КодИСР") or "").strip(),
                        name=str(work.get("Наименование") or "").strip(),
                        qty=_num(work.get("Количество")), coef=_num(work.get("Коэффициент")),
                        reduce=_num(work.get("Уменьшение")), left=_num(work.get("Остается"))))
    return out


def main_code(works):
    """Основная работа строки в 1С — с наибольшим количеством под ней (у крепежа строка делится между работами)."""
    coded = [w for w in works if w["code"]]
    if not coded:
        return ""
    return max(coded, key=lambda w: w["qty"] or 0)["code"]


def row_status(binding, works, agent_codes):
    codes = {w["code"] for w in works if w["code"]}
    if not works:
        return "no_1c"
    if not codes:
        return "not_isr"
    if not binding.get("code"):
        return "agent_none"
    return "match" if codes & agent_codes else "differ"


def text_1c(works, kb_works=None):
    """Работы 1С строкой — для модели и страницы: «код — работа (кол-во)»."""
    parts = []
    for work in works:
        name = work["name"] or (kb_works or {}).get(work["code"], "")
        qty = "" if work["qty"] is None else " (%g)" % work["qty"]
        parts.append("%s — %s%s" % (work["code"] or "без кода ИСР", name[:90], qty))
    return "; ".join(parts) or "—"


def model_verdict(entry, works):
    """Вердикт модели по строке в терминах сверки: agent / 1c / other / question."""
    if not entry:
        return None
    verdict = entry.get("verdict")
    codes = {w["code"] for w in works if w["code"]}
    if verdict == "подтвердить":
        side = "agent"
    elif verdict == "заменить" and entry.get("code"):
        side = "1c" if entry["code"] in codes else "other"
    else:
        side = "question"
    return dict(side=side, code=entry.get("code") or "", work=entry.get("work") or "",
                reason=entry.get("reason") or entry.get("question") or "")


def compare(elements, works_rv, review=None, kb_works=None):
    """Сверка: elements — блоки привязки web_rv_run.run_bind (items, bindings, distribution, rv),
    works_rv — «РаботыРВ» из 1С, review — проверка моделью {id: entry}. Возвращает dict(summary, rows, works)."""
    review = review or {}
    rows = []
    agent_volumes = {}
    for block in elements:
        by_id = {it["id"]: it for it in block.get("items") or []}
        split = {d.get("id"): {p.get("code") for p in d.get("split") or [] if p.get("code")}
                 for d in block.get("distribution") or []}
        for binding in block.get("bindings") or []:
            item = by_id.get(binding["id"], {})
            works = works_1c(item.get("ext"))
            agent_codes = ({binding["code"]} if binding.get("code") else set()) | split.get(binding["id"], set())
            status = row_status(binding, works, agent_codes)
            entry = review.get(binding["id"]) or review.get(str(binding["id"]))
            rows.append(dict(
                id=binding["id"], name=item.get("name") or binding.get("name") or "", unit=item.get("unit") or "",
                qty=item.get("qty"), system=item.get("system") or "", element=block.get("element") or "",
                status=status, agent=dict(code=binding.get("code") or "", work=binding.get("work") or "",
                                          role=binding.get("role") or "", confidence=binding.get("confidence"),
                                          learned=binding.get("learned") or ""),
                c1=works, c1_main=main_code(works),
                model=model_verdict(entry, works) if status in DISPUTED else None))
        for work in (block.get("rv") or {}).get("works") or []:
            slot = agent_volumes.setdefault(work["code"], dict(volume=0.0, has=False, unit=work.get("unit") or "",
                                                               name=work.get("work") or ""))
            if work.get("volume") is not None:
                slot["volume"] += float(work["volume"])
                slot["has"] = True

    onec = {}
    not_isr = []
    for work in works_rv or []:
        if not isinstance(work, dict):
            continue
        code = str(work.get("Код") or work.get("КодИСР") or "").strip()
        qty = _num(work.get("Количество"))
        name = str(work.get("Наименование") or "").strip()
        if not code:
            not_isr.append(dict(code="", name=name, unit=str(work.get("ЕдиницаИзмерения") or ""), vol_1c=qty,
                                vol_agent=None, status="not_isr"))
            continue
        slot = onec.setdefault(code, dict(volume=0.0, unit=str(work.get("ЕдиницаИзмерения") or ""), name=name))
        slot["volume"] += qty or 0.0
    work_rows = []
    for code in sorted(set(onec) | set(agent_volumes)):
        mine, theirs = agent_volumes.get(code), onec.get(code)
        vol_agent = round(mine["volume"], 3) if mine and mine["has"] else None
        vol_1c = round(theirs["volume"], 3) if theirs else None
        if theirs is None:
            status = "only_agent"
        elif mine is None:
            status = "only_1c"
        elif vol_agent is None or not vol_1c:
            status = "match" if (vol_agent or 0) == (vol_1c or 0) else "volume"
        else:
            status = "match" if abs(vol_agent - vol_1c) <= VOLUME_TOL * max(abs(vol_1c), abs(vol_agent)) else "volume"
        name = (theirs or {}).get("name") or (mine or {}).get("name") or (kb_works or {}).get(code, "")
        work_rows.append(dict(code=code, name=name, unit=(mine or theirs or {}).get("unit") or "",
                              vol_1c=vol_1c, vol_agent=vol_agent, status=status))
    work_rows.extend(not_isr)

    counts = {key: 0 for key in ROW_STATUS}
    for row in rows:
        counts[row["status"]] += 1
    comparable = counts["match"] + counts["differ"] + counts["agent_none"]
    model = {"agent": 0, "1c": 0, "other": 0, "question": 0}
    for row in rows:
        if row["model"]:
            model[row["model"]["side"]] += 1
    work_counts = {key: 0 for key in WORK_STATUS}
    for work in work_rows:
        work_counts[work["status"]] += 1
    summary = dict(rows=len(rows), match_pct=round(100.0 * counts["match"] / comparable, 1) if comparable else None,
                   disputed=counts["differ"] + counts["agent_none"], model=model,
                   disputed_ids=[row["id"] for row in rows if row["status"] in DISPUTED],
                   works=len(work_rows), works_volume=work_counts["volume"],
                   works_only_1c=work_counts["only_1c"], works_only_agent=work_counts["only_agent"], **counts)
    summary["work_counts"] = work_counts
    return dict(summary=summary, rows=rows, works=work_rows)
