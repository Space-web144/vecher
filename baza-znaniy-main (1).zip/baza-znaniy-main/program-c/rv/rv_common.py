# -*- coding: utf-8 -*-
import re, json
SEC = {'6.2.3.1': 'ВК', '6.2.3.2': 'ОВ1', '6.2.3.3': 'ОВ2', '6.2.3.4': 'ЭОМ', '6.2.3.5': 'СС', '6.2.3.6': 'ИТП'}
SEC_RVR = {'12.1.11': 'ВК', '12.1.12': 'ОВ1', '12.1.13': 'ОВ2', '12.1.14': 'ЭОМ', '12.1.15': 'СС'}   # код 12 (РВР) — те же разделы
def sec_of(code):
    p = code.split('.'); return SEC.get('.'.join(p[:4])) or SEC_RVR.get('.'.join(p[:3]), '.'.join(p[:3]))
def norm(s):
    s = (s or '').lower().replace('ё', 'е').replace('x', 'х').replace('*', 'х').replace('×', 'х').replace(' ', ' ')
    s = re.sub(r'\s+', ' ', s).strip()
    return s
def head(s):
    s = norm(s); s = re.sub(r'[^a-zа-я0-9 ]', ' ', s); w = s.split()
    return w[0] if w else ''
# «работа-шаблон»: код с замаскированной веткой системы
OV1_MAP = {'7.1': '1', '7.2': '2', '7.3': '3', '7.4': '4', '8.1': '1.1', '8.2': '3.2', '8.3': '3.3', '8.4': '3.4', '8.5': '4.4', '8.6': '2.2'}
def template(code):
    p = code.split('.')
    if len(p) < 6: return code
    sec = '.'.join(p[:4]); rest = p[4:]
    if sec == '6.2.3.1':                       # ВК: 6.2.3.1.S.группа.работа.вариант
        return '6.2.3.1.*.' + '.'.join(rest[1:])
    if sec == '6.2.3.2':                       # ОВ1: ветки 7 (теплоснабжение ПУ) и 8 (узлы управления) → основные
        key2 = '.'.join(rest[:2])
        if key2 in OV1_MAP: return '6.2.3.2.' + OV1_MAP[key2] + ('.' + '.'.join(rest[2:]) if rest[2:] else '')
        return code
    if sec == '6.2.3.3':                       # ОВ2: 1 общеобменная / 2 противодымная
        return '6.2.3.3.*.' + '.'.join(rest[1:])
    if sec == '6.2.3.4':                       # ЭОМ: 1 нежилая / 2 квартиры / 4 ЦИН
        return '6.2.3.4.*.' + '.'.join(rest[1:])
    if sec == '6.2.3.5':                       # СС: подсистема
        return '6.2.3.5.*.' + '.'.join(rest[1:])
    return code
