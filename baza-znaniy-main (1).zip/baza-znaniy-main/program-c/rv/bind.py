# -*- coding: utf-8 -*-
"""Агент РВ: привязка строк ЛРВ из 1С к работам ИСР и расчёт объёмов — прототип v0.5 (31.10.2026).
usage: python3 -I bind.py <kb_dir> <лрв.json> <рв.json>
Вход: {"section": "ВК", "object_type": "жилой|паркинг|СКБ", "items": [{"id": ..., "name": ..., "unit": ..., "qty": ..., "system": "К1|В2|ОВ|ПДВ|отопление|2.2|..."}, ...]}
Выход: {"rv": {"works": [...], "unbound": [...]}, "bindings": [...], "volumes": {...}, "distribution": [...]} — ТЗ v2.0 §3.
Порядок (ТЗ 4.2; правило выше практики, п. 0.4): (1) правила ведущих (ОВ2 форма/толщина/фасонная; ЭОМ Σ сечений; СС марка; ВК/ОВ1 материал трубы и фасонной);
(2) конвенции РВ (Кр — п. 0.7; металлопрокат → опорные конструкции, п. 0.6; окраска; фланцевое соединение; резьба; гильзы; шнур; классы с одной работой-потребителем);
(3) эталонная библиотека (library_clean.json) с жёстким фильтром по системе; (4) класс → семья; (5) вариант по признаку, граничный Ø — в старший диапазон [В 31.10];
(6) карта кодов по индексу (codemap.json); (7) замена закрытых работ; (8) роль по ведущим группам индекса [КЦ]; флаги F-*.
volumes(): объём = Σ количество / k ведущих групп работы (индекс КЦ v2), пересчёт единиц, масса проката по сортаменту, площадь воздуховодов по геометрии,
метраж парной работы для «расходных материалов», объём ведут основные изделия [К]. distribute(): Кр — по потребителям системы пропорционально объём × норма.
Пути — переменные окружения KC_INDEX, BIND_HOME (по умолчанию /home/claude/tool14_idx/index.json и /home/claude/bind)."""
import sys, os, re, json, pickle, collections, statistics
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from rv_common import *  # common.py комплекта переименован: на сайте есть свой пакет common

KB = None
def load(kb_dir):
    """Данные агента из <kb_dir>: library_clean.json, codemap.json и либо kb.pkl (pandas, полная база), либо kb_light.json (переносимо, без pandas).
    Справочник КЦ: переменная KC_INDEX, иначе <kb_dir>/kc_index_compact.json, иначе /home/claude/tool14_idx/index.json."""
    global KB
    idx_path = os.environ.get('KC_INDEX') or next((p_ for p_ in (os.path.join(kb_dir, 'kc_index_compact.json'), os.path.join(kb_dir, 'index.json'), '/home/claude/tool14_idx/index.json') if os.path.exists(p_)), None)
    idx = json.load(open(idx_path, encoding='utf-8'))
    works = {w[0]: w[1] for sec in ('vk', 'ot', 'vent', 'eom', 'ss', 'itp') for w in idx[f'{sec}_works']}
    lib = collections.defaultdict(list)
    headfam = collections.defaultdict(list); famcodes = collections.defaultdict(list); norms = {}
    clean_path = os.path.join(kb_dir, 'library_clean.json'); pkl = os.path.join(kb_dir, 'kb.pkl')
    if os.path.exists(pkl):
        pairs, names, wp, fams, hf = pickle.load(open(pkl, 'rb'))
        if not os.path.exists(clean_path):
            for r in pairs.itertuples(index=False):
                lib[(r.sec, r.mn)].append(dict(code=r.code, work=r.work, fam=r.fam, sys=r.sys, files=int(r.files), share=float(r.share), ratio=None if r.ratio_med != r.ratio_med else float(r.ratio_med)))
        for r in hf.itertuples(index=False): headfam[(r.sec, r.head)].append((r.fam, int(r.files), float(r.share)))
        for r in fams.itertuples(index=False): famcodes[(r.sec, r.fam)].append((r.code, r.sys, r.var, int(r.files)))
        for r in wp.itertuples(index=False):
            if r.ratio_med == r.ratio_med and int(r.ratio_n) >= 10: norms[(r.code, r.head)] = float(r.ratio_med)   # медиана расхода класса на единицу работы (веса Кр)
    else:
        lt = json.load(open(os.path.join(kb_dir, 'kb_light.json'), encoding='utf-8'))
        for k, v in lt['headfam'].items(): headfam[tuple(k.split('|', 1))] = [tuple(x) for x in v]
        for k, v in lt['famcodes'].items(): famcodes[tuple(k.split('|', 1))] = [tuple(x) for x in v]
        norms = {tuple(k.split('|', 1)): v for k, v in lt['norms'].items()}
    if os.path.exists(clean_path):
        # эталонная библиотека (только связки, прошедшие критерии build_clean.py) — данные для агента
        for sec, d in json.load(open(clean_path, encoding='utf-8')).items():
            for mn, r in d.items(): lib[(sec, mn)].append(dict(code=r['code'], work=r['work'], fam=r['fam'], sys=r['sys'], files=r['files'], share=r['share'], ratio=r.get('ratio')))
    cm_path = os.path.join(kb_dir, 'codemap.json')
    if os.path.exists(cm_path):
        # карта кодов по индексу: добавляем действующие коды, которых в выборке не было (files = 0), чтобы агент мог их выбрать
        cm = json.load(open(cm_path, encoding='utf-8'))['codemap']
        for sec, fam_d in cm.items():
            for fam, br_d in fam_d.items():
                key = (sec, fam[:70]); have = {c[0] for c in famcodes.get(key, [])}
                for br, var_d in br_d.items():
                    for var, code in var_d.items():
                        if code not in have and code in works: famcodes[key].append((code, br.split('.')[0], var[:60], 0))
    fams_by_sec = collections.defaultdict(list)
    for (sec_, fam_) in famcodes: fams_by_sec[sec_].append(fam_)
    # группы КЦ по работам (для объёма [КЦ] и ролей): код → (единица работы, [группы])
    gw = {}; byguid = {}
    for sec in ('vk', 'ot', 'vent', 'eom', 'ss', 'itp'):
        for w in idx[f'{sec}_works']: gw[w[0]] = dict(unit=nunit(w[9] if len(w) > 9 else ''), groups={}); byguid[w[2]] = w[0]
        for m_ in idx[f'{sec}_mats']:
            c = byguid.get(m_[1])
            if not c: continue
            g = gw[c]['groups'].setdefault(m_[3], dict(name=m_[3], toks=toks(m_[3]), main=False, unit=nunit(m_[7]), rows=[]))
            g['main'] = g['main'] or bool(m_[9]); g['rows'].append((toks(m_[5]), float(m_[8] or 1.0), nunit(m_[7]), bool(m_[9])))
    fl_path = os.path.join(kb_dir, 'fitting_lengths.json')
    fittings = json.load(open(fl_path, encoding='utf-8'))['families'] if os.path.exists(fl_path) else []
    KB = dict(lib=lib, headfam=headfam, famcodes=famcodes, works=works, fams_by_sec=fams_by_sec, norms=norms, kc=gw, fittings=fittings)
    FIT_FAMILY.clear()
    return KB

# --- Код 12 (РВР — работы, не предусмотренные основным проектом) --------------------------------------------------------------
# Заказ-наряд бывает ДР (работы кода 6) или РВР (работы кода 12). В КЦ монтажные работы 12.1.11–12.1.15 повторяют работы
# 6.2.3.1–6.2.3.5 по названию и группам материалов (kc_rvr.json, rv_kc_import.py --rvr). Поэтому для РВР агент подбирает
# работу по тем же правилам кода 6 и ставит её пару из кода 12 (to_rvr); пары нет — строка без работы, выбирает сметчик.
RVR = False                 # эта РВ собирается в коде 12 (ставит web_rv_run по выбору на сайте)
RVR_ROOT = {'ВК': '12.1.11', 'ОВ1': '12.1.12', 'ОВ2': '12.1.13', 'ЭОМ': '12.1.14', 'СС': '12.1.15'}
def load_rvr(kb_dir):
    """Работы кода 12 — в знания агента (после load): названия в KB['works'], группы материалов в KB['kc'] (у работы с парой в
    6.2.3 — те же, что у пары; без пары — свои из файла), пары «код 6 → (код 12, точно ли)» в KB['rvr']. Повторный вызов ничего не делает."""
    if KB.get('rvr') is not None: return KB['rvr']
    path = os.path.join(kb_dir, 'kc_rvr.json')
    if not os.path.exists(path):
        KB['rvr'] = {}; return KB['rvr']
    with open(path, encoding='utf-8') as fh: data = json.load(fh)
    for code, (name, guid, unit, pair) in data['works'].items():
        KB['works'][code] = name
        KB['kc'][code] = KB['kc'][pair] if pair in KB['kc'] else dict(unit=nunit(unit), groups={})
    for code, group, material, unit, coef, main in data['mats']:
        g = KB['kc'][code]['groups'].setdefault(group, dict(name=group, toks=toks(group), main=False, unit=nunit(unit), rows=[]))
        g['main'] = g['main'] or bool(main); g['rows'].append((toks(material), float(coef or 1.0), nunit(unit), bool(main)))
    KB['rvr'] = {c6: (pair[0], bool(pair[1])) for c6, pair in data['pairs'].items() if pair[0] in KB['works']}
    for (code, h), v in list(KB['norms'].items()):          # нормы крепежа на единицу работы — те же, что у пары
        if code in KB['rvr']: KB['norms'].setdefault((KB['rvr'][code][0], h), v)
    return KB['rvr']
def rvr_code(code):
    """Код 12 для работы: код 12 — как есть; код 6.2.3 — его пара; пары нет — None."""
    if not code: return None
    if code.startswith('12.'): return code if code in KB['works'] else None
    pair = (KB.get('rvr') or {}).get(code)
    return pair[0] if pair else None
def to_rvr(sec, results):
    """Привязки, подобранные по правилам кода 6, — в код 12: работа → её пара (то же название в разделе кода 12), потребители
    крепежа и варианты «или» — тоже. Пара выбрана не наверняка (в коде 12 работа есть только в других подсистемах) — на проверку;
    пары нет — строка остаётся без работы с флагом F-RVR и названием работы кода 6: сметчик выбирает работу кода 12 сам."""
    pairs = KB.get('rvr') or {}
    for r in results:
        if r.get('consumers'): r['consumers'] = sorted({pairs[c][0] for c in r['consumers'] if c in pairs})
        if r.get('alts'):
            alts = []
            for a in r['alts']:
                c12 = rvr_code(a.get('code'))
                if c12 and c12 not in [x['code'] for x in alts]: alts.append(dict(a, code=c12, work=KB['works'][c12][:100]))
            r['alts'] = alts
        code = r.get('code')
        if not code or code.startswith('12.'): continue
        r['code6'] = code; pair = pairs.get(code)
        flags = list(r.get('flags') or [])
        if pair:
            r['code'] = pair[0]; r['work'] = KB['works'][pair[0]][:100]
            if not pair[1]:
                flags.append('F-RVR: в коде 12 (РВР) такая работа есть только в других подсистемах — взята ближайшая, проверить'); r['review'] = True
        elif r.get('role') == 'Кр' and r.get('consumers'):
            r['code'] = r['consumers'][0]; r['work'] = KB['works'][r['code']][:100]
        else:
            flags.append(f'F-RVR: в коде 12 (РВР) нет работы «{KB["works"].get(code, "")[:70]}» ({code}) — выберите работу кода 12')
            r['code'] = None; r['work'] = None; r['family'] = None; r['review'] = True; r['confidence'] = 0
        r['flags'] = flags; r['fcodes'] = sorted({f.split(':')[0] for f in flags if f.startswith('F-')})
    return results

UNITS = {'погм': 'м', 'пм': 'м', 'мп': 'м', 'м': 'м', 'метр': 'м', 'м2': 'м2', 'м²': 'м2', 'квм': 'м2', 'шт': 'шт', 'штук': 'шт', 'компл': 'шт', 'комплект': 'шт', 'кт': 'шт', 'к-т': 'шт',
         'пара': 'шт', 'упак': 'упак', 'уп': 'упак', 'т': 'т', 'тн': 'т', 'кг': 'кг', 'л': 'л', 'м3': 'м3', 'комплекс': 'комплекс'}
def nunit(u):
    u = norm(u or '').replace(' ', '').replace('.', '')
    return UNITS.get(u, u)
STOP = {'для', 'из', 'с', 'и', 'на', 'по', 'в', 'под', 'до', 'от', 'мм', 'шт', 'гост', 'ту', 'тип', 'или', 'со', 'без', 'при', 'не', 'а', 'к'}
SYN = [(r'pp-?r(?:ct|gf)?|ppr|ppрс|pp-?h|(?<![а-я])пп(?![а-я])', ' полипропиленовая '), (r'pe-?[xх]a?|pex|пекс|сшит', ' сшитого полиэтилена '),
       (r'нпвх|(?<![а-я])пвх|pvc(?:-u)?', ' поливинилхлоридная '), (r'(?<![a-z])sml(?![a-z])|безраструб', ' чугунная безраструбная '),
       (r'пнд|пэ\s?100|pe\s?100|(?<![а-я])пэ(?![а-я])', ' полиэтиленовая '), (r'вгп|водогазопр', ' водогазопроводная '), (r'грувлок|grooved|victaulic|dinarm', ' грувлок ')]
ENDS = re.compile(r'(ого|его|ому|ему|ыми|ими|ая|яя|ое|ее|ый|ий|ой|ые|ие|ых|их|ую|юю|ов|ев|ам|ям|ах|ях|ом|ем|а|я|о|е|ы|и|у|ю|ь)$')
def stem(w):
    if not w.isalpha() or not re.match(r'[а-я]', w): return w
    if len(w) < 4: return w
    r = ENDS.sub('', w)
    return (r if len(r) >= 3 else w)[:5]
def toks(s):
    n = norm(s)
    for pat, rep in SYN: n = re.sub(pat, rep, n)
    out = set()
    for w in re.findall(r'[a-zа-я]+|\d+', n):
        if w in STOP or (w.isalpha() and len(w) < 3): continue
        out.add(stem(w))
    return out
def hstem(s):
    h = stem(head(s))
    return 'труб' if h in ('труб', 'трубо') else h
def match_group(code, name, unit=None):
    """Группа КЦ выбранной работы, к которой относится строка ЛРВ: первое слово группы = класс строки (по основе), далее — по пересечению слов.
    Возвращает (группа, k, единица группы, ведущая) или None. «(для гильз)» ищет группу гильз."""
    w = KB['kc'].get(code)
    if not w or not w['groups']: return None
    t = toks(name); h = hstem(name); mn = norm(name)
    gl = list(w['groups'].values()); heads = collections.Counter(hstem(g['name']) for g in gl)
    best = None
    for g in gl:
        gh = hstem(g['name'])
        if 'для гильз' in mn or h == 'гильз': ok = 2 if gh == 'гильз' else 0
        elif gh == h: ok = 2
        elif gh in t: ok = 1                                         # первое слово группы стоит в имени не первым («Пожарный шкаф ШПК»)
        else: ok = 0
        if not ok: continue
        sc = len(t & g['toks'])
        weak = heads[gh] > 1 and sc < min(2, len(g['toks']))       # несколько групп одного класса — нужен ещё признак (материал), «Труба стальная» ≠ «Труба поливинилхлоридная»
        if weak:
            same = {(g2['main'], g2['unit'], round(statistics.median([r_[1] for r_ in g2['rows']]), 3)) for g2 in gl if hstem(g2['name']) == gh}
            if len(same) > 1: continue                               # группы класса различаются по объёму — без признака не выбрать
        r = max(g['rows'], key=lambda r_: len(t & r_[0]))
        key = (not weak, ok, sc, (nunit(unit) == g['unit']) if unit else False, len(t & r[0]), g['main'])   # слабое совпадение допустимо, если группы класса равнозначны для объёма («Кабель силовой» / «Кабель контрольный»)
        if best is None or key > best[0]: best = (key, g, r)
    if not best: return None
    _, g, r = best
    return g, (r[1] if r[1] > 0 else 1.0), r[2], r[3]

ACCESSORY = {'кронш', 'держа', 'заглу', 'перех', 'масти', 'покры', 'кожух', 'крышк', 'наклей', 'накле', 'пломб', 'хомут', 'муфт', 'тройн', 'скоба', 'клипс', 'дюбел'}
SUPPORT_RE = re.compile(r'^монтаж опорных конструкций для крепления трубопроводов|^монтаж металлической рамы для воздуховодов', re.I)
METAL_RE = re.compile(r'^(уголок|швеллер|двутавр|полоса|пластина|лист|пруток|арматура|профиль|металлоконструкц|металлопрокат|труба профильная|закладн|сталь листовая|балка)', re.I)
CHANNEL = {5: 4.84, 6.5: 5.9, 8: 7.05, 10: 8.59, 12: 10.4, 14: 12.3, 16: 14.2, 18: 16.3, 20: 18.4, 22: 21.0, 24: 24.0, 27: 27.7, 30: 31.8}   # швеллер ГОСТ 8240, кг/м
def steel_mass(name, u):
    """Масса металлопроката (кг) на единицу строки ЛРВ по сортаменту: уголок a×b×t — (a+b−t)·t·7,85e-3 кг/м; швеллер — таблица ГОСТ 8240;
    полоса a×t — a·t·7,85e-3 кг/м; пластина/лист t×a×b (шт) — t·a·b·7,85e-6 кг; лист t (м²) — 7,85·t; арматура/пруток ⌀d — π·d²/4·7,85e-3 кг/м. None — не определить."""
    n = norm(name).replace(',', '.'); h = head(name)
    nums = [float(x) for x in re.findall(r'(\d+(?:\.\d+)?)\s*(?=[хx]|мм|$|\s)', n)]
    m = re.search(r'(\d+(?:\.\d+)?)\s*[хx]\s*(\d+(?:\.\d+)?)\s*[хx]\s*(\d+(?:\.\d+)?)', n)
    if h == 'уголок' and m and u == 'м':
        a, b, t = map(float, m.groups()); return (a + b - t) * t * 7.85e-3
    if h == 'швеллер' and u == 'м':
        c = re.search(r'(?:швеллер|№)\s*(\d+(?:\.\d)?)\s*[пу]?', n)
        if c and float(c.group(1)) in CHANNEL: return CHANNEL[float(c.group(1))]
    if h in ('полоса',) and u == 'м':
        p2 = re.search(r'(\d+(?:\.\d+)?)\s*[хx]\s*(\d+(?:\.\d+)?)', n)
        if p2: a, t = map(float, p2.groups()); return a * t * 7.85e-3
    if h in ('пластина', 'лист') and u == 'шт':
        if m:
            a, b, c3 = sorted(map(float, m.groups())); return a * b * c3 * 7.85e-6
        t = re.search(r'толщин[а-я]*\s*(\d+(?:\.\d+)?)', n); p2 = re.search(r'(\d{2,4})\s*[хx]\s*(\d{2,4})', n)
        if t and p2: return float(t.group(1)) * float(p2.group(1)) * float(p2.group(2)) * 7.85e-6
    if h == 'лист' and u == 'м2':
        t = re.search(r'(?:толщин[а-я]*|s|t|δ)\s*=?\s*(\d+(?:\.\d+)?)', n)
        if t: return 7.85 * float(t.group(1))
    if h in ('арматура', 'пруток', 'круг') and u == 'м':
        d = re.search(r'(?:ø|⌀|d|ф|диаметр)\s*(\d{1,2})', n) or re.search(r'а\d{1,3}[сc]?\s+(\d{1,2})', n)
        if d: dd = float(d.group(1)); return 3.14159 * dd * dd / 4 * 7.85e-3
    return None
import math
def duct_area(name):
    """ОВ2: площадь поверхности изделия (м² на 1 шт) по геометрии из имени ЛРВ. Прямые воздуховоды и врезки — периметр × L (точно);
    фасонные — приближённо: переход (P1+P2)/2·L; тройник/крестовина (P_вх+P_вых)/2·L + P_отв·0,2 на ответвление; отвод/утка — P × длина оси
    (отвод: π·φ/180·(W+0,1)); заглушка — площадь сечения; ниппель/муфта — π·D·0,1. None — размеров нет."""
    n = re.sub(r'\((\d{2,4})\)', r'\1', norm(name).replace(',', '.')); h = head(name)   # «(160)-(125)х(125)» → размеры без скобок
    dims = []   # периметры сечений по порядку
    for mm in re.finditer(r'(\d{2,4})\s*х\s*(\d{2,4})(?!\s*х\s*\d{2,4}\s*мм\.)|[øф⌀]\s*(\d{2,4})|(?<![\dх])d\s?(\d{2,4})', n):
        if mm.group(1): a, b = float(mm.group(1)) / 1000, float(mm.group(2)) / 1000; dims.append((2 * (a + b), a * b, max(a, b)))
        else:
            d = float(mm.group(3) or mm.group(4)) / 1000; dims.append((math.pi * d, math.pi * d * d / 4, d))
    if not dims: return None
    Lm = re.search(r'l\s*=?\s*(\d{2,5})', n); L = float(Lm.group(1)) / 1000 if Lm else None
    P = dims[0][0]
    if h in ('воздуховод', 'врезка', 'утка', 'патрубок', 'вставка') and L: return P * L
    if h in ('переход', 'переходник') and L: return (dims[0][0] + (dims[1][0] if len(dims) > 1 else dims[0][0])) / 2 * L
    if h in ('тройник', 'крестовина', 'штаны') and L:
        main = (dims[0][0] + dims[-1][0]) / 2 * L if len(dims) > 1 else P * L
        br = dims[1:-1] if len(dims) > 2 else []
        return main + sum(x[0] * 0.2 for x in br)
    if h in ('отвод', 'колено'):
        ang = re.search(r'(\d{2,3})\s*(?:°|гр|град)', n); phi = float(ang.group(1)) if ang else 90.0
        return P * (math.pi * phi / 180 * (dims[0][2] + 0.1))
    if h == 'заглушка': return dims[0][1]
    if h in ('ниппель', 'муфта'): return P * 0.1
    return None
def conv_qty(q, u_from, u_to, name):
    """Пересчёт количества строки ЛРВ в единицу группы КЦ: кг ↔ т; шт с длиной L в имени → м (лотки, короба, профили)."""
    if u_from == u_to or not u_from: return q
    if u_from == 'кг' and u_to == 'т': return q / 1000
    if u_from == 'т' and u_to == 'кг': return q * 1000
    if u_from == 'шт' and u_to == 'м':
        L = re.search(r'(?:l|дл[а-я]*)\s*[=:]?\s*(\d{3,4})\s*(?:мм)?', norm(name)) or re.search(r'(?<![\dх])(\d{4})\s*мм', norm(name))
        if L: return q * int(L.group(1)) / 1000
    if u_from == 'шт' and u_to == 'м2':
        a = duct_area(name)
        if a: return q * a
    return None
VGP_OUTER = {15: 21.3, 20: 26.8, 25: 33.5, 32: 42.3, 40: 48.0, 50: 60.0, 65: 75.5, 80: 88.5, 90: 101.3, 100: 114.0, 125: 140.0, 150: 165.0}   # ГОСТ 3262, мм
EW_OUTER = {15: 21.3, 20: 26.8, 25: 33.5, 32: 42.3, 40: 48.0, 50: 57.0, 65: 76.0, 80: 89.0, 100: 108.0, 125: 133.0, 150: 159.0, 200: 219.0, 250: 273.0, 300: 325.0}   # электросварные, мм
def pipe_outer_mm(name):
    """Наружный диаметр стальной трубы (мм) из имени ЛРВ: «57х3,5», «Ø57», «Дн 57» — как есть; «Ду50» и ВГП «25х3,2» (ГОСТ 3262 назван по Ду) — по таблице."""
    n = norm(name).replace(',', '.'); vgp = bool(re.search(r'водогаз|вгп|3262', n))
    m = re.search(r'(?:ду|dn)\s*-?\s*(\d{2,3})(?!\d)', n)
    if m:
        dn = int(m.group(1)); return (VGP_OUTER if vgp else EW_OUTER).get(dn)
    m = re.search(r'(?:ø|⌀|дн|ф|d)\s*(\d{2,3}(?:\.\d)?)(?!\d)', n) or re.search(r'(?<![\dх.])(\d{2,3}(?:\.\d)?)\s*х\s*\d{1,2}(?:\.\d+)?(?![\dх])', n)
    if m:
        v = float(m.group(1))
        if vgp and int(v) in VGP_OUTER and not re.search(r'(?:ø|⌀|дн)\s*' + m.group(1), n): return VGP_OUTER[int(v)]
        return v if 10 <= v <= 530 else None
    return None
PAINT_WORK = re.compile(r'^Антикоррозийная окраска трубопроводов')
STEEL_PIPE_WORK = re.compile(r'^Прокладка трубопроводов из стальных')
def paint_key(sec, it, code):
    """Группа «окраска ↔ трубы»: система строки ЛРВ; без системы — ветка кода (ОВ1: ветки 1–6 — одна система «отопление»)."""
    if it.get('system'): return sys_code(sec, it['system']) or norm(it['system'])
    b = code.split('.')[4] if len(code.split('.')) > 4 else ''
    return 'отоп' if sec == 'ОВ1' and b in ('1', '2', '3', '4', '5', '6') else b
def paint_area(sec, items, bindings, key):
    """[В 31.10] Объём окраски трубопроводов = площадь окрашиваемых труб: Σ π·Dнар·L по стальным трубам системы без заводского покрытия
    (не оцинкованные, не ЦПП/ЦПИ, не нержавеющие; гильзы «(для гильз)» не считаются). Чёрных труб нет — все стальные трубы системы (с замечанием)."""
    black, allst, nodia = 0.0, 0.0, []
    for it, b in zip(items, bindings):
        c = b.get('code')
        if not c or b.get('role') == 'Кр' or not STEEL_PIPE_WORK.search(KB['works'].get(c, '')) or paint_key(sec, it, c) != key: continue
        h = head(it['name']); mn = norm(it['name'])
        if h not in ('труба', 'трубопровод') or 'для гильз' in mn: continue
        q = fnum(it.get('qty')); u = nunit(it.get('unit'))
        if q is None: continue
        if u != 'м':
            q = conv_qty(q, u, 'м', it['name'])
            if q is None: continue
        d = pipe_outer_mm(it['name'])
        if not d: nodia.append(it['name'][:40]); continue
        a = 3.14159265 * d / 1000 * q
        allst += a
        if not re.search(r'оцинк|цпп|цпи|нерж|полимерн|с покрыт', mn): black += a
    if black: return round(black, 3), 'площадь окрашиваемых труб: Σ π·Dнар·L чёрных стальных труб системы [В 31.10]', nodia
    if allst: return round(allst, 3), 'площадь окрашиваемых труб: чёрных труб нет — Σ π·Dнар·L всех стальных труб системы, проверить [В 31.10]', nodia
    return None, '', nodia
# --- [В 11.11] Длина фасонных частей в объёме прокладки трубопроводов -----------------------------------------------------------------
# Работа «Прокладка трубопроводов …» в метрах: объём = метраж труб + длина по оси фасонных частей (отводы, тройники, крестовины,
# переходы, ревизии) — по каталогу производителя (rv/data/fitting_lengths.json; сейчас — HALIFAX для чугунных безраструбных).
# Хомуты, муфты, заглушки длины не добавляют. В 1С объём складывается Σ количество × коэффициент, поэтому коэффициент фасонной
# части — её длина в метрах (web_rv_run.row_coefs).
FIT_FAMILY = {}
FIT_METHOD = 'длина фасонных частей по каталогу'
FIT_HEAD = re.compile(r'^(отвод|колено|тройник|крестовин|переход|переходник|ревизи|поддерживающ\w*\s+труб)')
FIT_KIND = {'отвод': 'отвод', 'колено': 'отвод', 'тройник': 'тройник', 'крестовин': 'крестовина', 'переход': 'переход',
            'переходник': 'переход', 'ревизи': 'ревизия'}
FIT_DN = (50, 70, 100, 125, 150, 200, 250, 300)
def fit_family(code):
    """Семья каталога фасонных частей для работы (по имени работы, в метрах) или None."""
    if code not in FIT_FAMILY:
        name = KB.get('works', {}).get(code, ''); unit = KB.get('kc', {}).get(code, {}).get('unit')
        FIT_FAMILY[code] = next((f for f in KB.get('fittings', []) if unit == 'м' and re.search(f['work'], norm(name))), None)
    return FIT_FAMILY[code]
def _fit_dns(mn, od):
    """Условные проходы из имени фасонной части: «DN100x50», «Ду 100/50», «100х100х100», «d110» (наружный → DN по таблице семьи).
    Числа с градусами («88°», «45 гр.») и длины («L=3000») не в счёт."""
    s = re.sub(r'\d+(?:[.,]\d+)?\s*(?:°|º|гр\w*\b|град\w*)', ' ', mn)
    s = re.sub(r'\b[lд]\s*=\s*\d+', ' ', s)
    out = []
    for m in re.finditer(r'(?<![\d.,])(\d{2,3})(?![\d.,]?\d)', s):
        v = int(m.group(1))
        v = od.get(str(v), v) if v not in FIT_DN else v
        if v in FIT_DN: out.append(v)
    return out
def _fit_angle(mn):
    m = re.search(r'(\d{1,2}(?:[.,]\d)?)\s*(?:°|º|гр\w*\b|град)', mn) or re.search(r'/\s*(\d{2})(?![\d.,])\s*(?:$|[^\dхx])', mn)
    if not m: return None
    a = float(m.group(1).replace(',', '.'))
    return min((88, 69, 45, 30, 15), key=lambda t: abs(t - (88 if a >= 85 else a)))
def fitting_length(code, name, unit=None):
    """Длина фасонной части по оси, м: (длина, пояснение, приближённо ли) — если работа из семьи каталога (fit_family) и строка —
    отвод, тройник, крестовина, переход, ревизия или поддерживающая труба в шт; иначе None. Размера нет в каталоге — ближайший
    типоразмер того же вида (приближённо); угол не указан — 88° (приближённо)."""
    fam = fit_family(code)
    if not fam or (unit is not None and nunit(unit) not in ('шт', '')): return None
    mn = norm(name); mh = FIT_HEAD.match(mn)
    if not mh or re.search(r'заглуш|хомут|муфт|зажим|скоб', mn): return None
    kind = 'поддерживающая труба' if mh.group(1).startswith('поддерж') else FIT_KIND[mh.group(1)]
    dns = _fit_dns(mn, fam.get('od_to_dn', {}))
    if not dns: return None
    angle = _fit_angle(mn); approx = []
    types = [t for t in fam['types'] if t['key'].startswith(kind)]
    special = [t for t in types if t['match'] and re.search(t['match'], mn) and (t['angle'] is None or angle is None or t['angle'] == angle)]
    if special: t = special[0]
    else:
        plain = [t for t in types if not t['match']]
        t = next((x for x in plain if angle is not None and x['angle'] == angle), None)
        if t is None:
            t = next((x for x in plain if x['default']), plain[0] if plain else None)
            if t is None: return None
            if t['angle'] is not None and angle is None: approx.append(f'угол не указан — {t["angle"]}°')
            elif t['angle'] is not None: approx.append(f'угла {angle}° у вида нет — {t["angle"]}°')
    two = any('x' in k for k in t['rows'])
    if two:
        main, branch = dns[0], (dns[1] if len(dns) > 1 else dns[0])
        key = f'{main}x{branch}'
        if key not in t['rows']:
            near = min(t['rows'], key=lambda k: (abs(int(k.split('x')[0]) - main), abs(int(k.split('x')[1]) - branch)))
            approx.append(f'{key} нет в каталоге — {near}'); key = near
    else:
        key = str(dns[0])
        if key not in t['rows']:
            near = min(t['rows'], key=lambda k: abs(int(k) - dns[0]))
            approx.append(f'DN{key} нет в каталоге — DN{near}'); key = near
    dims = dict(zip(t['dims'], t['rows'][key]))
    mm = sum(int(k_ or 1) * dims[d_] for k_, d_ in re.findall(r'(\d*)([ABC])', t['length']))     # «2A», «A+2C»
    note = f'{t["label"]} {key}: {t["length"]} = {mm:g} мм'
    return round(mm / 1000.0, 4), note, bool(approx), approx
def volume_of(code, rows):
    """[КЦ] Объём работы = Σ количество / k по строкам, попавшим в ведущие группы работы (поле «ведущий» индекса), в единице работы.
    Опорные конструкции (ВК 99.1.1, ОВ1 99.2.1, рама ОВ2) — масса металлопроката [В 31.10]. rows: [(имя, ед., кол-во)].
    Возвращает (объём или None, способ, [замечания])."""
    w = KB['kc'].get(code); notes = []
    if not w: return None, 'работы нет в индексе', notes
    wu = w['unit']; wname = KB['works'].get(code, '')
    if SUPPORT_RE.search(wname):
        tot = 0.0; n = 0; how = 'масса металлопроката [В 31.10]'
        for name, u, q in rows:
            if not METAL_RE.search(norm(name)): continue
            u_ = nunit(u); v = conv_qty(q, u_, wu, name)
            if v is None and u_ in ('м', 'шт', 'м2'):
                km = steel_mass(name, u_)
                if km: v = conv_qty(q * km, 'кг', wu, name); how = 'масса металлопроката [В 31.10], часть — по сортаменту'
            if v is None: notes.append(f'металлопрокат «{name[:40]}» в «{u}» — масса не определяется, нужна масса'); continue
            tot += v; n += 1
        return (round(tot, 4) if n else None), how, notes
    if re.match(r'Прокладка воздуховодов', wname) and wu == 'м2':
        # ОВ2: ЛРВ даёт изделия в шт — площадь по геометрии из имени (прямые и врезки — точно, фасонные — приближённо); строки в м² — как есть
        tot = 0.0; n = 0; approx = False
        for name, u, q in rows:
            if head(name) not in DUCT_HEADS: continue
            u_ = nunit(u)
            if u_ == 'м2': tot += q; n += 1; continue
            if u_ == 'шт':
                a = duct_area(name)
                if a: tot += q * a; n += 1; approx = approx or head(name) not in ('воздуховод', 'врезка'); continue
            notes.append(f'«{name[:40]}»: площадь не определяется по имени')
        if n: return round(tot, 4), DUCT_AREA_METHOD + (' (фасонные — приближённо, WARN)' if approx else ''), notes
    contrib = collections.defaultdict(float); n = 0; rate = collections.defaultdict(float)
    fit_m = 0.0; fit_n = 0; fit_approx = 0
    for name, u, q in rows:
        fl = fitting_length(code, name, u) if q else None
        if fl:                                                         # [В 11.11] фасонная часть — её длина по оси
            fit_m += q * fl[0]; fit_n += 1; fit_approx += fl[2]
            if fl[2]: notes.append(f'«{name[:40]}»: {"; ".join(fl[3])} (приближённо)')
            continue
        mg = match_group(code, name, u)
        if mg and not mg[3] and mg[1] != 1.0 and mg[2] != wu:          # неведущая группа с нормой расхода (грунтовка 0,15 кг/м²) — запасной путь
            v0 = conv_qty(q, nunit(u), mg[2], name)
            if v0 is not None: rate[hstem(mg[0]['name'])] += v0 / mg[1]
        if not mg or not mg[3]: continue
        g, k, gu, _ = mg; u_ = nunit(u); cls = hstem(g['name'])
        v = conv_qty(q, u_, gu, name)
        if v is not None and (gu == wu or k != 1.0 or (gu == 'шт' and wu == 'шт')): contrib[cls] += v / k; n += 1; continue
        if u_ == wu: contrib[cls] += q; n += 1; continue              # группа КЦ в другой единице (труба PP-H — шт), строка ЛРВ уже в единице работы
        v2 = conv_qty(q, u_, wu, name)
        if v2 is not None: contrib[cls] += v2; n += 1; continue
        notes.append(f'«{name[:40]}»: «{u}» → «{gu}»/«{wu}» не пересчитывается')
    # [К] объём ведут основные изделия: если ведущих классов несколько — принадлежности (держатель, заглушка, переход, мастика, кожух…) объём не ведут;
    # затем, если класс назван в имени работы, — только он («Монтаж пожарных шкафов» — шкаф)
    if len(contrib) > 1:
        keep = {c: v for c, v in contrib.items() if c not in ACCESSORY} or contrib
        wt = toks(wname)
        named = {c: v for c, v in keep.items() if c in wt}
        contrib = named or keep
    tot = sum(contrib.values())
    if fit_n:
        fam = fit_family(code)
        how = ('Σ количество / k ведущих групп [КЦ]' if n else 'фасонные части') + \
              f' + {FIT_METHOD} ({fam["catalog"].split(" — ")[0] if fam else "каталог"}): {fit_m:.3f} м, строк {fit_n}' + \
              (f', приближённо {fit_approx}' if fit_approx else '') + ' [В 11.11]'
        return round(tot + fit_m, 4), how, notes
    if not n and rate:
        cls, v = max(rate.items(), key=lambda kv: kv[1])
        return round(v, 4), f'F-VOL: ведущих строк нет — по норме неведущей группы «{cls}» (количество / k)', notes
    return (round(tot, 4) if n else None), 'Σ количество / k ведущих групп [КЦ]', notes

SYS = {'ВК': {'к1': '1', 'к1н': '1', 'к1ф': '1', 'к2': '2', 'к2н': '2', 'к3': '3', 'к4': '4', 'к4н': '4', 'в1': '5', 'т3': '5', 'т4': '5', 'хвс': '5', 'гвс': '5', 'в2': '6', 'аупт': '6', 'пк': '6', 'шп': '7', 'прочие': '99'},
       'ОВ2': {'ов': '1', 'общеобменная': '1', 'п': '1', 'в': '1', 'пдв': '2', 'дп': '2', 'дв': '2', 'ду': '2', 'противодымная': '2'},
       'ОВ1': {'отопление': '1', 'т1': '1', 'т2': '1', 'пу': '7', 'теплоснабжение': '7', 'уу': '1', 'узел управления': '1'},   # ветка 8 не используется: узлы управления — в работы веток 1–4
       'ЭОМ': {'нежилая': '1', 'квартиры': '2', 'цин': '4'}, 'СС': {}}
OV1_BRANCHES = {'1': {'1', '2', '3', '4', '5', '6', '9'}, '7': {'7', '6', '9'}, '8': {'8', '9'}}   # ОВ1: «отопление» — ветки 1–6 (трубы; изоляция и окраска; арматура; узлы и учёт; приборы; завесы), ПУ — 7, УУ — 8; 9 (испытания) и 99 — любая
def sys_ok(sec, sysc, branch):
    """Код ветки branch допустим для системы строки: та же ветка, ветка 99 (прочие) или, в ОВ1, ветки 1–6 системы «отопление»."""
    if sysc is None or branch == sysc or branch == '99': return True
    return sec == 'ОВ1' and branch in OV1_BRANCHES.get(sysc, ())
_BY_NAME = {}
def same_in_branch(sec, code, sysc):
    """Код той же работы (то же полное имя) в ветке sysc — у ВК / ОВ2 / ЭОМ / СС ветка системы — 5-й сегмент кода.
    Сначала тот же код с заменённой веткой, иначе поиск по имени в ветке (номера групп в ветках могут не совпадать)."""
    parts = code.split('.')
    if sec not in ('ВК', 'ОВ2', 'ЭОМ', 'СС') or not sysc or sysc == '99' or len(parts) < 6 or parts[4] == sysc: return None
    name = KB['works'].get(code)
    if not name: return None
    c2 = '.'.join(parts[:4] + [sysc] + parts[5:])
    if KB['works'].get(c2) == name: return c2
    if not _BY_NAME:
        for c, n in KB['works'].items(): _BY_NAME.setdefault(n, []).append(c)
    prefix = '.'.join(parts[:4]) + '.' + sysc + '.'
    same = [c for c in _BY_NAME.get(name, []) if c.startswith(prefix)]
    return min(same, key=lambda c: [int(x) for x in c.split('.')]) if same else None
def sys_code(sec, system):
    s = norm(system or '')
    if re.fullmatch(r'\d{1,2}(\.\d{1,2})?', s): return s.split('.')[0]   # код ветки (СС: подветка 2.2/9.1/10.1 → 5-й сегмент; подветка используется при выборе кода)
    for k, v in SYS.get(sec, {}).items():
        if s == k or s.startswith(k + ' ') or s.startswith(k + '.') or re.match(rf'^{re.escape(k)}\d', s): return v
    return None

OUTER = {21: 15, 26: 20, 27: 20, 33: 25, 34: 25, 42: 32, 48: 40, 57: 50, 60: 50, 76: 65, 89: 80, 108: 100, 114: 100, 133: 125, 140: 125, 159: 150, 168: 150, 219: 200, 273: 250, 325: 300}
INCH = {'1/2': 15, '3/4': 20, '1': 25, '1 1/4': 32, '1 1/2': 40, '2': 50, '2 1/2': 65, '3': 80, '4': 100, '5': 125, '6': 150}
def dn_of(name):
    s = norm(name)
    m = re.search(r'(?:ду|dn|dу)\s*[-]?\s*(\d{2,3})(?!\d)', s)
    if m: return int(m.group(1))
    m = re.search(r'(?:ø|⌀|ф|d|дн|dн)\s*(\d{2,3})(?:[.,]\d)?\s*[хx]\s*\d', s)
    if m:
        v = int(m.group(1)); return OUTER.get(v, v if v in (15, 20, 25, 32, 40, 50, 65, 80, 100, 125, 150, 200, 250, 300) else None)
    m = re.search(r'((?:\d\s)?\d(?:/\d)?)\s*"', s)
    if m and m.group(1).strip() in INCH: return INCH[m.group(1).strip()]
    m = re.search(r'(?<![\dх.,])(\d{2,3})\s*[хx]\s*\d{1,2}(?:[.,]\d)?(?![\dх])', s)   # «133х4,5», «57х3,5» без префикса
    if m and int(m.group(1)) in OUTER: return OUTER[int(m.group(1))]
    m = re.search(r'(?:ø|⌀|ф|d)\s*(\d{2,3})(?!\d)', s)
    if m:
        v = int(m.group(1)); return OUTER.get(v, v if v in (15, 20, 25, 32, 40, 50, 65, 80, 100, 125, 150, 200, 250, 300) else None)
    return None

BOUNDARY_NEXT = {133: 131, 219: 201}   # [В 31.10] граничный диаметр, допустимый в двух соседних классах, → следующий (старший) диапазон
def dn_for_variant(name, dn):
    s = norm(name)
    for d, v in BOUNDARY_NEXT.items():
        if re.search(rf'(?<!\d){d}(?!\d)', s): return v
    return dn
def var_range(var):
    v = norm(var)
    m = re.search(r'от\s*(\d+)\s*мм?\s*до\s*(\d+)', v)
    if m: return int(m.group(1)), int(m.group(2))
    m = re.search(r'(\d+)\s*-\s*(\d+)\s*мм', v)
    if m: return int(m.group(1)), int(m.group(2))
    m = re.search(r'до\s*(\d+)\s*мм', v)
    if m: return 0, int(m.group(1))
    m = re.search(r'(?:от|свыше)\s*(\d+)\s*мм', v)
    if m: return int(m.group(1)) + (1 if 'свыше' in v else 0), 9999
    return None

def fam_of(work): return re.split(r'\s*/\s*', work.strip(), maxsplit=1)[0][:70]

# роли РВ (п. 0.2) и конвенции разделов (ВК 1.4, ОВ1 2.4, ОВ2 3.4, ЭОМ 4.4, СС 5.4)
FASTENER = {'анкер', 'анкерный', 'шпилька', 'гайка', 'шайба', 'болт', 'цанга', 'дюбель', 'шуруп', 'саморез', 'гвозди', 'гвоздь', 'винт', 'заклепка'}
METAL = {'уголок', 'швеллер', 'пластина', 'арматура', 'профиль', 'металлоконструкции', 'металлопрокат', 'полоса', 'лист', 'двутавр', 'пруток'}
PAINT = {'грунтовка', 'краска', 'эмаль', 'уайт', 'уайт-спирит', 'растворитель'}
CONV = {'ВК': dict(metal='6.2.3.1.99.1.1', paint_fam='Антикоррозийная окраска трубопроводов'),
        'ОВ1': dict(metal='6.2.3.2.99.2.1', paint_fam='Антикоррозийная окраска трубопроводов'),
        'ОВ2': dict(metal=fam_of('Монтаж металлической рамы для воздуховодов, с учетом грунтовки за 2 раза и огнезащитной окраски за 2 раза'))}
# ключи семей в famcodes обрезаны fam_of до 70 символов — CONV использует ту же обрезку
FLANGE_HEADS = {'фланец'}; THREAD_HEADS = {'резьба'}
DUCT_FASTENER = FASTENER | {'шина', 'траверса', 'хомут', 'скоба', 'шнур', 'герметик', 'кронштейн'}
# Кр — распределяемые классы (п. 0.7 [В 31.10]): делятся между работами-потребителями своей системы пропорционально объём × норма класса
PIPE_KR = FASTENER | {'траверса', 'кронштейн', 'консоль', 'т-консоль', 'хомут', 'скоба', 'шина'}
KR = {'ВК':  [dict(heads=PIPE_KR, cons=r'^прокладка трубопровод', what='работы прокладки трубопроводов системы', basis='м трубы × норма класса на 1 м')],
      'ОВ1': [dict(heads=PIPE_KR, cons=r'^прокладка трубопровод', what='работы прокладки трубопроводов системы, в т. ч. PE-X и PP-R [В 31.10]', basis='м трубы × норма класса на 1 м')],
      'ОВ2': [dict(heads=DUCT_FASTENER, cons=r'^прокладка воздуховод', what='работы прокладки воздуховодов системы', basis='м² воздуховодов × норма')],
      'ЭОМ': [dict(heads={'гайка', 'шайба', 'болт', 'винт', 'анкер', 'шпилька', 'консоль', 'профиль', 'шуруп'}, cons=r'^монтаж лотка', what='работы монтажа лотков', basis='м лотка'),
              dict(heads={'стяжка', 'хомут-стяжка'}, cons=r'^прокладка кабеля, провода в лотке', what='кабель в лотке', basis='м кабеля'),
              dict(heads={'наконечник', 'бирка', 'маркер'}, cons=r'коммутация щитов (вру|грщ)', what='щиты ВРУ/ГРЩ', basis='число панелей')],
      'СС':  [dict(heads={'винт', 'гайка', 'шайба', 'болт', 'шпилька', 'анкер', 'консоль', 'профиль'}, cons=r'^монтаж лотка', what='работы монтажа лотков', basis='м лотка')]}
INSUL_RE = re.compile(r'изоляц|теплоизол|energofle[xх]|k-?fle[xх]|термафлекс|тилит|порилекс')
def insulation_code(sec, sysc, mn):
    """ВК / ОВ1: работа изоляции труб цилиндрами (трубками) своей ветки по материалу: минвата или вспененные (умолчание)."""
    fam = 'Изоляция трубопроводов цилиндрами'
    fc = KB['famcodes'].get((sec, fam), [])
    fc = [x for x in fc if sys_ok(sec, sysc, x[1]) and 'спольз' not in KB['works'].get(x[0], '')] or fc
    want = 'минвата' if re.search(r'минват|минерал|базальт|каменн', mn) else 'вспененный'
    fc = [x for x in fc if want in x[2]] or fc
    return (max(fc, key=lambda x: x[3])[0], fam) if fc else (None, fam)
def kr_rule(sec, h, mn, ctx=None):
    """Номер правила Кр для строки или None (исключения — классы, которые идут в одну работу как С-В)."""
    if sec in ('ВК', 'ОВ1') and h in ('болт', 'гайка', 'шайба', 'шпилька') and ctx and ctx.get('has_flange') and re.search(r'(?<![a-zа-я])м\s?(1[6-9]|2\d)(?!\d)', mn): return None   # М16+ при фланцевой арматуре — фланцевые [Р]
    if sec in ('ВК', 'ОВ1') and h == 'профиль' and re.search(r'монтажн|перфор', mn): return 0   # профиль (шина) монтажный перфорированный — Кр [Р]
    if sec in ('ВК', 'ОВ1') and h == 'скоба' and INSUL_RE.search(mn): return None                # скоба для изоляции — расходник изоляции труб (Р), не крепёж трубопроводов [правила 1.3 / 2.3]
    if sec == 'ВК' and h == 'хомут' and re.search(r'rapid|усилив', mn): return None            # хомут SML — С-В SML-работы [Д]
    if sec in ('ВК', 'ОВ1') and h in ('болт', 'гайка', 'шайба') and re.search(r'фланц', mn): return None   # фланцевое соединение — С-В фланцевой арматуры [К]
    if sec == 'ОВ1' and h in ('кронштейн', 'консоль', 'дюбель', 'шуруп') and re.search(r'радиат|конвект|прибор|полотенц', mn): return None   # крепление прибора — С-В прибора
    if sec == 'ОВ2' and re.search(r'\bhtk\b|\bkkv\b|вентилятор|\bsib\b|big ?foot', mn): return None     # принадлежности вентиляторов, Big Foot — С-В своей работы
    if sec == 'ОВ2' and h == 'уголок' and not re.search(r'угф|фланцев', mn): return None
    for i, r in enumerate(KR.get(sec, [])):
        if h in r['heads'] or (sec == 'ОВ2' and h == 'уголок'): return i
    return None
# классы, которые идут целиком в одну работу-потребитель своей ветки (С-В): СС 5.4, ЭОМ 4.4
SINGLE = {'СС': [({'стяжка', 'наконечник', 'бирка', 'маркер', 'хомут-стяжка'}, r'^маркировка кабеля'),
                 ({'дюбель', 'саморез', 'гвозди', 'гвоздь', 'дюбель-гвоздь', 'шуруп', 'клипса'}, r'монтаж трубы пвх, пнд для кабеля / расходные')],
          'ЭОМ': [({'клипса', 'скоба', 'дюбель-хомут', 'дюбель', 'гвозди', 'гвоздь', 'дюбель-гвоздь', 'саморез'}, None)]}
R_HEADS = {'клей', 'очиститель', 'скотч', 'грунтовка', 'уайт', 'уайт-спирит', 'растворитель', 'герметик', 'проволока', 'изолента', 'смазка', 'припой', 'флюс'}
CC_HEADS = {'цилиндры', 'цилиндр', 'трубки', 'трубка', 'эмаль', 'краска', 'пергамин', 'стеклоткань', 'маты', 'мат', 'плиты'}
# замены закрытых семей (ЭОМ К4, СС 5.1): закрытая семья → действующая семья; вариант подбирается по совпадению текста варианта
REPLACE_FAM = {'Монтаж лотка': 'Монтаж лотка электротехнического', 'Монтаж короба': 'Монтаж кабель-канала', 'Прокладка кабель-канала': 'Монтаж кабель-канала',
               'Прокладка трубы ПВХ/ПНД для кабеля_ (Не использовать с 01.01.2024)': 'Монтаж трубы ПВХ, ПНД для кабеля', 'Монтаж трансивера': 'Установка модуля SFP (трансивер SFP)'}

# ЭОМ: вариант кабеля = сумма сечений жил (правила ЭОМ 4.2.2)
EOM_CLASSES = [(1.5, 6, '1,5-6'), (7, 17, '7-17'), (18, 39, '18-39'), (40, 69, '40-69'), (70, 124, '70-124'), (125, 249, '125-249'), (250, 479, '250-479'), (480, 699, '480-699'), (700, 1000, '700-1000'), (1001, 99999, 'свыше 1001')]
def cable_sum(name):
    s = norm(name).replace(',', '.')
    tot = 0.0; found = False
    for n, sec_ in re.findall(r'(?<![\d.])(\d{1,2})\s*[хx]\s*(\d{1,3}(?:\.\d+)?)(?![\dх])', s):
        n, sec_ = int(n), float(sec_)
        if n == 0 or sec_ > 300 or n > 61: continue
        tot += n * sec_; found = True
    return tot if found else None
def eom_cable_class(total):
    if total is None: return None
    if total < 1.5: return '1,5-6'
    for lo, hi, lab in EOM_CLASSES:
        if lo <= total <= hi: return lab
    for lo, hi, lab in EOM_CLASSES:          # разрыв между классами — ближайший сверху
        if total < lo: return lab
    return 'свыше 1001'

# СС: вариант «Прокладка кабеля» по марке (правила СС 5.2.1, шаги 1–11)
def ss_cable_variant(name, unit=None):
    s = norm(name)
    if unit and norm(unit) in ('шт', 'компл', 'комплект') or re.search(r'hdmi|usb|db9|c13|c14|rca|с разъем|комплект кабел', s): return 'Соединительный'
    if re.search(r'u/utp|f/utp|s/ftp|sf/utp|\butp\b|\bftp\b|витая пара|cat\.?\s?[567]|квпнг|квпэф', s): return 'Витая пара'
    if re.search(r'\bрк\s?-?\s?(50|75)|\d+d-fb|\brg-?\s?\d|\bsat\s?\d|коаксиал', s): return 'Коаксиальный'
    if re.search(r'\bок[а-я]*[\s-]|оквнг|окгнг|оптическ|волокон|\bfo\b|g\.65[27]', s): return 'Волоконно-оптический'
    if re.search(r'(?<![а-я])а?с?ввг|\bвбшв|\bвббшв|пвбшв|\bппг|\bкгвв|\bnym', s): return 'Силовой'
    if re.search(r'\bпвс|\bшввп', s): return 'Питающий'
    if re.search(r'кипэв|кипвэв|кипэнг|кис-|\bксб|сегментки|техноки|интерфейс|rs-?485', s): return 'Для промышленного интерфейса'
    if re.search(r'мкэш|мкш|кпстт|ск-эпп', s): return 'Монтажный'
    if re.search(r'\bкввг|\bквбб|\bкппг|кпспп|кпспэп|кпсгпп|кскв', s): return 'Контрольный'
    if re.search(r'\bкпл\b|лифтов', s): return 'Лифтовой'
    if re.search(r'\bтпп|\bтсв', s): return 'Телефонный'
    if re.search(r'комбинирован|\bквк', s): return 'Комбинированный'
    if re.search(r'кпс|ксв|кср|кск|копс|куин|лоутокс|кунрс|кшс|j-h|\bокл', s):
        return 'Огнестойкий' if re.search(r'fr', s) else 'Не распространяющий горение'
    return None

def pick_variant(sec, fam, sysc, dn, candidates):
    """candidates: [(code, sys, var, files)] одной семьи; выбрать по системе и DN."""
    c = [x for x in candidates if sys_ok(sec, sysc, x[1])] or candidates
    if dn is not None:
        ok = []
        for code, s, var, files in c:
            rng = var_range(var)
            if rng and rng[0] <= dn <= rng[1]: ok.append((code, s, var, files))
        if ok: return max(ok, key=lambda x: x[3]), 'DN'
    return max(c, key=lambda x: x[3]), 'частота'

# имена нормализованы norm(): латинская x → кириллическая х, поэтому в шаблонах [xх]
PIPE_MAT = [(r'pe-?[xх]|пекс|сшит', 'сшитого'), (r'pp-?r|ppr|полипропилен[а-я ]*(?:на )?сварк|стекловолокн', 'PP-R'), (r'\bsml\b|чугун|безраструб', 'чугунных'),
            (r'нпвх|\bпвх', 'НПВХ'), (r'\bпнд\b|пэ\s?100|pe\s?100|sdr', 'ПНД'), (r'раструб|pp-?h|\bпп\b|полипропилен', 'раструбных'), (r'сталь|вгп|электросвар|водогазопров|гост 3262|гост 10704|оцинк', 'стальных')]
def pipe_family(sec, name, hf_):
    """ВК/ОВ1: материал трубы из имени → семья прокладки (ТЗ 4.2 п.2, правила 1.3/2.3); hf_ — семьи класса из базы."""
    mn = norm(name)
    for pat, key in PIPE_MAT:
        if re.search(pat, mn):
            c = [x for x in hf_ if key in x[0]]
            if c: return max(c, key=lambda x: x[1]), key
    return None, None
FITTING_HEADS = {'отвод', 'тройник', 'переход', 'крестовина', 'заглушка', 'ревизия', 'патрубок', 'муфта', 'колено', 'угольник', 'компенсатор', 'бурт'}
DUCT_HEADS = {'воздуховод', 'отвод', 'тройник', 'переход', 'заглушка', 'врезка', 'крестовина', 'ниппель', 'утка', 'штаны', 'переходник'}
DUCT_AREA_METHOD = 'площадь по геометрии из имени'   # способ volume_of для ОВ2: объём ведёт каждое изделие из DUCT_HEADS, фильтр принадлежностей не применяется
def duct_rule(name, sysc, object_type):
    """ОВ2: воздуховоды и фасонные — семья и вариант по форме, толщине и типу изделия (правила ОВ2 2.2)."""
    mn = norm(name); h = head(name)
    if h not in DUCT_HEADS: return None
    shape = 'прямоугольного' if ('прямоуг' in mn or re.search(r'\d{3,4}\s*[хx]\s*\d{3,4}', mn)) and 'кругл' not in mn else ('круглого' if ('кругл' in mn or 'ø' in mn or re.search(r'(?<![\wа-я])d\s?\d{2,4}', mn)) else None)
    if not shape: return None
    skb = object_type and 'скб' in norm(object_type)
    fam = 'Прокладка воздуховодов СКБ (ДОУ, СОШ)' if skb else f'Прокладка воздуховодов {shape} сечения'
    if h == 'воздуховод':
        t = re.search(r'(?:стенк[аи]|толщ)\D{0,14}(\d[.,]\d+)', mn)
        th = float(t.group(1).replace(',', '.')) if t else None
        if th is None: var_key = 'от 0,71 до 0,9'
        elif th <= 0.7: var_key = 'до 0,7'
        elif th <= 0.9: var_key = 'от 0,71 до 0,9'
        else: var_key = 'от 0,91'
    else: var_key = 'соединительные'
    cands = KB['famcodes'].get(('ОВ2', fam), [])
    cs = [c for c in cands if var_key in norm(c[2]) and (not skb or shape in norm(c[2]))]
    if sysc: cs2 = [c for c in cs if sys_ok('ОВ2', sysc, c[1])]; cs = cs2 or cs
    if not cs: return None
    best = max(cs, key=lambda c: c[3])
    return dict(code=best[0], fam=fam, how=f'форма «{shape}», {"толщина" if h=="воздуховод" else "фасонная"} → «{var_key}»')

def find_code(sec, sysc, pat, prefix=None):
    """Код работы раздела по шаблону полного имени работы в своей ветке (самый частый в образцах; иначе любой действующий)."""
    rx = re.compile(pat, re.I); best = None
    for (s_, fam), cs in KB['famcodes'].items():
        if s_ != sec: continue
        for c in cs:
            wn = KB['works'].get(c[0], '')
            if not rx.search(wn) or re.search(r'НЕ ИСПОЛЬЗ|Не использовать', wn): continue
            if not sys_ok(sec, sysc, c[1]): continue
            if prefix and not c[0].startswith(prefix): continue
            if best is None or c[3] > best[3]: best = c
    return best[0] if best else None

def alt_code(sec, fam, sysc, dn_v, name, h):
    """Код работы-варианта в семье fam для материала name: у кабеля ЭОМ — вариант по Σ сечений (как правило 2a),
    иначе по системе и DN; «расходные / вспомогательные» варианты не предлагаются."""
    cf = [x for x in KB['famcodes'].get((sec, fam), []) if sys_ok(sec, sysc, x[1]) and not re.search(r'расходн|вспомогательн', norm(x[2]))]
    if not cf: return None
    if sec == 'ЭОМ' and h in ('кабель', 'провод') and re.search(r'кабеля, провода', fam):
        lab = eom_cable_class(cable_sum(name))
        if lab:
            fc = [x for x in cf if norm(x[2]).startswith(norm(lab))]
            if fc: return max(fc, key=lambda x: x[3])[0]
    (c2, s2, v2, f2), how2 = pick_variant(sec, fam, sysc, dn_v, cf)
    return c2

def bind_item(sec, item, ctx):
    name = item['name']; mn = norm(name); h = head(name); sysc = ctx.get('sysc')
    flags = []; dn = dn_of(name); dn_v = dn_for_variant(name, dn)   # dn_v — для выбора варианта: Ø133 → как 131, Ø219 → как 201 [В 31.10]
    alts = []   # другие работы, куда материал тоже мог бы лечь (кабель: открыто / в трубе / в лотке) — сметчику на выбор, когда агент не уверен
    if sec == 'ОВ2':
        d = duct_rule(name, sysc, ctx.get('object_type'))
        if d:
            code = d['code']
            return dict(code=code, work=KB['works'].get(code, '')[:100], family=d['fam'], role='В', confidence=0.9, source='правило ОВ2 3.2: ' + d['how'], flags=[], fcodes=[], review=False, dn=None, deprecated_code=None)
    # --- 1. библиотека по имени
    cands = KB['lib'].get((sec, mn), [])
    if cands:
        cs = [c for c in cands if sys_ok(sec, sysc, c['sys'])]
        if ctx.get('prefix'): cs = [c for c in cs if c['code'].startswith(ctx['prefix'])] or cs
        # библиотека — подтверждение; правила ведущих (2a/2b, duct_rule) и конвенции (3) применяются поверх неё
        if not cs:
            # [сайт 01.11] имя известно библиотеке только в других системах: та же работа (семья и вариант) в ветке
            # системы строки — берём её код; иначе код чужой системы с F-SYS (ТКП из 1С сгруппирует его в чужую систему)
            moved = []
            for c in cands:
                c2 = same_in_branch(sec, c['code'], sysc)
                if c2: moved.append(dict(c, code=c2, sys=sysc))
            if moved:
                cs = moved; flags.append('F-SYS: в библиотеке имя встречается только в других системах — взята та же работа в ветке системы строки, проверить')
            else:
                cs = cands; flags.append('F-SYS: в библиотеке имя встречается только в других системах — взят код другой системы, проверить')
        best = max(cs, key=lambda c: c['files'])
        tot_files = sum(c['files'] for c in cs) or 1
        for c in sorted(cs, key=lambda c: -c['files']):
            if c['code'] != best['code'] and c['files'] / max(best['files'], 1) >= 0.6 and len(alts) < 3 and fam_of(c.get('work') or KB['works'].get(c['code'], '')) == fam_of(best.get('work') or KB['works'].get(best['code'], '')):
                alts.append(dict(code=c['code'], work=(KB['works'].get(c['code']) or c.get('work') or '')[:100], share=round(c['files'] / tot_files, 2), ratio=round(c['files'] / max(best['files'], 1), 2)))
        # уверенность — доля файлов с именем в этой системе, где стоит этот код (приближение: по файлам кодов системы)
        src = 'библиотека'; conf = (best['files'] / max(sum(c['files'] for c in cs), 1)) if sysc is not None and cs is not cands else best['share']
        if cs is cands and sysc is not None: conf = best['share'] * 0.5
        code, work, fam = best['code'], best['work'], best['fam']
        if sec in ('ВК', 'ОВ1') and (h in ('труба', 'трубопровод') or h in FITTING_HEADS) and 'для гильз' not in mn:
            pf, key = pipe_family(sec, name, KB['headfam'].get((sec, h), []))
            if pf and key not in fam:
                cf = [x for x in KB['famcodes'].get((sec, pf[0]), []) if sys_ok(sec, sysc, x[1])]
                if cf:
                    (c2, s2, v2, f2), how2 = pick_variant(sec, pf[0], sysc, dn_v, cf)
                    flags.append(f'F-MAT: материал изделия «{key}» ≠ семье по библиотеке «{fam[:40]}» — семья по материалу: {code} → {c2}'); code, work, fam = c2, KB['works'].get(c2, ''), pf[0]; src = 'материал из имени (п. 0.4) поверх библиотеки'; conf = 0.8
    else:
        # --- 2. класс → семья
        hf_ = KB['headfam'].get((sec, h), [])
        if not hf_ and sec in ('ВК', 'ОВ1') and h in ('цилиндр', 'цилиндры', 'трубка', 'трубки') and (h.startswith('цилиндр') or INSUL_RE.search(mn)) and insulation_code(sec, sysc, mn)[0]:
            # теплоизоляционные цилиндры и трубки, которых нет ни в библиотеке, ни среди классов выборки: класс однозначен [правила 1.3 / 2.3]
            c_ = insulation_code(sec, sysc, mn)[0]
            return dict(code=c_, work=KB['works'].get(c_, '')[:100], family=fam_of(KB['works'].get(c_, '')), role='С-С', confidence=0.85,
                        source='правило: цилиндры и трубки теплоизоляционные — изоляция труб цилиндрами своей ветки (минвата / вспененные)', flags=[], fcodes=[], review=False, dn=dn, deprecated_code=None)
        if not hf_: return dict(code=None, work=None, family=None, role='?', confidence=0, source='нет данных', flags=['F-NEW: класс материала не встречался в выборке — вопрос'], fcodes=['F-NEW'], review=True, dn=dn, deprecated_code=None)
        fam, files, share = max(hf_, key=lambda x: x[1])
        mat_rule = False
        if sec in ('ВК', 'ОВ1') and (h in ('труба', 'трубопровод') or h in FITTING_HEADS) and 'для гильз' not in mn:
            pf, key = pipe_family(sec, name, hf_)
            if pf: fam, files, share = pf; share = max(share, 0.9); mat_rule = True
        cands_f = KB['famcodes'][(sec, fam)]
        if sysc is not None and not any(sys_ok(sec, sysc, x[1]) for x in cands_f):
            # семьи нет в этой системе — не брать код чужой системы (ТЗ F-SYS)
            alt = [(f_, fl, sh) for f_, fl, sh in hf_ if any(sys_ok(sec, sysc, x[1]) for x in KB['famcodes'][(sec, f_)])]
            if alt: fam, files, share = max(alt, key=lambda x: x[1]); cands_f = KB['famcodes'][(sec, fam)]
            else: return dict(code=None, work=None, family=fam, role='?', confidence=0, source='класс → семья', flags=[f'F-SYS: ни одна семья класса «{h}» не имеет работ в системе {sysc} — вопрос'], dn=dn, review=True, fcodes=['F-SYS'])
        if ctx.get('prefix'): cands_f = [x for x in cands_f if x[0].startswith(ctx['prefix'])] or cands_f
        (code, s, var, f), how = pick_variant(sec, fam, sysc, dn_v, cands_f)
        work = KB['works'].get(code, '') or fam
        tot_fam = sum(fl for f_, fl, sh in hf_) or 1
        for f_, fl, sh in sorted(hf_, key=lambda x: -x[1]):
            if mat_rule or f_ == fam or fl / max(files, 1) < 0.6 or len(alts) >= 3: continue
            c2 = alt_code(sec, f_, sysc, dn_v, name, h)
            if c2: alts.append(dict(code=c2, work=(KB['works'].get(c2) or f_)[:100], share=round(fl / tot_fam, 2), ratio=round(fl / max(files, 1), 2)))
        src = f'класс «{h}» → семья ({share:.0%} файлов){" по материалу из имени" if mat_rule else ""}, вариант по {how}'; conf = share * 0.7
        if (how == 'DN' or len({x[2] for x in cands_f if sys_ok(sec, sysc, x[1])}) <= 1) and (share >= 0.9 or mat_rule): conf = 0.85   # семья однозначна, вариант по признаку [Д]
    role = 'В'
    # --- 2a. ЭОМ: кабель/провод — вариант по Σ сечений жил (4.2.2); семья (способ прокладки) — из библиотеки/класса
    if sec == 'ЭОМ' and h in ('кабель', 'провод') and fam and re.search(r'кабеля, провода', fam):
        lab = eom_cable_class(cable_sum(name))
        if lab:
            fc = [x for x in KB['famcodes'].get((sec, fam), []) if norm(x[2]).startswith(norm(lab)) and (sys_ok(sec, sysc, x[1]))]
            if fc:
                c2 = max(fc, key=lambda x: x[3])[0]
                if c2 != code: flags.append(f'вариант по Σ сечений {cable_sum(name):g} мм² → «{lab}»: {code} → {c2}')
                code, work = c2, KB['works'].get(c2, ''); src += f'; вариант по Σ сечений ({lab})'; conf = max(conf, 0.85)
    # --- 2a'. ЭОМ: ВРУ — вариант по числу панелей из имени
    if sec == 'ЭОМ' and fam and fam.startswith('Установка и коммутация щитов ВРУ'):
        pm = re.search(r'(\d{1,2})\s*-?\s*(?:х\s*)?панел', mn)
        if pm:
            npan = int(pm.group(1)); fc = [x for x in KB['famcodes'].get((sec, fam), []) if sys_ok(sec, sysc, x[1]) and re.match(rf'{npan}\s+панел', norm(x[2]))]
            if fc:
                c2 = max(fc, key=lambda x: x[3])[0]
                if c2 != code: flags.append(f'вариант по числу панелей ({npan}): {code} → {c2}')
                code, work = c2, KB['works'].get(c2, ''); src += f'; вариант по числу панелей ({npan})'; conf = max(conf, 0.85)
    # --- 2b. СС: «Прокладка кабеля» — вариант по марке (5.2.1); провод → «Прокладка провода»
    if sec == 'СС' and h in ('кабель', 'кабель,', 'провод'):
        v = ss_cable_variant(name, item.get('unit'))
        if h == 'провод' or (v is None and re.search(r'\bпугв|\bпв[134]\b|\bмг\b', mn)):
            fc = [x for x in KB['famcodes'].get((sec, 'Прокладка провода'), []) if sys_ok(sec, sysc, x[1])]
            if fc and fam != 'Прокладка провода':
                c2 = max(fc, key=lambda x: x[3])[0]; flags.append(f'провод → «Прокладка провода»: {code} → {c2}'); code, work, fam = c2, KB['works'].get(c2, ''), 'Прокладка провода'; src += '; правило СС 5.2.1 шаг 6'; conf = max(conf, 0.85)
        elif v and (fam == 'Прокладка кабеля' or h.startswith('кабель')):
            fc = [x for x in KB['famcodes'].get((sec, 'Прокладка кабеля'), []) if norm(x[2]) == norm(v) and (sys_ok(sec, sysc, x[1]))]
            if ctx.get('prefix'): fc = [x for x in fc if x[0].startswith(ctx['prefix'])] or fc
            if fc:
                c2 = max(fc, key=lambda x: x[3])[0]
                if c2 != code: flags.append(f'вариант по марке → «{v}»: {code} → {c2}')
                code, work, fam = c2, KB['works'].get(c2, ''), 'Прокладка кабеля'; src += f'; вариант по марке ({v})'; conf = max(conf, 0.85)
    # --- 3. конвенции РВ: Кр (п. 0.7), одна работа-потребитель, сопутствующие с работой по назначению
    kr = kr_rule(sec, h, mn, ctx); special = None
    if kr is not None:
        role = 'Кр'; special = 'кр'; src = f'п. 0.7 [В 31.10]: Кр — распределяется по: {KR[sec][kr]["what"]} ({KR[sec][kr]["basis"]}); код = основной потребитель, разбивка — distribution'; conf = max(conf, 0.8)
    for heads_, pat in SINGLE.get(sec, []):
        if kr is None and h in heads_:
            if pat is None:   # ЭОМ: крепёж гофры/трубы → «Монтаж трубы ПВХ, ПНД / расходные», открытого кабеля → «Прокладка кабеля открыто / расходные»
                pat = (r'стальной трубы для кабеля / вспомогательный' if re.search(r'стальн[а-я]* труб|для труб[ыа]? стальн', mn) else
                       r'прокладка кабеля, провода открыто / расходные' if re.search(r'кабел|провод', mn) and not re.search(r'труб|гофр', mn) else r'монтаж трубы пвх, пнд для кабеля / расходные')
            c2 = find_code(sec, sysc, pat, ctx.get('prefix'))
            if c2:
                code, work = c2, KB['works'].get(c2, ''); fam = fam_of(work); role = 'С-В'; special = 'single'; src = f'конвенция {sec} N.4: класс «{h}» — целиком в «{fam_of(work)[:50]}» своей ветки'; conf = max(conf, 0.8)
    conv = CONV.get(sec)
    if special: pass
    elif sec == 'ОВ2' and conv:
        if h in METAL or h in PAINT:
            fc = [x for x in KB['famcodes'].get((sec, conv['metal']), []) if sys_ok(sec, sysc, x[1])] or KB['famcodes'].get((sec, conv['metal']), [])
            if fc:
                code = max(fc, key=lambda x: x[3])[0]; work = KB['works'].get(code, ''); fam = conv['metal']; special = 'conv'
                if h in METAL: role = 'В'; src = 'п. 0.6 [В 31.10]: металлопрокат рамы — по массе (кг)'
                else: role = 'Р'; src = 'ОВ2 К6 [В 31.10]: грунтовка/краска/растворитель рам — в работе рамы'
                conf = max(conf, 0.85)
    elif conv:
        label = {'ВК': 'ВК 1.4', 'ОВ1': 'ОВ1 2.4'}.get(sec, sec)
        if sec == 'ОВ1' and h in ('муфта', 'соединитель', 'футорка', 'угольник', 'ниппель', 'сгон', 'удлинитель', 'американка', 'фитинг', 'переходник') and not re.search(r'сталь|нерж|чугун|грувлок', mn):
            # ОВ1 2.4: латунные фитинги — в PE-X по D трубы или в муфтовую арматуру по DN
            fam_pex = next((f for f in KB['fams_by_sec'].get(sec, []) if f.startswith('Прокладка трубопроводов из труб сшитого')), None)
            fam_arm = next((f for f in KB['fams_by_sec'].get(sec, []) if f.startswith('Установка задвижек и клапанов резьбовых')), None)
            dn_ = dn_of(name); use_pex = ctx.get('pex_code') and (dn_ is None or dn_ <= 32) and re.search(r'евроконус|pe[xх]|пекс|d\s?(16|20|25|32)\b|(16|20|25|32)\s?[хx]\s?\d', mn)
            tf = fam_pex if use_pex else fam_arm
            fc = [x for x in KB['famcodes'].get((sec, tf), [])] if tf else []
            fc = [x for x in fc if sys_ok(sec, sysc, x[1])] or fc
            if fc:
                (code, s_, var, f), how = pick_variant(sec, tf, sysc, dn_, fc); work = KB['works'].get(code, ''); fam = tf; role = 'С-В'; special = 'conv'; src = f'конвенция {label} (латунный фитинг: ' + ('PE-X по D трубы' if use_pex else 'муфтовая арматура по DN') + ')'; conf = max(conf, 0.75)
        elif h in METAL and conv['metal']:
            code, work, fam, role, src = conv['metal'], KB['works'].get(conv['metal'], ''), fam_of(KB['works'].get(conv['metal'], '')), 'В', 'п. 0.6 [В 31.10]: в опорные конструкции — только металлопрокат, объём — масса (т)'; conf = max(conf, 0.9); special = 'conv'
        elif h in PAINT and conv['paint_fam']:
            fc = KB['famcodes'].get((sec, conv['paint_fam']), [])
            fc2 = [x for x in fc if '2 слоя' in x[2]] or fc
            if fc2:
                (code, s_, var, f), _ = pick_variant(sec, conv['paint_fam'], sysc, None, fc2); work = KB['works'].get(code, ''); fam = conv['paint_fam']; special = 'conv'
                role = 'Р'; src = f'конвенция {label}: окраска трубопроводов своей системы, «в 2 слоя» [К]; объём — площадь окрашиваемых труб [В 31.10]; в опорные конструкции не идёт [В 31.10]'; conf = max(conf, 0.8)
        elif h == 'скоба' and INSUL_RE.search(mn) and insulation_code(sec, sysc, mn)[0]:
            code, fam = insulation_code(sec, sysc, mn); work = KB['works'].get(code, ''); role = 'Р'; special = 'conv'
            src = f'конвенция {label}: скоба для изоляции — расходник изоляции труб своей ветки (Р), не крепёж трубопроводов'; conf = max(conf, 0.85)
        elif h in ('трубка', 'трубки') and INSUL_RE.search(mn) and insulation_code(sec, sysc, mn)[0]:
            code, fam = insulation_code(sec, sysc, mn); work = KB['works'].get(code, ''); role = 'С-С'; special = 'conv'
            src = f'конвенция {label}: трубка теплоизоляционная — изоляция труб цилиндрами (трубками) своей ветки'; conf = max(conf, 0.85)
        elif h == 'хомут' and re.search(r'rapid|усилив', mn):
            role = 'С-В'; special = 'conv'; src = 'конвенция ВК 1.4 п.2: хомут Rapid/усиливающий — в SML-работе (группа только там [КЦ])'; conf = max(conf, 0.8)
        elif h == 'шнур' and ctx.get('pipe_code'):
            code, work = ctx['pipe_code'], KB['works'].get(ctx['pipe_code'], ''); fam = fam_of(work); role = 'С-В'; special = 'conv'; src = f'конвенция {label}: шнур у гильз — в работе трубопровода'; conf = max(conf, 0.8)
        elif 'для гильз' in mn and ctx.get('pipe_code'):
            code, work = ctx['pipe_code'], KB['works'].get(ctx['pipe_code'], ''); fam = fam_of(work); role = 'С-В'; special = 'conv'; src = f'конвенция {label}: «(для гильз)» — гильза в работе защищаемой трубы, количество из ЛРВ, объём не ведёт'; conf = max(conf, 0.8); dn = None
        elif h in FLANGE_HEADS or h in ('прокладка', 'паронит') or (h == 'лента' and re.search(r'межфланц|паронит', mn)) or (h in ('болт', 'гайка', 'шайба', 'шпилька') and (re.search(r'фланц', mn) or (ctx.get('has_flange') and re.search(r'(?<![a-zа-я])м\s?(1[6-9]|2\d)(?!\d)', mn)))):
            fc = [x for x in KB['famcodes'].get((sec, next((f for f in KB['fams_by_sec'].get(sec, []) if f.startswith('Установка кранов фланцевых')), '')), []) if sys_ok(sec, sysc, x[1])]
            if fc:
                (code, s_, var, f), how = pick_variant(sec, 'фланцевая', sysc, dn_v, fc); work = KB['works'].get(code, ''); fam = fam_of(work); role = 'С-В'; special = 'conv'
                src = f'конвенция {label}: фланцевое соединение — в работу фланцевой арматуры того же DN [К, по назначению]'; conf = max(conf, 0.8)
        elif h in THREAD_HEADS:
            fc = [x for x in KB['famcodes'].get((sec, next((f for f in KB['fams_by_sec'].get(sec, []) if f.startswith('Установка задвижек и клапанов резьбовых')), '')), []) if sys_ok(sec, sysc, x[1])]
            if fc:
                (code, s_, var, f), how = pick_variant(sec, 'муфтовая', sysc, dn_v, fc); work = KB['works'].get(code, ''); fam = fam_of(work); role = 'С-В'; special = 'conv'; src = f'конвенция {label}: резьба — в работу муфтовой арматуры того же DN [К, вопрос владельцу]'; conf = max(conf, 0.75)
    # --- 4. поправка варианта по DN для ведущих в семьях с DN-вариантами
    if dn is not None and code and fam and re.search(r'трубопровод|задвиж|кранов флан|фильтра|опор|компенсатор|сшитого', fam):
        fc = KB['famcodes'].get((sec, fam), [])
        dn_eff = dn_v
        if 'опор' in fam and 'горизонт' in fam and dn == 65: dn_eff = 76   # [В 31.10] DN65 (Ø76) горизонтальных опор → «от 76мм до 120мм»
        rng_now = var_range(KB['works'].get(code, work) or '')
        if rng_now and not (rng_now[0] <= dn_eff <= rng_now[1]):
            (c2, s2, v2, f2), how = pick_variant(sec, fam, sysc or (code.split('.')[4] if len(code.split('.')) > 4 else None), dn_eff, fc)
            if how == 'DN' and c2 != code:
                flags.append(f'F-DN: вариант исправлен по DN{dn}{" (граничный Ø → следующий диапазон, решение владельца 31.10)" if dn_eff != dn else ""}: {code} → {c2}'); code, work = c2, KB['works'].get(c2, '')
    # --- 4a. ОВ1: воздушно-тепловая завеса — вариант по нагреву из имени (карточка 2.2: «водяная», AdWU → водяных; «электрическая» → электрических)
    if sec == 'ОВ1' and code and fam and fam.startswith('Установка завес воздушно-тепловых'):
        want = 'водян' if re.search(r'водян|adwu|теплоносител', mn) else ('электрич' if re.search(r'электр', mn) else None)
        c2 = next((x[0] for x in KB['famcodes'].get((sec, fam), []) if want and want in x[2]), None)
        if c2 and c2 != code: code, work = c2, KB['works'].get(c2, '')
    # --- 5. справочник; закрытые работы → действующая замена (ЭОМ К4, СС 5.1)
    depr = None
    if code and code not in KB['works']: flags.append('F-DEPR: кода нет в справочнике КЦ v2')
    elif code and re.search(r'НЕ ИСПОЛЬЗ|Не использовать', KB['works'][code]):
        wname = KB['works'][code]; old_fam = fam_of(wname); var_txt = norm(re.split(r'\s*/\s*', wname, maxsplit=1)[1]) if '/' in wname else ''
        new_fam = next((v for k, v in REPLACE_FAM.items() if old_fam.startswith(k) or k in wname), None)
        cs = [x for x in KB['famcodes'].get((sec, new_fam), []) if (sys_ok(sec, sysc, x[1])) and (not var_txt or norm(x[2])[:12] == var_txt[:12])] if new_fam else []
        if not cs and new_fam: cs = [x for x in KB['famcodes'].get((sec, new_fam), []) if sys_ok(sec, sysc, x[1])]
        if cs:
            depr = code; code = max(cs, key=lambda x: x[3])[0]; work = KB['works'].get(code, ''); fam = new_fam
            flags.append(f'F-DEPR: работа закрыта в КЦ: {depr} → замена {code} («{new_fam}»)')
        else: flags.append('F-DEPR: работа закрыта в КЦ — выбрать действующую (замены в карте нет)')
    if src.startswith('конвенция') or src.startswith('правило') or src.startswith('п. 0'): flags = [f for f in flags if not f.startswith('F-SYS')]
    # роль по справочнику: строка попала в ведущую группу работы — В (С-С для изоляции/окраски), в неведущую — С-В; расходники — Р [КЦ]
    if code and role not in ('Кр',) and not special:
        mg = match_group(code, name, item.get('unit'))
        if h in R_HEADS: role = 'Р'
        elif mg and mg[3] and hstem(mg[0]['name']) not in ACCESSORY: role = 'С-С' if h in CC_HEADS else 'В'
        elif mg: role = 'С-В'
        else:
            role = 'В' if h in LEAD_HEADS.get(sec, ()) else 'С-В'
            flags.append(f'F-GRP: в работе {code} нет группы КЦ для класса «{h}» — подсказка, проверить работу')
    conf = round(min(conf, 1.0), 2)
    if sysc is None: flags.append('F-CTX: система позиции не задана — код выбран по частоте, нужна проверка')
    fcodes = sorted({f.split(':')[0] for f in flags if f.startswith('F-')})
    review = conf < 0.8 or sysc is None or any(c in ('F-SYS', 'F-DEPR') for c in fcodes)
    # варианты - когда работу не задала конвенция и у класса/имени есть почти равные семьи (кабель: в лотке / в трубу / открыто);
    # почти ничья (вторая семья ≥ 85 % первой) - на проверку с F-ALT, иначе варианты показываются тихо
    alts = [a for a in alts if a['code'] != code and a['code'] in KB['works']] if conf < 0.9 and not special else []
    if alts and max(a.get('ratio', 0) for a in alts) >= 0.85:
        flags.append('F-ALT: материал может относиться к %d работам - %s; подтвердите или выберите' % (len(alts) + 1, '; '.join('%s (%d%% файлов)' % (a['code'], a['share'] * 100) for a in alts)))
        fcodes = sorted(set(fcodes) | {'F-ALT'}); review = True
    return dict(code=code, work=(KB['works'].get(code) or work or '')[:100], family=fam, role=role, confidence=conf, source=src, flags=flags, fcodes=fcodes, review=review, dn=dn, deprecated_code=depr, alts=alts)

def bind(sec, items, object_type=None):
    out = []
    subs = {}   # СС: подветка «2.2» → префикс кода 6.2.3.5.2.2.
    # контекст по системам: ведущая труба каждой системы (для хомутов и шнура)
    by_sys = collections.defaultdict(list)
    for it in items:
        sc = sys_code(sec, it.get('system')); by_sys[sc].append(it)
        if sec == 'СС' and re.fullmatch(r'\d{1,2}\.\d{1,2}', norm(it.get('system') or '')): subs[sc] = '6.2.3.5.' + norm(it['system']) + '.'
    for sysc, its in by_sys.items():
        pipes = collections.Counter()
        for it in its:
            if head(it['name']) in ('труба', 'трубопровод'):
                c = KB['lib'].get((sec, norm(it['name'])), [])
                c = [x for x in c if sys_ok(sec, sysc, x['sys'])]
                if c: pipes[max(c, key=lambda x: x['files'])['code']] += 1
        pex = collections.Counter()
        for it in its:
            if head(it['name']) in ('труба', 'трубопровод') and re.search(r'pe-?[xх]|пекс|сшит', norm(it['name'])):
                c = [x for x in KB['lib'].get((sec, norm(it['name'])), []) if sys_ok(sec, sysc, x['sys'])]
                if c: pex[max(c, key=lambda x: x['files'])['code']] += 1
        has_support = any(head(it['name']) in METAL for it in items)   # есть ли в перечне металл опорных конструкций (ВК 1.4 п.1: иначе крепёж — в работе трубопровода)
        has_flange = any(head(it['name']) == 'фланец' or re.search(r'межфланц|фланцев', norm(it['name'])) for it in its)
        ctx = dict(has_flange=has_flange, sysc=sysc, pipe_code=pipes.most_common(1)[0][0] if pipes else None, pex_code=pex.most_common(1)[0][0] if pex else None, has_support=has_support, object_type=object_type, prefix=subs.get(sysc))
        if sec == 'ОВ2':
            # ведущая работа прокладки воздуховодов системы (для крепежа): самая частая среди воздуховодов перечня, иначе самая частая в выборке
            ducts = collections.Counter(); ducts_round = collections.Counter()
            for it in its:
                d = duct_rule(it['name'], sysc, object_type)
                if d and head(it['name']) == 'воздуховод' and 'соединительные' not in norm(KB['works'].get(d['code'], '')):
                    ducts[d['code']] += 1
                    if 'круглого' in d['fam']: ducts_round[d['code']] += 1
            if not ducts:
                fc = [x for x in KB['famcodes'].get(('ОВ2', 'Прокладка воздуховодов прямоугольного сечения'), []) if (sys_ok(sec, sysc, x[1])) and 'соединительные' not in norm(x[2])]
                if fc: ducts[max(fc, key=lambda x: x[3])[0]] += 1
            if not ducts_round:
                fc = [x for x in KB['famcodes'].get(('ОВ2', 'Прокладка воздуховодов круглого сечения'), []) if (sys_ok(sec, sysc, x[1])) and 'соединительные' not in norm(x[2])]
                if fc: ducts_round[max(fc, key=lambda x: x[3])[0]] += 1
            ctx['duct_code'] = ducts.most_common(1)[0][0] if ducts else None
            ctx['duct_code_round'] = ducts_round.most_common(1)[0][0] if ducts_round else None
        res_sys = []
        for it in its:
            r = bind_item(sec, it, ctx); r['id'] = it.get('id'); r['name'] = it['name']; r['system'] = it.get('system'); res_sys.append((it, r))
        # второй проход: ведущая работа прокладки системы — по привязанным трубам (библиотека могла их не знать), затем перепривязка крепежа/хомутов/шнура/гильз
        if ctx.get('pipe_code') is None and sec in ('ВК', 'ОВ1'):
            pc = collections.Counter(r['code'] for it, r in res_sys if r['code'] and head(it['name']) in ('труба', 'трубопровод') and 'для гильз' not in norm(it['name']) and (r['role'] or '').startswith('В') is False and 'трубопровод' in (r['family'] or '').lower())
            pc = pc or collections.Counter(r['code'] for it, r in res_sys if r['code'] and head(it['name']) in ('труба', 'трубопровод') and 'трубопровод' in (r['family'] or '').lower())
            if pc:
                ctx['pipe_code'] = pc.most_common(1)[0][0]
                for i, (it, r) in enumerate(res_sys):
                    h = head(it['name'])
                    if h == 'шнур' or 'для гильз' in norm(it['name']):
                        r2 = bind_item(sec, it, ctx); r2['id'] = it.get('id'); r2['name'] = it['name']; r2['system'] = it.get('system'); res_sys[i] = (it, r2)
        # Кр (п. 0.7): потребители — работы этой системы (ветки) из ЛРВ, подходящие под правило класса; код строки = основной потребитель, разбивка — distribute()
        for i, (it, r) in enumerate(res_sys):
            if r['role'] != 'Кр': continue
            rule = KR[sec][kr_rule(sec, head(it['name']), norm(it['name']))]
            cons = sorted({r2['code'] for it2, r2 in res_sys if r2['code'] and r2['role'] in ('В', 'С-С') and re.search(rule['cons'], (KB['works'].get(r2['code']) or '').lower())})
            nm = norm(it['name']); d_ = dn_for_variant(it['name'], dn_of(it['name'])) if head(it['name']) in ('хомут', 'скоба', 'кронштейн') else None
            if d_ and cons:   # хомут с размером — только в работы трубы/воздуховода своего диаметра
                byd = [c for c in cons if (lambda rg: rg and rg[0] <= d_ <= rg[1])(var_range(KB['works'].get(c, '')))]
                if byd: cons = byd
            if sec == 'ОВ2' and cons:
                if re.search(r'червяч', nm): cons = [c for c in cons if 'гибк' in (KB['works'].get(c) or '').lower()] or cons
                elif head(it['name']) == 'хомут' and re.search(r'[øф⌀]|d\s?\d', nm): cons = [c for c in cons if 'кругл' in (KB['works'].get(c) or '').lower()] or cons
            r['consumers'] = cons
            if cons:
                cnt = collections.Counter(r2['code'] for it2, r2 in res_sys if r2['code'] in cons)
                r['code'] = cnt.most_common(1)[0][0]; r['work'] = KB['works'].get(r['code'], '')[:100]; r['family'] = fam_of(r['work'])
                r['flags'] = [f for f in r['flags'] if not f.startswith(('F-SYS', 'F-DEPR', 'F-DN', 'F-MAT', 'F-GRP'))]; r['deprecated_code'] = None
                r['review'] = r['confidence'] < 0.8 or r['system'] is None
            else:
                r['flags'].append(f'F-KR: в ЛРВ системы нет работ-потребителей ({rule["what"]}) — код по библиотеке/классу, проверить'); r['review'] = True
            r['fcodes'] = sorted({f.split(':')[0] for f in r['flags'] if f.startswith('F-')})
        out.extend(r for it, r in res_sys)
    if RVR: to_rvr(sec, out)
    return out

# ---------------------------------------------------------------------------------------------------------------------------
# Объём работ [КЦ] (п. 0.8) и распределение Кр [В 31.10] (п. 0.7)
LEAD_HEADS = {'ВК': ('труба', 'трубопровод', 'кран', 'затвор', 'задвижка', 'клапан', 'фильтр', 'редуктор', 'воздухоотводчик', 'насос', 'трап', 'воронка', 'муфта', 'манжета', 'шахт-пакет', 'ороситель', 'шкаф', 'огнетушитель', 'счетчик', 'счётчик', 'компенсатор', 'опора', 'уголок', 'швеллер', 'цилиндры', 'трубки', 'эмаль'),
              'ОВ1': ('труба', 'трубопровод', 'конвектор', 'радиатор', 'кран', 'клапан', 'фильтр', 'воздухоотводчик', 'компенсатор', 'многослойный', 'неподвижная', 'опора', 'коллектор', 'шкаф', 'счетчик', 'манометр', 'термометр', 'насос', 'завеса', 'цилиндры', 'трубки', 'гофра', 'шланг', 'регистр', 'уголок', 'швеллер'),
              'ОВ2': ('воздуховод', 'отвод', 'тройник', 'переход', 'заглушка', 'врезка', 'ниппель', 'клапан', 'решетка', 'решётка', 'сетка', 'вентилятор', 'дроссель-клапан', 'компенсатор', 'шумоглушитель', 'зонт', 'дефлектор', 'диффузор', 'установка', 'металлическая', 'уголок', 'лист'),
              'ЭОМ': ('кабель', 'провод', 'труба', 'лоток', 'металлорукав', 'светильник', 'щит', 'шкаф', 'вру', 'коробка', 'розетка', 'выключатель', 'датчик', 'счетчик', 'гильза', 'полоса', 'пруток', 'плитка'),
              'СС': ('кабель', 'провод', 'труба', 'лоток', 'металлорукав', 'коробка', 'бирка', 'шина', 'извещатель', 'оповещатель', 'шкаф', 'камера', 'коммутатор', 'прибор', 'блок', 'модуль', 'датчик')}
def fnum(q):
    try: return float(str(q).replace(',', '.').replace(' ', ''))
    except (TypeError, ValueError): return None
def volumes(sec, items, bindings):
    """Объём каждой работы РВ по правилам КЦ (п. 0.8): Σ количество / k строк ЛРВ, попавших в ведущие группы работы, в единице работы;
    опорные конструкции — масса металлопроката. Строки Кр объём не ведут. Если ведущих групп не нашлось — объём по ведущему классу (флаг F-VOL).
    Возвращает {код: {'volume', 'unit', 'method', 'work', 'notes'}}."""
    rows = collections.defaultdict(list); lead = collections.defaultdict(list)
    for it, b in zip(items, bindings):
        code = b.get('code'); q = fnum(it.get('qty'))
        if not code or q is None or b.get('role') == 'Кр': continue
        rows[code].append((it['name'], it.get('unit'), q))
        if b.get('role') in ('В', 'С-С'): lead[code].append((it['name'], it.get('unit'), q))
    vol = {}
    for code, rs in rows.items():
        v, how, notes = volume_of(code, rs)
        wu = KB['kc'].get(code, {}).get('unit', '')
        if v is None:
            same = [q for n_, u, q in lead[code] if nunit(u) == wu]
            if same: v = round(sum(same), 4); how = 'F-VOL: ведущая группа КЦ не найдена — объём по строкам роли В в единице работы'
            else: how = 'F-VOL: объём не определён — нет строк ведущих групп / единица не совпадает'
        vol[code] = dict(volume=v, unit=wu, method=how, work=KB['works'].get(code, '')[:90], notes=notes[:5])
    # окраска трубопроводов — площадь окрашиваемых труб своей системы [В 31.10]
    for code, d in vol.items():
        if not PAINT_WORK.search(KB['works'].get(code, '')): continue
        keys = {paint_key(sec, it, b.get('code')) for it, b in zip(items, bindings) if b.get('code') == code}
        tot = 0.0; how = ''; miss = []
        for k_ in keys:
            a, h_, nd = paint_area(sec, items, bindings, k_)
            if a: tot += a; how = h_
            miss += nd
        if tot: d['volume'] = round(tot, 3); d['method'] = how; d['notes'] = (d['notes'] + ([f'диаметр не определён: {", ".join(miss[:3])}'] if miss else []))[:5]
        else: d['method'] = 'F-VOL: окрашиваемых стальных труб в системе нет — объём по расходу краски / k, проверить'; d['notes'].append('нет стальных труб системы для расчёта площади окраски')
    # «… / расходные материалы» — объём = метраж парной работы той же семьи и ветки (труба ПВХ, кабель открыто) [В]
    for code, d in vol.items():
        wn = KB['works'].get(code, '')
        if not re.search(r'/ (расходные материалы|вспомогательный материал)|расходные материалы\)', wn): continue
        fam = fam_of(wn); pre = code.rsplit('.', 1)[0]
        pair = [c for c, d2 in vol.items() if c != code and c.rsplit('.', 1)[0] == pre and fam_of(KB['works'].get(c, '')) == fam and d2['volume']]
        if pair: d['volume'] = round(sum(vol[c]['volume'] for c in pair), 4); d['method'] = 'метраж парной работы (' + ', '.join(pair) + ') [В]'
        else: d['notes'].append('парной работы в РВ нет — объём по ведущей группе (клипсы / k)')
    return vol
def distribute(sec, items, bindings, vol):
    """[В 31.10] Кр делится между работами-потребителями своей системы: доля = объём работы × норма класса на единицу работы
    (медиана корректных РВ, work_profiles; иначе 1) / Σ. Возвращает [{id, name, qty, split: [{code, work, qty}], note}]."""
    out = []; norms = KB.get('norms', {})
    for it, b in zip(items, bindings):
        if b.get('role') != 'Кр': continue
        q = fnum(it.get('qty')); h = head(it['name'])
        cons = [c for c in b.get('consumers', []) if vol.get(c, {}).get('volume')]
        if q is None: out.append(dict(id=it.get('id'), name=it['name'], qty=None, split=[], note='количество не задано')); continue
        if not cons:
            out.append(dict(id=it.get('id'), name=it['name'], qty=q, split=[dict(code=b.get('code'), work=KB['works'].get(b.get('code') or '', '')[:90], qty=q)] if b.get('code') else [],
                            note='нет потребителей с объёмом в системе — вся строка в работе по библиотеке/классу (F-KR)')); continue
        w = {c: vol[c]['volume'] * (norms.get((c, h)) or 1.0) for c in cons}
        tot = sum(w.values()) or 1.0
        if nunit(it.get('unit')) == 'шт' and abs(q - round(q)) < 1e-9:
            # шт — целые части методом наибольших остатков [К]
            raw = {c: q * w[c] / tot for c in cons}; base = {c: int(raw[c]) for c in cons}; rest = int(round(q)) - sum(base.values())
            for c in sorted(cons, key=lambda c: -(raw[c] - base[c]))[:rest]: base[c] += 1
            parts = [dict(code=c, work=vol[c]['work'], qty=base[c]) for c in cons if base[c]]
        else:
            parts = [dict(code=c, work=vol[c]['work'], qty=round(q * w[c] / tot, 3)) for c in cons]
            diff = round(q - sum(p_['qty'] for p_ in parts), 3)
            if parts and diff: max(parts, key=lambda p_: p_['qty'])['qty'] = round(max(parts, key=lambda p_: p_['qty'])['qty'] + diff, 3)   # сумма частей = количеству строки
        out.append(dict(id=it.get('id'), name=it['name'], qty=q, split=parts, note='доля = объём работы × норма класса на единицу работы / Σ (п. 0.7)'))
    return out
def rv(sec, items, bindings, vol, dist):
    """Ресурсная ведомость: работы с объёмом и материалами (Кр — частями)."""
    parts = {d['id']: d['split'] for d in dist}
    works = collections.OrderedDict()
    for it, b in zip(items, bindings):
        lines = [(p_['code'], p_['qty']) for p_ in parts.get(it.get('id'), [])] if b.get('role') == 'Кр' and parts.get(it.get('id')) else [(b.get('code'), fnum(it.get('qty')))]
        for code, q in lines:
            if not code: continue
            w = works.setdefault(code, dict(code=code, work=KB['works'].get(code, '')[:120], unit=vol.get(code, {}).get('unit') or KB['kc'].get(code, {}).get('unit', ''),
                                            volume=vol.get(code, {}).get('volume'), method=vol.get(code, {}).get('method', 'объём ведут только Кр-строки — по потребителю'), materials=[]))
            w['materials'].append(dict(id=it.get('id'), name=it['name'], unit=it.get('unit'), qty=q, role=b.get('role')))
    unbound = [dict(id=it.get('id'), name=it['name']) for it, b in zip(items, bindings) if not b.get('code')]
    return dict(works=list(works.values()), unbound=unbound)

if __name__ == '__main__':
    load(sys.argv[1])
    inp = json.load(open(sys.argv[2], encoding='utf-8'))
    for i, it in enumerate(inp['items']): it.setdefault('id', i)
    res = bind(inp['section'], inp['items'], inp.get('object_type'))
    byid = {r['id']: r for r in res}; ordered = [byid.get(it.get('id')) for it in inp['items']]
    for r, it in zip(ordered, inp['items']): r['system_code'] = sys_code(inp['section'], it.get('system'))
    vol = volumes(inp['section'], inp['items'], ordered); dist = distribute(inp['section'], inp['items'], ordered, vol)
    json.dump(dict(rv=rv(inp['section'], inp['items'], ordered, vol, dist), bindings=ordered, volumes=vol, distribution=dist), open(sys.argv[3], 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
    n = len(res); ok = sum(1 for r in res if r['code'] and not r['review']); q = sum(1 for r in res if r['review'])
    nv = sum(1 for v in vol.values() if v['volume']); kr = sum(1 for r in res if r['role'] == 'Кр')
    print(f'строк ЛРВ {n}: готово без проверки {ok}, на проверку {q}; работ {len(vol)}, с объёмом {nv}; строк Кр {kr} (распределено по потребителям: {sum(1 for d in dist if len(d["split"]) > 0)})')
