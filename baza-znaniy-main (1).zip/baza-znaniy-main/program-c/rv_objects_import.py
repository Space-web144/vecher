# -*- coding: utf-8 -*-
"""Справочник объектов и ответственных сметчиков для сайта - из таблицы «Объекты и сметчики» (xlsx).

    python3 rv_objects_import.py <таблица.xlsx> [--out файл.json] [--keep прежний.json]

Лист «Объекты и сметчики»: объект, корпус / участок, код в номере НЗ и сметчики ЦО по системам
(Отопление, Вентиляция, ВК, ЭОМ, СС - основной договор, ДР, РВР; Механизация - один столбец).
На сайте вид работ не делится на ДР и РВР: у ячейки два значения - «осн» (основной договор) и «НЗ»
(ДР, а если пусто - РВР). Столбцы «проверка НЗ» и начальник участка сайту не нужны.
--keep: из прежнего JSON сайта переносятся список исключённых объектов, запасные ответственные
(fallback) и привязки номенклатурных групп 1С (bind) - их правят на сайте, таблица их не знает.
Пишет JSON: {"version", "systems", "objects": [{"name", "code", "buildings": [{"name", "nz",
"resp": {система: {"осн", "НЗ"}}}]}], "excluded", "fallback", "bind"}.
"""
import argparse
import json
import sys
import time

SYSTEMS = ["Отопление", "Вентиляция", "ВК", "ЭОМ", "СС", "Механизация"]

# Как те же объекты называются в папках номенклатурных групп 1С (по выгрузке папок): сайт находит объект
# по началу имени НГ, и имя таблицы не всегда совпадает. Дополняются на сайте (aliases у объекта).
ALIASES = {
    "ЖК 2-ой Иртышский": ["2-Й Иртышский", "ЖК 2-й Иртышский"],
    "Одесская ул., вл.4": ["ЖК Одесская"],
    "ЖК Сиреневый б-р 6.1": ["ЖК Сиреневый бульвар", "Сиреневый б-р"],
    "ЖК Строительный проезд вл.9, стр.1": ["ЖК Строительный проезд, вл. 9"],
    "ЖК Сигнальный 16 СОШ": ["ЖК Сигнальный, 16, стр. 27/1 СОШ"],
    "ЖК Плеханова": ["ЖК Плеханова 11", "Плеханова 11"],
    "ЖК Люблинский парк": ["ЖК Люблинский парк 72"],
}


def _cell(row, col, name):
    i = col.get(name)
    v = row[i] if i is not None and i < len(row) else None
    if v is None:
        return ""
    v = str(v).strip()
    return "" if v == "-" else v


def read_table(path):
    import openpyxl
    wb = openpyxl.load_workbook(path, data_only=True, read_only=True)
    if "Объекты и сметчики" not in wb.sheetnames:
        raise SystemExit("в книге нет листа «Объекты и сметчики»")
    ws = wb["Объекты и сметчики"]
    rows = [list(r) for r in ws.iter_rows(values_only=True)]
    header = [str(h).strip() if h is not None else "" for h in rows[0]]
    col = {h: i for i, h in enumerate(header) if h}
    codes = {}
    if "Объекты" in wb.sheetnames:
        for r in wb["Объекты"].iter_rows(values_only=True):
            if r and r[0] and r[1] and str(r[0]).strip() != "Объект":
                codes[str(r[0]).strip()] = str(r[1]).strip()
    objects = {}
    for r in rows[1:]:
        if not r or not r[0]:
            continue
        name = str(r[0]).strip()
        building = str(r[1] or "").strip() or "(основной)"
        resp = {}
        for system in SYSTEMS:
            if system == "Механизация":
                one = _cell(r, col, "Механизация")
                resp[system] = {"осн": one, "НЗ": one}
            else:
                resp[system] = {"осн": _cell(r, col, "%s основной договор" % system),
                                "НЗ": _cell(r, col, "%s — ДР" % system) or _cell(r, col, "%s — РВР" % system)}
        obj = objects.setdefault(name, {"name": name, "code": codes.get(name, ""), "aliases": ALIASES.get(name, []), "buildings": []})
        obj["buildings"].append({"name": building, "nz": _cell(r, col, "Код в номере НЗ"), "resp": resp})
    return list(objects.values())


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("xlsx")
    ap.add_argument("--out", default="rv/data/rv_objects_table.json")
    ap.add_argument("--keep", default="", help="прежний JSON сайта: исключённые, запасные ответственные, привязки НГ")
    args = ap.parse_args()
    objects = read_table(args.xlsx)
    out = {"version": time.strftime("%Y-%m-%d"), "systems": SYSTEMS, "objects": objects,
           "excluded": [], "fallback": {"ОВВК": "", "ЭОМСС": ""}, "bind": {}}
    if args.keep:
        with open(args.keep, encoding="utf-8") as handle:
            old = json.load(handle)
        for key in ("excluded", "fallback", "bind"):
            if key in old:
                out[key] = old[key]
        was = {o.get("name"): o for o in old.get("objects") or [] if isinstance(o, dict)}
        for o in objects:                   # псевдонимы, добавленные на сайте
            for alias in (was.get(o["name"]) or {}).get("aliases") or []:
                if alias not in o["aliases"]:
                    o["aliases"].append(alias)
    names = {o["name"] for o in objects}
    out["excluded"] = [n for n in out["excluded"] if n in names]
    with open(args.out, "w", encoding="utf-8") as handle:
        json.dump(out, handle, ensure_ascii=False, indent=1)
    logins = sorted({v for o in objects for b in o["buildings"] for s in b["resp"].values() for v in s.values() if v})
    print("объектов %d, корпусов %d, сметчиков %d, исключено %d -> %s" % (
        len(objects), sum(len(o["buildings"]) for o in objects), len(logins), len(out["excluded"]), args.out))


if __name__ == "__main__":
    main()
