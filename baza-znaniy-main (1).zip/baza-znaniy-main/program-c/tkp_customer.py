# -*- coding: utf-8 -*-
"""ТКП заказчика (Excel платформы заказчика, лист «ТКП») - разбор в JSON и сравнение двух версий.

    python3 tkp_customer.py parse <ткп.xlsx> --out <версия.json> [--prev <прежняя.json> --diff-out <изменения.json>]
    python3 tkp_customer.py diff <прежняя.json> <новая.json> [--out <изменения.json>]

Лист «ТКП» (листы «ТКП с формулами» и «Изменения» не нужны: «Изменения» сайт строит сам по двум версиям).
D1 - JSON {"estimateId", "estimateVersionId"}: смета заказчика и её версия. A2 - заголовок, A3 - адрес объекта.
Строка 1 - скрытые ключи платформы (object_element_guid, id, zeroParent_id, material_guid, work_guid, hwd_guid,
cost_item_guid), строки 5-7 - шапка, данные с 8-й. Виды строк:
  блок     - «1. Жилое здание» (номер и название в A, ключ - object_element_guid), итоги блока в M-O и S-U;
  узел     - номер п/п и код ИСР, без единицы;
  работа   - номер п/п, код ИСР и единица;
  материал - номер п/п и единица без кода ИСР, работа - номер без последней части.
Постоянный ключ строки между версиями - zeroParent_id (у материала «работа.материал»); id меняется с версией.
Таблица кончается строкой без номера п/п («Квалификационная и контактная информация»).
Числа: G коэф. расхода, H кол-во БО, I общее кол-во; J/K/L цена ПСПР мат./СМР/всего, M/N/O стоимость ПСПР;
P/Q/R цена подрядчика, S/T/U стоимость подрядчика (с НДС). Ячейки с ошибкой формулы (#VALUE!) - пусто.
Python 3.8, openpyxl.
"""
import argparse
import json
import re
import sys
import time

SHEET = "ТКП"
FIRST_ROW = 8
NUM_RE = re.compile(r"^\d+(\.\d+)*$")
BLOCK_RE = re.compile(r"^(\d+)\.\s+(\S.*)$")

# Буква столбца → поле строки.
TEXT_COLS = {"A": "num", "B": "code", "C": "name", "D": "isr_comment", "E": "comment", "F": "unit"}
NUM_COLS = {
    "G": "coef", "H": "qty_base", "I": "qty",
    "J": "ref_price_mat", "K": "ref_price_smr", "L": "ref_price",
    "M": "ref_cost_mat", "N": "ref_cost_smr", "O": "ref_cost",
    "P": "price_mat", "Q": "price_smr", "R": "price",
    "S": "cost_mat", "T": "cost_smr", "U": "cost",
}
KEY_NAMES = {
    "object_element_guid": "element_guid", "id": "row_id", "zeroParent_id": "uid",
    "material_guid": "material_guid", "work_guid": "work_guid", "hwd_guid": "hwd_guid", "cost_item_guid": "cost_item_guid",
}
# Что сравнивается между версиями (у блока - только итоги).
DIFF_FIELDS = ("code", "name", "unit", "coef", "qty_base", "qty", "ref_price_mat", "ref_price_smr",
               "price_mat", "price_smr", "comment", "isr_comment")
BLOCK_DIFF_FIELDS = ("name", "ref_cost", "cost")


class TkpError(Exception):
    """Файл - не ТКП платформы заказчика (сообщение для пользователя)."""


def _col(letter):
    n = 0
    for ch in letter:
        n = n * 26 + ord(ch) - 64
    return n - 1


def _text(value):
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        value = int(value)
    return re.sub(r"\s+", " ", str(value)).strip()


def _num(value):
    if value is None or isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip().replace(" ", "").replace(" ", "").replace(",", ".")
    if not text or text.startswith("#"):
        return None
    try:
        return float(text)
    except ValueError:
        return None


def _ids(cell):
    """D1: {"estimateId": .., "estimateVersionId": ..} - строкой JSON."""
    text = _text(cell)
    try:
        data = json.loads(text) if text.startswith("{") else {}
    except ValueError:
        data = {}
    est = data.get("estimateId")
    ver = data.get("estimateVersionId")
    return (str(int(est)) if isinstance(est, (int, float)) else _text(est),
            str(int(ver)) if isinstance(ver, (int, float)) else _text(ver))


def _sheet(wb):
    if SHEET in wb.sheetnames:
        return wb[SHEET]
    for ws in wb.worksheets:
        if ws.title.lower().startswith("изменен"):
            continue
        head = [_text(c) for c in next(ws.iter_rows(min_row=5, max_row=5, values_only=True), ())]
        if len(head) > 2 and head[1].startswith("Код узла ИСР"):
            return ws
    raise TkpError("В файле нет листа «ТКП» с шапкой «Номер п/п / Код узла ИСР» - это не ТКП платформы заказчика.")


def parse_rows(rows):
    """rows - значения листа построчно (кортежи с первой строки). Возвращает словарь версии ТКП."""
    rows = [tuple(r) for r in rows]
    if len(rows) < FIRST_ROW:
        raise TkpError("Лист «ТКП» пустой.")
    get = lambda r, letter: r[_col(letter)] if _col(letter) < len(r) else None
    head5 = [_text(c) for c in rows[4]]
    if len(head5) < 3 or not head5[0].startswith("Номер") or not head5[1].startswith("Код узла ИСР"):
        raise TkpError("Шапка листа не та: в строке 5 ждём «Номер п/п» и «Код узла ИСР».")
    keys = {}
    for i, name in enumerate(rows[0]):
        field = KEY_NAMES.get(_text(name))
        if field:
            keys[field] = i
    if "uid" not in keys:
        raise TkpError("Нет скрытой строки ключей платформы (zeroParent_id) - выгрузите ТКП с платформы заново.")
    estimate_id, version_id = _ids(get(rows[0], "D"))
    if not estimate_id or not version_id:
        raise TkpError("В D1 нет идентификаторов сметы и версии (estimateId, estimateVersionId).")
    contractor, inn = "", ""
    for value in rows[4][_col("P"):_col("V")]:
        text = _text(value)
        if not text:
            continue
        if re.fullmatch(r"\d{10}|\d{12}", text):
            inn = inn or text
        elif not contractor:
            contractor = text

    out_rows, blocks = [], []
    block = None
    by_num = {}
    for index in range(FIRST_ROW - 1, len(rows)):
        r = rows[index]
        num = _text(get(r, "A"))
        if not num:
            if block is not None and _text(get(r, "C")) == "" and not any(_text(v) for v in r[:_col("V")]):
                continue
            break
        m = BLOCK_RE.match(num)
        if m and not _text(get(r, "B")):
            guid = _text(r[keys["element_guid"]]) if "element_guid" in keys else ""
            block = dict(kind="block", num=m.group(1), name=m.group(2), uid="b:" + (guid or m.group(1)),
                         element_guid=guid, line=index + 1)
            for letter, field in NUM_COLS.items():
                if field.startswith(("ref_cost", "cost")):
                    block[field] = _num(get(r, letter))
            blocks.append(block)
            out_rows.append(block)
            continue
        if not NUM_RE.match(num):
            break
        if block is None:
            block = dict(kind="block", num=num.split(".")[0], name="Без блока", uid="b:" + num.split(".")[0],
                         element_guid="", line=index + 1)
            blocks.append(block)
            out_rows.append(block)
        row = dict(line=index + 1, block=block["uid"])
        for letter, field in TEXT_COLS.items():
            row[field] = _text(get(r, letter))
        for letter, field in NUM_COLS.items():
            row[field] = _num(get(r, letter))
        for field, i in keys.items():
            row[field] = _text(r[i]) if i < len(r) else ""
        if row["code"]:
            row["kind"] = "work" if row["unit"] else "node"
        else:
            row["kind"] = "material"
        if not row["uid"]:
            row["uid"] = "n:" + num
        parent_num = num.rsplit(".", 1)[0] if "." in num else ""
        parent = by_num.get(parent_num)
        row["parent"] = parent["uid"] if parent else block["uid"]
        if row["kind"] == "material":
            row["work"] = parent["uid"] if parent and parent["kind"] == "work" else ""
        by_num[num] = row
        out_rows.append(row)
    if not blocks:
        raise TkpError("На листе «ТКП» не нашлось ни одного блока («1. Жилое здание»).")
    for b in blocks:
        inner = [r for r in out_rows if r.get("block") == b["uid"]]
        b["works"] = sum(1 for r in inner if r["kind"] == "work")
        b["materials"] = sum(1 for r in inner if r["kind"] == "material")
        b["priced"] = sum(1 for r in inner if r["kind"] == "work" and (r.get("price") or 0) > 0)
    title = _text(rows[1][0]) if len(rows) > 1 and rows[1] else ""
    address = _text(rows[2][0]) if len(rows) > 2 and rows[2] else ""
    works = [r for r in out_rows if r["kind"] == "work"]
    # Пустые поля не храним: версия ТКП на 1800 строк - около 1 МБ вместо полутора.
    out_rows = [{k: v for k, v in r.items() if v is not None and v != ""} for r in out_rows]
    return dict(
        format=1, estimate_id=estimate_id, version_id=version_id, title=title, address=address,
        contractor=contractor, contractor_inn=inn,
        totals=dict(blocks=len(blocks), nodes=sum(1 for r in out_rows if r["kind"] == "node"), works=len(works),
                    materials=sum(1 for r in out_rows if r["kind"] == "material"),
                    works_with_qty=sum(1 for r in works if (r.get("qty") or 0) > 0),
                    ref_cost=_sum(b.get("ref_cost") for b in blocks), cost=_sum(b.get("cost") for b in blocks)),
        rows=out_rows,
    )


def _sum(values):
    total = 0.0
    for v in values:
        total += v or 0.0
    return round(total, 2)


def parse(path):
    try:
        import openpyxl
    except ImportError:
        raise TkpError("На сервере нет openpyxl.")
    try:
        wb = openpyxl.load_workbook(path, read_only=True, data_only=True)
    except Exception as exc:  # битый файл, не xlsx
        raise TkpError("Файл не читается как Excel (.xlsx): %s" % exc)
    try:
        ws = _sheet(wb)
        return parse_rows(ws.iter_rows(values_only=True))
    finally:
        wb.close()


def _same(a, b):
    if isinstance(a, float) or isinstance(b, float):
        if a is None or b is None:
            return a is None and b is None
        return abs(a - b) < 1e-6
    return (a or "") == (b or "")


def diff(old, new):
    """Изменения новой версии против прежней по постоянному ключу строки (uid)."""
    old_rows = {r["uid"]: r for r in old.get("rows") or []}
    new_rows = {r["uid"]: r for r in new.get("rows") or []}
    added, removed, changed = [], [], []
    for uid, row in new_rows.items():
        prev = old_rows.get(uid)
        if prev is None:
            added.append(uid)
            continue
        fields = BLOCK_DIFF_FIELDS if row["kind"] == "block" else DIFF_FIELDS
        delta = {f: [prev.get(f), row.get(f)] for f in fields if not _same(prev.get(f), row.get(f))}
        if row["kind"] != "block" and prev.get("parent") != row.get("parent"):
            delta["parent"] = [prev.get("parent"), row.get("parent")]
        if delta:
            changed.append(dict(uid=uid, fields=delta))
    for uid in old_rows:
        if uid not in new_rows:
            removed.append(uid)
    kinds = lambda uids, rows: {k: sum(1 for u in uids if rows[u]["kind"] == k) for k in ("block", "node", "work", "material")}
    qty_changed = sum(1 for c in changed if "qty" in c["fields"])
    price_changed = sum(1 for c in changed if set(c["fields"]) & {"price_mat", "price_smr"})
    return dict(
        format=1, estimate_id=new.get("estimate_id"), from_version=old.get("version_id"), to_version=new.get("version_id"),
        added=added, removed=removed, changed=changed,
        removed_rows={u: _brief(old_rows[u]) for u in removed},
        summary=dict(added=kinds(added, new_rows), removed=kinds(removed, old_rows), changed=len(changed),
                     qty_changed=qty_changed, price_changed=price_changed),
    )


def _brief(row):
    return {k: row.get(k) for k in ("kind", "num", "code", "name", "unit", "qty", "price_mat", "price_smr", "block", "parent")}


def _write(path, data):
    text = json.dumps(data, ensure_ascii=False, separators=(",", ":"))
    if path:
        with open(path, "w", encoding="utf-8") as fh:
            fh.write(text)
    else:
        sys.stdout.write(text)


def main(argv=None):
    ap = argparse.ArgumentParser(description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd")
    p = sub.add_parser("parse")
    p.add_argument("xlsx")
    p.add_argument("--out")
    p.add_argument("--prev")
    p.add_argument("--diff-out")
    d = sub.add_parser("diff")
    d.add_argument("old")
    d.add_argument("new")
    d.add_argument("--out")
    args = ap.parse_args(argv)
    started = time.time()
    try:
        if args.cmd == "parse":
            data = parse(args.xlsx)
            data["parsed_sec"] = round(time.time() - started, 2)
            _write(args.out, data)
            if args.prev and args.diff_out:
                with open(args.prev, encoding="utf-8") as fh:
                    _write(args.diff_out, diff(json.load(fh), data))
        elif args.cmd == "diff":
            with open(args.old, encoding="utf-8") as fh:
                old = json.load(fh)
            with open(args.new, encoding="utf-8") as fh:
                new = json.load(fh)
            _write(args.out, diff(old, new))
        else:
            ap.print_help()
            return 2
    except TkpError as exc:
        sys.stdout.write(json.dumps(dict(error=str(exc)), ensure_ascii=False))
        return 3
    return 0


if __name__ == "__main__":
    sys.exit(main())
