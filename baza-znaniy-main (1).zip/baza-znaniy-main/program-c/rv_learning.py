# -*- coding: utf-8 -*-
"""
Память решений инженеров для агента РВ.

Инженер проверяет построенную РВ на сайте: где агент ошибся — указывает
работу (и роль), остальные строки считаются подобранными верно. Решения
копятся в web/data/rv_learning.json (на сервере, в репозиторий не попадает)
и применяются при каждой следующей привязке сразу после bind.bind():

  * исправление — строка с тем же именем в том же разделе и системе получает
    код инженера, уверенность 100 %, без проверки;
  * подтверждение — если агент выбрал тот же код, уверенность не ниже 95 %
    и строка не идёт «на проверку»; если другой — код инженера, как исправление.

Ключ записи: раздел | система | нормализованное имя строки ЛРВ. Решение для
другой системы того же раздела переносится, когда у кода есть такой же
вариант в ветке системы строки (ВК: 6.2.3.1.<ветка>.…).

Файл пишется под блокировкой fcntl — одновременно могут завершаться
несколько задач.

Каждая запись помнит, из какой РВ она пришла (token, source) и что было по
этому ключу до неё (prev, один шаг). forget() откатывает решения одной РВ —
например, согласованной для пробы: записи этой РВ удаляются, а где до неё
было другое решение — оно возвращается.
"""
import datetime
import json
import os

try:
    import fcntl
except ImportError:  # Windows при отладке
    fcntl = None

from rv_common import norm

VERSION = 1
CONFIRM_BELOW = 0.95      # подтверждение запоминается только у строк, где агент не был уверен
ROLES = ("В", "С-В", "С-С", "Р", "Кр")
DROP_FLAGS = ("F-SYS", "F-DEPR", "F-DN", "F-MAT", "F-GRP", "F-KR", "F-CTX", "F-ALT")


def key_of(section, system, name):
    return "%s|%s|%s" % (section or "", norm(system or ""), norm(name))


def load(path):
    """Записи из файла; нет файла или он битый — пусто."""
    if not path or not os.path.exists(path):
        return {}
    try:
        with open(path, encoding="utf-8") as handle:
            data = json.load(handle)
    except (OSError, ValueError):
        return {}
    entries = data.get("entries") if isinstance(data, dict) else None
    return entries if isinstance(entries, dict) else {}


def decisions_from_feedback(result, feedback, confirm_rest=True):
    """Решения инженера по результату (out.json) и его ответу
    {corrections: [{id, code, role}], confirm_rest: bool}.
    Исправление с тем же кодом, что у агента, — подтверждение. Подтверждаются
    только строки с кодом, в которых агент не был уверен (на проверку или
    уверенность < CONFIRM_BELOW): остальное запоминать незачем.
    confirm_rest=False — у РВ с указаниями только для неё (web_rv_run.local_input): подтверждения «остального»
    не запоминаются, только явные исправления сметчика; строки, изменённые моделью по указаниям, и принятые
    пачкой предложения модели (via=model) — тоже нет.
    Возвращает список {key, section, system, name, code, role, kind}."""
    by_id = {}
    for block in result.get("elements") or []:
        for binding in block.get("bindings") or []:
            by_id[str(binding["id"])] = (block.get("section"), binding)
    decided = set()
    out = []
    for fix in feedback.get("corrections") or []:
        section, binding = by_id.get(str(fix.get("id")), (None, None))
        if binding is None or not section or binding.get("split_of") is not None:
            continue        # часть строки, разбитой на несколько работ, - решение по ней не обобщается на имя
        if not confirm_rest and fix.get("via") == "model":
            decided.add(str(binding["id"]))
            continue        # РВ с указаниями: принятое пачкой из предложений модели - по указаниям, не ручное решение
        code = str(fix.get("code") or "").strip() or (binding.get("code") or "")
        coef = _coef(fix.get("coef"))
        if not code:
            continue
        role = str(fix.get("role") or binding.get("role") or "").strip()
        if role not in ROLES:
            role = binding.get("role") if binding.get("role") in ROLES else "В"
        same = code == (binding.get("code") or "") and role == (binding.get("role") or "")
        decision = dict(key=key_of(section, binding.get("system"), binding["name"]), section=section,
                        system=binding.get("system") or "", name=binding["name"], code=code, role=role,
                        kind="confirmed" if same else "correction")
        if coef is not None:
            decision["coef"] = coef
        out.append(decision)
        decided.add(str(binding["id"]))
    if feedback.get("confirm_rest") and confirm_rest:
        for item_id, (section, binding) in by_id.items():
            if item_id in decided or not section or not binding.get("code"):
                continue
            if binding.get("learned") == "correction" or binding.get("split_of") is not None:
                continue        # уже решение инженера (или часть разбитой строки) — повторно не считаем
            if not binding.get("review") and (binding.get("confidence") or 0) >= CONFIRM_BELOW:
                continue
            out.append(dict(key=key_of(section, binding.get("system"), binding["name"]), section=section,
                            system=binding.get("system") or "", name=binding["name"], code=binding["code"],
                            role=binding.get("role") or "В", kind="confirmed"))
    return out


def _coef(value):
    """Коэффициент инженера: число ≥ 0 или None."""
    if value is None or value == "":
        return None
    try:
        number = float(str(value).replace(",", ".").replace(" ", ""))
    except ValueError:
        return None
    return number if 0 <= number < 1e9 else None


def _locked(path, change):
    """Прочитать записи файла памяти под блокировкой, изменить change(entries) и записать."""
    directory = os.path.dirname(path)
    if directory and not os.path.isdir(directory):
        os.makedirs(directory, exist_ok=True)
    today = datetime.date.today().isoformat()
    with open(path, "a+", encoding="utf-8") as handle:
        if fcntl is not None:
            fcntl.flock(handle, fcntl.LOCK_EX)
        try:
            handle.seek(0)
            raw = handle.read()
            try:
                data = json.loads(raw) if raw.strip() else {}
            except ValueError:
                data = {}
            entries = data.get("entries") if isinstance(data, dict) and isinstance(data.get("entries"), dict) else {}
            result = change(entries)
            payload = dict(version=VERSION, updated=today, entries=entries)
            handle.seek(0)
            handle.truncate()
            json.dump(payload, handle, ensure_ascii=False, indent=0)
            handle.flush()
        finally:
            if fcntl is not None:
                fcntl.flock(handle, fcntl.LOCK_UN)
    return result


def forget(path, token="", source=""):
    """Откатить решения одной РВ: записи с этим token (или, у записей до появления token, с этим source)
    удаляются, а если до них по ключу было другое решение (prev) — оно возвращается.
    Возвращает (удалено, возвращено прежних)."""
    if not path or not os.path.exists(path) or not (token or source):
        return 0, 0

    def mine(entry):
        if token and entry.get("token"):
            return entry.get("token") == token
        return bool(source) and entry.get("source") == source

    def change(entries):
        removed = restored = 0
        for key in list(entries):
            entry = entries[key]
            if not isinstance(entry, dict):
                continue
            prev = entry.get("prev")
            if not mine(entry):
                if isinstance(prev, dict) and mine(prev):
                    entry.pop("prev")        # решение из другой РВ остаётся, но откатываться к этой РВ уже некуда
                continue
            # Прежнее решение возвращаем, только если оно не из этой же РВ.
            if isinstance(prev, dict) and prev.get("code") and not mine(prev):
                entries[key] = prev
                restored += 1
            else:
                del entries[key]
                removed += 1
        return removed, restored

    return _locked(path, change)


def merge(path, decisions, user="", source="", token=""):
    """Записать решения в файл памяти. Последнее решение по ключу побеждает;
    count — сколько раз подряд выбран этот же код. token и source — из какой РВ решение,
    prev — что было по ключу до неё (для отката forget). Возвращает (исправлений, подтверждений)."""
    if not path or not decisions:
        return 0, 0
    today = datetime.date.today().isoformat()

    def change(entries):
        corrected = confirmed = 0
        for decision in decisions:
            old = entries.get(decision["key"]) or {}
            same = old.get("code") == decision["code"] and old.get("role") == decision["role"]
            entry = dict(code=decision["code"], role=decision["role"], kind=decision["kind"],
                         count=(int(old.get("count") or 0) + 1) if same else 1,
                         section=decision["section"], system=decision["system"], name=decision["name"],
                         user=user or old.get("user") or "", updated=today, source=source or old.get("source") or "",
                         token=token or "")
            if same and old.get("kind") == "correction":
                entry["kind"] = "correction"      # подтверждение исправления остаётся исправлением
            if decision.get("coef") is not None:
                entry["coef"] = decision["coef"]
            elif same and old.get("coef") is not None:
                entry["coef"] = old["coef"]       # коэффициент остаётся, пока работа та же
            # Прежнее решение — для отката; повторная проверка той же РВ его не затирает.
            if old and (not token or old.get("token") != token):
                entry["prev"] = {k: v for k, v in old.items() if k != "prev"}
            elif old.get("prev"):
                entry["prev"] = old["prev"]
            entries[decision["key"]] = entry
            if decision["kind"] == "correction":
                corrected += 1
            else:
                confirmed += 1
        return corrected, confirmed

    return _locked(path, change)


def _branch_code(section, code, sysc):
    """Код того же варианта в ветке sysc: у ВК / ОВ2 / ЭОМ / СС ветка — 5-й сегмент."""
    parts = code.split(".")
    if len(parts) < 6 or not sysc or sysc == "99":
        return None
    if section in ("ВК", "ОВ2", "ЭОМ", "СС"):
        if parts[4] == sysc:
            return code
        return ".".join(parts[:4] + [sysc] + parts[5:])
    return None


def _kind_of_work(name):
    """Род работы — первые два слова названия: «прокладка трубопроводов», «изоляция трубопроводов», «монтаж лотка»."""
    return " ".join(norm(name).split()[:2])


OWN_TOKEN = ""      # token РВ, которую строит этот процесс (web_rv_run.main): её решения сметчика — «свои»


def apply(entries, section, items, bindings, works, fam_of, sys_code, log=None, own_token=None):
    """Применить память к привязкам блока (после bind.bind, до объёмов).
    Строка-крепёж (Кр) делится между работами-потребителями; если сметчик отнёс её к другой работе, она идёт туда
    целиком: в этой же РВ (own_token — её token) — всегда, по памяти из других РВ — когда работа не из семей
    потребителей (сметчик решил, что это не крепёж труб: «скоба для изоляции» → изоляция), тогда роль — Р.
    Возвращает dict(corrected, confirmed, transferred)."""
    stats = dict(corrected=0, confirmed=0, transferred=0)
    if own_token is None:
        own_token = OWN_TOKEN
    if not entries:
        return stats
    by_name = {}
    for key, entry in entries.items():
        sec, _, name = key.partition("|")
        _, _, name = name.partition("|")
        if sec == section:
            by_name.setdefault(name, []).append(entry)
    for item, binding in zip(items, bindings):
        if binding.get("role") == "?" and not binding.get("code") and binding.get("fcodes") == ["F-CTX"]:
            continue
        name = norm(item["name"])
        entry = entries.get(key_of(section, item.get("system"), item["name"]))
        transferred = False
        if entry is None:
            sysc = sys_code(section, item.get("system"))
            for other in by_name.get(name, []):
                if not sysc or not str(other.get("code") or "").startswith("6."):
                    continue        # перенос между системами — по веткам кода 6.2.3; у кода 12 (РВР) веток систем нет
                code = _branch_code(section, other["code"], sysc)
                if code and code in works and fam_of(works[code]) == fam_of(works.get(other["code"], "")):
                    entry = dict(other, code=code)
                    transferred = True
                    break
        if entry is None:
            continue
        if entry.get("role") == "Кр" and entry.get("kind") != "correction" and binding.get("role") != "Кр":
            continue        # подтверждена прежняя разбивка крепежа, а по правилу строка теперь не крепёж — правило новее
        code = entry.get("code")
        if code not in works:
            continue        # код ушёл из справочника — память по нему не применяем
        role = entry.get("role") if entry.get("role") in ROLES else (binding.get("role") or "В")
        when = entry.get("updated") or ""
        who = (" %s" % entry["user"]) if entry.get("user") else ""
        times = int(entry.get("count") or 1)
        same = code == binding.get("code") and role == binding.get("role")
        if entry.get("coef") is not None and not transferred:
            binding["coef_user"] = float(entry["coef"])
        if same:
            binding["confidence"] = max(float(binding.get("confidence") or 0), CONFIRM_BELOW)
            binding["review"] = False
            binding["learned"] = "confirmed"
            binding["learned_token"] = entry.get("token") or ""
            binding["source"] = (binding.get("source") or "") + "; подтверждено инженером%s %s" % (who, when)
            stats["confirmed"] += 1
        else:
            binding["code"] = code
            binding["work"] = works[code][:100]
            binding["family"] = fam_of(works[code])
            binding["role"] = role
            binding["confidence"] = 1.0
            binding["review"] = False
            binding["deprecated_code"] = None
            binding["learned"] = "correction"
            binding["learned_token"] = entry.get("token") or ""      # из какой РВ решение (своя задача — решение этой проверки)
            binding["source"] = "решение инженера%s %s%s%s" % (
                who, when, (" (×%d)" % times) if times > 1 else "",
                " — перенесено из системы «%s»" % entry.get("system") if transferred else "")
            binding["flags"] = [f for f in (binding.get("flags") or []) if not f.startswith(DROP_FLAGS)]
            binding["fcodes"] = sorted({f.split(":")[0] for f in binding["flags"] if f.startswith("F-")})
            if role == "Кр" and entry.get("kind") == "correction":
                # Сметчик выбрал работу сам — вся строка под ней, а не разбивка крепежа по трубам. Работа другого
                # рода, чем потребители крепежа («Изоляция…» при «Прокладка трубопроводов…»), — это уже не крепёж: Р.
                consumers = binding.get("consumers") or []
                kin = {_kind_of_work(works.get(c, "")) for c in consumers}
                foreign = _kind_of_work(works[code]) not in kin
                if foreign or (own_token and entry.get("token") == own_token):
                    binding["consumers"] = [code]
                    if foreign:
                        binding["role"] = role = "Р"
            if role != "Кр":
                binding.pop("consumers", None)
            stats["corrected"] += 1
        if transferred:
            stats["transferred"] += 1
    if log and (stats["corrected"] or stats["confirmed"]):
        log("память решений (%s): исправлено %d, подтверждено %d%s" % (
            section, stats["corrected"], stats["confirmed"],
            (", перенесено из других систем %d" % stats["transferred"]) if stats["transferred"] else ""))
    return stats


def summary(entries):
    """Сколько решений накоплено — для сводки."""
    kinds = {}
    for entry in entries.values():
        kinds[entry.get("kind", "?")] = kinds.get(entry.get("kind", "?"), 0) + 1
    return dict(total=len(entries), corrections=kinds.get("correction", 0), confirmations=kinds.get("confirmed", 0))


__all__ = ["key_of", "load", "decisions_from_feedback", "merge", "apply", "summary", "ROLES", "CONFIRM_BELOW"]
