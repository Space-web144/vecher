#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Агент РВ для сайта: ЛРВ из 1С → ресурсная ведомость (РВ).

Две фазы, обе запускаются из PHP в фоне.

Фаза «mark» (web/rv_process.php) — чтение и разметка:
    python3 web_rv_run.py --phase mark --status-file ... --work-file ... \\
        --section ВК --object-type жилой [--default-system В2] [--credentials ...] -- лрв.xlsx
  1. чтение ЛРВ: строки материалов и заголовки групп (rv_input.py);
  2. разметка заголовков — какая группа задаёт систему, какая элемент
     (модель, rv_agent.mark_headers; без модели — по кодам систем в тексте);
  3. всё прочитанное и разметка — в --work-file, статус awaiting_confirm:
     инженер на rv_status.php проверяет и правит разметку (A2: систему
     агент не угадывает — спрашивает один раз).

Фаза «bind» (web/rv_confirm.php) — по подтверждённой разметке:
    python3 web_rv_run.py --phase bind --status-file ... --work-file ... \\
        --out-xlsx ... --out-json ... [--credentials ...]
  4. привязка строк к работам ИСР и расчёт объёмов — инструмент комплекта
     rv/bind.py, отдельно по каждому элементу (A16);
  5. проверка строк «на проверку» по карточке раздела (модель,
     rv_agent.review_rows) — рекомендации, РВ они не меняют;
  6. книга Excel (rv_output.py) и JSON с результатом.

Статус пишется в --status-file на каждом шаге: страница rv_status.php
показывает его и по нему же понимает, что процесс жив.
"""
import argparse
import json
import os
import re
import sys
import time
import traceback

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
for path in (HERE, ROOT, os.path.join(HERE, "rv")):
    if path not in sys.path:
        sys.path.insert(0, path)

# До тяжёлых импортов (openpyxl, данные агента): снять зависшие запуски, отметить старт и
# понятно сообщить о нехватке памяти на хостинге — rv_startup использует только стандартную библиотеку.
import rv_startup  # noqa: E402

rv_startup.limit_threads()      # до openpyxl: без numpy и с одним потоком вычислений (лимит потоков хостинга)
if __name__ == "__main__":
    _STATUS_FILE = rv_startup.arg_value(sys.argv, "--status-file")
    rv_startup.stop_stale_runs(log=lambda message: print("[%s] %s" % (time.strftime("%H:%M:%S"), message), flush=True))
    rv_startup.mark_started(_STATUS_FILE)
try:
    if os.environ.get("RV_SIMULATE_STARTUP_OOM"):        # для теста пути «не хватило памяти на старте»
        raise ImportError("libtest.so: failed to map segment from shared object")
    if os.environ.get("RV_SIMULATE_STARTUP_ERROR"):      # для теста пути «сбой на старте»
        raise ImportError("No module named 'libtest'")
    import rv_input  # noqa: E402
    import rv_output  # noqa: E402
    import rv_agent  # noqa: E402
    import rv_form  # noqa: E402
    import rv_learning  # noqa: E402
    import rv_extra  # noqa: E402
    import rv_audit  # noqa: E402
except Exception as _exc:  # noqa: BLE001 — любой сбой на старте должен попасть в статус
    if __name__ != "__main__":
        raise
    if rv_startup.is_memory_failure(_exc):
        sys.exit(rv_startup.startup_failed(_STATUS_FILE, _exc))
    sys.exit(rv_startup.startup_error(_STATUS_FILE, _exc, traceback.format_exc()))

DATA_DIR = os.path.join(HERE, "rv", "data")
SAMPLE_FOR_MARKING = 25
REVIEW_MAX = 400       # строк на проверку моделью за один запуск (сначала без работы, затем по уверенности)


def _write(path, payload):
    """JSON атомарно; путь на .gz — сжато (результат и строки формы весят мегабайты, сжатые — в 15 раз меньше)."""
    tmp = path + ".tmp"
    if path.endswith(".gz"):
        import gzip
        with gzip.open(tmp, "wt", encoding="utf-8", compresslevel=6) as handle:
            json.dump(payload, handle, ensure_ascii=False)
    else:
        with open(tmp, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, ensure_ascii=False)
    os.replace(tmp, path)


def _read(path):
    if path.endswith(".gz"):
        import gzip
        with gzip.open(path, "rt", encoding="utf-8") as handle:
            return json.load(handle)
    with open(path, encoding="utf-8") as handle:
        return json.load(handle)


class Status(object):
    def __init__(self, path, started, keep_log=False):
        self.path = path
        self.started = started
        self.log_lines = []
        self.previous = {}          # прежний статус (feedback, summary…) — пересборка по кнопке сохраняет согласование
        if keep_log:
            # Вторая фаза продолжает журнал первой: на странице видно всё по порядку.
            try:
                with open(path, encoding="utf-8") as handle:
                    data = json.load(handle)
                if isinstance(data, dict):
                    self.previous = data
                    self.log_lines = list(data.get("log") or [])
            except (OSError, ValueError):
                pass

    def update(self, state, stage, **extra):
        self._last = (state, stage, extra)
        payload = dict(state=state, stage=stage, started=self.started, updated=int(time.time()),
                       log=self.log_lines[-30:])
        payload.update(extra)
        _write(self.path, payload)

    def touch(self):
        """Признак жизни без смены шага: модель на xhigh готовит ответ минутами, а страница считает
        процесс оборвавшимся после RV_STALL_SEC молчания (web/config.php)."""
        last = getattr(self, "_last", None)
        if last is not None:
            self.update(last[0], last[1], **last[2])

    def log(self, message):
        line = "[%s] %s" % (time.strftime("%H:%M:%S"), message)
        self.log_lines.append(line)
        print(line, flush=True)


def _memory():
    """Пик памяти процесса — для журнала: на хостинге процесс могут убить за превышение."""
    try:
        import resource
        return "память %d МБ" % (resource.getrusage(resource.RUSAGE_SELF).ru_maxrss // 1024)
    except Exception:  # noqa: BLE001
        return "память —"


def _short(exc, limit=160):
    """Первая строка ошибки без тела ответа API — для сводки."""
    text = str(exc).split("{", 1)[0].strip().rstrip(".:")
    return text[:limit] if text else type(exc).__name__


def _client(credentials, log):
    """Клиент модели или None, если ключ недоступен — агент работает без неё."""
    try:
        from common.anthropic_client import AnthropicClient
        return AnthropicClient(credentials_file=credentials, log=log)
    except Exception as exc:  # noqa: BLE001 — любая причина: без модели работа продолжается
        log("модель недоступна: %s" % exc)
        return None


def audit_input(args):
    """Сверка РВ из 1С: «РаботыРВ» и документ из <токен>_audit.json рядом с файлом статуса (web/1c_rv.php
    в режиме «Сверка»). Нет файла — обычная ЛРВ: None."""
    status_file = getattr(args, "status_file", "") or ""
    if not status_file.endswith("_status.json"):
        return None
    data = _read_json_file(status_file[:-len("_status.json")] + "_audit.json")
    return data if isinstance(data, dict) else None


def smeta_input(args, works=None, section=None, sysc=None):
    """Работы сметы из 1С (сметные позиции с кодами ИСР и объёмами; web/1c_rv.php, поле «РаботыСметы») —
    файл <токен>_smeta.json рядом с файлом статуса. Возвращает {код ИСР: {name, unit, qty, guid}} или {}.
    Кода ИСР у работы нет (в 1С у номенклатуры-работы не заполнен «СИТИ_КодИерархия») — код по наименованию
    работы, как у спецификаций (spec_code_of); не нашлось — работа пропускается."""
    status_file = getattr(args, "status_file", "") or ""
    if not status_file.endswith("_status.json"):
        return {}
    data = _read_json_file(status_file[:-len("_status.json")] + "_smeta.json")
    out = {}
    for work in (data or {}).get("works") or [] if isinstance(data, dict) else []:
        if not isinstance(work, dict):
            continue
        name = str(work.get("Наименование") or "").strip()
        code = str(work.get("Код") or work.get("КодИСР") or "").strip()
        if not code and works:
            code = spec_code_of(name, works, section, sysc)
        if code:
            out[code] = dict(name=name, unit=str(work.get("ЕдиницаИзмерения") or "").strip(),
                             unit_guid=str(work.get("ЕдиницаИзмеренияGUID") or "").strip(),
                             qty=rv_audit._num(work.get("Количество")), guid=str(work.get("СметнаяПозицияGUID") or "").strip(),
                             node=str(work.get("УИДУзлаДерева") or "").strip(),
                             work_guid=str(work.get("РаботаGUID") or "").strip(),
                             position=str(work.get("СметнаяПозиция") or "").strip(), position_code=str(work.get("КодПозиции") or "").strip(),
                             note=str(work.get("Примечание") or "").strip()[:500])
    return out


def work_notes(smeta, previous, feedback_file):
    """Примечания к работам: из сметы 1С (поле «Примечание» сметной позиции), поверх — примечания сметчика
    с прежней пересборки (result['work_notes']) и из текущей проверки (feedback['work_notes']: {код ИСР: текст}).
    {код: {text, by}} — by: «1С» или логин сметчика. Уходят в 1С полем «Примечание» сметной позиции (sopost_1c)."""
    out = {}
    for code, work in (smeta or {}).items():
        if work.get("note"):
            out[code] = dict(text=work["note"], by="1С")
    for code, note in ((previous or {}).get("work_notes") or {}).items():
        if isinstance(note, dict) and note.get("by") and note.get("by") != "1С":
            out[str(code)] = dict(text=str(note.get("text") or "")[:500], by=str(note["by"]))
    if feedback_file and os.path.exists(feedback_file):
        feedback = _read_json_file(feedback_file) or {}
        user = str(feedback.get("user") or "сметчик")
        for code, text in (feedback.get("work_notes") or {}).items():
            text = str(text or "").strip()[:500]
            code = str(code)
            if text:
                out[code] = dict(text=text, by=user)
            elif code in out and out[code]["by"] != "1С":
                del out[code]           # сметчик стёр своё примечание; примечание 1С стереть нельзя
            elif code in out:
                out[code] = dict(text="", by=user)
    return {code: note for code, note in out.items() if note["text"] or note["by"] != "1С"}


SPLIT_ID_STEP = 1000000     # id части строки: id + SPLIT_ID_STEP * k (k = 1, 2, …); первая часть оставляет id


def engineer_splits(previous, feedback_file):
    """Разбиения строк ЛРВ на несколько работ по решению сметчика: из прежней пересборки (result['splits']) и из
    текущей проверки (feedback['splits']: {id: [{code, qty}]}; пустой список — убрать разбиение).
    {id (int): {parts: [{code, qty}], by}}."""
    out = {}
    for key, entry in ((previous or {}).get("splits") or {}).items():
        try:
            parts = [dict(code=str(p.get("code") or ""), qty=float(p.get("qty"))) for p in (entry or {}).get("parts") or []]
        except (TypeError, ValueError, AttributeError):
            continue
        if parts:
            out[int(key)] = dict(parts=parts, by=str((entry or {}).get("by") or ""))
    if feedback_file and os.path.exists(feedback_file):
        feedback = _read_json_file(feedback_file) or {}
        user = str(feedback.get("user") or "сметчик")
        for key, parts in (feedback.get("splits") or {}).items():
            try:
                item_id = int(key)
                parts = [dict(code=str(p.get("code") or ""), qty=float(p.get("qty"))) for p in parts or []]
            except (TypeError, ValueError, AttributeError):
                continue
            if parts:
                out[item_id] = dict(parts=parts, by=user)
            else:
                out.pop(item_id, None)
    return out


def engineer_works(previous, feedback_file):
    """Работы, добавленные сметчиком на странице проверки («Добавить работу»: работа без материалов, объём вручную),
    и объём, заданный вручную у работы «добавлено агентом»: из прежней пересборки (result['added_works']) и из
    текущей проверки (feedback['added_works']: {код ИСР: объём}; пусто или 0 — убрать). {код: {qty, by}}."""
    out = {}
    for code, entry in ((previous or {}).get("added_works") or {}).items():
        qty = bind_fnum((entry or {}).get("qty")) if isinstance(entry, dict) else None
        if qty and qty > 0:
            out[str(code)] = dict(qty=qty, by=str(entry.get("by") or ""))
    if feedback_file and os.path.exists(feedback_file):
        feedback = _read_json_file(feedback_file) or {}
        user = str(feedback.get("user") or "сметчик")
        for code, qty in (feedback.get("added_works") or {}).items():
            qty = bind_fnum(qty)
            if qty and qty > 0:
                out[str(code)] = dict(qty=round(qty, 4), by=user)
            else:
                out.pop(str(code), None)
    return out


MANUAL_METHOD = "объём задан сметчиком"


def apply_engineer_works(section, rv_works, added, works, kc, taken):
    """Работы сметчика в блок РВ раздела section: новая — работой без материалов с его объёмом; работа «добавлено
    агентом» — его объём вместо расчёта. Работа с материалами объём считает по строкам — такая не трогается.
    taken — коды, уже поставленные в другой блок (одна работа — в один блок). Возвращает (добавлено, [замечания])."""
    from rv_common import sec_of
    have = {w["code"]: w for w in rv_works}
    count, notes = 0, []
    for code, entry in sorted(added.items()):
        if code in taken or code not in works or sec_of(code) != section:
            continue
        taken.add(code)
        note = "добавлено сметчиком%s: объём вручную" % (" " + entry["by"] if entry.get("by") else "")
        work = have.get(code)
        if work is not None and work.get("materials"):
            notes.append("Работа %s добавлена сметчиком, но в РВ она уже есть со строками ЛРВ — объём считается по строкам." % code)
            continue
        if work is None:
            work = dict(code=code, work=works.get(code, "")[:120], unit=(kc.get(code) or {}).get("unit", ""), materials=[])
            rv_works.append(work)
        work.update(volume=round(entry["qty"], 4), method=MANUAL_METHOD, auto=False, manual=True, note=note)
        count += 1
    return count, notes


def onec_signature(export):
    """То, что 1С сделает с РВ (export_1c): по работе — объём; по строке под работой — количество, коэффициент,
    действие и уменьшение. {ключ: значение}; по разнице двух подписей пересборка решает, снимать ли согласование."""
    sign = {}
    for work in (export or {}).get("Работы") or []:
        code = str(work.get("КодИСР") or "")
        volume = rv_audit._num(work.get("Объем"))
        sign[("работа", code)] = round(volume, 3) if volume is not None else None
        for row in work.get("Материалы") or []:
            key = ("строка", code, str(row.get("ИдентификаторСтроки") or row.get("СтрокаЛРВ") or row.get("Номенклатура") or ""),
                   str(row.get("Часть") or ""))
            qty, coef = rv_audit._num(row.get("Количество")), rv_audit._num(row.get("Коэффициент"))
            sign[key] = (round(qty, 4) if qty is not None else None, round(coef, 6) if coef is not None else None,
                         str(row.get("Действие") or ""), round(rv_audit._num(row.get("Уменьшение")) or 0, 4))
    for row in (export or {}).get("БезРаботы") or []:
        sign[("без работы", str(row.get("ИдентификаторСтроки") or row.get("СтрокаЛРВ") or ""))] = True
    return sign


def signature_changes(old, new):
    """Сколько работ и строк РВ для 1С изменилось: dict(works, rows)."""
    keys = set(old) | set(new)
    changed = [key for key in keys if old.get(key, "∅") != new.get(key, "∅")]
    return dict(works=sum(1 for key in changed if key[0] == "работа"), rows=sum(1 for key in changed if key[0] != "работа"))


REDUCED_SUFFIX = "|разнесено"      # идентификатор строки «разнесено в 1С»: <GUID номенклатуры>|разнесено (web/1c_rv.php)


def reductions_of(packet):
    """Уменьшения ЛРВ в пакете 1С: строки «Строки» (непривязанные МПЗ) с отрицательным остатком — материала в ЛРВ
    стало меньше, чем уже разнесено в 1С под работы. Возвращает [dict(uid, name, unit, qty)]: uid — GUID номенклатуры
    (как у строки «разнесено в 1С» без суффикса), qty > 0 — на сколько уменьшить; одна номенклатура — одна запись."""
    rows = None
    if isinstance(packet, dict):
        for key, value in packet.items():
            if rv_input._json_key(key) in ("строки", "rows") and isinstance(value, list):
                rows = value
    found = {}
    for row in rows or []:
        if not isinstance(row, dict):
            continue
        fields = {rv_input._json_key(key): value for key, value in row.items()}
        qty = rv_audit._num(fields.get("колво") if fields.get("колво") is not None else fields.get("количество"))
        if qty is None or qty >= 0:
            continue
        name = str(fields.get("номенклатура") or fields.get("наименование") or "").strip()
        uid = str(fields.get("номенклатураguid") or fields.get("идентификаторстроки") or "").strip() or name.lower()
        if not uid:
            continue
        entry = found.setdefault(uid.lower(), dict(uid=uid, name=name, qty=0.0,
                                                   unit=str(fields.get("единицаизмерения") or fields.get("единица") or "").strip()))
        entry["qty"] = round(entry["qty"] - qty, 4)
    return list(found.values())


def packet_input(args):
    """Пакет, как его прислала 1С (<токен>_in.json.gz рядом со статусом); нет или не читается — None."""
    status_file = getattr(args, "status_file", "") or ""
    if not status_file.endswith("_status.json"):
        return None
    path = status_file[:-len("_status.json")] + "_in.json.gz"
    if not os.path.exists(path):
        return None
    try:
        return _read(path)
    except (OSError, ValueError, EOFError):
        return None


def reductions_input(args):
    """Уменьшения из пакета, как его прислала 1С (packet_input): читаются при каждой привязке — и у РВ, собранных
    до появления уменьшений, они появляются при пересборке. Нет пакета — []."""
    packet = packet_input(args)
    return reductions_of(packet) if packet is not None else []


def onec_sums_of(packet):
    """Суммы разнесённого в 1С по материалам: строки материалов «МассивРабот» обработки (или «Материалы» сметных
    позиций) с разнесённым количеством > 0 — «Сумма» и «СуммаВСмету» по GUID номенклатуры (без GUID — по имени).
    Возвращает {ключ в нижнем регистре: (сумма, сумма в смету)}; сумм в пакете нет — {}."""
    lines = []
    if isinstance(packet, dict):
        for key, value in packet.items():
            name = rv_input._json_key(key)
            if name in ("массивработ", "деревосоответствия") and isinstance(value, list):
                lines.extend(value)
            elif name == "сметныепозиции" and isinstance(value, list):
                for position in value:
                    for pkey, materials in (position.items() if isinstance(position, dict) else ()):
                        if rv_input._json_key(pkey) == "материалы" and isinstance(materials, list):
                            lines.extend(materials)
    sums = {}
    found = False
    for line in lines:
        if not isinstance(line, dict):
            continue
        fields = {rv_input._json_key(key): value for key, value in line.items()}
        name = str(fields.get("номенклатура") or "").strip()
        qty = rv_audit._num(fields.get("колвоматериала") if fields.get("колвоматериала") is not None else
                            fields.get("колво") if fields.get("колво") is not None else fields.get("количество"))
        if not name or not qty or qty <= 0:
            continue
        key = (str(fields.get("номенклатураguid") or fields.get("номенклатура_guid") or "").strip() or name).lower()
        total = rv_audit._num(fields.get("сумма") if fields.get("сумма") is not None else fields.get("суммаматериала"))
        smeta = rv_audit._num(fields.get("суммавсмету") if fields.get("суммавсмету") is not None else fields.get("суммаматериалавсмету"))
        found = found or total is not None or smeta is not None
        was = sums.get(key, (0.0, 0.0))
        sums[key] = (round(was[0] + (total or 0), 2), round(was[1] + (smeta or 0), 2))
    return sums if found else {}


def _unit_key(name):
    """Единица для поиска её GUID: без регистра, пробелов и точек («пог. м» = «пог.м»)."""
    return re.sub(r"[\s.]+", "", str(name or "").lower().replace("²", "2").replace("³", "3"))


def unit_guids_of(packet):
    """GUID единиц измерения из пакета 1С: {"position": {GUID сметной позиции: GUID единицы}, "name": {единица: GUID}} —
    из «СметныеПозиции» (у позиции) и из всех строк с «ЕдиницаИзмерения» и «ЕдиницаИзмеренияGUID» («Строки»,
    «МассивРабот», материалы позиций). Единица с разными GUID в пакете в «name» не попадает."""
    by_position, by_name, clash = {}, {}, set()

    def note(fields):
        unit = _unit_key(fields.get("единицаизмерения"))
        guid = str(fields.get("единицаизмеренияguid") or fields.get("единицаизмерения_guid") or "").strip()
        if not unit or not guid:
            return guid
        if by_name.get(unit, guid) != guid:
            clash.add(unit)
        by_name.setdefault(unit, guid)
        return guid

    if isinstance(packet, dict):
        for key, value in packet.items():
            name = rv_input._json_key(key)
            if not isinstance(value, list) or name not in ("строки", "rows", "массивработ", "деревосоответствия", "сметныепозиции"):
                continue
            for line in value:
                if not isinstance(line, dict):
                    continue
                fields = {rv_input._json_key(k): v for k, v in line.items()}
                guid = note(fields)
                if name == "сметныепозиции":
                    position = str(fields.get("сметнаяпозицияguid") or "").strip()
                    if position and guid:
                        by_position[position] = guid
                    for material in fields.get("материалы") or []:
                        if isinstance(material, dict):
                            note({rv_input._json_key(k): v for k, v in material.items()})
    return {"position": by_position, "name": {k: v for k, v in by_name.items() if k not in clash}}


def fill_onec_sums(items, sums):
    """Строки «разнесено в 1С» (<GUID номенклатуры>|разнесено), собранные до того, как сайт стал переносить суммы
    разнесённого (web/1c_rv.php): «Сумма» и «СуммаВСмету» — из пакета 1С (onec_sums_of). Поля, которые уже есть,
    не трогаются. Возвращает, скольким строкам суммы добавлены."""
    filled = 0
    for item in items:
        uid = str(item.get("uid") or "")
        ext = item.get("ext")
        if not uid.endswith(REDUCED_SUFFIX) or not isinstance(ext, dict) or "Сумма" in ext:
            continue
        found = sums.get(uid[:-len(REDUCED_SUFFIX)].lower())
        if found is None:
            continue
        ext["Сумма"], ext["СуммаВСмету"] = found
        filled += 1
    return filled


def apply_reductions(items, reductions):
    """ЛРВ уменьшилась: у материала отрицательный остаток — под работы в 1С разнесено больше, чем теперь в ЛРВ.
    Количество строки «разнесено в 1С» уменьшается на эту величину; материал под несколькими работами —
    пропорционально разнесённому под каждой. В «РаботыВ1С» количество остаётся как в 1С, рядом — «Уменьшение» и
    «Остается» (части строки берут «Остается»). item['reduce'] = dict(qty — на сколько, before — сколько было в 1С):
    страница проверки выделяет строку как изменение, в 1С уходит минус (sopost_1c, действие «уменьшить»).
    Уменьшение больше разнесённого снимает всё разнесённое. Возвращает (уменьшено строк, [замечания])."""
    by_uid = {}
    for item in items:
        uid = str(item.get("uid") or "")
        if uid.endswith(REDUCED_SUFFIX) and not item.get("skip"):
            by_uid.setdefault(uid[:-len(REDUCED_SUFFIX)].lower(), item)
    done, missing, over = 0, [], []
    for entry in reductions or []:
        item = by_uid.get(str(entry.get("uid") or "").lower())
        asked = bind_fnum(entry.get("qty")) or 0
        if asked <= 0:
            continue
        works = [w for w in ((item or {}).get("ext") or {}).get("РаботыВ1С") or []
                 if isinstance(w, dict) and (rv_audit._num(w.get("Количество")) or 0) > 0]
        total = sum(rv_audit._num(w.get("Количество")) for w in works)
        if item is None or total <= 0:
            missing.append("%s (−%s)" % ((entry.get("name") or entry.get("uid") or "")[:60], _trim(asked)))
            continue
        cut = min(asked, total)
        if asked > total + 1e-9:
            over.append("%s (по ЛРВ −%s, разнесено %s)" % (item.get("name", "")[:60], _trim(asked), _trim(total)))
        left = cut
        for k, work in enumerate(works):
            was = rv_audit._num(work.get("Количество"))
            part = min(was, round(left, 4) if k == len(works) - 1 else round(cut * was / total, 4))
            left -= part
            work["Уменьшение"] = part
            work["Остается"] = round(was - part, 4)
        item["qty"] = round(total - cut, 4)
        item["reduce"] = dict(qty=round(cut, 4), before=round(total, 4))
        done += 1
    notes = []
    if done:
        notes.append("ЛРВ уменьшилась по %d материалам: в 1С под работы разнесено больше, чем осталось в ЛРВ. Количество под "
                     "работами уменьшено (материал под несколькими работами — пропорционально), строки отмечены «уменьшение»; "
                     "в 1С уйдёт минус по этим работам." % done)
    if over:
        notes.append("Уменьшение по ЛРВ больше разнесённого в 1С — снято всё разнесённое: %s%s." % (
            "; ".join(over[:5]), "; …" if len(over) > 5 else ""))
    if missing:
        notes.append("Отрицательный остаток по ЛРВ, но в 1С материал под работы не разнесён — уменьшать нечего: %s%s." % (
            "; ".join(missing[:5]), "; …" if len(missing) > 5 else ""))
    return done, notes


def _trim(value):
    """Число без хвостовых нулей: 2.0 → «2», 0.6 → «0.6»."""
    text = ("%.4f" % float(value)).rstrip("0").rstrip(".")
    return text or "0"


def apply_splits(items, bindings, splits, works, fam_of, section, log=None):
    """Одна строка ЛРВ на несколько работ. Источники: решение сметчика (splits, сильнее) и разнесённое в 1С
    («РаботыВ1С» с двумя и более работами с кодами и количеством). Строка делится на части с тем же
    ИдентификаторСтроки (ext, uid): первая часть оставляет id, остальные — id + SPLIT_ID_STEP·k; у части
    qty_total — количество всей строки, split_of — id строки, split_by — «1С» или логин.
    Возвращает (items, bindings, dict(engineer, onec))."""
    stats = dict(engineer=0, onec=0)
    out_items, out_bindings = [], []
    for item, binding in zip(items, bindings):
        total = bind_fnum(item.get("qty"))
        reduced = item.get("reduce")           # ЛРВ уменьшилась (apply_reductions): количество строки уже меньше, чем в 1С
        parts, by = None, ""
        decided = splits.get(item["id"])
        if decided:
            parts = [p for p in decided["parts"] if p["code"] in works and p["qty"] > 0]
            by = decided["by"]
        elif not (binding.get("learned") in ("correction", "confirmed") and binding.get("learned_token")):
            onec = [w for w in rv_audit.works_1c(item.get("ext")) if w["code"] in works and (w["qty"] or 0) > 0]
            if len(onec) >= 2:
                # часть берёт то, что остаётся под работой после уменьшения; снятая целиком часть остаётся строкой с нулём
                parts = [dict(code=w["code"], qty=float(w["qty"] if w.get("left") is None else w["left"]),
                              before=float(w["qty"]), reduce=float(w.get("reduce") or 0)) for w in onec]
                by = "1С"
        if total is None or total < 0 or (total == 0 and not reduced) or not parts or len(parts) < 2:
            if decided and parts and len(parts) == 1 and total:
                # одна работа - не разбиение, а исправление всей строки
                binding["code"] = parts[0]["code"]
                binding["work"] = works[parts[0]["code"]][:100]
                binding["family"] = fam_of(works[parts[0]["code"]])
                binding["confidence"] = 1.0
                binding["review"] = False
                binding["learned"] = "correction"
                binding["source"] = "решение сметчика %s (вся строка на одну работу)" % by
            out_items.append(item)
            out_bindings.append(binding)
            continue
        parts_sum = sum(p["qty"] for p in parts)
        scale = total / parts_sum if parts_sum else 0.0      # сумма частей = количеству строки
        for k, part in enumerate(parts):
            qty = round(part["qty"] * scale, 4)
            new_item = dict(item, qty=qty, qty_total=total, split_of=item["id"], split_k=k, split_n=len(parts), split_by=by)
            if reduced:
                # уменьшение части: как под её работой в 1С; у разбиения сметчика — доля части в строке
                share = (part["qty"] / parts_sum) if parts_sum else 1.0 / len(parts)
                new_item["reduce"] = dict(
                    qty=round(part["reduce"] if "before" in part else reduced["qty"] * share, 4),
                    before=round(part["before"] if "before" in part else reduced["before"] * share, 4),
                    total=reduced["before"])
            new_binding = dict(binding, code=part["code"], work=works[part["code"]][:100], family=fam_of(works[part["code"]]),
                               confidence=1.0, review=False, deprecated_code=None, qty=qty, split_of=item["id"],
                               role=binding.get("role") if binding.get("role") != "Кр" else "С-В",
                               learned="onec" if by == "1С" else "split",
                               source=("разнесено в 1С на %d работ" % len(parts)) if by == "1С" else ("разбито сметчиком %s на %d работ" % (by, len(parts))),
                               flags=[f for f in (binding.get("flags") or []) if not f.startswith("F-")], fcodes=[])
            new_binding.pop("consumers", None)
            if by == "1С":
                new_binding["onec_code"] = part["code"]
                new_binding["onec_text"] = binding.get("onec_text") or ""
            if k:
                new_item["id"] = item["id"] + SPLIT_ID_STEP * k
                new_binding["id"] = new_item["id"]
            out_items.append(new_item)
            out_bindings.append(new_binding)
        stats["onec" if by == "1С" else "engineer"] += 1
    if log and (stats["engineer"] or stats["onec"]):
        log("строки на несколько работ (%s): по решению сметчика %d, как в 1С %d" % (section, stats["engineer"], stats["onec"]))
    return out_items, out_bindings, stats


def bind_fnum(value):
    try:
        return float(str(value).replace(",", ".").replace(" ", ""))
    except (TypeError, ValueError):
        return None


def smeta_branch(items):
    """Раздел и код системы ветки для работ сметы без кода ИСР: раздел и система, которых в строках больше всего."""
    import bind
    counts = {}
    for item in items:
        if item.get("section") and item.get("system"):
            key = (item["section"], item["system"])
            counts[key] = counts.get(key, 0) + 1
    if not counts:
        return None, None
    section, system = max(counts, key=counts.get)
    return section, bind.sys_code(section, system)


def head_input(args):
    """Шапка 1С (web/1c_rv.php, пакет из обработки «Соответствие РВ и ЛРВ»): документ «Сопоставление РВ и ЛРВ»,
    РВ, GUID сметы и НГ — файл <токен>_head.json; возвращается в РВ для 1С как есть. Нет файла — {}."""
    status_file = getattr(args, "status_file", "") or ""
    if not status_file.endswith("_status.json"):
        return {}
    data = _read_json_file(status_file[:-len("_status.json")] + "_head.json")
    return data if isinstance(data, dict) else {}


def job_input(args):
    """Задача сайта (web/1c_rv.php): token, lrv_id, meta (смета и её GUID, НГ, объект) — файл <токен>_job.json.
    Нет файла — {}."""
    status_file = getattr(args, "status_file", "") or ""
    if not status_file.endswith("_status.json"):
        return {}
    data = _read_json_file(status_file[:-len("_status.json")] + "_job.json")
    return data if isinstance(data, dict) else {}


def code_root(args):
    """Код работ, в котором собирается РВ: «12» — заказ-наряд РВР (работы, не предусмотренные основным проектом),
    иначе «6» (основные работы и заказ-наряды ДР). Выбирается на сайте до сборки (web/rv_kind.php → job['code_root'])."""
    return "12" if str(job_input(args).get("code_root") or "") == "12" else "6"


def learning_path(args):
    """Файл памяти решений: у РВ кода 12 — свой (…_rvr.json рядом с общим): решения сметчиков по работам кода 12
    не должны подменять решения по коду 6 для тех же материалов, и наоборот."""
    path = getattr(args, "learning_file", None) or ""
    if path and code_root(args) == "12":
        base, ext = os.path.splitext(path)
        return base + "_rvr" + ext
    return path


_GUID_RE = None


def clean_guid(value):
    """GUID без приставки сайта: «Смета-ada1bf7c-…» → «ada1bf7c-…» (ИдентификаторЛРВ, которым 1С именует ЛРВ,
    — это «Смета-» + GUID сметы, у сверки — «Сверка-» + GUID документа РВ). Голый GUID — как есть; не GUID — ''."""
    global _GUID_RE
    if _GUID_RE is None:
        import re
        _GUID_RE = re.compile(r"^(?:[^-]*-)?([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$")
    found = _GUID_RE.match((value or "").strip())
    return found.group(1) if found else ""


def site_uuid(token):
    """УИД сайта для сопоставления: один и тот же для задачи (token) — чтобы в 1С хранить ссылку на подбор сайта
    как УникальныйИдентификатор и потом сопоставлять ресурсные ведомости с тем, что согласовали на сайте."""
    import uuid
    return str(uuid.uuid5(uuid.NAMESPACE_URL, "alfastroi.info/rv/job/%s" % token)) if token else ""


SPEC_FIELD = "СпецОсновнаяСметнаяПозицияНоменклатура"


def spec_code_of(name, works, section, sysc):
    """Код работы по наименованию из спецификации номенклатуры 1С: имена работ 1С — те же, что в справочнике КЦ
    агента; при нескольких кодах (одна работа в ветках разных систем) — тот, что в ветке системы строки."""
    import bind
    key = bind.norm(name or "")
    if not key:
        return ""
    if not bind._BY_NAME:
        for code, work in works.items():
            bind._BY_NAME.setdefault(work, []).append(code)
    codes = [code for work, items in bind._BY_NAME.items() if bind.norm(work) == key for code in items]
    if not codes:
        return ""
    if sysc and section in ("ВК", "ОВ2", "ЭОМ", "СС"):
        same = [code for code in codes if code.split(".")[4:5] == [sysc]]
        if same:
            return min(same, key=lambda c: [int(x) for x in c.split(".")])
    return codes[0] if len(codes) == 1 else ""


_SPEC_STOP = {"и", "с", "со", "для", "за", "из", "под", "по", "на", "в", "к", "от", "до", "при", "без", "учетом", "учётом"}


def spec_code_near(name, works, section, sysc):
    """Похожая работа, когда точного имени в справочнике нет (работу в КЦ переименовали): та же ветка системы,
    тот же вариант (хвост после первого « / »), голова совпадает по словам не меньше чем на половину."""
    import bind
    key = bind.norm(name or "")
    if " / " not in key:
        head, tail = key, ""
    else:
        head, tail = key.split(" / ", 1)
    tokens = {t for t in re.split(r"[^а-яa-z0-9]+", head) if len(t) > 2 and t not in _SPEC_STOP}
    if not tokens:
        return ""
    best, score = "", 0.0
    for code, work in works.items():
        if sysc and section in ("ВК", "ОВ2", "ЭОМ", "СС") and code.split(".")[4:5] != [sysc]:
            continue
        wkey = bind.norm(work)
        whead, wtail = (wkey.split(" / ", 1) + [""])[:2] if " / " in wkey else (wkey, "")
        if wtail != tail:
            continue
        wtokens = {t for t in re.split(r"[^а-яa-z0-9]+", whead) if len(t) > 2 and t not in _SPEC_STOP}
        if not wtokens:
            continue
        jaccard = len(tokens & wtokens) / len(tokens | wtokens)
        if jaccard > score:
            best, score = code, jaccard
    return best if score >= 0.5 else ""


# Работы из 1С, которых нет в справочнике КЦ агента (КЦ в 1С пополнили после выгрузки для агента): код → наименование.
# Заполняет register_onec_works на один запуск; строку, разнесённую в 1С на такую работу, агент не оспаривает.
ONEC_ONLY = {}
_ISR_CODE = {"6": re.compile(r"6\.2\.3\.[1-6](\.\d+){3,4}"), "12": re.compile(r"12\.1\.1[1-5](\.\d+){3,5}")}


def register_onec_works(items, smeta, root="6"):
    """Работы, на которые строки разнесены в 1С («РаботыВ1С»), и работы сметы, которых нет в справочнике КЦ агента, —
    в знания агента на этот запуск: имя и единица из 1С, группы материалов — у работы с тем же наименованием (та же
    работа в ветке другой системы), если такая есть: тогда агент сам ставит её строкам своей ветки. Работа появляется
    в выборе «Исправить» на странице проверки. Возвращает {код: наименование} добавленных (и ONEC_ONLY)."""
    import bind
    from rv_common import sec_of
    pattern = _ISR_CODE["12" if root == "12" else "6"]
    found = {}
    for item in items:
        for work in rv_audit.works_1c(item.get("ext")):
            if work["code"] and work["code"] not in bind.KB["works"] and pattern.fullmatch(work["code"]):
                entry = found.setdefault(work["code"], dict(name="", unit=""))
                entry["name"] = entry["name"] or work["name"]
    for code, work in (smeta or {}).items():
        if code not in bind.KB["works"] and pattern.fullmatch(code):
            entry = found.setdefault(code, dict(name="", unit=""))
            entry["name"] = entry["name"] or work.get("name") or ""
            entry["unit"] = work.get("unit") or ""
    by_name = {}
    for code, name in bind.KB["works"].items():
        by_name.setdefault(bind.norm(name), []).append(code)
    ONEC_ONLY.clear()
    for code, entry in sorted(found.items()):
        name = str(entry["name"] or "").strip()
        if not name:
            continue
        section = sec_of(code)
        key = bind.norm(name)
        twins = [c for c in by_name.get(key) or by_name.get(re.sub(r"\.\s+[^/]*$", "", key)) or []
                 if sec_of(c) == section and c in bind.KB["kc"]]
        twin = bind.KB["kc"][twins[0]] if twins else None
        unit = bind.nunit(entry["unit"]) if entry["unit"] else (twin or {}).get("unit", "")
        bind.KB["works"][code] = name
        bind.KB["kc"][code] = dict(twin, unit=unit) if twin else dict(unit=unit, groups={})
        if twins:
            # Та же семья работ, что у двойника, — вариант в ветке своей системы (агент выбирает вариант по ветке строки).
            branch = code.split(".")[4] if len(code.split(".")) > 4 else ""
            for entries in bind.KB.get("famcodes", {}).values():
                same = [e for e in entries if e[0] == twins[0]]
                if same and not any(e[0] == code for e in entries):
                    entries.append((code, branch) + tuple(same[0][2:]))
        ONEC_ONLY[code] = name
    if ONEC_ONLY and hasattr(bind, "_BY_NAME"):
        bind._BY_NAME.clear()          # поиск той же работы в ветке системы строки — с новыми работами
    return dict(ONEC_ONLY)


def apply_onec(items, bindings, works, fam_of, smeta, own_token, split_codes=None, section=None):
    """Разнесённое в 1С и работы сметы (обычная ЛРВ из 1С, не сверка).
    Строка, которую в 1С уже разнесли («РаботыВ1С»), берёт работу 1С: по умолчанию 1С права. Агент не согласен —
    строка «на проверку» с его работой в подсказке (F-1C), модель рассудит, инженер решит; решение инженера
    в этой же задаче (исправление с её token) сильнее 1С — такая строка уйдёт в 1С как «перепривязать».
    Работа агента не из сметы — флаг F-SMETA (при загрузке станет новой сметной позицией); есть похожая работа
    сметы той же ветки — ещё и «на проверку». Возвращает dict(bound, disputed, not_in_smeta)."""
    stats = dict(bound=0, disputed=0, not_in_smeta=0)
    split_codes = split_codes or {}
    for item, binding in zip(items, bindings):
        onec = rv_audit.works_1c(item.get("ext"))
        for work_1c in onec:          # 1С прислала работу без кода ИСР — код по наименованию, как у спецификаций
            if not work_1c["code"] and work_1c["name"]:
                work_1c["code"] = spec_code_of(work_1c["name"], works, section, binding.get("system_code"))
        main = rv_audit.main_code(onec)
        if main and main in works:
            stats["bound"] += 1
            binding["onec_code"] = main
            binding["onec_text"] = rv_audit.text_1c(onec, works)
            own_decision = (binding.get("learned") in ("correction", "confirmed") and own_token
                            and binding.get("learned_token") == own_token)
            agent_code = binding.get("code")
            agrees = agent_code == main or main in split_codes.get(binding["id"], set())
            if main in ONEC_ONLY and not own_decision:
                # Работы нет в справочнике КЦ агента — судить о ней агент не может: остаётся работа 1С, без спора.
                binding.setdefault("flags", []).append(
                    "F-KC: работы %s нет в справочнике КЦ агента — оставлена работа из 1С (обновить справочник агента)" % main)
                binding["fcodes"] = sorted(set(binding.get("fcodes") or []) | {"F-KC"})
                agrees = True
            if own_decision and not agrees:
                binding.setdefault("flags", []).append("F-1C: в 1С разнесено на %s, инженер решил перепривязать на %s" % (main, agent_code))
                binding["fcodes"] = sorted(set(binding.get("fcodes") or []) | {"F-1C"})
                stats["disputed"] += 1
                continue
            if not agrees:
                binding["agent_code"] = agent_code or ""
                binding["agent_work"] = binding.get("work") or ""
                binding["agent_source"] = binding.get("source") or ""
                binding.setdefault("flags", []).append("F-1C: в 1С разнесено на %s; агент предлагает %s — %s (уверенность %s)" % (
                    binding["onec_text"], agent_code or "—", (binding.get("work") or "—")[:80], binding.get("confidence")))
                binding["fcodes"] = sorted(set(binding.get("fcodes") or []) | {"F-1C"})
                stats["disputed"] += 1
            binding["code"] = main
            binding["work"] = works[main][:100]
            binding["family"] = fam_of(works[main])
            binding["confidence"] = 1.0
            binding["review"] = not agrees
            binding["deprecated_code"] = None
            binding["learned"] = "onec"
            binding["source"] = "разнесено в 1С: " + binding["onec_text"]
        if smeta and binding.get("code") and binding["code"] not in smeta and binding.get("learned") != "onec":
            stats["not_in_smeta"] += 1
            prefix = binding["code"].rsplit(".", 2)[0] + "."
            near = [c for c in sorted(smeta) if c.startswith(prefix)][:3]
            binding.setdefault("flags", []).append("F-SMETA: работы %s нет в смете%s" % (
                binding["code"], ("; в смете есть похожие: " + "; ".join("%s — %s" % (c, smeta[c]["name"][:60]) for c in near)) if near else ""))
            binding["fcodes"] = sorted(set(binding.get("fcodes") or []) | {"F-SMETA"})
            if near:
                binding["review"] = True
    return stats


# ── Указания для одной РВ (web/rv_local.php): ТЗ сметчика — текст и файлы ──
# Файл <токен>_local.json рядом со статусом: {text, files: [{name, file, size}], by, at,
# agent: {rows: {id строки: {code, role, reason}}, stats, at} — что модель поменяла по указаниям (local_agent_pass;
# пусто/нет — указания только что сохранены, модель ещё не смотрела), fixes: {id строки: {code, role, coef}} — принятое
# сметчиком пачкой из предложений модели в этой РВ}. Файлы — в папке <токен>_local/. Читается при каждой привязке этой
# РВ (пересборка, согласование, откат) и только её: в общую память агента и общий журнал замечаний не попадает.

LOCAL_TEXT_MAX = 150000              # символов текста указаний и файлов (Excel, Word, CSV, TXT) в промпт модели
LOCAL_IMAGE_MAX = 5 * 1024 * 1024    # картинка в запрос модели (предел API)
LOCAL_PDF_MAX = 15 * 1024 * 1024     # PDF в запрос модели
LOCAL_BLOBS_MAX = 20 * 1024 * 1024   # PDF и картинок в сумме: в base64 запрос не больше 32 МБ
LOCAL_REVIEW_MAX = 600               # строк, которые модель смотрит при пересборке по указаниям
LOCAL_BLOB = {".pdf": ("document", "application/pdf"), ".png": ("image", "image/png"),
              ".jpg": ("image", "image/jpeg"), ".jpeg": ("image", "image/jpeg"), ".webp": ("image", "image/webp")}
LOCAL_ROLES = ("В", "С-В", "С-С", "Р", "Кр")


def _local_file(args):
    status_file = getattr(args, "status_file", "") or ""
    return status_file[:-len("_status.json")] + "_local.json" if status_file.endswith("_status.json") else ""


def local_input(args):
    """Указания для этой РВ (см. выше) или None; _dir — папка их файлов."""
    path = _local_file(args)
    data = _read_json_file(path) if path else None
    if not isinstance(data, dict):
        return None
    data["files"] = [f for f in data.get("files") or [] if isinstance(f, dict) and f.get("file")]
    if not (str(data.get("text") or "").strip() or data["files"]):
        return None
    data["_dir"] = path[:-len(".json")]
    return data


def _update_local(args, **fields):
    """Записать поля в файл указаний этой РВ (остальное в нём не трогаем)."""
    path = _local_file(args)
    data = _read_json_file(path) if path else None
    if not isinstance(data, dict):
        return False
    data.update(fields)
    _write(path, data)
    return True


def _cell(value):
    if value is None:
        return ""
    if isinstance(value, float):
        return ("%.6f" % value).rstrip("0").rstrip(".")
    if hasattr(value, "isoformat"):
        return value.isoformat()[:10]
    return str(value).strip()


def _xlsx_text(path, limit):
    """Книга Excel текстом: по листам, строка — непустые ячейки через « | »."""
    import openpyxl
    book = openpyxl.load_workbook(path, read_only=True, data_only=True)
    lines, size = [], 0
    try:
        for sheet in book.worksheets:
            lines.append("— лист «%s»" % sheet.title)
            for row in sheet.iter_rows(values_only=True):
                cells = [c for c in (_cell(v) for v in row) if c]
                if not cells:
                    continue
                line = " | ".join(cells)
                lines.append(line)
                size += len(line) + 1
                if size > limit:
                    lines.append("… (дальше обрезано)")
                    return "\n".join(lines)
    finally:
        book.close()
    return "\n".join(lines)


def _xls_text(path, limit):
    """Старая книга Excel (.xls, xlrd — им же читается ЛРВ в xls) текстом, как _xlsx_text."""
    import xlrd
    book = xlrd.open_workbook(path, on_demand=True)
    lines, size = [], 0
    try:
        for index in range(book.nsheets):
            sheet = book.sheet_by_index(index)
            lines.append("— лист «%s»" % sheet.name)
            for r in range(sheet.nrows):
                cells = [c for c in (_cell(v) for v in sheet.row_values(r)) if c]
                if not cells:
                    continue
                line = " | ".join(cells)
                lines.append(line)
                size += len(line) + 1
                if size > limit:
                    lines.append("… (дальше обрезано)")
                    return "\n".join(lines)
    finally:
        book.release_resources()
    return "\n".join(lines)


_W = "{http://schemas.openxmlformats.org/wordprocessingml/2006/main}"


def _docx_text(path, limit):
    """Документ Word текстом: абзацы и строки таблиц (ячейки через « | »)."""
    import zipfile
    from xml.etree import ElementTree
    with zipfile.ZipFile(path) as book:
        if book.getinfo("word/document.xml").file_size > 64 * 1024 * 1024:
            raise ValueError("документ слишком большой")
        root = ElementTree.fromstring(book.read("word/document.xml"))

    def para(node):
        return "".join(t.text or "" for t in node.iter(_W + "t")).strip()

    lines, size = [], 0
    body = root.find(_W + "body")
    for child in list(body) if body is not None else []:
        if child.tag == _W + "p":
            found = [para(child)]
        elif child.tag == _W + "tbl":
            found = [" | ".join(" ".join(filter(None, (para(p) for p in cell.iter(_W + "p")))) for cell in row.findall(_W + "tc"))
                     for row in child.iter(_W + "tr")]
        else:
            continue
        for line in found:
            if line.strip(" |"):
                lines.append(line)
                size += len(line) + 1
        if size > limit:
            lines.append("… (дальше обрезано)")
            break
    return "\n".join(lines)


def _plain_text(path, limit):
    with open(path, "rb") as handle:
        raw = handle.read(limit * 4)
    for encoding in ("utf-8-sig", "cp1251"):
        try:
            return raw.decode(encoding)[:limit]
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", "replace")[:limit]


def local_material(local):
    """ТЗ для модели: (текст — задание сметчика и файлы Excel/Word/CSV/TXT, блоки сообщения — PDF и картинки как есть,
    прочитанные файлы, [(файл, почему не прочитан)])."""
    import base64
    parts, blocks, used, skipped = [], [], [], []
    text = str((local or {}).get("text") or "").strip()
    if text:
        parts.append("Задание сметчика:\n" + text)
    budget = LOCAL_TEXT_MAX - len(text)
    blobs = 0
    for entry in (local or {}).get("files") or []:
        name = str(entry.get("name") or entry["file"])
        path = os.path.join((local or {}).get("_dir") or "", os.path.basename(str(entry["file"])))
        ext = os.path.splitext(path)[1].lower()
        try:
            if ext in LOCAL_BLOB:
                kind, media = LOCAL_BLOB[ext]
                size = os.path.getsize(path)
                cap = LOCAL_IMAGE_MAX if kind == "image" else LOCAL_PDF_MAX
                if size > cap or blobs + size > LOCAL_BLOBS_MAX:
                    skipped.append((name, "больше %d МБ" % ((cap if size > cap else LOCAL_BLOBS_MAX) // (1024 * 1024))))
                    continue
                with open(path, "rb") as handle:
                    data = base64.b64encode(handle.read()).decode("ascii")
                blocks.append({"type": "text", "text": "Файл ТЗ «%s»:" % name})
                blocks.append({"type": kind, "source": {"type": "base64", "media_type": media, "data": data}})
                blobs += size
            else:
                if budget < 500:
                    skipped.append((name, "текста указаний больше %d символов" % LOCAL_TEXT_MAX))
                    continue
                if ext in (".xlsx", ".xlsm"):
                    body = _xlsx_text(path, budget)
                elif ext == ".xls":
                    body = _xls_text(path, budget)
                elif ext == ".docx":
                    body = _docx_text(path, budget)
                elif ext in (".csv", ".tsv", ".txt", ".md"):
                    body = _plain_text(path, budget)
                else:
                    skipped.append((name, "формат не читается"))
                    continue
                body = body[:budget]
                budget -= len(body)
                parts.append("Файл ТЗ «%s»:\n%s" % (name, body))
            used.append(name)
        except ImportError:
            skipped.append((name, "этот формат сервер не читает — сохраните как .xlsx"))
        except Exception as exc:  # noqa: BLE001 — битый файл не должен ронять пересборку
            skipped.append((name, _short(exc, 100)))
    return "\n\n".join(parts), blocks, used, skipped


def save_local_fixes(args, fixes, user=""):
    """Принятое сметчиком пачкой из предложений модели в РВ с указаниями — в файл указаний этой РВ: {id строки: code,
    role, coef}. Применяется при каждой привязке этой РВ (apply_local_fixes) и больше нигде."""
    path = _local_file(args)
    if not fixes or not path:
        return 0
    data = _read_json_file(path)
    if not isinstance(data, dict):
        return 0
    stored = data.get("fixes") if isinstance(data.get("fixes"), dict) else {}
    for fix in fixes:
        if fix.get("code"):
            stored[str(fix.get("id"))] = dict(code=str(fix["code"]), role=str(fix.get("role") or ""),
                                             coef=fix.get("coef"), by=user, at=int(time.time()))
    data["fixes"] = stored
    _write(path, data)
    return len(fixes)


def apply_local_fixes(items, bindings, fixes, works, fam_of, own_token):
    """Принятое сметчиком в РВ с указаниями: как решение сметчика в этой РВ (learned=correction с её token) — так его
    увидят разнесённое в 1С (перепривязка) и проверка. В общую память не идёт. Возвращает число строк."""
    count = 0
    for item, binding in zip(items, bindings):
        fix = (fixes or {}).get(str(item.get("id")))
        if not fix or fix.get("code") not in works:
            continue
        code = fix["code"]
        role = fix.get("role") if fix.get("role") in LOCAL_ROLES else (
            binding.get("role") if binding.get("role") in LOCAL_ROLES else "В")
        binding.update(code=code, work=works[code][:100], family=fam_of(works[code]), role=role, confidence=1.0,
                       review=False, deprecated_code=None, learned="correction", learned_token=own_token,
                       source="решение сметчика в этой РВ (по указаниям для неё)", flags=[], fcodes=[], alts=[])
        if fix.get("coef") is not None:
            binding["coef_user"] = float(fix["coef"])
        count += 1
    return count


def apply_local_agent(items, bindings, rows, works, fam_of, own_token):
    """Работы, которые модель выбрала по указаниям для этой РВ (local_agent_pass): строка берёт их и остаётся «на
    проверку» с причиной (F-LOCAL). learned=local: в общую память не идёт; решение сметчика в этой РВ сильнее;
    разнесённое в 1С сильнее тоже — apply_onec после этого сделает работу по указаниям предложением (F-1C).
    Возвращает число строк."""
    count = 0
    for item, binding in zip(items, bindings):
        row = (rows or {}).get(str(item.get("id")))
        if not row or row.get("code") not in works:
            continue
        if binding.get("learned") in ("correction", "confirmed") and own_token and binding.get("learned_token") == own_token:
            continue
        code = row["code"]
        role = row.get("role") if row.get("role") in LOCAL_ROLES else (
            binding.get("role") if binding.get("role") in LOCAL_ROLES else "В")
        reason = str(row.get("reason") or "").strip()[:240]
        was = binding.get("code") or ""
        binding.update(code=code, work=works[code][:100], family=fam_of(works[code]), role=role, confidence=0.9,
                       review=True, deprecated_code=None, learned="local", learned_token=own_token,
                       source="по указаниям для этой РВ" + (": " + reason if reason else ""), alts=[],
                       flags=["F-LOCAL: по указаниям для этой РВ%s%s" % (
                           (" — " + reason) if reason else "", ("; было %s" % was) if was and was != code else "")],
                       fcodes=["F-LOCAL"])
        count += 1
    return count


def local_agent_pass(client, prepared, object_type, local_text, local_blocks, works, own_token, smeta=None,
                     guidance_of=None, log=None, progress=None, heartbeat=None, review=None):
    """Пересборка по указаниям для этой РВ: модель смотрит все строки (не только «на проверку» — указание может касаться
    и строк, в которых агент уверен) с ТЗ сметчика. prepared — [(раздел, строки, привязки)] после памяти, решений
    сметчика и разнесённого в 1С. Что модель меняет — rows (применит apply_local_agent); у строк, разнесённых в 1С,
    замена остаётся предложением в review, как и подтверждения и вопросы. Решения сметчика в этой РВ не смотрит.
    Возвращает dict(rows={id: {code, role, reason}}, review={id: вердикт}, questions, stats)."""
    review = review or rv_agent.review_rows
    candidates = []
    for section, items, bindings in prepared:
        for binding in bindings:
            if binding.get("learned") in ("correction", "confirmed") and own_token and binding.get("learned_token") == own_token:
                continue
            candidates.append(binding)
    candidates.sort(key=lambda b: (bool(b.get("code")), b.get("confidence") or 0))
    chosen = {b["id"] for b in candidates[:LOCAL_REVIEW_MAX]}
    stats = dict(checked=0, changed=0, onec_proposed=0, confirmed=0, questions=0,
                 not_checked=max(0, len(candidates) - len(chosen)), files_error="")
    result, kept, questions = {}, {}, []
    done = [0]
    for section, items, bindings in prepared:
        todo = [b for b in bindings if b["id"] in chosen]
        if not todo:
            continue
        by_id = {b["id"]: b for b in todo}

        def step(current, total, base=done[0]):
            if progress is not None:
                progress(base + current, len(chosen))

        kwargs = dict(log=log, guidance=guidance_of(section) if guidance_of else None, progress=step, heartbeat=heartbeat,
                      smeta=smeta, local=local_text, local_blocks=local_blocks or None, all_rows=True)
        try:
            part, part_questions = review(client, section, object_type, items, todo, works, **kwargs)
        except Exception as exc:  # noqa: BLE001
            if not local_blocks:
                raise
            # PDF или картинку модель не приняла (страниц больше предела, повреждён) — повтор без них, с текстом.
            stats["files_error"] = _short(exc, 160)
            if log:
                log("указания для этой РВ: файлы PDF/картинки модель не приняла (%s) — проверяю без них" % stats["files_error"])
            local_blocks = None
            kwargs["local_blocks"] = None
            part, part_questions = review(client, section, object_type, items, todo, works, **kwargs)
        done[0] += len(todo)
        questions.extend(part_questions)
        for rid, entry in part.items():
            binding = by_id.get(rid)
            if binding is None:
                continue
            stats["checked"] += 1
            code = entry.get("code") or ""
            if entry.get("verdict") == "заменить" and code in works and code != binding.get("code") and binding.get("learned") != "onec":
                result[str(rid)] = dict(code=code, role=entry.get("role") or "", reason=entry.get("reason") or "")
                stats["changed"] += 1
                continue
            kept[rid] = entry
            if entry.get("verdict") == "заменить":
                stats["onec_proposed" if binding.get("learned") == "onec" else "confirmed"] += 1
            elif entry.get("verdict") == "вопрос":
                stats["questions"] += 1
            else:
                stats["confirmed"] += 1
    return dict(rows=result, review=kept, questions=questions, stats=stats)


def smeta_text(smeta):
    """Работы сметы для подсказки модели: «код — работа (объём ед.)»."""
    lines = []
    for code in sorted(smeta):
        work = smeta[code]
        qty = ("%g %s" % (work["qty"], work["unit"])).strip() if work.get("qty") is not None else work.get("unit") or ""
        lines.append("%s — %s%s" % (code, work["name"][:90], (" (%s)" % qty) if qty else ""))
    return "\n".join(lines)


def _read_json_file(path):
    try:
        with open(path, encoding="utf-8") as handle:
            return json.load(handle)
    except (OSError, ValueError):
        return None


def run_mark(args):
    """Фаза 1: прочитать ЛРВ, разметить заголовки, отдать на подтверждение."""
    started = int(time.time())
    status = Status(args.status_file, started)
    status.update("running", "читаю ЛРВ…")
    try:
        parsed = rv_input.parse_lrv(args.input)
    except Exception as exc:  # noqa: BLE001
        status.update("error", "не удалось прочитать ЛРВ", error="Не удалось прочитать файл ЛРВ: %s" % exc)
        return 1
    # Загруженный файл на сайте не хранится: прочитали — удалили.
    if not args.keep_input:
        try:
            os.remove(args.input)
        except OSError:
            pass
    items = parsed["items"]
    fmt = parsed.get("format", "table")
    if not items:
        status.update("error", "в файле нет строк материалов",
                      error="В файле не найдено строк материалов с количеством. Подходит отчёт 1С «Остатки по ЛРВ» "
                            "с группировкой по системам или таблица с колонками «Наименование», «Ед.», «Кол-во».")
        return 1
    if fmt == "1c_report":
        status.log("отчёт 1С с группировкой %s" % " → ".join(parsed.get("levels") or []))
        status.log("строк номенклатуры: %d, групп: %d, документов-регистраторов пропущено: %d, строк без планового количества: %d"
                   % (len(items), len(parsed["headers"]), parsed.get("docs", 0), parsed.get("skipped_zero", 0)))
    else:
        status.log("прочитано строк: %d, заголовков групп: %d, пропущено итогов: %d (лист «%s»)"
                   % (len(items), len(parsed["headers"]), parsed["skipped"], parsed["sheet"]))

    notes = []
    section = args.section or "авто"
    if section == "авто" and fmt != "1c_report" and args.default_system and "|" in args.default_system:
        section = args.default_system.split("|", 1)[0]          # раздел — из выбранной при загрузке системы
    if section == "авто" and fmt != "1c_report":
        section = rv_input.guess_section(parsed["headers"]) or "авто"
        if section == "авто":
            status.update("error", "раздел не определён",
                          error="Не удалось определить раздел по заголовкам файла — выберите раздел (ВК, ОВ1, ОВ2, ЭОМ, СС) "
                                "при загрузке.")
            return 1
        notes.append("Раздел определён по заголовкам групп: %s." % section)
    status.update("running", "размечаю системы и элементы…")
    marks = rv_input.guess_headers(section, parsed["headers"], fmt)
    rv_input.fix_drainage_marks(parsed["headers"], marks)
    default_system = None
    # Система, выбранная при загрузке, — для всех строк: агент её не переспрашивает.
    force_system = None
    if args.default_system:
        default_section, default_sys = rv_input.split_system(args.default_system)
        if default_section:
            force_system = args.default_system
        elif section in rv_input.SECTIONS:
            normalized = rv_input.normalize_system(section, default_sys)
            force_system = "%s|%s" % (section, normalized) if normalized else None
    model_default = None
    has_system_column = "system" in parsed["columns"]
    if fmt == "1c_report":
        marked_by = "по словарю систем 1С (группы уровня «Система»)"
        unresolved = [parsed["headers"][i]["text"] for i, m in marks.items() if m.get("unresolved")]
        if unresolved:
            notes.append("Системы не распознаны по названию, нужен выбор: %s." % "; ".join(sorted(set(unresolved))[:8]))
        if not parsed.get("has_unit"):
            notes.append("В выгрузке нет колонки единиц измерения: единицы взяты из эталонной библиотеки, а где имени "
                         "в ней нет — по типу материала (флаг F-UNIT). Точнее — добавить в отчёт 1С поле «Единица измерения».")
    else:
        marked_by = "по кодам систем в тексте заголовков"
    if fmt != "1c_report" and parsed["headers"] and not has_system_column and not force_system:
        client = _client(args.credentials, status.log)
        if client is not None:
            try:
                status.log("разметка заголовков моделью %s (усилие %s)…" % rv_agent.model_of(client, "mark"))
                model_marks, model_default, model_notes = rv_agent.mark_headers(
                    client, section, parsed["headers"], items[:SAMPLE_FOR_MARKING], log=status.log,
                    heartbeat=status.touch)
                # Модель главнее эвристики там, где высказалась; код системы в тексте — сильнее «other».
                for index, mark in model_marks.items():
                    if mark["kind"] != "other" or marks.get(index, {}).get("kind") != "system":
                        if mark.get("kind") == "system":
                            mark.setdefault("section", section)
                        marks[index] = mark
                if model_default:
                    model_default = "%s|%s" % (section, model_default)
                notes.extend(model_notes)
                marked_by = "моделью по заголовкам групп"
            except Exception as exc:  # noqa: BLE001
                status.log("разметка моделью не удалась, системы — по кодам в заголовках: %s" % exc)
                notes.append("Разметка заголовков моделью не удалась (%s); системы взяты по кодам в тексте заголовков."
                             % _short(exc))
    elif has_system_column:
        marked_by = "по колонке «Система» в файле"

    # Сколько строк под каждым заголовком (включая вложенные группы) — для страницы подтверждения.
    rows_under = {}
    for item in items:
        for h in item["headers"]:
            rows_under[h] = rows_under.get(h, 0) + 1
    rows_without_header = sum(1 for item in items if not item["headers"])

    # Спрашивать или сразу строить: вопрос — только при неоднозначности (система не выбрана при загрузке
    # и у части строк её нет в самом файле, либо в отчёте 1С есть нераспознанные системы).
    probe = dict(items=[dict(it) for it in items], headers=parsed["headers"], columns=parsed["columns"])
    rv_input.apply_marks(section, probe, marks, default_system, force_system)
    no_system = [it for it in probe["items"] if not it.get("skip") and not (it.get("system") and it.get("section"))]
    unresolved_1c = fmt == "1c_report" and any(m.get("unresolved") for m in marks.values())
    if force_system:
        need_confirm, why = False, "система выбрана при загрузке: %s" % force_system.replace("|", " / ")
        marked_by = "система выбрана при загрузке"
    elif unresolved_1c:
        need_confirm, why = True, "в отчёте 1С есть группы с нераспознанной системой"
    elif no_system:
        need_confirm, why = True, "у %d строк из %d системы в файле нет" % (len(no_system), len(items))
    else:
        need_confirm, why = False, "системы всех строк есть в файле (%s)" % marked_by
    if need_confirm and model_default and not default_system:
        default_system = model_default          # предложение модели — выбрано в вопросе, но не применено молча
    if need_confirm and audit_input(args) is not None:
        # Сверка РВ из 1С идёт пачкой без людей: не спрашиваем — строки нераспознанных систем останутся без работы.
        need_confirm, why = False, "сверка РВ из 1С — без вопросов (%s: такие строки без работы)" % why
    # Заказ-наряд бывает ДР (работы кода 6) или РВР (работы кода 12). Если вид заранее не известен (1С не прислала, работ
    # сметы ещё нет, прежней версии не было — web/1c_rv.php), перед сборкой спрашиваем сметчика на странице подтверждения.
    job = job_input(args)
    ask_code_root = ((job.get("meta") or {}).get("kind") == "НЗ" and str(job.get("code_root") or "") not in ("6", "12")
                     and audit_input(args) is None)
    if ask_code_root:
        why = "Заказ-наряд: выберите, по какому коду работ собирать РВ — ДР (код 6) или РВР (код 12)" + (
            "; " + why if need_confirm else "")
        need_confirm = True
    status.log(("нужно подтверждение: %s" if need_confirm else "подтверждение не нужно: %s") % why)

    work = dict(
        section=section, object_type=args.object_type, source_name=args.source_name or os.path.basename(args.input),
        format=fmt, levels=parsed.get("levels"), has_unit=parsed.get("has_unit", "unit" in parsed["columns"]),
        sheet=parsed["sheet"], columns=parsed["columns"], skipped=parsed["skipped"],
        skipped_zero=parsed.get("skipped_zero", 0), docs=parsed.get("docs", 0),
        items=items, headers=parsed["headers"],
        marks={str(k): v for k, v in marks.items()}, default_system=default_system,
        rows_under={str(k): v for k, v in rows_under.items()}, rows_without_header=rows_without_header,
        has_system_column=has_system_column, marked_by=marked_by, notes=notes,
        sample=[dict(name=it["name"], unit=it.get("unit", ""), qty=it["qty"]) for it in items[:8]],
        force_system=force_system, need_confirm=need_confirm, confirm_reason=why, ask_code_root=ask_code_root,
        rows_no_system=len(no_system), model_default=model_default,
        lrv_id=getattr(args, "lrv_id", ""), version=getattr(args, "lrv_version", ""), object=getattr(args, "object_name", ""),
    )
    if not need_confirm and args.out_xlsx and args.out_json:
        work["confirmed"] = "auto"
        _write(args.work_file, work)
        status.update("running", "привязываю строки к работам…", rows=len(items), headers=len(parsed["headers"]),
                      marked_by=marked_by, format=fmt)
        return run_bind(args)
    _write(args.work_file, work)
    status.update("awaiting_confirm", "ждёт подтверждения разметки", rows=len(items), headers=len(parsed["headers"]),
                  marked_by=marked_by, format=fmt)
    status.log("разметка готова (%s), ждём подтверждения" % marked_by)
    return 0


def _library_units():
    """Единица материала по нормализованному имени из эталонной библиотеки
    комплекта (все разделы) — для выгрузок без колонки единиц."""
    path = os.path.join(DATA_DIR, "library_clean.json")
    units = {}
    if not os.path.exists(path):
        return units
    with open(path, encoding="utf-8") as handle:
        library = json.load(handle)
    for entries in library.values():
        for name, entry in entries.items():
            unit = entry.get("munit")
            if unit and name not in units:
                units[name] = unit
    return units


def _fill_units(items, log):
    """Строкам без единицы — единица из библиотеки, иначе по типу материала.
    Возвращает (из библиотеки, по типу)."""
    from rv_common import norm
    missing = [it for it in items if not (it.get("unit") or "").strip()]
    if not missing:
        return 0, 0
    units = _library_units()
    from_library = 0
    guessed = 0
    for item in missing:
        unit = units.get(norm(item["name"]))
        if unit:
            item["unit"] = unit
            item["unit_source"] = "библиотека"
            from_library += 1
        else:
            unit, confidence = rv_input.guess_unit(item["name"])
            item["unit"] = unit
            item["unit_source"] = "по типу"
            item["unit_confidence"] = confidence
            guessed += 1
    log("единицы измерения: из библиотеки %d, по типу материала %d" % (from_library, guessed))
    return from_library, guessed


def _stub_binding(item, reason):
    return dict(id=item["id"], name=item["name"], system=item.get("system"), code=None, work=None, family=None,
                role=None, confidence=0.0, source="", flags=["F-CTX: %s" % reason], fcodes=["F-CTX"], review=False,
                dn=None, deprecated_code=None, system_code=None)


def _auto_phase(args):
    """Привязка запущена сразу из первой фазы (подтверждение не понадобилось)."""
    return getattr(args, "phase", "") == "mark"


def job_token(args):
    """Номер задачи на сайте — по имени файла статуса (<token>_status.json)."""
    name = os.path.basename(getattr(args, "status_file", "") or "")
    token = name.split("_", 1)[0]
    return token if len(token) == 16 and all(c in "0123456789abcdef" for c in token) else ""


def _forget(args, status):
    """Откат согласования (--forget-learning, web/rv_rollback.php): решения инженера по этой РВ
    убираются из памяти агента — где до них было другое решение, оно возвращается.
    Возвращает dict(removed, restored, user) или None, если отката не было."""
    if not getattr(args, "forget_learning", False) or not getattr(args, "learning_file", ""):
        return None
    removed, restored = rv_learning.forget(args.learning_file, token=job_token(args), source=args.source_name or "")
    status.log("откат проверки: из памяти решений убрано %d записей, возвращено прежних %d" % (removed, restored))
    return dict(removed=removed, restored=restored, user=args.user or "")


def _feedback(args, status):
    """Повтор по проверке инженера: его решения — в память, прежний результат — для переноса
    проверки моделью. Возвращает (прежний результат, dict(corrected, confirmed)) или (None, None)."""
    if not getattr(args, "feedback_file", None):
        return None, None
    if not os.path.exists(args.feedback_file) or not os.path.exists(args.out_json):
        status.log("файл проверки или прежний результат не найден — строю заново без учёта проверки")
        return None, None
    feedback = json.load(open(args.feedback_file, encoding="utf-8"))
    previous = _read(args.out_json)
    known = set()
    if os.path.exists(form_path(args)):
        for rows in (_read(form_path(args)).get("catalog") or {}).values():
            known.update(row[0] for row in rows)
    bad = [fix for fix in feedback.get("corrections") or []
           if known and fix.get("code") and str(fix.get("code")) not in known]
    if bad:
        status.log("в проверке %d строк с неизвестным кодом работы — пропущены" % len(bad))
        feedback["corrections"] = [fix for fix in feedback.get("corrections") or [] if fix not in bad]
    # РВ с указаниями только для неё: в общую память — лишь ручные исправления сметчика, не то, что привязано по указаниям;
    # принятое пачкой из предложений модели (via=model) действует только в этой РВ — пишется в её файл указаний.
    is_local = bool(previous.get("local"))
    decisions = rv_learning.decisions_from_feedback(previous, feedback, confirm_rest=not is_local)
    if is_local:
        save_local_fixes(args, [fix for fix in feedback.get("corrections") or [] if fix.get("via") == "model"],
                         feedback.get("user") or args.user or "")
    corrected, confirmed = rv_learning.merge(args.learning_file, decisions, user=feedback.get("user") or args.user or "",
                                             source=args.source_name or previous.get("source_name") or "",
                                             token=job_token(args))
    status.log("проверка инженера: исправлено %d строк, подтверждено %d — записано в память решений" % (corrected, confirmed))
    when = feedback.get("when")
    return previous, dict(corrected=corrected, confirmed=confirmed, user=feedback.get("user") or "",
                          when=time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime(when)) if isinstance(when, (int, float)) and when else "")


NOTES_FOR_MODEL = 25        # последних замечаний инженеров в промпт проверки
NOTES_CHARS = 6000


def engineer_notes(path, section=None):
    """Замечания инженеров к агенту (web/data/rv_notes.jsonl, пишет rv_note.php): последние, сначала по разделу,
    не длиннее NOTES_CHARS — для проверки строк моделью."""
    if not path or not os.path.exists(path):
        return []
    notes = []
    try:
        with open(path, encoding="utf-8") as handle:
            for line in handle:
                try:
                    note = json.loads(line)
                except ValueError:
                    continue
                text = str(note.get("text") or "").strip()
                if not text:
                    continue
                sections = note.get("sections") or []
                notes.append((section in sections if section else False, text))
    except OSError:
        return []
    picked = [t for own, t in reversed(notes) if own] + [t for own, t in reversed(notes) if not own]
    out, size = [], 0
    for text in picked[:NOTES_FOR_MODEL]:
        if size + len(text) > NOTES_CHARS:
            break
        out.append(text)
        size += len(text)
    return out


ZN_ANALYTIC = re.compile(r"з\s*/\s*н|заказ[\s-]*наряд|наряд[\s-]*заказ", re.I)


def zn_of(ext):
    """Наряд-заказ строки ЛРВ из 1С: «НомерЗН», а если он пуст — Аналитика 4 вида «Работы по З/Н №ЭОМ-1»
    (номер после «№», без него — имя аналитики). Пусто — основные работы. То же — zn_of в web/rv_smeta.php."""
    number = str(ext.get("НомерЗН") or "").strip()
    if number:
        return number
    analytic = str(ext.get("Аналитика") or ext.get("Аналитика_4_Имя") or "").strip()
    if not ZN_ANALYTIC.search(analytic):
        return ""
    match = re.search(r"№\s*(\S.*)$", analytic)
    return match.group(1).strip() if match else analytic


def zn_counts(items):
    """Наряд-заказы строк ЛРВ из 1С (zn_of) и сколько строк под каждым — для дерева объектов
    на сайте (rv_registry.php). Строки основных работ сюда не входят."""
    counts = {}
    for item in items:
        if item.get("skip"):
            continue
        number = zn_of(item.get("ext") or {})
        if number:
            counts[number] = counts.get(number, 0) + 1
    return dict(sorted(counts.items()))


def onec_path(args):
    """РВ для 1С — отдельный файл рядом с результатом: работы с объёмами и строки ЛРВ под ними со всеми
    идентификаторами, которые прислала 1С (web/1c_rv.php?file=json)."""
    path = args.out_json
    if path.endswith(".json.gz"):
        return path[:-len(".json.gz")] + "_1c.json.gz"
    return os.path.splitext(path)[0] + "_1c.json"


def export_1c(result, work, works, smeta=None, head=None, job=None, units=None):
    """РВ в виде для 1С: по работам ИСР — код, имя, единица, объём, элемент, система, признак «добавлено агентом»;
    под каждой — строки ЛРВ: идентификатор строки и остальные поля 1С как пришли (ext), код номенклатуры,
    наименование, единица, количество (у крепежа — часть под этой работой и всего), коэффициент, роль,
    уверенность, проверено ли инженером. Строки без работы — отдельно.
    В шапке — чем 1С связывает РВ с сайтом и сметой: «КодСайта» (token задачи, он же в URL статуса) и «УИДСайта»
    (UUID по token, для реквизита-идентификатора), «ЛРВGUID» (GUID из ИдентификаторЛРВ без приставки «Смета-»),
    «Смета» и «СметаGUID» (из шапки обработки, иначе из пакета ЛРВ — job.meta).
    У работы — итоги по сметной позиции из её строк: «Количество», «КоличествоПоСмете» (сумма «КоличествоВСмету»
    строк), «Сумма», «СуммаВСмету»; «ЕдиницаИзмеренияGUID» — у позиции сметы, иначе по имени единицы из пакета 1С
    (units — unit_guids_of), иначе пусто."""
    head = head or {}
    units = units or {}
    job = job or {}
    meta = job.get("meta") or {}
    lrv_id = work.get("lrv_id") or job.get("lrv_id") or ""
    token = job.get("token") or ""
    out_works = []
    unbound = []
    review = result.get("review") or {}
    for block in result.get("elements") or []:
        by_id = {it["id"]: it for it in block.get("items") or []}
        bindings = {b["id"]: b for b in block.get("bindings") or []}
        for rv_work in (block.get("rv") or {}).get("works") or []:
            rows = []
            for material in rv_work.get("materials") or []:
                item = by_id.get(material["id"], {})
                binding = bindings.get(material["id"], {})
                rows.append(_row_1c(item, binding, material.get("qty"), review.get(str(material["id"]))))
            smeta_work = (smeta or {}).get(rv_work["code"]) or {}
            unit = rv_work.get("unit") or ""
            unit_guid = (smeta_work.get("unit_guid") or (units.get("position") or {}).get(smeta_work.get("guid") or "")
                         or (units.get("name") or {}).get(_unit_key(smeta_work.get("unit") or unit)) or "")
            out_works.append({
                "КодИСР": rv_work["code"], "Наименование": works.get(rv_work["code"]) or rv_work.get("work") or "",
                "ЕстьВСмете": bool(smeta_work) if smeta else None, "СметнаяПозицияGUID": smeta_work.get("guid") or "",
                # Явно: в 1С нужна новая сметная позиция (работы нет среди позиций сметы, которые прислала 1С);
                # null — 1С не присылала позиции сметы, сайт не знает (1С сверяет по КодИСР сама).
                "НоваяСметнаяПозиция": (not smeta_work) if smeta else None,
                "УИДУзлаДерева": smeta_work.get("node") or "",      # узел открытого «Сопоставления РВ и ЛРВ», если 1С прислала
                "ЕдиницаИзмерения": unit, "ЕдиницаИзмеренияGUID": unit_guid, "Объем": rv_work.get("volume"),
                # итоги по сметной позиции — по строкам «Материалы» (заполняются в конце, когда суммы строк — доли)
                "Количество": 0, "КоличествоПоСмете": 0, "Сумма": 0, "СуммаВСмету": 0,
                "СпособРасчета": rv_form.explain_method(rv_work.get("method")),
                "Элемент": block.get("element") or "", "Раздел": block.get("section") or "",
                "Система": (rows[0].get("Система") if rows else "") or "",
                "ДобавленоАгентом": bool(rv_work.get("auto")), "ДобавленоСметчиком": bool(rv_work.get("manual")),
                "Примечание": rv_work.get("note") or "",
                "Материалы": rows,
            })
        for entry in (block.get("rv") or {}).get("unbound") or []:
            item = by_id.get(entry["id"], {})
            unbound.append(_row_1c(item, bindings.get(entry["id"], {}), item.get("qty"), review.get(str(entry["id"]))))
    summary = result.get("summary") or {}
    rebind = sum(1 for w in out_works for m in w["Материалы"] if m.get("Действие") == "перепривязать")
    out = {
        "ИдентификаторЛРВ": lrv_id, "ЛРВGUID": clean_guid(lrv_id), "Версия": work.get("version") or "",
        "КодСайта": token, "УИДСайта": site_uuid(token),
        "Смета": head.get("Смета") or meta.get("smeta") or "",
        "СметаGUID": head.get("СметаGUID") or meta.get("smeta_id") or clean_guid(lrv_id),
        "Объект": work.get("object") or "", "ФайлЛРВ": result.get("source_name") or "",
        # Код работ РВ: 12 — заказ-наряд РВР (работы, не предусмотренные основным проектом), 6 — основные работы и ДР.
        "КодРабот": result.get("code_root") or "6",
        "Разделы": list(result.get("sections") or []), "ТипОбъекта": result.get("object_type") or "",
        "Сформировано": time.strftime("%Y-%m-%dT%H:%M:%S"),
        "Итого": {"СтрокЛРВ": summary.get("rows"), "Работ": summary.get("works"), "НаПроверку": summary.get("review"),
                  "БезРаботы": summary.get("unbound"), "ДобавленоРабот": summary.get("auto_works", 0),
                  "ПроверкаИнженером": result.get("summary", {}).get("feedback") or None,
                  "РазнесеноВ1С": (summary.get("onec") or {}).get("bound", 0), "Перепривязать": rebind,
                  "Уменьшено": sum(1 for w in out_works for m in w["Материалы"] if (rv_audit._num(m.get("Уменьшение")) or 0) > 0),
                  "РаботНеИзСметы": sum(1 for w in out_works if w.get("ЕстьВСмете") is False),
                  "НовыхСметныхПозиций": sum(1 for w in out_works if w.get("НоваяСметнаяПозиция") is True)},
        "Работы": out_works,
        "БезРаботы": unbound,
        "Замечания": list(result.get("notes") or []),
    }
    if head:
        # Пакет из обработки «Соответствие РВ и ЛРВ»: документ, РВ и GUID — как прислала 1С, чтобы загрузка знала,
        # куда класть подбор.
        out["Сопоставление1С"] = head
        for key in ("Сопоставление", "СопоставлениеGUID"):
            if head.get(key):
                out[key] = head[key]
    out["СопоставлениеРВиЛРВ"] = sopost_1c(out, out_works, smeta or {}, head, work, result)
    # после sopost_1c: он берёт суммы целой строки ЛРВ и сам делит их по работам
    for row in [m for w in out_works for m in w["Материалы"]] + unbound:
        _row_shares(row)
    for rv_work in out_works:
        _work_totals(rv_work)
    return out


def _work_totals(rv_work):
    """Итоги работы РВ для 1С по сметной позиции — по её строкам «Материалы» (после _row_shares): «Количество»,
    «КоличествоПоСмете» (из «КоличествоВСмету» строк) — до 4 знаков, «Сумма», «СуммаВСмету» — до копеек.
    Работа без строк (добавлена агентом или сметчиком) — нули."""
    rows = rv_work.get("Материалы") or []

    def total(field, digits):
        return round(sum(rv_audit._num(row.get(field)) or 0 for row in rows), digits)

    rv_work.update({"Количество": total("Количество", 4), "КоличествоПоСмете": total("КоличествоВСмету", 4),
                    "Сумма": total("Сумма", 2), "СуммаВСмету": total("СуммаВСмету", 2)})


def _node_uuid(lrv_id, code):
    """УИД узла дерева для работы, которой в 1С ещё нет: один и тот же у одной сметы и кода ИСР при любом
    перестроении, чтобы повторная загрузка попала в тот же узел."""
    import uuid
    return str(uuid.uuid5(uuid.NAMESPACE_URL, "alfastroi.info/rv/%s/%s" % (lrv_id, code)))


def _share(row, qty, field):
    """Часть суммы (или другого поля строки ЛРВ) на количество qty: пропорционально количеству строки.
    Суммы — до копеек, количества («КоличествоВСмету») — до 4 знаков, как в 1С."""
    total = rv_audit._num(row.get(field))
    # у строки, уменьшенной по ЛРВ, суммы и «в смету» из 1С относятся к прежнему количеству («КоличествоВсегоВ1С»)
    whole = rv_audit._num(row.get("КоличествоВсегоВ1С")) or rv_audit._num(row.get("КоличествоВсего"))
    if total is None or not whole or qty is None:
        return 0
    return round(total * qty / whole, 2 if field.startswith("Сумма") else 4)


SHARE_FIELDS = ("Сумма", "СуммаВСмету", "КоличествоВСмету")


def _row_shares(row):
    """«Сумма», «СуммаВСмету», «КоличествоВСмету» строки РВ для 1С — доля строки ЛРВ под этой работой (на её
    «Количество»), как в «Товары» и «ТЧИзменений»: у строки, разнесённой на несколько работ, сумма частей равна сумме
    строки; у уменьшенной — на то, что осталось. Поля есть всегда: 0 — 1С сумм не прислала."""
    qty = rv_audit._num(row.get("Количество"))
    shares = {field: _share(row, qty, field) for field in SHARE_FIELDS}
    row.update(shares)


def _minus(value):
    """−value без «−0.0» у нуля."""
    return -value if value else 0


def sopost_1c(out, out_works, smeta, head, work, result):
    """Данные для документа «Сопоставление РВ и ЛРВ» (Документ.Сити_СопоставлениеРВиЛРВ) и того, что он делает при
    проведении: ресурсная ведомость (бит_стр_РесурснаяВедомость, вид операции по наличию РВ у сметы) и по строке
    изменений — документ «Сопоставление с ресурсной ведомостью» (бит_стр_СопоставлениеСРесурснойВедомостью).
      Документ        — шапка: сопоставление и РВ из 1С (если пакет пришёл из обработки), код и УИД сайта
                        (КодСайта/УИДСайта — чтобы потом сопоставлять ресурсные ведомости с подбором сайта), смета
                        и её GUID, ЛРВGUID, НГ, аналитики, кто и когда согласовал на сайте. Организация и
                        подразделение сайт не знает — 1С берёт их из ЛРВ (сметы).
      СметныеПозиции  — ТЧ «Сметные позиции»: все работы РВ; у работы из сметы — GUID позиции и узла, у новой —
                        Код/Наименование/ЕдиницаИзмерения, код ИСР работы (Номенклатура.СИТИ_КодИерархия) и УИД узла,
                        который сайт выдаёт сам (один и тот же при перестроении).
      ТЧИзменений     — ТЧ «Изменения», только разница с 1С: «привязать» — строка на работу; «перепривязать» —
                        минус со старой позиции и плюс на новую; «как в 1С» — ничего. Количество, количество в смету,
                        сумма и сумма в смету — доля строки ЛРВ пропорционально количеству под работой; весовой
                        коэффициент — у крепежа доля под работой, иначе 1; НоменклатураРодитель — сама номенклатура.
      Товары          — вся РВ после проведения (контроль): каждая строка ЛРВ под своей работой, в том числе разнесённое
                        в 1С как есть."""
    lrv_id = out.get("ИдентификаторЛРВ") or ""
    feedback = (result.get("summary") or {}).get("feedback") or {}
    rv_guid = head.get("РесурснаяВедомостьGUID") or ""
    if set(rv_guid) <= set("0-"):
        rv_guid = ""                            # пустая ссылка 1С: 00000000-0000-…
    doc = {
        "Сопоставление": head.get("Сопоставление") or out.get("Сопоставление") or "",
        "СопоставлениеGUID": head.get("СопоставлениеGUID") or out.get("СопоставлениеGUID") or "",
        "КодСайта": out.get("КодСайта") or "", "УИДСайта": out.get("УИДСайта") or "",
        "Смета": out.get("Смета") or work.get("smeta") or "", "СметаGUID": out.get("СметаGUID") or "",
        "НоменклатурнаяГруппа": head.get("НоменклатурнаяГруппа") or work.get("object") or "",
        "НоменклатурнаяГруппаGUID": head.get("НоменклатурнаяГруппаGUID") or "",
        "РесурснаяВедомость": head.get("РесурснаяВедомость") or "", "РесурснаяВедомостьGUID": rv_guid,
        "ВидОперацииРВ": "Корректировка" if rv_guid else "Добавление",
        "Организация": "", "Подразделение": "",
        "Пользователь": feedback.get("user") or "", "ДатаСогласования": feedback.get("when") or "",
        "Источник": "alfastroi.info, агент РВ", "ИдентификаторЛРВ": lrv_id, "ЛРВGUID": out.get("ЛРВGUID") or "",
        "Версия": out.get("Версия") or "",
    }
    for key in ("Аналитика1", "Аналитика2", "Аналитика3", "Аналитика4"):
        doc[key] = head.get(key) or ""
    positions = []
    by_code = {}
    for rv_work in out_works:
        code = rv_work["КодИСР"]
        smeta_work = smeta.get(code) or {}
        node = smeta_work.get("node") or ("" if smeta_work.get("guid") else _node_uuid(lrv_id, code))
        position = {
            "СметнаяПозиция": smeta_work.get("position") or rv_work["Наименование"], "СметнаяПозицияGUID": smeta_work.get("guid") or "",
            "Код": smeta_work.get("position_code") or "", "Наименование": rv_work["Наименование"],
            "ЕдиницаИзмерения": smeta_work.get("unit") or rv_work.get("ЕдиницаИзмерения") or "",
            "ЕдиницаИзмеренияGUID": rv_work.get("ЕдиницаИзмеренияGUID") or "",
            "КодИерархии": code, "РаботаGUID": smeta_work.get("work_guid") or "",
            "Количество": rv_work.get("Объем"), "КоличествоПоСмете": smeta_work.get("qty"),
            "УИДУзлаДерева": node, "ЕстьВСмете": bool(smeta_work), "НоваяСметнаяПозиция": not smeta_work,
            "ДобавленоАгентом": bool(rv_work.get("ДобавленоАгентом")),
            "ДобавленоСметчиком": bool(rv_work.get("ДобавленоСметчиком")),
            "Примечание": ((result.get("work_notes") or {}).get(code) or {}).get("text") or "",
        }
        positions.append(position)
        by_code[code] = position
    changes = []
    goods = []
    for rv_work in out_works:
        position = by_code[rv_work["КодИСР"]]
        for row in rv_work["Материалы"]:
            qty = rv_audit._num(row.get("Количество")) or 0
            base = {
                "Номенклатура": row.get("Номенклатура") or "", "НоменклатураGUID": row.get("НоменклатураGUID") or row.get("Номенклатура_GUID") or "",
                "Код": row.get("Код") or "", "НоменклатураРодитель": row.get("Номенклатура") or "",
                "НоменклатураРодительGUID": row.get("НоменклатураGUID") or row.get("Номенклатура_GUID") or "",
                "ЕдиницаИзмерения": row.get("ЕдиницаИзмерения") or "", "ЕдиницаИзмеренияGUID": row.get("ЕдиницаИзмеренияGUID") or "",
                # весовой коэффициент: из 1С (спецификация), иначе у крепежа - доля под работой, иначе 1
                "ВесовойКоэф": rv_audit._num(row.get("ВесовойКоэф")) or (row.get("Коэффициент") if row.get("Роль") == "Кр" else 1),
                "ИдентификаторСтроки": row.get("ИдентификаторСтроки") or "", "СтрокаЛРВ": row.get("СтрокаЛРВ"),
            }
            goods.append(dict(base, СметнаяПозицияGUID=position["СметнаяПозицияGUID"], УИДУзлаДерева=position["УИДУзлаДерева"],
                              КодИерархии=position["КодИерархии"], Количество=qty, КоличествоВСмету=_share(row, qty, "КоличествоВСмету"),
                              Сумма=_share(row, qty, "Сумма"), СуммаВСмету=_share(row, qty, "СуммаВСмету"),
                              Источник="1С" if row.get("Действие") == "как в 1С" else "сайт"))
            action = row.get("Действие") or ""
            reduce = rv_audit._num(row.get("Уменьшение")) or 0
            if action == "как в 1С" and reduce > 0:
                # ЛРВ уменьшилась, работа та же: минус на уменьшение. Строка целиком под несколькими работами 1С
                # (не разбита на части) — минус по каждой работе 1С на её долю.
                entries = [w for w in row.get("РаботыВ1С") or [] if isinstance(w, dict) and (rv_audit._num(w.get("Уменьшение")) or 0) > 0] \
                    if isinstance(row.get("РаботыВ1С"), list) else []
                if row.get("Часть") or len(entries) < 2:
                    entries = [{"Код": position["КодИерархии"], "Наименование": position["Наименование"], "Уменьшение": reduce,
                                "СметнаяПозицияGUID": position["СметнаяПозицияGUID"]}]
                for entry in entries:
                    cut = rv_audit._num(entry.get("Уменьшение")) or 0
                    target = by_code.get(entry.get("Код") or "") or {}
                    changes.append(dict(base, Действие="уменьшить",
                                        СметнаяПозицияGUID=entry.get("СметнаяПозицияGUID") or target.get("СметнаяПозицияGUID") or "",
                                        УИДУзлаДерева=target.get("УИДУзлаДерева") or "", КодИерархии=entry.get("Код") or "",
                                        Работа=entry.get("Наименование") or target.get("Наименование") or "",
                                        Количество=-cut, КоличествоВСмету=_minus(_share(row, cut, "КоличествоВСмету")),
                                        Сумма=_minus(_share(row, cut, "Сумма")), СуммаВСмету=_minus(_share(row, cut, "СуммаВСмету")),
                                        КоличествоВ1С=row.get("КоличествоВ1С")))
                continue
            if action not in ("привязать", "перепривязать"):
                continue
            if action == "перепривязать":
                old_code = row.get("РаботаВ1С") or ""
                old = next((w for w in row.get("РаботыВ1С") or [] if w.get("Код") == old_code), {}) if isinstance(row.get("РаботыВ1С"), list) else {}
                old_qty = rv_audit._num(old.get("Количество")) if old and not row.get("Часть") else qty
                old_qty = old_qty if old_qty is not None else qty
                if reduce > 0 and rv_audit._num(row.get("КоличествоВ1С")) is not None:
                    old_qty = rv_audit._num(row.get("КоличествоВ1С"))     # ЛРВ уменьшилась: со старой работы снимается всё, что там было
                changes.append(dict(base, Действие="перепривязать", СметнаяПозицияGUID=old.get("СметнаяПозицияGUID") or "",
                                    УИДУзлаДерева="", КодИерархии=old_code, Работа=old.get("Наименование") or "",
                                    Количество=-old_qty, КоличествоВСмету=-_share(row, old_qty, "КоличествоВСмету"),
                                    Сумма=-_share(row, old_qty, "Сумма"), СуммаВСмету=-_share(row, old_qty, "СуммаВСмету")))
            changes.append(dict(base, Действие=action, СметнаяПозицияGUID=position["СметнаяПозицияGUID"], УИДУзлаДерева=position["УИДУзлаДерева"],
                                КодИерархии=position["КодИерархии"], Работа=position["Наименование"],
                                Количество=qty, КоличествоВСмету=_share(row, qty, "КоличествоВСмету"),
                                Сумма=_share(row, qty, "Сумма"), СуммаВСмету=_share(row, qty, "СуммаВСмету"),
                                РешениеИнженера=row.get("РешениеИнженера") or "", Уверенность=row.get("Уверенность")))
    return {"Документ": doc, "СметныеПозиции": positions, "ТЧИзменений": changes, "Товары": goods,
            "Итого": {"Позиций": len(positions), "НовыхПозиций": sum(1 for p in positions if not p["ЕстьВСмете"]),
                      "Изменений": len(changes), "Привязать": sum(1 for c in changes if c["Действие"] == "привязать"),
                      "Уменьшить": sum(1 for c in changes if c["Действие"] == "уменьшить"),
                      "РаботСметчика": sum(1 for p in positions if p["ДобавленоСметчиком"]),
                      "Перепривязать": sum(1 for c in changes if c["Действие"] == "перепривязать" and c["Количество"] > 0),
                      "СтрокРВ": len(goods)}}


def onec_action(binding):
    """Что 1С делать со строкой при загрузке в «Сопоставление РВ и ЛРВ»: «привязать» — в 1С не разнесена;
    «как в 1С» — разнесена, работа и коэффициент те же (или агент не согласен, но инженер оставил 1С); «перепривязать» —
    инженер в этой проверке выбрал другую работу или другой коэффициент (пара строк изменений: −количество со старой
    работы или со старым коэффициентом, + на новую)."""
    onec = binding.get("onec_code") or ""
    if not onec:
        return "привязать" if binding.get("code") else ""
    if binding.get("code") != onec:
        return "перепривязать"
    # Та же работа, но инженер задал другой коэффициент: 1С снимает строку со старым коэффициентом и ставит с новым.
    was = binding.get("coef_onec")
    now = binding.get("coef_user", binding.get("coef"))
    if was is not None and now is not None and abs(float(now) - float(was)) > 1e-9:
        return "перепривязать"
    return "как в 1С"


def _row_1c(item, binding, qty, rec):
    row = dict(item.get("ext") or {})
    row.update({
        "ИдентификаторСтроки": item.get("uid") or "", "Код": item.get("code_1c") or "",
        "Номенклатура": item.get("name") or binding.get("name") or "", "ЕдиницаИзмерения": item.get("unit") or "",
        "Количество": qty, "КоличествоВсего": item.get("qty_total", item.get("qty")),
        "Система": item.get("system") or "", "Коэффициент": binding.get("coef_user", binding.get("coef", 0)),
        "Роль": binding.get("role") or "", "Уверенность": rv_output.percent(binding.get("confidence")),
        "НаПроверку": bool(binding.get("review")) or not binding.get("code"),
        "РешениеИнженера": binding.get("learned") or "",
        "СтрокаЛРВ": item.get("row"),
        "РаботаВ1С": binding.get("onec_code") or "",
        "Действие": onec_action(binding),
    })
    if item.get("split_of") is not None:
        # часть строки, разнесённой на несколько работ: доля - весовой коэффициент, 1С вычитает со старой работы только её
        total = bind_fnum(item.get("qty_total")) or 0
        row["Часть"] = "%d/%d" % (int(item.get("split_k") or 0) + 1, int(item.get("split_n") or 1))
        row["ВесовойКоэф"] = round(float(qty or 0) / total, 4) if total else 1
    reduce = item.get("reduce")
    if reduce:
        # ЛРВ уменьшилась: «Количество» — сколько остаётся под работой, «КоличествоВ1С» — сколько было, «Уменьшение» —
        # разница (1С снимает её с работы: строка изменений с минусом); «Действие» — как у строки без уменьшения.
        row["Уменьшение"] = reduce["qty"]
        row["КоличествоВ1С"] = reduce["before"]
        row["КоличествоВсегоВ1С"] = reduce.get("total", reduce["before"])
    if rec and rec.get("verdict") and binding.get("learned") != "correction":
        row["РекомендацияМодели"] = {"Вердикт": rec.get("verdict"), "КодИСР": rec.get("code") or "", "Причина": rec.get("reason") or ""}
    return row


def form_path(args):
    """Строки формы и каталог работ для страницы проверки — отдельный файл рядом с результатом
    (страница читает его как есть, без разбора JSON в PHP)."""
    path = args.out_json
    if path.endswith(".json.gz"):
        return path[:-len(".json.gz")] + "_form.json.gz"
    return os.path.splitext(path)[0] + "_form.json"


def row_coefs(items, bindings, volumes):
    """Коэффициент каждой строки: сколько единиц работы даёт одна единица материала — то, из чего
    bind.volumes складывает объём (м² на 1 шт воздуховода, т на 1 м уголка, 1 для трубы в метрах).
    Считается тем же volume_of по одной строке; строки, чьи классы в сумме объём не ведут
    (принадлежности при нескольких ведущих классах, классы не из имени работы), и Кр — 0.
    Возвращает {id строки: коэффициент}."""
    import bind
    by_code = {}
    coefs = {}
    for item, binding in zip(items, bindings):
        code = binding.get("code")
        if not code:
            continue
        if binding.get("role") == "Кр":
            coefs[item["id"]] = 0
            continue
        by_code.setdefault(code, []).append((item, binding))
    for code, pairs in by_code.items():
        method = (volumes.get(code) or {}).get("method") or ""
        work_unit = (bind.KB.get("kc") or {}).get(code, {}).get("unit", "")
        per, classes = {}, {}
        for item, binding in pairs:
            qty = bind.fnum(item.get("qty"))
            if not qty and item.get("reduce"):
                qty = 1.0       # строка снята по ЛРВ целиком (количество 0): коэффициент — как у одной единицы, а не 0
            if not qty:
                per[item["id"]] = 0
                continue
            if method.startswith("F-VOL: ведущая группа КЦ не найдена"):
                per[item["id"]] = 1 if binding.get("role") == "В" and bind.nunit(item.get("unit")) == work_unit else 0
                continue
            fitting = bind.fitting_length(code, item["name"], item.get("unit"))
            if fitting:
                # [В 11.11] фасонная часть трубопровода: коэффициент — её длина по оси, м (каталог, bind.fitting_length);
                # в разбор «ведущих классов» ниже не идёт — иначе обнулилась бы как принадлежность.
                per[item["id"]] = fitting[0]
                continue
            value, how, _ = bind.volume_of(code, [(item["name"], item.get("unit"), qty)])
            if value is None or (how.startswith("F-VOL") and not method.startswith("F-VOL: ведущих строк нет")):
                per[item["id"]] = 0
                continue
            per[item["id"]] = round(value / qty, 6)
            matched = bind.match_group(code, item["name"], item.get("unit"))
            classes[item["id"]] = bind.hstem(matched[0]["name"]) if matched else bind.hstem(item["name"])
        leading = {cls for item_id, cls in classes.items() if per.get(item_id)}
        # ОВ2 «площадь по геометрии»: объём работы в bind.volume_of складывают все изделия воздуховодов — и переходы,
        # тройники, крестовины, заглушки (в ACCESSORY они принадлежности только для других разделов), поэтому их
        # коэффициенты не обнуляются: иначе Σ количество × коэффициент расходится с объёмом, а в 1С уходит 0.
        if len(leading) > 1 and not method.startswith(bind.DUCT_AREA_METHOD):
            work_name = bind.KB["works"].get(code, "")
            keep = {cls for cls in leading if cls not in bind.ACCESSORY} or leading
            named = {cls for cls in keep if cls in bind.toks(work_name)}
            keep = named or keep
            for item_id, cls in classes.items():
                if cls not in keep:
                    per[item_id] = 0
        if bind.PAINT_WORK.search(bind.KB["works"].get(code, "")):
            per = paint_coefs(pairs, (volumes.get(code) or {}).get("volume"))
        elif "парной работы" in method:
            per = {item_id: 0 for item_id in per}      # объём берётся не из своих строк
        coefs.update(per)
    return coefs


PAINT_PRIMER = re.compile(r"^грунт")
PAINT_COAT = re.compile(r"^(краск|эмал)")


def paint_coefs(pairs, volume):
    """[В 10.11] Окраска трубопроводов: объём работы — площадь окрашиваемых труб (bind.paint_area), а в 1С он
    складывается как Σ количество × коэффициент по строкам работы. Поэтому коэффициент получает грунтовка:
    площадь / Σ количества грунтовки (строк грунтовки несколько — у всех один); краска, эмаль, растворитель — 0.
    Грунтовки в работе нет — коэффициент так же у краски / эмали; нет и их — у всех 0.
    pairs — [(строка, привязка)] работы. Возвращает {id строки: коэффициент}."""
    import bind
    per = {item["id"]: 0 for item, _ in pairs}
    if not volume:
        return per
    for pattern in (PAINT_PRIMER, PAINT_COAT):
        rows = [item for item, binding in pairs
                if binding.get("role") != "Кр" and pattern.match(bind.norm(item["name"]))]
        total = sum(max(bind.fnum(item.get("qty")) or 0, 0) for item in rows)
        if total > 0:
            coef = round(float(volume) / total, 6)
            for item in rows:
                per[item["id"]] = coef
            return per
    return per


def onec_coef_of(item, code):
    """Коэффициент строки в 1С для работы code («РаботыВ1С» → «Коэффициент»); None — в 1С строка не на этой работе
    или коэффициента нет. Строка на одной работе дважды (разные изменения) — у большего количества."""
    best = None
    for work in rv_audit.works_1c(item.get("ext")):
        if work["code"] == code and work["coef"] is not None and (best is None or (work["qty"] or 0) > (best["qty"] or 0)):
            best = work
    return best["coef"] if best else None


def apply_onec_coefs(items, bindings, coefs, own_token=""):
    """Коэффициент, проведённый в 1С, агент сам не меняет. У строки, разнесённой в 1С на ту же работу, коэффициент —
    из 1С (binding['coef_onec'], он же в coefs); коэффициент агента — расчёт или память решений по другим РВ —
    только предложение (binding['coef_agent'], если отличается): инженер принимает его на странице проверки.
    Решение инженера в этой же РВ (коэффициент из памяти с её token) сильнее 1С и уходит в 1С заменой коэффициента.
    Возвращает число строк, где агент предлагает другой коэффициент."""
    suggested = 0
    for item, binding in zip(items, bindings):
        code = binding.get("code")
        if not code:
            continue
        onec = onec_coef_of(item, code)
        if onec is None:
            continue
        binding["coef_onec"] = onec
        binding.pop("coef_agent", None)
        if binding.get("coef_user") is not None and own_token and binding.get("learned_token") == own_token:
            continue        # инженер в этой проверке задал коэффициент сам
        agent = binding.pop("coef_user", None)
        if agent is None:
            agent = coefs.get(item["id"], 0)
        coefs[item["id"]] = onec
        if abs(float(agent) - float(onec)) > 1e-9:
            binding["coef_agent"] = round(float(agent), 6)
            suggested += 1
    return suggested


def apply_coef_overrides(items, bindings, volumes, coefs):
    """Коэффициенты, исправленные инженером (binding['coef_user'] из памяти решений), и проведённые в 1С, когда они
    расходятся с расчётом агента (binding['coef_onec'], см. apply_onec_coefs): объём работы пересчитывается
    как Σ количество × коэффициент по всем её строкам, где хотя бы один такой."""
    import bind
    touched = {}
    by_user = set()
    computed = {}
    for item, binding in zip(items, bindings):
        if not binding.get("code"):
            continue
        if binding.get("coef_user") is not None:
            touched.setdefault(binding["code"], 0)
            by_user.add(binding["code"])
        elif binding.get("coef_onec") is not None and binding.get("coef_agent") is not None:
            touched.setdefault(binding["code"], 0)
    if not touched:
        return
    for item, binding in zip(items, bindings):
        code = binding.get("code")
        fixed = binding.get("coef_user") if binding.get("coef_user") is not None else binding.get("coef_onec")
        if code not in touched or (binding.get("role") == "Кр" and fixed is None):
            continue
        qty = bind.fnum(item.get("qty")) or 0
        coef = fixed if fixed is not None else coefs.get(item["id"], 0)
        coefs[item["id"]] = coef
        touched[code] += qty * coef
        computed[code] = True
    for code, total in touched.items():
        entry = volumes.setdefault(code, dict(volume=None, unit=(bind.KB.get("kc") or {}).get(code, {}).get("unit", ""),
                                              method="", work=bind.KB["works"].get(code, "")[:90], notes=[]))
        entry["volume"] = round(total, 4) if total else None
        entry["method"] = "по коэффициентам %s: Σ количество × коэффициент" % ("инженера" if code in by_user else "1С")


def _catalog(works, root="6"):
    """Коды и имена работ по разделам — для выбора работы на странице проверки
    (без выведенных из оборота): [код, имя, единица, ветка системы по ИСР]. root — код работ РВ: «12» — только
    работы кода 12 (заказ-наряд РВР), иначе — без них."""
    from rv_common import sec_of
    isr = rv_form.names()
    catalog = {}
    for code, name in works.items():
        if "НЕ ИСПОЛЬЗОВАТЬ" in name.upper() or code.startswith("12.") != (root == "12"):
            continue
        parts = code.split(".")
        branch = isr.get(".".join(parts[:5]), "") if len(parts) > 5 else ""
        catalog.setdefault(sec_of(code), []).append([code, name, bind_unit(code), branch])
    for entries in catalog.values():
        entries.sort(key=lambda e: [int(x) if x.isdigit() else x for x in e[0].split(".")])
    return catalog


def bind_unit(code):
    import bind
    return (bind.KB.get("kc") or {}).get(code, {}).get("unit", "")


def element_blocks(active, order):
    """Строки ЛРВ по блокам «раздел · элемент» в порядке order: [(раздел, элемент, строки блока)]; id строк — сквозные
    с 1 (по ним сохранены решения сметчика в этой РВ). Каждый вызов — новые словари строк."""
    blocks = []
    next_id = 1
    for block_section, element in order:
        block_items = []
        for item in active:
            if (item.get("section") if item.get("system") else None) != block_section or (item.get("element") or "") != element:
                continue
            block_item = {"id": next_id, "name": item["name"], "unit": item.get("unit") or "",
                          "qty": item["qty"], "system": item.get("system"), "row": item["row"],
                          "element": element, "header_path": item.get("header_path", ""),
                          "unit_source": item.get("unit_source")}
            for key in ("code_1c", "uid", "ext", "reduce"):      # идентификаторы из 1С — сквозь РВ обратно в 1С
                if item.get(key):
                    block_item[key] = item[key]
            block_items.append(block_item)
            next_id += 1
        blocks.append((block_section, element, block_items))
    return blocks


def run_bind(args):
    """Фаза 2: по подтверждённой разметке — привязка, проверка, книга Excel.
    С --feedback-file — повтор после проверки инженером: решения в память, привязка заново
    с их учётом; с --no-review проверка моделью не повторяется (переносится прежняя)."""
    started = int(time.time())
    status = Status(args.status_file, started, keep_log=True)
    status.log("подтверждённая разметка получена, начинаю привязку" if not _auto_phase(args) else "начинаю привязку")
    status.update("running", "применяю разметку…")
    rollback_stats = _forget(args, status)
    previous, feedback_stats = _feedback(args, status)
    if previous is None and getattr(args, "no_review", False) and os.path.exists(args.out_json):
        previous = _read(args.out_json)      # пересборка без проверки моделью: прежние рекомендации переносятся
    if feedback_stats is None and getattr(args, "rebuild", False):
        # Пересборка по кнопке: решения инженера уже в памяти и применятся сами, память не трогаем;
        # согласование остаётся — иначе РВ стала бы «не согласована» и 1С перестала бы её забирать.
        feedback_stats = status.previous.get("feedback") if isinstance(status.previous.get("feedback"), dict) else None
        status.log("пересборка по запросу%s: привязка и коэффициенты заново, согласование %s"
                   % (" (%s)" % args.user if args.user else "",
                   "останется, если РВ для 1С не изменится" if feedback_stats else "не было"))
    work = json.load(open(args.work_file, encoding="utf-8"))
    section = work["section"]
    items = work["items"]
    parsed = dict(items=items, headers=work["headers"], columns=work["columns"])
    raw_marks = work.get("marks") or {}
    if isinstance(raw_marks, list):      # PHP мог записать список, если индексы шли подряд
        raw_marks = dict(enumerate(raw_marks))
    marks = {int(k): v for k, v in raw_marks.items()}
    default_system = work.get("default_system")
    force_system = work.get("force_system")
    notes = list(work.get("notes") or [])
    drainage = rv_input.fix_drainage_marks(parsed["headers"], marks)
    if drainage:
        status.log("дренажная канализация — ветка КЦ 4 (К4), не 3 (производственная): %s" % "; ".join(drainage[:5]))
    rv_input.apply_marks(section, parsed, marks, default_system, force_system)
    if force_system:
        notes.append("Все строки отнесены к системе «%s» — выбрана при загрузке." % force_system.replace("|", " / "))
    elif work.get("confirmed") == "auto":
        notes.append("Подтверждение систем не понадобилось: %s." % (work.get("confirm_reason") or "системы есть в файле"))
    skipped = [it for it in items if it.get("skip")]
    if skipped:
        reasons = {}
        for item in skipped:
            reasons[item["skip"]] = reasons.get(item["skip"], 0) + 1
        notes.append("Не включено в РВ %d строк: %s." % (
            len(skipped), "; ".join("%s — %d" % (reason, count) for reason, count in sorted(reasons.items()))))
    active = [it for it in items if not it.get("skip")]
    without_system = [it for it in active if not it.get("system") or not it.get("section")]
    if without_system:
        notes.append("У %d строк не определены раздел и система — для них код работы не выбран (F-CTX)." % len(without_system))
    if default_system and work["headers"] and not force_system:
        notes.append("Строки без системы в заголовках отнесены к системе «%s»." % default_system.replace("|", " / "))
    from_library, guessed = _fill_units(active, status.log)
    if from_library or guessed:
        notes = [n for n in notes if not n.startswith("В выгрузке нет колонки единиц")]
        notes.append("Единиц измерения в выгрузке нет: взяты из эталонной библиотеки для %d строк, по типу материала — "
                     "для %d (флаг F-UNIT). Точнее — добавить в отчёт 1С поле «Единица измерения»." % (from_library, guessed))
    object_type = work.get("object_type")
    client = _client(args.credentials, status.log)

    # ── Привязка по разделам и элементам ──
    status.log("загружаю данные агента (справочник КЦ, библиотека)…")
    status.update("running", "загружаю данные агента…")
    import bind  # noqa: E402 — импорт здесь: загрузка данных долгая, статус уже записан
    try:
        bind.load(DATA_DIR)
    except MemoryError:
        status.update("error", "не хватило памяти",
                      error="Агенту РВ не хватило памяти сервера при загрузке справочника. Сообщите администратору.")
        return 1
    # Заказ-наряд РВР: работы кода 12. Агент подбирает работу по правилам кода 6 и ставит её пару из кода 12 (bind.to_rvr).
    rvr = code_root(args) == "12"
    bind.RVR = rvr
    rv_agent.CODE_TRANSLATE = None
    if rvr:
        bind.load_rvr(DATA_DIR)
        rv_agent.CODE_TRANSLATE = bind.rvr_code
        status.log("заказ-наряд РВР: РВ собирается в коде 12 (работ кода 12 в справочнике агента: %d, пар с кодом 6: %d)" % (
            sum(1 for code in bind.KB["works"] if code.startswith("12.")), len(bind.KB.get("rvr") or {})))
    status.log("данные агента загружены (%s)" % _memory())
    learning = rv_learning.load(getattr(args, "learning_file", None))
    if learning:
        status.log("память решений инженеров: %d записей" % len(learning))
    local = local_input(args) if audit_input(args) is None else None
    local_text, local_blocks, local_used, local_skipped = ("", [], [], [])
    local_agent = None          # итог модели по указаниям, если она смотрела РВ в этот запуск
    local_error = ""
    local_changed = 0
    if local:
        local_text, local_blocks, local_used, local_skipped = local_material(local)
        status.log("указания для этой РВ: %s%s%s" % (
            "текст" if str(local.get("text") or "").strip() else "без текста",
            (", файлы: " + ", ".join(local_used)) if local_used else "",
            ("; не прочитаны: " + "; ".join("%s — %s" % pair for pair in local_skipped)) if local_skipped else ""))
    learned = dict(corrected=0, confirmed=0, transferred=0)
    splits = engineer_splits(previous, getattr(args, "feedback_file", ""))
    added_works = engineer_works(previous, getattr(args, "feedback_file", ""))
    added_taken = set()
    manual_added = 0
    reduced_rows = 0
    if audit_input(args) is None:
        packet = packet_input(args)
        filled = fill_onec_sums(active, onec_sums_of(packet)) if packet is not None else 0
        if filled:
            status.log("суммы разнесённого в 1С взяты из пакета 1С: строк %d" % filled)
        reduced_rows, reduce_notes = apply_reductions(active, reductions_of(packet) if packet is not None else [])
        notes.extend(reduce_notes)
        if reduced_rows:
            status.log("уменьшение по ЛРВ: материалов %d" % reduced_rows)
    split_stats = dict(engineer=0, onec=0)
    onec_stats = dict(bound=0, disputed=0, not_in_smeta=0)
    smeta = smeta_input(args, bind.KB["works"], *smeta_branch(active))
    if smeta:
        status.log("работы сметы из 1С: %d" % len(smeta))
    ONEC_ONLY.clear()
    if audit_input(args) is None:
        onec_only = register_onec_works(active, smeta, "12" if rvr else "6")
        if onec_only:
            status.log("работы из 1С, которых нет в справочнике КЦ агента (взяты из 1С на эту РВ): %s" % "; ".join(
                "%s — %s" % (code, name[:70]) for code, name in sorted(onec_only.items())[:10]))
            notes.append("Работ из 1С нет в справочнике КЦ агента: %d (%s) — строки на них оставлены как в 1С; "
                         "справочник агента нужно обновить из свежей выгрузки КЦ." % (
                             len(onec_only), ", ".join(sorted(onec_only)[:5])))
    auto_added = 0
    status.update("running", "привязываю строки к работам…")
    order = []
    for item in active:
        key = (item.get("section") if item.get("system") else None, item.get("element") or "")
        if key not in order:
            order.append(key)
    section_rank = lambda s: rv_input.SECTIONS.index(s) if s in rv_input.SECTIONS else 99  # noqa: E731
    sections = sorted({key[0] for key in order if key[0]}, key=section_rank)
    position = {key: index for index, key in enumerate(order)}
    order.sort(key=lambda key: (section_rank(key[0]) if key[0] else 100, key[1] != "", position[key]))
    many = len(sections) > 1 or any(key[0] is None for key in order)

    def prepare(block_section, block_items):
        """Привязка блока до объёмов: инструмент, память решений, указания этой РВ, разнесённое в 1С."""
        bindings = bind.bind(block_section, block_items, object_type)
        by_id = {b["id"]: b for b in bindings}
        ordered = [by_id[it["id"]] for it in block_items]
        for binding, item in zip(ordered, block_items):
            binding["system_code"] = bind.sys_code(block_section, item.get("system"))
        stats = rv_learning.apply(learning, block_section, block_items, ordered, bind.KB["works"], bind.fam_of,
                                  bind.sys_code, log=status.log if local_agent is not False else None)
        changed = 0
        if local and (local.get("agent") or {}).get("rows"):
            changed = apply_local_agent(block_items, ordered, local["agent"]["rows"], bind.KB["works"], bind.fam_of,
                                        job_token(args))
        if local and local.get("fixes"):
            apply_local_fixes(block_items, ordered, local["fixes"], bind.KB["works"], bind.fam_of, job_token(args))
        onec = dict(bound=0, disputed=0, not_in_smeta=0)
        if audit_input(args) is None:
            # Обычная ЛРВ из 1С: разнесённое в 1С и работы сметы (сверка идёт отдельно, там агент разносит сам).
            # Спецификации номенклатуры 1С («СпецОсновнаяСметнаяПозицияНоменклатура») агент не применяет:
            # он учится на решениях сметчиков на сайте.
            onec = apply_onec(block_items, ordered, bind.KB["works"], bind.fam_of, smeta, job_token(args),
                              section=block_section)
        return ordered, stats, changed, onec

    if local and local.get("agent") is None and not getattr(args, "feedback_file", None) \
            and not getattr(args, "no_review", False):
        # Указания только что сохранены: модель смотрит все строки с ТЗ сметчика, её замены запоминаются в файле
        # указаний этой РВ (agent) и применяются при этой и следующих привязках этой РВ.
        if client is None:
            local_error = "модель недоступна"
            status.log("указания для этой РВ: " + local_error)
        else:
            local_agent = False          # подготовка: память решений второй раз в журнал не пишем
            prepared = []
            for block_section, element, block_items in element_blocks(active, order):
                if block_section is not None:
                    prepared.append((block_section, block_items, prepare(block_section, block_items)[0]))
            total = sum(len(b) for _, _, b in prepared)
            status.update("running", "модель пересобирает РВ по указаниям: %d строк…" % min(total, LOCAL_REVIEW_MAX))
            status.log("пересборка по указаниям: модель %s (усилие %s) смотрит строки РВ" % rv_agent.model_of(client))

            def local_progress(done, total_rows):
                status.update("running", "модель пересобирает РВ по указаниям: %d из %d строк…" % (done, total_rows))

            try:
                local_agent = local_agent_pass(
                    client, prepared, object_type, local_text, local_blocks, bind.KB["works"], job_token(args),
                    smeta=smeta_text(smeta) if smeta else None,
                    guidance_of=lambda sec: engineer_notes(getattr(args, "notes_file", ""), sec),
                    log=status.log, progress=local_progress, heartbeat=status.touch)
                local["agent"] = dict(rows=local_agent["rows"], stats=local_agent["stats"], at=int(time.time()),
                                      by=getattr(args, "user", "") or "")
                _update_local(args, agent=local["agent"])
                s = local_agent["stats"]
                status.log("по указаниям: модель проверила %d строк — изменила %d, подтвердила %d, вопросов %d, "
                           "разнесено в 1С иначе — предложено %d" % (s["checked"], s["changed"], s["confirmed"],
                                                                      s["questions"], s["onec_proposed"]))
            except Exception as exc:  # noqa: BLE001
                local_agent = None
                local_error = "модель не смогла пересобрать по указаниям: %s" % _short(exc)
                status.log("указания для этой РВ: " + local_error)
    elements = []
    for block_section, element, block_items in element_blocks(active, order):
        if many:
            label = (block_section or "без раздела") + (" · " + element if element else "")
        else:
            label = element
        status.update("running", "привязываю строки к работам… %s, %d строк" % (label or "без элемента", len(block_items)))
        if block_section is None:
            ordered = [_stub_binding(it, "раздел и система не определены") for it in block_items]
            volumes, distribution = {}, []
            rv = dict(works=[], unbound=[dict(id=it["id"], name=it["name"]) for it in block_items])
        else:
            ordered, stats, changed, onec = prepare(block_section, block_items)
            for key in learned:
                learned[key] += stats.get(key, 0)
            local_changed += changed
            for key in onec_stats:
                onec_stats[key] += onec.get(key, 0)
            for binding in ordered:
                if binding.get("alts") and binding.get("learned") in ("correction", "confirmed", "onec"):
                    binding["alts"] = []        # работу задали память решений, 1С или спецификация - варианты не нужны
                    binding["flags"] = [f for f in (binding.get("flags") or []) if not f.startswith("F-ALT")]
                    binding["fcodes"] = [c for c in (binding.get("fcodes") or []) if c != "F-ALT"]
            block_items, ordered, stats = apply_splits(block_items, ordered, splits, bind.KB["works"], bind.fam_of,
                                                       block_section, log=status.log)
            for key in split_stats:
                split_stats[key] += stats.get(key, 0)
            volumes = bind.volumes(block_section, block_items, ordered)
            coefs = row_coefs(block_items, ordered, volumes)
            if audit_input(args) is None:
                suggested = apply_onec_coefs(block_items, ordered, coefs, job_token(args))
                if suggested:
                    status.log("коэффициенты: как в 1С, у %d строк агент предлагает свой (%s)" % (suggested, block_section))
            apply_coef_overrides(block_items, ordered, volumes, coefs)
            distribution = bind.distribute(block_section, block_items, ordered, volumes)
            rv = bind.rv(block_section, block_items, ordered, volumes, distribution)
            # Работы без материалов (гидроиспытания, испытание и наладка, ПНР ВРУ, сдача систем СКБ) —
            # в ЛРВ их нет, в ТКП из 1С есть: добавляются по правилам rv_extra, «на проверку».
            # Работы без материалов (испытания, сдача систем) — по структуре кода 6; в РВР (код 12) агент их не добавляет.
            extra = [] if rvr else rv_extra.add_works(block_section, rv["works"], bind.KB["works"], bind.KB["kc"], object_type)
            if extra:
                rv["works"].extend(extra)
                auto_added += len(extra)
            if added_works:
                # Работы сметчика («Добавить работу» на странице проверки): без материалов, объём вручную.
                count, work_notes_added = apply_engineer_works(block_section, rv["works"], added_works, bind.KB["works"],
                                                               bind.KB["kc"], added_taken)
                manual_added += count
                notes.extend(work_notes_added)
        for binding, item in zip(ordered, block_items):
            binding["coef"] = coefs.get(item["id"], 0) if block_section else 0
            binding["unit"] = item.get("unit") or ""
            binding["qty"] = item.get("qty")
            binding["row"] = item.get("row")
            if item.get("unit_source") == "по типу":
                binding.setdefault("flags", []).append("F-UNIT: единица «%s» взята по типу материала (в выгрузке нет)" % item["unit"])
                if "F-UNIT" not in (binding.get("fcodes") or []):
                    binding["fcodes"] = sorted(set(binding.get("fcodes") or []) | {"F-UNIT"})
        elements.append(dict(element=label, section=block_section, items=block_items, bindings=ordered, volumes=volumes,
                             distribution=distribution, rv=rv))
    all_items = [it for block in elements for it in block["items"]]
    all_bindings = [b for block in elements for b in block["bindings"]]
    status.log("привязка: строк %d, на проверку %d, без работы %d"
               % (len(all_bindings), sum(1 for b in all_bindings if b.get("review")),
                  sum(1 for b in all_bindings if not b.get("code"))))

    # ── Проверка моделью: по разделам, не больше REVIEW_MAX строк (сначала без работы, потом по уверенности) ──
    review = {}
    questions = []
    review_note = "не выполнялась: модель недоступна"
    todo_all = [b for block in elements if block["section"] for b in block["bindings"]
                if b.get("review") or not b.get("code")]
    audit = audit_input(args)
    audit_text = None
    if audit is not None:
        # Сверка: модель смотрит только строки, где разнос в 1С и агента расходятся, видя работу из 1С.
        pre = rv_audit.compare(elements, audit.get("works"), kb_works=bind.KB["works"])
        disputed = {row["id"]: row for row in pre["rows"] if row["status"] in rv_audit.DISPUTED}
        audit_text = {rid: rv_audit.text_1c(row["c1"], bind.KB["works"]) for rid, row in disputed.items()}
        todo_all = [b for block in elements if block["section"] for b in block["bindings"] if b["id"] in disputed]
        status.log("сверка с 1С: совпадает %d строк, расходится %d, в 1С не разнесено %d"
                   % (pre["summary"]["match"], pre["summary"]["disputed"], pre["summary"]["no_1c"]))
    todo_all.sort(key=lambda b: (bool(b.get("code")), b.get("confidence") or 0))
    chosen = todo_all[:REVIEW_MAX]
    if local_agent:
        # Модель только что смотрела РВ по указаниям (local_agent_pass): её вердикты по строкам, которые она не меняла.
        review = dict(local_agent["review"])
        questions = list(local_agent["questions"])
        s = local_agent["stats"]
        review_note = "по указаниям для этой РВ: проверено %d строк — изменено %d, подтверждено %d, вопросов %d%s%s" % (
            s["checked"], s["changed"], s["confirmed"], s["questions"],
            ("; разнесено в 1С иначе — предложено %d" % s["onec_proposed"]) if s["onec_proposed"] else "",
            ("; не проверено %d строк с большей уверенностью (предел %d)" % (s["not_checked"], LOCAL_REVIEW_MAX))
            if s["not_checked"] else "")
    elif getattr(args, "no_review", False) and previous is not None:
        corrected_ids = {str(b["id"]) for block in elements for b in block["bindings"] if b.get("learned") == "correction"}
        review = {k: v for k, v in (previous.get("review") or {}).items() if str(k) not in corrected_ids}
        questions = list(previous.get("questions") or [])
        review_note = "не повторялась при пересборке; прежняя: %s" % (
            (previous.get("summary") or {}).get("review_note") or "—")
    elif not todo_all:
        review_note = "не нужна: расхождений с 1С нет" if audit is not None else "не нужна: строк на проверку нет"
    elif client is not None:
        status.update("running", "проверяю %d строк по карточкам разделов…" % len(chosen))
        status.log("проверка строк моделью %s (усилие %s)" % rv_agent.model_of(client))
        chosen_ids = {b["id"] for b in chosen}
        checked = [0]

        def progress(done, total, base=checked):
            status.update("running", "проверяю строки по карточкам разделов: %d из %d…"
                          % (base[0] + done, len(chosen)))

        try:
            for block_section in sections:
                sec_items = [it for block in elements if block["section"] == block_section for it in block["items"]]
                sec_bindings = [b for block in elements if block["section"] == block_section for b in block["bindings"]
                                if b["id"] in chosen_ids]
                if not sec_bindings:
                    continue
                part, part_questions = rv_agent.review_rows(client, block_section, object_type, sec_items, sec_bindings,
                                                            bind.KB["works"], log=status.log,
                                                            guidance=engineer_notes(getattr(args, "notes_file", ""), block_section),
                                                            progress=progress, heartbeat=status.touch, audit=audit_text,
                                                            smeta=smeta_text(smeta) if smeta else None,
                                                            local=local_text or None, local_blocks=local_blocks or None)
                checked[0] += len(sec_bindings)
                review.update(part)
                questions.extend(part_questions)
            counts = {}
            for entry in review.values():
                counts[entry["verdict"]] = counts.get(entry["verdict"], 0) + 1
            review_note = "проверено %d строк: подтвердить %d, заменить %d, вопрос %d" % (
                len(review), counts.get("подтвердить", 0), counts.get("заменить", 0), counts.get("вопрос", 0))
            if len(todo_all) > len(chosen):
                review_note += "; %d строк с большей уверенностью не проверялись (предел %d за запуск)" % (
                    len(todo_all) - len(chosen), REVIEW_MAX)
        except Exception as exc:  # noqa: BLE001
            status.log("проверка моделью не удалась: %s" % exc)
            review_note = "не удалась: %s" % _short(exc)

    # Вердикты по id строки — строкой, как в JSON результата: страница проверки, Excel и РВ для 1С ищут их одинаково
    # и после свежей проверки моделью, и после переноса прежней (там ключи уже строки).
    review = {str(k): v for k, v in review.items()}

    # ── Итог ──
    status.update("running", "собираю книгу Excel…")
    if auto_added:
        notes.append("Добавлено работ без материалов (гидроиспытания, испытание и наладка, ПНР): %d — объёмы по работам РВ, "
                     "проверить." % auto_added)
    if onec_stats["bound"]:
        notes.append("Разнесено в 1С: %d строк — взята работа из 1С%s. Оставить как в 1С — ничего не делать; принять агента — "
                     "«Исправить» или «принять» у рекомендации." % (
                         onec_stats["bound"], (", агент не согласен по %d (F-1C, на проверку)" % onec_stats["disputed"]) if onec_stats["disputed"] else ""))
    if smeta and onec_stats["not_in_smeta"]:
        notes.append("Работ не из сметы 1С: %d строк (F-SMETA) — при загрузке в 1С такие работы добавятся новыми сметными позициями." % onec_stats["not_in_smeta"])
    if learned["corrected"] or learned["confirmed"]:
        notes.append("Учтены решения инженеров из памяти агента: исправлено %d строк, подтверждено %d%s." % (
            learned["corrected"], learned["confirmed"],
            (", перенесено из других систем %d" % learned["transferred"]) if learned["transferred"] else ""))
    summary = dict(
        rows=len(all_bindings),
        done=sum(1 for b in all_bindings if b.get("code") and not b.get("review")),
        review=sum(1 for b in all_bindings if b.get("code") and b.get("review")),
        unbound=sum(1 for b in all_bindings if not b.get("code")),
        works=sum(len(block["rv"]["works"]) for block in elements),
        works_with_volume=sum(1 for block in elements for w in block["rv"]["works"] if w.get("volume")),
        kr=sum(1 for b in all_bindings if b.get("role") == "Кр"),
        kr_distributed=sum(1 for block in elements for d in block["distribution"] if d.get("split")),
        elements=len(elements),
        sections=sections,
        skipped=len(skipped),
        zn=zn_counts(items),
        units_guessed=guessed,
        units_from_library=from_library,
        review_note=review_note,
        learned=learned,
        onec=dict(onec_stats, smeta_works=len(smeta)) if (smeta or onec_stats["bound"]) else None,
        auto_works=auto_added,
        manual_works=manual_added,
        local=dict(text=bool(str(local.get("text") or "").strip()), files=local_used,
                   skipped=["%s — %s" % pair for pair in local_skipped], by=local.get("by") or "", at=local.get("at") or 0,
                   changed=local_changed, agent=(local.get("agent") or {}).get("stats"),
                   agent_at=(local.get("agent") or {}).get("at") or 0, fresh=bool(local_agent),
                   error=local_error) if local else None,
        reduced=reduced_rows,
        feedback=feedback_stats,
        review_counts={"подтвердить": sum(1 for r in review.values() if r["verdict"] == "подтвердить"),
                       "заменить": sum(1 for r in review.values() if r["verdict"] == "заменить"),
                       "вопрос": sum(1 for r in review.values() if r["verdict"] == "вопрос")},
    )
    audit_result = None
    if audit is not None:
        audit_result = rv_audit.compare(elements, audit.get("works"), review=review, kb_works=bind.KB["works"])
        audit_result["doc"] = audit.get("doc") or ""
        summary["audit"] = audit_result["summary"]
        status.log("сверка с 1С: совпадает %s%% строк, расхождений %d, работ с другим объёмом %d"
                   % (audit_result["summary"]["match_pct"], audit_result["summary"]["disputed"],
                      audit_result["summary"]["works_volume"]))
    result = dict(section=", ".join(sections) if sections else section, sections=sections, object_type=object_type,
                  source_name=work.get("source_name", ""), format=work.get("format", "table"),
                  elements=elements, review=review, questions=questions, notes=notes, summary=summary,
                  usage=(client.usage if client is not None else None),
                  work_notes=work_notes(smeta, previous, getattr(args, "feedback_file", "")),
                  splits={str(key): value for key, value in splits.items()},
                  added_works=added_works,
                  local=bool(local), code_root="12" if rvr else "6")
    summary["splits"] = split_stats
    summary["code_root"] = "12" if rvr else "6"
    if rvr:
        no_pair = sum(1 for b in all_bindings if "F-RVR" in (b.get("fcodes") or []) and not b.get("code"))
        unsure = sum(1 for b in all_bindings if "F-RVR" in (b.get("fcodes") or []) and b.get("code"))
        summary["rvr"] = dict(no_pair=no_pair, unsure=unsure)
        notes.append("Заказ-наряд РВР: РВ собрана из работ кода 12 (работы, не предусмотренные основным проектом). Агент "
                     "подбирает работу по правилам кода 6 и ставит работу кода 12 с тем же названием%s%s. Работы без "
                     "материалов (испытания, сдача систем) агент в РВР не добавляет — добавьте нужные «+ Добавить работу»."
                     % (("; у %d строк такой работы в коде 12 нет — выберите работу (F-RVR)" % no_pair) if no_pair else "",
                        ("; у %d строк работа взята из другой подсистемы — проверьте (F-RVR)" % unsure) if unsure else ""))
    if local:
        s = (local.get("agent") or {}).get("stats") or {}
        if local_error:
            notes.append("Указания для этой РВ: %s. Сохраните указания ещё раз, чтобы повторить." % local_error)
        elif s:
            notes.append("Указания для этой РВ: по ним изменено строк — %d (F-LOCAL, «на проверку», причина в пометке)%s%s. "
                         "В общую память агента это не попадёт — только ваши ручные исправления." % (
                             local_changed,
                             ("; разнесено в 1С на другую работу — предложено %d" % s.get("onec_proposed", 0)) if s.get("onec_proposed") else "",
                             ("; вопросов модели %d" % s.get("questions", 0)) if s.get("questions") else ""))
        if local_skipped:
            notes.append("Файлы указаний не прочитаны: %s." % "; ".join("%s — %s" % pair for pair in local_skipped))
    units = unit_guids_of(packet_input(args))
    export = export_1c(result, work, bind.KB["works"], smeta, head_input(args), job_input(args), units)
    rebuilt = None
    if getattr(args, "rebuild", False):
        # Пересборка согласованной РВ: изменилось то, что уйдёт в 1С (уменьшения по ЛРВ, коэффициенты, объёмы,
        # работы строк) — согласование снимается, РВ снова «на проверку»; ничего не изменилось — остаётся.
        try:
            before = onec_signature(_read(onec_path(args))) if os.path.exists(onec_path(args)) else None
        except (OSError, ValueError, EOFError):
            before = None
        changes = signature_changes(before, onec_signature(export)) if before is not None else None
        reset = bool(feedback_stats) and (changes is None or bool(changes["works"] or changes["rows"]))
        rebuilt = dict(user=args.user or "", changes=changes, approval_reset=reset, had_approval=bool(feedback_stats))
        if reset:
            status.log("пересборка изменила РВ для 1С (работ %s, строк %s) — согласование снято, нужна повторная проверка"
                       % ((changes or {}).get("works", "?"), (changes or {}).get("rows", "?")))
            feedback_stats = None
            summary["feedback"] = None
            export = export_1c(result, work, bind.KB["works"], smeta, head_input(args), job_input(args), units)
        elif feedback_stats:
            status.log("пересборка не изменила РВ для 1С — согласование остаётся")
    form_rows = rv_form.build_rows(result, bind.KB["works"])
    web_rows = rv_form.build_rows(result, bind.KB["works"], flat=True)      # страница проверки: одно дерево по работам
    rv_output.build_workbook(args.out_xlsx, result, form_rows)
    slim = dict(result)
    slim["elements"] = [dict(element=b["element"], section=b["section"], works=b["rv"]["works"], unbound=b["rv"]["unbound"],
                             bindings=b["bindings"], distribution=b["distribution"]) for b in elements]
    if audit_result is not None:
        slim["audit"] = audit_result
    _write(args.out_json, slim)
    _write(onec_path(args), export)
    _write(form_path(args), dict(rows=[{k: v for k, v in row.items() if not k.startswith("_")} for row in web_rows],
                                 catalog={sec: rows for sec, rows in _catalog(bind.KB["works"], "12" if rvr else "6").items() if sec in sections},
                                 roles=list(rv_learning.ROLES), legend=dict(roles=rv_form.ROLE_TEXT, coef=rv_form.COEF_TEXT),
                                 summary=summary, notes=notes, questions=questions, source_name=result["source_name"]))
    status.update("done", "готово", summary=summary, notes=notes, questions=questions,
                  elapsed=int(time.time()) - started, feedback=feedback_stats, rollback=rollback_stats, rebuilt=rebuilt)
    status.log("готово за %d с" % (int(time.time()) - started))
    return 0


# ── Очередь ЛРВ из 1С ──
# 1С присылает ЛРВ по мере появления (web/1c_rv.php), иногда пачкой. Общий хостинг не выдержит
# нескольких агентов сразу (каждый ~280 МБ), поэтому присланное встаёт в очередь (статус queued),
# а разбирает её один процесс --phase queue: по одной ЛРВ, каждую — отдельным дочерним процессом
# (обычная фаза mark, без вопросов переходит в bind). Второй такой процесс, запущенный следующим
# приёмом, видит занятую блокировку и сразу выходит.

QUEUE_LOCK = "rv_queue.lock"


def _load_json(path):
    try:
        with open(path, encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else None
    except (OSError, ValueError):
        return None


def queued_jobs(out_dir):
    """Задачи в статусе queued, старые первыми, сверка РВ из 1С — после рабочих ЛРВ: [(token, job)]."""
    import re
    found = []
    for name in os.listdir(out_dir):
        if not name.endswith("_job.json"):
            continue
        token = name[:-len("_job.json")]
        if not re.fullmatch(r"[a-f0-9]{16}", token):
            continue
        status = _load_json(os.path.join(out_dir, token + "_status.json")) or {}
        if status.get("state") != "queued":
            continue
        job = _load_json(os.path.join(out_dir, name)) or {}
        # Пересборка готовой РВ, поставленная в очередь (web/rv_rebuild.php, пачкой): отметка — в статусе.
        if isinstance(status.get("rebuild"), dict):
            job["_rebuild"] = status["rebuild"]
        # Сверка РВ из 1С (пачкой, сотни) и пересборки — после рабочих ЛРВ: они не ждут, пока проверится архив.
        found.append((2 if job.get("_rebuild") else (1 if job.get("mode") == "audit" else 0), int(job.get("created") or 0), token, job))
    found.sort(key=lambda entry: entry[:3])
    return [(token, job) for _, _, token, job in found]


def _queue_command(args, out_dir, token, job):
    base = os.path.join(out_dir, token)
    if job.get("_rebuild"):
        # пересборка готовой РВ: привязка заново по сохранённой разметке, согласование остаётся (run_bind, --rebuild)
        out_json = base + "_rv.json.gz" if os.path.exists(base + "_rv.json.gz") or not os.path.exists(base + "_rv.json") else base + "_rv.json"
        cmd = [sys.executable, "-u", os.path.abspath(__file__), "--phase", "bind",
               "--status-file", base + "_status.json", "--work-file", base + "_work.json",
               "--out-xlsx", base + "_rv.xlsx", "--out-json", out_json, "--rebuild", "--no-review",
               "--user", str(job["_rebuild"].get("by") or ""), "--source-name", job.get("source_name") or ""]
        if args.credentials:
            cmd += ["--credentials", args.credentials]
        if args.learning_file:
            cmd += ["--learning-file", args.learning_file]
        return cmd
    cmd = [sys.executable, "-u", os.path.abspath(__file__), "--phase", "mark",
           "--status-file", base + "_status.json", "--work-file", base + "_work.json",
           "--out-xlsx", base + "_rv.xlsx", "--out-json", base + "_rv.json.gz",
           "--section", job.get("section") if job.get("section") in rv_input.SECTIONS else "авто",
           "--object-type", job.get("object_type") or "жилой", "--source-name", job.get("source_name") or ""]
    if args.credentials:
        cmd += ["--credentials", args.credentials]
    if args.learning_file:
        cmd += ["--learning-file", args.learning_file]
    if getattr(args, "notes_file", ""):
        cmd += ["--notes-file", args.notes_file]
    for key, flag in (("lrv_id", "--lrv-id"), ("version", "--lrv-version"), ("object", "--object-name")):
        if job.get(key):
            cmd += [flag, str(job[key])]
    if job.get("default_system"):
        cmd += ["--default-system", job["default_system"]]
    return cmd + ["--", job.get("input") or ""]


def run_queue(args, runner=None, sleep=time.sleep):
    """Разобрать очередь ЛРВ из 1С. runner(cmd, env) → код возврата (для тестов — подмена)."""
    import subprocess
    try:
        import fcntl
    except ImportError:
        fcntl = None
    out_dir = args.queue_dir
    runner = runner or (lambda cmd, env: subprocess.call(cmd, env=env))
    attempts = max(1, int(os.environ.get("RV_ATTEMPTS") or 3))
    retry = int(os.environ.get("RV_RETRY_SEC") or 60)
    processed = 0
    while True:
        lock = open(os.path.join(out_dir, QUEUE_LOCK), "a+")
        if fcntl is not None:
            try:
                fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except OSError:
                lock.close()
                print("[%s] очередь ЛРВ уже разбирает другой процесс" % time.strftime("%H:%M:%S"), flush=True)
                return 0
        try:
            while True:
                jobs = queued_jobs(out_dir)
                if not jobs:
                    break
                token, job = jobs[0]
                status_file = os.path.join(out_dir, token + "_status.json")
                print("[%s] очередь ЛРВ: %s (%s), в очереди ещё %d" % (time.strftime("%H:%M:%S"), token,
                                                                       job.get("source_name") or "", len(jobs) - 1), flush=True)
                if job.get("_rebuild"):
                    if not os.path.exists(os.path.join(out_dir, token + "_work.json")):
                        rv_startup._update_status(status_file, state="error", stage="нет разметки",
                                                  error="Разметка этой РВ не найдена на сервере — пересобрать нельзя, пришлите ЛРВ ещё раз.")
                        continue
                elif not job.get("input") or not os.path.exists(job["input"]):
                    rv_startup._update_status(status_file, state="error", stage="нет файла",
                                              error="Файл ЛРВ, присланный 1С, не найден на сервере — пришлите ЛРВ ещё раз.")
                    continue
                rv_startup._update_status(status_file, state="running", stage="запуск агента…", launched=False)
                cmd = _queue_command(args, out_dir, token, job)
                code = None
                for attempt in range(1, attempts + 1):
                    env = dict(os.environ, RV_ATTEMPT=str(attempt), RV_ATTEMPTS=str(attempts))
                    code = runner(cmd, env)
                    if code != 75:
                        break
                    if attempt < attempts:
                        sleep(retry)
                state = (_load_json(status_file) or {}).get("state")
                if state in ("running", "queued", None, ""):
                    rv_startup._update_status(status_file, state="error", stage="сбой",
                                              error="Агент РВ завершился без результата (код %s). Сообщите администратору." % code)
                processed += 1
        finally:
            if fcntl is not None:
                fcntl.flock(lock, fcntl.LOCK_UN)
            lock.close()
        # Пока блокировка была снята, могла прийти новая ЛРВ, а её процесс — уже выйти: проверить ещё раз.
        if not queued_jobs(out_dir):
            print("[%s] очередь ЛРВ разобрана: %d" % (time.strftime("%H:%M:%S"), processed), flush=True)
            return 0


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--phase", choices=("mark", "bind", "queue"), default="mark")
    parser.add_argument("--status-file", default="")
    parser.add_argument("--work-file", default="", help="прочитанная ЛРВ и разметка между фазами")
    parser.add_argument("--queue-dir", default="", help="папка задач РВ — для --phase queue")
    parser.add_argument("--out-xlsx", default="")
    parser.add_argument("--out-json", default="")
    parser.add_argument("--section", choices=rv_input.SECTIONS + ("авто",), default="авто",
                        help="раздел ЛРВ; «авто» — по группам «Система» отчёта 1С или по заголовкам")
    parser.add_argument("--object-type", default="жилой")
    parser.add_argument("--default-system", default="")
    parser.add_argument("--credentials", default=None)
    parser.add_argument("--source-name", default="")
    parser.add_argument("--keep-input", action="store_true", help="не удалять файл ЛРВ после чтения (для отладки)")
    parser.add_argument("--learning-file", default="", help="память решений инженеров (web/data/rv_learning.json)")
    parser.add_argument("--feedback-file", default="", help="проверка инженера по прежнему результату — повтор привязки")
    parser.add_argument("--forget-learning", action="store_true",
                        help="откат согласования: убрать решения инженера по этой РВ из памяти агента (rv_rollback.php)")
    parser.add_argument("--no-review", action="store_true", help="не повторять проверку моделью (перенести прежнюю)")
    parser.add_argument("--rebuild", action="store_true",
                        help="пересборка по кнопке «Пересобрать РВ» (web/rv_rebuild.php): привязка и коэффициенты заново по "
                             "текущим правилам и памяти решений, согласование (feedback в статусе) сохраняется")
    parser.add_argument("--user", default="", help="кто проверял — для памяти решений")
    parser.add_argument("--notes-file", default="", help="замечания инженеров к агенту (web/data/rv_notes.jsonl)")
    parser.add_argument("--lrv-id", default="", help="идентификатор ЛРВ в 1С — вернётся в РВ для 1С")
    parser.add_argument("--lrv-version", default="", help="версия ЛРВ в 1С")
    parser.add_argument("--object-name", default="", help="название объекта из 1С")
    parser.add_argument("input", nargs="?")
    args = parser.parse_args()
    if args.phase != "queue":
        args.learning_file = learning_path(args)      # у РВ кода 12 (РВР) память решений своя
    rv_learning.OWN_TOKEN = job_token(args)      # решения сметчика в этой же РВ (см. rv_learning.apply: крепёж целиком в выбранную работу)
    if args.phase == "queue":
        if not args.queue_dir or not os.path.isdir(args.queue_dir):
            parser.error("фазе queue нужна --queue-dir")
        return run_queue(args)
    if not args.status_file or not args.work_file:
        parser.error("нужны --status-file и --work-file")
    if args.phase == "mark" and not args.input:
        parser.error("фазе mark нужен файл ЛРВ")
    if args.phase == "bind" and (not args.out_xlsx or not args.out_json):
        parser.error("фазе bind нужны --out-xlsx и --out-json")
    try:
        return run_mark(args) if args.phase == "mark" else run_bind(args)
    except Exception as exc:  # noqa: BLE001 — любая ошибка должна попасть в статус, а не в тишину
        traceback.print_exc()
        _write(args.status_file, dict(state="error", stage="сбой", updated=int(time.time()),
                                      error="Сбой агента РВ: %s" % exc))
        return 1


if __name__ == "__main__":
    sys.exit(main())
