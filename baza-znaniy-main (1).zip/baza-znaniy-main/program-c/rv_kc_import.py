#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Обновление справочника КЦ агента РВ из выгрузки «справочник_КЦ_ВЕСЬ.xlsx».

Выгрузка — три листа: «Работы» (код, наименование, пакет, путь разделов,
цена, guid), «Материалы» (код работы, работа, группа, материал, ед., коэф.
расхода, «Основной», «Объём редакт.», цена, guid материала), «Пакеты».
Агенту нужна только часть 6.2.3 (инженерные системы: ВК, ОВ1, ОВ2, ЭОМ, СС,
ИТП) в формате kc_index_compact.json комплекта — его читает rv/bind.py:

    <раздел>_works: [код, наименование, guid работы, '', '', 0, 0, [], [], ед. работы]
    <раздел>_mats:  [код, guid работы, '', группа, '', материал, '', ед., коэф., основной, редакт.]

Цены в индекс не переносятся. Единицы работ в выгрузке нет — берётся из
текущего индекса (коды и guid работ совпадают), для новых работ — самая
частая единица основных материалов. Материалы у прежних работ остаются из
текущего индекса (иначе память агента почти удваивается и хостинг убивает
процесс); --full-materials — взять все из выгрузки.

Рядом с индексом пишется isr_names.json — названия узлов ИСР над работами
(«6.2.3.1» → «Водоснабжение и канализация», «6.2.3.1.1» → «Система
хозяйственно-бытовой канализации» …) из колонки «Путь разделов»: по ним лист
«РВ» и страница проверки строят иерархию, как в ТКП из 1С.

Запуск (не на хостинге — выгрузка большая, чтение ~1,5 мин):
    python3 program-c/rv_kc_import.py справочник_КЦ_ВЕСЬ.xlsx [--out program-c/rv/data/kc_index_compact.json]
    python3 program-c/rv_kc_import.py справочник_КЦ_ВЕСЬ.xlsx --names-only   # только isr_names.json
Печатает сверку со старым индексом: какие работы ушли, какие появились,
сколько позиций материалов добавилось.

Код 12 (РВР — работы, не предусмотренные основным проектом): --rvr пишет рядом
kc_rvr.json — работы 12.1.11–12.1.15 (ВК, отопление, вентиляция, ЭОМ, СС) и
пары «код 6.2.3 → код 12» (тот же раздел, то же название работы; у пар одни
и те же группы материалов — проверено по выгрузке). Агент подбирает работу по
правилам кода 6 и ставит её пару из кода 12 (rv/bind.py, to_rvr). Материалы
в файл идут только у работ кода 12 без пары (в основном «Демонтаж…»).
    python3 program-c/rv_kc_import.py справочник_КЦ_ВЕСЬ.xlsx --rvr
"""
import argparse
import collections
import json
import os
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
DEFAULT_OUT = os.path.join(HERE, "rv", "data", "kc_index_compact.json")

# Префикс кода → ключ раздела в индексе (как в комплекте).
SECTIONS = collections.OrderedDict([
    ("6.2.3.1.", "vk"), ("6.2.3.2.", "ot"), ("6.2.3.3.", "vent"),
    ("6.2.3.4.", "eom"), ("6.2.3.5.", "ss"), ("6.2.3.6.", "itp"),
])
NAMES = {"vk": "ВК", "ot": "ОВ1", "vent": "ОВ2", "eom": "ЭОМ", "ss": "СС", "itp": "ИТП"}
# Код 12 (РВР): раздел кода 12 → раздел агента (и раздел 6.2.3, с которым сопоставляются работы).
RVR_SECTIONS = collections.OrderedDict([
    ("12.1.11.", "ВК"), ("12.1.12.", "ОВ1"), ("12.1.13.", "ОВ2"), ("12.1.14.", "ЭОМ"), ("12.1.15.", "СС"),
])
RVR_OUT = "kc_rvr.json"


def _s(value):
    return "" if value is None else str(value).strip()


def _f(value, default=1.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def section_of(code):
    for prefix, key in SECTIONS.items():
        if code.startswith(prefix):
            return key
    return None


def rvr_section_of(code):
    for prefix, name in RVR_SECTIONS.items():
        if code.startswith(prefix):
            return name
    return None


def read_catalog(path, log=print, accept=None):
    """Работы и материалы части 6.2.3 из выгрузки КЦ (accept(код) — какие работы брать, по умолчанию 6.2.3)."""
    accept = accept or section_of
    import openpyxl
    book = openpyxl.load_workbook(path, read_only=True, data_only=True)
    names = {sheet.title.strip().lower(): sheet for sheet in book.worksheets}
    if "работы" not in names or "материалы" not in names:
        raise ValueError("В файле нет листов «Работы» и «Материалы» — это не выгрузка справочника КЦ.")

    def header_map(row, wanted):
        cells = [_s(c).lower() for c in row]
        found = {}
        for key, words in wanted.items():
            for index, cell in enumerate(cells):
                if any(cell.startswith(w) for w in words):
                    found[key] = index
                    break
        missing = [k for k in wanted if k not in found]
        if missing:
            raise ValueError("Нет колонок: %s" % ", ".join(missing))
        return found

    works = collections.OrderedDict()
    rows = names["работы"].iter_rows(values_only=True)
    head = next(rows)
    cols = header_map(head, {"code": ("код",), "name": ("наимен",), "guid": ("guid",)})
    path_col = next((i for i, c in enumerate(head) if _s(c).lower().startswith("путь")), None)
    total_works = 0
    for row in rows:
        code = _s(row[cols["code"]])
        if not code:
            continue
        total_works += 1
        if accept(code):
            works[code] = dict(name=_s(row[cols["name"]]), guid=_s(row[cols["guid"]]),
                               path=_s(row[path_col]) if path_col is not None else "")
    log("работ в выгрузке: %d, из них отобрано: %d" % (total_works, len(works)))

    mats = collections.defaultdict(list)
    rows = names["материалы"].iter_rows(values_only=True)
    cols = header_map(next(rows), {"code": ("код работы",), "group": ("группа",), "material": ("материал",),
                                   "unit": ("ед",), "coef": ("коэф",), "main": ("основн",), "edit": ("объём редакт", "объем редакт")})
    total_mats = 0
    for row in rows:
        code = _s(row[cols["code"]])
        if not code:
            continue
        total_mats += 1
        if code not in works:
            continue
        mats[code].append(dict(group=_s(row[cols["group"]]), material=_s(row[cols["material"]]),
                               unit=_s(row[cols["unit"]]), coef=_f(row[cols["coef"]]),
                               main=_s(row[cols["main"]]).lower() == "да", edit=_s(row[cols["edit"]]).lower() == "да"))
    book.close()
    log("позиций материалов в выгрузке: %d, у отобранных работ: %d" % (total_mats, sum(len(v) for v in mats.values())))
    return works, mats


def build_index(works, mats, old_index=None, full_materials=False):
    """Индекс в формате комплекта. old_index — текущий: из него единицы работ и (по умолчанию)
    материалы — у работ, которые в нём уже есть, материалы остаются прежние, из выгрузки берутся
    только у новых работ. Полный список материалов выгрузки (full_materials) почти вдвое
    увеличивает память агента (~510 МБ против ~270 МБ) — общий хостинг такой процесс убивает,
    а на привязку он почти не влияет (проверено на ЛРВ Гольяново 2.2)."""
    old_units = {}
    old_mats = {}
    if old_index:
        for key in SECTIONS.values():
            for w in old_index.get(key + "_works", []):
                if len(w) > 9 and w[9]:
                    old_units[w[0]] = w[9]
            for m in old_index.get(key + "_mats", []):
                old_mats.setdefault(m[0], []).append(m)
    index = collections.OrderedDict()
    for key in SECTIONS.values():
        index[key + "_works"] = []
        index[key + "_mats"] = []
    guessed = []
    for code, work in works.items():
        key = section_of(code)
        unit = old_units.get(code)
        if not unit:
            main_units = collections.Counter(m["unit"] for m in mats.get(code, []) if m["main"] and m["unit"])
            unit = main_units.most_common(1)[0][0] if main_units else ""
            guessed.append(code)
        index[key + "_works"].append([code, work["name"], work["guid"], "", "", 0, 0, [], [], unit])
        if not full_materials and code in old_mats:
            for m in old_mats[code]:
                m = list(m); m[1] = work["guid"]
                index[key + "_mats"].append(m)
            continue
        seen = set()
        for m in mats.get(code, []):
            row_key = (m["group"], m["material"], m["unit"], m["coef"], m["main"])
            if row_key in seen:
                continue
            seen.add(row_key)
            index[key + "_mats"].append([code, work["guid"], "", m["group"], "", m["material"], "", m["unit"],
                                         m["coef"], m["main"], m["edit"]])
    return index, guessed


def build_names(works):
    """Названия узлов ИСР над работами по колонке «Путь разделов»: «Затраты на строительство / СМР корпуса
    без отделки / … / Прокладка трубопроводов из полипропиленовых труб» задаёт имена префиксов кода
    (6, 6.2, …, код без последнего сегмента — семья работы). Имена с « / » внутри (семья «Монтаж шкафа /
    щита») путь ломает — семья берётся из имени работы, а остаток пути делится по уровням; если уровней в
    пути больше, чем в коде (у СС есть узлы без своего сегмента), верхние четыре берутся с начала,
    остальные — с конца. Точные пути идут первыми и не перезаписываются."""
    exact, loose = [], []
    for code, work in works.items():
        parts = code.split(".")
        family = (work.get("name") or "").split(" / ")[0].strip()
        path = (work.get("path") or "").strip()
        if not family or not path:
            continue
        if path.endswith(family):
            path = path[:-len(family)].rstrip(" /")
        elif " / " + family + " / " in path:
            path = path[:path.index(" / " + family + " / ")]
        else:
            continue
        levels = [x.strip() for x in path.split(" / ") if x.strip()] + [family]
        (exact if len(levels) == len(parts) - 1 else loose).append((parts, levels))
    names = {}
    for parts, levels in exact:
        for depth, name in enumerate(levels, start=1):
            names.setdefault(".".join(parts[:depth]), name)
    for parts, levels in loose:
        if len(levels) < 5 or len(parts) < 6:
            continue
        for depth in range(1, 5):
            names.setdefault(".".join(parts[:depth]), levels[depth - 1])
        tail = levels[4:]
        for offset in range(1, min(len(tail), len(parts) - 5) + 1):
            names.setdefault(".".join(parts[:len(parts) - offset]), tail[-offset])
    return collections.OrderedDict(sorted(names.items(), key=lambda kv: [int(x) if x.isdigit() else x for x in kv[0].split(".")]))


def compare(old_index, new_index, log=print):
    """Сверка по разделам: работы ушли / появились, имена и guid, материалы."""
    report = collections.OrderedDict()
    for key in SECTIONS.values():
        old_w = {w[0]: w for w in (old_index or {}).get(key + "_works", [])}
        new_w = {w[0]: w for w in new_index[key + "_works"]}
        both = old_w.keys() & new_w.keys()
        old_m = collections.Counter(m[0] for m in (old_index or {}).get(key + "_mats", []))
        new_m = collections.Counter(m[0] for m in new_index[key + "_mats"])
        entry = dict(
            works_old=len(old_w), works_new=len(new_w),
            removed=sorted(old_w.keys() - new_w.keys()), added=sorted(new_w.keys() - old_w.keys()),
            renamed=sorted(c for c in both if old_w[c][1] != new_w[c][1]),
            guid_changed=sorted(c for c in both if old_w[c][2] != new_w[c][2]),
            mats_old=sum(old_m.values()), mats_new=sum(new_m.values()),
        )
        report[NAMES[key]] = entry
        log("%-4s работ %5d → %5d (ушло %d, новых %d, переименовано %d, guid сменился %d); материалов %6d → %6d"
            % (NAMES[key], entry["works_old"], entry["works_new"], len(entry["removed"]), len(entry["added"]),
               len(entry["renamed"]), len(entry["guid_changed"]), entry["mats_old"], entry["mats_new"]))
        for code in entry["removed"][:20]:
            log("     ушла: %s %s" % (code, old_w[code][1][:80]))
    return report


def _norm_name(text):
    return " ".join(_s(text).lower().replace("ё", "е").split())


def _path_stems(path):
    """Слова пути разделов по трём первым буквам: «в нежилой части» ↔ «Нежилая часть»; квартиры — жилая часть."""
    import re
    text = _norm_name(path).replace("в квартирах", "жилая часть")
    return collections.Counter(w[:3] for w in re.findall(r"[a-zа-я0-9]+", text) if len(w) > 1)


def _subsystem(path, family):
    """Подсистема работы — узел пути сразу под разделом («Слаботочные системы / Сети связи / …» → «сети связи»)."""
    parts = [_norm_name(x) for x in _s(path).split(" / ")]
    for root in ("слаботочные системы", "электроснабжение", "водоснабжение и канализация", "отопление", "вентиляция"):
        if root in parts and parts.index(root) + 1 < len(parts):
            return parts[parts.index(root) + 1].replace("в квартирах", "жилая часть")
    return ""


def build_rvr(works, mats, units):
    """Код 12 (РВР) для агента: работы разделов RVR_SECTIONS и пары «код 6.2.3 → код 12».
    Пара — работа того же раздела с тем же названием; кандидатов несколько (ЭОМ: жилая / нежилая часть; СС:
    подсистемы) — та, у которой совпадает подсистема, иначе самая похожая по пути разделов (такая пара — «не
    наверняка»: агент поставит строку на проверку). units — единицы работ 6.2.3 из индекса агента.
    Возвращает dict(works={код 12: [название, guid, единица, пара 6 или ""]}, pairs={код 6: [код 12, 1 — точно]},
    mats=[[код 12, группа, материал, ед., коэф., основной]] — только у работ без пары)."""
    by_name = collections.defaultdict(list)
    for code, work in works.items():
        section = rvr_section_of(code)
        if section:
            by_name[(section, _norm_name(work["name"]))].append(code)
    section6 = {"vk": "ВК", "ot": "ОВ1", "vent": "ОВ2", "eom": "ЭОМ", "ss": "СС"}
    pairs = collections.OrderedDict()
    back = {}           # код 12 → код 6 с теми же материалами (любая пара)
    unsure = 0
    for code, work in works.items():
        section = section6.get(section_of(code) or "")
        if not section:
            continue
        candidates = by_name.get((section, _norm_name(work["name"])))
        if not candidates:
            continue
        sure = 1
        best = candidates[0]
        if len(candidates) > 1:
            sub = _subsystem(work["path"], work["name"])
            mine = _path_stems(work["path"])
            scored = []
            for candidate in candidates:
                other = _path_stems(works[candidate]["path"])
                jaccard = sum((mine & other).values()) / float(sum((mine | other).values()) or 1)
                same_sub = 1 if sub and sub == _subsystem(works[candidate]["path"], works[candidate]["name"]) else 0
                scored.append((same_sub, round(jaccard, 4), candidate))
            scored.sort(key=lambda s: (-s[0], -s[1], s[2]))
            best = scored[0][2]
            if not scored[0][0] and scored[0][1] == scored[1][1]:
                sure = 0
                if section == "ЭОМ":        # частей здания в коде 12 две: всё, что не квартиры, — нежилая часть
                    best = next((c for _, _, c in scored if "нежил" in _norm_name(works[c]["path"])), best)
                unsure += 1
        pairs[code] = [best, sure]
        back.setdefault(best, code)
    out_works = collections.OrderedDict()
    out_mats = []
    for code, work in works.items():
        if not rvr_section_of(code):
            continue
        pair = back.get(code, "")
        unit = units.get(pair, "")
        if not unit:
            main_units = collections.Counter(m["unit"] for m in mats.get(code, []) if m["main"] and m["unit"])
            unit = main_units.most_common(1)[0][0] if main_units else ""
        out_works[code] = [work["name"], work["guid"], unit, pair]
        if not pair:
            seen = set()
            for m in mats.get(code, []):
                key = (m["group"], m["material"], m["unit"], m["coef"], m["main"])
                if key not in seen:
                    seen.add(key)
                    out_mats.append([code, m["group"], m["material"], m["unit"], m["coef"], m["main"]])
    return dict(works=out_works, pairs=pairs, mats=out_mats), unsure


def write_names(path, works, keep_existing=False):
    names = build_names(works)
    if not names:
        print("названий узлов ИСР нет (в выгрузке нет колонки «Путь разделов») — isr_names.json не тронут")
        return
    if keep_existing and os.path.exists(path):
        # Дополнить (код 12): прежние имена узлов остаются, новые добавляются.
        with open(path, encoding="utf-8") as handle:
            merged = json.load(handle)
        merged.update(names)
        names = collections.OrderedDict(sorted(merged.items(), key=lambda kv: [int(x) if x.isdigit() else x for x in kv[0].split(".")]))
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as handle:
        json.dump(names, handle, ensure_ascii=False, separators=(",", ":"))
    os.replace(tmp, path)
    print("записан %s: %d узлов ИСР" % (path, len(names)))


def main():
    parser = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("catalog", help="выгрузка справочника КЦ (xlsx)")
    parser.add_argument("--out", default=DEFAULT_OUT, help="куда записать индекс (по умолчанию — данные агента)")
    parser.add_argument("--report", default="", help="JSON со сверкой (необязательно)")
    parser.add_argument("--full-materials", action="store_true",
                        help="взять все материалы из выгрузки (память агента ~510 МБ — не для общего хостинга)")
    parser.add_argument("--names-only", action="store_true", help="записать только isr_names.json, индекс не трогать")
    parser.add_argument("--rvr", action="store_true",
                        help="код 12 (РВР): записать kc_rvr.json и имена его узлов в isr_names.json, индекс не трогать")
    args = parser.parse_args()
    names_out = os.path.join(os.path.dirname(os.path.abspath(args.out)), "isr_names.json")
    if args.rvr:
        works, mats = read_catalog(args.catalog, accept=lambda code: section_of(code) or rvr_section_of(code))
        units = {}
        if os.path.exists(args.out):
            with open(args.out, encoding="utf-8") as handle:
                for key, rows in json.load(handle).items():
                    if key.endswith("_works"):
                        units.update({w[0]: w[9] for w in rows if len(w) > 9 and w[9]})
        data, unsure = build_rvr(works, mats, units)
        data = collections.OrderedDict([("source", "справочник КЦ: код 12 (РВР), разделы " + ", ".join(
            "%s → %s" % (k.rstrip("."), v) for k, v in RVR_SECTIONS.items()))] + list(data.items()))
        rvr_out = os.path.join(os.path.dirname(os.path.abspath(args.out)), RVR_OUT)
        with open(rvr_out + ".tmp", "w", encoding="utf-8") as handle:
            json.dump(data, handle, ensure_ascii=False, separators=(",", ":"))
        os.replace(rvr_out + ".tmp", rvr_out)
        by_section = collections.Counter(rvr_section_of(code) for code in data["works"])
        paired = collections.Counter(rvr_section_of(code) for code, w in data["works"].items() if w[3])
        print("записан %s (%.1f МБ): работ кода 12 — %s; с парой в 6.2.3 — %s; пар 6 → 12: %d (не наверняка %d); "
              "материалов у работ без пары: %d" % (
                  rvr_out, os.path.getsize(rvr_out) / 1024 / 1024,
                  ", ".join("%s %d" % kv for kv in by_section.items()), ", ".join("%s %d" % kv for kv in paired.items()),
                  len(data["pairs"]), unsure, len(data["mats"])))
        write_names(names_out, {code: w for code, w in works.items() if rvr_section_of(code)}, keep_existing=True)
        return 0
    if args.names_only:
        works, _ = read_catalog(args.catalog)
        write_names(names_out, works)
        return 0
    old_index = None
    if os.path.exists(args.out):
        with open(args.out, encoding="utf-8") as handle:
            old_index = json.load(handle)
    works, mats = read_catalog(args.catalog)
    index, guessed = build_index(works, mats, old_index, full_materials=args.full_materials)
    if guessed:
        print("единица работы не из старого индекса (по основным материалам): %d работ" % len(guessed))
    report = compare(old_index, index)
    write_names(names_out, works)
    tmp = args.out + ".tmp"
    with open(tmp, "w", encoding="utf-8") as handle:
        json.dump(index, handle, ensure_ascii=False, separators=(",", ":"))
    os.replace(tmp, args.out)
    print("записан %s (%.1f МБ)" % (args.out, os.path.getsize(args.out) / 1024 / 1024))
    if args.report:
        with open(args.report, "w", encoding="utf-8") as handle:
            json.dump(report, handle, ensure_ascii=False, indent=1)
    return 0


if __name__ == "__main__":
    sys.exit(main())
