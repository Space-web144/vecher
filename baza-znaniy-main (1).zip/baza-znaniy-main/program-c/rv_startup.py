#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Запуск агента РВ на общем хостинге: только стандартная библиотека.

Модуль импортируется до openpyxl и данных агента, поэтому работает и тогда,
когда памяти на аккаунте не хватает даже на загрузку библиотек
(ImportError «failed to map segment from shared object»). Он:

* снимает «зависшие» запуски агента РВ этого же пользователя (старше двух часов) —
  они держат память, и новый процесс не может стартовать;
* сразу отмечает в статусе, что процесс запустился (страница не ждёт 2 минуты);
* при нехватке памяти на старте пишет в статус понятную причину и список
  процессов аккаунта с памятью, а код выхода 75 (EX_TEMPFAIL) говорит
  оболочке запуска (rv_launch в web/rv_lib.php) повторить через минуту.
"""
import json
import os
import signal
import sys
import time

TEMPFAIL = 75                 # код выхода «повторить позже»
RUN_MAX_AGE = 7200            # запуск агента РВ дольше двух часов — завис (проверка 400 строк моделью на высоком усилии — десятки минут)
RETRY_PAUSE_SEC = 60          # пауза оболочки между попытками (rv_launch)
MEMORY_MARKERS = ("failed to map segment", "cannot allocate memory", "out of memory",
                  # лимит процессов и потоков аккаунта (RLIMIT_NPROC): освобождается, когда завершатся другие процессы
                  "can't start new thread", "resource temporarily unavailable", "rlimit_nproc", "pthread_create")

# Хостинг ограничивает аккаунт 36 процессами и потоками (RLIMIT_NPROC), а numpy/OpenBLAS (его подтягивает
# openpyxl, если numpy установлен) запускает по потоку на каждое ядро сервера — 40: процесс обрывается
# ещё на импорте, а резерв памяти этих потоков даёт «failed to map segment». Агенту РВ numpy не нужен.
THREAD_ENV = ("OPENBLAS_NUM_THREADS", "OMP_NUM_THREADS", "MKL_NUM_THREADS", "NUMEXPR_NUM_THREADS", "VECLIB_MAXIMUM_THREADS")


def limit_threads(block_numpy=True):
    """Один поток вычислений и, по умолчанию, без numpy (openpyxl работает без него так же).
    Вызывать до импорта openpyxl."""
    for name in THREAD_ENV:
        os.environ.setdefault(name, "1")
    if block_numpy and "numpy" not in sys.modules:
        sys.modules["numpy"] = None            # import numpy → ImportError, openpyxl это предусматривает


def arg_value(argv, name):
    """Значение ключа командной строки до argparse (его импорт ещё впереди)."""
    try:
        return argv[argv.index(name) + 1]
    except (ValueError, IndexError):
        return None


def _read(path, mode="r"):
    with open(path, mode) as handle:
        return handle.read()


def own_processes():
    """Процессы этого пользователя: [(pid, rss_мб, возраст_с или None, команда)], по убыванию памяти.
    Читается /proc — внешние программы (ps) для этого не нужны."""
    uid = os.getuid()
    try:
        ticks = os.sysconf("SC_CLK_TCK")
        uptime = float(_read("/proc/uptime").split()[0])
    except (OSError, ValueError):
        ticks, uptime = 100, None
    result = []
    try:
        pids = [p for p in os.listdir("/proc") if p.isdigit()]
    except OSError:
        return result
    for pid in pids:
        try:
            status = _read("/proc/%s/status" % pid)
            uids = next((line.split()[1:] for line in status.splitlines() if line.startswith("Uid:")), [])
            if not uids or int(uids[0]) != uid:
                continue
            rss = next((int(line.split()[1]) // 1024 for line in status.splitlines() if line.startswith("VmRSS:")), 0)
            cmd = _read("/proc/%s/cmdline" % pid, "rb").split(b"\0")
            cmd = [part.decode("utf-8", "replace") for part in cmd if part]
            age = None
            if uptime is not None:
                fields = _read("/proc/%s/stat" % pid).rsplit(")", 1)[1].split()
                age = int(uptime - int(fields[19]) / ticks)       # поле 22 — время старта процесса
            result.append((int(pid), rss, age, cmd))
        except (OSError, ValueError, IndexError, StopIteration):
            continue
    result.sort(key=lambda item: -item[1])
    return result


def account_threads():
    """(потоков у процессов пользователя, лимит процессов и потоков RLIMIT_NPROC или None)."""
    uid = os.getuid()
    total = 0
    try:
        pids = [p for p in os.listdir("/proc") if p.isdigit()]
    except OSError:
        pids = []
    for pid in pids:
        try:
            status = _read("/proc/%s/status" % pid)
            uids = next((line.split()[1:] for line in status.splitlines() if line.startswith("Uid:")), [])
            if uids and int(uids[0]) == uid:
                total += next((int(line.split()[1]) for line in status.splitlines() if line.startswith("Threads:")), 1)
        except (OSError, ValueError, StopIteration):
            continue
    limit = None
    try:
        for line in _read("/proc/self/limits").splitlines():
            if line.startswith("Max processes"):
                limit = line.split()[2]
    except OSError:
        pass
    return total, limit


def _short_cmd(cmd):
    """«python3 web_rv_run.py mark» вместо полной командной строки с путями."""
    if not cmd:
        return "?"
    words = [os.path.basename(cmd[0])]
    script = next((part for part in cmd[1:] if part.endswith((".py", ".php"))), None)
    if script:
        words.append(os.path.basename(script))
    phase = arg_value(cmd, "--phase")
    if phase:
        words.append(phase)
    return " ".join(words)


def _age(seconds):
    if seconds is None:
        return ""
    if seconds >= 3600:
        return "%d ч %02d мин" % (seconds // 3600, seconds % 3600 // 60)
    return "%d мин" % (seconds // 60) if seconds >= 60 else "%d с" % seconds


def memory_report(processes=None, top=8):
    """Одна строка для статуса и журнала: кто занимает память аккаунта, и лимиты процесса."""
    processes = own_processes() if processes is None else processes
    total = sum(rss for _, rss, _, _ in processes)
    parts = ["%s — %d МБ%s" % (_short_cmd(cmd), rss, (", идёт " + _age(age)) if age else "")
             for _, rss, age, cmd in processes[:top] if rss]
    text = "процессы аккаунта: %s; всего %d МБ" % ("; ".join(parts) or "нет данных", total)
    threads, nproc = account_threads()
    text += "; потоков у процессов аккаунта: %d (лимит хостинга: %s)" % (threads, nproc or "—")
    try:
        for line in _read("/proc/self/limits").splitlines():
            if line.startswith(("Max address space", "Max resident set")):
                bits = line.split()
                text += "; %s: %s" % ("адресное пространство" if "address" in line else "резидентная память", bits[-3])
    except OSError:
        pass
    return text


def stop_stale_runs(log=None, max_age=RUN_MAX_AGE, processes=None):
    """Завершить запуски агента РВ этого пользователя, идущие дольше max_age. Возвращает их pid."""
    log = log or (lambda message: None)
    stopped = []
    for pid, rss, age, cmd in (own_processes() if processes is None else processes):
        if pid == os.getpid() or age is None or age <= max_age:
            continue
        if not any(part.endswith("web_rv_run.py") for part in cmd):
            continue
        if "queue" in cmd and cmd[cmd.index("queue") - 1] == "--phase":
            continue        # разборщик очереди 1С живёт долго по делу; зависшие — его дочерние запуски
        try:
            os.kill(pid, signal.SIGTERM)
            stopped.append(pid)
            log("остановлен зависший запуск агента РВ: pid %d, %s, %d МБ, шёл %s" % (pid, _short_cmd(cmd), rss, _age(age)))
        except OSError as exc:
            log("не удалось остановить pid %d: %s" % (pid, exc))
    return stopped


def _update_status(path, **fields):
    """Обновить статус, сохранив остальные поля (журнал первой фазы и т.п.); ключ launched снимается."""
    if not path:
        return
    try:
        with open(path, encoding="utf-8") as handle:
            status = json.load(handle)
        if not isinstance(status, dict):
            status = {}
    except (OSError, ValueError):
        status = {}
    status.pop("launched", None)
    status.update(fields)
    status["updated"] = int(time.time())
    tmp = path + ".tmp"
    try:
        with open(tmp, "w", encoding="utf-8") as handle:
            json.dump(status, handle, ensure_ascii=False)
        os.replace(tmp, path)
    except OSError:
        pass


def mark_started(path):
    """Процесс жив: страница перестаёт ждать запуска."""
    _update_status(path, state="running", stage="запуск агента…")


def is_memory_failure(exc):
    if isinstance(exc, MemoryError):
        return True
    text = str(exc).lower()
    return any(marker in text for marker in MEMORY_MARKERS)


def startup_error(path, exc, details=""):
    """Сбой на старте не из-за ресурсов (нет библиотеки, ошибка в коде): сразу ошибка в статусе — страница
    не ждёт 15 минут «признаков жизни»."""
    reason = str(exc).strip().splitlines()[-1][:300] if str(exc).strip() else type(exc).__name__
    sys.stderr.write("[%s] агент РВ не запустился: %s: %s\n%s" % (time.strftime("%H:%M:%S"), type(exc).__name__, reason, details))
    sys.stderr.flush()
    _update_status(path, state="error", stage="запуск",
                   error="Агент РВ не запустился: %s: %s. Сообщите администратору — подробности в журнале ниже."
                   % (type(exc).__name__, reason))
    return 1


def startup_failed(path, exc, attempt=None, attempts=None):
    """Нехватка памяти на старте: статус и журнал с причиной; код TEMPFAIL — оболочка повторит."""
    attempt = int(attempt if attempt is not None else os.environ.get("RV_ATTEMPT") or 1)
    attempts = int(attempts if attempts is not None else os.environ.get("RV_ATTEMPTS") or 1)
    report = memory_report()
    reason = str(exc).strip().splitlines()[-1][:200] if str(exc).strip() else type(exc).__name__
    sys.stderr.write("[%s] агент РВ не запустился — на сервере не хватает памяти или потоков (%s); попытка %d из %d; %s\n"
                     % (time.strftime("%H:%M:%S"), reason, attempt, attempts, report))
    sys.stderr.flush()
    if attempt < attempts:
        _update_status(path, state="running",
                       stage="на сервере не хватает памяти или потоков — повтор через %d с (попытка %d из %d)"
                       % (int(os.environ.get("RV_RETRY_SEC") or RETRY_PAUSE_SEC), attempt, attempts))
    else:
        _update_status(path, state="error", stage="запуск",
                       error=("Агент РВ не смог запуститься: на сервере не хватает памяти или потоков даже на загрузку библиотек "
                              "(попыток: %d). Чаще всего их занимают другие процессы аккаунта — список ниже в журнале. "
                              "Повторите через несколько минут; если повторится, сообщите администратору. %s" % (attempts, report)))
    return TEMPFAIL
