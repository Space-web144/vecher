# -*- coding: utf-8 -*-
"""
РВ в форме ТКП (как выгружает 1С): иерархия узлов ИСР по коду работы
(6 → 6.2 → 6.2.3 → 6.2.3.1 → система → … → семья), строка работы с единицей,
коэффициентом 1 и объёмом, под ней — строки материалов с коэффициентом
расхода по справочнику КЦ и количеством из ЛРВ. Колонки A–M — как в форме,
дальше три колонки проверки: уверенность, роль, примечание агента.

build_rows() собирает строки для листа «РВ» книги Excel и для страницы
проверки на сайте (тот же список уходит в JSON результата); write_sheet()
пишет лист. Названия узлов ИСР — rv/data/isr_names.json (из колонки
«Путь разделов» выгрузки КЦ, см. rv_kc_import.py).
"""
import json
import os
import re

from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

HERE = os.path.dirname(os.path.abspath(__file__))
NAMES_FILE = os.path.join(HERE, "rv", "data", "isr_names.json")

TITLE_ROW = "РЕСУРСНАЯ ВЕДОМОСТЬ (РВ)"
NOTE_ROW = ("Количества материалов — по ЛРВ, объёмы работ — по правилам КЦ; цены (ПСПР) не заполнены — "
            "вносятся при подготовке ТКП. Колонки N–P — проверка привязки: уверенность агента, роль строки, примечание.")
HEADERS = ["Номер п/п", "Код узла ИСР/код материала", "Наименование затрат", "Примечание", "Ед. изм.", "Коэф. расхода",
           "Кол-во", "Предельная стоимость производства работ (ПСПР)", "", "", "", "", "",
           "Уверенность, %", "Роль", "Примечание агента"]
WIDTHS = [7.3, 13.3, 43.5, 13.3, 9.5, 8.8, 9.7, 23.3, 21.5, 10.5, 17.5, 20.8, 15.5, 11, 7, 54]
MAIN_WORKS = "Основные работы"

# Пояснения для инженера: флаги агента и способы расчёта объёма — словами, без кодов.
FLAG_TEXT = {
    "F-SYS": "работа из другой ветки или системы — библиотека знала это имя только там",
    "F-DEPR": "код закрыт в справочнике КЦ — подобрана действующая замена",
    "F-DN": "вариант работы исправлен по диаметру из наименования",
    "F-MAT": "материал в наименовании не совпадает с семьёй работы из библиотеки",
    "F-GRP": "в справочнике КЦ у этой работы нет группы для такого материала — проверить работу",
    "F-KR": "крепёж: в системе нет работ-потребителей, работа взята по библиотеке",
    "F-CTX": "раздел и система строки не определены",
    "F-UNIT": "единица измерения взята по типу материала — в ЛРВ её нет",
    "F-VOL": "объём работы не определился по ведущим материалам",
    "F-NORM": "расход не сходится с нормой КЦ",
    "F-1C": "в 1С материал разнесён на эту работу, программа предлагает другую (какую — в подсказке и в строке «агент: …»). Оставить как в 1С — ничего не делать; принять — «принять агента» или «Исправить»",
    "F-SMETA": "такой работы нет среди сметных позиций сметы в 1С — при загрузке она добавится новой позицией",
    "F-RVR": "заказ-наряд РВР: в коде 12 нет работы с таким названием или она взята из другой подсистемы — выберите работу кода 12 («Исправить»)",
    "F-LOCAL": "работу поменяла модель по указаниям для этой РВ (ТЗ сметчика) — причина в пометке; проверьте: «Исправить», если не так",
    "F-ALT": "материал может относиться к нескольким работам (например, кабель открыто, в трубе или в лотке) — агент выбрал самую частую, остальные в вариантах: подтвердите или выберите другую",
}
METHOD_TEXT = (
    ("по коэффициентам инженера", "объём пересчитан по коэффициентам, исправленным инженером"),
    ("Σ количество / k ведущих групп [КЦ] + длина фасонных частей", "объём = метраж труб + длина фасонных частей (отводы, тройники, переходы, ревизии) по каталогу производителя"),
    ("фасонные части + длина фасонных частей", "объём = длина фасонных частей по каталогу производителя (труб под работой нет)"),
    ("Σ количество / k ведущих групп", "объём = сумма количеств ведущих материалов по справочнику КЦ"),
    ("площадь по геометрии из имени (фасонные", "объём = площадь воздуховодов по размерам из наименований (фасонные — приближённо)"),
    ("площадь по геометрии из имени", "объём = площадь воздуховодов по размерам из наименований"),
    ("масса металлопроката [В 31.10], часть", "объём = масса металлопроката (часть — по сортаменту)"),
    ("масса металлопроката", "объём = масса металлопроката"),
    ("метраж парной работы", "объём = метраж парной работы прокладки"),
    ("площадь окрашиваемых труб: чёрных труб нет", "объём = площадь всех стальных труб системы (чёрных нет — проверить)"),
    ("площадь окрашиваемых труб", "объём = площадь чёрных стальных труб системы под окраску"),
    ("F-VOL: ведущая группа КЦ не найдена", "объём = сумма строк роли В в единице работы (ведущей группы КЦ нет)"),
    ("F-VOL: ведущих строк нет", "объём по норме расхода вспомогательного материала — ведущих материалов нет"),
    ("F-VOL: объём не определён", "объём не определён: нет ведущих материалов или единицы не совпадают"),
    ("F-VOL: окрашиваемых стальных труб", "объём по расходу краски — стальных труб в системе нет, проверить"),
    ("объём ведут только Кр-строки", "объём не считается: под работой только крепёж"),
)
ROLE_TEXT = {
    "В": "ведущий материал — определяет работу и её объём",
    "С-В": "сопутствующий в работе ведущего (фасонные, фланцы, гильзы); фасонные части трубопроводов, для которых есть каталог, добавляют к объёму свою длину",
    "С-С": "сопутствующий со своей работой (изоляция, противопожарная защита)",
    "Р": "расходник одной работы (клей, краска, герметик)",
    "Кр": "крепёж — распределяется между работами-потребителями по их объёму",
    "?": "роль не определена",
}
ROLE_LEGEND = "; ".join("%s — %s" % (role, text) for role, text in ROLE_TEXT.items() if role != "?")
COEF_TEXT = ("Коэффициент строки — сколько единиц работы даёт одна единица материала (м² на 1 шт воздуховода, "
             "т на 1 м уголка, 1 для трубы в метрах, длина по оси в м для фасонной части трубопровода по каталогу); "
             "0 — строка объём работы не ведёт. Можно исправить на странице проверки.")


def explain_flags(fcodes):
    return [FLAG_TEXT.get(code, code) for code in fcodes or []]


def explain_method(method):
    for prefix, text in METHOD_TEXT:
        if (method or "").startswith(prefix):
            return text
    return method or ""
NO_WORK = "Строки без работы — укажите работу"
NO_SECTION = "Раздел и система не определены — задайте систему при загрузке ЛРВ"

_names_cache = None


def names():
    """Названия узлов ИСР по префиксу кода."""
    global _names_cache
    if _names_cache is None:
        try:
            with open(NAMES_FILE, encoding="utf-8") as handle:
                _names_cache = json.load(handle)
        except (OSError, ValueError):
            _names_cache = {}
    return _names_cache


def _code_key(code):
    return [int(x) if x.isdigit() else x for x in (code or "").split(".")]


def _fam(work):
    return re.split(r"\s*/\s*", (work or "").strip(), maxsplit=1)[0]


def _conf(binding):
    try:
        return int(round(float(binding.get("confidence") or 0) * 100))
    except (TypeError, ValueError):
        return 0


def _onec_works(item):
    """Работы строки в 1С (поле «РаботыВ1С»): [{code, name, qty, coef}] — без импорта rv_audit (у него свои зависимости)."""
    out = []
    for work in ((item.get("ext") or {}).get("РаботыВ1С") or []):
        if not isinstance(work, dict):
            continue
        code = str(work.get("Код") or work.get("КодИСР") or "").strip()
        name = str(work.get("Наименование") or "").strip()
        if not code and not name:
            continue
        out.append(dict(code=code, name=name[:100], qty=_num_or_none(work.get("Количество")), coef=_num_or_none(work.get("Коэффициент"))))
    return out


def _num_or_none(value):
    try:
        return None if value in (None, "") else float(str(value).replace(",", ".").replace(" ", ""))
    except (TypeError, ValueError):
        return None


def _qty_smeta(item, qty):
    """Количество «в смету» строки из 1С («КоличествоВСмету» в полях строки); у части разделённой строки — её доля."""
    ext = item.get("ext") or {}
    total = _num_or_none(ext.get("КоличествоВСмету"))
    if total is None:
        return None
    reduce = item.get("reduce")
    if reduce and qty is not None:
        # ЛРВ уменьшилась: «в смету» из 1С относится к прежнему количеству строки — берётся доля оставшегося
        before = _num_or_none(reduce.get("total", reduce.get("before")))
        return round(total * float(qty) / before, 4) if before else 0
    whole = _num_or_none(item.get("qty_total"))
    if item.get("split_of") is not None and whole and qty is not None:
        return round(total * float(qty) / whole, 4)
    return total


def _mat_row(block, binding, item, qty, part, level, review_map, coef, works=None):
    rec = review_map.get(str(binding["id"]))
    onec = _onec_works(item)
    onec_main = None
    if binding.get("onec_code"):
        for work in onec:
            if work["code"] == binding["onec_code"] and (onec_main is None or (work["qty"] or 0) > (onec_main["qty"] or 0)):
                onec_main = work
    return dict(t="mat", lvl=level, id=binding["id"], name=binding.get("name") or item.get("name") or "",
                onec_code=binding.get("onec_code") or "", onec_text=binding.get("onec_text") or "",
                onec_coef=onec_main["coef"] if onec_main else None, onec_works=onec,
                agent_code=binding.get("agent_code") or "", agent_work=binding.get("agent_work") or "",
                qty2=_qty_smeta(item, qty),
                reduce=item.get("reduce") or None,      # ЛРВ уменьшилась: dict(qty — на сколько, before — было в 1С)
                split_of=item.get("split_of"), split_k=item.get("split_k"), split_n=item.get("split_n"),
                split_total=item.get("qty_total"), split_by=item.get("split_by") or "",
                alts=[dict(code=a.get("code") or "", work=a.get("work") or "", share=a.get("share") or 0)
                      for a in (binding.get("alts") or []) if a.get("code")],
                unit=binding.get("unit") or item.get("unit") or "", coef=coef, qty=qty,
                qty_total=item.get("qty") if part else None, part=part,
                conf=_conf(binding), role=binding.get("role") or "", review=bool(binding.get("review")),
                code=binding.get("code") or "",
                flags=list(binding.get("flags") or []), fcodes=list(binding.get("fcodes") or []),
                src=binding.get("source") or "", learned=binding.get("learned") or "",
                coef_user=binding.get("coef_user") is not None, coef_agent=binding.get("coef_agent"),
                why=explain_flags(binding.get("fcodes")),
                rec=(dict(verdict=rec.get("verdict"), code=rec.get("code") or "", work=rec.get("work") or "",
                          role=rec.get("role") or "", reason=rec.get("reason") or "", question=rec.get("question") or "")
                     if rec else None),
                system=item.get("system") or binding.get("system") or "", sysc=binding.get("system_code") or "",
                section=block.get("section") or "")


def build_rows(result, works, isr=None, flat=False):
    """Строки формы по результату web_rv_run (полному, с items/bindings/rv).
    works — код → полное имя работы (bind.KB['works']); коэффициент строки — binding['coef']
    (web_rv_run.row_coefs: объём работы на единицу материала); isr — названия узлов (по умолчанию из файла).
    flat — для страницы проверки: без разбивки на блоки по системам ИСР (заголовок один на элемент, дерево узлов
    одно), в Excel по форме ТКП — с блоками (flat=False)."""
    isr = names() if isr is None else isr
    review_map = result.get("review") or {}
    work_notes = result.get("work_notes") or {}
    source = os.path.splitext(result.get("source_name") or "")[0] or "Объект"
    rows = []

    def title(parts, short=""):
        rows.append(dict(t="title", lvl=0, name=" / ".join(p for p in parts if p), short=short))

    def node(code, name, level):
        rows.append(dict(t="node", lvl=level, code=code, name=name))

    for block in result.get("elements") or []:
        section = block.get("section")
        element = block.get("element") or ""
        by_id = {it["id"]: it for it in block.get("items") or []}
        bindings = {b["id"]: b for b in block.get("bindings") or []}
        if not section:
            title([source, element, NO_SECTION])
            node("", NO_SECTION, 1)
            for binding in block.get("bindings") or []:
                item = by_id.get(binding["id"], {})
                rows.append(_mat_row(block, binding, item, item.get("qty"), False, 2, review_map, None, works))
                rows[-1]["nosec"] = True
            continue
        work_list = sorted((block.get("rv") or {}).get("works") or [], key=lambda w: _code_key(w["code"]))
        groups = {}
        for work in work_list:
            parts = work["code"].split(".")
            groups.setdefault(".".join(parts[:5]), []).append(work)
        element_label = element if element and element != section else MAIN_WORKS
        emitted = set()
        if flat:
            title([source, section, element_label], short=section + " · " + element_label)
        for prefix in sorted(groups, key=_code_key):
            if not flat:
                system_name = isr.get(prefix) or isr.get(".".join(prefix.split(".")[:4])) or prefix
                title([source, system_name, element_label])
                emitted = set()
            for work in groups[prefix]:
                code = work["code"]
                parts = code.split(".")
                for depth in range(1, len(parts)):
                    pre = ".".join(parts[:depth])
                    if pre in emitted:
                        continue
                    emitted.add(pre)
                    name = isr.get(pre)
                    if not name and depth == len(parts) - 1:
                        name = _fam(works.get(code) or work.get("work"))
                    node(pre, name or "—", depth)
                volume = work.get("volume")
                remark = work_notes.get(code) or {}
                rows.append(dict(t="work", lvl=len(parts), code=code, name=works.get(code) or work.get("work") or "",
                                 unit=work.get("unit") or "", coef=1, qty=volume, method=explain_method(work.get("method")),
                                 nmat=len(work.get("materials") or []), section=section, element=element,
                                 auto=bool(work.get("auto")), manual=bool(work.get("manual")), note=work.get("note") or "",
                                 remark=str(remark.get("text") or ""), remark_by=str(remark.get("by") or "")))
                for material in work.get("materials") or []:
                    binding = bindings.get(material["id"])
                    item = by_id.get(material["id"], {})
                    if binding is None:
                        continue
                    part = binding.get("role") == "Кр" and material.get("qty") != item.get("qty")
                    coef = binding.get("coef_user") if binding.get("coef_user") is not None else binding.get("coef")
                    rows.append(_mat_row(block, binding, item, material.get("qty"), part, len(parts), review_map,
                                         coef if coef is not None else 0, works))
        unbound = [bindings[u["id"]] for u in (block.get("rv") or {}).get("unbound") or [] if u["id"] in bindings]
        if unbound:
            title([source, element_label, "Строки без работы"])
            node("", NO_WORK, 1)
            for binding in unbound:
                item = by_id.get(binding["id"], {})
                rows.append(_mat_row(block, binding, item, item.get("qty"), False, 2, review_map, None, works))
    rows.append(dict(t="total", lvl=0, name="Общая стоимость работ с НДС (руб.)"))
    return rows


# ── Книга Excel ──

THIN = Side(style="thin")
BOX = Border(left=THIN, right=THIN, top=THIN, bottom=THIN)
TOP_BOTTOM = Border(top=THIN, bottom=THIN)
FILL_BAND = PatternFill("solid", fgColor="FF2E5386")
FILL_HEAD = PatternFill("solid", fgColor="FFDBE6F0")
FILL_TITLE = PatternFill("solid", fgColor="FFF9D7FF")
FILL_NODE = PatternFill("solid", fgColor="FFE4FFE4")
FILL_WORK = PatternFill("solid", fgColor="FFFFFECB")
FILL_REVIEW = PatternFill("solid", fgColor="FFFDF6E6")
FILL_QUESTION = PatternFill("solid", fgColor="FFFCEFEC")
FILL_LEARNED = PatternFill("solid", fgColor="FFEDF7F0")
FILL_AUTO = PatternFill("solid", fgColor="FFFFE9B8")     # работа добавлена агентом (без материалов) — проверить
FONT = "Times New Roman"
CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)
LEFT = Alignment(horizontal="left", vertical="center", wrap_text=True)
LEFT_NOWRAP = Alignment(horizontal="left", vertical="center")
MONEY = "#,##0.00"
ZERO_BLANK = '[=0]""'
SUM_CHUNK = 200


def _sum(column, rows_):
    """=SUM(K15,K40,…) по списку строк; длинные списки — кусками."""
    if not rows_:
        return 0
    refs = ["%s%d" % (column, r) for r in rows_]
    chunks = ["SUM(%s)" % ",".join(refs[i:i + SUM_CHUNK]) for i in range(0, len(refs), SUM_CHUNK)]
    return "=" + "+".join(chunks)


def write_sheet(book, result, rows, title="РВ"):
    """Лист «РВ» в форме ТКП. Формулы стоимости живые: цены вносятся в H (материалы) и I (СМР)."""
    sheet = book.create_sheet(title, 0)
    for index, width in enumerate(WIDTHS, start=1):
        sheet.column_dimensions[get_column_letter(index)].width = width
    sheet.sheet_properties.outlinePr.summaryBelow = False
    sheet.sheet_properties.outlinePr.summaryRight = False

    def put(row, col, value, font=None, fill=None, border=None, align=None, fmt=None):
        cell = sheet.cell(row=row, column=col, value=value)
        cell.font = font or Font(name=FONT, size=8)
        if fill is not None:
            cell.fill = fill
        if border is not None:
            cell.border = border
        if align is not None:
            cell.alignment = align
        if fmt:
            cell.number_format = fmt
        return cell

    bold = Font(name=FONT, size=8, bold=True)
    grey = Font(name=FONT, size=8, color="FF454545")
    object_name = os.path.splitext(result.get("source_name") or "")[0]
    sections = result.get("sections") or ([result["section"]] if result.get("section") else [])
    put(1, 1, TITLE_ROW, bold, align=Alignment(horizontal="center", vertical="center"))
    put(2, 1, "%s — %s" % (object_name, ", ".join(sections)) if sections else object_name,
        Font(name=FONT, size=8, bold=True, color="FFFFFFFF"), FILL_BAND, align=Alignment(horizontal="center", vertical="center"))
    put(3, 1, NOTE_ROW, align=Alignment(horizontal="center", vertical="center", wrap_text=True))
    for col in range(1, 14):
        for row in (1, 2, 3):
            sheet.cell(row=row, column=col).fill = FILL_BAND if row == 2 else PatternFill()
    sheet.merge_cells("A1:M1")
    sheet.merge_cells("A2:M2")
    sheet.merge_cells("A3:M3")
    sheet.row_dimensions[3].height = 24
    # шапка — три строки, как в форме
    for col, text in enumerate(HEADERS, start=1):
        put(4, col, text or None, align=CENTER, border=BOX, fill=FILL_HEAD if 8 <= col <= 13 else None)
        for row in (5, 6):
            put(row, col, None, border=BOX)
    put(5, 8, "Цена, руб. с НДС", align=CENTER, border=BOX)
    put(5, 10, "Цена, руб. с НДС", align=CENTER, border=BOX)
    put(5, 11, "Стоимость, руб с НДС", align=CENTER, border=BOX)
    put(5, 13, "Общая стоимость,\nруб. с НДС", align=CENTER, border=BOX)
    put(6, 8, "Материалы/\nоборудование", align=CENTER, border=BOX)
    put(6, 9, "СМР, ПНР", align=CENTER, border=BOX)
    put(6, 11, "Материалы/\nоборудование", align=CENTER, border=BOX)
    put(6, 12, "СМР, ПНР", align=CENTER, border=BOX)
    for rng in ("A4:A6", "B4:B6", "C4:C6", "D4:D6", "E4:E6", "F4:F6", "G4:G6", "H4:M4", "H5:I5", "J5:J6", "K5:L5",
                "M5:M6", "N4:N6", "O4:O6", "P4:P6"):
        sheet.merge_cells(rng)
    sheet.row_dimensions[6].height = 23
    sheet.freeze_panes = "A7"
    from openpyxl.comments import Comment
    for ref, text in (("F4", COEF_TEXT), ("O4", "Роль строки: " + ROLE_LEGEND),
                      ("N4", "Уверенность агента в выбранной работе, %. Правило раздела или конвенция — 80–100, "
                             "эталонная библиотека — доля образцов, класс → семья — до 70. Решение инженера — 100."),
                      ("P4", "Почему строка привязана так и что проверить; рекомендация модели, если была.")):
        comment = Comment(text, "агент РВ")
        comment.width, comment.height = 420, 160
        sheet[ref].comment = comment

    # строки: сначала значения и номера, формулы узлов — после (нужны строки работ-потомков)
    row = 6
    pending = []            # (строка заголовка блока, строки его работ)
    node_children = {}      # строка узла → строки работ под ним
    work_rows = []
    stack = []              # открытые узлы: [(уровень, строка)]
    title_row = None
    title_works = []
    last_work = None
    mats_of = {}            # строка работы → строки её материалов

    def close_title():
        if title_row is not None:
            pending.append((title_row, list(title_works)))

    for entry in rows:
        kind = entry["t"]
        if kind == "total":
            close_title()
            row += 1
            put(row, 3, entry["name"], Font(name="Arial", size=8, bold=True), align=Alignment(horizontal="right"))
            for col in (11, 12, 13):
                put(row, col, _sum(get_column_letter(col), work_rows), Font(name="Arial", size=8, bold=True),
                    FILL_HEAD if col == 13 else None, align=Alignment(horizontal="right"), fmt=MONEY)
            continue
        row += 1
        if kind == "title":
            close_title()
            title_row, title_works = row, []
            stack = []
            for col in range(1, 14):
                put(row, col, None, border=TOP_BOTTOM, fill=FILL_TITLE if col in (1, 2, 3, 11, 12, 13) else None)
            put(row, 3, entry["name"], Font(name="Arial", size=10, bold=True), FILL_TITLE, TOP_BOTTOM, LEFT_NOWRAP)
            sheet.merge_cells(start_row=row, start_column=3, end_row=row, end_column=10)
            sheet.row_dimensions[row].height = 21
            continue
        level = int(entry.get("lvl") or 1)
        sheet.row_dimensions[row].outlineLevel = min(level, 7)
        if kind == "node":
            while stack and stack[-1][0] >= level:
                stack.pop()
            stack.append((level, row))
            for col in range(1, 14):
                put(row, col, None, border=BOX if col in (1, 11, 12, 13) else TOP_BOTTOM,
                    fill=FILL_NODE if col in (1, 2, 3, 11, 12, 13) else None)
            put(row, 2, entry.get("code") or None, fill=FILL_NODE, border=TOP_BOTTOM, align=LEFT_NOWRAP)
            put(row, 3, entry["name"], fill=FILL_NODE, border=TOP_BOTTOM, align=LEFT_NOWRAP)
            entry["_row"] = row
            continue
        if kind == "work":
            last_work = row
            mats_of[row] = []
            work_rows.append(row)
            title_works.append(row)
            for _lvl, node_row in stack:
                node_children.setdefault(node_row, []).append(row)
            work_fill = FILL_AUTO if entry.get("auto") else FILL_WORK
            for col in range(1, 17):
                put(row, col, None, bold, work_fill, BOX, CENTER if col >= 5 else LEFT)
            put(row, 2, entry["code"], bold, FILL_WORK, BOX, LEFT)
            put(row, 3, entry["name"], bold, FILL_WORK, BOX, LEFT)
            put(row, 5, entry.get("unit") or None, bold, FILL_WORK, BOX, CENTER)
            put(row, 6, 1, bold, FILL_WORK, BOX, CENTER)
            qty = entry.get("qty")
            put(row, 7, qty if qty is not None else None, bold, FILL_WORK, BOX, CENTER, "0.000")
            put(row, 10, "=H%d+I%d" % (row, row), bold, FILL_WORK, BOX, CENTER, "0.00")
            put(row, 12, "=G%d*I%d" % (row, row), bold, FILL_WORK, BOX, CENTER, MONEY)
            put(row, 13, "=K%d+L%d" % (row, row), bold, FILL_WORK, BOX, CENTER, MONEY)
            note = entry.get("method") or ""
            if entry.get("auto"):
                note = (entry.get("note") or "добавлено агентом: работа без материалов") + ("; " + note if note else "")
            if qty is None:
                note = "объём не определён: " + note if note else "объём не определён"
            put(row, 16, note or None, Font(name=FONT, size=8, bold=False), FILL_WORK, BOX, LEFT)
            entry["_row"] = row
            continue
        # материал
        if last_work is not None and kind == "mat" and not entry.get("nosec") and entry.get("code"):
            mats_of[last_work].append(row)
        fill = None
        if entry.get("nosec") or not entry.get("code"):
            fill = FILL_QUESTION
        elif entry.get("learned") == "correction":
            fill = FILL_LEARNED
        elif entry.get("review"):
            fill = FILL_REVIEW
        for col in range(1, 17):
            put(row, col, None, grey, fill if (fill is not None and (col >= 14 or fill is FILL_QUESTION)) else None, BOX,
                CENTER if col >= 5 else LEFT)
        put(row, 1, entry.get("id"), grey, None, BOX, LEFT)
        put(row, 3, entry["name"], grey, None, BOX, LEFT)
        put(row, 5, entry.get("unit") or None, grey, None, BOX, CENTER)
        put(row, 6, entry.get("coef") if entry.get("coef") is not None else 0, grey, None, BOX, CENTER)
        put(row, 7, entry.get("qty"), grey, None, BOX, CENTER, "0.000")
        put(row, 8, None, Font(name=FONT, size=8), None, BOX, CENTER, "0.00")
        put(row, 9, 0, grey, None, BOX, CENTER, ZERO_BLANK)
        put(row, 10, 0, grey, None, BOX, CENTER, ZERO_BLANK)
        put(row, 11, "=G%d*H%d" % (row, row), grey, None, BOX, CENTER, "0.00")
        put(row, 12, 0, grey, None, BOX, CENTER, ZERO_BLANK)
        put(row, 13, 0, grey, None, BOX, CENTER, ZERO_BLANK)
        conf_fill = fill if fill is not None else None
        put(row, 14, entry.get("conf"), grey, conf_fill, BOX, CENTER)
        put(row, 15, entry.get("role") or None, grey, conf_fill, BOX, CENTER)
        put(row, 16, _note(entry), grey, conf_fill, BOX, LEFT)
        entry["_row"] = row

    # формулы работ (цена материалов = Σ стоимости материалов / объём) и узлов
    for work_row, mats in mats_of.items():
        if mats:
            rng = "K%d:K%d" % (mats[0], mats[-1])
            put(work_row, 11, "=SUM(%s)" % rng, bold, FILL_WORK, BOX, CENTER, MONEY)
            put(work_row, 8, "=IF(G%d>0,K%d/G%d,0)" % (work_row, work_row, work_row), bold, FILL_WORK, BOX, CENTER, "0.00")
        else:
            put(work_row, 11, 0, bold, FILL_WORK, BOX, CENTER, MONEY)
            put(work_row, 8, 0, bold, FILL_WORK, BOX, CENTER, "0.00")
    for node_row, children in node_children.items():
        for col in (11, 12, 13):
            put(node_row, col, _sum(get_column_letter(col), children), None, FILL_NODE, BOX, CENTER, MONEY)
    for title_row_, children in pending:
        for col in (11, 12, 13):
            put(title_row_, col, _sum(get_column_letter(col), children), bold, FILL_TITLE, BOX, CENTER, ZERO_BLANK if not children else MONEY)
    return sheet


def _note(entry):
    """Примечание агента для строки материала — словами: почему привязка такая, что проверить."""
    parts = []
    if entry.get("nosec"):
        parts.append("раздел и система не определены")
    elif not entry.get("code"):
        parts.append("работа не определена")
    if entry.get("part"):
        parts.append("крепёж: часть строки ЛРВ, распределённой между работами (всего %s)" % _qty_text(entry.get("qty_total")))
    if entry.get("learned") == "correction":
        parts.append(entry.get("src") or "решение инженера")
    elif entry.get("learned") == "confirmed":
        parts.append("подтверждено инженером")
    if entry.get("coef_user"):
        parts.append("коэффициент исправлен инженером")
    parts.extend(entry.get("why") or [])
    rec = entry.get("rec")
    if rec and rec.get("verdict") and entry.get("learned") != "correction":
        text = "модель: " + rec["verdict"]
        if rec.get("code"):
            text += " → %s %s" % (rec["code"], rec.get("work") or "")
        if rec.get("question"):
            text += ". " + rec["question"]
        parts.append(text)
    return "; ".join(parts) or None


def _qty_text(value):
    try:
        number = float(value)
    except (TypeError, ValueError):
        return str(value or "")
    return ("%d" % number) if number == int(number) else ("%.3f" % number).rstrip("0").rstrip(".")
