# -*- coding: utf-8 -*-
"""
Чтение ЛРВ из 1С (xlsx / xls / csv) для агента РВ.

На выходе — строки материалов (наименование, единица, количество) и
заголовки групп, под которыми они стоят. В ЛРВ система и элемент обычно
не отдельные колонки, а группировка: строки-заголовки без количества
(«Корпус 1», «В2 Противопожарный водопровод», «К1»). Система каждой строки
нужна агенту обязательно (мастер-инструкция, A2), поэтому заголовки
размечает модель (rv_mark.py): какой заголовок — система, какой — элемент.
Если в файле есть колонки «Система» и «Элемент» — берём их, модель не
нужна.

Формат файла заранее не известен (выгрузки 1С бывают разные), поэтому
заголовок таблицы ищется по словам «наименование», «ед.», «кол-во», а при
его отсутствии колонки угадываются по содержимому.
"""
import csv
import io
import re

SECTIONS = ("ВК", "ОВ1", "ОВ2", "ЭОМ", "СС")

# Словарь систем (мастер-инструкция A2): синоним → значение для bind.py.
SYSTEMS = {
    "ВК": {
        "К1": "К1", "К1Н": "К1", "К1Ф": "К1", "К2": "К2", "К2Н": "К2", "К3": "К3", "К4": "К4", "К4Н": "К4",
        "В1": "В1", "Т3": "В1", "Т4": "В1", "ХВС": "В1", "ГВС": "В1", "В2": "В2", "АУПТ": "В2", "ПК": "В2",
        "ШП": "ШП", "ПРОЧИЕ": "прочие", "ПРОЧЕЕ": "прочие",
    },
    "ОВ1": {"ОТОПЛЕНИЕ": "отопление", "ПУ": "ПУ", "ТЕПЛОСНАБЖЕНИЕ": "ПУ", "УУ": "УУ"},
    "ОВ2": {"ОВ": "ОВ", "ОБЩЕОБМЕННАЯ": "ОВ", "ПДВ": "ПДВ", "ПРОТИВОДЫМНАЯ": "ПДВ", "ДЫМОУДАЛЕНИЕ": "ПДВ"},
    "ЭОМ": {"НЕЖИЛАЯ": "нежилая", "КВАРТИРЫ": "квартиры", "КОНДИЦИОНИРОВАНИЕ": "кондиционирование",
            "ЦИН": "ЦИН", "ФАСАД": "фасад"},
    # СС — код ветки/подветки как есть («5», «2.2», «10.1»).
    "СС": {},
}

OBJECT_TYPES = ("жилой", "паркинг", "СКБ", "прочее")

# Отчёт 1С «Остатки по ЛРВ» (выгрузка реального формата, 31.10.2026): одна
# колонка наименований с группировкой по уровням Проект → Аналитика 4 →
# Проект → Система → Номенклатура → Регистратор. Систему задаёт группа
# «Система» своим названием в 1С — ниже словарь: признак в названии →
# (раздел, система для bind.py). Порядок важен: первое совпадение.
SYSTEM_1C = (
    (r"накладн|вспомогат|плановая экономия|\bбнр\b", "skip", None),  # накладные расходы, БНР — не материалы работ
    (r"противопожарн|пожаротуш|аупт|спринкл", "ВК", "В2"),
    (r"хоз[а-я.\-]*\s*быт[а-я.\-]*\s*канализ|бытов[а-я]*\s*канализ|канализац[а-я]*\s*к1", "ВК", "К1"),
    (r"ливнев|дождев|внутренн[а-я]*\s*водосток|\bк2\b", "ВК", "К2"),
    # В КЦ ветка 3 (К3) — производственная канализация, ветка 4 (К4) — дренажная (канализация условно-чистых стоков).
    # Слово в названии главнее кода системы: «дренаж» — К4, даже если в проекте дренаж обозначен К3.
    (r"дренаж|условно[\s\-]*чист", "ВК", "К4"),
    (r"производств[а-я]*\s*канализ|\bк3\b", "ВК", "К3"),
    (r"\bк4\b", "ВК", "К4"),
    (r"канализ", "ВК", "К1"),
    (r"шахт[\s\-]*пакет", "ВК", "ШП"),
    (r"водоснабж|водопровод|хвс|гвс|\bв1\b", "ВК", "В1"),
    # Теплоснабжение калориферов приточных установок и воздушно-тепловых завес — в КЦ отдельный раздел 6.2.3.2.7.
    (r"теплоснабж|калорифер|\bитп\b|тепловой пункт|\bпу\b", "ОВ1", "ПУ"),
    (r"отоплен|теплоснабжение", "ОВ1", "отопление"),
    (r"противодым|дымоудал|\bпдв\b", "ОВ2", "ПДВ"),
    (r"вентиляц|кондиционир|\bов\b", "ОВ2", "ОВ"),
    (r"автоматизац|\(ак\)|\bаов\b|автоматика", "СС", "1"),
    (r"аиис\s*куэ|учет[а-я]*\s*электроэнерг", "СС", "2.1"),
    (r"аскув|учет[а-я]*\s*воды|учет[а-я]*\s*тепла", "СС", "2.2"),
    (r"аоди|мгн|вызов[а-я]*\s*инвалид", "СС", "3"),
    (r"асуд|диспетчериз", "СС", "4"),
    (r"апс|соуэ|пожарн[а-я]*\s*сигнализ|оповещен[а-я]*\s*(о\s*)?пожар", "СС", "5"),
    (r"кабельн[а-я]*\s*конструкц|\bкк\b|ккз", "СС", "7"),
    (r"оспд|передач[а-я]*\s*данных", "СС", "8"),
    (r"сети связи|слаботочн[а-я]*\s*сист", "СС", "9"),                 # общий том связи — ветка 9 без подветки
    (r"сов\W{0,3}скуд|скуд\W{0,3}сов", "СС", "10"),
    (r"\bсвн\b|видеонаблюд|\bсот\b|охранн[а-я]*\s*телевид", "СС", "11"),
    (r"скс|структурированн", "СС", "9.1"),
    (r"радиофик", "СС", "9.2"),
    (r"телевиден", "СС", "9.3"),
    (r"гочс|го\s*и\s*чс", "СС", "9.6"),
    (r"связ[иь]\b|телефон", "СС", "9"),
    (r"\bсов\b|домофон|охран[а-я]*\s*входов", "СС", "10.1"),
    (r"скуд|контрол[а-я]*\s*доступ|шлагбаум", "СС", "10.2"),
    (r"оздс|дератизац", "СС", "12"),
    (r"безопасн[а-я]*\s*регион", "СС", "13"),
    (r"сотс|охранн[а-я]*\s*сигнализ", "СС", "14"),
    (r"\bскз\b|контрол[а-я]*\s*загазован", "СС", "15"),
    (r"электромонтаж|электроснабж|электроосвещ|освещен|силов[а-я]*\s*электро|\bэом\b", "ЭОМ", None),
)
# Система ЭОМ — по части здания в названии группы.
_EOM_PARTS = ((r"квартир|(?<!не)жил[а-я]*\s*част", "квартиры"), (r"кондиционир", "кондиционирование"),
              (r"\bцин\b|индивидуальн[а-я]*\s*наруж", "ЦИН"), (r"фасад", "фасад"), (r".", "нежилая"))


def system_1c(text):
    """(раздел, система) по названию группы 1С; ("skip", None) — не материалы
    работ (накладные расходы, вспомогательные); (None, None) — не распознано."""
    low = _s(text).lower().replace("ё", "е")
    if not low:
        return None, None
    for pattern, section, system in SYSTEM_1C:
        if re.search(pattern, low):
            if section == "ЭОМ" and system is None:
                system = next(v for p, v in _EOM_PARTS if re.search(p, low))
            return section, system
    return None, None


_DRAIN_RE = re.compile(r"дренаж|условно[\s\-]*чист")


def fix_drainage_marks(headers, marks):
    """До 12.11.2026 словарь систем 1С относил дренажную канализацию к К3 — в КЦ это ветка 3, производственная
    канализация (дренажная — ветка 4, К4), и агент подбирал работы производственной канализации. Заголовок
    со словом «дренаж», размеченный как ВК/К3, становится ВК/К4 — и в новой разметке, и при пересборке уже
    собранной РВ. Меняет marks на месте, возвращает тексты исправленных заголовков."""
    fixed = []
    for index, mark in marks.items():
        if not isinstance(mark, dict) or mark.get("kind") != "system" or mark.get("system") != "К3" \
                or (mark.get("section") or "ВК") != "ВК":
            continue
        header = headers[int(index)] if 0 <= int(index) < len(headers) else {}
        text = _s((header or {}).get("text")).lower().replace("ё", "е")
        if _DRAIN_RE.search(text):
            mark["system"] = "К4"
            fixed.append(_s(header.get("text")))
    return fixed

_NAME_WORDS = ("наимен", "материал", "номенклат")
_UNIT_WORDS = ("ед.", "ед ", "един", "едизм")
_QTY_WORDS = ("кол-во", "колич", "кол.", "количество")


def _s(value):
    if value is None:
        return ""
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value).strip()


def _num(value):
    if value is None or value == "":
        return None
    if isinstance(value, bool):
        return None
    if isinstance(value, (int, float)):
        return float(value)
    text = str(value).strip().replace("\xa0", "").replace(" ", "").replace(",", ".")
    if not re.fullmatch(r"-?\d+(\.\d+)?", text):
        return None
    return float(text)


def read_table(path, limit_rows=200000):
    """Все листы файла как списки строк (списков ячеек). Берётся лист с
    наибольшим числом непустых строк — в выгрузках 1С он один."""
    lower = path.lower()
    sheets = []
    if lower.endswith((".xlsx", ".xlsm")):
        import openpyxl
        book = openpyxl.load_workbook(path, read_only=True, data_only=True)
        for sheet in book.worksheets:
            rows = []
            for row in sheet.iter_rows(values_only=True):
                rows.append(list(row))
                if len(rows) >= limit_rows:
                    break
            sheets.append((sheet.title, rows))
        book.close()
    elif lower.endswith(".xls"):
        import xlrd
        book = xlrd.open_workbook(path)
        for sheet in book.sheets():
            rows = [[sheet.cell_value(r, c) for c in range(sheet.ncols)] for r in range(min(sheet.nrows, limit_rows))]
            sheets.append((sheet.name, rows))
    else:
        raw = open(path, "rb").read()
        text = None
        for encoding in ("utf-8-sig", "cp1251", "utf-16"):
            try:
                text = raw.decode(encoding)
                break
            except UnicodeDecodeError:
                continue
        if text is None:
            text = raw.decode("utf-8", errors="replace")
        sample = text[:4096]
        try:
            dialect = csv.Sniffer().sniff(sample, delimiters=";,\t")
        except csv.Error:
            dialect = csv.excel
            dialect.delimiter = ";" if sample.count(";") >= sample.count(",") else ","
        rows = [list(r) for r in csv.reader(io.StringIO(text), dialect)]
        sheets.append(("csv", rows[:limit_rows]))
    if not sheets:
        raise ValueError("В файле нет листов с данными.")

    def filled(rows):
        return sum(1 for r in rows if any(_s(c) for c in r))

    sheets.sort(key=lambda item: filled(item[1]), reverse=True)
    return sheets[0]


def find_columns(rows):
    """Строка заголовка и индексы колонок: name, unit, qty, system?, element?, code?."""
    for index, row in enumerate(rows[:60]):
        cells = [_s(c).lower() for c in row]
        has_name = any(any(w in c for w in _NAME_WORDS) for c in cells)
        has_qty = any(any(w in c for w in _QTY_WORDS) for c in cells)
        has_unit = any(c.startswith(("ед", "единиц")) or any(w in c for w in _UNIT_WORDS) for c in cells)
        if has_name and (has_qty or has_unit):
            cols = {}
            for j, c in enumerate(cells):
                if not c:
                    continue
                if "name" not in cols and any(w in c for w in _NAME_WORDS):
                    cols["name"] = j
                elif "unit" not in cols and (c.startswith(("ед", "единиц")) or any(w in c for w in _UNIT_WORDS)):
                    cols["unit"] = j
                elif "qty" not in cols and any(w in c for w in _QTY_WORDS):
                    cols["qty"] = j
                elif "system" not in cols and "систем" in c:
                    cols["system"] = j
                elif "element" not in cols and ("элемент" in c or "корпус" in c or "секци" in c):
                    cols["element"] = j
                elif "code" not in cols and ("код" in c or "артикул" in c):
                    cols["code"] = j
            if "name" in cols and ("qty" in cols or "unit" in cols):
                return index, cols
    # Заголовка нет — угадываем по содержимому: самая текстовая колонка —
    # наименование, самая числовая — количество, короткие слова — единицы.
    width = max((len(r) for r in rows[:500]), default=0)
    score_text = [0] * width
    score_num = [0] * width
    score_unit = [0] * width
    for row in rows[:500]:
        for j in range(min(width, len(row))):
            value = _s(row[j])
            if not value:
                continue
            if _num(row[j]) is not None:
                score_num[j] += 1
            elif len(value) <= 6 and re.fullmatch(r"[а-яa-z0-9²³./\- ]+", value.lower()):
                score_unit[j] += 1
            else:
                score_text[j] += len(value) > 8
    if width == 0 or max(score_text) == 0:
        raise ValueError("Не удалось найти в файле колонку с наименованиями материалов.")
    cols = {"name": score_text.index(max(score_text))}
    if max(score_num) > 0:
        cols["qty"] = score_num.index(max(score_num))
    if max(score_unit) > 0:
        cols["unit"] = score_unit.index(max(score_unit))
    return -1, cols


_TOTAL_WORDS = ("итого", "всего", "сумма")

_NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
_NS_R = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"


def _col_index(ref):
    letters = re.match(r"[A-Z]+", ref)
    index = 0
    for ch in (letters.group(0) if letters else "A"):
        index = index * 26 + (ord(ch) - 64)
    return index - 1


def read_xlsx_outline(path, limit_rows=400000):
    """Строки первого (самого большого) листа xlsx с уровнем группировки
    строк (outlineLevel) и отступом первой ячейки — потоково, через XML:
    openpyxl в режиме read_only уровней не отдаёт, а полная загрузка
    отчёта 1С на 26 000 строк на хостинге слишком тяжела.

    Возвращает (имя листа, [{"values": [...], "level": int, "indent": int}])."""
    import xml.etree.ElementTree as ET
    import zipfile

    book = zipfile.ZipFile(path)
    names = set(book.namelist())
    shared = []
    if "xl/sharedStrings.xml" in names:
        for _, element in ET.iterparse(book.open("xl/sharedStrings.xml")):
            if element.tag == _NS + "si":
                shared.append("".join(t.text or "" for t in element.iter(_NS + "t")))
                element.clear()
    indents = []
    if "xl/styles.xml" in names:
        root = ET.parse(book.open("xl/styles.xml")).getroot()
        xfs = root.find(_NS + "cellXfs")
        for xf in (xfs if xfs is not None else []):
            alignment = xf.find(_NS + "alignment")
            indents.append(int(alignment.get("indent", "0")) if alignment is not None else 0)
    # Листы: имя → файл, через связи книги.
    rels = {}
    if "xl/_rels/workbook.xml.rels" in names:
        for rel in ET.parse(book.open("xl/_rels/workbook.xml.rels")).getroot():
            target = rel.get("Target", "")
            rels[rel.get("Id")] = target if target.startswith("/") else "xl/" + target.lstrip("/")
    sheets = []
    for sheet in ET.parse(book.open("xl/workbook.xml")).getroot().iter(_NS + "sheet"):
        target = rels.get(sheet.get(_NS_R + "id"), "").lstrip("/")
        if target in names:
            sheets.append((sheet.get("name"), target, book.getinfo(target).file_size))
    if not sheets:
        raise ValueError("В файле нет листов с данными.")
    sheets.sort(key=lambda item: item[2], reverse=True)
    title, target, _ = sheets[0]

    rows = []
    for _, element in ET.iterparse(book.open(target)):
        if element.tag != _NS + "row":
            continue
        values = []
        indent = 0
        for cell in element.iter(_NS + "c"):
            index = _col_index(cell.get("r", "A1"))
            while len(values) <= index:
                values.append(None)
            kind = cell.get("t")
            value = None
            if kind == "inlineStr":
                node = cell.find(_NS + "is")
                value = "".join(t.text or "" for t in node.iter(_NS + "t")) if node is not None else None
            else:
                node = cell.find(_NS + "v")
                if node is not None and node.text is not None:
                    if kind == "s":
                        value = shared[int(node.text)] if int(node.text) < len(shared) else None
                    elif kind in ("str", "e"):
                        value = node.text
                    elif kind == "b":
                        value = bool(int(node.text))
                    else:
                        try:
                            value = float(node.text)
                        except ValueError:
                            value = node.text
            values[index] = value
            if index == 0 and cell.get("s") is not None and int(cell.get("s")) < len(indents):
                indent = indents[int(cell.get("s"))]
        rows.append({"values": values, "level": int(element.get("outlineLevel", "0")), "indent": indent})
        element.clear()
        if len(rows) >= limit_rows:
            break
    book.close()
    return title, rows


def read_xls_outline(path, limit_rows=400000):
    """То же для старого xls (xlrd даёт уровень группировки через rowinfo_map)."""
    import xlrd
    book = xlrd.open_workbook(path, formatting_info=True)
    sheet = max(book.sheets(), key=lambda s: s.nrows)
    rows = []
    for r in range(min(sheet.nrows, limit_rows)):
        info = sheet.rowinfo_map.get(r)
        rows.append({"values": [sheet.cell_value(r, c) for c in range(sheet.ncols)],
                     "level": int(info.outline_level) if info is not None else 0, "indent": 0})
    return sheet.name, rows


_LEVEL_LABELS = {"system": ("систем",), "element": ("корпус", "секци", "элемент", "объект", "этаж", "очеред"),
                 "item": ("номенклатур", "материал", "наимен"), "doc": ("регистратор", "документ"),
                 "group": ("аналитик", "вид работ", "статья")}
_1C_QTY_WORDS = ("количество план", "кол-во план", "план лрв", "количество", "кол-во")


def _label_kind(text):
    low = text.lower()
    for kind, words in _LEVEL_LABELS.items():
        if any(w in low for w in words):
            return kind
    return "other"


def detect_1c_report(rows):
    """Отчёт 1С с группировками? Ищем строку шапки (ячейка с количеством
    плана) и под ней подписи уровней по одной в строке. Возвращает
    (индекс шапки, подписи уровней, колонка количества, прочие колонки)
    или None."""
    for index, row in enumerate(rows[:40]):
        cells = [_s(v) for v in row["values"]]
        if not cells or not cells[0]:
            continue
        qty_col = None
        for word in _1C_QTY_WORDS:
            qty_col = next((j for j, c in enumerate(cells) if j > 0 and word in c.lower()), None)
            if qty_col is not None:
                break
        if qty_col is None:
            continue
        labels = [cells[0]]
        cursor = index + 1
        while cursor < len(rows) and cursor < index + 12:
            values = [_s(v) for v in rows[cursor]["values"]]
            filled = [v for v in values if v]
            if len(filled) == 1 and values[0] and _num(rows[cursor]["values"][0]) is None:
                labels.append(values[0])
                cursor += 1
                continue
            break
        if len(labels) < 2 or not any(_label_kind(l) == "item" for l in labels):
            continue
        columns = {}
        for j, c in enumerate(cells):
            low = c.lower()
            if j == 0 or not c or j == qty_col:
                continue
            if "заказано по заявке" in low:
                columns["ordered"] = j
            elif "остаток по спец" in low:
                columns["rest"] = j
            elif low.startswith(("ед", "единиц")):
                columns["unit"] = j
        return index, labels, qty_col, columns
    return None


def parse_1c_report(path):
    """Отчёт 1С «Остатки по ЛРВ» с группировками → строки и заголовки групп
    в том же виде, что parse_lrv. Уровень строки — группировка Excel
    (outlineLevel), если её нет — отступ первой ячейки / 2.

    Заголовки: группы уровней выше «Номенклатуры», кроме уровней
    «Проект» (не несут смысла для РВ); у каждого — level и label
    («Система», «Аналитика 4»). Строки уровня «Регистратор» (документы
    ЛРВ и заявки) пропускаются."""
    lower = path.lower()
    if lower.endswith((".xlsx", ".xlsm")):
        sheet, rows = read_xlsx_outline(path)
    elif lower.endswith(".xls"):
        sheet, rows = read_xls_outline(path)
    else:
        return None
    found = detect_1c_report(rows)
    if found is None:
        return None
    header_index, labels, qty_col, extra = found
    kinds = [_label_kind(l) for l in labels]
    if "item" not in kinds:
        return None
    item_level = kinds.index("item")
    use_indent = all(r["level"] == 0 for r in rows[header_index + 1:header_index + 400])
    first_data = header_index + len(labels)

    def level_of(row):
        if use_indent:
            return min(row["indent"] // 2, len(labels) - 1)
        return row["level"]

    items = []
    headers = []
    stack = {}          # уровень → индекс заголовка в headers
    skipped = 0
    skipped_zero = 0
    docs = 0
    for index in range(first_data, len(rows)):
        row = rows[index]
        values = row["values"]
        name = _s(values[0]) if values else ""
        level = level_of(row)
        if not name and level < item_level:
            continue
        if level > item_level:
            docs += 1
            continue
        if level < item_level:
            if not name:
                continue
            low = name.lower()
            if any(low.startswith(w) for w in _TOTAL_WORDS):
                skipped += 1
                continue
            for deeper in [l for l in stack if l >= level]:
                del stack[deeper]
            if kinds[level] == "other" and labels[level].lower().startswith("проект"):
                continue        # уровень «Проект» — пропускаем, но ветку выше сохраняем
            headers.append({"row": index + 1, "text": name, "level": level, "label": labels[level]})
            stack[level] = len(headers) - 1
            continue
        # Строка номенклатуры.
        if not name:
            skipped += 1
            continue
        qty = _num(values[qty_col]) if qty_col < len(values) else None
        if qty is None or qty == 0:
            skipped_zero += 1
            continue
        item = {"row": index + 1, "name": name, "unit": _s(values[extra["unit"]]) if "unit" in extra and extra["unit"] < len(values) else "",
                "qty": qty, "headers": [stack[l] for l in sorted(stack)]}
        for key in ("ordered", "rest"):
            if key in extra and extra[key] < len(values):
                value = _num(values[extra[key]])
                if value is not None:
                    item[key] = value
        items.append(item)
    if not items:
        return None
    return {"sheet": sheet, "columns": {"name": 0, "qty": qty_col}, "items": items, "headers": headers,
            "skipped": skipped, "skipped_zero": skipped_zero, "docs": docs, "format": "1c_report",
            "levels": labels, "has_unit": "unit" in extra}


# ЛРВ, присланная 1С по API (web/1c_rv.php) строками JSON. Имена полей — как в 1С,
# регистр и пробелы не важны; синонимы — на случай другой выгрузки.
_JSON_FIELDS = {
    "name": ("номенклатура", "наименование", "материал", "name"),
    "unit": ("единицаизмерения", "единица", "едизм", "ед", "unit"),
    "qty": ("количество", "количествоплан", "колво", "кол", "qty"),
    "system": ("система", "system"),
    "group": ("аналитика", "аналитика4", "видработ", "статья", "group"),
    "element": ("элемент", "корпус", "секция", "element"),
    "code": ("код", "кодноменклатуры", "артикул", "code"),
    "uid": ("идентификатор", "идентификаторстроки", "строкаид", "uid", "lineid", "rowid"),
}


def _json_key(key):
    return re.sub(r"[^a-zа-я0-9]", "", str(key).lower().replace("ё", "е"))


def parse_1c_json(path):
    """ЛРВ из 1С в JSON: {"Строки": [{"Номенклатура", "ЕдиницаИзмерения", "Количество", "Система",
    "Аналитика"?, "Элемент"?, "Код"?}], …} (или сразу список строк) → тот же вид, что parse_1c_report:
    заголовки групп уровней «Аналитика» → «Элемент» → «Система», разметка — по словарю систем 1С."""
    import json
    with open(path, encoding="utf-8-sig") as handle:
        data = json.load(handle)
    rows = data
    if isinstance(data, dict):
        rows = next((v for k, v in data.items() if _json_key(k) in ("строки", "rows", "items", "материалы")), None)
    if not isinstance(rows, list):
        raise ValueError("в JSON нет списка «Строки»")
    labels = ["Аналитика", "Элемент", "Система", "Номенклатура"]
    headers = []
    index = {}          # (уровень, путь) → индекс заголовка
    items = []
    skipped = 0
    skipped_zero = 0
    has_unit = False
    for number, row in enumerate(rows, start=1):
        if not isinstance(row, dict):
            skipped += 1
            continue
        fields = {}
        for key, value in row.items():
            norm_key = _json_key(key)
            for field, names in _JSON_FIELDS.items():
                if norm_key in names and field not in fields:
                    fields[field] = value
        name = _s(fields.get("name"))
        if not name:
            skipped += 1
            continue
        qty = _num(fields.get("qty"))
        if qty is None or qty <= 0:
            skipped_zero += 1       # нет планового количества; отрицательное - разнесено больше плана, подбирать нечего
            continue
        path_ = []
        above = []
        for level, field in enumerate(("group", "element", "system")):
            text = _s(fields.get(field))
            if not text:
                continue
            path_.append(text)
            key = (level, tuple(path_))
            if key not in index:
                headers.append({"row": number, "text": text, "level": level, "label": labels[level]})
                index[key] = len(headers) - 1
            above.append(index[key])
        unit = _s(fields.get("unit"))
        has_unit = has_unit or bool(unit)
        item = {"row": number, "name": name, "unit": unit, "qty": qty, "headers": above}
        if fields.get("code"):
            item["code_1c"] = _s(fields["code"])
        if fields.get("uid"):
            item["uid"] = _s(fields["uid"])
        # Всё остальное, что прислала 1С (GUID номенклатуры, системы, аналитики, субконто…), — как есть:
        # вернётся в 1С вместе с РВ, чтобы связи и сквозные аналитики документов сохранились.
        ext = {}
        for key, value in row.items():
            norm_key = _json_key(key)
            if any(norm_key in names for names in _JSON_FIELDS.values()):
                continue
            if isinstance(value, (str, int, float, bool)) and _s(value) != "":
                ext[str(key)] = value
            elif isinstance(value, list) and value:
                ext[str(key)] = value       # «РаботыВ1С» сверки РВ и подобные списки 1С — как есть
        if ext:
            item["ext"] = ext
        items.append(item)
    return {"sheet": "JSON 1С", "columns": {"name": 0, "qty": 1}, "items": items, "headers": headers,
            "skipped": skipped, "skipped_zero": skipped_zero, "docs": 0, "format": "1c_report",
            "levels": labels, "has_unit": has_unit}


def parse_lrv(path):
    """Строки и заголовки групп ЛРВ.

    Возвращает словарь: items — [{row, name, unit, qty, system?, element?,
    headers: [индексы заголовков над строкой]}], headers — [{row, text}],
    columns, skipped (строк пропущено: итоги, пустые), sheet (имя листа)."""
    if path.lower().endswith(".json"):
        return parse_1c_json(path)
    if path.lower().endswith((".xlsx", ".xlsm", ".xls")):
        report = parse_1c_report(path)
        if report is not None:
            return report
    sheet, rows = read_table(path)
    header_index, cols = find_columns(rows)
    items = []
    headers = []
    skipped = 0
    stack = []      # индексы заголовков над текущей строкой (в порядке появления)
    for index, row in enumerate(rows):
        if index <= header_index:
            continue
        cell = lambda key: row[cols[key]] if key in cols and cols[key] < len(row) else None  # noqa: E731
        name = _s(cell("name"))
        qty = _num(cell("qty")) if "qty" in cols else None
        unit = _s(cell("unit")) if "unit" in cols else ""
        if not name and qty is None:
            if not any(_s(c) for c in row):
                continue
            # Текст в другой колонке — возможно, заголовок группы.
            name = next((_s(c) for c in row if _s(c)), "")
            if not name:
                continue
        low = name.lower()
        if any(low.startswith(w) for w in _TOTAL_WORDS):
            skipped += 1
            continue
        if qty is None:
            # Строка без количества — заголовок группы (система, элемент, раздел).
            headers.append({"row": index + 1, "text": name})
            stack.append(len(headers) - 1)
            continue
        item = {
            "row": index + 1,
            "name": name,
            "unit": unit,
            "qty": qty,
            "headers": list(stack),
        }
        if "system" in cols:
            item["system_raw"] = _s(cell("system"))
        if "element" in cols:
            item["element_raw"] = _s(cell("element"))
        items.append(item)
    return {"sheet": sheet, "columns": cols, "items": items, "headers": headers, "skipped": skipped, "format": "table"}


def normalize_system(section, raw):
    """Значение системы для bind.py по словарю A2; None — не распознано."""
    text = _s(raw)
    if not text:
        return None
    if section == "СС":
        match = re.search(r"\b(\d{1,2}(?:\.\d)?)\b", text)
        return match.group(1) if match else None
    table = SYSTEMS.get(section, {})
    upper = text.upper().replace("Ё", "Е")
    if upper in table:
        return table[upper]
    # Код системы внутри фразы: «В2 Противопожарный водопровод», «Система К1н».
    for token in re.findall(r"[А-ЯA-Z]{1,4}\d{0,2}[НФ]?", upper):
        if token in table:
            return table[token]
    for key, value in table.items():
        if len(key) > 3 and key in upper:
            return value
    return None


def guess_section(headers):
    """Раздел по заголовкам групп, если он не задан: чей словарь систем
    узнаёт больше заголовков. None — не определить."""
    scores = {}
    for section in SECTIONS:
        if section == "СС":
            continue        # у СС система — число, совпадёт с чем угодно
        scores[section] = sum(1 for h in headers if normalize_system(section, h["text"]) is not None)
    best = max(scores.items(), key=lambda kv: kv[1]) if scores else (None, 0)
    return best[0] if best[1] > 0 else None


_ELEMENT_RE = re.compile(r"\b(корпус|секци|паркинг|этаж|блок|стилобат|подземн|надземн|очередь)")
_ORDER_RE = re.compile(r"з/н|заказ[\s\-]*наряд|наряд|\bнз\b|доп\.?\s*работ|дополнит")


def guess_headers(section, headers, fmt="table"):
    """Разметка заголовков без модели.

    Отчёт 1С (fmt == "1c_report"): группа уровня «Система» — по словарю
    SYSTEM_1C (раздел и система), «Накладные расходы», «Вспомогательные
    работы» и БНР — не включать, «Работы по З/Н №…» — элемент (отдельный
    объём работ). Таблица: система — по коду в тексте («В2 Противопожарный
    водопровод»), элемент — по словам «корпус», «секция», «паркинг»."""
    marks = {}
    for i, header in enumerate(headers):
        text = header["text"]
        low = text.lower()
        if fmt == "1c_report":
            kind = _label_kind(header.get("label", ""))
            if kind == "system":
                sec, system = system_1c(text)
                if sec == "skip":
                    marks[i] = {"kind": "skip", "reason": "накладные расходы — не материалы работ"}
                elif sec:
                    marks[i] = {"kind": "system", "section": sec, "system": system, "confidence": 0.9}
                else:
                    marks[i] = {"kind": "other", "unresolved": True}
            elif kind == "group":
                if re.search(r"вспомогат|накладн|\bбнр\b", low):
                    marks[i] = {"kind": "skip", "reason": "вспомогательные работы, накладные расходы, БНР"}
                elif _ORDER_RE.search(low):
                    marks[i] = {"kind": "element", "element": text}
                else:
                    marks[i] = {"kind": "other"}
            elif kind == "element":
                marks[i] = {"kind": "element", "element": text}
            else:
                marks[i] = {"kind": "other"}
            continue
        system = normalize_system(section, text) if section in SECTIONS else None
        if system is not None:
            marks[i] = {"kind": "system", "section": section, "system": system, "confidence": 0.8}
        elif _ELEMENT_RE.search(low):
            marks[i] = {"kind": "element", "element": text}
        else:
            marks[i] = {"kind": "other"}
    return marks


def split_system(value):
    """«ВК|В1» → ("ВК", "В1"); «В1» → (None, "В1")."""
    text = _s(value)
    if "|" in text:
        section, system = text.split("|", 1)
        return (section.strip() or None), (system.strip() or None)
    return None, (text or None)


_UNIT_HEADS_M = ("кабель", "провод", "труба", "трубка", "трубопровод", "воздуховод", "лоток", "короб", "кабель-канал",
                 "шина", "профиль", "металлорукав", "гофра", "гофротруба", "шнур", "лента", "уголок", "швеллер", "полоса",
                 "канат", "трос", "рукав", "шланг", "проволока", "жгут", "трубопровод", "кабельканал", "пруток", "арматура")
_UNIT_KG_RE = re.compile(r"краск|грунт|мастик|герметик|состав|кле[йе]|смесь|пена|эмаль|растворител|припой|флюс")


def guess_unit(name):
    """Единица строки по типу материала, когда в выгрузке её нет:
    протяжённые — м, составы — кг, изоляция — м², остальное — шт.
    Возвращает (единица, уверенность 0–1)."""
    low = _s(name).lower().replace("ё", "е")
    first = re.sub(r"[^a-zа-я0-9\- ]", " ", low).split()
    first = first[0] if first else ""
    if re.search(r"\b(\d+(?:[.,]\d+)?)\s*(кг|л|м2|м²|м3|м³)\b", low) and not re.search(r"\b\d+\s*(шт|компл)", low):
        unit = re.search(r"\b\d+(?:[.,]\d+)?\s*(кг|л|м2|м²|м3|м³)\b", low).group(1)
        return {"м²": "м2", "м³": "м3"}.get(unit, unit), 0.5
    if first in _UNIT_HEADS_M or (first == "лоток" or first.startswith("кабель")):
        if re.search(r"\bl\s*=|длин[аы]|\d{3,4}\s*мм\b.*(лоток|короб)", low):
            return "шт", 0.4
        return "м", 0.6
    if _UNIT_KG_RE.search(" ".join(low.split()[:2])):
        return "кг", 0.4
    if re.search(r"^(изоляц|теплоизоляц|мат\b|плита|рулон|пленк|мембран)", low):
        return ("м", 0.4) if re.search(r"трубн|трубк|цилиндр", low) else ("м2", 0.4)
    return "шт", 0.6


def apply_marks(section, parsed, marks, default_system=None, force_system=None):
    """Раздел, система и элемент каждой строки по размеченным заголовкам
    (ближайший сверху) или по колонкам файла; строки под заголовком «не
    включать» получают skip. default_system — «В1» или «ВК|В1» для строк,
    у которых системы нет ни там, ни там. force_system — система, выбранная
    пользователем при загрузке: её получают все строки (элементы и «не
    включать» по заголовкам сохраняются)."""
    headers = parsed["headers"]
    default_section, default_sys = split_system(default_system)
    force_section, force_sys = split_system(force_system)
    for item in parsed["items"]:
        system = None
        element = None
        item_section = None
        skip = None
        if item.get("system_raw"):
            item_section, system = split_system(item["system_raw"])
            if system is not None and item_section is None:
                system = normalize_system(section, system)
        if item.get("element_raw"):
            element = item["element_raw"]
        for h in reversed(item["headers"]):
            mark = marks.get(h) or {}
            kind = mark.get("kind")
            if kind == "skip":
                skip = mark.get("reason") or headers[h]["text"]
                break
            if system is None and kind == "system" and mark.get("system"):
                system = mark["system"]
                item_section = mark.get("section")
            if element is None and kind == "element" and mark.get("element"):
                element = mark["element"]
        if force_sys:
            system = force_sys
            item_section = force_section or item_section
        elif system is None and default_sys:
            system = default_sys
            item_section = default_section
        item["system"] = system
        item["section"] = item_section or (section if section in SECTIONS else None)
        item["element"] = element or ""
        item["skip"] = skip
        item["header_path"] = " / ".join(headers[h]["text"] for h in item["headers"][-3:])
    return parsed
