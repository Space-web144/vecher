# -*- coding: utf-8 -*-
"""
Шаги агента РВ, которые делает модель (Claude):

1. mark_headers — разметка заголовков групп ЛРВ: какой заголовок задаёт
   систему (по словарю A2), какой — элемент (корпус, секция, паркинг).
   Без системы код работы не выбирается, а в выгрузке 1С система — это
   заголовок группы, не колонка.
2. review_rows — проверка строк «на проверку» и строк без работы по
   карточке раздела (часть B мастер-инструкции) и решениям владельца
   (A11): подтвердить код инструмента, предложить другой или задать
   вопрос. Рекомендации не меняют РВ сами — их смотрит человек
   (мастер-инструкция A13: строки «на проверку» нужно смотреть человеку).

Ключ — тот же, что у остального сайта (common/anthropic_client). Модель
своя — Opus 5.5 (решение владельца 01.11.2026); усилие по шагу: разметка
заголовков — medium (разнести заголовки по словарю), проверка строк — high
(рассуждение по карточке раздела, но один ответ без инструментов: xhigh
документация API оставляет для работы агента дольше 30 минут). Меняются
полями model_rv, effort_rv (проверка) и effort_rv_mark (разметка) в файле
с ключом, без правки кода. Запросы идут потоком: на высоком усилии ответ
готовится минутами, и обычный запрос упирался бы в таймаут чтения, а поток
держат ping-события API; heartbeat получает их, чтобы статус задачи не
выглядел зависшим.

Если модель недоступна, оба шага пропускаются: заголовки размечаются по
кодам систем в тексте (rv_input.guess_headers), проверка не делается, и
об этом сказано в сводке.
"""
import json
import os
import re
import time

from rv_input import SYSTEMS, normalize_system

HERE = os.path.dirname(os.path.abspath(__file__))
MASTER_DOC = os.path.join(HERE, "rv", "docs", "00_Мастер_инструкция_агента_РВ.md")

RV_MODEL = "claude-opus-5-5"
RV_EFFORT = "high"           # проверка строк
RV_MARK_EFFORT = "medium"    # разметка заголовков
# В max_tokens входят и размышление, и ответ; на высоком усилии документация
# API советует начинать с 64 тыс. Это предохранитель — оплачивается только
# написанное.
MARK_MAX_TOKENS = 64000
REVIEW_MAX_TOKENS = 64000
REVIEW_BATCH = 40
HEARTBEAT_SEC = 30          # не чаще — событий потока много, а статус пишется в файл

SECTION_CARD_NUM = {"ВК": "1", "ОВ1": "2", "ОВ2": "3", "ЭОМ": "4", "СС": "5"}
# РВ в коде 12 (заказ-наряд РВР): перевод кода работы в код 12 (bind.rvr_code) — ставит web_rv_run; None — обычная РВ.
CODE_TRANSLATE = None

MARK_SCHEMA = {
    "type": "object",
    "properties": {
        "headers": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "i": {"type": "integer"},
                    "kind": {"type": "string", "enum": ["system", "element", "section", "other"]},
                    "system": {"type": "string"},
                    "element": {"type": "string"},
                },
                "required": ["i", "kind"],
            },
        },
        "default_system": {"type": "string"},
        "notes": {"type": "array", "items": {"type": "string"}},
    },
    "required": ["headers"],
}

REVIEW_SCHEMA = {
    "type": "object",
    "properties": {
        "rows": {
            "type": "array",
            "items": {
                "type": "object",
                "properties": {
                    "id": {"type": "integer"},
                    "verdict": {"type": "string", "enum": ["подтвердить", "заменить", "вопрос"]},
                    "code": {"type": "string"},
                    "role": {"type": "string"},
                    "reason": {"type": "string"},
                    "question": {"type": "string"},
                },
                "required": ["id", "verdict", "reason"],
            },
        },
        "questions": {"type": "array", "items": {"type": "string"}},
    },
    "required": ["rows"],
}


def _strict(schema):
    """Структурированный вывод API требует у каждого объекта схемы "additionalProperties": false —
    без него запрос отклоняется с HTTP 400 («запрос отклонён как некорректный»)."""
    if isinstance(schema, dict):
        if schema.get("type") == "object":
            schema.setdefault("additionalProperties", False)
        for value in schema.values():
            _strict(value)
    elif isinstance(schema, list):
        for value in schema:
            _strict(value)
    return schema


_strict(MARK_SCHEMA)
_strict(REVIEW_SCHEMA)


def _section_text(doc, start_pattern, end_pattern):
    start = re.search(start_pattern, doc, re.M)
    if not start:
        return ""
    end = re.search(end_pattern, doc[start.end():], re.M)
    return doc[start.start(): start.end() + (end.start() if end else len(doc))]


def master_parts(section):
    """Куски мастер-инструкции для проверки: A4 (приоритет), A7 (роли),
    A11 (решения владельца), A12 (ошибки образцов) и карточка раздела."""
    try:
        doc = open(MASTER_DOC, encoding="utf-8").read()
    except OSError:
        return ""
    parts = []
    for num in ("A4", "A7", "A11", "A12"):
        parts.append(_section_text(doc, r"^### %s\." % num, r"^### A\d+\."))
    card_num = SECTION_CARD_NUM.get(section)
    if card_num:
        parts.append(_section_text(doc, r"^### %s\. Раздел " % card_num, r"^### \d\. Раздел |^## Часть C"))
    return "\n\n".join(p for p in parts if p)


def _system_dictionary(section):
    if section == "СС":
        return ("код ветки и подветки по индексу: 1, 2.1, 2.2, 3, 4, 5, 6, 7, 8, 9.1…9.9, "
                "10.1…10.4, 11, 12, 13, 14, 15")
    values = sorted(set(SYSTEMS.get(section, {}).values()))
    return ", ".join(values)


def model_of(client, step="review"):
    """Модель и усилие агента РВ для шага review (проверка строк) или mark (разметка заголовков):
    поля model_rv / effort_rv / effort_rv_mark файла с ключом или значения по умолчанию."""
    model = getattr(client, "model_rv", None) or RV_MODEL
    if step == "mark":
        return model, getattr(client, "effort_rv_mark", None) or RV_MARK_EFFORT
    return model, getattr(client, "effort_rv", None) or RV_EFFORT


def _ask(client, turns, step, heartbeat=None, **kwargs):
    """Запрос модели агента РВ потоком; heartbeat() — не чаще раза в HEARTBEAT_SEC, пока ответ готовится."""
    model, effort = model_of(client, step)
    last = [time.time()]

    def on_event(event, accumulator):
        if heartbeat is not None and time.time() - last[0] >= HEARTBEAT_SEC:
            last[0] = time.time()
            heartbeat()

    return client.messages(turns, model=model, effort=effort, on_event=on_event, **kwargs)


def mark_headers(client, section, headers, sample_items, log=None, heartbeat=None):
    """Разметка заголовков моделью. Возвращает (marks, default_system, notes);
    marks — {индекс заголовка: {kind, system?, element?}}."""
    if not headers:
        return {}, None, []
    lines = ["%d\t%s" % (i, h["text"]) for i, h in enumerate(headers)]
    sample = ["%s | %s | %s" % (it["name"], it.get("unit", ""), it.get("qty", "")) for it in sample_items[:25]]
    system_prompt = (
        "Ты размечаешь выгрузку ЛРВ (локальная ресурсная ведомость) из 1С для агента построения РВ. "
        "Раздел проекта: %s. Строки без количества в выгрузке — заголовки групп. Для каждого заголовка "
        "определи, что он задаёт: system — система инженерных сетей (значение строго из словаря раздела), "
        "element — элемент объекта (корпус, секция, паркинг, этаж, очередь: верни его название как в файле), "
        "section — название раздела или проекта в целом, other — всё остальное (группы материалов, подзаголовки). "
        "Словарь систем раздела: %s. Если заголовок — система, но её нет в словаре, укажи ближайшее значение словаря "
        "и напиши об этом в notes. Если во всей выгрузке система одна и видна только из названия раздела или "
        "примеров строк, укажи её в default_system. Не выдумывай: сомневаешься — kind=other."
    ) % (section, _system_dictionary(section))
    user = ("Заголовки групп (индекс и текст):\n%s\n\nПримеры строк материалов (наименование | ед. | кол-во):\n%s"
            % ("\n".join(lines), "\n".join(sample)))
    response = _ask(client, [{"role": "user", "content": user}], "mark", heartbeat=heartbeat, system=system_prompt,
                    max_tokens=MARK_MAX_TOKENS, output_schema=MARK_SCHEMA)
    from common.anthropic_client import extract_text
    data = json.loads(extract_text(response))
    marks = {}
    for entry in data.get("headers") or []:
        i = entry.get("i")
        if not isinstance(i, int) or i < 0 or i >= len(headers):
            continue
        kind = entry.get("kind", "other")
        mark = {"kind": kind}
        if kind == "system":
            system = normalize_system(section, entry.get("system") or "") or normalize_system(section, headers[i]["text"])
            if system is None:
                mark = {"kind": "other"}
            else:
                mark["system"] = system
        elif kind == "element":
            mark["element"] = (entry.get("element") or headers[i]["text"]).strip()
        marks[i] = mark
    default_system = normalize_system(section, data.get("default_system") or "")
    notes = [str(n) for n in (data.get("notes") or []) if str(n).strip()]
    if log:
        log("разметка заголовков: %d системных, %d элементов из %d"
            % (sum(1 for m in marks.values() if m["kind"] == "system"),
               sum(1 for m in marks.values() if m["kind"] == "element"), len(headers)))
    return marks, default_system, notes


def _row_line(item, binding):
    flags = "; ".join(binding.get("flags") or [])
    return ("id %s | %s | %s | %s | система %s | код %s | работа %s | роль %s | уверенность %s | источник: %s%s"
            % (item["id"], item["name"], item.get("unit", ""), item.get("qty", ""), item.get("system") or "—",
               binding.get("code") or "—", binding.get("work") or "—", binding.get("role") or "—",
               binding.get("confidence"), binding.get("source") or "—",
               (" | флаги: " + flags) if flags else ""))


def review_rows(client, section, object_type, items, bindings, works, log=None, guidance=None,
                progress=None, heartbeat=None, audit=None, smeta=None, local=None, local_blocks=None, all_rows=False):
    """Проверка строк «на проверку» и без работы. Возвращает (по id:
    {verdict, code, work, role, reason, question}, вопросы владельцу).
    guidance — замечания инженеров к агенту (страница РВ, «Замечания к агенту»): учитываются как решения
    владельца, если относятся к строкам. progress(сделано, всего) — перед каждой порцией строк,
    heartbeat() — пока модель готовит ответ (см. _ask).
    audit — сверка РВ из 1С ({id: работы строки в 1С текстом}, rv_audit.text_1c): проверяются все переданные
    строки — те, где разнос в 1С и инструмента расходятся; модель видит обе работы и решает, кто прав.
    smeta — работы сметы в 1С текстом (web_rv_run.smeta_text): модель предпочитает их, если подходят.
    local — ТЗ сметчика только для этой РВ текстом (задание и файлы Excel/Word/CSV, web_rv_run.local_material):
    главнее общих замечаний и библиотеки; local_blocks — PDF и картинки ТЗ блоками сообщения (модель читает их сама).
    all_rows — проверить все переданные строки, не только «на проверку» (пересборка по указаниям: указание может
    касаться и строк, в которых агент уверен)."""
    by_id = {it["id"]: it for it in items}
    todo = list(bindings) if audit or all_rows else [b for b in bindings if b.get("review") or not b.get("code")]
    if not todo:
        return {}, []
    rules = master_parts(section)
    if audit:
        task = ("Инструмент bind.py привязал строки ЛРВ к работам ИСР; те же строки инженер раньше разнёс вручную в 1С. "
                "Ниже — строки, где разнос расходится («в 1С: …» — работы строки в 1С с количеством под каждой). "
                "Проверь каждую по карточке раздела и решениям владельца и вынеси вердикт: «подтвердить» — верен код "
                "инструмента; «заменить» — верна работа из 1С (укажи её код) или обе неверны (укажи верный код — только "
                "действующий код из карточки или карты кодов раздела, не выдумывай) и роль; «вопрос» — решить нельзя, "
                "сформулируй вопрос владельцу. Разнос в 1С не считай верным по умолчанию — там бывают ошибки. ")
    else:
        task = ("Инструмент bind.py уже привязал строки ЛРВ к работам ИСР; ниже — строки, которые он отметил «на проверку» "
                "или не смог привязать. Проверь каждую по карточке раздела и решениям владельца и вынеси вердикт: "
                "«подтвердить» — код инструмента верен; «заменить» — укажи верный код (только действующий код из карточки "
                "или карты кодов раздела, не выдумывай) и роль; «вопрос» — кода определить нельзя, сформулируй вопрос владельцу. "
                "Строка с флагом F-1C уже разнесена инженером в 1С: код в строке — из 1С, в флаге — что предлагает инструмент; "
                "«подтвердить» — верен код 1С, «заменить» — верен код инструмента или другой. Разнос в 1С не считай верным по умолчанию. "
                "Флаг F-SMETA — такой работы нет в смете 1С, в флаге — похожие работы сметы: если одна из них подходит, предложи её. ")
    system_prompt = (
        "Ты — агент построения РВ (ресурсной ведомости) по ЛРВ из 1С в компании «Альфастрой». Раздел %s, тип объекта %s. "
        "%sПричину пиши коротко, со ссылкой на пункт карточки или решение [В]. Общие вопросы владельцу — в questions.\n\n"
        "Выдержки из мастер-инструкции агента РВ:\n\n%s"
    ) % (section, object_type or "не указан", task, rules)
    if guidance:
        system_prompt += ("\n\nЗамечания инженеров к агенту РВ (оставлены после проверки прежних РВ; учитывай их как "
                          "решения владельца, если относятся к строкам; противоречат карточке — вынеси вопрос):\n"
                          + "\n".join("- " + str(note)[:600] for note in guidance))
    if local or local_blocks:
        system_prompt += ("\n\nТЗ сметчика для ЭТОЙ РВ (дано только для неё: решения владельца по этому объекту, главнее общих "
                          "замечаний и решений [В] из библиотеки). Это может быть текст задания и/или файлы: смета (заказчика "
                          "или своя), спецификация, ведомость, письмо. Следуй ТЗ для строк, к которым оно относится; если ТЗ "
                          "расходится с карточкой раздела — всё равно следуй ТЗ и напиши это в причине, со ссылкой на ТЗ. "
                          "Если в ТЗ смета — материал относится к той её работе, под которой он стоит; работу сметы переведи "
                          "в код ИСР (только действующий код из карточки или карты кодов раздела). Названия материалов в ЛРВ "
                          "и в ТЗ пишутся по-разному — сопоставляй по смыслу, типу и размерам. К чему ТЗ не относится — "
                          "проверяй как обычно." + (" Файлы PDF и картинки ТЗ — в начале сообщения." if local_blocks else "")
                          + ("\n\n" + str(local) if local else ""))
    if CODE_TRANSLATE is not None:
        system_prompt += ("\n\nЭта РВ — по заказ-наряду РВР: она собирается из работ кода 12 («работы, не предусмотренные "
                          "основным проектом», разделы 12.1.11–12.1.15). Работы кода 12 повторяют работы 6.2.3 по названию и "
                          "материалам, поэтому правила карточки те же. У строк стоят коды 12 — это пары работ 6.2.3 с тем же "
                          "названием. Если заменяешь работу — дай код 6.2.3… по карточке (сайт сам поставит его пару из кода "
                          "12) или код 12, если знаешь его из работ сметы. Флаг F-RVR — в коде 12 такой работы нет или она "
                          "взята из другой подсистемы: предложи ближайшую подходящую работу или задай вопрос.")
    if smeta:
        system_prompt += ("\n\nРаботы сметы в 1С (сметные позиции с объёмами). Материал обычно относится к одной из них — "
                          "предпочитай работу сметы, если она подходит по карточке; работу не из сметы предлагай, только когда "
                          "в смете подходящей нет:\n" + str(smeta)[:6000])
    result = {}
    questions = []
    from common.anthropic_client import extract_text
    for start in range(0, len(todo), REVIEW_BATCH):
        batch = todo[start:start + REVIEW_BATCH]
        lines = [_row_line(by_id.get(b["id"], {"id": b["id"], "name": "?"}), b)
                 + ((" | в 1С: " + str(audit.get(b["id"]) or "—")) if audit else "") for b in batch]
        if progress is not None:
            progress(start, len(todo))
        content = "Строки на проверку:\n" + "\n".join(lines)
        if local or local_blocks:
            # ТЗ большое и одно на все порции строк: точки кэша — в конце промта и после файлов ТЗ, чтобы следующие
            # порции читали их из кэша, а не оплачивали заново.
            system = [{"type": "text", "text": system_prompt, "cache_control": {"type": "ephemeral"}}]
            if local_blocks:
                head = [dict(block) for block in local_blocks]
                head[-1]["cache_control"] = {"type": "ephemeral"}
                content = head + [{"type": "text", "text": content}]
            response = _ask(client, [{"role": "user", "content": content}], "review", heartbeat=heartbeat, system=system,
                            max_tokens=REVIEW_MAX_TOKENS, output_schema=REVIEW_SCHEMA)
        else:
            response = _ask(client, [{"role": "user", "content": content}],
                            "review", heartbeat=heartbeat, system=system_prompt, max_tokens=REVIEW_MAX_TOKENS,
                            output_schema=REVIEW_SCHEMA, cache=True)
        data = json.loads(extract_text(response))
        for row in data.get("rows") or []:
            rid = row.get("id")
            if rid not in by_id:
                continue
            verdict = row.get("verdict", "вопрос")
            code = (row.get("code") or "").strip()
            entry = {"verdict": verdict, "reason": (row.get("reason") or "").strip(),
                     "question": (row.get("question") or "").strip(), "role": (row.get("role") or "").strip()}
            if verdict == "заменить":
                if CODE_TRANSLATE is not None and code in works:
                    # РВ в коде 12: модель дала код 6.2.3 по карточке — ставим его пару; пары нет — вопрос.
                    pair = CODE_TRANSLATE(code)
                    if not pair:
                        entry["question"] = entry["question"] or (
                            "Предложена работа %s «%s», но в коде 12 (РВР) такой нет — выберите работу кода 12" % (code, works[code][:80]))
                    code = pair or ""
                if code in works:
                    entry["code"] = code
                    entry["work"] = works[code]
                else:
                    # Код не из справочника — не предлагаем, переводим в вопрос.
                    entry["verdict"] = "вопрос"
                    entry["question"] = entry["question"] or ("Предложен код %s, которого нет в справочнике КЦ" % (code or "—"))
            result[rid] = entry
        questions.extend(str(q) for q in (data.get("questions") or []) if str(q).strip())
        if log:
            log("проверка моделью: %d из %d строк" % (min(start + REVIEW_BATCH, len(todo)), len(todo)))
    return result, questions
